package mud.combat;

import mud.core.*;

import java.util.List;
import java.util.Random;

public class CombatManager {
    private static final Random random = new Random();

    public static String performAttack(Mob attacker, Mob target) {
        if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
            return "Invalid combatants.";
        }
        
        
        Room curRoom = attacker.getCurrentRoom();
        attacker.setCurrentRoom(curRoom);
        target.setCurrentRoom(curRoom);
        
        StringBuilder result = new StringBuilder();

        // Primary attack (main hand weapon)
        ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
        result.append(performSingleAttack(attacker, target, mainHand, false));
        
        // Offhand attack if dual wield effect active
        if (attacker.hasEffect("dual_wield")) {
            ObjectItem offHand = attacker.getEquipment().get(EquipSlot.OFFHAND);
            if (offHand != null && offHand.isWeapon()) {
                result.append("\n").append(performSingleAttack(attacker, target, offHand, true));
            }
        }
        
        if (target.getTarget() == null) {
            target.setTarget(attacker);
        }

     // after attack messages
        String hpMpStatus = String.format("%s:HP: %d/%d MP: %d/%d  %s:HP: %d/%d MP: %d/%d",
            attacker.getMobName(), attacker.getCurrentHP(), attacker.getMaxHP(), attacker.getCurrentMP(), attacker.getMaxMP(),
            target.getMobName(), target.getCurrentHP(), target.getMaxHP(), target.getCurrentMP(), target.getMaxMP());

        // Send directly to players
        if (attacker instanceof Player playerAttacker) {
            playerAttacker.sendMessage(hpMpStatus);
        }
        if (target instanceof Player playerTarget && playerTarget != attacker) {
            playerTarget.sendMessage(hpMpStatus);
        }

        // Optionally broadcast to room if you want everyone to see HP/MP status

        return result.toString().trim();

       
    }

    public static String getCombatStatus(Mob a, Mob b) {
        return a.getMobName() + ":HP: " + a.getCurrentHP() + "/" + a.getMaxHP() +
               " MP: " + a.getCurrentMP() + "/" + a.getMaxMP() + "  " +
               b.getMobName() + ":HP: " + b.getCurrentHP() + "/" + b.getMaxHP() +
               " MP: " + b.getCurrentMP() + "/" + b.getMaxMP();
    }


    private static String performSingleAttack(Mob attacker, Mob target, ObjectItem weapon, boolean isOffhand) {
    	attacker.setTarget(target);
        int baseDamage = rollWeaponDamage(weapon, attacker);
        int bonusDamage = attacker.getStat("Strength") / 2;
        double scaledDamage = (baseDamage + bonusDamage) * attacker.getRank().getMultiplier();
        int totalDamage = (int) scaledDamage;

        // Vampiric healing
        double vampPercent = weapon != null ? weapon.getVampiricPercent() : 0.0;
        int vampHeal = (int) (totalDamage * vampPercent);
        if (vampHeal > 0) {
            attacker.heal(vampHeal);
        }

        // Damage type
        WeaponDamageType dmgType = (weapon != null && weapon.getDamageType() != null)
            ? weapon.getDamageType()
            : WeaponDamageType.HIT;

        String icon = dmgType.getIcon();
        String verb = dmgType.getPrettyName().toLowerCase();
        String handLabel = isOffhand ? " (offhand)" : "";

        // Apply damage
        target.takeDamage(totalDamage);

        // Messaging
        String attackerMsg = "You " + verb + handLabel + " " + target.getMobName() + " for " + totalDamage + " damage! " + icon;
        String targetMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " you for " + totalDamage + " damage! " + icon;
        String roomMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " " + target.getMobName() + "! " + icon;

        
        
        if (attacker instanceof Player playerAttacker) {
            playerAttacker.sendMessage(attackerMsg); // this outputs to client
        }
        // Send message to target (player or mob)
        if (target instanceof Player targetPlayer) {        	
            targetPlayer.sendMessage(targetMsg); // this is outputting now
        } else {
        	System.out.println("🔎 Target class: " + target.getClass().getName());

            System.out.println("[Mob] " + targetMsg); // this outputs to server for log/debug
        }

        attacker.getCurrentRoom().broadcastToExcept(attacker, target, roomMsg);

        deathStuff(attacker,target);

        return attackerMsg;
    }

    public static void deathStuff(Mob attacker, Mob target) {
        // Death check
        if (target.isDead()) {
            String deathMsg = target.getMobName() + " has been slain!";
            
            if (attacker instanceof Player playerAttacker) {
                playerAttacker.sendMessage(deathMsg);
                playerAttacker.setCurrentHP(1);
                playerAttacker.setCurrentMP(1);
            }

            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You have been slain!");
                // Optionally: handle player respawn logic or death penalty
            }

            // Broadcast death to everyone else in the room
            attacker.getCurrentRoom().broadcastToExcept(attacker, target, deathMsg);

            // Grant EXP
            if (attacker instanceof Player player) {
                int exp = target.getExpValue();
                player.gainExpShared(exp);
            }

            // Clear attacker’s target
            attacker.setTarget(null);

            // Clear other mobs that may be targeting this one
            for (Mob mob : WorldManager.getAllMobs()) {
                if (mob.getTarget() == target) {
                    mob.setTarget(null);
                }
            }

            // Drop loot (if any)
            List<ObjectItem> loot = target.dropAllLoot();
            for (ObjectItem item : loot) {
                attacker.getCurrentRoom().addObject(item);
            }

            // Optional: create a corpse item
            ObjectItem corpse = new ObjectItem("corpse of " + target.getMobName());
            corpse.setShortDescription("a corpse of " + target.getMobName());
            corpse.setType(ObjectType.TRASH);
            corpse.setContents(loot);
            attacker.getCurrentRoom().addObject(corpse);

            // Remove mob from room or schedule for cleanup
            target.setCurrentRoom(null); // or mark as inactive
        }
    }
    
    private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
        if (weapon == null || weapon.getDamageDice() == null) {
            int level = attacker.getLevel();
            
            // Scale dice based on level (example: Monk's martial arts)
            if (level >= 75) return rollDice(4, 6);
            if (level >= 50) return rollDice(3, 6);
            if (level >= 20) return rollDice(2, 6);
            if (level >= 10) return rollDice(1, 8);
            return rollDice(1, 6);
        }

        String[] parts = weapon.getDamageDice().split("d");
        int num = Integer.parseInt(parts[0]);
        int sides = Integer.parseInt(parts[1]);

        return rollDice(num, sides) + weapon.getDamageBonus();
    }

    private static int rollDice(int num, int sides) {
        int total = 0;
        for (int i = 0; i < num; i++) {
            total += random.nextInt(sides) + 1;
        }
        return total;
    }
} 
// end CombatManager
