package mud.config;

import java.io.File;

public class Config {

	private static final String gameDesigner = "Jan Ouellette";
	private static final String gameDedication = "Jon Prue, a true friend and inspiration. The man who introduced me to the Empire and Imperium MUDs.  I started writing this game as we could not easily play together when he was in China.  Sadly he passed away before I was able to get a demo out to him.  He was a very well travelled man and expierenced many things in his life. He suffered silently to alcohol addiction, but if he had just reached out to us, we would have given him all the love and attention he needed.  You will be missed my friend.";
	private static final String gameVersion = "v0.7.0.1";
	
	// v7.0.1  redesign of base structure on game, modularized game systems
	// v7.0.0 game created a Server and Client login system for game
	// v6.0.0 player objects gone, players are now Mobs
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux nox
	// game v0.5.0 introduces zone objects and zoneScript objects

	
	
    // Base directory for all MUD data files
    public static final String DATA_DIR = "mud_data";

    // Subdirectories for different data types
    public static final String PLAYERS_DIR = DATA_DIR + File.separator + "players";
    public static final String WORLDS_DIR = DATA_DIR + File.separator + "worlds";
    public static final String ZONES_DIR = DATA_DIR + File.separator + "zones";
    public static final String SCRIPT_DIR = DATA_DIR + File.separator + "zones";
    public static final String MOBS_DIR = DATA_DIR + File.separator + "mobs";
    public static final String OBJECTS_DIR = DATA_DIR + File.separator + "objects";
    public static final String LOGS_DIR = DATA_DIR + File.separator + "logs";
    public static final String HELPS_DIR = DATA_DIR + File.separator + "helps";

    // Game settings
    public static final int SERVER_PORT = 4000;
    public static final int CLIENT_TIMEOUT_MILLIS = 10 * 60 * 1000; // 10 minutes
    
    public static final String DEFAULT_WORLD_ID = "1";
    public static final int DEFAULT_LOGIN_ZONE = 0;
    public static final int DEFAULT_LOGIN_ROOM = 0;
    
    // UNIVERSAL DAY LENGTH
    public static final int tickIntervalMillis = 5000; // 5 seconds per tick
    public final static int ticksPerDay = 60; // 60 ticks = 1 game day
    public final static int sunriseTick = 15; // example: tick 15
    public final static int sunsetTick = 45;  // example: tick 45

    // Ensures the directory structure exists on startup
    public static void createDirectories() {
        new File(PLAYERS_DIR).mkdirs();
        new File(WORLDS_DIR).mkdirs();
        new File(ZONES_DIR).mkdirs();
        new File(MOBS_DIR).mkdirs();
        new File(OBJECTS_DIR).mkdirs();
        new File(LOGS_DIR).mkdirs();
        new File(HELPS_DIR).mkdirs();
               
    }

    // You can add more config values or helper methods here...

    private Config() {
        // Prevent instantiation
    }
}
