package mud.core;

public enum MobBehaviorFlag {
    STATIONARY(0 << 0),     // Default
    WANDERS(1 << 1),
    SENTRY(1 << 2),
    AGGRESSIVE(1 << 3),
    PROTECTOR(1 << 4),
    JANITOR(1 << 5),
    TALKER(1 << 6),
    BANKER(1 << 7),
    BLACKSMITH(1 << 8),
    SHOPKEEPER(1 << 9),
    INNKEEPER(1 << 10),
    USE_SPELLS(1 << 11),
    REINCARNATE(1 << 12),
    HUNTER(1 << 13),
    CITYGUARD(1 << 14);

    private final int bit;
    MobBehaviorFlag(int bit) { this.bit = bit; }
    public int getBit() { return bit; }
}
