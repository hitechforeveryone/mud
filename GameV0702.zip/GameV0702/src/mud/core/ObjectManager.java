package mud.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ObjectManager {
    private static final Map<Integer, ObjectItem> objectsById = new ConcurrentHashMap<>();

    public static void addObject(ObjectItem obj) {
        objectsById.put(obj.getObjID(), obj);
    }

    public static ObjectItem getObjectById(int id) {
        return objectsById.get(id);
    }

    public static void removeObject(int id) {
        objectsById.remove(id);
    }

    // Additional helper methods as needed...
}
