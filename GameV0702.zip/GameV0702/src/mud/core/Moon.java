package mud.core;

public class Moon {
	

	
    private String name;
    private int orbitDays;
    private int currentDay = 0;

    public Moon() {
    	
    }
    public Moon(String name) {
    	this.name = name;
    }
    
    public Moon(String name, int orbitDays) {
        this.name = name;
        this.orbitDays = orbitDays;
    }

    public void advance() {
        previousPhase = getPhase();
        currentDay = (currentDay + 1) % orbitDays;
    }

    public int getCurrentDay() {
        return currentDay;
    }

    public String getName() {
        return name;
    }

    public int getOrbitDays() {
        return orbitDays;
    }

    public boolean isFullMoon() {
        return getPhase() == MoonPhase.FULL_MOON;
    }

    public MoonPhase getPhase() {
        double fraction = (double) currentDay / orbitDays;

        if (fraction < 0.0625) return MoonPhase.NEW_MOON;
        else if (fraction < 0.1875) return MoonPhase.WAXING_CRESCENT;
        else if (fraction < 0.3125) return MoonPhase.FIRST_QUARTER;
        else if (fraction < 0.4375) return MoonPhase.WAXING_GIBBOUS;
        else if (fraction < 0.5625) return MoonPhase.FULL_MOON;
        else if (fraction < 0.6875) return MoonPhase.WANING_GIBBOUS;
        else if (fraction < 0.8125) return MoonPhase.LAST_QUARTER;
        else return MoonPhase.WANING_CRESCENT;
    }

    public String getPhaseName() {
        return getPhase().name().replace("_", " ").toLowerCase();
    }

	public void setName(String name) {
		this.name = name;
	}

	public void setOrbitDays(int orbitDays) {
		this.orbitDays = orbitDays;
	}

	public void setCurrentDay(int currentDay) {
		this.currentDay = currentDay;
	}
	
	private MoonPhase previousPhase = null;

	public MoonPhase getPreviousPhase() {
	    return previousPhase;
	}

	public void setPreviousPhase(MoonPhase phase) {
	    this.previousPhase = phase;
	}

	
	
}
