package mud.core;

import java.util.concurrent.ConcurrentHashMap;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import mud.config.Config;
import mud.scripting.BasicZoneScript;
import mud.scripting.ZoneScript;
import mud.scripting.ZoneScriptRegistry;
import mud.scripting.ZoneScriptTextParser;
import mud.system.GameClock;
import mud.system.CalendarSystem;

public class WorldManager {

	// --- Global Game Clock (shared across all worlds) ---
	public static final CalendarSystem GLOBAL_CALENDAR = new CalendarSystem();
	public static final GameClock GLOBAL_CLOCK = new GameClock(GLOBAL_CALENDAR);



	public static GameClock getGlobalClock() {
		return GLOBAL_CLOCK;
	}

	// --- World / Zone / Player maps ---
	private static final Map<String, World> worlds = new ConcurrentHashMap<>();
	private static final Map<Integer, Zone> zones = new HashMap<>();
	private static final Map<String, Player> activePlayers = new ConcurrentHashMap<>();
	private static final List<Player> onlinePlayers = new ArrayList<>();
	private static final Map<Integer, ObjectItem> objects = new HashMap<>();
	private static List<Mob> globalMobList = new ArrayList<>();
	private static World currentWorld;

	List<Room> parsedRooms = new ArrayList<>();
	List<PendingExit> pendingExits = new ArrayList<>();
	List<PendingZoneExit> pendingZoneExits = new ArrayList<>();

	// --- Initialization ---
	static {
		// Start the global clock once on server load
		GLOBAL_CLOCK.start();

		// Attach moons to the global clock (shared across all worlds)
		GLOBAL_CLOCK.addMoon(new Moon("Selene", 7));
		GLOBAL_CLOCK.addMoon(new Moon("Vareth", 13));

		// Configure global calendar (all worlds share)
		CalendarSystem calendar = GLOBAL_CLOCK.getCalendar();
		calendar.setDaysPerWeek(6);
		calendar.setWeeksPerMonth(5);
		calendar.setMonthsPerYear(12);
		calendar.setDayNames(List.of("Primeday", "Twosday", "Threesday", "Foursday", "Fiveday", "Sixthday"));
		calendar.setMonthNames(List.of(
				"Frostmere", "Snowwane", "Thawmarch", "Rainfell", "Bloomreach", "Sungold",
				"Emberbright", "Dustcall", "Harvestwane", "Coldfall", "Starwatch", "Yearsend"
				));
	}

	// --- World Management ---

	public static void addWorld(World world) {
		worlds.put(world.getName().toLowerCase(), world);
	}

	public static World getWorld(String id) {
		return worlds.get(id);
	}

	public static World getWorld(int id) {
		return getWorld(String.valueOf(id));
	}


	public static List<String> getWorldNames() {
		List<String> names = new ArrayList<>(worlds.keySet());
		Collections.sort(names);
		return names;
	}

	public static Map<String, World> getWorlds() {
		return worlds;
	}

	public static World createWorld(String worldId) {
		worldId = worldId.toLowerCase();
		World world = new World(worldId, Config.DEFAULT_WORLD_ID, GLOBAL_CLOCK);
		addWorld(world);

		int zoneId = Config.DEFAULT_LOGIN_ZONE;

		Zone newZone = new Zone();
		newZone.setZoneId(zoneId);
		newZone.setWorld(world); // must be set before constructing script
		newZone.setParentWorld(world);

		// Dynamically attach script from registry or fallback
		// TODO THIS DOESNT SEEM TO LOAD OUR SCRIPTS 0_0.Script.txt or it cant find it
		ZoneScript script = ZoneScriptRegistry.createForZone(world, zoneId);
		if (script == null) {
			System.out.println("⚠️ No ZoneScript registered for " + worldId + "_" + zoneId + ", using BasicZoneScript.");
			script = new BasicZoneScript(newZone); // ✅ FIXED
		}

		newZone.setScript(script);
		newZone.initialize();

		world.addZone(zoneId, newZone);
		newZone.setParentWorld(world);
		return world;
	}






	public static Room getStartingRoom(String worldId) {
		World world = worlds.get(worldId);
		if (world == null) {
			world = createWorld(worldId);
		}

		Zone zone = world.getZone(3);
		if (zone == null) throw new IllegalStateException("Missing zone 'forest' in world: " + worldId);

		Room room = zone.getRoom(0);
		if (room == null) throw new IllegalStateException("Missing room 0 in zone: forest");

		return room;
	}

	// --- Player Management ---

	public static void addPlayer(Player player) {
		if (player == null || player.getName() == null) return;
		activePlayers.put(player.getName().toLowerCase(), player);
		if (!onlinePlayers.contains(player)) {
			onlinePlayers.add(player);
		}
	}

	public static void removePlayer(Player player) {
		if (player == null) return;
		activePlayers.remove(player.getName().toLowerCase());
		onlinePlayers.remove(player);
	}

	public static List<Player> getAllPlayers() {
		return new ArrayList<>(onlinePlayers); // return copy to prevent external modification
	}
	public static Player getPlayer(String name) {
		return activePlayers.get(name.toLowerCase());
	}

	public static Player getPlayerByName(String name) {
		if (name == null) return null;
		for (Player p : getAllPlayers()) {
			if (p.getName().equalsIgnoreCase(name)) {
				return p;
			}
		}
		return null;
	}

	public static List<String> getActivePlayerNames() {
		List<String> names = new ArrayList<>();
		for (Player player : activePlayers.values()) {
			names.add(player.getName());
		}
		return names;
	}

	public static List<Player> getActivePlayers() {
		return new ArrayList<>(activePlayers.values()); // defensive copy
	}

	// --- Zone / Room Management ---

	public static void addZone(Zone zone) {
		zones.put(zone.getZoneId(), zone);
	}

	public static Zone getZone(int i) {
		return zones.get(i);
	}

	public static Zone getZoneOfRoom(Room room) {
		for (Zone zone : zones.values()) {
			if (zone.getRooms().containsValue(room)) return zone;
		}
		return null;
	}

	public static Room getRoomById(int roomId) {
		for (World world : worlds.values()) {
			Collection<Zone> zones = world.getZones();
			for (Zone zone : zones) {
				Room room = zone.getRoomById(roomId);
				if (room != null) return room;
			}
		}
		return null;
	}

	public static Room getRoom(String worldId, int zoneId, int roomId) {
		World world = getWorldByName(worldId);
		if (world == null) return null;
		Zone zone = world.getZone(zoneId);
		if (zone == null) return null;
		return zone.getRoom(roomId);
	}

	public static World createTithriusWorld() {
		String worldId = Config.DEFAULT_WORLD_ID;
		int zoneId = 0;

		System.out.println("Creating world...");

		String worldName = "tithrius";
		World world = new World(worldName, worldName, GLOBAL_CLOCK);
		world.setWorldId(worldId);
		world.setName(worldName);
		world.setOwner("Aetherion, the Shaper of the Veil");
		world.setStartingZoneId(zoneId);
		world.setStartingRoomNumber(0);

		// Create zone 0
		Zone zone = new Zone();
		zone.setZoneId(zoneId);
		zone.setName("The Void");
		zone.setWorld(world);
		zone.setParentWorld(world);
		zone.setClimate(Climate.VOID);
		zone.setResetType(ZoneResetType.WHEN_EMPTY);
		zone.setResetTimer(5);

		// Create default room 0 in zone 0
		Room room = new Room();
		room.setId(0);
		room.setName("Starting Room");
		room.setDescription("An empty, dull room.");
		room.setZone(zone);
		zone.addRoom(room.getId(), room);

		// Attach zone script
		ZoneScript script = ZoneScriptRegistry.createForZone(zone);
		if (script == null) {
			System.out.println("⚠️ No ZoneScript registered for zone " + zoneId + ", using fallback BasicZoneScript.");
			script = new BasicZoneScript(zone); // ✅ Fixed
		}
		zone.setScript(script);

		// Add zone to world
		world.addZone(zoneId, zone);

		// Save
		WorldManager.saveZone(zone);
		WorldManager.saveWorld(world);

		System.out.println("Zone " + zoneId + " initialized correctly with room 0.");
		return world;
	} // end createTithriusWorld








	public static Room getDefaultLoginRoom() {
		World defaultWorld = getWorld(Config.DEFAULT_WORLD_ID);
		if (defaultWorld == null) {
			throw new IllegalStateException("Default world not found.");
		}

		Zone defaultZone = defaultWorld.getZone(Config.DEFAULT_LOGIN_ZONE);
		if (defaultZone == null) {
			throw new IllegalStateException("Default login zone " + Config.DEFAULT_LOGIN_ZONE + " not found.");
		}

		Room defaultRoom = defaultZone.getRoom(Config.DEFAULT_LOGIN_ROOM);
		if (defaultRoom == null) {
			throw new IllegalStateException("Default login room " + Config.DEFAULT_LOGIN_ROOM
					+ " not found in zone '" + defaultZone.getName() + "'.");
		}

		return defaultRoom;
	}


	public static Room getRoomFromIds(String worldId, int zoneId, int roomId) {
		if (worldId == null) return null;

		World world = getWorld(worldId.toLowerCase());
		if (world == null) return null;

		Zone zone = world.getZone(zoneId);
		if (zone == null) return null;

		return zone.getRoom(roomId);
	}

	public static boolean worldExists(String id) {
		if (id == null) return false;
		return worlds.containsKey(id.toLowerCase());
	}

	public static void reattachZoneScripts(World world) {
		for (Zone zone : world.getZones()) {
			int zoneId = zone.getZoneId();

			// Attempt to load from registry or fallback
			ZoneScript script = ZoneScriptRegistry.createForZone(zone);
			if (script != null) {
				zone.setScript(script);
				System.out.println("✅ Script reattached to Zone " + zoneId);
			} else {
				System.out.println("⚠️ No script found for Zone ID: " + zoneId + ", using fallback.");
				zone.setScript(new BasicZoneScript(zone)); // ✅ Use actual zone
			}

			zone.initialize(); // Re-run population logic via script
		}
	}



	public static World getOrCreateWorld(String worldId) {
		World world = getWorld(worldId);
		if (world != null) return world;

		System.out.println("World '" + worldId + "' not found. Creating...");

		// Create new world
		World newWorld = new World(worldId.toLowerCase(), "Generated World: " + worldId, GLOBAL_CLOCK);
		addWorld(newWorld);

		// Add at least 1 default zone
		int zoneId = Config.DEFAULT_LOGIN_ZONE;
		Zone defaultZone = createOrAttachZone(newWorld, zoneId);
		defaultZone.setName("Town of Nowhere");

		// Add fallback room if needed
		if (defaultZone.getRoom(Config.DEFAULT_LOGIN_ROOM) == null) {
			Room room = new Room(Config.DEFAULT_LOGIN_ROOM);
			room.setName("Default Room");
			room.setZone(defaultZone);
			defaultZone.addRoom(Config.DEFAULT_LOGIN_ROOM, room);
		}

		return newWorld;
	}

	public static Zone createOrAttachZone(World world, int zoneId) {
		Zone zone = world.getZone(zoneId);
		if (zone != null) return zone;

		zone = new Zone();
		zone.setZoneId(zoneId);
		zone.setWorld(world);
		zone.setParentWorld(world);

		// Use the ZoneScriptRegistry to assign a script
		ZoneScript script = ZoneScriptRegistry.createForZone(zone);
		zone.setScript(script);

		zone.initialize(); // Populate rooms/mobs if script supports it
		world.addZone(zoneId, zone);

		return zone;
	}

/*
	public static void loadZoneScripts(World world) {
		for (Zone zone : world.getZones()) {
			String baseName = world.getWorldId().toLowerCase() + "_" + zone.getZoneId();
			File scriptMetaFile = new File(Config.SCRIPT_DIR, baseName + "Script.meta"); // class metadata
			File scriptDataFile = new File(Config.SCRIPT_DIR, baseName + ".zs");         // binary data

			if (!scriptMetaFile.exists()) {
				System.err.println("⚠️ No ZoneScript registered for zone " + zone.getZoneId() + ", using fallback BasicZoneScript.");
				ZoneScript fallback = new BasicZoneScript(zone); // ✅ use correct constructor
				zone.setScript(fallback);
				attachZoneScriptIfPresent(zone);
				System.out.println("✅ Assigned BasicZoneScript to zone " + zone.getZoneId());
				continue;
			}

			try {
				// Read class name
				String className = Files.readString(scriptMetaFile.toPath()).trim();

				// Dynamically create script instance
				Class<?> clazz = Class.forName(className);
				ZoneScript script = (ZoneScript) clazz.getDeclaredConstructor().newInstance();

				// Restore state from .zs file (if available)
				if (scriptDataFile.exists()) {
					try (DataInputStream in = new DataInputStream(new FileInputStream(scriptDataFile))) {
						script = ZoneScript.readFrom(in, zone); // ✅ capture return value
					}
				}

				zone.setScript(script);
				attachZoneScriptIfPresent(zone);
				System.out.println("✅ Script " + className + " loaded for zone " + zone.getZoneId());

			} catch (Exception e) {
				System.err.println("❌ Failed to load ZoneScript for zone " + zone.getZoneId() + ": " + e.getMessage());
				e.printStackTrace();
				zone.setScript(new BasicZoneScript(zone)); // fallback
			}
		}
	}
*/






	public static boolean saveWorld(World world) {
		if (world == null) return false;

		File dir = new File(Config.WORLDS_DIR);
		dir.mkdirs();

		File file = new File(dir, world.getWorldId() + ".world.txt");

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
			writer.write("World Name: " + world.getName() + "\n");
			writer.write("World ID: " + world.getWorldId() + "\n");
			writer.write("Owner: " + world.getOwner() + "\n");
			writer.write("Starting Zone: " + world.getStartingZoneId() + "\n");
			writer.write("Starting Room: " + world.getStartingRoomNumber() + "\n");

			// 🎯 Moons section
			List<Moon> moons = world.getMoons();
			writer.write("Moons: " + moons.size() + "\n");
			for (Moon moon : moons) {
				writer.write("  Moon: " + moon.getName() + "\n");
				writer.write("    OrbitDays: " + moon.getOrbitDays() + "\n");
			}

			// 🗺️ Zones section
			writer.write("Zones: " + world.getZones().size() + "\n");
			for (Zone zone : world.getZones()) {
				writer.write("  Zone " + zone.getZoneId() + ": " + zone.getName() + "\n");
			}

			System.out.println("✅ Saved world to: " + file.getAbsolutePath());
			return true;
		} catch (IOException e) {
			System.err.println("❌ Failed to save world: " + e.getMessage());
			return false;
		}
	}



	public static void loadAll() {
		File dir = new File(Config.WORLDS_DIR);
		if (!dir.exists()) return;

		File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".world.txt"));
		if (files == null) return;

		for (File file : files) {
			World world = loadWorldFromFile(file);
			if (world != null) {
				registerWorld(world);
				System.out.println("✅ Loaded world: " + world.getWorldId() + " (" + world.getName() + ")");
			}
		}
	}
	private static World loadWorldFromFile(File file) {
		// Extract the world ID from the file name, assuming it ends in .world.txt
		String name = file.getName();
		if (!name.endsWith(".world.txt")) return null;

		String id = name.substring(0, name.indexOf(".world.txt")); // strip the extension
		return loadWorld(id);
	}



	public static Collection<World> getAllWorlds() {
		return worlds.values();
	}

	public static boolean saveZone(Zone zone) {
		if (zone == null || zone.getWorld() == null) {
			System.err.println("❌ Cannot save zone: missing world or zone.");
			return false;
		}

		String baseName = zone.getWorld().getWorldId() + "_" + zone.getZoneId();
		File zoneFile = new File(Config.ZONES_DIR, baseName + ".zone.txt");

		zone.setSaving(true);
		ZoneScript script = zone.getScript();
		zone.setScript(null); // avoid writing non-serializable object
		if (WorldManager.saveWorld(zone.getWorld())) {
			System.out.println("✅ World updated and saved with new zone " + zone.getZoneId());
		} else {
			System.out.println("⚠️ Failed to save world after adding zone " + zone.getZoneId());
		}

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(zoneFile))) {
			writer.write("Zone ID: " + zone.getZoneId() + "\n");
			writer.write("Zone Name: " + zone.getName() + "\n");
			writer.write("Zone Owner: " + zone.getOwner() + "\n");
			writer.write("World ID: " + zone.getWorld().getWorldId() + "\n");
			writer.write("Climate: " + zone.getClimate() + "\n");
			writer.write("Reset Type: " + zone.getResetType() + "\n");
			writer.write("Reset Timer: " + zone.getResetTimer() + "\n");
			writer.write("Rooms:\n");

			for (Room room : zone.getRooms().values()) {
				writer.write("  Room ID: " + room.getId() + "\n");
				writer.write("  Name: " + room.getName() + "\n");
				writer.write("  Short Description: " + room.getShortDescription() + "\n");
				writer.write("  Description: " + room.getDescription() + "\n");
				writer.write("  Tunnel Limit: " + room.getTunnelNum() + "\n");

				// Save flags as a comma-separated list
				StringBuilder flagStr = new StringBuilder();
				for (RoomFlag flag : RoomFlag.values()) {
					if (room.hasFlag(flag)) {
						if (flagStr.length() > 0) flagStr.append(",");
						flagStr.append(flag.name());
					}
				}
				writer.write("  Flags: " + flagStr.toString() + "\n");

				// Save standard exits (room-to-room)
				writer.write("  Exits:\n");
				for (Direction dir : room.getExits().keySet()) {
					Room target = room.getExit(dir);
					if (target != null) {
						writer.write("    Direction: " + dir.name() + "\n");
						writer.write("    Target Room ID: " + target.getId() + "\n");
					}
				}

				// Save zone exits (cross-zone/world)
				writer.write("  ZoneExits:\n");
				for (Direction dir : room.getZoneExits().keySet()) {
					ZoneExit zx = room.getZoneExits().get(dir);
					writer.write("    Direction: " + dir.name() + "\n");
					writer.write("    Target World ID: " + zx.getTargetWorldId() + "\n");
					writer.write("    Target Zone ID: " + zx.getTargetZoneId() + "\n");
					writer.write("    Target Room ID: " + zx.getTargetRoomId() + "\n");
				}

				// Save doors
				writer.write("  Doors:\n");
				for (Direction dir : room.getDoors().keySet()) {
					Door door = room.getDoor(dir);
					writer.write("    Direction: " + dir.name() + "\n");
					writer.write("    Name: " + door.getDoorName() + "\n");
					writer.write("    Short Description: " + door.getShortDescription() + "\n");
					writer.write("    Long Description: " + door.getLongDescription() + "\n");
					writer.write("    Keywords: " + String.join(",", door.getKeywords()) + "\n");
					writer.write("    Open: " + door.isOpen() + "\n");
					writer.write("    Locked: " + door.isLocked() + "\n");
					writer.write("    Lockable: " + door.isLockable() + "\n");
				}

				writer.write("\n");  // Blank line between rooms
			}
			System.out.println("✅ Zone saved: " + zoneFile.getAbsolutePath());
			return true;
		} catch (IOException e) {
			System.err.println("❌ Failed to save zone: " + zoneFile.getName());
			e.printStackTrace();
			return false;
		} finally {
			zone.setScript(script);
			zone.setSaving(false);
		}
	}




	public static void unloadZone(Zone zone) {
		if (zone == null) return;

		// Example: remove zone from the world it belongs to
		World world = zone.getWorld();
		if (world != null) {
			world.removeZone(zone.getZoneId()); // You should have this method
			System.out.println("Zone " + zone.getZoneId() + " unloaded from world " + world.getWorldId());
		} else {
			System.err.println("Cannot unload zone: zone has no associated world.");
		}

		// Additional cleanup if needed
	}


	/*
	public static Zone loadZone(String worldId, int zoneId) {
		String baseName = worldId.toLowerCase() + "_" + zoneId;
		File zoneFile = new File(Config.ZONES_DIR, baseName + ".json"); // ⬅️ Must match saveZone extension

		if (!zoneFile.exists()) {
			System.err.println("❌ Zone file not found: " + zoneFile.getAbsolutePath());
			return null;
		}

		try (FileReader reader = new FileReader(zoneFile)) {
			Gson gson = new GsonBuilder()
					.excludeFieldsWithoutExposeAnnotation() // if you're using @Expose
					.create();

			Zone zone = gson.fromJson(reader, Zone.class);

			// Link world
			World world = WorldManager.getWorld(worldId);
			if (world == null) {
				System.err.println("⚠️ World " + worldId + " not found while loading zone " + zoneId);
				return null;
			}

			zone.setWorld(world);
			world.addZone(zoneId, zone);

			// Reconnect zone to its script
			ZoneScript script = ZoneScriptRegistry.createForZone(world, zoneId);
			if (script == null) {
				System.out.println("⚠️ No ZoneScript found for zone " + zoneId + ", using fallback BasicZoneScript.");
				script = new BasicZoneScript(zone);
			}
			zone.setScript(script);

			// Fix zone reference in rooms
			for (Room room : zone.getRooms().values()) {
				room.setZone(zone);
			}

			System.out.println("✅ Loaded zone " + zoneId + " from JSON.");
			return zone;

		} catch (IOException e) {
			System.err.println("❌ Failed to load zone: " + zoneFile.getAbsolutePath());
			e.printStackTrace();
			return null;
		}
	}
	 */


	public static boolean saveMob(Mob mob) {
		File dir = new File(Config.MOBS_DIR);
		dir.mkdirs();
		File file = new File(dir, mob.getId() + ".mob.txt");

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
			writer.write("MobName: " + mob.getMobName() + "\n");
			writer.write("ShortDesc: " + mob.getShortDescription() + "\n");
			writer.write("LongDesc: " + mob.getLongDescription() + "\n");
			writer.write("ExtDesc: " + mob.getExtendedDescription() + "\n");
			writer.write("Keywords: " + String.join(" ", mob.getKeywords()) + "\n");
			writer.write("Level: " + mob.getLevel() + "\n");
			writer.write("Profession: " + mob.getProfession() + "\n");
			writer.write("Race: " + mob.getRace() + "\n");
			writer.write("Subrace: " + mob.getSubrace() + "\n");
			writer.write("Rank: " + mob.getRank() + "\n");

			writer.write("STR: " + mob.getStrength() + "\n");
			writer.write("STA: " + mob.getStamina() + "\n");
			writer.write("AGI: " + mob.getAgility() + "\n");
			writer.write("INT: " + mob.getIntellect() + "\n");

			writer.write("HP: " + mob.getMaxHP() + "\n");
			writer.write("MP: " + mob.getMaxMP() + "\n");

			writer.write("ReincarnateMax: " + mob.getReincarnateMax() + "\n");

			if (mob.getSentryDirection() != null)
				writer.write("SentryDir: " + mob.getSentryDirection() + "\n");
			if (mob.getSentryMessage() != null)
				writer.write("SentryMsg: " + mob.getSentryMessage() + "\n");

			writer.write("BehaviorFlags: " + String.join(",", mob.getBehaviorFlagsAsStrings()) + "\n");
			writer.write("AffectFlags: " + String.join(",", mob.getAffectFlagsAsStrings()) + "\n");

			if (!mob.getSpeeches().isEmpty()) {
				writer.write("Speeches: " + String.join(",", mob.getSpeeches()) + "\n");
			}
			MobManager.registerMobTemplate(mob); // ensures latest version is cached

			System.out.println("✅ Saved mob to: " + file.getAbsolutePath());

			return true;

		} catch (IOException e) {
			System.err.println("❌ Failed to save mob: " + e.getMessage());
			return false;
		}
	}


	public static Mob loadMob(String mobId) {
		File file = new File(Config.MOBS_DIR, mobId + ".mob.txt");
		if (!file.exists()) {
			System.err.println("❌ Mob file not found: " + file.getAbsolutePath());
			return null;
		}

		Mob mob = new Mob();
		mob.setId(Integer.parseInt(mobId)); // optional

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (!line.contains(":")) continue;
				String[] parts = line.split(":", 2);
				String key = parts[0].trim();
				String value = parts[1].trim();

				switch (key) {
				case "MobName" -> mob.setMobName(value);
				case "ShortDesc" -> mob.setShortDescription(value);
				case "LongDesc" -> mob.setLongDescription(value);
				case "ExtDesc" -> mob.setExtendedDescription(value);
				case "Keywords" -> mob.setKeywords(new HashSet<>(Arrays.asList(value.split(" "))));
				case "Level" -> mob.setLevel(Integer.parseInt(value));
				case "Profession" -> mob.setProfession(Profession.valueOf(value.toUpperCase()));
				case "Race" -> mob.setRace(value);
				case "Subrace" -> mob.setSubrace(value);
				case "Rank" -> mob.setRank(MobRank.valueOf(value.toUpperCase()));

				case "STR" -> mob.setStrength(Integer.parseInt(value));
				case "STA" -> mob.setStamina(Integer.parseInt(value));
				case "AGI" -> mob.setAgility(Integer.parseInt(value));
				case "INT" -> mob.setIntellect(Integer.parseInt(value));

				case "HP" -> {
					mob.setMaxHP(Integer.parseInt(value));
					mob.setCurrentHP(mob.getMaxHP());
				}
				case "MP" -> {
					mob.setMaxMP(Integer.parseInt(value));
					mob.setCurrentMP(mob.getMaxMP());
				}

				case "ReincarnateMax" -> {
					int count = Integer.parseInt(value);
					mob.setReincarnateMax(count);
					mob.setReincarnateRemaining(count);
				}

				case "SentryDir" -> mob.setSentryDirection(value);
				case "SentryMsg" -> mob.setSentryMessage(value);

				case "BehaviorFlags" -> {
					for (String flag : value.split(",")) {
						try {
							mob.addBehavior(MobBehaviorFlag.valueOf(flag.trim().toUpperCase()));
						} catch (IllegalArgumentException ignored) {}
					}
				}
				case "AffectFlags" -> {
					for (String flagName : value.split(",")) {
						try {
							MobAffectFlag flag = MobAffectFlag.valueOf(flagName.trim().toUpperCase());
							mob.addAffect(flag);
						} catch (IllegalArgumentException e) {
							System.err.println("⚠️ Unknown affect flag: " + flagName);
						}
					}

				}

				case "Speeches" -> {
					List<String> speeches = Arrays.stream(value.split(","))
							.map(String::trim).filter(s -> !s.isEmpty()).toList();
					mob.setSpeeches(speeches);
				}

				default -> System.out.println("⚠️ Unknown mob property: " + key);
				}
			}
			mob.initializeFromRaceAndRank();

			MobManager.registerMobTemplate(mob); // Add this after loading
			WorldManager.registerMob(mob);
			System.out.println("✅ Loaded mob: " + mob.getMobName());
			return mob;

		} catch (IOException e) {
			System.err.println("❌ Failed to load mob: " + e.getMessage());
			return null;
		}
	}



	public static World loadWorld(String worldId) {
		File file = new File(Config.WORLDS_DIR, worldId.toLowerCase() + ".world.txt");
		if (!file.exists()) {
			System.err.println("❌ World file not found: " + file.getAbsolutePath());
			return null;
		}

		World world = new World();  // Default constructor — you may need to adjust
		world.setClock(WorldManager.getGlobalClock());

		// Replace the clock's moons with the world's moons
		world.getClock().setMoons(world.getMoons());


		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			Moon currentMoon = null;

			while ((line = reader.readLine()) != null) {
				if (line.trim().isEmpty()) continue;


				if (line.startsWith("  Moon:")) {
					currentMoon = new Moon();
					currentMoon.setName(line.substring("  Moon:".length()).trim());
				}
				else if (line.startsWith("    OrbitDays:") && currentMoon != null) {
					try {
						int orbit = Integer.parseInt(line.substring("    OrbitDays:".length()).trim());
						currentMoon.setOrbitDays(orbit);
						world.addMoon(currentMoon);
						currentMoon = null;  // Reset for next moon
					} catch (NumberFormatException e) {
						System.err.println("⚠️ Invalid orbit days: " + line);
					}
				}
				else if (line.contains(":")) {
					String[] parts = line.split(":", 2);
					String key = parts[0].trim();
					String value = parts[1].trim();

					switch (key.toLowerCase()) {
					case "worldid", "world id" -> world.setWorldId(value);
					case "name", "world name" -> world.setName(value);
					case "owner" -> world.setOwner(value);
					case "startingzoneid", "starting zone" -> world.setStartingZoneId(Integer.parseInt(value));
					case "startingroomnumber", "starting room" -> world.setStartingRoomNumber(Integer.parseInt(value));
					case "moons" -> {
						// Do nothing here — just a header line
					}
					case "zones" -> {
						// Read zone lines until we hit a non-indented line or EOF
						while ((line = reader.readLine()) != null) {
							if (line.trim().isEmpty() || !line.startsWith("  ")) break; // not a zone line

							line = line.trim();
							if (line.toLowerCase().startsWith("zone")) {
								// Example format: Zone 0: Default Zone
								String[] zoneParts = line.split(":", 2);
								if (zoneParts.length < 2) continue;

								String idPart = zoneParts[0].trim(); // "Zone 0"
								String zoneName = zoneParts[1].trim(); // "Default Zone"

								int zoneId = Integer.parseInt(idPart.replaceAll("[^0-9]", ""));
								Zone zone = WorldManager.loadZone(world.getWorldId(), zoneId);

								if (zone != null) {
									zone.setParentWorld(world);     // 🔥 REQUIRED!
									// zone.setOwner();
									world.addZone(zoneId,zone);            // 🔥 REQUIRED!
								} else {
									System.err.println("⚠️ Could not load zone ID " + zoneId + " from world " + world.getWorldId());
								}
							}
						}
					}
					default -> System.out.println("⚠️ Unknown world property: " + key);
					}
				}
			}

			// Link calendar and clock
			world.setClock(WorldManager.getGlobalClock());

			// Add to memory map
			worlds.put(world.getWorldId().toLowerCase(), world);
			System.out.println("🌍 Loaded world: " + world.getName());

			// Load zones
			loadZonesForWorld(world);
			return world;

		} catch (IOException e) {
			System.err.println("❌ Failed to load world " + worldId + ": " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}



	static class PendingExit {
		Room fromRoom;
		Direction direction;
		int targetRoomId;

		PendingExit(Room fromRoom, Direction direction, int targetRoomId) {
			this.fromRoom = fromRoom;
			this.direction = direction;
			this.targetRoomId = targetRoomId;
		}
	}

	public static Zone loadZone(String worldId, int zoneId) {
	    File file = new File(Config.ZONES_DIR, worldId.toLowerCase() + "_" + zoneId + ".zone.txt");

	    if (!file.exists()) {
	        System.err.println("\u274c Zone file not found: " + file.getAbsolutePath());
	        return null;
	    }

	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        Zone zone = new Zone();
	        zone.setZoneId(zoneId);
	        attachZoneScriptIfPresent(zone);

	        Room currentRoom = null;
	        Direction currentDirection = null;
	        Door currentDoor = null;

	        List<PendingExit> pendingExits = new ArrayList<>();
	        List<PendingZoneExit> pendingZoneExits = new ArrayList<>();
	        List<Room> parsedRooms = new ArrayList<>();

	        String line;
	        while ((line = reader.readLine()) != null) {
	            line = line.trim();
	            if (line.isEmpty()) continue;

	            // Zone metadata
	            if (line.startsWith("Zone ID:")) {
	                zone.setZoneId(Integer.parseInt(line.substring("Zone ID:".length()).trim()));
	            } else if (line.startsWith("Zone Name:")) {
	                zone.setName(line.substring("Zone Name:".length()).trim());
	            } else if (line.startsWith("Zone Owner:")) {
	                zone.setOwner(line.substring("Zone Owner:".length()).trim());
	            } else if (line.startsWith("Climate:")) {
	                zone.setClimate(Climate.valueOf(line.substring("Climate:".length()).trim().toUpperCase()));
	            } else if (line.startsWith("Reset Type:")) {
	                zone.setResetType(ZoneResetType.valueOf(line.substring("Reset Type:".length()).trim().toUpperCase()));
	            } else if (line.startsWith("Reset Timer:")) {
	                zone.setResetTimer(Integer.parseInt(line.substring("Reset Timer:".length()).trim()));
	            }

	            // Room start - save previous room first
	            else if (line.startsWith("Room ID:")) {
	                if (currentRoom != null) {
	                    zone.addRoom(currentRoom.getId(), currentRoom);
	                    parsedRooms.add(currentRoom);
	                }
	                int roomId = Integer.parseInt(line.substring("Room ID:".length()).trim());
	                currentRoom = new Room(roomId);
	                currentRoom.setZone(zone);
	                currentDirection = null;
	                currentDoor = null;
	            }

	            // Room fields
	            else if (currentRoom != null) {
	                if (line.startsWith("Name:")) {
	                    currentRoom.setName(line.substring("Name:".length()).trim());
	                } else if (line.startsWith("Short Description:")) {
	                    currentRoom.setShortDescription(line.substring("Short Description:".length()).trim());
	                } else if (line.startsWith("Description:")) {
	                    currentRoom.setDescription(line.substring("Description:".length()).trim());
	                } else if (line.startsWith("Tunnel Limit:")) {
	                    currentRoom.setTunnelNum(Integer.parseInt(line.substring("Tunnel Limit:".length()).trim()));
	                } else if (line.startsWith("Flags:")) {
	                    currentRoom.clearFlags();
	                    String flagsLine = line.substring("Flags:".length()).trim();
	                    if (!flagsLine.isEmpty()) {
	                        for (String flagStr : flagsLine.split(",")) {
	                            try {
	                                RoomFlag flag = RoomFlag.valueOf(flagStr.trim());
	                                currentRoom.setFlag(flag);
	                            } catch (IllegalArgumentException e) {
	                                System.err.println("\u26a0\ufe0f Unknown room flag: " + flagStr.trim());
	                            }
	                        }
	                    }
	                }

	                // Parse Exits section
	                else if (line.equals("Exits:")) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;

	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                        }
	                        else if (line.startsWith("Target Room ID:") && currentDirection != null) {
	                            int targetRoomId = Integer.parseInt(line.substring("Target Room ID:".length()).trim());
	                            pendingExits.add(new PendingExit(currentRoom, currentDirection, targetRoomId));
	                            currentDirection = null;
	                        } 
	                    }
	                }

	                else if (line.equals("ZoneExits:")) {
	                    Direction dir = null;
	                    String targetWorldId = null;
	                    int targetZoneId = -1;
	                    int targetRoomId = -1;

	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty() || line.startsWith("#")) continue;
	                        if (line.startsWith("Room ")) {
	                            if (currentRoom != null) {
	                                zone.addRoom(currentRoom.getId(), currentRoom);
	                                parsedRooms.add(currentRoom);
	                            }
	                            int roomId = Integer.parseInt(line.substring(5).trim());
	                            currentRoom = new Room(roomId);
	                            currentRoom.setZone(zone);
	                            break;
	                        }
	                        if (line.startsWith("Direction:")) {
	                            dir = Direction.valueOf(line.substring(10).trim());
	                        } else if (line.startsWith("Target World ID: ")) {
	                            targetWorldId = line.substring(16).trim();
	                        } else if (line.startsWith("Target Zone ID: ")) {
	                            targetZoneId = Integer.parseInt(line.substring(15).trim());
	                        } else if (line.startsWith("Target Room ID: ")) {
	                            targetRoomId = Integer.parseInt(line.substring(15).trim());
	                            if (dir != null && targetWorldId != null && targetZoneId >= 0 && targetRoomId >= 0) {
	                                pendingZoneExits.add(new PendingZoneExit(currentRoom, dir,
	                                    new ZoneExit(targetWorldId, targetZoneId, targetRoomId, dir)));
	                                System.out.println("loaded zexit for: " + dir + ":" + targetWorldId + ":" + targetZoneId + ":" + targetRoomId);
	                                dir = null; targetWorldId = null; targetZoneId = -1; targetRoomId = -1;
	                             
	                            }
	                        }
	                    }
	                }


	                // Parse Doors section
	                else if (line.equals("Doors:")) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;

	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.fromString(line.substring("Direction:".length()).trim());
	                            currentDoor = new Door();
	                            currentRoom.setDoor(currentDirection, currentDoor);
	                        } else if (currentDoor != null) {
	                            if (line.startsWith("Name:")) {
	                                currentDoor.setDoorName(line.substring("Name:".length()).trim());
	                            } else if (line.startsWith("Short Description:")) {
	                                currentDoor.setShortDescription(line.substring("Short Description:".length()).trim());
	                            } else if (line.startsWith("Long Description:")) {
	                                currentDoor.setLongDescription(line.substring("Long Description:".length()).trim());
	                            } else if (line.startsWith("Keywords:")) {
	                                String kwLine = line.substring("Keywords:".length()).trim();
	                                currentDoor.setKeywords(kwLine.isEmpty() ? List.of() : List.of(kwLine.split(",")));
	                            } else if (line.startsWith("Open:")) {
	                                currentDoor.setOpen(Boolean.parseBoolean(line.substring("Open:".length()).trim()));
	                            } else if (line.startsWith("Locked:")) {
	                                currentDoor.setLocked(Boolean.parseBoolean(line.substring("Locked:".length()).trim()));
	                            } else if (line.startsWith("Lockable:")) {
	                                currentDoor.setLockable(Boolean.parseBoolean(line.substring("Lockable:".length()).trim()));
	                            } else if (line.startsWith("Room ID:") || line.startsWith("ZoneExits:") || line.startsWith("Exits:")) {
	                                // End doors section on new section
	                                break;
	                            }
	                        }
	                    }
	                }
	            }
	        }

	        // Add last room if exists and not already added
	        if (currentRoom != null && !parsedRooms.contains(currentRoom)) {
	            zone.addRoom(currentRoom.getId(), currentRoom);
	            parsedRooms.add(currentRoom);
	        }

	        // Resolve normal exits
	        for (PendingExit pe : pendingExits) {
	            Room target = zone.getRoom(pe.targetRoomId);
	            if (target == null) {
	                System.err.println("\u26a0\ufe0f Zone " + zone.getName() + " Missing room " + pe.targetRoomId + " for exit from room " + pe.fromRoom.getId());
	                continue;
	            }
	            pe.fromRoom.setExit(pe.direction, target);
	        }

	        // Resolve zone exits
	        for (PendingZoneExit pze : pendingZoneExits) {
	            pze.sourceRoom.setZoneExit(pze.direction, pze.zoneExit);
	            System.out.print("Loaded zoneExit" + pze.toString());
	        }
	        

	        return zone;

	    } catch (IOException e) {
	        System.err.println("\u274c Failed to load zone: " + e.getMessage());
	        return null;
	    }
	} // end loadZone

/*
	public static void loadZonesForWorld(World world) {
	    File zoneDir = new File(Config.ZONES_DIR);
	    ZoneScriptRegistry.registerDefaults(world);
	    File[] files = zoneDir.listFiles((dir, name) ->
	        name.startsWith(world.getWorldId() + "_") && name.endsWith(".zone.txt")
	    );

	    if (files == null) return;

	    for (File file : files) {
	        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	            Zone zone = new Zone();
	            zone.setWorld(world);
	            zone.setParentWorld(world);

	            String line;
	            Room currentRoom = null;
	            Direction currentDirection = null;
	            Door currentDoor = null;
	            List<PendingExit> pendingExits = new ArrayList<>();

	            while ((line = reader.readLine()) != null) {
	                line = line.trim();
	                if (line.isEmpty()) continue;

	                if (line.startsWith("Zone ID:")) {
	                    zone.setZoneId(Integer.parseInt(line.substring("Zone ID:".length()).trim()));
	                } else if (line.startsWith("Zone Name:")) {
	                    zone.setName(line.substring("Zone Name:".length()).trim());
	                } else if (line.startsWith("Zone Owner:")) {
	                    zone.setOwner(line.substring("Zone Owner:".length()).trim());
	                } else if (line.startsWith("Climate:")) {
	                    zone.setClimate(Climate.valueOf(line.substring("Climate:".length()).trim().toUpperCase()));
	                } else if (line.startsWith("Reset Type:")) {
	                    zone.setResetType(ZoneResetType.valueOf(line.substring("Reset Type:".length()).trim().toUpperCase()));
	                } else if (line.startsWith("Reset Timer:")) {
	                    zone.setResetTimer(Integer.parseInt(line.substring("Reset Timer:".length()).trim()));

	                } else if (line.startsWith("Room ID:")) {
	                    if (currentRoom != null) {
	                        zone.addRoom(currentRoom.getId(), currentRoom);
	                    }
	                    int roomId = Integer.parseInt(line.substring("Room ID:".length()).trim());
	                    currentRoom = new Room(roomId);
	                    currentRoom.setZone(zone);
	                    currentDirection = null;
	                    currentDoor = null;

	                } else if (line.startsWith("Name:") && currentRoom != null) {
	                    currentRoom.setName(line.substring("Name:".length()).trim());
	                } else if (line.startsWith("Short Description:") && currentRoom != null) {
	                    currentRoom.setShortDescription(line.substring("Short Description:".length()).trim());
	                } else if (line.startsWith("Description:") && currentRoom != null) {
	                    currentRoom.setDescription(line.substring("Description:".length()).trim());
	                } else if (line.startsWith("Tunnel Limit:") && currentRoom != null) {
	                    currentRoom.setTunnelNum(Integer.parseInt(line.substring("Tunnel Limit:".length()).trim()));
	                } else if (line.startsWith("Flags:") && currentRoom != null) {
	                    String flagsLine = line.substring("Flags:".length()).trim();
	                    currentRoom.clearFlags();
	                    if (!flagsLine.isEmpty()) {
	                        String[] flags = flagsLine.split(",");
	                        for (String flagStr : flags) {
	                            try {
	                                RoomFlag flag = RoomFlag.valueOf(flagStr.trim());
	                                currentRoom.setFlag(flag);
	                            } catch (IllegalArgumentException e) {
	                                System.err.println("\u26A0\uFE0F Unknown room flag: " + flagStr.trim());
	                            }
	                        }
	                    }

	                } else if (line.equals("Exits:") && currentRoom != null) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;

	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                        } else if (line.startsWith("Target Room ID:") && currentDirection != null) {
	                            int targetRoomId = Integer.parseInt(line.substring("Target Room ID:".length()).trim());
	                            pendingExits.add(new PendingExit(currentRoom, currentDirection, targetRoomId));
	                            currentDirection = null;
	                        } else if (line.startsWith("ZoneExits:") || line.startsWith("Doors:") || line.startsWith("Room ID:")) {
	                            break;
	                        }
	                    }

	                } else if (line.equals("ZoneExits:") && currentRoom != null) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;
	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                        } else if (line.startsWith("Target World ID:") && currentDirection != null) {
	                            String targetWorldId = line.substring("Target World ID:".length()).trim();
	                            String zoneLine = reader.readLine().trim();
	                            String roomLine = reader.readLine().trim();

	                            int targetZoneId = Integer.parseInt(zoneLine.substring("Target Zone ID:".length()).trim());
	                            int targetRoomId = Integer.parseInt(roomLine.substring("Target Room ID:".length()).trim());

	                            ZoneExit zoneExit = new ZoneExit(targetWorldId, targetZoneId, targetRoomId, currentDirection);
	                            currentRoom.setZoneExit(currentDirection, zoneExit);
	                            System.out.println("[DEBUG] Loaded ZoneExit: " + currentDirection + " -> World:" + targetWorldId + " Zone:" + targetZoneId + " Room:" + targetRoomId);

	                            currentDirection = null;
	                        } else if (line.startsWith("Doors:") || line.startsWith("Room ID:") || line.startsWith("Exits:")) {
	                            break;
	                        }
	                    }

	                } else if (line.equals("Doors:") && currentRoom != null) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;
	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                            currentDoor = new Door();
	                            currentRoom.setDoor(currentDirection, currentDoor);
	                        } else if (currentDoor != null) {
	                            if (line.startsWith("Name:")) {
	                                currentDoor.setDoorName(line.substring("Name:".length()).trim());
	                            } else if (line.startsWith("Short Description:")) {
	                                currentDoor.setShortDescription(line.substring("Short Description:".length()).trim());
	                            } else if (line.startsWith("Long Description:")) {
	                                currentDoor.setLongDescription(line.substring("Long Description:".length()).trim());
	                            } else if (line.startsWith("Keywords:")) {
	                                String kwLine = line.substring("Keywords:".length()).trim();
	                                currentDoor.setKeywords(kwLine.isEmpty() ? List.of() : List.of(kwLine.split(",")));
	                            } else if (line.startsWith("Open:")) {
	                                currentDoor.setOpen(Boolean.parseBoolean(line.substring("Open:".length()).trim()));
	                            } else if (line.startsWith("Locked:")) {
	                                currentDoor.setLocked(Boolean.parseBoolean(line.substring("Locked:".length()).trim()));
	                            } else if (line.startsWith("Lockable:")) {
	                                currentDoor.setLockable(Boolean.parseBoolean(line.substring("Lockable:".length()).trim()));
	                            } else if (line.startsWith("Room ID:") || line.startsWith("ZoneExits:") || line.startsWith("Exits:")) {
	                                break;
	                            }
	                        }
	                    }
	                }
	            }

	            if (currentRoom != null) {
	                zone.addRoom(currentRoom.getId(), currentRoom);
	            }

	            for (PendingExit pe : pendingExits) {
	                Room target = zone.getRoom(pe.targetRoomId);
	                if (target != null) {
	                    pe.fromRoom.setExit(pe.direction, target);
	                } else {
	                    System.err.printf("\u26A0\uFE0F1 Missing room %d for exit from room %d%n", pe.targetRoomId, pe.fromRoom.getId());
	                }
	            }

	            world.addZone(zone.getZoneId(), zone);
	            zone.setParentWorld(world);

	            ZoneScript script = ZoneScriptRegistry.getScriptForZone(zone.getZoneId());
	            zone.setScript(script);

	            System.out.println("\u2705 Loaded zone " + zone.getZoneId() + " (" + zone.getName() + ")");
	        } catch (Exception e) {
	            System.err.println("\u274C Failed to load zone from file: " + file.getName());
	            e.printStackTrace();
	        }
	    }

	    loadAllMobsFromDisk();
	}
*/
	public static void loadZonesForWorld(World world) {
		World loadWorld=world;
	    File zoneDir = new File(Config.ZONES_DIR);
	    ZoneScriptRegistry.registerDefaults(world);
	    File[] files = zoneDir.listFiles((dir, name) ->
	        name.startsWith(world.getWorldId() + "_") && name.endsWith(".zone.txt")
	    );

	    if (files == null) return;

	    for (File file : files) {
	        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	            Zone zone = new Zone();
	            zone.setWorld(world);
	            zone.setParentWorld(world);

	            String line;
	            Room currentRoom = null;
	            Direction currentDirection = null;
	            Door currentDoor = null;
	            List<PendingExit> pendingExits = new ArrayList<>();

	            /*
	         // Temporary debugging to trace why ZoneExits parsing never runs
	            while ((line = reader.readLine()) != null) {
	                System.out.println("[DEBUG] Reading line: '" + line + "'");
	                line = line.trim();
	                if (line.isEmpty()) continue;

	                if (line.startsWith("Room ID:") && currentRoom == null) {
	                    int roomId = Integer.parseInt(line.substring("Room ID:".length()).trim());
	                    currentRoom = new Room(roomId);
	                    currentRoom.setZone(zone);
	                    System.out.println("[DEBUG] Created Room " + roomId);
	                    continue;
	                }

	                // Original ZoneExits block
	                if (line.startsWith("ZoneExits") && currentRoom != null) {
	                    System.out.println("[DEBUG] Entering ZoneExits parsing for room " + currentRoom.getId() + ", raw line: '" + line + "'");
	                    // parse ZoneExits normally here
	                }
	            }
*/
	            
	            while ((line = reader.readLine()) != null) {
	                line = line.trim();
	                if (line.isEmpty()) continue;

	                if (line.startsWith("Zone ID:")) {
	                    zone.setZoneId(Integer.parseInt(line.substring("Zone ID:".length()).trim()));
	                } else if (line.startsWith("Zone Name:")) {
	                    zone.setName(line.substring("Zone Name:".length()).trim());
	                } else if (line.startsWith("Zone Owner:")) {
	                    zone.setOwner(line.substring("Zone Owner:".length()).trim());
	                } else if (line.startsWith("World ID:")) {
	                	String worldId = line.substring("World ID:".length()).trim();
	                	loadWorld = getWorldByName(worldId);  // You need to have this method somewhere
	                	zone.setWorld(world);
	                   // zone.setWorld(line.substring("World ID:".length()).trim());
	                } else if (line.startsWith("Climate:")) {
	                    zone.setClimate(Climate.valueOf(line.substring("Climate:".length()).trim().toUpperCase()));
	                } else if (line.startsWith("Reset Type:")) {
	                    zone.setResetType(ZoneResetType.valueOf(line.substring("Reset Type:".length()).trim().toUpperCase()));
	                } else if (line.startsWith("Reset Timer:")) {
	                    zone.setResetTimer(Integer.parseInt(line.substring("Reset Timer:".length()).trim()));
	                } else if (line.startsWith("Rooms:")) {
	                    continue; // structural marker only
	                }
	                else if (line.trim().startsWith("Room ID:")) {
	                    // Save the previous room before starting a new one
	                    if (currentRoom != null) {
	                        zone.addRoom(currentRoom.getId(), currentRoom);
	                    }

	                    int roomId = Integer.parseInt(line.trim().substring("Room ID:".length()).trim());
	                    currentRoom = new Room(roomId);
	                    currentRoom.setZone(zone);
	                    currentDirection = null;
	                    currentDoor = null;
	                }
	                else if (line.startsWith("Name:") && currentRoom != null) {
	                    currentRoom.setName(line.substring("Name:".length()).trim());
	                } else if (line.startsWith("Short Description:") && currentRoom != null) {
	                    currentRoom.setShortDescription(line.substring("Short Description:".length()).trim());
	                } else if (line.startsWith("Description:") && currentRoom != null) {
	                    currentRoom.setDescription(line.substring("Description:".length()).trim());
	                } else if (line.startsWith("Tunnel Limit:") && currentRoom != null) {
	                    currentRoom.setTunnelNum(Integer.parseInt(line.substring("Tunnel Limit:".length()).trim()));
	                } else if (line.startsWith("Flags:") && currentRoom != null) {
	                    String flagsLine = line.substring("Flags:".length()).trim();
	                    currentRoom.clearFlags();
	                    if (!flagsLine.isEmpty()) {
	                        for (String flagStr : flagsLine.split(",")) {
	                            try {
	                                RoomFlag flag = RoomFlag.valueOf(flagStr.trim());
	                                currentRoom.setFlag(flag);
	                            } catch (IllegalArgumentException e) {
	                                System.err.println("⚠ Unknown room flag: " + flagStr.trim());
	                            }
	                        }
	                    }
	                }
	                else if (line.equals("Exits:") && currentRoom != null) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;
	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                        } else if (line.startsWith("Target Room ID:") && currentDirection != null) {
	                            int targetRoomId = Integer.parseInt(line.substring("Target Room ID:".length()).trim());
	                            pendingExits.add(new PendingExit(currentRoom, currentDirection, targetRoomId));
	                            currentDirection = null;
	                        } else if (line.startsWith("ZoneExits:") || line.startsWith("Doors:") || line.startsWith("Room ID:")) {
	                            break;
	                        }
	                    }
	                }
	                else if (line.equals("ZoneExits:") && currentRoom != null) {
	                    System.out.println("[DEBUG] Entering ZoneExits parsing for room " + currentRoom.getId());
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;
	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                        } else if (line.startsWith("Target World ID:") && currentDirection != null) {
	                            String targetWorldId = line.substring("Target World ID:".length()).trim();
	                            String zoneLine = reader.readLine().trim();
	                            String roomLine = reader.readLine().trim();
	                            int targetZoneId = Integer.parseInt(zoneLine.substring("Target Zone ID:".length()).trim());
	                            int targetRoomId = Integer.parseInt(roomLine.substring("Target Room ID:".length()).trim());

	                            ZoneExit zoneExit = new ZoneExit(targetWorldId, targetZoneId, targetRoomId, currentDirection);
	                            currentRoom.setZoneExit(currentDirection, zoneExit);
	                            System.out.printf("[DEBUG] Loaded ZoneExit: %s -> World:%s Zone:%d Room:%d%n", currentDirection, targetWorldId, targetZoneId, targetRoomId);
	                            currentDirection = null;
	                        } else if (line.startsWith("Doors:") || line.startsWith("Room ID:") || line.startsWith("Exits:")) {
	                            break;
	                        }
	                    }
	                }
	                else if (line.equals("Doors:") && currentRoom != null) {
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) break;
	                        if (line.startsWith("Direction:")) {
	                            currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
	                            currentDoor = new Door();
	                            currentRoom.setDoor(currentDirection, currentDoor);
	                        } else if (currentDoor != null) {
	                            if (line.startsWith("Name:")) {
	                                currentDoor.setDoorName(line.substring("Name:".length()).trim());
	                            } else if (line.startsWith("Short Description:")) {
	                                currentDoor.setShortDescription(line.substring("Short Description:".length()).trim());
	                            } else if (line.startsWith("Long Description:")) {
	                                currentDoor.setLongDescription(line.substring("Long Description:".length()).trim());
	                            } else if (line.startsWith("Keywords:")) {
	                                String kwLine = line.substring("Keywords:".length()).trim();
	                                currentDoor.setKeywords(kwLine.isEmpty() ? List.of() : List.of(kwLine.split(",")));
	                            } else if (line.startsWith("Open:")) {
	                                currentDoor.setOpen(Boolean.parseBoolean(line.substring("Open:".length()).trim()));
	                            } else if (line.startsWith("Locked:")) {
	                                currentDoor.setLocked(Boolean.parseBoolean(line.substring("Locked:".length()).trim()));
	                            } else if (line.startsWith("Lockable:")) {
	                                currentDoor.setLockable(Boolean.parseBoolean(line.substring("Lockable:".length()).trim()));
	                            } else if (line.startsWith("Room ID:") || line.startsWith("ZoneExits:") || line.startsWith("Exits:")) {
	                                break;
	                            }
	                        }
	                    }
	                }
	            }

	            if (currentRoom != null) {
	                zone.addRoom(currentRoom.getId(), currentRoom);
	            }

	            
	            
	            for (PendingExit pe : pendingExits) {
	                Room target = zone.getRoom(pe.targetRoomId);
	                if (target != null) {
	                    pe.fromRoom.setExit(pe.direction, target);
	                } else {
	                    System.err.printf("⚠ Missing room %d for exit from room %d%n", pe.targetRoomId, pe.fromRoom.getId());
	                }
	            }

	            world.addZone(zone.getZoneId(), zone);
	            zone.setParentWorld(world);

	            ZoneScript script = ZoneScriptRegistry.getScriptForZone(zone.getZoneId());
	            zone.setScript(script);

	            System.out.println("✅ Loaded zone " + zone.getZoneId() + " (" + zone.getName() + ")");
	        } catch (Exception e) {
	            System.err.println("❌ Failed to load zone from file: " + file.getName());
	            e.printStackTrace();
	        }
	    }
	    reattachZoneScripts(world);
	    loadAllMobsFromDisk();
	}




	public static void loadAllMobsFromDisk() {
		File dir = new File(Config.MOBS_DIR);
		File[] files = dir.listFiles((d, name) -> name.endsWith(".mob.txt"));
		if (files == null) return;

		for (File file : files) {
			String fileName = file.getName();
			String idStr = fileName.split("\\.")[0]; // "3" from "3.mob.txt"
			try {
				Mob mob = loadMob(idStr);
				if (mob != null) {
					MobManager.registerMobTemplate(mob);
					WorldManager.registerMob(mob);
				}
			} catch (Exception e) {
				System.err.println("⚠️ Failed to load mob: " + idStr);
			}
		}
	}

	public static Mob getMobById(int id, Room currentRoom) {
		// First check the current room
		for (Mob mob : currentRoom.getMobs()) {
			if (mob.getId() == id) return mob;
		}

		// Then check all zones
		for (Zone zone : getAllZones()) {
			for (Room room : zone.getRooms().values()) {
				for (Mob mob : room.getMobs()) {
					if (mob.getId() == id) return mob;
				}
			}
		}

		return null;
	}



	public static Collection<Zone> getAllZones() {
		return zones.values();
	}

	public static Mob findMobByName(String name) {
		if (name == null || name.isBlank()) return null;
		String lowerName = name.toLowerCase();

		for (Zone zone : WorldManager.getAllZones()) {
			for (Room room : zone.getRooms().values()) {
				for (Mob mob : room.getMobs()) {
					if (mob.getMobName() != null && mob.getMobName().equalsIgnoreCase(name)) {
						return mob;
					}

					if (mob.getKeywords() != null) {
						for (String keyword : mob.getKeywords()) {
							if (keyword.equalsIgnoreCase(lowerName)) {
								return mob;
							}
						}
					}
				}
			}
		}
		return null;
	}


	public static ObjectItem getObjectByIdOrName(String input) {
		try {
			int id = Integer.parseInt(input);
			return getObjectById(id);
		} catch (NumberFormatException e) {
			// Lookup by name if not numeric
			for (ObjectItem obj : objects.values()) {
				if (obj.getName().equalsIgnoreCase(input)) {
					return obj;
				}
			}
			return null;
		}
	}

	public static ObjectItem getObjectById(int id) {
		return objects.get(id);
	}


	public static void registerWorld(World world) {
		if (world != null) {
			worlds.put(world.getWorldId(), world);
		}
	}

	public static String getWorldStatBlock(World world) {
		StringBuilder sb = new StringBuilder();


		if (world == null) return "No world is currently loaded.\n";

		sb.append("World ID: ").append(world.getWorldId()).append("\n");
		sb.append("World Name: ").append(world.getName()).append("\n");
		sb.append("World Owner: ").append(world.getOwner()).append("\n");

		if (world.getClock() != null)
			sb.append("Time: ").append(world.getClock().getFormattedTime(world)).append("\n");

		if (world.getClock() != null)
			sb.append("Date: ").append(world.getClock().getFormattedDate()).append("\n");

		world.getZones();
		sb.append("Zones:\n");
		for (Zone zone : zones.values()) {
			sb.append(" - ").append(zone.getZoneId())
			.append(" : ").append(zone.getName())
			.append(" : ").append(zone.getOwner()).append("\n");
		}

		return sb.toString();
	}

	public static World getWorldByName(String name) {
		for (World world : worlds.values()) {
			if (world.getName().equalsIgnoreCase(name)) {
				return world;
			}
		}
		return null;
	}

	public static World getWorld() {
		return currentWorld;
	}

	public static void setWorld(World world) {
		currentWorld = world;
	}

	public static void registerMob(Mob mob) {
		if (mob != null && !globalMobList.contains(mob)) {
			globalMobList.add(mob);
		}
	}

	public static void unregisterMob(Mob mob) {
		globalMobList.remove(mob);
	}

	public static List<Mob> getAllMobs() {
		List<Mob> allMobs = new ArrayList<>();
		for (World world : getAllWorlds()) {
			for (Room room : world.getRooms()) {
				allMobs.addAll(room.getMobs()); // or getMobList(), depending on your API
			}
		}
		return allMobs;
	}

	// Optional for debugging
	public static void printAllWorlds() {
		for (World world : worlds.values()) {
			System.out.println("- " + world.getWorldId() + " (" + world.getName() + ")");
		}
	}

	private static void attachZoneScriptIfPresent(Zone zone) {
		try {
			BasicZoneScript script = ZoneScriptTextParser.read(zone);
			if (script != null) {
				// (A) If Zone has a setter
				zone.setZoneScript(script);

				// (B) Or a registry you use elsewhere:
				// ZoneScriptRegistry.register(script);

				// Optional: immediately apply to the zone
				script.apply(zone);

				// Optional: log
				System.out.println("[WorldManager] Loaded ZoneScript for zone " + zone.getZoneId());
			}
			else {
				// No script file? You can decide to create a default BasicZoneScript or do nothing.
				// zone.setZoneScript(new BasicZoneScript(zone));
			}
		}
		catch (IOException e) {
			System.err.println("[WorldManager] Failed to load ZoneScript for zone " + zone.getZoneId() + ": " + e.getMessage());
			e.printStackTrace();
		}
	}

} // end WorldManager
