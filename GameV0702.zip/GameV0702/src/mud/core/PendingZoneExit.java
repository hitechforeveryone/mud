package mud.core;

public class PendingZoneExit {
    final Room sourceRoom;
    final Direction direction;
    private final int targetWorldId;
    private final int targetZoneId;
    private final int targetRoomId;
    final ZoneExit zoneExit;

    public PendingZoneExit(Room sourceRoom, Direction direction, int targetWorldId, int targetZoneId, int targetRoomId) {
        this.sourceRoom = sourceRoom;
        this.direction = direction;
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
		this.zoneExit = null;
    }

    public PendingZoneExit(Room sourceRoom, Direction direction, ZoneExit zoneExit) {
        this.sourceRoom = sourceRoom;
        this.direction = direction;
		this.targetWorldId = 0;
		this.targetZoneId = 0;
		this.targetRoomId = 0;
        this.zoneExit = zoneExit;
    }
    
    public Room getSourceRoom() {
        return sourceRoom;
    }

    public Direction getDirection() {
        return direction;
    }

    public int getTargetWorldId() {
        return targetWorldId;
    }

    public int getTargetZoneId() {
        return targetZoneId;
    }

    public int getTargetRoomId() {
        return targetRoomId;
    }

    public ZoneExit getZoneExit() {
        return zoneExit;
    }
    
}
