package mud.core;

import java.util.ArrayList;
import java.util.List;

public class Party {
    private final List<Player> members = new ArrayList<>();
    private Player leader;

    public Party(Player leader) {
        this.leader = leader;
        addMember(leader);
    }

    public void addMember(Player player) {
        if (!members.contains(player)) {
            members.add(player);
            player.setParty(this);
        }
    }

    public void removeMember(Player player) {
        if (members.remove(player)) {
            player.setParty(null);
            // If leader left
            if (player.equals(leader)) {
                if (!members.isEmpty()) {
                    leader = members.get(0); // promote next member
                    leader.sendMessage("You are now the party leader.");
                } else {
                    disband(); // no one left
                }
            } else if (members.size() <= 1) {
                disband(); // too few members
            }
        }
    }

    public void disband() {
        for (Player p : new ArrayList<>(members)) {
            p.setParty(null);
            p.sendMessage("Your party has disbanded.");
        }
        members.clear();
    }

    public void broadcast(String message) {
        for (Player p : members) {
            p.sendMessage("%% " + message);
        }
    }

    public boolean isMember(Player p) {
        return members.contains(p);
    }

    public boolean isLeader(Player p) {
        return p != null && p.equals(leader);
    }

    public List<Player> getMembers() {
        return members;
    }

    public Player getLeader() {
        return leader;
    }

    public void setLeader(Player newLeader) {
        if (members.contains(newLeader)) {
            leader = newLeader;
        }
    }
}
