package mud.core;

public enum MobAffectFlag {
    NOKILL(1 << 0),
    REGENERATION(1 << 1),
    REINCARNATE(1 << 2),
	AGGRESSIVE(1 << 3),
	INVISIBIBLE(1 << 4);

    private final int bit;
    MobAffectFlag(int bit) { this.bit = bit; }
    public int getBit() { return bit; }
}