package mud.core;

public enum Climate {
    NONE,
    TEMPERATE,
    DESERT,
    ARCTIC,
    TROPICAL,
    SWAMP,
    MOUNTAIN,
    FOREST,
    BLIGHTED,
    HIGHLAND,
    COASTAL,
    PLAINS, VOID;

    public static Climate fromString(String input) {
        for (Climate c : values()) {
            if (c.name().equalsIgnoreCase(input.trim())) {
                return c;
            }
        }
        return null;
    }
}
