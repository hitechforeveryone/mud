package mud.core;

public enum ObjectType {
    NONE,
    WEAPON,
    ARMOR,
    LIGHTSOURCE,
    FOOD,
    DRINK,
    POTION,
    SCROLL,
    WAND,
    STAFF,
    TREASURE,
    COIN,
    TRASH,
    CONTAINER,
    SIGN,
    BOOK,
    PART,
    KEY,
    CONTROLLER;

    public static ObjectType fromString(String input) {
        if (input == null) return NONE;

        String normalized = input.trim().toLowerCase();

        switch (normalized) {
            case "none": return NONE;
            case "weapon": case "wep": case "mainhand": case "offhand": return WEAPON;
            case "armor": case "armour": return ARMOR;
            case "light": case "lightsource": case "lantern": case "torch": return LIGHTSOURCE;
            case "food": case "meal": return FOOD;
            case "drink": case "beverage": return DRINK;
            case "potion": case "elixir": case "pill": return POTION;
            case "scroll": return SCROLL;
            case "wand": return WAND;
            case "staff": case "stave": return STAFF;
            case "treasure": case "loot": return TREASURE;
            case "coin": case "money": case "currency": return COIN;
            case "trash": case "junk": return TRASH;
            case "container": case "bag": case "chest": return CONTAINER;
            case "sign": case "placard": return SIGN;
            case "book": return BOOK;
            case "part": case "component": return PART;
            case "key": case "lockpick": return KEY;
            case "controller": case "switch": case "lever": case"button": return CONTROLLER;
            default: return NONE;
        }
    }

    @Override
    public String toString() {
        // Capitalize only first letter
        return name().charAt(0) + name().substring(1).toLowerCase();
    }
}
