package mud.core;

import java.io.Serializable;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class Inventory implements Serializable {
    private List<ObjectItem> items = new ArrayList<>();

    
    public boolean hasItem(ObjectItem item) {
        return items.contains(item);
    }


    public String listItems() {
        if (items.isEmpty()) return "You are not carrying anything.";
        StringBuilder sb = new StringBuilder("You are carrying:\n");
        for (ObjectItem item : items) {
            sb.append(" - ").append(item.getName()).append("\n");
        }
        return sb.toString();
    }
    
    // Find first matching stackable item by name and type (case insensitive)
    public ObjectItem findStackableItem(ObjectItem item) {
        for (ObjectItem i : items) {
            if (i.isStackable() && i.getObjectType() == item.getObjectType()
                && i.getName().equalsIgnoreCase(item.getName())) {
                return i;
            }
        }
        return null;
    }


    // Remove item completely
    public boolean removeItem(ObjectItem item) {
        return items.remove(item);
    }

    // Use/consume stackable item from inventory
    // Returns true if item was fully consumed and removed
    public boolean consumeItem(ObjectItem item, int amount) {
        if (item == null || !item.isStackable()) return false;
        boolean fullyConsumed = item.consume(amount);
        if (fullyConsumed) {
            removeItem(item);
        }
        return fullyConsumed;
    }

    // Find item by exact name match (not necessarily stackable)
    public ObjectItem findItemByName(String name) {
        for (ObjectItem i : items) {
            if (i.getName().equalsIgnoreCase(name)) {
                return i;
            }
        }
        return null;
    }

    // Get all items for listing etc.
    public List<ObjectItem> getItems() {
        return items;
    }

    public void add(ObjectItem item) {
        items.add(item);
    }

    public void remove(ObjectItem item) {
        items.remove(item);
    }

    public boolean contains(ObjectItem item) {
        return items.contains(item);
    }


	public void setItems(List<ObjectItem> items) {
		this.items = items;
	}
	public void addItem(ObjectItem item) {
	    if (item == null) return;

	    // Try to find an existing stack to combine with
	    if (item.isStackable()) {
	        for (ObjectItem existing : items) {
	            if (existing.combineStack(item)) {
	                return; // Successfully stacked, don't add a new item
	            }
	        }
	    }

	    // Otherwise, add as a separate item
	    items.add(item);
	}

    
    
} // end Inventory
