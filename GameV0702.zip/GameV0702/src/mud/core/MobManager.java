package mud.core;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MobManager {
    private static final Map<Integer, Mob> mobsById = new ConcurrentHashMap<>();
    private static final Map<Integer, Mob> mobTemplates = new HashMap<>();

    // Add or update a mob in the manager
    public static void addMob(Mob mob) {
        mobsById.put(mob.getId(), mob);
    }

    // Retrieve mob by ID
    public static Mob getMobById(int id) {
        return mobsById.get(id);
    }

    // Remove a mob by ID
    public static void removeMob(int id) {
        mobsById.remove(id);
    }

 // In MobManager.java
    public static Mob createMobById(int id) {
        Mob prototype = mobTemplates.get(id);

        if (prototype == null) {
            // Try loading from file if not already registered
            Mob loaded = WorldManager.loadMob(String.valueOf(id));
            if (loaded != null) {
                registerMobTemplate(loaded); // Register it
                prototype = loaded;
            }
        }

        return prototype != null ? prototype.clone() : null;
    }

    
    public static void registerMobTemplate(int id, Mob mob) {
        mobTemplates.put(id, mob);
    }

    
    public static void loadMobTemplates() {
        // Example hardcoded:
        Mob blob = new Mob();
        blob.setMobName("a blob");
        blob.setLevel(1);
        // Set other properties...

        registerMobTemplate(0, blob);
    }

    public static void registerMobTemplate(Mob mob) {
        mobTemplates.put(mob.getId(), mob);
    }


    // Other helper methods as needed...
}
