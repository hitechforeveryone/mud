package mud.core;

public enum EffectType {
    POISON,
    BLEED,
    STUN,
    BURN,
    FROSTBITE,
    CURSE,
    BLESSING,
    REGENERATION,
    SHIELD,
    SILENCE,
    ROOT,
    CONFUSE,
    INVISIBILITY,
    SANCTUARY,
    DETECT_INVISIBLE,
    FEAR,
    CHARM,
    FIRE_SHIELD,
    TAME
}