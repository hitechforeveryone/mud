package mud.scripting;

public enum DoorState {
OPEN,
CLOSED,
LOCKED
}
