package mud.scripting;

import mud.core.Direction;
import mud.core.Door;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Room;
import mud.core.WorldManager;
import mud.core.Zone;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.*;

public class BasicZoneScript implements ZoneScript {

    private final Map<Integer, Double> mobSpawnChances = new HashMap<>();
    private final Map<Integer, Integer> mobSpawnCounts = new HashMap<>();

    private final Map<Integer, Double> objectSpawnChances = new HashMap<>();
    private final Map<Integer, Map<Integer, List<Integer>>> nestedObjects = new HashMap<>();
    private final Map<Integer, Map<String, DoorState>> doorStates = new HashMap<>();
    private final Set<Integer> recallNodes = new HashSet<>();
    
    private final Map<Integer, Map<Integer, Double>> mobSpawnsByRoom = new HashMap<>();
    private final Map<Integer, Map<Integer, Double>> objectSpawnsByRoom = new HashMap<>();

    private final int zoneId;

    public BasicZoneScript(Zone zone) {
        this.zoneId = zone.getZoneId();
    }

    @Override
    public int getZoneId() {
        return zoneId;
    }

    public void onLoad(Zone zone) {}

    public void onTick(Zone zone) {}

    public void onEnter(Player player) {}

    @Override
    public Map<Integer, Double> getMobSpawnChances() {
        return mobSpawnChances;
    }

    @Override
    public void addMobSpawnChance(int mobId, double chance) {
        addMobSpawnChance(mobId, chance, 1);
    }

    @Override
    public void addMobSpawnChance(int mobId, double chance, int count) {
        mobSpawnChances.put(mobId, chance);
        mobSpawnCounts.put(mobId, count);
    }

    @Override
    public int getMobSpawnCount(int mobId) {
        return mobSpawnCounts.getOrDefault(mobId, 1);
    }

    public Map<Integer, Double> getMobsForRoom(int roomId) {
        return Collections.emptyMap();
    }

    @Override
    public void addMobToRoom(int roomId, int mobId, double chance) {}

    @Override
    public Map<Integer, Double> getObjectSpawnChances() {
        return objectSpawnChances;
    }

    public Map<Integer, Double> getObjectsForRoom(int roomId) {
        return Collections.emptyMap();
    }

    @Override
    public void addObjectToRoom(int roomId, int objectId, double chance) {
        objectSpawnChances.put(objectId, chance);
    }

    @Override
    public void addObjectInsideObject(int roomId, int containerObjectId, int objectId) {
        nestedObjects.computeIfAbsent(roomId, k -> new HashMap<>())
            .computeIfAbsent(containerObjectId, k -> new ArrayList<>())
            .add(objectId);
    }

    public Map<Integer, Map<Integer, List<Integer>>> getNestedObjects() {
        return nestedObjects;
    }

    public Set<Integer> getRecallNodes() {
        return recallNodes;
    }

    public void addRecallNode(int roomId) {
        recallNodes.add(roomId);
    }

    public Map<String, Double> getEquipmentForMob(int mobId) {
        return Collections.emptyMap();
    }

    public void addEquipmentToMob(int mobId, int objectId, int slot, double chance) {}

    public Map<String, Double> getInventoryForMob(int mobId) {
        return Collections.emptyMap();
    }

    public void addInventoryToMob(int mobId, int objectId, int index, double chance) {}

    @Override
    public void setDoorState(int roomId, String direction, DoorState state) {
        doorStates.computeIfAbsent(roomId, k -> new HashMap<>()).put(direction, state);
    }

    public DoorState getDoorState(int roomId, String direction) {
        return doorStates.getOrDefault(roomId, Collections.emptyMap()).get(direction);
    }

    public Map<String, DoorState> getDoorStatesForRoom(int roomId) {
        return doorStates.getOrDefault(roomId, Collections.emptyMap());
    }

    public Map<Integer, Map<String, DoorState>> getDoorStates() {
        return doorStates;
    }

    public void writeTo(DataOutputStream out) throws IOException {}

    public String getSourceCode() {
        return serialize();
    }

    @Override
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("ZoneScript for Zone ID: ").append(zoneId).append("\n\n");

        if (!mobSpawnChances.isEmpty()) {
            sb.append("Mob Spawn Rules:\n");
            for (Map.Entry<Integer, Double> entry : mobSpawnChances.entrySet()) {
                int mobId = entry.getKey();
                double chance = entry.getValue();
                int count = mobSpawnCounts.getOrDefault(mobId, 1);
                sb.append("  MobID: ").append(mobId)
                  .append(", Count: ").append(count)
                  .append(", Chance: ").append((int)(chance * 100)).append("%\n");
            }
            sb.append("\n");
        }

        if (!objectSpawnChances.isEmpty()) {
            sb.append("Object Spawn Rules:\n");
            for (Map.Entry<Integer, Double> entry : objectSpawnChances.entrySet()) {
                sb.append("  ObjectID: ").append(entry.getKey())
                  .append(", Chance: ").append((int)(entry.getValue() * 100)).append("%\n");
            }
            sb.append("\n");
        }

        if (!doorStates.isEmpty()) {
            sb.append("Door States:\n");
            for (Map.Entry<Integer, Map<String, DoorState>> roomEntry : doorStates.entrySet()) {
                int roomId = roomEntry.getKey();
                for (Map.Entry<String, DoorState> entry : roomEntry.getValue().entrySet()) {
                    sb.append("  Room ").append(roomId)
                      .append(" - ").append(entry.getKey())
                      .append(": ").append(entry.getValue()).append("\n");
                }
            }
            sb.append("\n");
        }

        if (!recallNodes.isEmpty()) {
            sb.append("Recall Nodes:\n");
            for (int roomId : recallNodes) {
                sb.append("  RoomID: ").append(roomId).append("\n");
            }
            sb.append("\n");
        }

        if (!nestedObjects.isEmpty()) {
            sb.append("Nested Object Spawns:\n");
            for (Map.Entry<Integer, Map<Integer, List<Integer>>> roomEntry : nestedObjects.entrySet()) {
                int roomId = roomEntry.getKey();
                for (Map.Entry<Integer, List<Integer>> containerEntry : roomEntry.getValue().entrySet()) {
                    int containerId = containerEntry.getKey();
                    for (int innerId : containerEntry.getValue()) {
                        sb.append("  Room ").append(roomId)
                          .append(": ").append(innerId)
                          .append(" inside ").append(containerId).append("\n");
                    }
                }
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    public void readAdditionalData(DataOutputStream in) throws IOException {
        // Stub: future use
    }
    @Override
    public void apply(Zone zone) {
        // 1. Apply Door States
        if (doorStates != null) {
            for (Map.Entry<Integer, Map<String, DoorState>> roomEntry : doorStates.entrySet()) {
                int roomId = roomEntry.getKey();
                Room room = zone.getRoom(roomId);
                if (room == null) continue;

                for (Map.Entry<String, DoorState> entry : roomEntry.getValue().entrySet()) {
                    try {
                        Direction dir = Direction.valueOf(entry.getKey().toUpperCase());
                        Door door = room.getDoor(dir);
                        if (door != null) {
                            door.setState(entry.getValue());
                        }
                    } catch (IllegalArgumentException e) {
                        System.err.println("Invalid direction: " + entry.getKey());
                    }
                }
            }
        }

        // 2. Spawn Mobs
        for (Map.Entry<Integer, Map<Integer, Double>> entry : mobSpawnsByRoom.entrySet()) {
            int roomId = entry.getKey();
            Room room = zone.getRoom(roomId);
            if (room == null) continue;

            for (Map.Entry<Integer, Double> mobEntry : entry.getValue().entrySet()) {
                int mobId = mobEntry.getKey();
                double chance = mobEntry.getValue();
                if (Math.random() < chance) {
                    room.addMob(WorldManager.loadMob(String.valueOf(mobId)));
                }
            }
        }

        // 3. Spawn Objects
        for (Map.Entry<Integer, Map<Integer, Double>> entry : objectSpawnsByRoom.entrySet()) {
            int roomId = entry.getKey();
            Room room = zone.getRoom(roomId);
            if (room == null) continue;

            for (Map.Entry<Integer, Double> objEntry : entry.getValue().entrySet()) {
                int objectId = objEntry.getKey();
                double chance = objEntry.getValue();
               
                if (Math.random() < chance) {
                    room.addObject( WorldManager.getObjectById(objectId));
                }
            }
        }

        // 4. Nest Objects (i.e., place objects inside other objects)
        for (Map.Entry<Integer, Map<Integer, List<Integer>>> roomEntry : nestedObjects.entrySet()) {
            int roomId = roomEntry.getKey();
            Room room = zone.getRoom(roomId);
            if (room == null) continue;

            for (Map.Entry<Integer, List<Integer>> containerEntry : roomEntry.getValue().entrySet()) {
                int containerId = containerEntry.getKey();
                ObjectItem container = room.getObject(containerId);
                if (container == null || !container.isContainer()) continue;

                for (int innerId : containerEntry.getValue()) {
                    ObjectItem inner = WorldManager.getObjectById(innerId);
                    if (inner != null) {
                        container.setContents(Collections.singletonList(inner));
                    }
                }
            }
        }
    }



}
