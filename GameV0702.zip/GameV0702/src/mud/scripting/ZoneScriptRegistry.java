package mud.scripting;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

import mud.config.Config;
import mud.core.World;
import mud.core.Zone;

public class ZoneScriptRegistry {
    private static final Map<Integer, Supplier<ZoneScript>> scripts = new HashMap<>();
    

    public static void register(int zoneId, Supplier<ZoneScript> supplier) {
        scripts.put(zoneId, supplier);
    }

    public static ZoneScript getScriptForZone(int zoneId) {
        Supplier<ZoneScript> supplier = scripts.get(zoneId);
        return (supplier != null) ? supplier.get() : null;
    }
    private static final Map<Integer, ZoneScript> zoneScriptMap = new HashMap<>();

    public static void register(int zoneId, ZoneScript script) {
        zoneScriptMap.put(zoneId, script);
    }

    public static ZoneScript get(int zoneId) {
        return zoneScriptMap.get(zoneId);
    }

    public static void clear() {
        zoneScriptMap.clear();
    }

    public static boolean contains(int zoneId) {
        return zoneScriptMap.containsKey(zoneId);
    }
    
    private static final Map<Integer, Function<Zone, ZoneScript>> registry = new HashMap<>();

    public static void register(int zoneId, Function<Zone, ZoneScript> constructor) {
        registry.put(zoneId, constructor);
    }

    public static ZoneScript getScriptForZone(int zoneId, Zone zone) {
        Function<Zone, ZoneScript> constructor = registry.get(zone.getZoneId());
        if (constructor != null) {
            return constructor.apply(zone);
        }
        return null;
    }
    
    public static ZoneScript createForZone(Zone zone) {
        int zoneId = zone.getZoneId();

        ZoneScript script = null;

        // ✅ Load text-based ZoneScript if available
        try {
            script = ZoneScriptTextParser.read(zone);
            if (script != null) {
                System.out.println("✅ Loaded ZoneScript (.txt) for zone " + zone.getParentWorld().getWorldId() + ":" + zoneId);
            }
        } catch (IOException e) {
            System.err.println("❌ Failed to load ZoneScript (.txt) for zone " + zoneId + ": " + e.getMessage());
            e.printStackTrace();
        }

        // ⚠️ Fallback to empty BasicZoneScript
        if (script == null) {
            System.out.println("⚠️ No ZoneScript found. Using default BasicZoneScript for zone " + zoneId);
            script = new BasicZoneScript(zone);
        }

        // Optional: apply the script now
        script.apply(zone);

        // Optional: set on zone or register
        zone.setZoneScript(script);
        register(zoneId, script);

        return script;
    }


    


    // Optionally preload defaults
    public static void registerDefaults(World world) {
    	for (Zone zone : world.getZones()) {
    	    ZoneScriptRegistry.register(zone.getZoneId(), () -> new BasicZoneScript(zone));
    	    zone.setScript(ZoneScriptRegistry.getScriptForZone(zone.getZoneId()));
    	}

    }


    public static ZoneScript createForZone(World world, int zoneId) {
        Zone zone = world.getZone(zoneId);
        if (zone == null) {
            System.out.println("⚠️ World has no zone with ID: " + zoneId);
            return null;
        }

        // Try loading from .txt file first
        String baseName = world.getWorldId() + "_" + zoneId + ".Script.txt";
        File scriptFile = new File(Config.SCRIPT_DIR, baseName);
        ZoneScript script = null;

        if (scriptFile.exists()) {
            try {
                BasicZoneScript parsedScript = new BasicZoneScript(zone);
                ZoneScriptTextParser.parseFile(scriptFile, parsedScript);
                script = parsedScript;
                System.out.println("✅ Loaded ZoneScript from " + scriptFile.getName());
            } catch (IOException e) {
                System.err.println("❌ Failed to load script " + scriptFile.getName() + ": " + e.getMessage());
            }
        }

        // Try factory function if still null
        if (script == null) {
            Function<Zone, ZoneScript> factory = registry.get(zoneId);
            if (factory != null) {
                script = factory.apply(zone);
            }
        }

        // Fall back to blank BasicZoneScript
        if (script == null) {
            System.out.println("⚠️ No ZoneScript registered or loaded. Using default BasicZoneScript.");
            script = new BasicZoneScript(zone);
        }

        // Apply and register
        script.apply(zone);
        zone.setZoneScript(script);
        register(zoneId, script);

        return script;
    }


    private static String generateStubJava(Zone zone) {
        String worldId = zone.getWorld() != null ? zone.getWorld().getWorldId() : "unknown";
        int zoneId = zone.getZoneId();
        String className = capitalize(worldId) + "_" + zoneId + "Script";

        return """
            package mud.scripting;

            import mud.core.Zone;
            import mud.core.Player;
            import java.util.*;
            import java.io.*;

            public class %s implements ZoneScript {
                private final int zoneId;

                public %s() {
                    this.zoneId = %d;
                }

                @Override public int getZoneId() { return zoneId; }
                @Override public void onLoad(Zone zone) {}
                @Override public void onTick(Zone zone) {}
                @Override public void onEnter(Player player) {}
                @Override public void apply(Zone zone) {}

                @Override public Map<Integer, Double> getMobSpawnChances() { return Map.of(); }
                @Override public Map<Integer, Double> getMobsForRoom(int roomId) { return Map.of(); }
                @Override public void addMobToRoom(int roomId, int mobId, double chance) {}

                @Override public Map<Integer, Double> getObjectSpawnChances() { return Map.of(); }
                @Override public Map<Integer, Double> getObjectsForRoom(int roomId) { return Map.of(); }
                @Override public void addObjectToRoom(int roomId, int objectId, double chance) {}

                @Override public void setDoorState(int roomId, String direction, DoorState state) {}
                @Override public DoorState getDoorState(int roomId, String direction) { return DoorState.CLOSED; }
                @Override public Map<String, DoorState> getDoorStatesForRoom(int roomId) { return Map.of(); }

                @Override public void writeTo(DataOutputStream out) throws IOException {}
                @Override public String getSourceCode() {
                    return "TODO: Implement getSourceCode() for saving this script";
                }
            }
            """.formatted(className, className, zoneId);
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

	
    
    
    
}
