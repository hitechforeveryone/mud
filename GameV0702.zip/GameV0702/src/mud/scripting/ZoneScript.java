package mud.scripting;

import mud.core.Zone;

public interface ZoneScript {

    /**
     * Zone ID that this script applies to.
     */
    int getZoneId();

    /**
     * Add a global mob spawn chance (default count = 1).
     */
    default void addMobSpawnChance(int mobId, double chance) {}

    /**
     * Add a global mob spawn chance with count.
     */
    default void addMobSpawnChance(int mobId, double chance, int count) {
        addMobSpawnChance(mobId, chance);
    }

    /**
     * Returns the number of mobs to spawn for the given mob ID.
     */
    default int getMobSpawnCount(int mobId) {
        return 1;
    }

    /**
     * Add a global object spawn chance.
     */
    default void addObjectSpawnChance(int objectId, double chance) {}

    /**
     * Add a mob spawn in a specific room.
     */
    default void addMobToRoom(int roomId, int mobId, double chance) {}

    /**
     * Add an object spawn in a specific room.
     */
    default void addObjectToRoom(int roomId, int objectId, double chance) {}

    /**
     * Place an object inside another object in a given room.
     */
    default void addObjectInsideObject(int roomId, int containerObjectId, int innerObjectId) {}

    /**
     * Set a door state for a given room + direction.
     */
    default void setDoorState(int roomId, String direction, DoorState state) {}

    /**
     * Serialize this script to human-readable text.
     */
    String serialize();

    /**
     * Retrieve current mob spawn rules (global).
     */
    java.util.Map<Integer, Double> getMobSpawnChances();

    /**
     * Retrieve current object spawn rules (global).
     */
    java.util.Map<Integer, Double> getObjectSpawnChances();
    void apply(Zone zone);
} // end
