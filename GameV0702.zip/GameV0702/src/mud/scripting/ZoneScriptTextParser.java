package mud.scripting;

import mud.config.Config;
import mud.core.Zone;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Parses the human-readable ZoneScript *.txt file that ZoneScriptEditor writes via serialize().
 * Supported sections (all optional):
 *
 *   Mob Spawn Rules:
 *     MobID: <id>, Count: <n>, Chance: <n>%        // Count is optional (defaults to 1)
 *
 *   Object Spawn Rules:
 *     ObjectID: <id>, Chance: <n>%
 *
 *   Door States:
 *     Room <roomId> - <dir>: <state>
 *
 *   Recall Nodes:
 *     RoomID: <roomId>
 *
 *   Nested Object Spawns:
 *     Room <roomId>: <innerId> inside <containerId>
 */
public final class ZoneScriptTextParser {

    private enum Section {
        NONE,
        MOB_SPAWNS,
        OBJECT_SPAWNS,
        DOOR_STATES,
        RECALL_NODES,
        NESTED_OBJECT_SPAWNS
    }

    private ZoneScriptTextParser() {}

    /**
     * Attempt to read the zone's script txt file and return a populated BasicZoneScript.
     * Returns null if no file is found.
     */
    public static BasicZoneScript read(Zone zone) throws IOException {
        File file = resolveScriptFile(zone);
        if (file == null || !file.exists()) return null;

        BasicZoneScript script = new BasicZoneScript(zone);
        parseFile(file, script);
        return script;
    }

    private static File resolveScriptFile(Zone zone) {
    	// should read in <worldId>_<zoneId>.Script.txt
        String worldPrefix = zone.getWorld() != null ? zone.getWorld().getWorldId() + "_" : "";
        String baseA = worldPrefix + zone.getZoneId() + ".Script.txt";
        String baseB = zone.getZoneId() + ".txt";

        File dir = new File(Config.SCRIPT_DIR);
        File fA = new File(dir, baseA);
        File fB = new File(dir, baseB);

        if (fA.exists()) return fA;
        if (fB.exists()) return fB;
        return null;
    }

    static void parseFile(File file, BasicZoneScript script) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            Section section = Section.NONE;
            String line;
            while ((line = br.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) continue;

                // Detect sections
                if (trimmed.startsWith("Mob Spawn Rules:")) {
                    section = Section.MOB_SPAWNS;
                    continue;
                }
                else if (trimmed.startsWith("Object Spawn Rules:")) {
                    section = Section.OBJECT_SPAWNS;
                    continue;
                }
                else if (trimmed.startsWith("Door States:")) {
                    section = Section.DOOR_STATES;
                    continue;
                }
                else if (trimmed.startsWith("Recall Nodes:")) {
                    section = Section.RECALL_NODES;
                    continue;
                }
                else if (trimmed.startsWith("Nested Object Spawns:")) {
                    section = Section.NESTED_OBJECT_SPAWNS;
                    continue;
                }

                switch (section) {
                    case MOB_SPAWNS -> parseMobSpawn(trimmed, script);
                    case OBJECT_SPAWNS -> parseObjectSpawn(trimmed, script);
                    case DOOR_STATES -> parseDoorState(trimmed, script);
                    case RECALL_NODES -> parseRecallNode(trimmed, script);
                    case NESTED_OBJECT_SPAWNS -> parseNestedObject(trimmed, script);
                    default -> {
                        // ignore lines outside known sections
                    }
                }
            }
        }
    }

    private static void parseMobSpawn(String line, BasicZoneScript script) {
        // Accepts: "MobID: 123, Count: 5, Chance: 50%"  (Count optional)
        try {
            int mobId = -1;
            int count = 1;
            double chance = 1.0;

            String[] parts = line.split(",");
            for (String part : parts) {
                part = part.trim();
                if (part.startsWith("MobID:")) {
                    mobId = Integer.parseInt(part.substring("MobID:".length()).trim());
                } else if (part.startsWith("Count:")) {
                    count = Integer.parseInt(part.substring("Count:".length()).trim());
                } else if (part.startsWith("Chance:")) {
                    int pct = Integer.parseInt(part.substring("Chance:".length()).replace("%", "").trim());
                    chance = pct / 100.0;
                }
            }

            if (mobId != -1) {
                script.addMobSpawnChance(mobId, chance, count);
            }
        } catch (Exception ex) {
            // ignore bad line
        }
    }

    private static void parseObjectSpawn(String line, BasicZoneScript script) {
        // Expected: "ObjectID: 101, Chance: 75%"
        try {
            String[] parts = line.split(",");
            int objectId = Integer.parseInt(parts[0].replace("ObjectID:", "").trim());
            int chancePct = Integer.parseInt(parts[1].replace("Chance:", "").replace("%", "").trim());
            double chance = chancePct / 100.0;
            script.addObjectSpawnChance(objectId, chance);
        }
        catch (Exception ex) {
            // ignore bad line
        }
    }

    private static void parseDoorState(String line, BasicZoneScript script) {
        // Expected: "Room 42 - north: LOCKED"
        try {
            String rest = line.substring("Room ".length()).trim();
            int dashIdx = rest.indexOf(" - ");
            int colonIdx = rest.indexOf(":");

            int roomId = Integer.parseInt(rest.substring(0, dashIdx).trim());
            String dir = rest.substring(dashIdx + 3, colonIdx).trim();
            String stateName = rest.substring(colonIdx + 1).trim();

            DoorState state = DoorState.valueOf(stateName);
            script.setDoorState(roomId, dir, state);
        }
        catch (Exception ex) {
            // ignore bad line
        }
    }

    private static void parseRecallNode(String line, BasicZoneScript script) {
        // Expected: "RoomID: 3001"
        try {
            int roomId = Integer.parseInt(line.replace("RoomID:", "").trim());
            script.addRecallNode(roomId);
        }
        catch (Exception ex) {
            // ignore bad line
        }
    }

    private static void parseNestedObject(String line, BasicZoneScript script) {
        // Expected: "Room 42: 102 inside 201"
        try {
            int afterRoom = "Room ".length();
            int colon = line.indexOf(':');
            int roomId = Integer.parseInt(line.substring(afterRoom, colon).trim());

            String rest = line.substring(colon + 1).trim();
            String[] parts = rest.split("\\s+inside\\s+");
            int innerId = Integer.parseInt(parts[0].trim());
            int containerId = Integer.parseInt(parts[1].trim());

            script.addObjectInsideObject(roomId, containerId, innerId);
        }
        catch (Exception ex) {
            // ignore bad line
        }
    }
} // end