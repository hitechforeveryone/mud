// updated ClientHandler with rent-return message
package mud.server;

import mud.commands.CommandProcessor;
import mud.core.Player;
import mud.core.Room;
import mud.core.WorldManager;
import mud.editor.Editor;
import mud.system.PlayerLoader;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.function.Consumer;

public class ClientHandler implements Runnable {

	private final Socket socket;
	private BufferedReader in;
	private PrintWriter out;
	private Player player;
	@SuppressWarnings("unused")
	private Consumer<String> inputHandler;
	@SuppressWarnings("unused")
	private boolean awaitingInput = false;

	public ClientHandler(Socket socket) {
		this.socket = socket;
	}

	public void sendMessage(String msg) {
		if (out != null) {
			out.println(msg);
		}
	}

	private void closeSocket() {
		try {
			if (!socket.isClosed()) socket.close();
		} catch (IOException ignored) {}
	}

	// Inside ClientHandler.java

	@Override
	public void run() {
	    try {
	        socket.setSoTimeout(30 * 60 * 1000); // 10 minute timeout

	        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	        out = new PrintWriter(socket.getOutputStream(), true);

	        while (true) {
	            player = LoginManager.loginOrCreate(in, out);

	            if (player == null) {
	                out.println("Disconnected.");
	                break;
	            }

	            // Reconnect handling
	            ClientHandler existingHandler = player.getClientHandler();
	            if (existingHandler != null && existingHandler != this) {
	                existingHandler.sendMessage("\u26a0\ufe0f You have been disconnected due to login from another location.");
	                existingHandler.disconnect();
	            }

	            player.setClientHandler(this);
	            WorldManager.addPlayer(player);  // Add to active list

	            // Handle reconnect to previous room if valid
	            if (player.getCurrentRoom() != null && player.getCurrentZone() != null) {
	                Room room = player.getCurrentRoom();
	                room.addMob(player);
	                player.sendMessage("You awaken where you left off...");
	            } else {
	                // fallback to respawn or lobby, depending on system design
	                player.sendMessage("You awaken in the MUD...");
	            }

	            boolean sessionActive = handleGameSession();

	            if (!sessionActive) {
	                break; // user disconnected or connection closed
	            }
	        }

	    } catch (SocketTimeoutException e) {
	        sendMessage("You have been disconnected due to inactivity.");
	        System.out.println("Client timed out: " + (player != null ? player.getName() : "unknown"));

	    } catch (IOException e) {
	        System.err.println("IO error with client: " + e.getMessage());

	    } catch (Exception e) {
	        e.printStackTrace();

	    } finally {
	        if (player != null && player.getClientHandler() == this) {
	            cleanupPlayer();
	        }
	        closeSocket();
	    }
	}

	private boolean handleGameSession() throws Exception {
		String input;

		while ((input = in.readLine()) != null) {
			input = input.trim();
			if (input.isEmpty()) continue;

			Editor editor = player.getEditor();
			if (editor != null) {
				editor.handleInput(input);
				if (editor.isFinished()) {
					player.setEditor(null);
					player.sendMessage("Exited editor.");
				}
				continue;
			}

			String response = CommandProcessor.processCommand(input, player);

			if (player.isPendingLogout()) {
				player.sendMessage("Disconnecting and returning to login screen...");
				cleanupPlayer();
				return true;
			}

			if (response != null) {
				if (response.equalsIgnoreCase("quit")) {
					player.sendMessage("You have exited to the login screen.");
					cleanupPlayer();
					return true;
				}
				sendMessage(response);
			}
		}

		return false;
	}

	private void cleanupPlayer() {
		if (player != null) {
			Room room = player.getCurrentRoom();
			if (room != null) room.removeMob(player);
			player.updateRespawnLocationFromCurrentRoom();
			PlayerLoader.save(player);
			WorldManager.removePlayer(player);
			System.out.println("Player disconnected: " + player.getName());
		}
	}

	public void disconnect() {
		try {
			if (player != null) {
				cleanupPlayer();
				player.sendMessage("You have been disconnected. Progress saved.");
			}
			if (socket != null && !socket.isClosed()) socket.close();
			System.out.println("Client disconnected: " + (player != null ? player.getName() : "unknown"));
		} catch (IOException e) {
			System.err.println("Error during disconnect: " + e.getMessage());
		}
	}
} // end
