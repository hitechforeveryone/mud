package mud.system;

import mud.config.Config;
import mud.core.EquipSlot;
import mud.core.MobAffectFlag;
import mud.core.MobBehaviorFlag;
import mud.core.MobRank;
import mud.core.ObjectItem;
import mud.core.ObjectManager;
import mud.core.Player;
import mud.core.Profession;
import mud.core.World;
import mud.core.WorldManager;
import mud.core.Zone;
import mud.editor.Editor;
import mud.scripting.ZoneScript;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

public class PlayerLoader {
    private static final String PLAYER_FOLDER = Config.PLAYERS_DIR;
    private static final String BACKUP_FOLDER = PLAYER_FOLDER + "/backup";

    static {
        new File(PLAYER_FOLDER).mkdirs();
        new File(BACKUP_FOLDER).mkdirs();
    }

    private static File getPlayerFile(String playerName) {
        return new File(PLAYER_FOLDER, playerName.toLowerCase() + ".dat");
    }

    public static boolean save(Player player) {
        if (player == null || player.getName() == null) {
            System.err.println("❌ Cannot save player: null player or name.");
            return false;
        }

        String fileName = player.getName().toLowerCase() + ".player.txt";
        File file = new File(Config.PLAYERS_DIR, fileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("Name: " + player.getName() + "\n");
            writer.write("Password: " + player.getPassword() + "\n");
            writer.write("PrivilegeLevel: " + player.getPrivilegeLevel() + "\n");
	        writer.write("ShortDesc: " + player.getShortDescription() + "\n");
	        writer.write("LongDesc: " + player.getLongDescription() + "\n");
	        writer.write("ExtDesc: " + player.getExtendedDescription() + "\n");
	        writer.write("Keywords: " + String.join(" ", player.getKeywords()) + "\n");
            writer.write("Level: " + player.getLevel() + "\n");
            writer.write("Experience: " + player.getExp() + "\n");
            writer.write("Title: " + player.getPlayerTitle() + "\n");

            writer.write("STR: " + player.getStrength() + "\n");
            writer.write("STA: " + player.getStamina() + "\n");
            writer.write("AGI: " + player.getAgility() + "\n");
            writer.write("INT: " + player.getIntellect() + "\n");

            writer.write("HP: " + player.getCurrentHP() + "/" + player.getMaxHP() + "\n");
            writer.write("MP: " + player.getCurrentMP() + "/" + player.getMaxMP() + "\n");

            writer.write("Race: " + player.getRace() + "\n");
            writer.write("Subrace: " + player.getSubrace() + "\n");
            writer.write("Profession: " + player.getProfession() + "\n");
            writer.write("Rank: " + player.getRank() + "\n");

            if (player.getCurrentWorld() != null)
                writer.write("WorldID: " + player.getCurrentWorld().getWorldId() + "\n");

            if (player.getCurrentZone() != null)
                writer.write("ZoneID: " + player.getCurrentZone().getZoneId() + "\n");

            if (player.getCurrentRoom() != null)
                writer.write("RoomID: " + player.getCurrentRoom().getId() + "\n");

            writer.write("BehaviorFlags: " + String.join(",", player.getBehaviorFlagsAsStrings()) + "\n");
            writer.write("AffectFlags: " + String.join(",", player.getAffectFlagsAsStrings()) + "\n");

            if (!player.getSpeeches().isEmpty()) {
                writer.write("Speeches: " + String.join(",", player.getSpeeches()) + "\n");
            }

            // Save inventory
            writer.write("Inventory:");
            for (ObjectItem obj : player.getInventory()) {
                writer.write(" " + obj.getObjID());
            }
            writer.write("\n");

            // Save equipment
            writer.write("Equipment:\n");
            for (EquipSlot slot : EquipSlot.values()) {
                ObjectItem equipped = player.getEquipment().get(slot);
                if (equipped != null) {
                    writer.write(slot.name() + ": " + equipped.getObjID() + "\n");
                }
            }

            System.out.println("✅ Saved player to: " + file.getAbsolutePath());
            return true;
        } catch (IOException e) {
            System.err.println("❌ Failed to save player '" + player.getName() + "'");
            e.printStackTrace();
            return false;
        }
    }





    public static Player load(String name) {
        File file = new File(Config.PLAYERS_DIR, name.toLowerCase() + ".player.txt");
        if (!file.exists()) return null;

        Player player = new Player();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Name:")) {
                    player.setName(line.substring("Name:".length()).trim());
                } else if (line.startsWith("Password:")) {
                    player.setPassword(line.substring("Password:".length()).trim());
                } else if (line.startsWith("PrivilegeLevel:")) {
                    player.setPrivilegeLevel(Integer.parseInt(line.substring("PrivilegeLevel:".length()).trim()));
                }
                // add these in
                else if (line.startsWith("ShortDesc")) {
                	player.setShortDescription(line.substring("ShortDesc:".length()).trim());
                }
                else if (line.startsWith("LongDesc")) {
                	player.setLongDescription(line.substring("LongDesc:".length()).trim());
                }
                else if (line.startsWith("ExtDesc")) {
                	player.setExtendedDescription(line.substring("ExtDesc:".length()).trim());
                }
                else if (line.startsWith("Keywords:")) {
                    String keywordsLine = line.substring("Keywords:".length()).trim();
                    player.setKeywords(new HashSet<>(Arrays.asList(keywordsLine.split("\\s+"))));
                }
                else if (line.startsWith("Level:")) {
                    player.setLevel(Integer.parseInt(line.substring("Level:".length()).trim()));
                }
                else if (line.startsWith("Experience:")) {
                    player.setExp(Integer.parseInt(line.substring("Experience:".length()).trim()));
                }
                else if (line.startsWith("Title:")) {
                    player.setPlayerTitle(line.substring("Title:".length()).trim());
                }
             else if (line.startsWith("HP:")) {
                String[] parts = line.substring("HP:".length()).trim().split("/");
                if (parts.length == 2) {
                    player.setCurrentHP(Integer.parseInt(parts[0].trim()));
                    player.setMaxHP(Integer.parseInt(parts[1].trim()));
                }
            } else if (line.startsWith("MP:")) {
                String[] parts = line.substring("MP:".length()).trim().split("/");
                if (parts.length == 2) {
                    player.setCurrentMP(Integer.parseInt(parts[0].trim()));
                    player.setMaxMP(Integer.parseInt(parts[1].trim()));
                }
            }
                else if (line.startsWith("WorldID:")) {
                    String worldId = line.substring("WorldID:".length()).trim();

                    World world = WorldManager.getWorld(worldId);
                    player.setCurrentWorld(world);
                    if (world == null) {
                        // Fallback: try to find by world name
                        world = WorldManager.getAllWorlds().stream()
                            .filter(w -> w.getName().equalsIgnoreCase(worldId))
                            .findFirst()
                            .orElse(null);
                    }

                    System.out.println("DEBUG: Loading world '" + worldId + "' -> " + (world != null ? world.getName() : "NOT FOUND"));
                    player.setCurrentWorld(world);
         
                }


                else if (line.startsWith("ZoneID:")) {
                    int zoneId = Integer.parseInt(line.substring("ZoneID:".length()).trim());
                    if (player.getCurrentWorld() != null) {
                        player.setCurrentZone(player.getCurrentWorld().getZone(zoneId));
                    }
                }
                else if (line.startsWith("RoomID:")) {
                    int roomId = Integer.parseInt(line.substring("RoomID:".length()).trim());
                    if (player.getCurrentZone() != null) {
                        player.setCurrentRoom(player.getCurrentZone().getRoom(roomId));
                    }
                } 
                
                else if (line.startsWith("Inventory:")) {
                    String[] ids = line.substring("Inventory:".length()).trim().split(" ");
                    for (String idStr : ids) {
                        try {
                            int id = Integer.parseInt(idStr);
                            ObjectItem obj = ObjectManager.getObjectById(id);
                            if (obj != null) player.addItem(obj);
                        } catch (NumberFormatException ignored) {}
                    }
                } else if (line.equals("Equipment:")) {
                    while ((line = reader.readLine()) != null && line.contains(":")) {
                        String[] parts = line.split(":");
                        if (parts.length == 2) {
                            String slotName = parts[0].trim();
                            String objIdStr = parts[1].trim();
                            try {
                                int objId = Integer.parseInt(objIdStr);
                                ObjectItem obj = ObjectManager.getObjectById(objId);
                                EquipSlot slot = EquipSlot.valueOf(slotName);
                                if (obj != null) player.equip(slot, obj);
                            } catch (IllegalArgumentException ignored) {}
                        }
                    }
                }         
                
                else if (line.startsWith("Profession:")) {
                    try {
                        player.setProfession(Profession.valueOf(line.substring("Profession:".length()).trim()));
                    } catch (IllegalArgumentException ignored) {}
                } else if (line.startsWith("Race:")) {
                    player.setRace(line.substring("Race:".length()).trim());
                } else if (line.startsWith("Subrace:")) {
                    player.setSubrace(line.substring("Subrace:".length()).trim());
                } else if (line.startsWith("Rank:")) {
                    try {
                        player.setRank(MobRank.valueOf(line.substring("Rank:".length()).trim()));
                    } catch (IllegalArgumentException ignored) {}
                } else if (line.startsWith("STR:")) {
                    player.setStrength(Integer.parseInt(line.substring("STR:".length()).trim()));
                } else if (line.startsWith("STA:")) {
                    player.setStamina(Integer.parseInt(line.substring("STA:".length()).trim()));
                } else if (line.startsWith("AGI:")) {
                    player.setAgility(Integer.parseInt(line.substring("AGI:".length()).trim()));
                } else if (line.startsWith("INT:")) {
                    player.setIntellect(Integer.parseInt(line.substring("INT:".length()).trim()));
                } else if (line.startsWith("HP:")) {
                    player.setMaxHP(Integer.parseInt(line.substring("HP:".length()).trim()));
                    player.setCurrentHP(player.getMaxHP());
                } else if (line.startsWith("MP:")) {
                    player.setMaxMP(Integer.parseInt(line.substring("MP:".length()).trim()));
                    player.setCurrentMP(player.getMaxMP());
                } else if (line.startsWith("BehaviorFlags:")) {
                    String[] flags = line.substring("BehaviorFlags:".length()).trim().split(",");
                    for (String flag : flags) {
                        try {
                            player.addBehavior(MobBehaviorFlag.valueOf(flag.trim()));
                        } catch (IllegalArgumentException ignored) {}
                    }
                } else if (line.startsWith("AffectFlags:")) {
                    String[] flags = line.substring("AffectFlags:".length()).trim().split(",");
                    for (String flag : flags) {
                        try {
                            player.addAffect(MobAffectFlag.valueOf(flag.trim()));
                        } catch (IllegalArgumentException ignored) {}
                    }
                } else if (line.startsWith("Speeches:")) {
                    String[] speeches = line.substring("Speeches:".length()).trim().split(",");
                    List<String> speechList = new ArrayList<>();
                    for (String speech : speeches) {
                        if (!speech.trim().isEmpty()) speechList.add(speech.trim());
                    }
                    player.setSpeeches(speechList);
                }
                
            }
            return player;
        } catch (IOException e) {
            System.err.println("❌ Failed to load player: " + name);
            e.printStackTrace();
            return null;
        }
    }



    public static boolean exists(String playerName) {
        File file = getPlayerFile(playerName);
        return file.exists();
    }

    public static boolean delete(String playerName) {
        return getPlayerFile(playerName).delete();
    }

    public static boolean backupPlayer(String playerName) {
        File original = getPlayerFile(playerName);
        if (!original.exists()) return false;

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmm").format(new Date());
        File backup = new File(BACKUP_FOLDER, playerName.toLowerCase() + "_" + timestamp + ".dat");

        try (InputStream in = new FileInputStream(original);
             OutputStream out = new FileOutputStream(backup)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            return true;
        } catch (IOException e) {
            System.err.println("Error backing up player '" + playerName + "': " + e.getMessage());
            return false;
        }
    }
    
    public static List<File> listBackups(String playerName) {
        File backupDir = new File(BACKUP_FOLDER);
        if (!backupDir.exists() || !backupDir.isDirectory()) return Collections.emptyList();

        File[] files = backupDir.listFiles((dir, name) ->
            name.toLowerCase().startsWith(playerName.toLowerCase() + "_") && name.endsWith(".dat")
        );

        if (files == null) return Collections.emptyList();

        List<File> backups = new ArrayList<>(List.of(files));
        backups.sort((f1, f2) -> Long.compare(f2.lastModified(), f1.lastModified())); // newest first
        return backups;
    }
    public static boolean restoreBackup(String filename) {
        File backupFile = new File(BACKUP_FOLDER, filename);
        if (!backupFile.exists()) {
            System.err.println("Backup file not found: " + filename);
            return false;
        }

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(backupFile))) {
            Object obj = in.readObject();
            if (obj instanceof Player player) {
                save(player);  // Save over main copy
                System.out.println("Backup restored for player: " + player.getName());
                return true;
            } else {
                System.err.println("Invalid backup file format.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error restoring backup: " + e.getMessage());
        }

        return false;
    }

    public static boolean createNamedBackup(Player player, String label) {
        String sanitizedLabel = label.replaceAll("[^a-zA-Z0-9_-]", "_"); // make it safe for filenames
        String filename = player.getName().toLowerCase() + "_" + sanitizedLabel + ".dat";
        File backupFile = new File(BACKUP_FOLDER, filename);

        try {
            File dir = new File(BACKUP_FOLDER);
            if (!dir.exists()) dir.mkdirs();

            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(backupFile))) {
                out.writeObject(player);
            }

            return true;
        } catch (IOException e) {
            System.err.println("Error creating named backup: " + e.getMessage());
            return false;
        }
    }

} // end PlayerLoader
