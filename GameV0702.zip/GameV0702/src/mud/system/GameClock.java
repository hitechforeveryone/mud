package mud.system;

import mud.core.Direction;
import mud.core.Door;
import mud.core.Mob;
import mud.core.MobBehaviorFlag;
import mud.core.Moon;
import mud.core.MoonPhase;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.World;
import mud.core.WorldManager;
import mud.core.Zone;
import mud.core.ZoneResetType;
import mud.core.Player;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.WeatherType;
import mud.combat.CombatManager;
import mud.config.Config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class GameClock {


	private static int currentTick = 0;
	private final int ticksPerDay = Config.ticksPerDay; // 60 ticks = 1 game day
	private int ticksPerWeatherUpdate = ticksPerDay / 4;
	private final int sunriseTick = Config.sunriseTick; // example: tick 15
	private final int sunsetTick = Config.sunsetTick;  // example: tick 45
	private int lastTickOfDay = -1; //
	private int currentDay = 0;
	private int currentMonth = 0;
	private int currentWeek = 0;
	private int currentYear = 0;
	int currentHour;




	private final CalendarSystem calendar;
	private List<Moon> moons = new ArrayList<>();
	private int tickCounter = 0;

	private boolean previousDayState = true;


	public GameClock(CalendarSystem calendar) {
		this.calendar = calendar;
	}


	public void start() {
		tickMobMovement();
	    startMobMovementTicker();
		startCombatTicker();    // 
		startWorldTicker();     // 

	}

	private void startWorldTicker() {
		Thread clockThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(10 * 1000); // 10-second global ticks
					tick();
					tickAllMobs();
				} catch (InterruptedException e) {
					System.err.println("GameClock interrupted.");
					break;
				}
			}
		});

		clockThread.setDaemon(true);
		clockThread.setName("GameClock-Thread");
		clockThread.start();
	}

	public void startCombatTicker() {
		Thread combatThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(1000); // 1 second ticks for combat
					tickCombat();       // run only combat logic
				} catch (InterruptedException e) {
					System.err.println("Combat thread interrupted.");
					break;
				}
			}
		});

		combatThread.setDaemon(true);
		combatThread.setName("CombatTick-Thread");
		combatThread.start();
	}

	private void startMobMovementTicker() {
	    Thread mobMoveThread = new Thread(() -> {
	        while (true) {
	            try {
	                Thread.sleep(5000); // Every 5 seconds
	                tickMobMovement();
	                
	            } catch (InterruptedException e) {
	                System.err.println("Mob movement thread interrupted.");
	                break;
	            }
	        }
	    });
	    mobMoveThread.setDaemon(true);
	    mobMoveThread.setName("MobMovement-Thread");
	    mobMoveThread.start();
	}
	
	public void tick() {
		
		
		int currentGameHourTick = (int) Config.ticksPerDay / 8;
		
	    for (World world : WorldManager.getAllWorlds()) {
	        for (Zone zone : world.getZones()) {
	            for (Room room : zone.getRooms().values()) {
	                for (Mob mob : room.getMobs()) {
	                    ObjectItem.processSapientItemWhispers(mob, currentGameHourTick);
	                }
	            }
	        }
	        
	    }
	    
	    
	    
		tickCounter++;
		int tickOfDay = tickCounter % ticksPerDay;

		if (previousDayState != isDay()) {
			previousDayState = isDay();
			updateRoomLighting(previousDayState);
		}

		if (tickOfDay == sunriseTick) {
			System.out.println("Tick of Day: " + tickOfDay);
			broadcastToOutsidePlayers("🌅 The sun rises on the world.");
		}

		if (tickOfDay == sunsetTick) {
			broadcastToOutsidePlayers("🌇 The sun sets over the land.");
		}

		if (tickCounter % ticksPerWeatherUpdate == 0) {
			System.out.println("[Weather] Ticking weather update...");
			for (World world : WorldManager.getAllWorlds()) {
				System.out.println("[Weather] World: " + world.getName());
				WeatherSystem.updateWeather(world);
			}
		}
		


		// ✅ Trigger advanceDay at END of tick cycle
		if (tickOfDay == ticksPerDay - 1) {
			// Display the Full Moons
			for (Moon moon : moons) {
				moon.advance();

				if (moon.getPhase() == MoonPhase.FULL_MOON &&
						moon.getPreviousPhase() != MoonPhase.FULL_MOON) {

					String message = "🌕 The moon " + moon.getName() + " is full, bathing the land in light.";
					broadcastToOutsidePlayers(message);
				}
			}
			
			advanceDay();   // This is now the only call
		}
		
	}

	public static void tickCombat() {
	    Set<Mob> alreadyProcessed = new HashSet<>();

	    for (Mob mob : WorldManager.getAllMobs()) {
	        Mob target = mob.getTarget();

	        // Skip invalid or already processed
	        if (target == null || mob.isDead() || target.isDead() || alreadyProcessed.contains(mob) || alreadyProcessed.contains(target)) {
	            continue;
	        }

	        if (mob.canAttack()) {
	            StringBuilder roundSummary = new StringBuilder();

	            // Mob attacks target
	            roundSummary.append(CombatManager.performAttack(mob, target)).append("\n");
	            mob.setLastAttackTime();

	            // Check if target is still alive before they counterattack
	            if (!target.isDead() && target.canAttack() && target.getTarget() == mob) {
	                roundSummary.append(CombatManager.performAttack(target, mob)).append("\n");
	                target.setLastAttackTime();
	            }

	            // Final HP/MP summary (if both still exist)
	            if (!mob.isDead() && !target.isDead()) {
	                roundSummary.append(CombatManager.getCombatStatus(mob, target));
	            }

	            // Send result to both players if applicable
	            if (mob instanceof Player playerMob) {
	                playerMob.sendMessage(roundSummary.toString().trim());
	            }

	            if (target instanceof Player playerTarget) {
	                playerTarget.sendMessage(roundSummary.toString().trim());
	            }

	            // Log for debugging
	            System.out.println("[Combat Tick] " + mob.getMobName() + " vs " + target.getMobName());
	            System.out.println(roundSummary);

	            // Mark both as processed
	            alreadyProcessed.add(mob);
	            alreadyProcessed.add(target);
	        }
	    }
	}







	private void broadcastTimeOfDayMessage(boolean isSunrise) {
		String message = isSunrise ? "🌅 The sun rises on a new day." : "🌇 The sun sets, and night falls.";

		for (Player player : WorldManager.getActivePlayers()) {
			Room room = player.getCurrentRoom();
			if (room != null && room.hasFlag(mud.core.RoomFlag.OUTSIDE)) {
				player.sendMessage(message);
			}
		}
	}




	public void advanceDay() {
		int lastAdvancedTick = -1;
		if (currentTick == lastAdvancedTick) {
			System.err.println("⚠️ Skipping duplicate advanceDay() call");
			return;
		}

		lastAdvancedTick = currentTick;
		currentTick += ticksPerDay;





		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				zone.incrementResetCounter();


				ZoneResetType type = zone.getResetType();
				int timer = zone.getResetTimer();

				if (timer <= 0) continue; // skip if no timer set

				boolean ready = zone.getDaysSinceReset() >= timer;

				if (!ready) continue;

				switch (type) {
				case NEVER: // default, zone never undocks/resets
					break;
				case WHEN_EMPTY: // Reset when empty
					if (!zone.hasPlayers()) zone.resetZone();
					break;

				case ALWAYS: // Always reset
					zone.resetZone();
					break;

				case RESET_AND_UNLOAD: // Reset and unload
					if (!zone.hasPlayers()) {
						zone.resetZone();
						WorldManager.unloadZone(zone);
					}                     
					break;

				default:

					break;
				}
			}
		}


/*
		// TODO for Debug
		System.out.println("---- GameClock Debug ----");
		System.out.println("Day: " + getCurrentDayIndex());
		System.out.println("Moons: " + moons.stream().map(Moon::getName).toList());
		for (Moon m : moons) {
			System.out.println(" - " + m.getName() + " phase: " + m.getPhase());
		}
*/

		System.out.println("[GameClock] New day: " + getCurrentDateString());
		for (Player player : WorldManager.getActivePlayers()) {
			World world = player.getCurrentWorld();
			sendDateAndMoonInfo(player, world);
		}
		
	} // end advanceDay



	// --- Moon Management ---
	public void addMoon(Moon moon) {
		moons.add(moon);
	}

	public List<Moon> getMoons() {
		return moons;
	}

	public Moon getMoonByName(String name) {
		for (Moon m : moons) {
			if (m.getName().equalsIgnoreCase(name)) return m;
		}
		return null;
	}

	// --- Time of Day ---
	public boolean isNight() {
		int tickOfDay = currentTick % ticksPerDay;
		return tickOfDay < sunriseTick || tickOfDay > sunsetTick;
	}

	public boolean isDay() {
		return !isNight();
	}

	public int getCurrentTick() {
		return currentTick;
	}

	public int getCurrentDayIndex() {
		return currentTick / ticksPerDay;
	}

	// --- Calendar Delegation ---
	public void sendTimeInfo(Player player, World world) {
	    if (player == null || world == null) return;

	    long tick = world.getClock().getCurrentTick();
	    player.sendMessage("raw tick: " + tick);
	    int ticksPerDay = Config.ticksPerDay;
	    int ticksPerHour = ticksPerDay / 24;
	    int hour = (int) ((tick % ticksPerDay) / ticksPerHour);

	    String timeOfDay;
	    if (hour >= 5 && hour < 8) {
	        timeOfDay = "🌅 Dawn breaks across the sky.";
	    } else if (hour >= 8 && hour < 12) {
	        timeOfDay = "🌞 Morning light brightens the land.";
	    } else if (hour >= 12 && hour < 17) {
	        timeOfDay = "🌤 The sun shines brightly in the afternoon sky.";
	    } else if (hour >= 17 && hour < 20) {
	        timeOfDay = "🌇 The sky glows orange as dusk sets in.";
	    } else if (hour >= 20 && hour < 23) {
	        timeOfDay = "🌃 Night falls over the world.";
	    } else {
	        timeOfDay = "🌌 The deep stillness of midnight surrounds you.";
	    }

	    player.sendMessage("⏰ Time: Hour " + hour + ". " + timeOfDay);

	    Zone zone = player.getCurrentRoom().getZone();
	    if (zone != null && zone.getCurrentWeather() != null) {
	        player.sendMessage("☁️ Weather: " + zone.getCurrentWeather().getDescription());
	    }
	} // end

	
	public String getCurrentDateString() {
		int dayIndex = getCurrentDayIndex(); // This must be counting total in-game days.

		String dayName = calendar.getDayName(dayIndex);
		int week = calendar.getWeekOfMonth(dayIndex); // 0-based index
		String month = calendar.getMonthNameByDay(dayIndex); // ✅ FIXED
		int year = calendar.getYear(dayIndex);

		return String.format("%s, Week %d of %s, Year %d", dayName, week, month, year);
	}

	// Sends date and moons info to the player, including moon phases nicely formatted
	// Separate method to send info to player:
	public void sendDateAndMoonInfo(Player player, World world) {
		player.sendMessage("📅 Date: " + getCurrentDateString());
		if (world.getMoons().isEmpty()) {
			player.sendMessage("🌙 Moons: None.");
		} else {
			for (Moon moon : world.getMoons()) {
				player.sendMessage("🌙 " + moon.getName() + " — Phase: " + moon.getPhase());
			}
		}

		Zone zone = player.getCurrentRoom().getZone();
		if (zone != null && zone.getCurrentWeather() != null) {
			player.sendMessage("☁️ Weather: " + zone.getCurrentWeather().getDescription());
		}
	}

	public void tickMobMovement() {
	    for (World world : WorldManager.getAllWorlds()) {
	        tickMobMovement(world);
	    }
	}
	
	// Enhanced tickMobMovement to confirm mobs are processed
	public void tickMobMovement(World world) {
	    System.out.println("[MobMove] Ticking movement for world: " + world.getName());
	    System.out.println("World " + world.getName() + " has " + world.getRooms().size() + " rooms.");

	    // Collect moves first (Mob -> Destination Room)
	    Map<Mob, Room> moves = new HashMap<>();

	    for (Room room : world.getRooms()) {
	        List<Mob> mobs = room.getMobs();
	  //      System.out.println("Room " + room.getId() + " loaded with mobs: " + mobs.size());

	        // Use a copy to safely iterate
	        List<Mob> mobsCopy = new ArrayList<>(mobs);

	        for (Mob mob : mobsCopy) {
	            if (mob == null) continue;

	            System.out.println("[MobMove] Checking mob: " + mob.getMobName());

	            if (mob.hasBehavior(MobBehaviorFlag.STATIONARY)) continue;
	            if (!mob.hasBehavior(MobBehaviorFlag.WANDERS)) continue;

	            Room currentRoom = mob.getCurrentRoom();
	            if (currentRoom == null) continue;

	            Zone currentZone = currentRoom.getZone();
	            if (currentZone == null) continue;

	            Map<Direction, Room> exits = currentRoom.getExits();
	            if (exits == null || exits.isEmpty()) continue;

	            List<Direction> validDirs = new ArrayList<>();

	            for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                Direction dir = entry.getKey();
	                Room dest = entry.getValue();

	                if (dest == null) continue;
	                if (dest.getZone() != currentZone) continue;
	                if (dest.hasFlag(RoomFlag.NOMOB)) continue;

	                Door door = currentRoom.getDoor(dir);
	                if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                // Skip lastRoom to avoid immediate backtracking
	                if (dest == mob.getLastRoom()) continue;

	                validDirs.add(dir);
	            }

	            // Allow backtracking only if no other options
	            if (validDirs.isEmpty()) {
	                for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                    Direction dir = entry.getKey();
	                    Room dest = entry.getValue();

	                    if (dest == null) continue;
	                    if (dest.getZone() != currentZone) continue;
	                    if (dest.hasFlag(RoomFlag.NOMOB)) continue;

	                    Door door = currentRoom.getDoor(dir);
	                    if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                    validDirs.add(dir);
	                }
	            }

	            if (!validDirs.isEmpty()) {
	                Direction chosen = validDirs.get(new Random().nextInt(validDirs.size()));
	                Room dest = currentRoom.getExit(chosen);

	                if (dest != null && !dest.hasFlag(RoomFlag.NOMOB)) {
	                    moves.put(mob, dest);
	                }
	            }
	        }
	    }

	    // Now apply moves after iteration to avoid concurrent modification
	    for (Map.Entry<Mob, Room> entry : moves.entrySet()) {
	        Mob mob = entry.getKey();
	        Room dest = entry.getValue();
	        Room currentRoom = mob.getCurrentRoom();

	        if (currentRoom != null) {
	            currentRoom.removeMob(mob);
	            currentRoom.broadcast(mob.getMobName() + " wanders.", mob);
	        }

	        mob.setCurrentRoom(dest);
	        dest.addMob(mob);
	        mob.setLastRoom(currentRoom);

	        dest.broadcast(mob.getMobName() + " arrives.", mob);
	    }
	}

	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";

		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}


	public CalendarSystem getCalendar() {
		return calendar;
	}
	private String capitalizeFirstLetter(String input) {
		if (input == null || input.isEmpty()) return input;
		return input.substring(0, 1).toUpperCase() + input.substring(1);
	}

	public String getSunriseTime() {
		return ticksToTimeString(sunriseTick);
	}

	public String getSunsetTime() {
		return ticksToTimeString(sunsetTick);
	}

	// Helper to convert tick to HH:mm format (assumes 60 ticks per 24 hours)
	private String ticksToTimeString(int tick) {
		// 60 ticks = 24 hours
		// So each tick = 24/60 = 0.4 hours = 24 minutes
		double hoursDecimal = (tick * 24.0) / ticksPerDay;
		int hours = (int) hoursDecimal;
		int minutes = (int) ((hoursDecimal - hours) * 60);

		String ampm = (hours >= 12) ? "PM" : "AM";
		int displayHour = hours % 12;
		if (displayHour == 0) displayHour = 12;

		return String.format("%02d:%02d %s", displayHour, minutes, ampm);
	}

	private void checkZoneReset(Zone zone, int currentDay) {
		ZoneResetType type = zone.getResetType();
		int timer = zone.getResetTimer();
		int last = zone.getLastResetDay();

		if (type == ZoneResetType.NEVER || timer <= 0) return; // never resets

		if ((currentDay - last) >= timer) {
			boolean hasPlayers = zone.hasPlayers();

			switch (type) {
			case ZoneResetType.NEVER:

			case ZoneResetType.WHEN_EMPTY:
				if (!hasPlayers) resetZone(zone, currentDay);
				break;

			case ZoneResetType.ALWAYS:
				resetZone(zone, currentDay);
				break;

			case ZoneResetType.RESET_AND_UNLOAD:
				resetZone(zone, currentDay);
				WorldManager.unloadZone(zone); // implement this logic if needed
				break;
			}
		}
	}


	private void broadcastToOutsidePlayers(String message) {
		System.out.println("📣 Broadcasting to outside players...");
		System.out.println("🧍 Active players: " + WorldManager.getActivePlayers().size());

		for (Player player : WorldManager.getActivePlayers()) {
			Room room = player.getCurrentRoom();
			if (room == null) {
				System.out.println("🚫 Player " + player.getName() + " is not in a room.");
				continue;
			}

			if (room.hasFlag(RoomFlag.OUTSIDE)) {
				System.out.println("✅ Sending sunrise/sunset to " + player.getName());
				player.sendMessage(message);
			} else {
				System.out.println("⛔ Room " + room.getId() + " is not outside for player " + player.getName());
			}
		}
	}

	private void updateRoomLighting(boolean isDay) {
		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					boolean hasLightSource = room.getObjects().stream()
							.anyMatch(obj -> obj.getType() == ObjectType.LIGHTSOURCE);
					boolean lit = isDay || hasLightSource;
					room.setLit(lit);
				}
			}
		}
	}

	public void setMoons(List<Moon> moons) {
		this.moons = moons;
	}



	private void resetZone(Zone zone, int currentDay) {
		System.out.println("Resetting zone " + zone.getZoneId());
		zone.clearMobs(); // optionally remove mobs
		zone.clearObjects(); // optionally remove items
		zone.initialize(); // re-run script
		zone.setLastResetDay(currentDay);
	}

	public String getDayOfWeek() {
		return calendar.getDayName(getCurrentDay());
	}

	public String getFormattedDate() {
		return String.format("%s, Week %d of %s, Year %d", 
				getDayOfWeek(), currentWeek, getCurrentMonthName(), currentYear);
	}

	public String getCurrentMonthName() {
		return calendar.getMonthName(currentMonth);
	}
	public int getCurrentDayOfYear() {
		return (currentMonth * calendar.getDaysPerMonth()) + currentDay;
	}
	public int getCurrentDay() {
		return currentDay;
	}

	public int getCurrentMonth() {
		return currentMonth;
	}

	public int getCurrentWeek() {
		return currentWeek;
	}

	public int getCurrentYear() {
		return currentYear;
	}



	public String getFormattedTime(World world) {
		StringBuilder sb = new StringBuilder();

		int curTick = world.getClock().tickCounter;
		int dayOfYear = getCurrentDayOfYear();
		int currentMonth = getCurrentMonth();
		int currentWeek = getCurrentWeek();
		int currentYear = getCurrentYear();
		int currentHour = getCurrentTick(); // Or however you determine hour

		String dayName = calendar.getDayName(dayOfYear);
		String monthName = calendar.getMonthName(currentMonth);
		sb.append("📅 Date: ").append(dayName)
		.append(", Week ").append(currentWeek)
		.append(" of ").append(monthName)
		.append(", Year ").append(currentYear).append("\n");

		for (Moon moon : world.getMoons()) {
			MoonPhase phase = moon.getPhase();
			sb.append("🌙 ").append(moon.getName())
			.append(" — Phase: ").append(phase).append("\n");
		}

		String timeDesc = calendar.getTimeOfDay(curTick);
		sb.append("🕒 Time: ").append(timeDesc).append(" - Hour: ").append(ticksToTimeString(curTick));

		return sb.toString();
	}

	public void tickAllMobs() {
	    for (Mob mob : WorldManager.getAllMobs()) {
	        mob.passiveRegenTick();
	    }
	}

} // end GameClock
