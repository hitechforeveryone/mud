package mud.spell;

import mud.combat.CombatManager;
import mud.core.Mob;
import mud.core.MagicDamageType;
import mud.core.MobRank;

public class FireballSpell implements Spell {

    @Override
    public String getName() {
        return "fireball";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to hit.");
            return false;
        }

        int manaCost = 15;
        if (caster.getCurrentMP() - manaCost < 0) {
        	caster.sendMessage("You do not have enough mana to cast that.");
        	return false;
        }
        else {
        	caster.setCurrentMP(caster.getCurrentMP()-manaCost);
        	}
        
        
        // 🔥 Get damage type and caster's rank
        MagicDamageType damageType = MagicDamageType.FIRE;
        MobRank rank = caster.getRank();
        double multiplier = rank != null ? rank.getMultiplier() : 1.0;

        // 🔢 Calculate raw + scaled damage
        int baseDamage = 15 + caster.getIntellect();
        caster.sendMessage(caster.getIntellect() + ":" + caster.getBaseIntellect());
        int finalDamage = (int) Math.round(baseDamage * multiplier);

        // 💥 Apply damage
        target.takeDamage(finalDamage, damageType);

        // 🎨 Flavor
        String icon = damageType.getIcon();
        String typeName = damageType.getPrettyName().toLowerCase();

        // 💬 Messages
        caster.sendMessage("You hurl a " + typeName + "ball " + icon + " at " + target.getMobName()
                + " for " + finalDamage + " damage!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " hits you with a " + typeName + "ball " + icon
                    + " for " + finalDamage + " damage!");
        }

        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " hurls a " + typeName + "ball " + icon + " at " + target.getMobName()
                + ", hitting for " + finalDamage + " damage!",
            caster, target
        );

        CombatManager.deathStuff(caster, target);
        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}
