package mud.spell;

import mud.core.Mob;
import mud.core.Room;

public class RescueSpell implements Spell {

    @Override
    public String getName() {
        return "rescue";
    }

    /**
     * Rescue redirects the attack from the target mob to the caster.
     * Returns true if rescue succeeded, false otherwise.
     */
    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no one to rescue.");
            return false;
        }
        if (target == caster) {
            caster.sendMessage("You can't rescue yourself.");
            return false;
        }

        Room room = caster.getCurrentRoom();
        if (room == null) {
            caster.sendMessage("You are nowhere. Rescue failed.");
            return false;
        }

        // Find an attacker who is currently attacking the target
        Mob attacker = findAttackerAttackingTarget(room, target);
        if (attacker == null) {
            caster.sendMessage(target.getMobName() + " is not being attacked.");
            return false;
        }

        // Redirect attacker's target to caster
        attacker.setTarget(caster);

        // Messaging
        caster.sendMessage("You heroically rescue " + target.getMobName() + " from " + attacker.getMobName() + "!");
        target.sendMessage(caster.getMobName() + " rescues you from " + attacker.getMobName() + "!");
        attacker.sendMessage(caster.getMobName() + " jumps in and intercepts your attack!");

        // Broadcast to others except caster, target, attacker
        room.broadcastExcept(
            caster.getMobName() + " rescues " + target.getMobName() + " from " + attacker.getMobName() + "!",
            caster, target, attacker
        );

        return true;
    }

    /**
     * Utility method to find a mob in the room attacking the target.
     * This depends on your combat system; adjust accordingly.
     */
    private Mob findAttackerAttackingTarget(Room room, Mob target) {
        for (Mob mob : room.getMobs()) {
            if (mob.isAttacking() && mob.getTarget() == target) {
                return mob;
            }
        }
        return null;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}
