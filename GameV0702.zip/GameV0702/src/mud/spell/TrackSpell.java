package mud.spell;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Room;
import mud.core.Zone;

public class TrackSpell implements Spell {
	
	
	public String cast(Player caster, String[] args) {
	    if (args.length < 1) return "Track who?";

	    String targetName = String.join(" ", args).toLowerCase();
	    Room startRoom = caster.getRoom();
	    Zone zone = caster.getCurrentZone();

	    if (zone == null || startRoom == null) return "You are not in a valid location to track.";

	    // Check current room
	    for (Mob mob : startRoom.getMobs()) {
	        if (matches(mob, targetName)) {
	            return mob.getMobName() + " is right here with you.";
	        }
	    }

	    Map<Room, Room> visitedFrom = new HashMap<>();
	    Map<Room, Direction> firstDirection = new HashMap<>();
	    Queue<Room> queue = new LinkedList<>();
	    queue.add(startRoom);
	    visitedFrom.put(startRoom, null);

	    while (!queue.isEmpty()) {
	        Room current = queue.poll();

	        for (Direction dir : Direction.values()) {
	            Room neighbor = current.getExit(dir);
	            if (neighbor == null || visitedFrom.containsKey(neighbor)) continue;

	            visitedFrom.put(neighbor, current);
	            firstDirection.put(neighbor, firstDirection.getOrDefault(current, dir));

	            for (Mob mob : neighbor.getMobs()) {
	                if (matches(mob, targetName)) {
	                    Direction foundDirection = firstDirection.get(neighbor);
	                    return "You sense " + mob.getMobName() + " to the " + foundDirection.name().toLowerCase() + ".";
	                }
	            }

	            queue.add(neighbor);
	        }
	    }

	    return "You can't sense " + targetName + " anywhere nearby.";
	}

	private boolean matches(Mob mob, String input) {
	    if (mob.hasKeyword(input)) return true;
	    return mob.matchesKeyword(input); // depends on how you implemented this
	}


    @Override
    public String getName() {
        return "Track";
    }

    /*
    @Override
    public int getManaCost() {
        return 5; // Or whatever balance dictates
    }
*/
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cast(Mob caster, Mob target) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}
