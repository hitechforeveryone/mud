package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.spell.effects.DamageReductionEffect;

public class DamageReductionSpell implements Spell {

    @Override
    public String getName() {
        return "damage_reduction";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to protect.");
            return false;
        }

        int reductionPercent = 25; // 25% damage reduction
        int duration = 10; // lasts 10 ticks (adjust as needed)

        // Add effect to target
        target.addDamageReductionEffect(new DamageReductionEffect(target, reductionPercent, duration));

        // Messaging
        caster.sendMessage("You cast a protective aura on " + target.getMobName() + ", reducing damage taken by " + reductionPercent + "%.");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " casts a protective aura on you, reducing damage taken.");
        }

        Room room = caster.getCurrentRoom();
        if (room != null) {
            room.broadcastExcept(caster.getMobName() + " casts a glowing shield around " + target.getMobName() + ".", caster, target);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}
