package mud.spell;

import java.io.File;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import mud.core.Mob;

public class SpellManager {
    private static SpellManager instance;
    private static final Map<String, Spell> spells = new ConcurrentHashMap<>();

    private SpellManager() {
        loadSpells();
    }

    public static synchronized SpellManager getInstance() {
        if (instance == null) {
            instance = new SpellManager();
        }
        return instance;
    }

    private void loadSpells() {
        try {
            String packageName = "mud.spell";
            String path = packageName.replace('.', '/');
            URL resource = ClassLoader.getSystemClassLoader().getResource(path);

            if (resource == null) {
                System.err.println("Could not find spell package: " + path);
                return;
            }

            File dir = new File(resource.toURI());
            if (!dir.exists() || !dir.isDirectory()) return;

            for (File file : dir.listFiles((d, name) -> name.endsWith(".class") && !name.contains("$"))) {
                String className = file.getName().replace(".class", "");
                Class<?> clazz = Class.forName(packageName + "." + className);

                if (Spell.class.isAssignableFrom(clazz) && !Modifier.isAbstract(clazz.getModifiers())) {
                    Spell spell = (Spell) clazz.getDeclaredConstructor().newInstance();
                    registerSpell(spell);
                    System.out.println("Loaded spell: " + className);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to auto-load spells:");
            e.printStackTrace();
        }
    }

    public String registerSpell(Spell spell) {
        if (spell == null || spell.getName() == null || spell.getName().isEmpty()) {
            throw new IllegalArgumentException("Spell and spell name must not be null or empty.");
        }
        spells.put(spell.getName().toLowerCase(), spell);
        return "Spell " + spell.getName() + " added.";
    }

    public static Spell getSpellByName(String name) {
        if (name == null) return null;
        return spells.get(name.toLowerCase());
    }

    public static String castSpell(String spellName, Mob caster, Mob target) {
        Spell spell = getSpellByName(spellName);
        if (spell == null) {
            return "No such spell: " + spellName;
        }

        boolean success = spell.cast(caster, target);
        return success ? spell.getName() + " was cast successfully." : "The spell failed.";
    }

    public static String listSpells() {
        getInstance();
        return "Available spells: " + String.join(", ", spells.keySet());
    }
}
