package mud.spell;
// SAMPLE MELEE ATTACK SPELL
import mud.core.Mob;
import mud.core.EquipSlot;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.Room;

public class SmiteSpell implements Spell {

    @Override
    public String getName() {
        return "smite";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to heal.");
            return false;
        }

        int healAmount = 20 + caster.getIntellect();

        target.heal(healAmount);

        caster.sendMessage("You cast heal and restore " + healAmount + " health to " + target.getMobName() + ".");
        
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " heals you for " + healAmount + " health.");
        }

        // Broadcast to everyone else in the room except caster and target
        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " casts a healing spell on " + target.getMobName() + ".",
            caster, target
        );

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}