package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.EquipSlot;  // Import the nested enum explicitly

public class KickSpell implements Spell {

    @Override
    public String getName() {
        return "kick";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to kick.");
            return false;
        }

        if (target == caster) {
            caster.sendMessage("You can't kick yourself.");
            return false;
        }

        // Base damage for kick
        int baseDamage = 10 + caster.getStat("Strength") / 2;  // Use getStat() or getter for strength

        // Add weapon damage if wielding a main hand weapon
        ObjectItem weapon = caster.getEquippedItem(EquipSlot.MAINHAND);
        if (weapon != null && weapon.getObjectType() == ObjectType.WEAPON) {
            baseDamage += weapon.rollDamage();
            baseDamage += weapon.getDamageBonus();
        }

        // Apply damage to target
        target.takeDamage(baseDamage);

        // Send messages
        caster.sendMessage("You deliver a powerful kick to " + target.getMobName() + " for " + baseDamage + " damage!");
        target.sendMessage(caster.getMobName() + " kicks you hard, dealing " + baseDamage + " damage!");

        // Broadcast to others in the room except caster and target
        Room room = caster.getCurrentRoom();
        if (room != null) {
            room.broadcastExcept(caster.getMobName() + " kicks " + target.getMobName() + " with a fierce blow!", caster, target);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}