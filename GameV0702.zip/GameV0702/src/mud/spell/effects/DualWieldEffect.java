package mud.spell.effects;

import mud.spell.effects.Effect;
import mud.core.Mob;

public class DualWieldEffect implements Effect {

    private final Mob target;
    private final boolean permanent = true;

    public DualWieldEffect(Mob target) {
        this.target = target;
        this.target.setCanDualWield(true);  // Enable dual wield
    }

    @Override
    public void tick() {
        // Passive/permanent effects don’t need ticking logic
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent effect
    }

    @Override
    public String getName() {
        return "dual_wield";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
    
    public void onRemove() {
        target.setCanDualWield(false);
    }

	@Override
	public int getHpBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStrengthBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
