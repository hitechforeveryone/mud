// mud/spell/LifeBloomEffect.java
package mud.spell.effects;

import mud.core.Mob;
import mud.core.Room;
import mud.spell.effects.HealOverTimeEffect;

public class LifeBloomEffect implements Effect {

    private final Mob target;
    private final int tickHeal;
    private final int finalHeal;
    private final int totalTicks;

    private int ticksPassed = 0;

    public LifeBloomEffect(Mob target, int tickHeal, int finalHeal, int totalTicks) {
        this.target = target;
        this.tickHeal = tickHeal;
        this.finalHeal = finalHeal;
        this.totalTicks = totalTicks;
    }

    @Override
    public void tick() {
        ticksPassed++;

        if (ticksPassed < totalTicks) {
            target.heal(tickHeal);
            target.sendMessage("A gentle pulse of life restores " + tickHeal + " health.");
        } else if (ticksPassed == totalTicks) {
            target.heal(finalHeal);
            target.sendMessage("The bloom explodes with healing energy, restoring " + finalHeal + " health!");
            Room room = target.getCurrentRoom();
            if (room != null) {
                room.broadcastExcept(target.getMobName() + "'s Life Bloom bursts in a radiant flash!", target, null);
            }
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getHpBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStrengthBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
