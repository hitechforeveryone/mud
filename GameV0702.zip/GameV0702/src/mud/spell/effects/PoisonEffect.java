package mud.spell.effects;

import mud.core.Mob;

public class PoisonEffect implements Effect {
    private int duration;

    public PoisonEffect(int duration) {
        this.duration = duration;
    }

    @Override
    public String getType() {
        return "Poisoned";
    }

    @Override
    public int getDuration() {
        return duration;
    }

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
