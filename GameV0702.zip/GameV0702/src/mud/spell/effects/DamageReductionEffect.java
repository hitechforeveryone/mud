// mud/spell/effects/DamageReductionEffect.java
package mud.spell.effects;

import mud.core.Mob;

public class DamageReductionEffect implements Effect {
    private final Mob target;
    private final int reductionPercent;
    private int remainingTicks;

    public DamageReductionEffect(Mob target, int reductionPercent, int durationTicks) {
        this.target = target;
        this.reductionPercent = reductionPercent;
        this.remainingTicks = durationTicks;
    }

    @Override
    public void tick() {
        remainingTicks--;
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public String getName() {
        return "damage_reduction";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    public int reduceDamage(int incomingDamage) {
        return incomingDamage * (100 - reductionPercent) / 100;
    }

	@Override
	public int getHpBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStrengthBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
