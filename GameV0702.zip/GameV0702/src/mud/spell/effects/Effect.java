package mud.spell.effects;

import mud.core.Mob;

public interface Effect {
    void tick();
    boolean isExpired();
    Mob getTarget(); // Optional but useful
    String getName(); // For debugging or UI
    String getType(); // or EffectType getType(), if you're using an enum
    int getDuration(); // if applicable
    
    default void onApply(Mob target) {}
    default void onExpire(Mob target) {}
    default void onRemove() {}
    
 // These default to 0 unless overridden by specific effect subclasses
    public default int getHpBonus() {
        return 0;
    }

    public default int getMpBonus() {
        return 0;
    }

    public default int getStrengthBonus() {
        return 0;
    }

    public default int getStaminaBonus() {
        return 0;
    }

    public default int getIntellectBonus() {
        return 0;
    }

    public default int getAgilityBonus() {
        return 0;
    }

    public default int getHitrollBonus() {
        return 0;
    }

    public default int getDamrollBonus() {
        return 0;
    }

    
}
