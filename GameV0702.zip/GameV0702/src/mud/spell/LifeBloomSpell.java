package mud.spell;

import mud.core.Mob;
import mud.spell.effects.LifeBloomEffect;

public class LifeBloomSpell implements Spell {

    @Override
    public String getName() {
        return "lifebloom";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to bloom.");
            return false;
        }

        LifeBloomEffect effect = new LifeBloomEffect(target, 5, 30, 3); // 5 HP per tick, 30 on bloom, 3 ticks
        target.addEffect(effect);

        caster.sendMessage("You begin a gentle bloom of life on " + target.getMobName() + ".");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " blesses you with a blooming life spell.");
            target.getCurrentRoom().broadcastExcept(caster.getMobName() + " casts Life Bloom on " + target.getMobName() + ".", caster, target);
        } else {
            caster.getCurrentRoom().broadcastExcept(caster.getMobName() + " casts Life Bloom on themselves.", caster, null);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}
}
