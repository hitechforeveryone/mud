package mud.spell;

import java.util.*;

import mud.core.Profession;

public class SpellRegister {

    // Map from Profession to (Map from spellName -> Spell)
    private final Map<Profession, Map<String, Spell>> spellsByProfession;

    public SpellRegister() {
        spellsByProfession = new EnumMap<>(Profession.class);
        // Initialize map for each profession
        for (Profession prof : Profession.values()) {
            spellsByProfession.put(prof, new HashMap<>());
        }
    }

    /**
     * Registers a new spell under a given profession.
     * If a spell with the same name exists, it will be replaced.
     */
    public void addSpell(Profession profession, Spell spell) {
        if (profession == null || spell == null) {
            throw new IllegalArgumentException("Profession and spell cannot be null");
        }
        spellsByProfession.get(profession).put(spell.getName().toLowerCase(), spell);
    }

    /**
     * Gets a spell by name under a specific profession.
     * Returns null if no such spell exists.
     */
    public Spell getSpell(Profession profession, String spellName) {
        if (profession == null || spellName == null) return null;
        return spellsByProfession.get(profession).get(spellName.toLowerCase());
    }

    /**
     * Gets all spells registered under a given profession.
     */
    public Collection<Spell> getSpellsForProfession(Profession profession) {
        if (profession == null) return Collections.emptyList();
        return Collections.unmodifiableCollection(spellsByProfession.get(profession).values());
    }

    /**
     * Removes a spell by name from a profession.
     */
    public boolean removeSpell(Profession profession, String spellName) {
        if (profession == null || spellName == null) return false;
        return spellsByProfession.get(profession).remove(spellName.toLowerCase()) != null;
    }
    
    public Set<String> getSpellsFor(Profession profession) {
        return spellsByProfession.getOrDefault(profession, Collections.emptyMap()).keySet();
    }
    
}
