package mud.editor;

import mud.config.Config;
import mud.core.Player;
import mud.core.Room;
import mud.core.Zone;
import mud.scripting.ZoneScript;
import mud.scripting.BasicZoneScript;
import mud.scripting.DoorState;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ZoneScriptEditor — final version
 *
 * - Does NOT implement ZoneScript. It edits a ZoneScript instance.
 * - Supports: recall nodes, nested object spawns, door states,
 *   room-based mob/object additions, and NEW: global mob spawn (with Count).
 * - Uses zoneScript.serialize() for saving to text.
 */
public class ZoneScriptEditor implements Editor {

    private Player player;
    private ZoneScript zoneScript;

    private boolean finished = false;
    private ZoneScriptEditorState state = ZoneScriptEditorState.MAIN_MENU;

    private int editingRoomId = -1;
    private String editingDoorDirection = null;

    private int pendingMobId = -1;
    private int pendingObjectId = -1;
    private int pendingContainerObjectId = -1;

    // For global mob spawn flow
    private double pendingChance = 0.0;

    public ZoneScriptEditor(Player player, ZoneScript zoneScript) {
        this.player = player;
        this.zoneScript = zoneScript;
    }

    // ===== Editor lifecycle =====

    @Override
    public void startEditing() {
        finished = false;
        this.state = ZoneScriptEditorState.MAIN_MENU;
        showMenu();
    }

    @Override
    public void stopEditing() {
        finished = true;
    }

    @Override
    public void tick() { }

    @Override
    public boolean save() { return saveZoneScriptInternal(); }

    @Override
    public boolean isFinished() { return finished; }

    @Override
    public String getEditorName() {
        return "ZoneScriptEditor for zone " + (zoneScript != null ? zoneScript.getZoneId() : "?");
    }

    @Override
    public void showMenu() {
        player.sendMessage("\n--- Zone Script Editor ---");
        player.sendMessage("1) Edit Room Scripts");
        player.sendMessage("2) Show Script");
        player.sendMessage("3) Set Recall Nodes");
        player.sendMessage("4) Save Script and Exit Editor");
        player.sendMessage("5) Exit Without Saving");
        player.sendMessage("6) Add Global Mob Spawn");
        player.sendMessage("Type a command or option number:");
    }

    public void showScript() {
        if (zoneScript == null) {
            player.sendMessage("No script assigned.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\nZoneScript for zone ID: ").append(zoneScript.getZoneId()).append("\n");

        Map<Integer, Double> mobSpawns = zoneScript.getMobSpawnChances();
        if (mobSpawns != null && !mobSpawns.isEmpty()) {
            sb.append("Mob Spawn Rules:\n");
            for (Map.Entry<Integer, Double> entry : mobSpawns.entrySet()) {
                int count = 1;
                if (zoneScript instanceof BasicZoneScript bzs) {
                    count = bzs.getMobSpawnCount(entry.getKey());
                }
                sb.append("  MobID: ").append(entry.getKey())
                  .append(", Count: ").append(count)
                  .append(", Chance: ").append(String.format("%.1f", entry.getValue() * 100)).append("%\n");
            }
        }

        Map<Integer, Double> objectSpawns = zoneScript.getObjectSpawnChances();
        if (objectSpawns != null && !objectSpawns.isEmpty()) {
            sb.append("Object Spawn Rules:\n");
            for (Map.Entry<Integer, Double> entry : objectSpawns.entrySet()) {
                sb.append("  ObjectID: ").append(entry.getKey())
                  .append(", Chance: ").append(String.format("%.1f", entry.getValue() * 100)).append("%\n");
            }
        }

        if (zoneScript instanceof BasicZoneScript bzs) {
            Map<Integer, Map<String, DoorState>> doorStates = bzs.getDoorStates();
            if (doorStates != null && !doorStates.isEmpty()) {
                sb.append("Door States:\n");
                for (Map.Entry<Integer, Map<String, DoorState>> roomEntry : doorStates.entrySet()) {
                    int roomId = roomEntry.getKey();
                    for (Map.Entry<String, DoorState> dirEntry : roomEntry.getValue().entrySet()) {
                        sb.append("  Room ").append(roomId)
                          .append(" - ").append(dirEntry.getKey())
                          .append(": ").append(dirEntry.getValue()).append("\n");
                    }
                }
            }

            Set<Integer> recallNodes = bzs.getRecallNodes();
            if (recallNodes != null && !recallNodes.isEmpty()) {
                sb.append("Recall Nodes:\n");
                for (int roomId : recallNodes) {
                    sb.append("  RoomID: ").append(roomId).append("\n");
                }
            }
        }

        player.sendMessage(sb.toString());
    }

    // ===== Input handling =====

    @Override
    public void handleInput(String input) {
        if (input == null || input.isBlank()) {
            player.sendMessage("Enter a command or type 'menu' to see options.");
            return;
        }

        input = input.trim();

        if (input.equalsIgnoreCase("menu")) { showMenu(); return; }
        if (input.equalsIgnoreCase("show")) { showScript(); return; }
        if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("done") || input.equalsIgnoreCase("quit")) {
            player.sendMessage("Exiting zone script editor.");
            finished = true;
            return;
        }

        switch (state) {
            case MAIN_MENU -> handleMainMenu(input);
            case AWAITING_ROOM_ID -> handleRoomIdInput(input);
            case EDITING_ROOM_SCRIPT -> handleRoomScriptMenuInput(input);
            case AWAITING_ADD_MOB_ID -> handleMobIdInput(input);
            case AWAITING_MOB_LOAD_CHANCE -> handleMobLoadChance(input);
            case AWAITING_ADD_MOB_EQUIP_ID, AWAITING_ADD_MOB_INV_ID -> handleMobEquipOrInvId(input);
            case AWAITING_MOB_EQUIP_OBJECT_ID, AWAITING_MOB_INV_OBJECT_ID -> handleEquipOrInvObjectId(input);
            case AWAITING_MOB_EQUIP_LOAD_CHANCE, AWAITING_MOB_INV_LOAD_CHANCE -> handleEquipOrInvLoadChance(input);
            case AWAITING_ADD_OBJECT_ID -> handleObjectIdInput(input);
            case AWAITING_OBJECT_LOAD_CHANCE -> handleObjectLoadChance(input);
            case AWAITING_DOOR_DIRECTION -> handleDoorDirection(input);
            case AWAITING_DOOR_STATE -> handleDoorState(input);
            case AWAITING_CONTAINER_OBJECT_ID -> handleContainerObjectId(input);
            case AWAITING_INNER_OBJECT_ID -> handleInnerObjectId(input);
            case AWAITING_RECALL_NODES -> handleRecallNodesInput(input);
            case AWAITING_GLOBAL_MOB_ID -> handleGlobalMobId(input);
            case AWAITING_GLOBAL_MOB_CHANCE -> handleGlobalMobChance(input);
            case AWAITING_GLOBAL_MOB_COUNT -> handleGlobalMobCount(input);
            default -> {
                player.sendMessage("Unexpected state. Returning to main menu.");
                state = ZoneScriptEditorState.MAIN_MENU;
                showMenu();
            }
        }
    }

    private void handleMainMenu(String input) {
        switch (input) {
            case "1" -> { player.sendMessage("Enter room ID to edit:"); state = ZoneScriptEditorState.AWAITING_ROOM_ID; }
            case "2" -> showScript();
            case "3" -> { player.sendMessage("Enter comma-separated Room IDs to set as Recall Nodes:"); state = ZoneScriptEditorState.AWAITING_RECALL_NODES; }
            case "4" -> { if (saveZoneScriptInternal()) { player.sendMessage("Exiting editor."); finished = true; } }
            case "5" -> { player.sendMessage("Exiting editor without saving."); finished = true; }
            case "6" -> { player.sendMessage("Enter Mob ID to add globally:"); state = ZoneScriptEditorState.AWAITING_GLOBAL_MOB_ID; }
            default -> player.sendMessage("Invalid option. Type 'menu' to see commands.");
        }
    }

    private void handleRoomIdInput(String input) {
        try {
            int roomId = Integer.parseInt(input);
            Room room = player.getCurrentWorld().getRoom(player.getCurrentZone().getZoneId(), roomId);
            if (room == null) {
                player.sendMessage("Room not found.");
            } else {
                editingRoomId = roomId;
                player.sendMessage("Now editing script options for Room ID: " + roomId);
                state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
                showRoomScriptMenu(roomId);
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid room ID.");
        }
    }

    private void handleRoomScriptMenu(int roomId) { showRoomScriptMenu(roomId); }

    private void handleRoomScriptMenuInput(String input) {
        switch (input) {
            case "1" -> { player.sendMessage("Enter Mob ID to add to this room:"); state = ZoneScriptEditorState.AWAITING_ADD_MOB_ID; }
            case "2" -> { player.sendMessage("Enter Mob ID to give equipment to:"); state = ZoneScriptEditorState.AWAITING_ADD_MOB_EQUIP_ID; }
            case "3" -> { player.sendMessage("Enter Mob ID to add inventory to:"); state = ZoneScriptEditorState.AWAITING_ADD_MOB_INV_ID; }
            case "4" -> { player.sendMessage("Enter Object ID to add to this room:"); state = ZoneScriptEditorState.AWAITING_ADD_OBJECT_ID; }
            case "5" -> { player.sendMessage("Enter **container** Object ID (in this room) to put something inside:"); state = ZoneScriptEditorState.AWAITING_CONTAINER_OBJECT_ID; }
            case "6" -> { player.sendMessage("Enter Door Direction to set state (e.g., north, east):"); state = ZoneScriptEditorState.AWAITING_DOOR_DIRECTION; }
            case "7" -> { player.sendMessage("Returning to main menu."); state = ZoneScriptEditorState.MAIN_MENU; showMenu(); }
            default -> player.sendMessage("Invalid option. Choose 1-7.");
        }
    }

    private void handleMobIdInput(String input) {
        try { pendingMobId = Integer.parseInt(input); player.sendMessage("Enter load chance (0-100%) for Mob ID " + pendingMobId + ":"); state = ZoneScriptEditorState.AWAITING_MOB_LOAD_CHANCE; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Mob ID."); }
    }

    private void handleMobLoadChance(String input) {
        try { double chance = Double.parseDouble(input) / 100.0; zoneScript.addMobToRoom(editingRoomId, pendingMobId, chance); player.sendMessage("Added Mob ID " + pendingMobId + " to room " + editingRoomId + " with " + (chance * 100) + "% load chance."); }
        catch (NumberFormatException e) { player.sendMessage("Invalid load chance. Must be a number between 0 and 100."); }
        pendingMobId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleMobEquipOrInvId(String input) {
        player.sendMessage("Mob equipment/inventory editing not yet implemented in BasicZoneScript.");
        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleEquipOrInvObjectId(String input) {
        player.sendMessage("Mob equipment/inventory editing not yet implemented in BasicZoneScript.");
        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleEquipOrInvLoadChance(String input) {
        player.sendMessage("Mob equipment/inventory editing not yet implemented in BasicZoneScript.");
        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleObjectIdInput(String input) {
        try { pendingObjectId = Integer.parseInt(input); player.sendMessage("Enter load chance (0-100%) for Object ID " + pendingObjectId + ":"); state = ZoneScriptEditorState.AWAITING_OBJECT_LOAD_CHANCE; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Object ID."); }
    }

    private void handleObjectLoadChance(String input) {
        try { double chance = Double.parseDouble(input) / 100.0; zoneScript.addObjectToRoom(editingRoomId, pendingObjectId, chance); player.sendMessage("Added Object ID " + pendingObjectId + " to room " + editingRoomId + " with " + (chance * 100) + "% load chance."); }
        catch (NumberFormatException e) { player.sendMessage("Invalid load chance. Must be a number between 0 and 100."); }
        pendingObjectId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleDoorDirection(String input) {
        editingDoorDirection = input.toLowerCase();
        player.sendMessage("Enter door state for direction '" + editingDoorDirection + "' (open, closed, locked):");
        state = ZoneScriptEditorState.AWAITING_DOOR_STATE;
    }

    private void handleDoorState(String input) {
        DoorState doorState = switch (input.toLowerCase()) {
            case "open" -> DoorState.OPEN;
            case "closed" -> DoorState.CLOSED;
            case "locked" -> DoorState.LOCKED;
            default -> null;
        };
        if (doorState == null) { player.sendMessage("Invalid door state. Use open, closed, or locked."); return; }
        zoneScript.setDoorState(editingRoomId, editingDoorDirection, doorState);
        player.sendMessage("Door state for '" + editingDoorDirection + "' set to " + doorState + ".");
        editingDoorDirection = null; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleContainerObjectId(String input) {
        try { pendingContainerObjectId = Integer.parseInt(input.trim()); player.sendMessage("Enter **inner** Object ID to place inside " + pendingContainerObjectId + ":"); state = ZoneScriptEditorState.AWAITING_INNER_OBJECT_ID; }
        catch (NumberFormatException e) { player.sendMessage("Invalid object ID. Try again:"); }
    }

    private void handleInnerObjectId(String input) {
        try { int innerObjectId = Integer.parseInt(input.trim()); zoneScript.addObjectInsideObject(editingRoomId, pendingContainerObjectId, innerObjectId); player.sendMessage("Queued object " + innerObjectId + " inside " + pendingContainerObjectId + " for room " + editingRoomId + "."); }
        catch (NumberFormatException e) { player.sendMessage("Invalid object ID. Aborting nested add."); }
        finally { pendingContainerObjectId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId); }
    }

    private void handleRecallNodesInput(String input) {
        if (!(zoneScript instanceof BasicZoneScript bzs)) { player.sendMessage("Current ZoneScript doesn't support recall nodes."); state = ZoneScriptEditorState.MAIN_MENU; showMenu(); return; }
        String[] parts = input.split(",");
        for (String part : parts) {
            try { int roomId = Integer.parseInt(part.trim()); bzs.addRecallNode(roomId); player.sendMessage("Added room " + roomId + " as a recall node."); }
            catch (NumberFormatException e) { player.sendMessage("Invalid room ID: " + part); }
        }
        state = ZoneScriptEditorState.MAIN_MENU; showMenu();
    }

    private void handleGlobalMobId(String input) {
        try { pendingMobId = Integer.parseInt(input.trim()); player.sendMessage("Enter spawn chance (0-100%) for Mob ID " + pendingMobId + ":"); state = ZoneScriptEditorState.AWAITING_GLOBAL_MOB_CHANCE; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Mob ID."); }
    }

    private void handleGlobalMobChance(String input) {
        try { double pct = Double.parseDouble(input.trim()); if (pct < 0 || pct > 100) throw new NumberFormatException(); pendingChance = pct / 100.0; player.sendMessage("Enter Count for Mob ID " + pendingMobId + " (default 1):"); state = ZoneScriptEditorState.AWAITING_GLOBAL_MOB_COUNT; }
        catch (NumberFormatException e) { player.sendMessage("Invalid chance; must be 0-100"); }
    }

    private void handleGlobalMobCount(String input) {
        int count = 1;
        try { count = Math.max(1, Integer.parseInt(input.trim())); } catch (NumberFormatException ignored) {}
        if (zoneScript instanceof BasicZoneScript bzs) { bzs.addMobSpawnChance(pendingMobId, pendingChance, count); }
        else { zoneScript.addMobSpawnChance(pendingMobId, pendingChance); player.sendMessage("Warning: underlying ZoneScript doesn't support counts; using 1."); }
        player.sendMessage("Added global mob spawn: mob=" + pendingMobId + ", count=" + count + ", chance=" + (int)(pendingChance * 100) + "%");
        pendingMobId = -1; pendingChance = 0.0; state = ZoneScriptEditorState.MAIN_MENU; showMenu();
    }

    private void showRoomScriptMenu(int roomId) {
        player.sendMessage("\n--- Editing Script for Room ID: " + roomId + " ---");
        player.sendMessage("1) Add Mob");
        player.sendMessage("2) Add Mob Equipment");
        player.sendMessage("3) Add Mob Inventory");
        player.sendMessage("4) Add Object");
        player.sendMessage("5) Add Object Inside Object");
        player.sendMessage("6) Set Door State");
        player.sendMessage("7) Back to Main Menu");
        player.sendMessage("Choose an option:");
    }

    // ===== Saving =====

    private boolean saveZoneScriptInternal() {
        Zone zone = player.getZone();
        if (zone == null || zone.getWorld() == null) {
            player.sendMessage("Cannot save: zone or world is null.");
            return false;
        }
        String baseName = zone.getWorld().getWorldId() + "_" + zone.getZoneId();
        File scriptFile = new File(Config.SCRIPT_DIR, baseName + ".Script.txt");
        try (FileWriter writer = new FileWriter(scriptFile)) {
            writer.write(zoneScript.serialize());
            player.sendMessage("✅ ZoneScript saved to: " + scriptFile.getAbsolutePath());
            return true;
        } catch (IOException e) {
            player.sendMessage("❌ Failed to save ZoneScript: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
