package mud.editor;

import java.util.Scanner;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import mud.core.*;
import mud.config.Config;

public class ObjectEditor implements Editor {
	
	private final ObjectItem object;
    private final Scanner scanner = new Scanner(System.in);
    
    public ObjectEditor(ObjectItem object) {
        this.object = object;
    }
    

    public void launchEditor() {
        System.out.println("=== Object Editor ===");

        ObjectItem obj = new ObjectItem();

        System.out.print("Enter object name: ");
        obj.setName(scanner.nextLine().trim());

        System.out.print("Short description: ");
        obj.setShortDescription(scanner.nextLine().trim());

        System.out.print("Long description: ");
        obj.setLongDescription(scanner.nextLine().trim());

        System.out.print("Extended (look) description: ");
        obj.setExtDescription(scanner.nextLine().trim());

        System.out.print("Object type: ");
        obj.setType(ObjectType.valueOf(scanner.nextLine().trim().toUpperCase()));

        if (obj.getType() == ObjectType.WEAPON) {
            System.out.print("Weapon type: ");
            obj.setWeaponType(WeaponType.valueOf(scanner.nextLine().trim().toUpperCase()));

            System.out.print("Damage type: ");
            obj.setDamageType(WeaponDamageType.valueOf(scanner.nextLine().trim().toUpperCase()));

            System.out.print("Enter damage dice (e.g. 2d6): ");
            String[] parts = scanner.nextLine().trim().split("d");
            obj.setDiceCount(Integer.parseInt(parts[0]));
            obj.setDiceSides(Integer.parseInt(parts[1]));

            obj.setFlatDamage(promptInt("Flat damage override (-1 for none)"));
            obj.setVampiricPercent(promptInt("Vampiric percent (0 for none)"));
            obj.setVorpal(promptBool("Vorpal?"));
            obj.setPoisoned(promptBool("Poisoned?"));
        }

        if (obj.getType() == ObjectType.ARMOR) {
            System.out.print("Armor type: ");
            obj.setArmorType(ArmorType.valueOf(scanner.nextLine().trim().toUpperCase()));

            System.out.print("Equip slot: ");
            obj.setEquipSlot(EquipSlot.valueOf(scanner.nextLine().trim().toUpperCase()));
        }

        System.out.println("== Stat Bonuses ==");
        obj.setStrengthBonus(promptInt("Strength bonus"));
        obj.setStaminaBonus(promptInt("Stamina bonus"));
        obj.setIntellectBonus(promptInt("Intellect bonus"));
        obj.setAgilityBonus(promptInt("Agility bonus"));
        obj.setHitrollBonus(promptInt("Hitroll bonus"));
        obj.setDamrollBonus(promptInt("Damroll bonus"));
        obj.setHpBonus(promptInt("HP bonus"));
        obj.setMpBonus(promptInt("MP bonus"));

        obj.setStackable(promptBool("Is stackable?"));
        if (obj.isStackable()) {
            obj.setStackSize(promptInt("Stack size"));
            obj.setMaxStackSize(promptInt("Max stack size"));
        }

        obj.setIntelligent(promptBool("Is intelligent?"));
        obj.setCharges(promptInt("Current charges"));
        obj.setMaxCharges(promptInt("Max charges"));
        obj.setDurability(promptInt("Durability"));
        obj.setMaxDurability(promptInt("Max durability"));

        System.out.println("== Value ==");
        obj.setValueCopper(promptInt("Value in copper"));
        obj.setValueSilver(promptInt("Value in silver"));
        obj.setValueGold(promptInt("Value in gold"));
        obj.setValuePlatinum(promptInt("Value in platinum"));

        // Keywords
        obj.getKeywords().add(obj.getName().toLowerCase());
        System.out.print("Add extra keywords (comma-separated): ");
        String extra = scanner.nextLine().trim();
        if (!extra.isEmpty()) {
            for (String k : extra.split(",")) {
                obj.getKeywords().add(k.trim().toLowerCase());
            }
        }

        // Save using Gson
        try {
            File dir = new File(Config.OBJECTS_DIR);
            dir.mkdirs();

            String filename = obj.getName().toLowerCase().replaceAll("\\s+", "_") + ".json";
            File file = new File(dir, filename);

            Gson gson = new GsonBuilder()
                    .setPrettyPrinting()
                    .excludeFieldsWithoutExposeAnnotation() // Optional if you're using @Expose
                    .create();

            try (FileWriter writer = new FileWriter(file)) {
                gson.toJson(obj, writer);
            }

            System.out.println("✅ Saved object to: " + file.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Failed to save object.");
        }
    } // end launchEditor


    private int promptInt(String label) {
        System.out.print(label + ": ");
        return Integer.parseInt(scanner.nextLine().trim());
    }

    private boolean promptBool(String label) {
        System.out.print(label + " (true/false): ");
        return Boolean.parseBoolean(scanner.nextLine().trim());
    }

    public void startEditing() {
        System.out.println("Editing object: " + object.getName());
    }

	@Override
	public void handleInput(String input) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showMenu() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public boolean save() {
	    try {
	        File objectFile = new File(Config.OBJECTS_DIR, object.getObjID() + ".json");

	        Gson gson = new GsonBuilder()
	                .setPrettyPrinting()
	                .excludeFieldsWithoutExposeAnnotation() // optional, if using @Expose annotations
	                .create();

	        try (FileWriter writer = new FileWriter(objectFile)) {
	            gson.toJson(object, writer);
	        }

	        System.out.println("✅ Object saved: " + objectFile.getName());
	        return true;
	    } catch (IOException e) {
	        System.err.println("❌ Failed to save ObjectItem: " + object.getObjID());
	        e.printStackTrace();
	        return false;
	    }
	}

	@Override
	public String getEditorName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void stopEditing() {
		// TODO Auto-generated method stub
		
	}
} // end ObjectEditor
