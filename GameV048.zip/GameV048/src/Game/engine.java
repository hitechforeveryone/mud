package Game;

//imports
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;


public class engine {

	private static final String gameDesigner = "Jan Ouellette";
	private static final String gameVersion = "0.4.8";
	private static final String gameDedication = "Jon Prue, a true friend and inspiration. The man who introduced me to Empire and Imperium MUDs.  I started writing this game as we could not easily play together when he was in China.  Sadly he passed away before I was able to get a demo out to him.  He was a very well travelled man and expierenced many things in his life. He suffered silently, but if he had just reached out to us, we would have given him all the love and attention he needed.  You will be missed my friend.";


	// source files
	static String worldPath = "src/Game/world.txt";
	static String zonescriptPath = "src/Game/zonescipts.txt";  // new WIP
	static String mobPath = "src/Game/mobs.txt";
	static String objPath = "src/Game/objects.txt";
	static String charLoginPath = "src/Game/adminlogin.txt";
	static String charPath = "src/Game/characters.txt";
	static String pinvPath = "src/Game/pinventory.txt";
	static String minvPath = "src/Game/minventory.txt";

	static FileReader reader = null;

	// source arrays
	static String[] currentRoom = new String[50];
	static String[][] World = new String[10000][50];
	static String[][] Objects = new String[10000][100]; // default 10000 objects, up to 50 args per object
	static String[][] Mobs = new String[10000][50]; //default 10000 mobs, up to 50 args per mob
	static String[][] Chars = new String[10000][50];
	static String[][] charsFile = new String[10000][50];
	static String[][] pInventory = new String[10000][50];
	static String[][] mInventory = new String[10000][50];
	static String[][] Zscripts = new String[100000][50];


	static engine executingTask = new engine(); // the task that runs everthing, AKA the world!

	// zones for the world
	static zone currentZone = new zone();
	static zone previousZone = new zone();
	static zone nextZone1 = new zone();
	static zone nextZone2 = new zone();
	static zone nextZone3 = new zone();
	static zone nextZone4 = new zone();
	static zone nextZone5 = new zone();
	static zone nextZone6 = new zone();
	static zone nextZone7 = new zone();
	static zone nextZone8 = new zone();
	static zone nextZone9 = new zone();
	static zone nextZone10 = new zone();
	static zone editingZone = new zone();

	static room newRoom = new room();
	static room newRoom2 = new room();
	static String[][] mobsInRoom = new String[10000][6];
	String[] currentMob = new String[50];
	String[][] objInRoom = new String[10000][6];
	static Scanner keyboard = new Scanner(System.in);
	static String kinput = null;
	static Scanner input = new Scanner(System.in);
	static String tline = null;

	static String record = null;
	static String editor = "null";
	static player player1 = new player();
	static inventory playerinventory = new inventory();
	static inventory editingMobInventory = new inventory();
	static inventory mob0inventory = new inventory();
	static inventory mob1inventory = new inventory();
	static inventory mob2inventory = new inventory();
	static inventory mob3inventory = new inventory();
	static inventory mob4inventory = new inventory();
	static inventory mob5inventory = new inventory();
	static int inCombat = 0;

	static room exN = new room();
	static room exNE = new room();
	static room exE = new room();
	static room exSE = new room();
	static room exS = new room();
	static room exSW = new room();
	static room exW = new room();
	static room exNW = new room();
	static room exU = new room();
	static room exD = new room();


	static String tobjsar;
	static String[] tobjsarr = new String[6]; //= tobjsar.split("\\s+");
	static Object[] tmobsarr= new String[6];
	// room objects
	static objects tobj0 = new objects();
	static objects tobj1 = new objects();
	static objects tobj2 = new objects();
	static objects tobj3 = new objects();
	static objects tobj4 = new objects();
	static objects tobj5 = new objects();
	// player equipment objects
	static objects phelm = new objects();
	static objects pneck = new objects();
	static objects pshoulders = new objects();
	static objects pchest = new objects();
	static objects pwrist = new objects();
	static objects phands = new objects();
	static objects pfinger1 = new objects();
	static objects pfinger2 = new objects();
	static objects pwaist = new objects();
	static objects pleg = new objects();
	static objects pfoot = new objects();
	static objects ptrinket1 = new objects();
	static objects ptrinket2 = new objects();
	static objects pweapon1 = new objects();
	static objects pweapshi = new objects();
	static objects tempObj = new objects();
	static objects tempObj2 = new objects();
	static objects editingObject = new objects();
	static objects lookObject = new objects();
	static objects invObj = new objects();
	static int invNum = 0;
	static int tminvNum = 0;
	static String inv = "";
	static String inv2 = "";
	static String invSlot = "";
	static String mSlot = "";

	static int humanStartRm = 1; // human starting room
	static int elfStartRm = 1; // elf starting room
	static int halfelfStartRm = 2; // half elf starting room
	static int dwarfStartRm = 3; // dwarf starting room

	static objects mhelm = new objects();
	static objects mneck = new objects();
	static objects mshoulders = new objects();
	static objects mchest = new objects();
	static objects mwrist = new objects();
	static objects mhands = new objects();
	static objects mfinger1 = new objects();
	static objects mfinger2 = new objects();
	static objects mwaist = new objects();
	static objects mleg = new objects();
	static objects mfoot = new objects();
	static objects mtrinket1 = new objects();
	static objects mtrinket2 = new objects();
	static objects mweapon1 = new objects();
	static objects mweapshi = new objects();

	// player inventory
	static objects pinv0 = new objects();
	static objects pinv1 = new objects();
	static objects pinv2 = new objects();
	static objects pinv3 = new objects();
	static objects pinv4 = new objects();
	static objects pinv5 = new objects();
	static objects pinv6 = new objects();
	static objects pinv7 = new objects();
	static objects pinv8 = new objects();
	static objects pinv9 = new objects();
	static objects pinv10 = new objects();
	static objects pinv11 = new objects();
	static objects pinv12 = new objects();
	static objects pinv13 = new objects();
	static objects pinv14 = new objects();
	static objects pinv15 = new objects();
	static objects pinv16 = new objects();
	static objects pinv17 = new objects();
	static objects pinv18 = new objects();
	static objects pinv19 = new objects();
	static objects pinv20 = new objects();
	static objects pinv21 = new objects();
	static objects pinv22 = new objects();
	static objects pinv23 = new objects();
	static objects pinv24 = new objects();
	static objects pinv25 = new objects();
	static objects pinv26 = new objects();
	static objects pinv27 = new objects();
	static objects pinv28 = new objects();
	static objects pinv29 = new objects();
	static objects swapObj = new objects();

	static objects em0inv0 = new objects();
	static objects em0inv1 = new objects();
	static objects em0inv2 = new objects();
	static objects em0inv3 = new objects();
	static objects em0inv4 = new objects();
	static objects em0inv5 = new objects();
	static objects em0inv6 = new objects();
	static objects em0inv7 = new objects();
	static objects em0inv8 = new objects();
	static objects em0inv9 = new objects();
	static objects em0inv10 = new objects();
	static objects em0inv11 = new objects();
	static objects em0inv12 = new objects();
	static objects em0inv13 = new objects();
	static objects em0inv14 = new objects();
	static objects em0inv15 = new objects();
	static objects em0inv16 = new objects();
	static objects em0inv17 = new objects();
	static objects em0inv18 = new objects();
	static objects em0inv19 = new objects();
	static objects em0inv20 = new objects();
	static objects em0inv21 = new objects();
	static objects em0inv22 = new objects();
	static objects em0inv23 = new objects();
	static objects em0inv24 = new objects();
	static objects em0inv25 = new objects();
	static objects em0inv26 = new objects();
	static objects em0inv27 = new objects();
	static objects em0inv28 = new objects();
	static objects em0inv29 = new objects();
	// mob in-room inventory
	static objects m0inv0 = new objects();
	static objects m0inv1 = new objects();
	static objects m0inv2 = new objects();
	static objects m0inv3 = new objects();
	static objects m0inv4 = new objects();
	static objects m0inv5 = new objects();
	static objects m0inv6 = new objects();
	static objects m0inv7 = new objects();
	static objects m0inv8 = new objects();
	static objects m0inv9 = new objects();
	static objects m0inv10 = new objects();
	static objects m0inv11 = new objects();
	static objects m0inv12 = new objects();
	static objects m0inv13 = new objects();
	static objects m0inv14 = new objects();
	static objects m0inv15 = new objects();
	static objects m0inv16 = new objects();
	static objects m0inv17 = new objects();
	static objects m0inv18 = new objects();
	static objects m0inv19 = new objects();
	static objects m0inv20 = new objects();
	static objects m0inv21 = new objects();
	static objects m0inv22 = new objects();
	static objects m0inv23 = new objects();
	static objects m0inv24 = new objects();
	static objects m0inv25 = new objects();
	static objects m0inv26 = new objects();
	static objects m0inv27 = new objects();
	static objects m0inv28 = new objects();
	static objects m0inv29 = new objects();
	static objects m1inv0 = new objects();
	static objects m1inv1 = new objects();
	static objects m1inv2 = new objects();
	static objects m1inv3 = new objects();
	static objects m1inv4 = new objects();
	static objects m1inv5 = new objects();
	static objects m1inv6 = new objects();
	static objects m1inv7 = new objects();
	static objects m1inv8 = new objects();
	static objects m1inv9 = new objects();
	static objects m1inv10 = new objects();
	static objects m1inv11 = new objects();
	static objects m1inv12 = new objects();
	static objects m1inv13 = new objects();
	static objects m1inv14 = new objects();
	static objects m1inv15 = new objects();
	static objects m1inv16 = new objects();
	static objects m1inv17 = new objects();
	static objects m1inv18 = new objects();
	static objects m1inv19 = new objects();
	static objects m1inv20 = new objects();
	static objects m1inv21 = new objects();
	static objects m1inv22 = new objects();
	static objects m1inv23 = new objects();
	static objects m1inv24 = new objects();
	static objects m1inv25 = new objects();
	static objects m1inv26 = new objects();
	static objects m1inv27 = new objects();
	static objects m1inv28 = new objects();
	static objects m1inv29 = new objects();
	static objects m2inv0 = new objects();
	static objects m2inv1 = new objects();
	static objects m2inv2 = new objects();
	static objects m2inv3 = new objects();
	static objects m2inv4 = new objects();
	static objects m2inv5 = new objects();
	static objects m2inv6 = new objects();
	static objects m2inv7 = new objects();
	static objects m2inv8 = new objects();
	static objects m2inv9 = new objects();
	static objects m2inv10 = new objects();
	static objects m2inv11 = new objects();
	static objects m2inv12 = new objects();
	static objects m2inv13 = new objects();
	static objects m2inv14 = new objects();
	static objects m2inv15 = new objects();
	static objects m2inv16 = new objects();
	static objects m2inv17 = new objects();
	static objects m2inv18 = new objects();
	static objects m2inv19 = new objects();
	static objects m2inv20 = new objects();
	static objects m2inv21 = new objects();
	static objects m2inv22 = new objects();
	static objects m2inv23 = new objects();
	static objects m2inv24 = new objects();
	static objects m2inv25 = new objects();
	static objects m2inv26 = new objects();
	static objects m2inv27 = new objects();
	static objects m2inv28 = new objects();
	static objects m2inv29 = new objects();
	static objects m3inv0 = new objects();
	static objects m3inv1 = new objects();
	static objects m3inv2 = new objects();
	static objects m3inv3 = new objects();
	static objects m3inv4 = new objects();
	static objects m3inv5 = new objects();
	static objects m3inv6 = new objects();
	static objects m3inv7 = new objects();
	static objects m3inv8 = new objects();
	static objects m3inv9 = new objects();
	static objects m3inv10 = new objects();
	static objects m3inv11 = new objects();
	static objects m3inv12 = new objects();
	static objects m3inv13 = new objects();
	static objects m3inv14 = new objects();
	static objects m3inv15 = new objects();
	static objects m3inv16 = new objects();
	static objects m3inv17 = new objects();
	static objects m3inv18 = new objects();
	static objects m3inv19 = new objects();
	static objects m3inv20 = new objects();
	static objects m3inv21 = new objects();
	static objects m3inv22 = new objects();
	static objects m3inv23 = new objects();
	static objects m3inv24 = new objects();
	static objects m3inv25 = new objects();
	static objects m3inv26 = new objects();
	static objects m3inv27 = new objects();
	static objects m3inv28 = new objects();
	static objects m3inv29 = new objects();
	static objects m4inv0 = new objects();
	static objects m4inv1 = new objects();
	static objects m4inv2 = new objects();
	static objects m4inv3 = new objects();
	static objects m4inv4 = new objects();
	static objects m4inv5 = new objects();
	static objects m4inv6 = new objects();
	static objects m4inv7 = new objects();
	static objects m4inv8 = new objects();
	static objects m4inv9 = new objects();
	static objects m4inv10 = new objects();
	static objects m4inv11 = new objects();
	static objects m4inv12 = new objects();
	static objects m4inv13 = new objects();
	static objects m4inv14 = new objects();
	static objects m4inv15 = new objects();
	static objects m4inv16 = new objects();
	static objects m4inv17 = new objects();
	static objects m4inv18 = new objects();
	static objects m4inv19 = new objects();
	static objects m4inv20 = new objects();
	static objects m4inv21 = new objects();
	static objects m4inv22 = new objects();
	static objects m4inv23 = new objects();
	static objects m4inv24 = new objects();
	static objects m4inv25 = new objects();
	static objects m4inv26 = new objects();
	static objects m4inv27 = new objects();
	static objects m4inv28 = new objects();
	static objects m4inv29 = new objects();
	static objects m5inv0 = new objects();
	static objects m5inv1 = new objects();
	static objects m5inv2 = new objects();
	static objects m5inv3 = new objects();
	static objects m5inv4 = new objects();
	static objects m5inv5 = new objects();
	static objects m5inv6 = new objects();
	static objects m5inv7 = new objects();
	static objects m5inv8 = new objects();
	static objects m5inv9 = new objects();
	static objects m5inv10 = new objects();
	static objects m5inv11 = new objects();
	static objects m5inv12 = new objects();
	static objects m5inv13 = new objects();
	static objects m5inv14 = new objects();
	static objects m5inv15 = new objects();
	static objects m5inv16 = new objects();
	static objects m5inv17 = new objects();
	static objects m5inv18 = new objects();
	static objects m5inv19 = new objects();
	static objects m5inv20 = new objects();
	static objects m5inv21 = new objects();
	static objects m5inv22 = new objects();
	static objects m5inv23 = new objects();
	static objects m5inv24 = new objects();
	static objects m5inv25 = new objects();
	static objects m5inv26 = new objects();
	static objects m5inv27 = new objects();
	static objects m5inv28 = new objects();
	static objects m5inv29 = new objects();
	// xp values to reach each level
	// xp to lvl = 1000*(1.5)^(level-1)
	static int xplvl1 = 0;
	static int xplvl2 = 1000;
	static int xplvl3 = 1500;
	static int xplvl4 = 2250;
	static int xplvl5 = 3375;
	static int xplvl6 = 5063;
	static int xplvl7 = 7594;
	static int xplvl8 = 11391;
	static int xplvl9 = 17087;
	static int xplvl10 = 25630;
	static int xplvl11 = 25630;
	static int xplvl12 = 38445;
	static int xplvl13 = 57667;
	static int xplvl14 = 86501;
	static int xplvl15 = 129751;
	static int xplvl16 = 194626;
	static int xplvl17 = 291939;
	static int xplvl18 = 437904;
	static int xplvl19 = 656863;
	static int xplvl20 = 985294;
	static int xplvl21 = 1477941;
	static int xplvl22 = 2216911;
	static int xplvl23 = 3325367;
	static int xplvl24 = 4988051;
	static int xplvl25 = 7482076;
	static int xplvl26 = 11223114;
	static int xplvl27 = 16834701;
	static int xplvl28 = 25252006;
	static int xplvl29 = 37878009;
	static int xplvl30 = 56817013;
	static int xplvl31 = 999999999;

	static room curRoom =new room();
	static room rm00 = new room(); // should be 2 digits, this is separate from the room's ID number
	static room rm01 = new room();
	static room rm02 = new room();
	static room rm03 = new room();
	static room rm04 = new room();
	static room rm05 = new room();
	static room rm06 = new room();
	static room rm07 = new room();
	static room rm08 = new room();
	static room rm09 = new room();

	static room rm10 = new room();
	static room rm11 = new room();
	static room rm12 = new room();
	static room rm13 = new room();
	static room rm14 = new room();
	static room rm15 = new room();
	static room rm16 = new room();
	static room rm17 = new room();
	static room rm18 = new room();
	static room rm19 = new room();

	static room rm20 = new room();
	static room rm21 = new room();
	static room rm22 = new room();
	static room rm23 = new room();
	static room rm24 = new room();
	static room rm25 = new room();
	static room rm26 = new room();
	static room rm27 = new room();
	static room rm28 = new room();
	static room rm29 = new room();

	static room rm30 = new room();
	static room rm31 = new room();
	static room rm32 = new room();
	static room rm33 = new room();
	static room rm34 = new room();
	static room rm35 = new room();
	static room rm36 = new room();
	static room rm37 = new room();
	static room rm38 = new room();
	static room rm39 = new room();

	static room rm40 = new room();
	static room rm41 = new room();
	static room rm42 = new room();
	static room rm43 = new room();
	static room rm44 = new room();
	static room rm45 = new room();
	static room rm46 = new room();
	static room rm47 = new room();
	static room rm48 = new room();
	static room rm49 = new room();

	static room rm50 = new room();
	static room rm51 = new room();
	static room rm52 = new room();
	static room rm53 = new room();
	static room rm54 = new room();
	static room rm55 = new room();
	static room rm56 = new room();
	static room rm57 = new room();
	static room rm58 = new room();
	static room rm59 = new room();

	static room rm60 = new room();
	static room rm61 = new room();
	static room rm62 = new room();
	static room rm63 = new room();
	static room rm64 = new room();
	static room rm65 = new room();
	static room rm66 = new room();
	static room rm67 = new room();
	static room rm68 = new room();
	static room rm69 = new room();

	static room rm70 = new room();
	static room rm71 = new room();
	static room rm72 = new room();
	static room rm73 = new room();
	static room rm74 = new room();
	static room rm75 = new room();
	static room rm76 = new room();
	static room rm77 = new room();
	static room rm78 = new room();
	static room rm79 = new room();

	static room rm80 = new room();
	static room rm81 = new room();
	static room rm82 = new room();
	static room rm83 = new room();
	static room rm84 = new room();
	static room rm85 = new room();
	static room rm86 = new room();
	static room rm87 = new room();
	static room rm88 = new room();
	static room rm89 = new room();

	static room rm90 = new room();
	static room rm91 = new room();
	static room rm92 = new room();
	static room rm93 = new room();
	static room rm94 = new room();
	static room rm95 = new room();
	static room rm96 = new room();
	static room rm97 = new room();
	static room rm98 = new room();
	static room rm99 = new room();


	static mob tmob0 = new mob();
	static mob tmob1 = new mob();
	static mob tmob2 = new mob();
	static mob tmob3 = new mob();
	static mob tmob4 = new mob();
	static mob tmob5 = new mob();
	static mob tmob6 = new mob();
	static mob tmob7 = new mob();
	static mob tmob8 = new mob();
	static mob tmob9 = new mob();
	static mob tmob10 = new mob();
	static mob tmob11 = new mob();
	static mob tmob12 = new mob();
	static mob tmob13 = new mob();
	static mob tmob14 = new mob();
	static mob tmob15 = new mob();
	static mob tmob16 = new mob();
	static mob tmob17 = new mob();
	static mob tmob18 = new mob();
	static mob tmob19 = new mob();
	static mob tmob20 = new mob();
	static mob tmob21 = new mob();
	static mob tmob22 = new mob();
	static mob tmob23 = new mob();
	static mob tmob24 = new mob();
	static mob tmob25 = new mob();
	static mob tmob26 = new mob();
	static mob tmob27 = new mob();
	static mob tmob28 = new mob();
	static mob tmob29 = new mob();

	static mob tmob30 = new mob();
	static mob tmob31 = new mob();
	static mob tmob32 = new mob();
	static mob tmob33 = new mob();
	static mob tmob34 = new mob();
	static mob tmob35 = new mob();
	static mob tmob36 = new mob();
	static mob tmob37 = new mob();
	static mob tmob38 = new mob();
	static mob tmob39 = new mob();
	static mob tmob40 = new mob();
	static mob tmob41 = new mob();
	static mob tmob42 = new mob();
	static mob tmob43 = new mob();
	static mob tmob44 = new mob();
	static mob tmob45 = new mob();
	static mob tmob46 = new mob();
	static mob tmob47 = new mob();
	static mob tmob48 = new mob();
	static mob tmob49 = new mob();
	static mob editingMob = new mob();

	// tallies of rooms, chars, mobs, objs, player and mob inventories
	static int nextAvailRoom = 0;
	static int nextAvailChar = 0;
	static int nextAvailMob = 0;
	static int nextAvailObj = 0;
	static int nextAvailInv = 0;
	static int nextAvailmInv = 0;
	static int nextAvailZone = 0;

	static int curRmNum = 0;
	static int curZNum = currentZone.getZoneNum();

	// timers for sun, moons and weather
	int sundelaytime = 30; //  set for halfday in seconds (1/2 day)
	static int inoutside;
	long sundelay = sundelaytime * 1000; // get from milliseconds to seconds
	long moon1delay = sundelaytime * 1000;
	long moon2delay = sundelaytime * 1000; // double speed!
	long moon3delay = sundelaytime * 1000; //
	long rainyweather = sundelaytime * 2000; // 1 game day

	long roomstat = sundelaytime;
	SunTask task = new SunTask();
	Moon1Task task1 = new Moon1Task();
	Moon2Task task2 = new Moon2Task();
	Moon3Task task3 = new Moon3Task();

	RainyWeather3 task4 = new RainyWeather3(); // 4 climates

	Timer suntimer = new Timer("Sunrise");
	Timer moontimer1 = new Timer("Moon1rise");
	Timer moontimer2 = new Timer("Moon2rise");
	Timer moontimer3 = new Timer("Moon3rise");
	Timer raintimer = new Timer ("Rainy Weather");

	Timer roomStatCheck = new Timer("Checking the Indoor/Outdoor status");
	static int year = 345734;
	static int monthofYear = 0;
	static int weekofMonth = 0;
	static int dayofWeek = 0;
	static String weekDay = "Primeday";
	static String month = "Frostmere";
	static String week = "Dawnweek";
	static int daynum = 0; // days since start
	// 5 days (0-4) x 6 (0-5) weeks per 30 day month per 12 (0-11) month year (360 days)
	static int daytime = 0; // day status. 2 cycle
	static int moontime1 = 0; // moon 1 status, 6 status cycle
	static int moontime2 = 0; // moon 2 status, 2 status, 2x speed
	static int moontime3 = 0; // 
	static int raintime = 0; // rain status, 2 cycle

	static int hpRegenPer = 2;
	static int manaRegenPer = 2;
	// suns, moons and weather status's
	static String sunstatus = "visible";
	static String moon1status = "visible";
	static String moon2status = "visible";
	static String moon3status = "visible";
	static String weatherstatus = "clear";

	static long startTime = System.nanoTime();

	static ArrayList<String> Chars2 = new ArrayList<>(10);
	static volatile String input2 = "";
	static int t1=0;
	static int t2=0;
	static int regenCast = 0;
	static int regrowthCast = 0;
	static int rejuvCast = 0;

	static String one = "1";
	static String two = "2";
	static String three = "3";
	static String four = "4";
	static String five = "5";
	static String six = "6";




	///////////////////////////
	/// START MAIN ////////////
	///////////////////////////
	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception
	{
		System.out.println("testing the game engine");
		System.out.println("Initializing");
		System.out.println(".");
		System.out.println("..");
		System.out.println("...");
		System.out.println("....");

		ArrayList<String> Mobs2 = new ArrayList<>(100000);
		ArrayList<String> Objects2 = new ArrayList<>(100000);
		ArrayList<String> Chars2 = new ArrayList<>(100000);
		ArrayList<String> World2  = new ArrayList<>(100000);
		ArrayList<String> Zone2 = new ArrayList<>(100000);

		int troomNum = 0;
		int tmobNum = 0;
		int tobjNum = 0;
		int tcharNum = 0;
		int tloginNum = 0;
		int tinvNum = 0;
		int tminvNum = 0;
		int tzoneNum = 0;



		// testing something, disable file readin
		loadWorldFromArray();


		// start import of World File
		try {
			reader = new FileReader(worldPath);
			if (worldPath.length() == 0) {
				String worldPat = worldPath.toString();
				File newFile = new File(worldPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		BufferedReader breader = new BufferedReader(reader);
		Scanner scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			String[] worldSplit = new String[100];
			worldSplit=scannerData.split("|");
			int wRmNumInArr = Integer.parseInt(worldSplit[0]);
			World2.add(scannerData); // add line to our arraylist

			String[] tworld = new String[100];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tworld = tline.split("\\|");
			World[wRmNumInArr][0] = tworld[0];
			World[troomNum][1] = tworld[1];
			World[troomNum][2] = tworld[2];
			World[troomNum][3] = tworld[3];
			World[troomNum][4] = tworld[4];
			World[troomNum][5] = tworld[5];
			World[troomNum][6] = tworld[6];
			World[troomNum][7] = tworld[7];
			World[troomNum][8] = tworld[8];
			World[troomNum][9] = tworld[9];
			World[troomNum][10] = tworld[10];
			World[troomNum][11] = tworld[11];
			World[troomNum][12] = tworld[12];
			World[troomNum][13] = tworld[13];
			World[troomNum][14] = tworld[14];
			World[troomNum][15] = tworld[15];
			World[troomNum][16] = tworld[16];
			World[troomNum][17] = tworld[17];
			World[troomNum][18] = tworld[18];
			World[troomNum][19] = tworld[19];
			World[troomNum][20] = tworld[20];
			World[troomNum][21] = tworld[21];
			World[troomNum][22] = tworld[22];
			World[troomNum][23] = tworld[23];
			World[troomNum][24] = tworld[24];
			World[troomNum][25] = tworld[25];
			World[troomNum][26] = tworld[26];
			World[troomNum][27] = tworld[27];
			World[troomNum][28] = tworld[28];
			World[troomNum][29] = tworld[29];
			World[troomNum][30] = tworld[30];
			World[troomNum][31] = tworld[31];
			World[troomNum][32] = tworld[32];
			World[troomNum][33] = tworld[33];
			World[troomNum][34] = tworld[34];
			World[troomNum][35] = tworld[35];
			World[troomNum][36] = tworld[36];
			World[troomNum][37] = tworld[37];
			World[troomNum][38] = tworld[38];
			World[troomNum][39] = tworld[39];
			World[troomNum][40] = tworld[40];
			World[troomNum][41] = tworld[41];
			World[troomNum][42] = tworld[42];
			World[troomNum][43] = tworld[43];
			World[troomNum][44] = tworld[44];
			World[troomNum][45] = tworld[45];
			World[troomNum][46] = tworld[46];
			World[troomNum][47] = tworld[47];
			World[troomNum][48] = tworld[48];
			World[troomNum][49] = tworld[49];

			troomNum++;
		}

		nextAvailRoom = troomNum;
		//	System.out.println(World[0][0]); // testing the World array
		//	System.out.println(World[0][1]); // testing the World array
		System.out.println(".");
		System.out.println("The next available room number is " + nextAvailRoom);


		// start mob file import
		try {
			reader = new FileReader(mobPath);
			if (mobPath.length() == 0) {
				String mobPat = mobPath.toString();
				File newFile = new File(mobPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Mobs2.add(scannerData); // add line to our arraylist
			String[] tmobs = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tmobs = tline.split("\\|");
			Mobs[tmobNum][0] = tmobs[0];
			Mobs[tmobNum][1] = tmobs[1];
			Mobs[tmobNum][2] = tmobs[2];
			Mobs[tmobNum][3] = tmobs[3];
			Mobs[tmobNum][4] = tmobs[4];
			Mobs[tmobNum][5] = tmobs[5];
			Mobs[tmobNum][6] = tmobs[6];
			Mobs[tmobNum][7] = tmobs[7];
			Mobs[tmobNum][8] = tmobs[8];
			Mobs[tmobNum][9] = tmobs[9];
			Mobs[tmobNum][10] = tmobs[10];
			Mobs[tmobNum][11] = tmobs[11];
			Mobs[tmobNum][12] = tmobs[12];
			Mobs[tmobNum][13] = tmobs[13];
			Mobs[tmobNum][14] = tmobs[14];
			Mobs[tmobNum][15] = tmobs[15];
			Mobs[tmobNum][16] = tmobs[16];
			Mobs[tmobNum][17] = tmobs[17];
			Mobs[tmobNum][18] = tmobs[18];
			Mobs[tmobNum][19] = tmobs[19];
			Mobs[tmobNum][20] = tmobs[20];
			Mobs[tmobNum][21] = tmobs[21];
			Mobs[tmobNum][22] = tmobs[22];
			Mobs[tmobNum][23] = tmobs[23];
			Mobs[tmobNum][24] = tmobs[24];
			Mobs[tmobNum][25] = tmobs[25];
			Mobs[tmobNum][26] = tmobs[26];
			Mobs[tmobNum][27] = tmobs[27];
			Mobs[tmobNum][28] = tmobs[28];
			Mobs[tmobNum][29] = tmobs[29];
			Mobs[tmobNum][30] = tmobs[30];
			Mobs[tmobNum][31] = tmobs[31];
			Mobs[tmobNum][32] = tmobs[32];
			Mobs[tmobNum][33] = tmobs[33];
			Mobs[tmobNum][34] = tmobs[34];
			Mobs[tmobNum][35] = tmobs[35];
			Mobs[tmobNum][36] = tmobs[36];
			Mobs[tmobNum][37] = tmobs[37];
			Mobs[tmobNum][38] = tmobs[38];
			Mobs[tmobNum][39] = tmobs[39];
			Mobs[tmobNum][40] = tmobs[40];
			Mobs[tmobNum][41] = tmobs[41];
			Mobs[tmobNum][42] = tmobs[42];
			Mobs[tmobNum][43] = tmobs[43];
			Mobs[tmobNum][44] = tmobs[44];
			Mobs[tmobNum][45] = tmobs[45];
			Mobs[tmobNum][46] = tmobs[46];
			Mobs[tmobNum][47] = tmobs[47];
			Mobs[tmobNum][48] = tmobs[48];
			Mobs[tmobNum][49] = tmobs[49];

			tmobNum++;
		}

		nextAvailMob = tmobNum;
		//		System.out.println(Mobs[0][0]); // testing the Mobs array
		//		System.out.println(Mobs[0][1]); // testing the Mobs array
		System.out.println("..");
		System.out.println("The next available mob number is " + nextAvailMob);


		// start object file import
		try {
			reader = new FileReader(objPath);
			if (objPath.length() == 0) {
				String mobPat = objPath.toString();
				File newFile = new File(mobPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Objects2.add(scannerData); // add line to our arraylist
			String[] tobjs = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tobjs = tline.split("\\|");
			Objects[tobjNum][0] = tobjs[0];
			Objects[tobjNum][1] = tobjs[1];
			Objects[tobjNum][2] = tobjs[2];
			Objects[tobjNum][3] = tobjs[3];
			Objects[tobjNum][4] = tobjs[4];
			Objects[tobjNum][5] = tobjs[5];
			Objects[tobjNum][6] = tobjs[6];
			Objects[tobjNum][7] = tobjs[7];
			Objects[tobjNum][8] = tobjs[8];
			Objects[tobjNum][9] = tobjs[9];
			Objects[tobjNum][10] = tobjs[10];
			Objects[tobjNum][11] = tobjs[11];
			Objects[tobjNum][12] = tobjs[12];
			Objects[tobjNum][13] = tobjs[13];
			Objects[tobjNum][14] = tobjs[14];
			Objects[tobjNum][15] = tobjs[15];
			Objects[tobjNum][16] = tobjs[16];
			Objects[tobjNum][17] = tobjs[17];
			Objects[tobjNum][18] = tobjs[18];
			Objects[tobjNum][19] = tobjs[19];
			Objects[tobjNum][20] = tobjs[20];
			Objects[tobjNum][21] = tobjs[21];
			Objects[tobjNum][22] = tobjs[22];
			Objects[tobjNum][23] = tobjs[23];
			Objects[tobjNum][24] = tobjs[24];
			Objects[tobjNum][25] = tobjs[25];
			Objects[tobjNum][26] = tobjs[26];
			Objects[tobjNum][27] = tobjs[27];
			Objects[tobjNum][28] = tobjs[28];
			Objects[tobjNum][29] = tobjs[29];
			Objects[tobjNum][30] = tobjs[30];
			Objects[tobjNum][31] = tobjs[31];
			Objects[tobjNum][32] = tobjs[32];
			Objects[tobjNum][33] = tobjs[33];
			Objects[tobjNum][34] = tobjs[34];
			Objects[tobjNum][35] = tobjs[35];
			Objects[tobjNum][36] = tobjs[36];
			Objects[tobjNum][37] = tobjs[37];
			Objects[tobjNum][38] = tobjs[38];
			Objects[tobjNum][39] = tobjs[39];
			Objects[tobjNum][40] = tobjs[40];
			Objects[tobjNum][41] = tobjs[41];
			Objects[tobjNum][42] = tobjs[42];
			Objects[tobjNum][43] = tobjs[43];
			Objects[tobjNum][44] = tobjs[44];
			Objects[tobjNum][45] = tobjs[45];
			Objects[tobjNum][46] = tobjs[46];
			Objects[tobjNum][47] = tobjs[47];
			Objects[tobjNum][48] = tobjs[48];
			Objects[tobjNum][49] = tobjs[49];

			tobjNum++;
		}

		nextAvailObj = tobjNum;
		//		System.out.println(Objects[0][0]); // testing the Objests array
		//		System.out.println(Objects[0][1]); // testing the Objects array
		System.out.println("...");
		System.out.println("The next available object number is " + nextAvailObj);

		// start import of character file
		try {
			reader = new FileReader(charPath);
			if (charPath.length() == 0) {
				String charPat = charPath.toString();
				File newFile = new File(charPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Chars2.add(scannerData); // add line to our arraylist
			String[] tchars = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tchars = tline.split("\\|");
			Chars[tcharNum][0] = tchars[0];
			Chars[tcharNum][1] = tchars[1];
			Chars[tcharNum][2] = tchars[2];
			Chars[tcharNum][3] = tchars[3];
			Chars[tcharNum][4] = tchars[4];
			Chars[tcharNum][5] = tchars[5];
			Chars[tcharNum][6] = tchars[6];
			Chars[tcharNum][7] = tchars[7];
			Chars[tcharNum][8] = tchars[8];
			Chars[tcharNum][9] = tchars[9];
			Chars[tcharNum][10] = tchars[10];
			Chars[tcharNum][11] = tchars[11];
			Chars[tcharNum][12] = tchars[12];
			Chars[tcharNum][13] = tchars[13];
			Chars[tcharNum][14] = tchars[14];
			Chars[tcharNum][15] = tchars[15];
			Chars[tcharNum][16] = tchars[16];
			Chars[tcharNum][17] = tchars[17];
			Chars[tcharNum][18] = tchars[18];
			Chars[tcharNum][19] = tchars[19];
			Chars[tcharNum][20] = tchars[20];
			Chars[tcharNum][21] = tchars[21];
			Chars[tcharNum][22] = tchars[22];
			Chars[tcharNum][23] = tchars[23];
			Chars[tcharNum][24] = tchars[24];
			Chars[tcharNum][25] = tchars[25];
			Chars[tcharNum][26] = tchars[26];
			Chars[tcharNum][27] = tchars[27];
			Chars[tcharNum][28] = tchars[28];
			Chars[tcharNum][29] = tchars[29];
			Chars[tcharNum][30] = tchars[30];
			Chars[tcharNum][31] = tchars[31];
			Chars[tcharNum][32] = tchars[32];
			Chars[tcharNum][33] = tchars[33];
			Chars[tcharNum][34] = tchars[34];
			Chars[tcharNum][35] = tchars[35];
			Chars[tcharNum][36] = tchars[36];
			Chars[tcharNum][37] = tchars[37];
			Chars[tcharNum][38] = tchars[38];
			Chars[tcharNum][39] = tchars[39];
			Chars[tcharNum][40] = tchars[40];
			Chars[tcharNum][41] = tchars[41];
			Chars[tcharNum][42] = tchars[42];
			Chars[tcharNum][43] = tchars[43];
			Chars[tcharNum][44] = tchars[44];
			Chars[tcharNum][45] = tchars[45];
			Chars[tcharNum][46] = tchars[46];
			Chars[tcharNum][47] = tchars[47];
			Chars[tcharNum][48] = tchars[48];
			Chars[tcharNum][49] = tchars[49];

			tcharNum++;
		}

		nextAvailChar = tcharNum;
		//		System.out.println(Chars[0][0]); // testing the Chars array
		//		System.out.println(Chars[0][1]); // testing the Chars array
		System.out.println("....");
		System.out.println("The next available character number is " + nextAvailChar);


		// start charLogin (adminLogin) import
		try {
			reader = new FileReader(charLoginPath);
			if (charLoginPath.length() == 0) {
				String charLoginPat = charLoginPath.toString();
				File newFile = new File(charLoginPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			System.out.println("We cannot read " + charLoginPath);
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Chars2.add(scannerData); // add line to our arraylist

			String[] tchars = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tchars = tline.split("\\|");
			charsFile[tloginNum][0] = tchars[0];
			charsFile[tloginNum][1] = tchars[1];
			charsFile[tloginNum][2] = tchars[2];
			charsFile[tloginNum][3] = tchars[3];

			//		System.out.println(charsFile[tloginNum][1] + ":" + charsFile[tloginNum][2]); // just testing the array being loaded HIDE THIS BITCH



			tloginNum++;
		}
		//		System.out.println(charsFile[0][0]); // testing the charsFile array (adminLogin)
		//		System.out.println(charsFile[0][1]); // testing the charsFile array (adminLogin)
		System.out.println("tcharNum should equal tloginNum");
		System.out.println(tcharNum + " = " + tloginNum);


		//start here for import player inventory (money, potions, backpack)
		try {
			reader = new FileReader(pinvPath);
			if (pinvPath.length() == 0) {
				String pinvPat = pinvPath.toString();
				File newFile = new File(pinvPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Chars2.add(scannerData); // add line to our arraylist
			String[] tcharsinv = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tcharsinv = tline.split("\\|");
			pInventory[tinvNum][0] = tcharsinv[0];
			pInventory[tinvNum][1] = tcharsinv[1];
			pInventory[tinvNum][2] = tcharsinv[2];
			pInventory[tinvNum][3] = tcharsinv[3];
			pInventory[tinvNum][4] = tcharsinv[4];
			pInventory[tinvNum][5] = tcharsinv[5];
			pInventory[tinvNum][6] = tcharsinv[6];
			pInventory[tinvNum][7] = tcharsinv[7];
			pInventory[tinvNum][8] = tcharsinv[8];
			pInventory[tinvNum][9] = tcharsinv[9];
			pInventory[tinvNum][10] = tcharsinv[10];
			pInventory[tinvNum][11] = tcharsinv[11];
			pInventory[tinvNum][12] = tcharsinv[12];
			pInventory[tinvNum][13] = tcharsinv[13];
			pInventory[tinvNum][14] = tcharsinv[14];
			pInventory[tinvNum][15] = tcharsinv[15];
			pInventory[tinvNum][16] = tcharsinv[16];
			pInventory[tinvNum][17] = tcharsinv[17];
			pInventory[tinvNum][18] = tcharsinv[18];
			pInventory[tinvNum][19] = tcharsinv[19];
			pInventory[tinvNum][20] = tcharsinv[20];
			pInventory[tinvNum][21] = tcharsinv[21];
			pInventory[tinvNum][22] = tcharsinv[22];
			pInventory[tinvNum][23] = tcharsinv[23];
			pInventory[tinvNum][24] = tcharsinv[24];
			pInventory[tinvNum][25] = tcharsinv[25];
			pInventory[tinvNum][26] = tcharsinv[26];
			pInventory[tinvNum][27] = tcharsinv[27];
			pInventory[tinvNum][28] = tcharsinv[28];
			pInventory[tinvNum][29] = tcharsinv[29];
			pInventory[tinvNum][30] = tcharsinv[30];
			pInventory[tinvNum][31] = tcharsinv[31];
			pInventory[tinvNum][32] = tcharsinv[32];
			pInventory[tinvNum][33] = tcharsinv[33];
			pInventory[tinvNum][34] = tcharsinv[34];
			pInventory[tinvNum][35] = tcharsinv[35];
			pInventory[tinvNum][36] = tcharsinv[36];
			pInventory[tinvNum][37] = tcharsinv[37];
			pInventory[tinvNum][38] = tcharsinv[38];
			pInventory[tinvNum][39] = tcharsinv[39];
			pInventory[tinvNum][40] = tcharsinv[40];
			pInventory[tinvNum][41] = tcharsinv[41];
			pInventory[tinvNum][42] = tcharsinv[42];
			pInventory[tinvNum][43] = tcharsinv[43];
			pInventory[tinvNum][44] = tcharsinv[44];
			pInventory[tinvNum][45] = tcharsinv[45];
			pInventory[tinvNum][46] = tcharsinv[46];
			pInventory[tinvNum][47] = tcharsinv[47];
			pInventory[tinvNum][48] = tcharsinv[48];
			pInventory[tinvNum][49] = tcharsinv[49];

			tinvNum++;
		}

		nextAvailInv = tinvNum;
		//		System.out.println(Chars[0][0]); // testing the Chars array
		//		System.out.println(Chars[0][1]); // testing the Chars array
		System.out.println("....");
		System.out.println("The next available character inventory number is " + nextAvailInv);
		System.out.println("tinvNum should equal tcharNum and tlginNum (this should be the number of characters");
		System.out.println(tinvNum + " = " + tcharNum + " = " + tloginNum);




		//start here for import mob inventory (money, potions, backpack)
		//	System.out.println("tminvNum should equal tmobNum ");
		//  System.out.println(tminvNum + " = " + tmobNum);

		//start here for import player inventory (money, potions, backpack)
		try {
			reader = new FileReader(minvPath);
			if (minvPath.length() == 0) {
				String minvPat = minvPath.toString();
				File newFile = new File(minvPat);
				newFile.createNewFile();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		breader = new BufferedReader(reader);
		scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			String scannerData = scanner.nextLine();  // while there is a line
			Mobs2.add(scannerData); // add line to our arraylist
			String[] tminv = new String[50];
			tline = scannerData;
			tline = tline.replace("||", "|");
			tminv = tline.split("\\|");
			mInventory[tminvNum][0] = tminv[0];
			mInventory[tminvNum][1] = tminv[1];
			mInventory[tminvNum][2] = tminv[2];
			mInventory[tminvNum][3] = tminv[3];
			mInventory[tminvNum][4] = tminv[4];
			mInventory[tminvNum][5] = tminv[5];
			mInventory[tminvNum][6] = tminv[6];
			mInventory[tminvNum][7] = tminv[7];
			mInventory[tminvNum][8] = tminv[8];
			mInventory[tminvNum][9] = tminv[9];
			mInventory[tminvNum][10] = tminv[10];
			mInventory[tminvNum][11] = tminv[11];
			mInventory[tminvNum][12] = tminv[12];
			mInventory[tminvNum][13] = tminv[13];
			mInventory[tminvNum][14] = tminv[14];
			mInventory[tminvNum][15] = tminv[15];
			mInventory[tminvNum][16] = tminv[16];
			mInventory[tminvNum][17] = tminv[17];
			mInventory[tminvNum][18] = tminv[18];
			mInventory[tminvNum][19] = tminv[19];
			mInventory[tminvNum][20] = tminv[20];
			mInventory[tminvNum][21] = tminv[21];
			mInventory[tminvNum][22] = tminv[22];
			mInventory[tminvNum][23] = tminv[23];
			mInventory[tminvNum][24] = tminv[24];
			mInventory[tminvNum][25] = tminv[25];
			mInventory[tminvNum][26] = tminv[26];
			mInventory[tminvNum][27] = tminv[27];
			mInventory[tminvNum][28] = tminv[28];
			mInventory[tminvNum][29] = tminv[29];
			mInventory[tminvNum][30] = tminv[30];
			mInventory[tminvNum][31] = tminv[31];
			mInventory[tminvNum][32] = tminv[32];
			mInventory[tminvNum][33] = tminv[33];
			mInventory[tminvNum][34] = tminv[34];
			mInventory[tminvNum][35] = tminv[35];
			mInventory[tminvNum][36] = tminv[36];
			mInventory[tminvNum][37] = tminv[37];
			mInventory[tminvNum][38] = tminv[38];
			mInventory[tminvNum][39] = tminv[39];
			mInventory[tminvNum][40] = tminv[40];
			mInventory[tminvNum][41] = tminv[41];
			mInventory[tminvNum][42] = tminv[42];
			mInventory[tminvNum][43] = tminv[43];
			mInventory[tminvNum][44] = tminv[44];
			mInventory[tminvNum][45] = tminv[45];
			mInventory[tminvNum][46] = tminv[46];
			mInventory[tminvNum][47] = tminv[47];
			mInventory[tminvNum][48] = tminv[48];
			mInventory[tminvNum][49] = tminv[49];

			tminvNum++;
		}

		nextAvailmInv = tminvNum;
		//		System.out.println(Chars[0][0]); // testing the Chars array
		//		System.out.println(Chars[0][1]); // testing the Chars array
		System.out.println("....");




		// testing code

		/*
		
		// this bypasses the loginSys right now
		int testCharNum = 0;
		player1.setPlayerNum(testCharNum);
		player1.setPlayerName(Chars[testCharNum][1]);
		player1.setPlayerShortDesc(Chars[testCharNum][2]);
		player1.setPlayerLongDesc(Chars[testCharNum][3]);



		// create a zone, loads it with rooms
		currentZone.resetZone(); // have to reset all zones to be used
		nextZone1.resetZone();
		nextZone1.setZoneNum(1);
		nextZone1.setZoneName("Test Zone");
		curZNum = 0;
		nextAvailZone = 4;
		curRoom.resetRoom(); // 
		rm00.resetRoom();
		rm03.resetRoom();
		resetRoomsinZoneSample(currentZone); // reset all the rooms in the passed zone		

		// room stuffs
		currentZone.rm00.setRoomNum(0); // set rm#
		loadRoominZoneSample(currentZone,currentZone.rm00,0); // load the room the indicated rm#
		currentZone.rm01.setRoomNum(1);
		loadRoominZoneSample(currentZone,currentZone.rm01,1);
		currentZone.rm02.setRoomNum(2);
		loadRoominZoneSample(currentZone,currentZone.rm02,2);
		currentZone.rm03.setRoomNum(3);
		loadRoominZoneSample(currentZone,currentZone.rm03,3);
		currentZone.rm04.setRoomNum(4);
		loadRoominZoneSample(currentZone,currentZone.rm04,4);
		currentZone.rm05.setRoomNum(5);
		loadRoominZoneSample(currentZone,currentZone.rm05,5);

		buildCurrentRoomSample(currentZone.rm00,0); // build the room, then populate the room
		buildCurrentRoomSample(currentZone.rm03,3);
		buildCurrentRoom(curRmNum);
		
		// //mob stuffs
		currentZone.rm00.setMobNumAtPos(4,0); // sets the mob in the array // appears to do nothing
		//		currentZone.rm00.tmob0.setMobNum(4);
		loadMob(currentZone.rm00.tmob0,4); // loads mob into specific zone, room, and mob, the 4 is the mob ID from db
		loadMob(rm00.tmob0,4); // for mobs in rooms in current zone
		loadMob(tmob0,4); // for mobs in current room
		

		//test 2
		currentZone.rm03.setMobNumAtPos(4,0);
		loadMob(currentZone.rm03.tmob0,4); // loads mob into specific zone, room, and mob, the 4 is the mob ID from db
		rm03.setMobNumAtPos(4, 0);
		loadMob(rm03.tmob0,4); // for mobs in rooms in current zone


		// return stuffs

		System.out.println(currentZone.toString()); // output whole zone for testing
		currentZone.returnZoneInfo();
		currentZone.rm00.returnRoomInfo(); // output rm00 for testing

		currentZone.rm00.tmob0.returnmobInfo(); // returns mob 4
		rm00.tmob0.returnmobInfo();// returns mob 4
		tmob0.returnmobInfo();// returns nothing	

		lookSample(currentZone.rm00,"null"); // looks at currentZone.rm00

		//		commandAnalyzer("attack 1.mob"); // attacks tmob0! // this works was testing if you could interact with tmob0

		
		unloadZoneSample(nextZone1,1);

		
		
		System.out.println(currentZone.rm04.getRoomName()); // prints A long Corridor
		System.out.println(rm04.getRoomName()); // prints null
		
		
		*/
		
		// testing ends, remove comment out




		///////////////////////////////////////////////////////////////////////////
		//
		//        Start the GAME HERE!
		//
		///////////////////////////////////////////////////////////////////////////






		// start the system!
		loginSys();

		buildCurrentRoom(curRmNum);
		commandAnalyzer("look");
		commandAnalyzer("commands");


		// close resources
		input.close();
		scanner.close();
		keyboard.close();

	} // end main




	// END OF GAME FILE








	// to do
	// object durability, weapon dmg, armor, descriptor method
	// need to build Builder! for Objects, Mobs, from ingame (maybe allow commands preffixed with char && player set to Imm/Gimm)




	// INSERT METHODS HERE



	private static void loadWorldFromArray() {
		// TODO Auto-generated method stub


	}




	public static void loginSys() throws Exception {
		// main menu screen
		System.out.println("Welcome to the Game v." + gameVersion);
		System.out.println("This is a turned based RPG with (limited) in-game world building tools");
		System.out.println("New Game - 1   Load Game - 2  Exit - 3");
		String iinput = keyboard.nextLine();
		switch (iinput) {
		case "1": { // iinput was 1, make a New Game
			loginSys2(); // New Game
			break;
		}

		case "2": { // newput was 2, Load a Game
			loginSys3(); // Load Game
			executingTask.start(); // start the stuffs
			break;
		}

		case "3": { // Exit the Game
			System.exit(0); // Exit the System
			break;
		}
		// iinput was not one of the choices
		default: {
			loginSys();
		}
		}
	} // end loginSys()

	public static void loginSys2() throws Exception {
		// create a new player character
		System.out.println("Enter player name.");
		kinput = input.nextLine();
		String user = kinput;

		for (int i = 0; i < nextAvailChar; i++) {
			//		System.out.println(charsFile[i][1] + ":" + charsFile[i][2]);
			if (user.equals(charsFile[i][1])) {
				System.out.println(charsFile[i][1]);
				System.out.println("We found an existing character with that name.");
				System.out.println("Please choose another name.");
				// pick a diff user name
				loginSys2();
			} // end if1
			else { // System.out.println("No such User in file, moving to next entry.");
			}
		} // end for loop

		System.out.println("Enter password.");
		kinput = input.nextLine();
		String pw = kinput;

		player1.setPlayerNum(nextAvailChar); //0

		String playername = user;
		player1.setPlayerName(playername); //1

		int statmin = 6; // minimum player stat
		int statmax = 18; // max player stat
		int pStam; //8
		int pStr; //9
		int pInt; //10
		int pAgi; //11
		pStam = roll(statmin, statmax); //8
		pStr = roll(statmin, statmax); //9
		pInt = roll(statmin, statmax); //10
		pAgi = roll(statmin, statmax); //11

		System.out.println("Default Stats: ");
		System.out.println("Stamina: " + pStam);
		System.out.println("Strength: " + pStr);
		System.out.println("Intellect: " + pInt);
		System.out.println("Agility: " + pAgi);

		System.out.println("Set Player Race.");

		System.out.println("1 = Human, 2 = Elf, 3 = Half-elf, 4 = Dwarf");  // add more races
		kinput = input.nextLine();

		int rmToBuild = 0;

		player1.setPlayerRace("Humanoid");

		switch (kinput) {
		case "1": {
			player1.setPlayerSubRace("Human"); //27
			// Human no bonus stats
			player1.setStam(player1.getStam());
			player1.setStr(player1.getStr());
			player1.setIntel(player1.getIntel());
			player1.setAgility(player1.getAgility());
			rmToBuild = humanStartRm;
			break;
		}

		case "2": {
			player1.setPlayerSubRace("Elf");
			// elf -1 stam, -1 str, +1 intel, +1 agil
			player1.setStam(player1.getStam()-1);
			player1.setStr(player1.getStr()-1);
			player1.setIntel(player1.getIntel()+1);
			player1.setAgility(player1.getAgility()+1);
			rmToBuild = elfStartRm;
			break;
		}

		case "4": {
			player1.setPlayerSubRace("Dwarf");
			// dwarf +1 stam, -1 agil
			player1.setStam(player1.getStam() + 1);
			player1.setStr(player1.getStr());
			player1.setIntel(player1.getIntel());
			player1.setAgility(player1.getAgility() - 1);
			rmToBuild = dwarfStartRm;
			break;
		}

		case "3": {
			player1.setPlayerSubRace("Half-elf");
			// half-elf -1 str, +1 agil
			player1.setStam(player1.getStam());
			player1.setStr(player1.getStr() - 1);
			player1.setIntel(player1.getIntel());
			player1.setAgility(player1.getAgility() + 1);
			rmToBuild = halfelfStartRm;
			break;
		}
		// add more races here


		default: {
			System.out.println("Invalid race");
			kinput = input.nextLine().toLowerCase();
		}
		}

		System.out.println("Applying Racial Bonuses.");

		System.out.println("Set a Player Class");
		System.out.println("1 - Cleric, 2 - Druid, 3 - Paladin, 4 - Fighter, 5 - Barbarian, 6 - Rogue, 7 - Mage, 0 - None");
		kinput = input.nextLine();
		switch (kinput) {
		case "0": {
			player1.setPlayerClass("none");
			break;
		}

		case "1": {
			player1.setPlayerClass("cleric");
			player1.setIntel(player1.getIntel() + 1);
			break;
		}

		case "2": {
			player1.setPlayerClass("druid");
			player1.setIntel(player1.getIntel() + 1);
			player1.setIntel(player1.getAgility() + 1);
			break;
		}

		case "3": {
			player1.setPlayerClass("paladin");
			player1.setIntel(player1.getIntel() + 1);
			player1.setStam(player1.getStam() + 1);
			break;
		}

		case "4": {
			player1.setPlayerClass("fighter");
			player1.setIntel(player1.getIntel() - 1);
			player1.setStam(player1.getStam() + 1);
			player1.setStr(player1.getStr() + 1);
			break;
		}

		case "5": {
			player1.setPlayerClass("barbarian");
			player1.setIntel(player1.getIntel() - 1);
			player1.setStam(player1.getStam() + 1);
			player1.setStr(player1.getStr() + 1);
			break;
		}

		case "6": {
			player1.setPlayerClass("rogue");
			player1.setIntel(player1.getAgility() + 1);
			break;
		}

		case "7": {
			player1.setPlayerClass("mage");
			player1.setIntel(player1.getIntel() + 1);
			break;
		}
		default: {
			System.out.println("Not a valid class");
		}
		} // end switch for class select

		System.out.println("Applying Class Bonuses.");

		System.out.println("Create player short description.");
		System.out.println("This is a sentence fragement describing your character.  Example: a short, fat man");
		kinput = input.nextLine().toLowerCase();
		player1.setPlayerShortDesc(kinput); //2

		System.out.println("Create your characters long description.");
		System.out.println("This is a short paragraph describing your character");
		kinput = input.nextLine();
		player1.setPlayerLongDesc(kinput); //3

		System.out.println("Please enter your keywords, one at a time");
		String[] split = new String[3];
		kinput = input.nextLine();
		split[0] = kinput;
		kinput = input.nextLine();
		split[1] = kinput;
		kinput = input.nextLine();
		split[2] = kinput;

		player1.setPlayerKeyWords(split); //4

		// to dev player class when SEEN by other players (when multiplayer), player classes
		// class specific abilities, player tiers (quests?)

		// build out rest of Player fields

		player1.setPlayerHP(player1.getStam()  * 10); //5
		player1.setPlayerMP(player1.getIntel() * 10); //6
		player1.setPlayerLvl(1); //7
		//8,9,10,11 (Stam,Str,Int,Agi) set above by racial selection

		player1.setHeadSlot("0"); //12
		player1.setNeckSlot("0"); //13
		player1.setShoulderSlot("0"); //14
		player1.setChestSlot("0");// 15
		player1.setWristSlot("0"); //16
		player1.setHandSlot("0"); //17
		player1.setFinger1("0");//18
		player1.setFinger2("0");  // 19
		player1.setWaistSlot("0"); //20
		player1.setLegSlot("0");//21
		player1.setFootSlot("0");//22
		player1.setTrinket1Slot("0");//23
		player1.setTrinket2Slot("0");//24
		player1.setWeapon1Slot("0"); //25
		player1.setWeaponShieldSlot("0");//26
		// player1.setPlayerRace(""); // set above in console
		player1.setPlayerTier("0"); //29
		player1.setPlayerXP(0); // 30
		player1.setPlayerIsAlive(1); //31

		System.out.println("Select character gender"); // 32
		System.out.println("This is for descriptions, and serves no ingame function");
		System.out.println("0 = None (No Gender), 1 = Male, 2 = Female, 3 = Non-binary");
		kinput = input.nextLine().toLowerCase();
		switch (kinput) {
		case "0":
		{
			System.out.println("No gender selected, pronoun will be 'it'");
			player1.setPlayerGender("none");
			break;
		}

		case "1": {
			System.out.println("You have selected Male");
			player1.setPlayerGender("Male");
			break;
		}

		case "2": {
			System.out.println("You have selected Female");
			player1.setPlayerGender("Female");
			break;
		}

		case "3": {
			System.out.println("You have selected Non-binary");
			player1.setPlayerGender("Non-binary");
			break;
		}
		default: {
			System.out.println("No gender selected.");
		}
		} // end of Gender Selection block

		player1.setPlayerClass("unused"); //33
		player1.setBlank1("unused"); //34
		player1.setBlank2("unused"); //35
		player1.setBlank3("unused"); //36
		player1.setBlank4("unused"); //37
		player1.setBlank5("unused"); //38
		player1.setBlank6("unused"); //39
		player1.setBlank7("unused"); //40
		player1.setBlank8("unused"); //41
		player1.setBlank9("unused"); //42
		player1.setBlank10("unused"); //43
		player1.setBlank11("unused"); //44
		player1.setBlank12("unused"); //45
		player1.setBlank13("unused"); //46
		player1.setBlank14("unused"); //47
		player1.setBlank15("unused"); //48
		player1.setBlank16("unused"); //49

		playerinventory.resetInventory();
		playerinventory.setPmobid(nextAvailInv);
		playerinventory.setPmobname(player1.getPlayerName());

		charsFile[nextAvailChar][0] = String.valueOf(nextAvailChar);
		charsFile[nextAvailChar][1] = user;
		charsFile[nextAvailChar][2] = pw;

		writeadminLoginArray(nextAvailChar);
		writeCharToCharArray(nextAvailChar);
		writePInvArray(nextAvailInv);

		loadPlayer(nextAvailChar);

		nextAvailChar++;
		nextAvailInv++;

		buildCurrentRoom(rmToBuild);

		psave(); // save the new character
		commandAnalyzer("look");


	} // end loginSys2()


	public static void loginSys3() throws Exception {
		System.out.print("Username: ");
		String user = keyboard.nextLine();

		System.out.print("Password: ");
		String pass = keyboard.nextLine();

		boolean userFound = false;

		for (int i = 0; i < nextAvailChar; i++) {
			if (user.equals(charsFile[i][1])) {
				userFound = true;
				if (pass.equals(charsFile[i][2])) {
					System.out.println("We found you at id: " + charsFile[i][0]);
					loadPlayer(Integer.parseInt(charsFile[i][0]));
					curRmNum = Integer.parseInt(charsFile[i][3]);
					return;  // Exit method after successful login
				} else {
					System.out.println("Password does not match the file entry, please try again");
					loginSys3();  // Prompt for login again on incorrect password
					return;
				}
			}
		} // end for loop

		if (!userFound) {
			System.out.println("No such User, please try again.");
			loginSys3();  // Prompt for login again if no user found
		}
	} // end loginSys3()


	private static void commandAnalyzer(String st) throws Exception {
		// takes in strings, analyzes input and executes methods

		// does the STUFF!

		String tempString = st.toLowerCase();
		input = new Scanner(System.in);
		switch (tempString) { // wast tempString  also change cast cure light back similar to others

		////////////
		// test cases
		////////////



		case "gotoroom3": {
			System.out.println("What room would you like to goto?");
			kinput = input.nextLine();
			int iinput = Integer.parseInt(kinput);
			gotoRoomSample2(iinput);

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}
		case "gotoroom2": {
			System.out.println("What room would you like to goto?");
			kinput = input.nextLine();
			int iinput = Integer.parseInt(kinput);
			gotoRoomSample(iinput);

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}



		// look mob/obj look by keyword test cases
		// these work!
		case "look obj": {

			lookObjByKeyword();


			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}

		case "look mob": {

			lookMobByKeyword();


			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}

		// end look mob/obj test cases




		//	switch (tempString) { // wast tempString  also change cast cure light back similar to others

		case "set mob wanders": {
			// attempts to set the mob's wander status
			System.out.println("Mob's wander status is currently: " + editingMob.getWanders());
			System.out.println("Enter new mob wander status. 0 for stationary, 1 for wanders.  The default status is 0.");
			kinput = input.nextLine();
			switch (kinput) {
			case "0": {
				editingMob.setWanders(0);
				break;
			}
			case "1": {
				editingMob.setWanders(1);
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob wander status again");

			}
			} // end switch

			System.out.println("This mob's wander status has been set to: " + editingMob.getWanders());


			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set mob wanders"




		case "copy room": {

			System.out.println("Which room would you like to copy?");
			int i = keyboard.nextInt();
			newRoom.setRoomName(World[i][1]);
			newRoom.setRoomShortDesc(World[i][2]);
			newRoom.setRoomLongDesc(World[i][3]);

			newRoom.setLit(Integer.parseInt(World[i][16]));
			newRoom.setCamp(Integer.parseInt(World[i][17]));
			newRoom.setRent(Integer.parseInt(World[i][18]));
			newRoom.setInside(Integer.parseInt(World[i][19]));
			newRoom.setTerrain(Integer.parseInt(World[i][20]));
			newRoom.setBank(Integer.parseInt(World[i][21]));


			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;				
		}

		case "show all rooms": {
			showRooms();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}
		case "cast rejuv": {			
			castRejuv();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}
		case "case regrowth": {
			castRegrowth();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}
		case "cast regen": {
			castRegen();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;		
		}

		case "regrowth on": {
			// test casts all HoT spells on player
			castRegrowth();
			castRegen();
			castRejuv();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		}
		case "regrowth off": {
			// sets HoT timers back to Off state of "0"

			regrowthCast = 0;
			regenCast = 0;
			rejuvCast = 0;

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "stat obj": {
			pinv0.returnObjectFull();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "stat obj"


		case "test mob cosmos cast": {
			castCosmos2(tmob0, player1);

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}


		case "gotoRoom2": {
			gotoRoom2(7);

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "test attack": {
			System.out.println("Test attack");

			attackIndef(player1, tmob0);

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "testing testing": {
			System.out.println("This is a test");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "sysstat": {
			sysStatus();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}




		//  end test cases

		/////////////////////
		// PLAYER COMMANDS //
		/////////////////////


		// emotes
		case "smile":{
			System.out.println("You smile happily.");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "smile
		case "nod": {
			System.out.println("You nod in understanding.");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "nod"


		case "frown": {
			System.out.println("You frown in thought.");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} //end case "frown"


		case "ponder": {
			System.out.println("You ponder over matters.");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "ponder"


		case "sigh": {
			System.out.println("You sigh quietly.");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "sigh"


		// end emotes




		case "sort inventory": { 

			sortPlayerInventory();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "sort inventory"

		case "eat food": {
			if (inCombat == 0) {
				eatFood();
			}
			else {
				System.out.println("You can't do that in combat.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "eat food"
		case "drink":{
			if (inCombat == 0) {
				drinkDrink();
			}
			else {
				System.out.println("You can't do that in combat.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "drink"

		case "exchange coins": {
			if (newRoom.getBank() == 1) {
				exchangeCoins();
			}
			else {
				System.out.println("You cannot do that here.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "exchange coins"


		case "destroy obj": {
			destroyObj();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "destroy obj"


		case "drop obj": {
			dropObj();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "drop obj"


		case "take obj": {
			takeObja();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "take obj"


		case "equip obj": {
			equipObj();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "equip obj"


		case "remove obj": {
			remObj2();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "remove obj"


		case "inventory": {
			//	playerinventory.returnInventory();
			playerInv();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "inventory"


		case "coins": {
			// players current coins
			playerCoins();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "coins"


		case "xp" : {
			// displays the current XP stats
			xptoLevel();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "xp"


		case "goto room": {
			gotoRoom();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "goto room"





		/////////////////////////
		// END PLAYER COMMANDS //
		/////////////////////////

		////////////////////
		// MOB COMMANDS //
		///////////////////


		case "create mob": {
			createMob();

			msave();

			editMob2(editingMob.getMobNum());

			System.out.println(" ");
			System.out.println(editor + "Editor");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "create mob"


		case "edit mob": {
			editor = "mob";
			editMob();

			System.out.println(" ");
			System.out.println(editor + "Editor");

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "edit mob"


		case "copy mob": {
			if(editor == "mob") {
				copyMob();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "copy mob"


		case "reset mob": {
			if(editor == "mob") {
				resetMobStats();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "reset mob"


		case "defaults": {
			if(editor == "mob") {
				mobDefaults();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "defaults"


		case "set mob gender": {
			if (editor == "mob") {
				setMobGender();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob gender"


		case "set mob attackable": {
			if (editor == "mob") {
				setMobAttackable();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob attackable"


		case "set mob xp": {
			if (editor == "mob") {
				setMobXP();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob xp"


		case "set mob rank": {
			if (editor == "mob") {
				setMobRank();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob name"


		case "set mob level": {
			if (editor == "mob") {
				setMobLevel();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob level"


		case "set mob race": {
			if (editor == "mob") {
				setMobRace();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob race"


		case "set mob subrace": {
			if (editor == "mob") {
				setMobSubRace();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob subrace"


		case "set mob class": {
			if (editor == "mob") {
				setMobClass();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob class"


		case "set mob keywords": {
			if (editor == "mob") {
				setMobKeywords();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob keywords"


		case "set mob name": {
			if (editor == "mob") {
				setMobName();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob name"


		case "set mob long desc": {
			if (editor == "mob") {
				setMobLongDesc();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob long desc"


		case "set mob short desc": {
			if (editor == "mob") {
				setMobShortDesc();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end "set mob short desc"


		case "set mob talker": {
			if (editor == "mob") {
				setMobTalker(editingMob);
				System.out.println(" ");
				System.out.println(editor + "Editor");
			} // end if (editor == "mob"
			else {
				System.out.println("You are not in the mob editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob talker"


		case "show mob": {
			if (editingMob.getMobNum() != 0) {
				editingMob.returnmobInfo();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not currently editing a mob");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "show mob"

		case "show all mobs": {
			showMobs();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "show all mobs"

		case "set mob intellect": {
			if (editingMob.getMobNum() != 0) {
				setMobInt();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not currently editing a mob");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set mob intellect"


		case "set mob stamina": {
			if (editingMob.getMobNum() != 0) {
				setMobStam();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not currently editing a mob");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set mob stamina"


		case "set mob strength": {
			if (editingMob.getMobNum() != 0) {
				setMobStr();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not currently editing a mob");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set mob strength"


		case "set mob agility": {
			if (editingMob.getMobNum() != 0) {
				setMobAgi();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not currently editing a mob");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set mob agility"

		case "set mob head slot": {
			if (editor == "mob") {
				setMobHeadSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob head slot"
		case "set mob neck slot": {
			if (editor == "mob") {
				setMobNeckSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob neck slot"
		case "set mob shoulder slot": {
			if (editor == "mob") {
				setMobShoulderSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob shoulder slot"
		case "set mob chest slot": {
			if (editor == "mob") {
				setMobChestSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob chest slot"
		case "set mob wrist slot": {
			if (editor == "mob") {
				setMobWristSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob wrist slot"
		case "set mob hand slot": {
			if (editor == "mob") {
				setMobHandSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob hand slot"
		case "set mob finger1 slot": {
			if (editor == "mob") {
				setMobFinger1Slot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob finger1 slot"
		case "set mob finger2 slot": {
			if (editor == "mob") {
				setMobFinger2Slot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob fingre2 slot"
		case "set mob waist slot": {
			if (editor == "mob") {
				setMobWaistSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob waoist slot"
		case "set mob leg slot": {
			if (editor == "mob") {
				setMobLegSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob leg slot"
		case "set mob foot slot": {
			if (editor == "mob") {
				setMobFootSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob foot slot"
		case "set mob trinket1 slot": {
			if (editor == "mob") {
				setMobTrinket1Slot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob trinket1 slot"
		case "set mob trinket2 slot": {
			if (editor == "mob") {
				setMobTrinket2Slot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob trinket2 slot"
		case "set mob weapon1 slot": {
			if (editor == "mob") {
				setMobWeaponSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob weapon1 slot"
		case "set mob weaponshield slot": {
			if (editor == "mob") {
				setMobWeaponShieldSlot();

				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the mob editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob weaponShield slot"



		/////////////////////
		// END MOB COMMANDS //
		//////////////////////


		/////////////////////
		// OBJ COMMANDS //
		////////////////////


		case "create obj": {
			createObj();

			osave();

			editObj2(editingObject.getObjNum());

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "create obj"


		case "edit obj": {
			editObj();

			System.out.println(" ");
			System.out.println(editor + "Editor");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "edit obj"


		case "show obj": {
			if (editor == "object") {
				showObjInfo();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "show obj"


		case "show all objs": {
			showObjs();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "show all objs"


		case "set obj type": {
			if (editor == "object") {
				setObjType2();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}// end case "set obj type"


		case "set obj name": {
			if (editor == "object") {
				setObjName();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj name"


		case "set obj short desc": {
			if (editor == "object") {
				setObjShortDesc();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj short desc"


		case "set obj long desc": {
			if (editor == "object") {
				setObjLongDesc();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj long desc"


		case "set obj extended desc": {
			if (editor == "object") {
				setObjExtDesc();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj extended desc"


		case "set obj keywords": {
			if (editor == "object") {
				setObjKeyWords2();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj keywords"


		case "set obj equip slot": {
			if (editor == "object") {
				setEquip();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj equip slot"


		case "set obj takeable": {
			if (editor == "object") {
				setTake();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj takeable"


		case "set obj durability": {
			if (editor == "object") {
				setObjDur();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else { 
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj durability"


		case "set obj armor type": {
			if (editor == "object") {
				setarmrType();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}// end case "set obj armor type"


		case "set obj add mp": {
			if (editor == "object") {
				setObjAddMP();	
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add mp"


		case "set obj add hp": {
			if (editor == "object") {
				setObjAddHP();	
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add mp"


		case "set obj add agi": {
			if (editor == "object") {
				setObjAddAgi();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add agi"


		case "set obj add int": {
			if (editor == "object") {
				setObjAddInt();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add int"


		case "set obj add stam": {
			if (editor == "object") {
				setObjAddStam();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add stam"


		case "set obj add str": {
			if (editor == "object") {
				setObjAddStr();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj add str"


		case "set obj blue glow": {
			if (editor == "object") {
				setbGlow();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set blue glow"


		case "set obj red glow": {
			if (editor == "object") {
				setrGlow();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set red glow"


		case "set obj hum": {
			if (editor == "object") {
				sethums();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set obj hum"


		case "set obj cursed": {
			if (editor == "object") {
				setcurseditem();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set obj cursed"

		case "set obj container size": {
			if (editor == "object") {
				setcSize();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end case "set container size"


		case "set obj weapon type": {
			if (editor == "object") {
				setwpnType();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end "set obj weapon type"


		case "set obj weapon damage type": {
			if (editor == "object") {
				setwpndmgType();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		} // end "set obj weapon damage type"


		case "set obj wand charge": {
			if (editor == "object") {
				setwCharge();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	

		} // end case "set obj wand charge"


		case "set obj hp restore": {
			if (editor == "object") {
				sethpRes();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	

		} // end case "set obj hp restore"


		case "set obj mp restore": {
			if (editor == "object") {
				setmpRes();
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj hp restore"


		case "set obj weapon damage": {
			if (editor == "object") {
				setwpnDmg();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj weapon damage"	


		case "set obj value": {
			if (editor == "object") {
				setObjVal();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj value"	


		case "set obj potion spell": {
			if (editor == "object") {
				setpSpell();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj potion spell"


		case "set obj container contents": {
			if (editor == "object") {
				setcCont();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj container contents"	


		case "set obj damage reduction": {
			if (editor == "object") {
				setdmgRed();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj damage reduction"


		case "set obj wand spell": {
			if (editor == "object") {
				setwSpell();
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("You are not in the object editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "set obj wand spell"	


		//////////////////////
		// END OBJ COMMANDS //
		//////////////////////


		///////////////////
		// ROOM COMMANDS //
		///////////////////

		case "create room": {
			createRoomSimple();


			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		} // end case "create room"





		case "edit room": {
			editRoom();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "edit room"


		case "set room name": {
			if (editor == "room") {
				setRoomName();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set room name"


		case "set indoor setting": {
			if (editor == "room") {
				setRoomIndoor();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set indoor setting"


		case "set camp": {
			if (editor == "room") {
				setRoomCamp();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set camp"


		case "set rent": {
			if (editor == "room") {
				setRoomRent();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set rent"


		case "set lit": {
			if (editor == "room") {
				setRoomLit();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set lit"


		case "set terrain": {
			if (editor == "room") {
				setTerrain();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}// end case "set terrain"


		case "set bank": {
			if (editor == "room") {
				setRoomBank();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}


		case "set room short desc": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();
				System.out.println("Current room's short description: " + newRoom.getRoomShortDesc());
				System.out.println("This is a short description of the room. ex. a worn building");

				System.out.println(editor + "Editor");
				kinput = input.nextLine();
				newRoom.setRoomShortDesc(kinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set room short desc"


		case "set room long desc": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current room's long description: " + newRoom.getRoomLongDesc());
				System.out.println("This is a few sentences to short paragraph about the room.  This is what you see!");

				System.out.println(editor + "Editor");
				kinput = input.nextLine();
				newRoom.setRoomLongDesc(kinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set room long desc"


		case "set exit north": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();
				System.out.println("Current room's North Exit is: " + newRoom.getExitN());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitN(iinput);
				exN.setExitN(iinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit north"

		case "set exit northeast": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms NorthEast Exit is: " + newRoom.getExitNE());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitNE(iinput);
				exNE.setExitNE(iinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set exit northeast"


		case "set exit east": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();
				System.out.println("Current rooms East Exit is: " + newRoom.getExitE());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");

				newRoom.setExitE(iinput);
				exE.setExitE(iinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // case "set exit east"

		case "set exit southeast": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms SouthEast Exit is: " + newRoom.getExitSE());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitSE(iinput);
				exSE.setExitSE(iinput);
				//		buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit southeast"

		case "set exit south": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms South Exit is: " + newRoom.getExitS());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitS(iinput);
				exS.setExitS(iinput);
				//		buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit south"

		case "set exit southwest": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms SouthWest Exit is: " + newRoom.getExitSW());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitSW(iinput);
				exSW.setExitSW(iinput);
				//	buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit southwest"

		case "set exit west": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms West Exit is: " + newRoom.getExitW());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitW(iinput);
				exW.setExitW(iinput);
				//	buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}// end case "set exit west"

		case "set exit northwest": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms NorthWest Exit is: " + newRoom.getExitNW());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitNW(iinput);
				exNW.setExitNW(iinput);
				//buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit northwest"

		case "set exit up": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();
				System.out.println("Current rooms Up Exit is: " + newRoom.getExitU());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitU(iinput);

				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit up"

		case "set exit down": {
			if (editor == "room") {
				newRoom.returnRoomInfo2();

				System.out.println("Current rooms Down Exit is: " + newRoom.getExitD());

				int iinput = input.nextInt();
				System.out.println(editor + "Editor");
				newRoom.setExitD(iinput);
				newRoom.returnRoomInfo2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set exit down"


		case "set mob 1": {
			if (editor == "room") {
				setRoomMob1();			

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 1"


		case "set mob 2": {
			if (editor == "room") {
				setRoomMob2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 2"


		case "set mob 3": {
			if (editor == "room") {
				setRoomMob3();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 3"


		case "set mob 4": {
			if (editor == "room") {
				setRoomMob4();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 4"


		case "set mob 5": {
			if (editor == "room") {
				setRoomMob5();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 5"


		case "set mob 6": {
			if (editor == "room") {
				setRoomMob6();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set mob 6"


		case "set obj 1": {
			if (editor == "room") {
				setRoomObj1();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 1"


		case "set obj 2": {
			if (editor == "room") {
				setRoomObj2();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 2"


		case "set obj 3": {
			if (editor == "room") {
				setRoomObj3();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 3"


		case "set obj 4": {
			if (editor == "room") {
				setRoomObj4();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 4"


		case "set obj 5": {
			if (editor == "room") {
				setRoomObj5();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 5"


		case "set obj 6": {
			if (editor == "room") {
				setRoomObj6();

				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in the room editor.");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "set obj 6"


		case "list rooms": {
			if (editor != "null") {
				for (int i = 0; i < nextAvailRoom; i++ ) {
					System.out.println(World[i][0] + " | " + World[i][1]);
				} // end for loop
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");	
			}// end iff
			else {
				System.out.println("Not in an editor.");
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		}

		case "list objects": {
			if (editor != "null") {
				for (int i = 0; i < nextAvailObj; i++ ) {
					System.out.println(Objects[i][0] + " | " + Objects[i][1]);
				} // end for loop
			}// end iff
			else {
				System.out.println("Not in an editor.");
			}
			System.out.println(editor + "Editor");

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		}

		case "list mobs": {
			if (editor != "null") {
				for (int i = 0; i < nextAvailMob; i++ ) {
					System.out.println(Mobs[i][0] + " | " + Mobs[i][1]);
				} // end for loop

			}// end iff
			else {
				System.out.println("Not in an editor.");
			}
			System.out.println(editor + "Editor");

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		}


		case "commands": {
			if (editor == "room") {
				roomCommands();
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else if (editor == "mob") {
				mobCommands();
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else if (editor == "object") {
				objCommands();
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else if (editor == "player") {
				playerCommands();
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in an editor.");
				genCommands();
				System.out.println(" ");
				System.out.println(" ");
			}

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "create done": {
			editor = "null";

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// save all my editors please!
		case "csave": {
			if (editor == "room") {
				System.out.println("Saving the room");
				wsave();
				//	loadWorldArray();

				//	buildCurrentRoom(newRoom.getRoomNum());
				newRoom.returnRoomInfo2();
				System.out.println(editor + "Editor");
			}
			else if (editor == "mob") {
				System.out.println("Saving the mob");
				msave();
				editingMob.returnmobInfo();
				System.out.println(editor + "Editor");
			}
			else if (editor == "object") {
				System.out.println("Saving the object");
				osave();
				editingObject.returnObjectFull();
				System.out.println(editor + "Editor");
			}
			else if (editor == "player") {
				System.out.println("Saving the player");
				psave();
				System.out.println(editor + "Editor");
			}
			else if (editor == "zone") { 
				System.out.println("Saving the zone");
				zsave();
				editingZone.returnZoneInfo();
				System.out.println(editor + "Editor");
			}
			else {
				System.out.println("Not in an editor.");
				editor = "null";
			}

			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		}

		case "game time": {
			displayCurrentTime();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;			
		} // end case "game time"

		// system stuff
		case "time": {
			displayCurrentTime();
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "null": {
			kinput = input.next();
			commandAnalyzer(kinput);
			break;
		}

		case "score": {
			playerScore();
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "equipment": {
			playerEQ();
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// player spells

		/*
		case "cast":
		{
			switch (tarr1) {
			case "cure-light":
				switch (tarr2) {
				case "me":
					castCureLight(player1);
					break;
					// add more targets if making multiplayer
				default:
					System.out.println("You must have a target 'me'");
					break;
				}
				break;
				// add more cases for spells

			case "cure-serious":
				switch (tarr2) {
				case "me":
					castCureSer(player1);
					break;
					// add more targets if making multiplayer
				default:
					System.out.println("You must have a target 'me'");
					break;
				}
				break;
			default: { System.out.println("You don't know such a spell.");  }
			}


			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		 */

		case "roll": {
			System.out.println("You have rolled a " + d20() + ".");
			// d20();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "plvl me": {
			levelUp();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "quaff mmpot": {
			if(playerinventory.getPmobMMPot() > 0) {
				System.out.println("You quaff a Major Mana Potion.");
				int mpheal = roll(80,100);
				if (mpheal <= (player1.getPlayerMP()-mpheal)) {
					player1.setPlayerMP(player1.getPlayerMP() + mpheal);
					System.out.println("You have gained " + mpheal + " mana.");
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() - 1);
				}
				else {
					int mpdiff = player1.getPlayerMaxMP() - player1.getPlayerMP();
					player1.setPlayerMP(player1.getPlayerMaxMP());
					System.out.println("You have gained " + mpdiff + " mana.");
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff mmpot"

		case "quaff gmpot": {
			if(playerinventory.getPmobMMPot() > 0) {
				System.out.println("You quaff a Greater Mana Potion.");
				int mpheal = roll(60,70);
				if (mpheal <= (player1.getPlayerMP()-mpheal)) {
					player1.setPlayerMP(player1.getPlayerMP() + mpheal);
					System.out.println("You have gained " + mpheal + " mana.");
					playerinventory.setPmobGMPot(playerinventory.getPmobGMPot() - 1);
				}
				else {
					int mpdiff = player1.getPlayerMaxMP() - player1.getPlayerMP();
					player1.setPlayerMP(player1.getPlayerMaxMP());
					System.out.println("You have gained " + mpdiff + " mana.");
					playerinventory.setPmobGMPot(playerinventory.getPmobGMPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff gmpot"

		case "quaff mpot": {
			if(playerinventory.getPmobMPot() > 0) {
				System.out.println("You quaff a Mana Potion.");
				int mpheal = roll(40,50);
				if (mpheal <= (player1.getPlayerMP()-mpheal)) {
					player1.setPlayerMP(player1.getPlayerMP() + mpheal);
					System.out.println("You have gained " + mpheal + " mana.");
					playerinventory.setPmobMPot(playerinventory.getPmobMPot() - 1);
				}
				else {
					int mpdiff = player1.getPlayerMaxMP() - player1.getPlayerMP();
					player1.setPlayerMP(player1.getPlayerMaxMP());
					System.out.println("You have gained " + mpdiff + " mana.");
					playerinventory.setPmobMPot(playerinventory.getPmobMPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff mpot"

		case "quaff lmpot": {
			if(playerinventory.getPmobLMPot() > 0) {
				System.out.println("You quaff a Lesser Mana Potion.");
				int mpheal = roll(20,30);
				if (mpheal <= (player1.getPlayerMP()-mpheal)) {
					player1.setPlayerMP(player1.getPlayerMP() + mpheal);
					System.out.println("You have gained " + mpheal + " mana.");
					playerinventory.setPmobLMPot(playerinventory.getPmobLMPot() - 1);
				}
				else {
					int mpdiff = player1.getPlayerMaxMP() - player1.getPlayerMP();
					player1.setPlayerMP(player1.getPlayerMaxMP());
					System.out.println("You have gained " + mpdiff + " mana.");
					playerinventory.setPmobLMPot(playerinventory.getPmobLMPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff mmpot"

		case "quaff mhpot": {
			if(playerinventory.getPmobMHPot() > 0) {
				System.out.println("You quaff a Major Healing Potion.");
				int hpheal = roll(80,100);
				if (hpheal <= (player1.getPlayerHP()-hpheal)) {
					player1.setPlayerHP(player1.getPlayerHP() + hpheal);
					System.out.println("You have gained " + hpheal + " health.");
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() - 1);
				}
				else {
					int hpdiff = player1.getPlayerMaxHP() - player1.getPlayerHP();
					player1.setPlayerHP(player1.getPlayerMaxHP());
					System.out.println("You have gained " + hpdiff + " health.");
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff mhpot"

		case "quaff ghpot": {
			if(playerinventory.getPmobGHPot() > 0) {
				System.out.println("You quaff a Greater Healing Potion.");
				int hpheal = roll(60,70);
				if (hpheal <= (player1.getPlayerHP()-hpheal)) {
					player1.setPlayerHP(player1.getPlayerHP() + hpheal);
					System.out.println("You have gained " + hpheal + " health.");
					playerinventory.setPmobGHPot(playerinventory.getPmobGHPot() - 1);
				}
				else {
					int hpdiff = player1.getPlayerMaxHP() - player1.getPlayerHP();
					player1.setPlayerHP(player1.getPlayerMaxHP());
					System.out.println("You have gained " + hpdiff + " health.");
					playerinventory.setPmobGHPot(playerinventory.getPmobGHPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff ghpot"

		case "quaff hpot": {
			if(playerinventory.getPmobHPot() > 0) {
				System.out.println("You quaff a Healing Potion.");
				int hpheal = roll(40,50);
				if (hpheal <= (player1.getPlayerHP()-hpheal)) {
					player1.setPlayerHP(player1.getPlayerHP() + hpheal);
					System.out.println("You have gained " + hpheal + " health.");
					playerinventory.setPmobHPot(playerinventory.getPmobHPot() - 1);
				}
				else {
					int hpdiff = player1.getPlayerMaxHP() - player1.getPlayerHP();
					player1.setPlayerHP(player1.getPlayerMaxHP());
					System.out.println("You have gained " + hpdiff + " health.");
					playerinventory.setPmobHPot(playerinventory.getPmobHPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff hpot"

		case "quaff lhpot": {
			if(playerinventory.getPmobLHPot() > 0) {
				System.out.println("You quaff a Lesser Healing Potion.");
				int lhpheal = roll(20,30);
				if (lhpheal <= (player1.getPlayerHP()-lhpheal)) {
					player1.setPlayerHP(player1.getPlayerHP() + lhpheal);
					System.out.println("You have gained " + lhpheal + " health.");
					playerinventory.setPmobLHPot(playerinventory.getPmobLHPot() - 1);
				}
				else {
					int hpdiff = player1.getPlayerMaxHP() - player1.getPlayerHP();
					player1.setPlayerHP(player1.getPlayerMaxHP());
					System.out.println("You have gained " + hpdiff + " health.");
					playerinventory.setPmobLHPot(playerinventory.getPmobLHPot() - 1);
				}
			}
			else { System.out.println("You do not have any of those."); }

			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() +   " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end case "quaff lesser hp"




		// healing spells
		case "cast cure-light": {
			String t = player1.getPlayerClass().toString();
			switch (t) {
			case "paladin": {
				castCureLight(player1); 
				System.out.println(t);
				break;
			}
			case "cleric": {
				castCureLight(player1); 
				System.out.println(t);
				break;
			}
			case "druid": {
				castCureLight(player1); 
				System.out.println(t);
				break;
			}
			default: {
				System.out.println("You cannot cast that.");
			}
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "cast cure-serious": {
			castCureSer(player1);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "cast cure-crit": {
			castCureCrit(player1);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;

		}
		case "cast healing rain": {
			castHealingRain(player1);
			kinput = input.nextLine();
			break;
		}



		// attack spells
		// player casts cosmos
		case "cast cosmos 1.mob": {
			castCosmos(player1, tmob0);
			//	attackTar(player1,tmob0);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast cosmos 2.mob": {
			castCosmos(player1, tmob1);
			//	attackTar(player1,tmob1);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast cosmos 3.mob": {
			castCosmos(player1, tmob2);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast cosmos 4.mob": {
			castCosmos(player1, tmob3);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast cosmos 5.mob": {
			castCosmos(player1, tmob4);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast cosmos 6.mob": {
			castCosmos(player1, tmob5);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// player casts fireball
		case "cast fireball 1.mob": {
			castFireball(player1, tmob0);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast fireball 2.mob": {
			castFireball(player1, tmob1);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast fireball 3.mob": {
			castFireball(player1, tmob2);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast fireball 4.mob": {
			castFireball(player1, tmob3);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast fireball 5.mob": {
			castFireball(player1, tmob4);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "cast fireball 6.mob": {
			castFireball(player1, tmob5);
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}




		// directions
		case "north": {
			if (newRoom.getExitN() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitN();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "north east": {
			if (newRoom.getExitNE() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitNE();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "east": {
			if (newRoom.getExitE() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitE();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "south east": {
			if (newRoom.getExitSE() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitSE();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "south": {
			if (newRoom.getExitS() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitS();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "south west": {
			if (newRoom.getExitSW() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitSW();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "west": {
			if (newRoom.getExitW() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitW();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "north west": {
			if (newRoom.getExitNW() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitNW();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "up": {
			if (newRoom.getExitU() != 0) {
				buildCurrentRoom(newRoom.getExitU());
				curRmNum = newRoom.getRoomNum();
				look("null");
			}
			else {
				System.out.println("You cannot go that way.1");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "down": {
			if (newRoom.getExitD() != 0) {
				System.out.println("Walking " + tempString);
				int t = newRoom.getExitD();
				buildCurrentRoom(t);
				curRmNum = t;
				look("null");
			}
			else {
				System.out.println("You cannot go that way.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		// default or no target room - this refreshes the current view of room
		case "look": {
			look("null");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		// shorter look // for use in editRoom() ?
		case "look2": {// does not show mobs or objs in room
			look2("null");

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		// directional looks
		case "look north":{
			look("north");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look north east": {
			look("north east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look east": {
			look("east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look south east": {
			look("south east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look south": {
			look("south");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look south west": {
			look("south west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look west": {
			look("west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look north west": {
			look("north west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look up": {
			look("up");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break; }
		case "look down": {
			look("down");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}


		// game exits
		case "camp": { // camping for the "night" to regen mp/hps
			if (newRoom.getCamp() == 1) { // System.out.println("You pitch a tent and lie down beside a small fire, lit to ward off the cold.");
				camp();
			}
			else {
				System.out.println("You may not make camp here.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "camp out": {
			if(newRoom.getCamp() == 1) {
				camp();
				executingTask.stop();
				loginSys();
				break;
			}
			else {
				System.out.println("You may not make camp here.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
			}
			break;
		}// end camp out

		case "exit": { // bad idea hombre, nothing gets saved, but you gets OUT of the game
			System.out.println("Goodbye.");
			System.exit(0);
			break;
		}
		//rents for the night, restores HP/MP to full
		case "rent": {
			if (newRoom.getRent() == 1) {
				rent();
			}
			else {
				System.out.println("You must find an inn to rent.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		// rents an exits the game
		case "rent out": {
			if (newRoom.getRent() == 0) {
				System.out.println("You must find an inn to rent.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
			}

			else {
				rent();
				executingTask.stop();
				loginSys();
			}
			break;
		}

		// object looks
		case "look 1.obj": {
			if (tobj0.getObjNum()>0) {
				showObjInfo2(tobj0);
			}
			else {
				System.out.println("No such 1.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 2.obj": {
			if (tobj1.getObjNum()>0) {
				showObjInfo2(tobj1);
			}
			else {
				System.out.println("No such 2.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 3.obj": {
			if (tobj2.getObjNum()>0) {
				showObjInfo2(tobj2);
			}
			else {
				System.out.println("No such 3.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 4.obj": {
			if (tobj3.getObjNum()>0) {
				showObjInfo2(tobj3);
			}
			else {
				System.out.println("No such 4.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 5.obj": {
			if (tobj4.getObjNum()>0) {
				showObjInfo2(tobj4);
			}
			else {
				System.out.println("No such 5.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 6.obj": {
			if (tobj5.getObjNum()>0) {
				showObjInfo2(tobj5);
			}
			else {
				System.out.println("No such 6.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		} // end "look 6.obj"

		// mob looks
		case "look mob test": {
			lookRoomMob();

			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "look 1.mob": {
			if (tmob0.getMobNum()>0) {
				//	tmob0.returnmobInfo();
				lookMob(tmob0);
				mSlot = "tmob0";
			}
			else {
				System.out.println("No such 1.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 2.mob": {
			if (tmob1.getMobNum()>0) {
				lookMob(tmob1);
				mSlot = "tmob1";
			}
			else {
				System.out.println("No such 2.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 3.mob": {
			if (tmob2.getMobNum()>0) {
				lookMob(tmob2);
				mSlot = "tmob2";
			}
			else {
				System.out.println("No such 3.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 4.mob": {
			if (tmob3.getMobNum()>0) {
				//	tmob3.returnmobInfo();
				lookMob(tmob3);
				mSlot = "tmob3";
			}
			else {
				System.out.println("No such 4.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 5.mob": {
			if (tmob4.getMobNum()>0) {
				//	tmob4.returnmobInfo();
				lookMob(tmob4);
				mSlot = "tmob4";
			}
			else {
				System.out.println("No such 5.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "look 6.mob": {
			if (tmob5.getMobNum()>0) {
				//	tmob5.returnmobInfo();
				lookMob(tmob5);
				mSlot = "tmob5";
			}
			else {
				System.out.println("No such 6.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}


		// attacking mobs
		case "attack 1.mob": {
			//if ("1.mob"== temparr[1])
			if (tmob0.getMobNum()>0) {
				System.out.println("You have attacked " + tmob0.getMobShortDesc() +  ".");
				attackTar3b(player1, tmob0, 5);
			}
			else {
				System.out.println("No such 1.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "attack 2.mob": {
			if (tmob1.getMobNum()>0) {
				System.out.println("You have attacked " + tmob1.getMobShortDesc() + ".");
				attackTar3b(player1, tmob1, 5);
			}
			else {
				System.out.println("No such 2.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "attack 3.mob": {
			if (tmob2.getMobNum()>0) {
				System.out.println("You have attacked " + tmob2.getMobShortDesc() + ".");
				attackTar3b(player1, tmob2, 5);
			}
			else {
				System.out.println("No such 3.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "attack 4.mob": {
			if (tmob3.getMobNum()>0) {
				System.out.println("You have attacked " + tmob3.getMobShortDesc() + ".");
				attackTar3b(player1, tmob3, 5);
			}
			else {
				System.out.println("No such 4.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "attack 5.mob": {
			if (tmob4.getMobNum()>0) {
				System.out.println("You have attacked " + tmob4.getMobShortDesc() + ".");
				attackTar3b(player1, tmob4, 5);
			}
			else {
				System.out.println("No such 5.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "attack 6.mob": {
			if (tmob5.getMobNum()>0) {
				System.out.println("You have attacked " + tmob5.getMobShortDesc() + ".");
				attackTar3b(player1, tmob5, 5);
			}
			else {
				System.out.println("No such 6.mob exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		case "punch 1.mob":	{
			if (tmob0.getMobNum()>0) {
				System.out.println("You punched " + tmob0.getMobShortDesc() + ".");
				attackTar3b(player1, tmob0, 1);
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// attack objs
		case "attack 1.obj": {
			if (tobj0.getDurability()>=0) {
				System.out.println("You have attacked " + tobj0.getObjShortDesc() + ".");
				attackObj(player1, tobj0, 5);
			}
			else {
				System.out.println("No such 1.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "attack 2.obj": {
			if (tobj1.getDurability()>=0) {
				System.out.println("You have attacked " + tobj1.getObjShortDesc() + ".");
				attackObj(player1, tobj1, 5);
			}
			else {
				System.out.println("No such 2.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "attack 3.obj": {
			if (tobj2.getDurability()>=0) {
				System.out.println("You have attacked " + tobj2.getObjShortDesc() + ".");
				attackObj(player1, tobj2, 5);
			}
			else {
				System.out.println("No such 3.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "attack 4.obj": {
			if (tobj3.getDurability()>=0) {
				System.out.println("You have attacked " + tobj3.getObjShortDesc() + ".");
				attackObj(player1, tobj3, 5);
			}
			else {
				System.out.println("No such 4.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "attack 5.obj": {
			if (tobj4.getDurability()>=0) {
				System.out.println("You have attacked " + tobj4.getObjShortDesc() + ".");
				attackObj(player1, tobj4, 5);
			}
			else {
				System.out.println("No such 5.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "attack 6.obj": {
			if (tobj5.getDurability()>=0) {
				System.out.println("You have attacked " + tobj5.getObjShortDesc() + ".");
				attackObj(player1, tobj5, 5);
			}
			else {
				System.out.println("No such 6.obj exists.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// default response if no valid commands are input
		default: {
			System.out.println("Huh?");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		}
	} // end commandAnalyzer


	private static void buildCurrentRoomSample(room R, int i) {
		// R is the passed Room, i is the room# from db


		R.setRoomNum(i);
		R.setRoomName(World[i][1]);
		R.setRoomShortDesc(World[i][2]);
		R.setRoomLongDesc(World[i][3]);
		R.setExitN(Integer.parseInt(World[i][4]));
		R.setExitNE(Integer.parseInt(World[i][5]));
		R.setExitE(Integer.parseInt(World[i][6]));
		R.setExitSE(Integer.parseInt(World[i][7]));
		R.setExitS(Integer.parseInt(World[i][8]));
		R.setExitSW(Integer.parseInt(World[i][9]));
		R.setExitW(Integer.parseInt(World[i][10]));
		R.setExitNW(Integer.parseInt(World[i][11]));
		R.setExitU(Integer.parseInt(World[i][12]));
		R.setExitD(Integer.parseInt(World[i][13]));
		R.setMobsInRoom(World[i][14].split(", "));
		R.setObjsInRoom(World[i][15].split(", "));
		R.setLit(Integer.parseInt(World[i][16]));
		R.setCamp(Integer.parseInt(World[i][17]));
		R.setRent(Integer.parseInt(World[i][18]));
		R.setInside(Integer.parseInt(World[i][19]));
		R.setTerrain(Integer.parseInt(World[i][20]));
		R.setBank(Integer.parseInt(World[i][21]));

		R.setdNStatus(World[i][22]);
		R.setdNEStatus(World[i][23]);
		R.setdEStatus(World[i][24]);
		R.setdSEStatus(World[i][25]);
		R.setdSStatus(World[i][26]);
		R.setdSWStatus(World[i][27]);
		R.setdWStatus(World[i][28]);
		R.setdNWStatus(World[i][29]);
		R.setdUStatus(World[i][30]);
		R.setdDStatus(World[i][31]);

		R.setV32(World[i][32]);
		R.setV33(World[i][33]);
		R.setV34(World[i][34]);
		R.setV35(World[i][35]);
		R.setV36(World[i][36]);
		R.setV37(World[i][37]);
		R.setV38(World[i][38]);
		R.setV39(World[i][39]);
		R.setV40(World[i][40]);
		R.setV41(World[i][41]);
		R.setV42(World[i][42]);
		R.setV43(World[i][43]);
		R.setV44(World[i][44]);
		R.setV45(World[i][45]);
		R.setV46(World[i][46]);
		R.setV47(World[i][47]);
		R.setV48(World[i][48]);
		R.setV49(World[i][49]);

	} // end buildCurrentRoomSample(i)
	private static void resetRoomsinZoneSample(zone z0ne) {
		// This seems to work properly
		// attempts to reset all the rooms in the passed zone

		z0ne.rm00.resetRoom();
		z0ne.rm01.resetRoom();
		z0ne.rm02.resetRoom();
		z0ne.rm03.resetRoom();
		z0ne.rm04.resetRoom();
		z0ne.rm05.resetRoom();
		z0ne.rm06.resetRoom();
		z0ne.rm07.resetRoom();
		z0ne.rm08.resetRoom();
		z0ne.rm09.resetRoom();

		z0ne.rm10.resetRoom();
		z0ne.rm11.resetRoom();
		z0ne.rm12.resetRoom();
		z0ne.rm13.resetRoom();
		z0ne.rm14.resetRoom();
		z0ne.rm15.resetRoom();
		z0ne.rm16.resetRoom();
		z0ne.rm17.resetRoom();
		z0ne.rm18.resetRoom();
		z0ne.rm19.resetRoom();

		z0ne.rm20.resetRoom();
		z0ne.rm21.resetRoom();
		z0ne.rm22.resetRoom();
		z0ne.rm23.resetRoom();
		z0ne.rm24.resetRoom();
		z0ne.rm25.resetRoom();
		z0ne.rm26.resetRoom();
		z0ne.rm27.resetRoom();
		z0ne.rm28.resetRoom();
		z0ne.rm29.resetRoom();

		z0ne.rm30.resetRoom();
		z0ne.rm31.resetRoom();
		z0ne.rm32.resetRoom();
		z0ne.rm33.resetRoom();
		z0ne.rm34.resetRoom();
		z0ne.rm35.resetRoom();
		z0ne.rm36.resetRoom();
		z0ne.rm37.resetRoom();
		z0ne.rm38.resetRoom();
		z0ne.rm39.resetRoom();

		z0ne.rm40.resetRoom();
		z0ne.rm41.resetRoom();
		z0ne.rm42.resetRoom();
		z0ne.rm43.resetRoom();
		z0ne.rm44.resetRoom();
		z0ne.rm45.resetRoom();
		z0ne.rm46.resetRoom();
		z0ne.rm47.resetRoom();
		z0ne.rm48.resetRoom();
		z0ne.rm49.resetRoom();

		z0ne.rm50.resetRoom();
		z0ne.rm51.resetRoom();
		z0ne.rm52.resetRoom();
		z0ne.rm53.resetRoom();
		z0ne.rm54.resetRoom();
		z0ne.rm55.resetRoom();
		z0ne.rm56.resetRoom();
		z0ne.rm57.resetRoom();
		z0ne.rm58.resetRoom();
		z0ne.rm59.resetRoom();

		z0ne.rm60.resetRoom();
		z0ne.rm61.resetRoom();
		z0ne.rm62.resetRoom();
		z0ne.rm63.resetRoom();
		z0ne.rm64.resetRoom();
		z0ne.rm65.resetRoom();
		z0ne.rm66.resetRoom();
		z0ne.rm67.resetRoom();
		z0ne.rm68.resetRoom();
		z0ne.rm69.resetRoom();

		z0ne.rm70.resetRoom();
		z0ne.rm71.resetRoom();
		z0ne.rm72.resetRoom();
		z0ne.rm73.resetRoom();
		z0ne.rm74.resetRoom();
		z0ne.rm75.resetRoom();
		z0ne.rm76.resetRoom();
		z0ne.rm77.resetRoom();
		z0ne.rm78.resetRoom();
		z0ne.rm79.resetRoom();

		z0ne.rm80.resetRoom();
		z0ne.rm81.resetRoom();
		z0ne.rm82.resetRoom();
		z0ne.rm83.resetRoom();
		z0ne.rm84.resetRoom();
		z0ne.rm85.resetRoom();
		z0ne.rm86.resetRoom();
		z0ne.rm87.resetRoom();
		z0ne.rm88.resetRoom();
		z0ne.rm89.resetRoom();

		z0ne.rm90.resetRoom();
		z0ne.rm91.resetRoom();
		z0ne.rm92.resetRoom();
		z0ne.rm93.resetRoom();
		z0ne.rm94.resetRoom();
		z0ne.rm95.resetRoom();
		z0ne.rm96.resetRoom();
		z0ne.rm97.resetRoom();
		z0ne.rm98.resetRoom();
		z0ne.rm99.resetRoom();

	}// end resetRoomsinZoneSample

	private static void loadMobinRoominZoneSample(zone z0ne, room r00m, mob m0b, int mNum) {
		// //loadMob works just fine? why am I remaking it?
		// TODO		
	} // end loadMobinRoomZoneSample(z,r,m,i)
	private static void loadMobinRoomSample(room r00m, mob m0b, int mNum) {
		// //loadMob works just fine? why am I remaking it?
		// TODO			
	}// end loadMobinRoomSample(r,m,i)
	private static void loadRoominZoneSample(zone z0ne, room r00m, int rNum) {
		//TODO
		// load rNum to r00m in z0ne

		// load the z0ne?
		int zid = z0ne.getZoneNum();
		if (zid<=nextAvailZone) {
			loadZoneSample(z0ne, zid);
		}


		room loadr00m = new room();
		loadr00m.resetRoom();
		loadr00m = r00m;
		loadr00m.setRoomNum(rNum);


		loadr00m.setRoomName(World[rNum][1]);
		loadr00m.setRoomShortDesc(World[rNum][2]);
		loadr00m.setRoomLongDesc(World[rNum][3]);
		loadr00m.setExitN(Integer.parseInt(World[rNum][4]));
		loadr00m.setExitNE(Integer.parseInt(World[rNum][5]));
		loadr00m.setExitE(Integer.parseInt(World[rNum][6]));
		loadr00m.setExitSE(Integer.parseInt(World[rNum][7]));
		loadr00m.setExitS(Integer.parseInt(World[rNum][8]));
		loadr00m.setExitSW(Integer.parseInt(World[rNum][9]));
		loadr00m.setExitW(Integer.parseInt(World[rNum][10]));
		loadr00m.setExitNW(Integer.parseInt(World[rNum][11]));
		loadr00m.setExitU(Integer.parseInt(World[rNum][12]));
		loadr00m.setExitD(Integer.parseInt(World[rNum][13]));
		loadr00m.setMobsInRoom(World[rNum][14].split(", "));
		loadr00m.setObjsInRoom(World[rNum][15].split(", "));
		loadr00m.setLit(Integer.parseInt(World[rNum][16]));
		loadr00m.setCamp(Integer.parseInt(World[rNum][17]));
		loadr00m.setRent(Integer.parseInt(World[rNum][18]));
		loadr00m.setInside(Integer.parseInt(World[rNum][19]));
		loadr00m.setTerrain(Integer.parseInt(World[rNum][20]));
		loadr00m.setBank(Integer.parseInt(World[rNum][21]));

		loadr00m.setdNStatus(World[rNum][22]);
		loadr00m.setdNEStatus(World[rNum][23]);
		loadr00m.setdEStatus(World[rNum][24]);
		loadr00m.setdSEStatus(World[rNum][25]);
		loadr00m.setdSStatus(World[rNum][26]);
		loadr00m.setdSWStatus(World[rNum][27]);
		loadr00m.setdWStatus(World[rNum][28]);
		loadr00m.setdNWStatus(World[rNum][29]);
		loadr00m.setdUStatus(World[rNum][30]);
		loadr00m.setdDStatus(World[rNum][31]);

		loadr00m.setV32(World[rNum][32]);
		loadr00m.setV33(World[rNum][33]);
		loadr00m.setV34(World[rNum][34]);
		loadr00m.setV35(World[rNum][35]);
		loadr00m.setV36(World[rNum][36]);
		loadr00m.setV37(World[rNum][37]);
		loadr00m.setV38(World[rNum][38]);
		loadr00m.setV39(World[rNum][39]);
		loadr00m.setV40(World[rNum][40]);
		loadr00m.setV41(World[rNum][41]);
		loadr00m.setV42(World[rNum][42]);
		loadr00m.setV43(World[rNum][43]);
		loadr00m.setV44(World[rNum][44]);
		loadr00m.setV45(World[rNum][45]);
		loadr00m.setV46(World[rNum][46]);
		loadr00m.setV47(World[rNum][47]);
		loadr00m.setV48(World[rNum][48]);
		loadr00m.setV49(World[rNum][49]);

	}// end loadRoomSample
	private static void createZoneSampler() {
		// TODO
		// attempts to Asks the user if they are making a new zone, or editing existing zone
		// if zone ID exists, go to editZone(zid) orif else create a new zone
		System.out.println("What zone are you attempting to edit?");
		int tzoneNum = input.nextInt(0);

		if(tzoneNum<=nextAvailZone) {
			editZoneSampler(tzoneNum);
		}
		else {
			System.out.println("That zone does not exist, creating the next available zone");
			nextAvailZone++;
			int newZone = nextAvailZone;
			createZoneSample(newZone);;
		}
	} // end createZoneSampler
	private static void createZoneSample(int z) {
		// TODO
		// to be used with createZoneSampler()
		// creates a new zone
		// int newlyMadeZone = nextAvailZone;
		// editingZone.resetZone();
		// editingZone.setZoneNum(newlyMadeZone);
		// nextAvailZone++;

		// ...
		// dialog to fill in owner and name?

	} // end createZoneSample
	private static void editZoneSampler(int zid) {
		// TODO
		// supposed to started the editor for the zones
		// edits an existing zone
		int zoneToEdit = zid;
		editingZone.resetZone();

		if (zoneToEdit<nextAvailZone) {
			// load the editingZone with the zone to Edit
			loadZoneSample(editingZone,zoneToEdit);

			// add some more stuff editor stuffs here? 


		}
		else {
			// no such zone
			System.out.println("No such zone exists to be able do edit");
		}
	}// end editZoneSampler()

	private static void loadZoneSample(zone z, int zid) {
		// TODO
		// load/reload a zone on demand
		// 
		if (zid<=nextAvailZone) {
			int zonetoLoadNumber = zid;
			z.setZoneNum(zonetoLoadNumber);

			// for all rooms in World[][] that have zid, set them into rm's for the zone z
			// pull info from zid's/rm# zonescripts ? 

			// z.rm00.setRoomNum(...);
			//
			//			
			//
			// z.rm99.setRoomNum();

		}
		else {
			System.out.println("Not a valid zone number.");
		}
	} // endloadZoneZample

	private static void unloadZoneSample(zone uZone, int zid) {
		// TODO
		// this is supposed to unload zone to free up memory?
		// cannot be used on the zone the player is currently in!
		int zoneToUnload  = 0;
		if (uZone.getZoneNum()==zid) {
			zoneToUnload = zid;
		}

		// uZone=null;
		if (zoneToUnload!=curZNum) {  // zoneToUnload cannot equal the curZNum (current zone number)
			// if 
			System.out.println("Successfully unloaded zone: " + zoneToUnload + " " + uZone.getZoneName());
			uZone=null; // set the zone to null

		}
		else {
			// you can't unload it if you are inside it!!
			System.out.println("Unable to unload the zone you are currently inside of: " + zoneToUnload);
		}
	} // end unloadZoneSample


	private static void createRoomSimple() {
		// 

		System.out.println("Attempting to create a new room...");
		System.out.println("This ");
		newRoom = new room();
		newRoom.resetRoom();
		newRoom.setRoomNum(nextAvailRoom); //
		//	wsave();

		nextAvailRoom++;
		System.out.println("The next available room is: " + nextAvailRoom);
		newRoom.returnRoomInfo2();
		editRoom();

	} // createRoomSimple()




	private static void castRegen() {
		// casts Regen on the player
		int regenManaCost = 60;	

		System.out.println("Casting Regen on " + player1.getPlayerName());
		player1.setPlayerMP(player1.getPlayerMP() - regenManaCost);
		regenCast = 1; // starts timer in Moon3Task(0 and calls regenHeal(0
		//regenHeal(); // heals player for x over y
		// moved to Moon3Task to be Hot on the Moon timer (multiple times per day)

	} // end castRegen()


	private static void castRejuv() {
		// casts Rejuvinate on the player
		int rejuvManaCost = 50;	

		System.out.println("Casting Rejuv on " + player1.getPlayerName());
		player1.setPlayerMP(player1.getPlayerMP() - rejuvManaCost);
		rejuvCast = 1; // starts timer in Moon2Task() and calls rejuvHeal();
		// rejuvHeal(); // heals player for xx over yy
		// moved to Moon2Task to be HoT on the Moon timer (multiple times per day)
	} // end castRejuv()


	private static void castRegrowth() {
		// casts regrowth on the player
		// was split in 2 pcs so that other pc can be used for Potions

		int regrowthManaCost = 50;	

		System.out.println("Casting Regrowth on " + player1.getPlayerName());
		player1.setPlayerMP(player1.getPlayerMP() - regrowthManaCost);
		regrowthCast = 1; // starts timer in Moon1Task() and calls regrowthHeal()
		// 	regrowthHeal(); // heals player for xxx over yyy
		// moved to Moon1Task() to be HoT on Moon timer (mulitple times per day)
	} // end castRegrown()


	private static void sortPlayerInventory() {
		// attempts to "sort" out the 0 spaces in the player's inventory

		// moves inventory spaces to "left" or towards 0 

		int[] array = new int[30];
		array[0]= pinv0.getObjNum();
		array[1]= pinv1.getObjNum();
		array[2]= pinv2.getObjNum();
		array[3]= pinv3.getObjNum();
		array[4]= pinv4.getObjNum();
		array[5]= pinv5.getObjNum();
		array[6]= pinv6.getObjNum();
		array[7]= pinv7.getObjNum();
		array[8]= pinv8.getObjNum();
		array[9]= pinv9.getObjNum();

		array[10]= pinv10.getObjNum();
		array[11]= pinv11.getObjNum();
		array[12]= pinv12.getObjNum();
		array[13]= pinv13.getObjNum();
		array[14]= pinv14.getObjNum();
		array[15]= pinv15.getObjNum();
		array[16]= pinv16.getObjNum();
		array[17]= pinv17.getObjNum();
		array[18]= pinv18.getObjNum();
		array[19]= pinv19.getObjNum();

		array[20]= pinv20.getObjNum();
		array[21]= pinv21.getObjNum();
		array[22]= pinv22.getObjNum();
		array[23]= pinv23.getObjNum();
		array[24]= pinv24.getObjNum();
		array[25]= pinv25.getObjNum();
		array[26]= pinv26.getObjNum();
		array[27]= pinv27.getObjNum();
		array[28]= pinv28.getObjNum();
		array[29]= pinv29.getObjNum();

		System.out.println(java.util.Arrays.toString(array));		
		int writePos = 0;
		for (int readPos = 0; readPos < array.length; ++readPos) {
			if (0 != array[readPos]) {
				if (readPos != writePos) {
					array[writePos] = array[readPos];
					array[readPos] = 0; 
				}
				++writePos;
			}
		}

		System.out.println(java.util.Arrays.toString(array));

		loadObject(pinv0, array[0]);
		pinv0.setObjNum(array[0]);
		playerinventory.setPmobInv0(array[0]);
		loadObject(pinv1, array[1]);
		pinv1.setObjNum(array[1]);
		playerinventory.setPmobInv1(array[1]);			
		loadObject(pinv2, array[2]);
		pinv2.setObjNum(array[2]);
		playerinventory.setPmobInv2(array[2]);
		loadObject(pinv3, array[3]);
		pinv3.setObjNum(array[3]);
		playerinventory.setPmobInv3(array[3]);
		loadObject(pinv4, array[4]);
		pinv4.setObjNum(array[4]);
		playerinventory.setPmobInv4(array[4]);
		loadObject(pinv5, array[5]);
		pinv5.setObjNum(array[5]);
		playerinventory.setPmobInv5(array[5]);
		loadObject(pinv6, array[6]);
		pinv6.setObjNum(array[6]);
		playerinventory.setPmobInv6(array[6]);			
		loadObject(pinv7, array[7]);
		pinv7.setObjNum(array[7]);
		playerinventory.setPmobInv7(array[7]);
		loadObject(pinv8, array[8]);
		pinv8.setObjNum(array[8]);
		playerinventory.setPmobInv8(array[8]);
		loadObject(pinv9, array[9]);
		pinv9.setObjNum(array[9]);
		playerinventory.setPmobInv9(array[9]);

		loadObject(pinv10, array[10]);
		pinv10.setObjNum(array[10]);
		playerinventory.setPmobInv10(array[10]);
		loadObject(pinv11, array[11]);
		pinv11.setObjNum(array[11]);
		playerinventory.setPmobInv11(array[11]);			
		loadObject(pinv12, array[21]);
		pinv12.setObjNum(array[12]);
		playerinventory.setPmobInv12(array[12]);
		loadObject(pinv13, array[13]);
		pinv13.setObjNum(array[13]);
		playerinventory.setPmobInv13(array[13]);
		loadObject(pinv14, array[14]);
		pinv14.setObjNum(array[14]);
		playerinventory.setPmobInv14(array[14]);
		loadObject(pinv15, array[15]);
		pinv15.setObjNum(array[15]);
		playerinventory.setPmobInv15(array[15]);
		loadObject(pinv16, array[16]);
		pinv16.setObjNum(array[16]);
		playerinventory.setPmobInv16(array[16]);			
		loadObject(pinv17, array[17]);
		pinv17.setObjNum(array[17]);
		playerinventory.setPmobInv17(array[17]);
		loadObject(pinv18, array[18]);
		pinv18.setObjNum(array[18]);
		playerinventory.setPmobInv8(array[18]);
		loadObject(pinv19, array[19]);
		pinv19.setObjNum(array[19]);
		playerinventory.setPmobInv19(array[19]);

		loadObject(pinv20, array[20]);
		pinv20.setObjNum(array[20]);
		playerinventory.setPmobInv20(array[20]);
		loadObject(pinv21, array[21]);
		pinv21.setObjNum(array[21]);
		playerinventory.setPmobInv21(array[21]);			
		loadObject(pinv22, array[22]);
		pinv22.setObjNum(array[22]);
		playerinventory.setPmobInv22(array[22]);
		loadObject(pinv23, array[23]);
		pinv23.setObjNum(array[23]);
		playerinventory.setPmobInv23(array[23]);
		loadObject(pinv24, array[24]);
		pinv24.setObjNum(array[24]);
		playerinventory.setPmobInv24(array[24]);
		loadObject(pinv25, array[25]);
		pinv25.setObjNum(array[25]);
		playerinventory.setPmobInv25(array[25]);
		loadObject(pinv26, array[26]);
		pinv26.setObjNum(array[26]);
		playerinventory.setPmobInv26(array[26]);			
		loadObject(pinv27, array[27]);
		pinv27.setObjNum(array[27]);
		playerinventory.setPmobInv27(array[27]);
		loadObject(pinv28, array[28]);
		pinv28.setObjNum(array[28]);
		playerinventory.setPmobInv28(array[28]);
		loadObject(pinv29, array[29]);
		pinv29.setObjNum(array[29]);
		playerinventory.setPmobInv29(array[29]);
		//		psave();   // psave is optional was here for testing


	} // end sortPlayerInventory()




	private static void setRoomBank() {
		// 
		newRoom.returnRoomInfo2();
		System.out.println("Current bank setting: " + newRoom.getBank());
		System.out.println("Turning this on will allow the player to exchange coins.");

		System.out.println(editor + "Editor");
		int iinput = input.nextInt();
		newRoom.setTerrain(iinput);
		newRoom.returnRoomInfo2();

	} // end setRoomBank()


	private static void setRoomLit() {
		// 

		newRoom.returnRoomInfo2();

		System.out.println("Current lit setting: " + newRoom.getLit());
		System.out.println("1 = Is Lit, 0 = Is not Lit");

		System.out.println(editor + "Editor");
		int iinput = input.nextInt();
		newRoom.setLit(iinput);
		newRoom.returnRoomInfo2();

	} // end setRoomLit(0




	private static void setRoomRent() {
		// 

		newRoom.returnRoomInfo2();
		System.out.println("Current rent setting: " + newRoom.getRent());
		System.out.println("1 = Can Rent, 0 = Cannot Rent");
		System.out.println(editor + "Editor");
		int iinput = input.nextInt();
		newRoom.setRent(iinput);
		newRoom.returnRoomInfo2();

	} // end setRoomRent()




	private static void setRoomCamp() {
		// 

		newRoom.returnRoomInfo2();
		System.out.println("Current camp setting: " + newRoom.getCamp());
		System.out.println(" 0 = Cannot Camp, 1 = Can Camp,");
		System.out.println(editor + "Editor");
		int iinput = input.nextInt();
		newRoom.setCamp(iinput);
		newRoom.returnRoomInfo2();

	} // end setRoomCamp()




	private static void setRoomIndoor() {
		// 

		newRoom.returnRoomInfo2();
		System.out.println("Current indoor setting: " + newRoom.getInside());
		System.out.println("Enter a new indoor setting");
		System.out.println("0 = Outdoors, 1 = Indoors");
		System.out.println(editor + "Editor");
		int iinput = input.nextInt();
		newRoom.setInside(iinput);
		newRoom.returnRoomInfo2();

	}




	private static void setRoomName() {
		// sets the room name
		newRoom.returnRoomInfo2();
		System.out.println("Current room name: " + newRoom.getRoomName());
		System.out.println("Enter new room name.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		newRoom.setRoomName(kinput);
		newRoom.returnRoomInfo2();
	} // end set RoomName()


	private static void drinkDrink() {
		// drinks the drink-type object to restore mana
		System.out.println("Which item do you wish to drink? Pick the inventory slot of the drink item.");
		kinput = input.nextLine();
		switch(kinput) {
		// pinvo0-29
		// 0-9
		case "0":{
			if (pinv0.getObjType().equals("drink")) {					
				if (pinv0.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv0.getMpRestore());
					System.out.println("Your drink of " + pinv0.getObjName() + " provided you with " + pinv0.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv0.resetObject();
					playerinventory.setPmobInv0(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "0"
		case "1":{
			if (pinv1.getObjType().equals("drink")) {					
				if (pinv1.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv1.getMpRestore());
					System.out.println("Your drink of " + pinv1.getObjName() + " provided you with " + pinv1.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv1.resetObject();
					playerinventory.setPmobInv1(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "1"
		case "2":{
			if (pinv2.getObjType().equals("drink")) {					
				if (pinv2.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv2.getMpRestore());
					System.out.println("Your drink of " + pinv2.getObjName() + " provided you with " + pinv2.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv2.resetObject();
					playerinventory.setPmobInv2(0);
				}
			} 
			else { System.out.println("That is not a drink."); } 
			break;
		} // end case "2"
		case "3":{
			if (pinv3.getObjType().equals("drink")) {					
				if (pinv3.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv3.getMpRestore());
					System.out.println("Your drink of " + pinv3.getObjName() + " provided you with " + pinv3.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv3.resetObject();
					playerinventory.setPmobInv3(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "3"
		case "4":{
			if (pinv4.getObjType().equals("drink")) {					
				if (pinv4.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv4.getMpRestore());
					System.out.println("Your drink of " + pinv4.getObjName() + " provided you with " + pinv4.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv4.resetObject();
					playerinventory.setPmobInv4(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "4"
		case "5":{
			if (pinv5.getObjType().equals("drink")) {					
				if (pinv5.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv5.getMpRestore());
					System.out.println("Your drink of " + pinv5.getObjName() + " provided you with " + pinv5.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv5.resetObject();
					playerinventory.setPmobInv5(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "5"
		case "6":{
			if (pinv6.getObjType().equals("drink")) {					
				if (pinv6.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv6.getMpRestore());
					System.out.println("Your drink of " + pinv6.getObjName() + " provided you with " + pinv6.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv6.resetObject();
					playerinventory.setPmobInv6(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "6"
		case "7":{
			if (pinv7.getObjType().equals("drink")) {					
				if (pinv7.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv7.getMpRestore());
					System.out.println("Your drink of " + pinv7.getObjName() + " provided you with " + pinv7.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv7.resetObject();
					playerinventory.setPmobInv7(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "7"
		case "8":{
			if (pinv8.getObjType().equals("drink")) {					
				if (pinv8.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv8.getMpRestore());
					System.out.println("Your drink of " + pinv8.getObjName() + " provided you with " + pinv8.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv8.resetObject();
					playerinventory.setPmobInv8(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "8"
		case "9":{
			if (pinv9.getObjType().equals("drink")) {					
				if (pinv9.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv9.getMpRestore());
					System.out.println("Your drink of " + pinv9.getObjName() + " provided you with " + pinv9.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv9.resetObject();
					playerinventory.setPmobInv9(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "9"
		// 10-19
		case "10":{
			if (pinv10.getObjType().equals("drink")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getMpRestore());
					System.out.println("Your drink of " + pinv10.getObjName() + " provided you with " + pinv10.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "10"
		case "11":{
			if (pinv11.getObjType().equals("drink")) {					
				if (pinv11.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv11.getMpRestore());
					System.out.println("Your drink of " + pinv11.getObjName() + " provided you with " + pinv11.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv11.resetObject();
					playerinventory.setPmobInv11(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "11"
		case "12":{
			if (pinv12.getObjType().equals("drink")) {					
				if (pinv12.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv12.getMpRestore());
					System.out.println("Your drink of " + pinv12.getObjName() + " provided you with " + pinv12.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv12.resetObject();
					playerinventory.setPmobInv12(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "12"
		case "13":{
			if (pinv13.getObjType().equals("drink")) {					
				if (pinv13.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv13.getMpRestore());
					System.out.println("Your drink of " + pinv13.getObjName() + " provided you with " + pinv13.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv13(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "13"
		case "14":{
			if (pinv14.getObjType().equals("drink")) {					
				if (pinv14.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv14.getMpRestore());
					System.out.println("Your drink of " + pinv14.getObjName() + " provided you with " + pinv14.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv14.resetObject();
					playerinventory.setPmobInv14(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "14"
		case "15":{
			if (pinv15.getObjType().equals("drink")) {					
				if (pinv15.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv15.getMpRestore());
					System.out.println("Your drink of " + pinv15.getObjName() + " provided you with " + pinv15.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv15(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "15"
		case "16":{
			if (pinv16.getObjType().equals("drink")) {					
				if (pinv16.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv16.getMpRestore());
					System.out.println("Your drink of " + pinv16.getObjName() + " provided you with " + pinv16.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv16.resetObject();
					playerinventory.setPmobInv16(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "16"
		case "17":{
			if (pinv17.getObjType().equals("drink")) {					
				if (pinv17.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv17.getMpRestore());
					System.out.println("Your drink of " + pinv17.getObjName() + " provided you with " + pinv17.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv17.resetObject();
					playerinventory.setPmobInv17(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "17"
		case "18":{
			if (pinv18.getObjType().equals("drink")) {					
				if (pinv18.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv18.getMpRestore());
					System.out.println("Your drink of " + pinv18.getObjName() + " provided you with " + pinv18.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv18.resetObject();
					playerinventory.setPmobInv18(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "18"
		case "19":{
			if (pinv19.getObjType().equals("drink")) {					
				if (pinv19.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv19.getMpRestore());
					System.out.println("Your drink of " + pinv19.getObjName() + " provided you with " + pinv19.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv19(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "19"
		// 10-19
		case "20":{
			if (pinv10.getObjType().equals("drink")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getMpRestore());
					System.out.println("Your drink of " + pinv10.getObjName() + " provided you with " + pinv10.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "10"
		case "21":{
			if (pinv21.getObjType().equals("drink")) {					
				if (pinv21.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv21.getMpRestore());
					System.out.println("Your drink of " + pinv21.getObjName() + " provided you with " + pinv21.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv21.resetObject();
					playerinventory.setPmobInv21(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "21"
		case "22":{
			if (pinv22.getObjType().equals("drink")) {					
				if (pinv22.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv22.getMpRestore());
					System.out.println("Your drink of " + pinv22.getObjName() + " provided you with " + pinv22.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv22.resetObject();
					playerinventory.setPmobInv22(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "22"
		case "23":{
			if (pinv23.getObjType().equals("drink")) {					
				if (pinv23.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv23.getMpRestore());
					System.out.println("Your drink of " + pinv23.getObjName() + " provided you with " + pinv23.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv23(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "23"
		case "24":{
			if (pinv24.getObjType().equals("drink")) {					
				if (pinv24.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv24.getMpRestore());
					System.out.println("Your drink of " + pinv24.getObjName() + " provided you with " + pinv24.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv24.resetObject();
					playerinventory.setPmobInv24(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "24"
		case "25":{
			if (pinv25.getObjType().equals("drink")) {					
				if (pinv25.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv25.getMpRestore());
					System.out.println("Your drink of " + pinv25.getObjName() + " provided you with " + pinv25.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv25(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "25"
		case "26":{
			if (pinv26.getObjType().equals("drink")) {					
				if (pinv26.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv26.getMpRestore());
					System.out.println("Your drink of " + pinv26.getObjName() + " provided you with " + pinv26.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv26.resetObject();
					playerinventory.setPmobInv26(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "26"
		case "27":{
			if (pinv27.getObjType().equals("drink")) {					
				if (pinv27.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv27.getMpRestore());
					System.out.println("Your drink of " + pinv27.getObjName() + " provided you with " + pinv27.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv27.resetObject();
					playerinventory.setPmobInv27(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "27"
		case "28":{
			if (pinv28.getObjType().equals("drink")) {					
				if (pinv28.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv28.getMpRestore());
					System.out.println("Your drink of " + pinv28.getObjName() + " provided you with " + pinv28.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv28.resetObject();
					playerinventory.setPmobInv28(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "28"
		case "29":{
			if (pinv29.getObjType().equals("drink")) {					
				if (pinv29.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv29.getMpRestore());
					System.out.println("Your drink of " + pinv29.getObjName() + " provided you with " + pinv29.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv29(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "29"

		// slot 0-9
		case "slot 0":{
			if (pinv0.getObjType().equals("drink")) {					
				if (pinv0.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv0.getMpRestore());
					System.out.println("Your drink of " + pinv0.getObjName() + " provided you with " + pinv0.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv0.resetObject();
					playerinventory.setPmobInv0(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "0"
		case "slot 1":{
			if (pinv1.getObjType().equals("drink")) {					
				if (pinv1.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv1.getMpRestore());
					System.out.println("Your drink of " + pinv1.getObjName() + " provided you with " + pinv1.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv1.resetObject();
					playerinventory.setPmobInv1(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "1"
		case "slot 2":{
			if (pinv2.getObjType().equals("drink")) {					
				if (pinv2.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv2.getMpRestore());
					System.out.println("Your drink of " + pinv2.getObjName() + " provided you with " + pinv2.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv2.resetObject();
					playerinventory.setPmobInv2(0);
				}
			} 
			else { System.out.println("That is not a drink."); } 
			break;
		} // end case "2"
		case "slot 3":{
			if (pinv3.getObjType().equals("drink")) {					
				if (pinv3.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv3.getMpRestore());
					System.out.println("Your drink of " + pinv3.getObjName() + " provided you with " + pinv3.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv3.resetObject();
					playerinventory.setPmobInv3(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "3"
		case "slot 4":{
			if (pinv4.getObjType().equals("drink")) {					
				if (pinv4.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv4.getMpRestore());
					System.out.println("Your drink of " + pinv4.getObjName() + " provided you with " + pinv4.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv4.resetObject();
					playerinventory.setPmobInv4(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "4"
		case "slot 5":{
			if (pinv5.getObjType().equals("drink")) {					
				if (pinv5.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv5.getMpRestore());
					System.out.println("Your drink of " + pinv5.getObjName() + " provided you with " + pinv5.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv5.resetObject();
					playerinventory.setPmobInv5(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "5"
		case "slot 6":{
			if (pinv6.getObjType().equals("drink")) {					
				if (pinv6.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv6.getMpRestore());
					System.out.println("Your drink of " + pinv6.getObjName() + " provided you with " + pinv6.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv6.resetObject();
					playerinventory.setPmobInv6(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "6"
		case "slot 7":{
			if (pinv7.getObjType().equals("drink")) {					
				if (pinv7.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv7.getMpRestore());
					System.out.println("Your drink of " + pinv7.getObjName() + " provided you with " + pinv7.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv7.resetObject();
					playerinventory.setPmobInv7(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "7"
		case "slot 8":{
			if (pinv8.getObjType().equals("drink")) {					
				if (pinv8.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv8.getMpRestore());
					System.out.println("Your drink of " + pinv8.getObjName() + " provided you with " + pinv8.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv8.resetObject();
					playerinventory.setPmobInv8(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "8"
		case "slot 9":{
			if (pinv9.getObjType().equals("drink")) {					
				if (pinv9.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv9.getMpRestore());
					System.out.println("Your drink of " + pinv9.getObjName() + " provided you with " + pinv9.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}

					pinv9.resetObject();
					playerinventory.setPmobInv9(0);
				}
			} 
			else {
				System.out.println("That is not a drink.");
			}
			break;
		} // end case "9"
		// 10-19
		case "slot 10":{
			if (pinv10.getObjType().equals("drink")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getMpRestore());
					System.out.println("Your drink of " + pinv10.getObjName() + " provided you with " + pinv10.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "10"
		case "slot 11":{
			if (pinv11.getObjType().equals("drink")) {					
				if (pinv11.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv11.getMpRestore());
					System.out.println("Your drink of " + pinv11.getObjName() + " provided you with " + pinv11.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv11.resetObject();
					playerinventory.setPmobInv11(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "11"
		case "slot 12":{
			if (pinv12.getObjType().equals("drink")) {					
				if (pinv12.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv12.getMpRestore());
					System.out.println("Your drink of " + pinv12.getObjName() + " provided you with " + pinv12.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv12.resetObject();
					playerinventory.setPmobInv12(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "12"
		case "slot 13":{
			if (pinv13.getObjType().equals("drink")) {					
				if (pinv13.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv13.getMpRestore());
					System.out.println("Your drink of " + pinv13.getObjName() + " provided you with " + pinv13.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv13(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "13"
		case "slot 14":{
			if (pinv14.getObjType().equals("drink")) {					
				if (pinv14.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv14.getMpRestore());
					System.out.println("Your drink of " + pinv14.getObjName() + " provided you with " + pinv14.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv14.resetObject();
					playerinventory.setPmobInv14(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "14"
		case "slot 15":{
			if (pinv15.getObjType().equals("drink")) {					
				if (pinv15.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv15.getMpRestore());
					System.out.println("Your drink of " + pinv15.getObjName() + " provided you with " + pinv15.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv15(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "15"
		case "slot 16":{
			if (pinv16.getObjType().equals("drink")) {					
				if (pinv16.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv16.getMpRestore());
					System.out.println("Your drink of " + pinv16.getObjName() + " provided you with " + pinv16.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv16.resetObject();
					playerinventory.setPmobInv16(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "16"
		case "slot 17":{
			if (pinv17.getObjType().equals("drink")) {					
				if (pinv17.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv17.getMpRestore());
					System.out.println("Your drink of " + pinv17.getObjName() + " provided you with " + pinv17.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv17.resetObject();
					playerinventory.setPmobInv17(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "17"
		case "slot 18":{
			if (pinv18.getObjType().equals("drink")) {					
				if (pinv18.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv18.getMpRestore());
					System.out.println("Your drink of " + pinv18.getObjName() + " provided you with " + pinv18.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv18.resetObject();
					playerinventory.setPmobInv18(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "18"
		case "slot 19":{
			if (pinv19.getObjType().equals("drink")) {					
				if (pinv19.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv19.getMpRestore());
					System.out.println("Your drink of " + pinv19.getObjName() + " provided you with " + pinv19.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv19(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "19"
		// 10-19
		case "slot 20":{
			if (pinv10.getObjType().equals("drink")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getMpRestore());
					System.out.println("Your drink of " + pinv10.getObjName() + " provided you with " + pinv10.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "10"
		case "slot 21":{
			if (pinv21.getObjType().equals("drink")) {					
				if (pinv21.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv21.getMpRestore());
					System.out.println("Your drink of " + pinv21.getObjName() + " provided you with " + pinv21.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv21.resetObject();
					playerinventory.setPmobInv21(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "21"
		case "slot 22":{
			if (pinv22.getObjType().equals("drink")) {					
				if (pinv22.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv22.getMpRestore());
					System.out.println("Your drink of " + pinv22.getObjName() + " provided you with " + pinv22.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv22.resetObject();
					playerinventory.setPmobInv22(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "22"
		case "slot 23":{
			if (pinv23.getObjType().equals("drink")) {					
				if (pinv23.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv23.getMpRestore());
					System.out.println("Your drink of " + pinv23.getObjName() + " provided you with " + pinv23.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv23(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "23"
		case "slot 24":{
			if (pinv24.getObjType().equals("drink")) {					
				if (pinv24.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv24.getMpRestore());
					System.out.println("Your drink of " + pinv24.getObjName() + " provided you with " + pinv24.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv24.resetObject();
					playerinventory.setPmobInv24(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "24"
		case "slot 25":{
			if (pinv25.getObjType().equals("drink")) {					
				if (pinv25.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv25.getMpRestore());
					System.out.println("Your drink of " + pinv25.getObjName() + " provided you with " + pinv25.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv25(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "25"
		case "slot 26":{
			if (pinv26.getObjType().equals("drink")) {					
				if (pinv26.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv26.getMpRestore());
					System.out.println("Your drink of " + pinv26.getObjName() + " provided you with " + pinv26.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv26.resetObject();
					playerinventory.setPmobInv26(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "26"
		case "slot 27":{
			if (pinv27.getObjType().equals("drink")) {					
				if (pinv27.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv27.getMpRestore());
					System.out.println("Your drink of " + pinv27.getObjName() + " provided you with " + pinv27.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv27.resetObject();
					playerinventory.setPmobInv27(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "27"
		case "slot 28":{
			if (pinv28.getObjType().equals("drink")) {					
				if (pinv28.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv28.getMpRestore());
					System.out.println("Your drink of " + pinv28.getObjName() + " provided you with " + pinv28.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv28.resetObject();
					playerinventory.setPmobInv28(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "28"
		case "slot 29":{
			if (pinv29.getObjType().equals("drink")) {					
				if (pinv29.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv29.getMpRestore());
					System.out.println("Your drink of " + pinv29.getObjName() + " provided you with " + pinv29.getMpRestore() + " mana points.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your mana points feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv29(0);
				}
			} 
			else { System.out.println("That is not a drink."); }
			break;
		} // end case "29"


		default: {
			// they didnt enter a valid inventory slot, 0-29, slot 0-29
			break;
		}
		} // end switch 
	} // drinkDrink()

	private static void eatFood() {
		// 
		// enter food id from pinv (I used pinv2 for testing as a hand coded a food item into that inventory slot)
		System.out.println("Which item do you wish to eat? Pick the inventory slot of the food item.");
		kinput = input.nextLine();
		switch(kinput) {
		// pinvo0-29
		// 0-9
		case "0":{
			if (pinv0.getObjType().equals("food")) {					
				if (pinv0.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv0.getHpRestore());
					System.out.println("Your meal of " + pinv0.getObjName() + " provided you with " + pinv0.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv0.resetObject();
					playerinventory.setPmobInv0(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "0"
		case "1":{
			if (pinv1.getObjType().equals("food")) {					
				if (pinv1.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv1.getHpRestore());
					System.out.println("Your meal of " + pinv1.getObjName() + " provided you with " + pinv1.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv1.resetObject();
					playerinventory.setPmobInv1(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "1"
		case "2":{
			if (pinv2.getObjType().equals("food")) {					
				if (pinv2.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv2.getHpRestore());
					System.out.println("Your meal of " + pinv2.getObjName() + " provided you with " + pinv2.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv2.resetObject();
					playerinventory.setPmobInv2(0);
				}
			} 
			else { System.out.println("That is not a food."); } 
			break;
		} // end case "2"
		case "3":{
			if (pinv3.getObjType().equals("food")) {					
				if (pinv3.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv3.getHpRestore());
					System.out.println("Your meal of " + pinv3.getObjName() + " provided you with " + pinv3.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv3.resetObject();
					playerinventory.setPmobInv3(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "3"
		case "4":{
			if (pinv4.getObjType().equals("food")) {					
				if (pinv4.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv4.getHpRestore());
					System.out.println("Your meal of " + pinv4.getObjName() + " provided you with " + pinv4.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv4.resetObject();
					playerinventory.setPmobInv4(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "4"
		case "5":{
			if (pinv5.getObjType().equals("food")) {					
				if (pinv5.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv5.getHpRestore());
					System.out.println("Your meal of " + pinv5.getObjName() + " provided you with " + pinv5.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv5.resetObject();
					playerinventory.setPmobInv5(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "5"
		case "6":{
			if (pinv6.getObjType().equals("food")) {					
				if (pinv6.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv6.getHpRestore());
					System.out.println("Your meal of " + pinv6.getObjName() + " provided you with " + pinv6.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv6.resetObject();
					playerinventory.setPmobInv6(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "6"
		case "7":{
			if (pinv7.getObjType().equals("food")) {					
				if (pinv7.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv7.getHpRestore());
					System.out.println("Your meal of " + pinv7.getObjName() + " provided you with " + pinv7.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv7.resetObject();
					playerinventory.setPmobInv7(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "7"
		case "8":{
			if (pinv8.getObjType().equals("food")) {					
				if (pinv8.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv8.getHpRestore());
					System.out.println("Your meal of " + pinv8.getObjName() + " provided you with " + pinv8.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv8.resetObject();
					playerinventory.setPmobInv8(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "8"
		case "9":{
			if (pinv9.getObjType().equals("food")) {					
				if (pinv9.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv9.getHpRestore());
					System.out.println("Your meal of " + pinv9.getObjName() + " provided you with " + pinv9.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv9.resetObject();
					playerinventory.setPmobInv9(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "9"
		// 10-19
		case "10":{
			if (pinv10.getObjType().equals("food")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getHpRestore());
					System.out.println("Your meal of " + pinv10.getObjName() + " provided you with " + pinv10.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "10"
		case "11":{
			if (pinv11.getObjType().equals("food")) {					
				if (pinv11.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv11.getHpRestore());
					System.out.println("Your meal of " + pinv11.getObjName() + " provided you with " + pinv11.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv11.resetObject();
					playerinventory.setPmobInv11(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "11"
		case "12":{
			if (pinv12.getObjType().equals("food")) {					
				if (pinv12.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv12.getHpRestore());
					System.out.println("Your meal of " + pinv12.getObjName() + " provided you with " + pinv12.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv12.resetObject();
					playerinventory.setPmobInv12(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "12"
		case "13":{
			if (pinv13.getObjType().equals("food")) {					
				if (pinv13.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv13.getHpRestore());
					System.out.println("Your meal of " + pinv13.getObjName() + " provided you with " + pinv13.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv13(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "13"
		case "14":{
			if (pinv14.getObjType().equals("food")) {					
				if (pinv14.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv14.getHpRestore());
					System.out.println("Your meal of " + pinv14.getObjName() + " provided you with " + pinv14.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv14.resetObject();
					playerinventory.setPmobInv14(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "14"
		case "15":{
			if (pinv15.getObjType().equals("food")) {					
				if (pinv15.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv15.getHpRestore());
					System.out.println("Your meal of " + pinv15.getObjName() + " provided you with " + pinv15.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv15(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "15"
		case "16":{
			if (pinv16.getObjType().equals("food")) {					
				if (pinv16.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv16.getHpRestore());
					System.out.println("Your meal of " + pinv16.getObjName() + " provided you with " + pinv16.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv16.resetObject();
					playerinventory.setPmobInv16(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "16"
		case "17":{
			if (pinv17.getObjType().equals("food")) {					
				if (pinv17.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv17.getHpRestore());
					System.out.println("Your meal of " + pinv17.getObjName() + " provided you with " + pinv17.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv17.resetObject();
					playerinventory.setPmobInv17(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "17"
		case "18":{
			if (pinv18.getObjType().equals("food")) {					
				if (pinv18.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv18.getHpRestore());
					System.out.println("Your meal of " + pinv18.getObjName() + " provided you with " + pinv18.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv18.resetObject();
					playerinventory.setPmobInv18(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "18"
		case "19":{
			if (pinv19.getObjType().equals("food")) {					
				if (pinv19.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv19.getHpRestore());
					System.out.println("Your meal of " + pinv19.getObjName() + " provided you with " + pinv19.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv19(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "19"
		// 10-19
		case "20":{
			if (pinv10.getObjType().equals("food")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getHpRestore());
					System.out.println("Your meal of " + pinv10.getObjName() + " provided you with " + pinv10.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "10"
		case "21":{
			if (pinv21.getObjType().equals("food")) {					
				if (pinv21.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv21.getHpRestore());
					System.out.println("Your meal of " + pinv21.getObjName() + " provided you with " + pinv21.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv21.resetObject();
					playerinventory.setPmobInv21(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "21"
		case "22":{
			if (pinv22.getObjType().equals("food")) {					
				if (pinv22.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv22.getHpRestore());
					System.out.println("Your meal of " + pinv22.getObjName() + " provided you with " + pinv22.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv22.resetObject();
					playerinventory.setPmobInv22(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "22"
		case "23":{
			if (pinv23.getObjType().equals("food")) {					
				if (pinv23.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv23.getHpRestore());
					System.out.println("Your meal of " + pinv23.getObjName() + " provided you with " + pinv23.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv23(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "23"
		case "24":{
			if (pinv24.getObjType().equals("food")) {					
				if (pinv24.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv24.getHpRestore());
					System.out.println("Your meal of " + pinv24.getObjName() + " provided you with " + pinv24.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv24.resetObject();
					playerinventory.setPmobInv24(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "24"
		case "25":{
			if (pinv25.getObjType().equals("food")) {					
				if (pinv25.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv25.getHpRestore());
					System.out.println("Your meal of " + pinv25.getObjName() + " provided you with " + pinv25.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv25(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "25"
		case "26":{
			if (pinv26.getObjType().equals("food")) {					
				if (pinv26.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv26.getHpRestore());
					System.out.println("Your meal of " + pinv26.getObjName() + " provided you with " + pinv26.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv26.resetObject();
					playerinventory.setPmobInv26(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "26"
		case "27":{
			if (pinv27.getObjType().equals("food")) {					
				if (pinv27.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv27.getHpRestore());
					System.out.println("Your meal of " + pinv27.getObjName() + " provided you with " + pinv27.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv27.resetObject();
					playerinventory.setPmobInv27(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "27"
		case "28":{
			if (pinv28.getObjType().equals("food")) {					
				if (pinv28.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv28.getHpRestore());
					System.out.println("Your meal of " + pinv28.getObjName() + " provided you with " + pinv28.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv28.resetObject();
					playerinventory.setPmobInv28(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "28"
		case "29":{
			if (pinv29.getObjType().equals("food")) {					
				if (pinv29.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv29.getHpRestore());
					System.out.println("Your meal of " + pinv29.getObjName() + " provided you with " + pinv29.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv29(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "29"

		// slot 0-9
		case "slot 0":{
			if (pinv0.getObjType().equals("food")) {					
				if (pinv0.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv0.getHpRestore());
					System.out.println("Your meal of " + pinv0.getObjName() + " provided you with " + pinv0.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv0.resetObject();
					playerinventory.setPmobInv0(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "0"
		case "slot 1":{
			if (pinv1.getObjType().equals("food")) {					
				if (pinv1.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv1.getHpRestore());
					System.out.println("Your meal of " + pinv1.getObjName() + " provided you with " + pinv1.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv1.resetObject();
					playerinventory.setPmobInv1(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "1"
		case "slot 2":{
			if (pinv2.getObjType().equals("food")) {					
				if (pinv2.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv2.getHpRestore());
					System.out.println("Your meal of " + pinv2.getObjName() + " provided you with " + pinv2.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv2.resetObject();
					playerinventory.setPmobInv2(0);
				}
			} 
			else { System.out.println("That is not a food."); } 
			break;
		} // end case "2"
		case "slot 3":{
			if (pinv3.getObjType().equals("food")) {					
				if (pinv3.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv3.getHpRestore());
					System.out.println("Your meal of " + pinv3.getObjName() + " provided you with " + pinv3.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv3.resetObject();
					playerinventory.setPmobInv3(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "3"
		case "slot 4":{
			if (pinv4.getObjType().equals("food")) {					
				if (pinv4.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv4.getHpRestore());
					System.out.println("Your meal of " + pinv4.getObjName() + " provided you with " + pinv4.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv4.resetObject();
					playerinventory.setPmobInv4(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "4"
		case "slot 5":{
			if (pinv5.getObjType().equals("food")) {					
				if (pinv5.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv5.getHpRestore());
					System.out.println("Your meal of " + pinv5.getObjName() + " provided you with " + pinv5.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv5.resetObject();
					playerinventory.setPmobInv5(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "5"
		case "slot 6":{
			if (pinv6.getObjType().equals("food")) {					
				if (pinv6.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv6.getHpRestore());
					System.out.println("Your meal of " + pinv6.getObjName() + " provided you with " + pinv6.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv6.resetObject();
					playerinventory.setPmobInv6(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "6"
		case "slot 7":{
			if (pinv7.getObjType().equals("food")) {					
				if (pinv7.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv7.getHpRestore());
					System.out.println("Your meal of " + pinv7.getObjName() + " provided you with " + pinv7.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv7.resetObject();
					playerinventory.setPmobInv7(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "7"
		case "slot 8":{
			if (pinv8.getObjType().equals("food")) {					
				if (pinv8.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv8.getHpRestore());
					System.out.println("Your meal of " + pinv8.getObjName() + " provided you with " + pinv8.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv8.resetObject();
					playerinventory.setPmobInv8(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "8"
		case "slot 9":{
			if (pinv9.getObjType().equals("food")) {					
				if (pinv9.getObjNum()!=0) {

					player1.setPlayerHP(player1.getPlayerHP() + pinv9.getHpRestore());
					System.out.println("Your meal of " + pinv9.getObjName() + " provided you with " + pinv9.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}

					pinv9.resetObject();
					playerinventory.setPmobInv9(0);
				}
			} 
			else {
				System.out.println("That is not a food.");
			}
			break;
		} // end case "9"
		// 10-19
		case "slot 10":{
			if (pinv10.getObjType().equals("food")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getHpRestore());
					System.out.println("Your meal of " + pinv10.getObjName() + " provided you with " + pinv10.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "10"
		case "slot 11":{
			if (pinv11.getObjType().equals("food")) {					
				if (pinv11.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv11.getHpRestore());
					System.out.println("Your meal of " + pinv11.getObjName() + " provided you with " + pinv11.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv11.resetObject();
					playerinventory.setPmobInv11(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "11"
		case "slot 12":{
			if (pinv12.getObjType().equals("food")) {					
				if (pinv12.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv12.getHpRestore());
					System.out.println("Your meal of " + pinv12.getObjName() + " provided you with " + pinv12.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv12.resetObject();
					playerinventory.setPmobInv12(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "12"
		case "slot 13":{
			if (pinv13.getObjType().equals("food")) {					
				if (pinv13.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv13.getHpRestore());
					System.out.println("Your meal of " + pinv13.getObjName() + " provided you with " + pinv13.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv13(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "13"
		case "slot 14":{
			if (pinv14.getObjType().equals("food")) {					
				if (pinv14.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv14.getHpRestore());
					System.out.println("Your meal of " + pinv14.getObjName() + " provided you with " + pinv14.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv14.resetObject();
					playerinventory.setPmobInv14(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "14"
		case "slot 15":{
			if (pinv15.getObjType().equals("food")) {					
				if (pinv15.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv15.getHpRestore());
					System.out.println("Your meal of " + pinv15.getObjName() + " provided you with " + pinv15.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv15(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "15"
		case "slot 16":{
			if (pinv16.getObjType().equals("food")) {					
				if (pinv16.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv16.getHpRestore());
					System.out.println("Your meal of " + pinv16.getObjName() + " provided you with " + pinv16.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv16.resetObject();
					playerinventory.setPmobInv16(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "16"
		case "slot 17":{
			if (pinv17.getObjType().equals("food")) {					
				if (pinv17.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv17.getHpRestore());
					System.out.println("Your meal of " + pinv17.getObjName() + " provided you with " + pinv17.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv17.resetObject();
					playerinventory.setPmobInv17(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "17"
		case "slot 18":{
			if (pinv18.getObjType().equals("food")) {					
				if (pinv18.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv18.getHpRestore());
					System.out.println("Your meal of " + pinv18.getObjName() + " provided you with " + pinv18.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv18.resetObject();
					playerinventory.setPmobInv18(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "18"
		case "slot 19":{
			if (pinv19.getObjType().equals("food")) {					
				if (pinv19.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv19.getHpRestore());
					System.out.println("Your meal of " + pinv19.getObjName() + " provided you with " + pinv19.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv19(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "19"
		// 10-19
		case "slot 20":{
			if (pinv10.getObjType().equals("food")) {					
				if (pinv10.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv10.getHpRestore());
					System.out.println("Your meal of " + pinv10.getObjName() + " provided you with " + pinv10.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv10.resetObject();
					playerinventory.setPmobInv10(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "10"
		case "slot 21":{
			if (pinv21.getObjType().equals("food")) {					
				if (pinv21.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv21.getHpRestore());
					System.out.println("Your meal of " + pinv21.getObjName() + " provided you with " + pinv21.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv21.resetObject();
					playerinventory.setPmobInv21(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "21"
		case "slot 22":{
			if (pinv22.getObjType().equals("food")) {					
				if (pinv22.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv22.getHpRestore());
					System.out.println("Your meal of " + pinv22.getObjName() + " provided you with " + pinv22.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv22.resetObject();
					playerinventory.setPmobInv22(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "22"
		case "slot 23":{
			if (pinv23.getObjType().equals("food")) {					
				if (pinv23.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv23.getHpRestore());
					System.out.println("Your meal of " + pinv23.getObjName() + " provided you with " + pinv23.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv13.resetObject();
					playerinventory.setPmobInv23(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "23"
		case "slot 24":{
			if (pinv24.getObjType().equals("food")) {					
				if (pinv24.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv24.getHpRestore());
					System.out.println("Your meal of " + pinv24.getObjName() + " provided you with " + pinv24.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv24.resetObject();
					playerinventory.setPmobInv24(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "24"
		case "slot 25":{
			if (pinv25.getObjType().equals("food")) {					
				if (pinv25.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv25.getHpRestore());
					System.out.println("Your meal of " + pinv25.getObjName() + " provided you with " + pinv25.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv15.resetObject();
					playerinventory.setPmobInv25(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "25"
		case "slot 26":{
			if (pinv26.getObjType().equals("food")) {					
				if (pinv26.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv26.getHpRestore());
					System.out.println("Your meal of " + pinv26.getObjName() + " provided you with " + pinv26.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv26.resetObject();
					playerinventory.setPmobInv26(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "26"
		case "slot 27":{
			if (pinv27.getObjType().equals("food")) {					
				if (pinv27.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv27.getHpRestore());
					System.out.println("Your meal of " + pinv27.getObjName() + " provided you with " + pinv27.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv27.resetObject();
					playerinventory.setPmobInv27(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "27"
		case "slot 28":{
			if (pinv28.getObjType().equals("food")) {					
				if (pinv28.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv28.getHpRestore());
					System.out.println("Your meal of " + pinv28.getObjName() + " provided you with " + pinv28.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv28.resetObject();
					playerinventory.setPmobInv28(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "28"
		case "slot 29":{
			if (pinv29.getObjType().equals("food")) {					
				if (pinv29.getObjNum()!=0) {
					player1.setPlayerHP(player1.getPlayerHP() + pinv29.getHpRestore());
					System.out.println("Your meal of " + pinv29.getObjName() + " provided you with " + pinv29.getHpRestore() + " healthpoints.");
					if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
						player1.setPlayerHP(player1.getPlayerMaxHP());
						System.out.println("Your healthpoints feel fully restored.");
					}
					pinv19.resetObject();
					playerinventory.setPmobInv29(0);
				}
			} 
			else { System.out.println("That is not a food."); }
			break;
		} // end case "29"


		default: {
			// they didnt enter a valid inventory slot, 0-29, slot 0-29
			break;
		}
		} // end switch 
	} // end eatFood()




	private static void setRoomObj6() {
		// sets the obj in slot 6 (of 6) in the room

		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 6: " + newRoom.getObjNumAtPos(5));
		int iinput = input.nextInt();
		newRoom.setObjNumAtPos(iinput, 5);
		loadObject(tobj5,iinput);

	} // end setRoomObj6()


	private static void setRoomObj5() {
		// sets the obj in slot 5(of 6) in the room

		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 5: " + newRoom.getObjNumAtPos(4));
		int iinput = input.nextInt();
		newRoom.setObjNumAtPos(iinput, 4);
		loadObject(tobj4,iinput);

	} // end setRoomObj5()


	private static void setRoomObj4() {
		// sets obj in slot 4 (of 6) in the room

		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 4: " + newRoom.getObjNumAtPos(3));
		int iinput = input.nextInt();
		newRoom.setObjNumAtPos(iinput, 3);
		loadObject(tobj3,iinput);

	} // end setRoomObj4()


	private static void setRoomObj3() {
		// sets the obj in slot 3 (of 6) in the room

		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 3: " + newRoom.getObjNumAtPos(2));
		int iinput = input.nextInt();
		newRoom.setObjNumAtPos(iinput, 2);
		loadObject(tobj2,iinput);

	} // end setRoomObj3()


	@SuppressWarnings("resource")
	private static void setRoomObj2() {
		// sets the object in slot 2 (of 6) in the room

		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 2: " + newRoom.getObjNumAtPos(1));
		int iinput = input.nextInt();


		Scanner keyboard = new Scanner(System.in);
		while (!keyboard.hasNextInt()) {

			System.out.println("That is not an integer.  " + "Please try again.");
			setRoomObj2();
		}


		newRoom.setObjNumAtPos(iinput, 1);
		loadObject(tobj1,iinput);

	} // end setRoomObj2()


	private static void setRoomObj1() {
		// 
		// sets the object in slot 1 (of 6) in the room
		System.out.println("Please enter the object number.");
		System.out.println("This object should already exist.");
		System.out.println("Current object in spot 1: " + newRoom.getObjNumAtPos(0));
		int iinput = input.nextInt();
		newRoom.setObjNumAtPos(iinput, 0);
		loadObject(tobj0,iinput);

	} // end setRoomObj1()


	private static void setRoomMob6() {
		// 
		// sets the mob in slot 6 (of 6) in the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 6: " + newRoom.getMobNumAtPos(5));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 5);
		loadMob(tmob5,iinput);

	} // end setRoomMob6()


	private static void setRoomMob5() {
		// 
		// sets the mob in slot 5 (of 6) in the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 5: " + newRoom.getMobNumAtPos(4));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 4);
		loadMob(tmob4,iinput);

	} // end setRoomMob5()


	private static void setRoomMob4() {
		// 
		// sets mob in slot 4( of 6) in the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 4: " + newRoom.getMobNumAtPos(3));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 3);
		loadMob(tmob3,iinput);

	} // end setRoomMob4()


	private static void setRoomMob3() {
		// 
		// sets the mob in slot 3 (of 6) in the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 3: " + newRoom.getMobNumAtPos(2));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 2);
		loadMob(tmob2,iinput);


	} // end setRoom3()


	private static void setRoomMob2() {
		// 
		// sets the mob in slot 2 (of 6) of the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 2: " + newRoom.getMobNumAtPos(1));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 1);
		loadMob(tmob1,iinput);

	} // end setRoomMob2()


	private static void setRoomMob1() {
		// sets the mob in slot 1 (of 6) in the room
		System.out.println("Please enter the mob number.");
		System.out.println("This mob should already exist.");
		System.out.println("Current mob in spot 1: " + newRoom.getMobNumAtPos(0));
		int iinput = input.nextInt();
		newRoom.setMobNumAtPos(iinput, 0);
		loadMob(tmob0,iinput);

	} // end setRoomMob1()


	private static void showObjs() {
		// 
		// attempts to list out all the ojs in the array by obj ID num and obj Name
		System.out.println("Obj ID" + " | " + "Obj Name");		
		for (int i = 0; i < nextAvailObj; i++ ) {
			System.out.println(Objects[i][0] + "     | " + Objects[i][1]);
		} // end for loop
	} // end showObjs()


	private static void showRooms() { 
		// attempts to list out all mobs in the array by the mob ID Num and mob Name
		System.out.println("Room ID" + " | " + "Room Name");		
		for (int i = 0; i < nextAvailRoom; i++ ) {
			System.out.println(World[i][0] + "     | " + World[i][1]);
		} // end for loop
	} // end show Rooms()


	private static void showMobs() {
		// 
		// attempts to list out all mobs in the array by the mob ID Num and mob Name
		System.out.println("Mob ID" + " | " + "Mob Name");		
		for (int i = 0; i < nextAvailMob; i++ ) {
			System.out.println(Mobs[i][0] + "     | " + Mobs[i][1]);
		} // end for loop
	} // end showMobs()


	private static void editRoom() {
		// attempts to enter the room editor
		System.out.println("Attempting to enter the room editor...");

		newRoom.returnRoomInfo2();
		editor = "room";
		roomCommands();

		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");

	} // end editRoom()


	private static void setObjAddHP() {
		// attempts to add hitpoints to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added hitpoints: " + editingObject.getAddHP());
		System.out.println("Enter new object added hitpoints.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setAddHP(iinput);

		editingObject.returnObjectInfo();


	} // end setObjAddHP


	private static void setObjAddInt() {
		// attempts to add intellect to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added intellect: " + editingObject.getAddInt());
		System.out.println("Enter new object added intellect.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setAddInt(iinput);

		editingObject.returnObjectInfo();


	} // end setObjAddInt


	private static void setObjAddStam() {
		// attempts to add stamina to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added stamina: " + editingObject.getAddStam());
		System.out.println("Enter new object added stamina.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setAddStam(iinput);

		editingObject.returnObjectInfo();


	} // end setObjAddStam


	private static void setObjAddStr() {
		// attempts to add strength to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added strength: " + editingObject.getAddStr());
		System.out.println("Enter new object added strength.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);

		editingObject.setAddStr(iinput);

		editingObject.returnObjectInfo();


	} // end setObjAddStr()


	private static void setObjAddMP() {
		// attempts to add mana points to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added mana points: " + editingObject.getAddMP());
		System.out.println("Enter new object added mana points.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setAddMP(iinput);

		editingObject.returnObjectInfo();

	} // end setObjAddMP()


	private static void showObjInfo2(objects o) {
		// shows the object type specific info for object o
		String otype = o.getObjType();
		switch (otype) {
		case "none": {
			o.returnObjectFull();
			break;
		}
		case "weapon": {
			o.returnObjWeapon();
			break;
		}
		case "armor": {
			o.returnObjArmor();
			break;
		}
		case "food": {
			o.returnObjFood();
			break;
		}
		case "drink": {
			o.returnObjDrink();
			break;
		}
		case "potion": {
			o.returnObjPotion();
			break;
		}
		case "scroll": {
			o.returnObjScroll();
			break;
		}
		case "wand": {
			o.returnObjWand();
			break;
		}
		case "treasure": {
			o.returnObjTreasure();
			break;
		}
		case "coin": {
			o.returnObjCoin();
			break;
		}
		case "container": {
			o.returnObjContainer();
			break;
		}
		case "sign": {
			o.returnObjSign();
			break;	
		}
		default: {
			// do nothing
		}
		} // end switch

	} // end showObjInfo(objects)


	private static void setObjAddAgi() {
		// attempts to add agility to the object
		editingObject.returnObjectInfo();
		System.out.println ("Current objects added Agility: " + editingObject.getAddAgi());
		System.out.println("Enter new object added Agility.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setAddAgi(iinput);

		//editingObject.returnObjectInfo();
		showObjInfo();

	} // end setObjAddAgi()


	private static void createObj() {
		// attempts to create a new object
		System.out.println("Attempting to create a new object...");
		editingObject = new objects();
		editingObject.resetObject();

		editingObject.setObjNum(nextAvailObj);

		nextAvailObj++;
		System.out.println("The next available object: " + nextAvailObj);
		editingObject.returnObjectInfo();

	}


	private static void copyMob() {
		// copies description fields of copyMob
		System.out.println("This will copy the descriptions from the target mob");

		System.out.println("Enter the mob number to be copied");
		int copyMob = input.nextInt();

		if (copyMob < nextAvailMob) {
			editingMob.setMobName(Mobs[copyMob][1]); // name
			editingMob.setMobShortDesc(Mobs[copyMob][2]); // short desc
			editingMob.setMobLongDesc(Mobs[copyMob][3]); // long desc

			String t = Mobs[copyMob][4];
			t.replace("[", "");
			t.replace("]", "");
			String[] t2 = t.split(",");
			editingMob.setMobKeyWords(t2); // keywords

			editingMob.setMobRace(Mobs[copyMob][27]); // race
			editingMob.setMobSubRace(Mobs[copyMob][28]); // subrace
			editingMob.setMobRank(Mobs[copyMob][29]); // rank
			editingMob.setMobGender(Mobs[copyMob][32]); // gender
			editingMob.setMobClass(Mobs[copyMob][33]); // class

			System.out.println("Mob descriptions for " + editingMob.getMobNum() + " " + editingMob.getMobName() + " copied from mob " + Mobs[copyMob][0] + " " + Mobs[copyMob][1]);

		}
		else {
			System.out.println("Please choose an existing mob.");
			copyMob();
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");

	} // end copyMob()


	private static void createMob() {
		// attempts to create a new mob

		System.out.println("Attempting to create a new mob...");
		//editingMob = new mob();
		editingMob.reset();
		editingMob.setMobNum(nextAvailMob);

		editingMobInventory.resetInventory();
		editingMobInventory.setPmobid(nextAvailmInv);

		nextAvailMob++;
		nextAvailmInv++;
		System.out.println("The next available object: " + nextAvailMob);
		editingMob.returnmobInfo();

	} // end createMob()


	private static void mobDefaults() {
		// currently works to default up levels, but cannot default/reset down levels
		if (editor == "mob") {
			for (int i = 0; i < editingMob.getMobLvl(); i++) {
				moblvlUp(editingMob,1);
				editingMob.setMobXPVal((int) (editingMob.getMobXPVal()*1.2));
				checkMobMaxHP(editingMob);
				checkMobMaxMP(editingMob);
			} // end for loop
		} // end if (editor == "mob)
	} // end mobDefaults()


	private static void editMob2(int mobint) {
		System.out.println("Attempting to enter the mob editor2...");
		editor = "mob";
		mobCommands();

		System.out.println("");
		editingMob.setMobNum(mobint);
		editingMob.setMobName(Mobs[mobint][1]);
		editingMob.setMobShortDesc(Mobs[mobint][2]);
		editingMob.setMobLongDesc(Mobs[mobint][3]);
		String t = Mobs[mobint][4];
		t.replace("[", "");
		t.replace("]", "");
		String[] t2 = t.split(",");
		editingMob.setMobKeyWords(t2);

		editingMob.setMobHP(Integer.parseInt(Mobs[mobint][5]));
		editingMob.setMobMP(Integer.parseInt(Mobs[mobint][6]));
		editingMob.setMobLvl(Integer.parseInt(Mobs[mobint][7]));

		editingMob.setStam(Integer.parseInt(Mobs[mobint][8]));
		editingMob.setStr(Integer.parseInt(Mobs[mobint][9]));
		editingMob.setIntel(Integer.parseInt(Mobs[mobint][10]));
		editingMob.setAgility(Integer.parseInt(Mobs[mobint][11]));

		editingMob.setHeadSlot(Mobs[mobint][12]);
		editingMob.setNeckSlot(Mobs[mobint][13]);
		editingMob.setShoulderSlot(Mobs[mobint][14]);
		editingMob.setChestSlot(Mobs[mobint][15]);
		editingMob.setWristSlot(Mobs[mobint][16]);
		editingMob.setHandSlot(Mobs[mobint][17]);
		editingMob.setFinger1(Mobs[mobint][18]);
		editingMob.setFinger2(Mobs[mobint][19]);
		editingMob.setWaistSlot(Mobs[mobint][20]);
		editingMob.setLegSlot(Mobs[mobint][21]);
		editingMob.setFootSlot(Mobs[mobint][22]);
		editingMob.setTrinket1Slot(Mobs[mobint][23]);
		editingMob.setTrinket2Slot(Mobs[mobint][24]);
		editingMob.setWeapon1Slot(Mobs[mobint][25]);
		editingMob.setWeaponShieldSlot(Mobs[mobint][26]);

		checkMobMaxHP(editingMob);
		checkMobMaxMP(editingMob);

		editingMob.setMobRace(Mobs[mobint][27]);
		editingMob.setMobSubRace(Mobs[mobint][28]);
		editingMob.setMobRank(Mobs[mobint][29]);
		editingMob.setMobXPVal(Integer.parseInt(Mobs[mobint][30]));
		editingMob.setMobIsAlive(Integer.parseInt(Mobs[mobint][31]));
		editingMob.setMobGender(Mobs[mobint][32]);
		editingMob.setMobClass(Mobs[mobint][33]);

		editingMob.setV46(Integer.parseInt(Mobs[mobint][46])); // is talker
		editingMob.setV47(Mobs[mobint][47]); // speech 1
		editingMob.setV48(Mobs[mobint][48]); // speech 2
		editingMob.setV49(Mobs[mobint][49]); // speech 3

		editingMob.returnmobInfo();

	} // end editMob2()


	private static void editMob() {
		// enters the mob editor
		System.out.println("Attempting to enter the mob editor...");
		editor = "mob";
		mobCommands();

		System.out.println("Enter mob number to edit.");
		kinput = input.nextLine();
		int tempint = Integer.parseInt(kinput);
		editingMob.setMobNum(tempint);

		if (tempint < nextAvailMob) {

			editingMob.setMobNum(tempint);
			editingMob.setMobName(Mobs[tempint][1]);
			editingMob.setMobShortDesc(Mobs[tempint][2]);
			editingMob.setMobLongDesc(Mobs[tempint][3]);
			String t = Mobs[tempint][4];
			t.replace("[", "");
			t.replace("]", "");
			String[] t2 = t.split(",");
			editingMob.setMobKeyWords(t2);

			editingMob.setMobHP(Integer.parseInt(Mobs[tempint][5]));
			editingMob.setMobMP(Integer.parseInt(Mobs[tempint][6]));
			editingMob.setMobLvl(Integer.parseInt(Mobs[tempint][7]));

			editingMob.setStam(Integer.parseInt(Mobs[tempint][8]));
			editingMob.setStr(Integer.parseInt(Mobs[tempint][9]));
			editingMob.setIntel(Integer.parseInt(Mobs[tempint][10]));
			editingMob.setAgility(Integer.parseInt(Mobs[tempint][11]));

			editingMob.setHeadSlot(Mobs[tempint][12]);
			editingMob.setNeckSlot(Mobs[tempint][13]);
			editingMob.setShoulderSlot(Mobs[tempint][14]);
			editingMob.setChestSlot(Mobs[tempint][15]);
			editingMob.setWristSlot(Mobs[tempint][16]);
			editingMob.setHandSlot(Mobs[tempint][17]);
			editingMob.setFinger1(Mobs[tempint][18]);
			editingMob.setFinger2(Mobs[tempint][19]);
			editingMob.setWaistSlot(Mobs[tempint][20]);
			editingMob.setLegSlot(Mobs[tempint][21]);
			editingMob.setFootSlot(Mobs[tempint][22]);
			editingMob.setTrinket1Slot(Mobs[tempint][23]);
			editingMob.setTrinket2Slot(Mobs[tempint][24]);
			editingMob.setWeapon1Slot(Mobs[tempint][25]);
			editingMob.setWeaponShieldSlot(Mobs[tempint][26]);

			checkMobMaxHP(editingMob);
			checkMobMaxMP(editingMob);

			editingMob.setMobRace(Mobs[tempint][27]);
			editingMob.setMobSubRace(Mobs[tempint][28]);
			editingMob.setMobRank(Mobs[tempint][29]);
			editingMob.setMobXPVal(Integer.parseInt(Mobs[tempint][30]));
			editingMob.setMobIsAlive(Integer.parseInt(Mobs[tempint][31]));
			editingMob.setMobGender(Mobs[tempint][32]);
			editingMob.setMobClass(Mobs[tempint][33]);

			editingMob.setV46(Integer.parseInt(Mobs[tempint][46]));
			editingMob.setV47(Mobs[tempint][47]);
			editingMob.setV48(Mobs[tempint][48]);
			editingMob.setV49(Mobs[tempint][49]);

			editingMob.returnmobInfo();
		}
		else {
			System.out.println("No such mob exists.");
		}

	} // end editMob()


	private static void setMobGender() {
		// attempts to set the mob's gender
		System.out.println("Mob's gender is currently: " + editingMob.getMobGender());
		System.out.println("Enter new mob gender.");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingMob.setMobGender("none");
		}
		case "male": {
			editingMob.setMobGender("male");
		}
		case "female": {
			editingMob.setMobGender("female");
		}
		case "other": {
			editingMob.setMobGender("other");
		}
		default: {
			System.out.println("Bad input, Pick mob gender again");
			setMobGender();
		}
		} // end switch

		System.out.println("This mob's gender has been set to: " + editingMob.getMobGender());

	} // end setMobGender


	public static void setMobAttackable() {
		// sets if the mob is attackable

		int attackability = editingMob.getAttackable();
		String attackability2 = "";
		if (attackability == 0) {
			attackability2 = "Not Attackable";
		}
		else {
			attackability2 = "Attackable";
		} 


		System.out.println("Mob attackability is currently: " + attackability + " or " + attackability2);
		System.out.println("Enter mob attackability.");
		kinput = input.nextLine();
		switch (kinput) {

		case "0": {
			editingMob.setAttackable(0);
			attackability2 = "Not Attackable";
			//	System.out.println("Mob attackability is currently: " + attackability + " or " + attackability2);
			break;
		}
		case "1": {
			editingMob.setAttackable(1);
			attackability2 = "Attackable";
			//	System.out.println("Mob attackability is currently: " + attackability + " or " + attackability2);
			break;
		}
		default: {
			System.out.println("Bad input, Pick mob attackability again");
			setMobAttackable();
		}
		} // end switch
		attackability = editingMob.getAttackable();
		if (attackability == 0) {
			attackability2 = "Not Attackable";
		}
		else {
			attackability2 = "Attackable";
		} 
		System.out.println("Mob's attackability has been change to: " + attackability + " or "+ attackability2);

	} //end setMobAttackable


	private static void setMobXP() {
		// 
		// does not have a purpose yet, use mobDefaults()
		System.out.println("Mob's XP is currently: " + editingMob.getMobXPVal());
		System.out.println("Enter new XP value for mob.  Please remember to keep mob stats in an acceptable range.");
		System.out.println("Please use the Set Mob Defaults command.");
		int iinput = input.nextInt();
		editingMob.setMobXPVal(iinput);

		System.out.println("Mob's new XP is: " + editingMob.getMobXPVal());

	} // end setMobXP()


	private static void setMobRank() {
		// set the mob's rank
		// cosmetic at the moment, idea below for ranks

		/*
		 * 	mob ranks:
		 * 		mobs can have ranks, higher ranks increase their health and damage
		 * 		null/common/normal - hp, dps the same
		 * 		elite - hp, dps increase by 125%
		 * 		chieftain - hp, dps increase 150%
		 * 		lord - hp, dps increase 175%
		 * 		high lord - hp, dps increase 200%
		 * 		great lord - hp, dps increase 225%
		 * 		grand lord - hp, dps increase 250%
		 * 		mythic lord - hp, dps increase 300%
		 * 		Archaic lord - hp, dps increase by 750%
		 * 		God Rank - hp, dps increase 1000%
		 */

		System.out.println("This is currently cosmetic!");

		System.out.println("Mob's rank is currently: " + editingMob.getMobRank());
		System.out.println("normal, elite, chieftain, lord, high lord, greath lord, grand lord, mythic lord, archaic lord, god");
		System.out.println("Enter new mob rank.");
		kinput = input.nextLine();
		switch (kinput) {
		case "normal": {
			editingMob.setMobRank("normal");
			break;
		}
		case "elite": {
			editingMob.setMobRank("elite");
			break;
		}
		case "chieftain": {
			editingMob.setMobRank("chieftain");
			break;
		}
		case "lord": {
			editingMob.setMobRank("lord");
			break;
		}
		case "high lord": {
			editingMob.setMobRank("high lord");
			break;
		}
		case "great lord": {
			editingMob.setMobRank("great lord");
			break;
		}
		case "grand lord": {
			editingMob.setMobRank("grand lord");
			break;
		}
		case "mythic lord": {
			editingMob.setMobRank("mythic lord");
			break;
		}
		case "archaeic lord": {
			editingMob.setMobRank("archaeic lord");
			break;
		}
		case "god": {
			editingMob.setMobRank("god");
			break;
		}
		default: {
			System.out.println("Bad input, Pick mob rank again");
			setMobRank();
		}
		} // end switch
		System.out.println("Mob's rank/class has been change to: " + editingMob.getMobRank());

	} // end setMobRank


	private static void setMobLevel() {
		// 
		System.out.println("Not yet built");

		System.out.println("The mob's level is currently: " + editingMob.getMobLvl());

		System.out.println("Enter new mob level.");
		kinput = input.nextLine();
		switch (kinput) {
		case "1": {
			editingMob.setMobLvl(1);
			break;
		}
		case "2": {
			editingMob.setMobLvl(2);
			//	moblvlUp(editingMob,2);
			break;
		}
		case "3": {
			editingMob.setMobLvl(3);

			break;
		}
		case "4": {
			editingMob.setMobLvl(4);
			break;
		}
		case "5": {
			editingMob.setMobLvl(5);
			break;
		}
		case "6": {
			editingMob.setMobLvl(6);
			break;
		}
		case "7": {
			editingMob.setMobLvl(7);
			break;
		}
		case "8": {
			editingMob.setMobLvl(8);
			break;
		}
		case "9": {
			editingMob.setMobLvl(9);
			break;
		}
		case "10": {
			editingMob.setMobLvl(10);
			break;
		}
		case "11": {
			editingMob.setMobLvl(11);
			break;
		}
		case "12": {
			editingMob.setMobLvl(12);
			break;
		}
		case "13": {
			editingMob.setMobLvl(13);
			break;
		}
		case "14": {
			editingMob.setMobLvl(14);
			break;
		}
		case "15": {
			editingMob.setMobLvl(15);
			break;
		}
		case "16": {
			editingMob.setMobLvl(16);
			break;
		}
		case "17": {
			editingMob.setMobLvl(17);
			break;
		}
		case "18": {
			editingMob.setMobLvl(18);
			break;
		}
		case "19": {
			editingMob.setMobLvl(19);
			break;
		}
		case "20": {
			editingMob.setMobLvl(20);
			break;
		}
		case "21": {
			editingMob.setMobLvl(21);
			break;
		}
		case "22": {
			editingMob.setMobLvl(22);
			break;
		}
		case "23": {
			editingMob.setMobLvl(23);
			break;
		}
		case "24": {
			editingMob.setMobLvl(24);
			break;
		}
		case "25": {
			editingMob.setMobLvl(25);
			break;
		}
		case "26": {
			editingMob.setMobLvl(26);
			break;
		}
		case "27": {
			editingMob.setMobLvl(27);
			break;
		}
		case "28": {
			editingMob.setMobLvl(28);
			break;
		}
		case "29": {
			editingMob.setMobLvl(29);
			break;
		}
		case "30": {
			editingMob.setMobLvl(30);
			break;
		}
		case "31": {
			editingMob.setMobLvl(31);
			break;
		}
		case "32": {
			editingMob.setMobLvl(32);
			break;
		}
		default: {
			System.out.println("Enter a valid level.");
		}
		}
		editingMob.returnmobInfo();

	} // end setMobLevel()


	private static void setMobRace() {
		// set the mob's main racial type
		System.out.println("humanoid, aquatic, beast, critter, dragonkin, elemental, flying, magic, mechanical, undead, none");
		System.out.println("Mob's race is currently: " + editingMob.getMobRace());
		System.out.println("Enter new mob race.");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "humanoid": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "aquatic": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "beast": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "critter": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "dragonkin": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "elemental": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "flying": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "magic": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "mechanical": {
			editingMob.setMobRace(kinput);
			break;
		}
		case "undead": {
			editingMob.setMobRace(kinput);
			break;
		}
		default: {
			System.out.println("Bad input, Pick mob race again");
			setMobRace();
		}

		} // end switch

		System.out.println("Mob's race has been change to: " + editingMob.getMobRace());


		try {
			msave();
		} catch (IOException e) {
			// 
			e.printStackTrace();
		}
	} // end setMobRace()


	private static void setMobSubRace() {
		// set the mob subrace based off main race
		// none, human, elf, half-elf, dwarf, orc, troll, tauren, ...
		System.out.println("Mob's race is currently: " + editingMob.getMobRace());
		System.out.println("Mob's subrace is currently: " + editingMob.getMobSubRace());

		String trace = editingMob.getmobRace();
		switch (trace) {
		case "none": {
			System.out.println("Available subraces are: none");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();}
			} // end switch
			break;
		} // end case "none"

		case "humanoid": {
			System.out.println("Available subraces are: none, human, elf, half-elf, dwarf, orc, troll, tauren (minotaur)");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "human": {
				editingMob.setMobSubRace("human");
				break;
			}
			case "elf": {
				editingMob.setMobSubRace("elf");
				break;
			}
			case "half-elf": {
				editingMob.setMobSubRace("half-elf");
				break;
			}
			case "dwarf": {
				editingMob.setMobSubRace("dwarf");
				break;
			}
			case "orc": {
				editingMob.setMobSubRace("orc");
				break;
			}
			case "troll": {
				editingMob.setMobSubRace("troll");
				break;
			}
			case "tauren": {
				editingMob.setMobSubRace("tauren");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end if switch
			break;
		} // end humanoid

		case "aquatic": {
			// none, fish, shark, whale, ray, crustacean (crab, lobster, shrimp), cephalopod (ocopi, squid)
			System.out.println("Available subraces are: none, fish, shark, whale, ray, crustacean (crab, lobster, shrimp), cephalopod (ocopi, squid).");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "fish": {
				editingMob.setMobSubRace("fish");
				break;
			}
			case "shark": {
				editingMob.setMobSubRace("shark");
				break;
			}
			case "whale": {
				editingMob.setMobSubRace("whale");
				break;
			}
			case "ray": {
				editingMob.setMobSubRace("ray");
				break;
			}
			case "crustacean": {
				editingMob.setMobSubRace("crustacean");
				break;
			}
			case "cephalopod": {
				editingMob.setMobSubRace("cephalopod");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if aquatic

		case "beast": {   // if beast
			// wolf, bear, boar, large cat, cervid, bovidae, snake, lizard, insect
			System.out.println("Available subraces are: none, wolf, bear, boar, large cat, cervid (deer/moose), bovidae (oxen/cows), snake, lizard, insect");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "wolf": {
				editingMob.setMobSubRace("wolf");
				break;
			}
			case "bear": {
				editingMob.setMobSubRace("bear");
				break;
			}
			case "boar": {
				editingMob.setMobSubRace("boar");
				break;
			}
			case "large cat": {
				editingMob.setMobSubRace("large cat");
				break;
			}
			case "cervid": {
				editingMob.setMobSubRace("cervid");
				break;
			}
			case "bovidae": {
				editingMob.setMobSubRace("bovidae");
				break;
			}
			case "snake": {
				editingMob.setMobSubRace("snake");
				break;
			}
			case "lizard": {
				editingMob.setMobSubRace("lizard");
				break;
			}
			case "insect": {
				editingMob.setMobSubRace("insect");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if beast

		case "critter": {   // if critter
			// vermin, insect
			System.out.println("Available subraces are: none, vermin, insect");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "vermin": {
				editingMob.setMobSubRace("vermin");
				break;
			}
			case "insect": {
				editingMob.setMobSubRace("insect");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if critter

		case "dragonkin": {   // if dragonkin
			System.out.println("Available subraces are: none, true dragon, wyvern, land dragon, wyrm, serpent, drakonid, dragonkin, dragonblood");
			System.out.println("Enter new mob subrace.");

			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "true dragon": {
				editingMob.setMobSubRace("true dragon");
				break;
			}
			case "wyvern": {
				editingMob.setMobSubRace("wyvern");
				break;
			}
			case "land dragon": {
				editingMob.setMobSubRace("land dragon");
				break;
			}
			case "wyrm": {
				editingMob.setMobSubRace("wyrm");
				break;
			}
			case "serpent": {
				editingMob.setMobSubRace("serpent");
				break;
			}
			case "drakonid": {
				editingMob.setMobSubRace("drakonid");
				break;
			}
			case "dragonkin": {
				editingMob.setMobSubRace("dragonkin");
				break;
			}
			case "dragonblood": {
				editingMob.setMobSubRace("dragonblood");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if dragonkin

		case "elemenmtal": {   // if elemental
			System.out.println("Available subraces are: fire, water, earth, air, metal, poison, lightning, light, dark, space, time");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "fire": {
				editingMob.setMobSubRace("fire");
				break;
			}
			case "water": {
				editingMob.setMobSubRace("water");
				break;
			}
			case "earth": {
				editingMob.setMobSubRace("earth");
				break;
			}
			case "air": {
				editingMob.setMobSubRace("air");
				break;
			}
			case "metal": {
				editingMob.setMobSubRace("metal");
				break;
			}
			case "poison": {
				editingMob.setMobSubRace("poison");
				break;
			}
			case "lightning": {
				editingMob.setMobSubRace("lightning");
				break;
			}
			case "light": {
				editingMob.setMobSubRace("light");
				break;
			}
			case "dark": {
				editingMob.setMobSubRace("dark");
				break;
			}
			case "space": {
				editingMob.setMobSubRace("space");
				break;
			}
			case "time": {
				editingMob.setMobSubRace("time");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if elemental

		case "flying": {   // if flying
			// avian, cloud
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "avian": {
				editingMob.setMobSubRace("avian");
				break;
			}
			case "cloud": {
				editingMob.setMobSubRace("cloud");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if flying

		case "magic": {   // if magic
			// sprite, djinn,
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "sprite": {
				editingMob.setMobSubRace("sprite");
				break;
			}
			case "djinn": {
				editingMob.setMobSubRace("djinn");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if magic

		case "mechanical": {   // if mechanical
			// robot, mecha
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "robot": {
				editingMob.setMobSubRace("robot");
				break;
			}
			case "machine": {
				editingMob.setMobSubRace("machine");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if mechanical

		case "undead": {   // if undead
			System.out.println("Available subraces are: skeleton, zombie, ghost, ghoul, lich, vampire");
			System.out.println("Enter new mob subrace.");
			kinput = input.nextLine();
			switch (kinput) {
			case "none": {
				editingMob.setMobSubRace("none");
				break;
			}
			case "skeleton": {
				editingMob.setMobSubRace("skeleton");
				break;
			}
			case "zombie": {
				editingMob.setMobSubRace("zombie");
				break;
			}
			case "ghost": {
				editingMob.setMobSubRace("ghost");
				break;
			}
			case "ghoul": {
				editingMob.setMobSubRace("ghoul");
			}
			case "lich": {
				editingMob.setMobSubRace("lich");
				break;
			}
			case "vampire": {
				editingMob.setMobSubRace("vampire");
				break;
			}
			default: {
				System.out.println("Bad input, Pick mob subrace again");
				setMobSubRace();
			}
			} // end switch
			break;
		} // end if undead
		default:
			break;
		} // end switch trace
		System.out.println("Mob's subrace has been change to: " + editingMob.getMobSubRace());
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");

	} // end setMobSubRace()


	public static void setMobClass() {

		//	System.out.println("Available classes: Cleric, Druid, Paladin, Fighter, Barbarian, Rogue, Mage, None");

		System.out.println("Mob's class is currently: " + editingMob.getMobClass());
		System.out.println("Enter new mob class.");
		kinput = input.nextLine();
		switch (kinput) {

		case "none": {
			editingMob.setMobClass("none");
			break;
		}
		case "cleric": {
			editingMob.setMobClass("cleric");
			break;
		}
		case "druid": {
			editingMob.setMobClass("druid");
			break;
		}
		case "paladin": {
			editingMob.setMobClass("paladin");
			break;
		}
		case "fighter": {
			editingMob.setMobClass("fighter");
			break;
		}
		case "barbarian": {
			editingMob.setMobClass("barbarian");
			break;
		}
		case "rogue": {
			editingMob.setMobClass("rogue");
			break;
		}
		case "mage": {
			editingMob.setMobClass("mage");
			break;
		}
		default: {
			System.out.println("Not a valid class, try again");
			setMobClass();
		}
		} // end switch
		//editingMob.setMobShortDesc(kinput);
		System.out.println("Mob's class has been change to: " + editingMob.getMobClass());

	} // end setMobClass


	public static void setMobKeywords() {
		// Sets the mob keywords
		System.out.println("Keywords are currently: " + Arrays.toString(editingMob.getMobKeyWords()));

		System.out.println("Set the first keyword");
		kinput = input.nextLine();
		editingMob.setMobKeyword1(kinput);

		System.out.println("Set the second keyword");
		kinput = input.nextLine();
		editingMob.setMobKeyword2(kinput);

		System.out.println("Set the third keyword");
		kinput = input.nextLine();
		editingMob.setMobKeyword3(kinput);

		System.out.println("The mob's keywords have been changed to: " + Arrays.toString(editingMob.getMobKeyWords()));
	} // end setMobKeywords


	private static void setMobLongDesc() {
		// attempts to set the mob's long description
		System.out.println("Mob's long description is currently: " + editingMob.getMobLongDesc());
		System.out.println("Enter new mob description.");
		kinput = input.nextLine();

		editingMob.setMobLongDesc(kinput);
		System.out.println("Mob's has been change to: " + editingMob.getMobLongDesc());
	} // end setMobLongDesc()


	private static void setMobShortDesc() {
		// sets the mob short description
		System.out.println("Mob's short description is currently: " + editingMob.getMobShortDesc());
		System.out.println("Enter new mob description.");
		kinput = input.nextLine();

		editingMob.setMobShortDesc(kinput);
		System.out.println("Mob has been change to: " + editingMob.getMobShortDesc());
	} // end setMobShotDesc()


	private static void setMobName() {
		// sets the mob name
		System.out.println("Mob is currently named " + editingMob.getMobName());
		System.out.println("Enter new mob name.");
		kinput = input.nextLine();

		editingMob.setMobName(kinput);
		System.out.println("Mob has been renamed " + editingMob.getMobName());
	} // end setMobName()


	private static void setMobHeadSlot() {
		//  
		// be careful, this can set items were they arent supposed to be worn
		System.out.println("Mob's current head slot: " + editingMob.getHeadSlot());
		System.out.println("Enter new item number to put in the head slot.");
		kinput = input.nextLine();

		editingMob.setHeadSlot(kinput);
		System.out.println("Mob's new head slot: " + editingMob.getHeadSlot());

	}// end setMobHeadSlot()


	private static void setMobNeckSlot() {
		// 
		System.out.println("Mob's current neckslot: " + editingMob.getNeckSlot());
		System.out.println("Enter new item number to put in the neck slot.");
		kinput = input.nextLine();

		editingMob.setNeckSlot(kinput);
		System.out.println("Mob's new neck slot: " + editingMob.getNeckSlot());
	}// end setMobNeckSlot()


	private static void setMobShoulderSlot() {
		// 
		System.out.println("Mob's current shoulder slot: " + editingMob.getShoulderSlot());
		System.out.println("Enter new item number to put in the shoulder slot.");
		kinput = input.nextLine();

		editingMob.setShoulderSlot(kinput);
		System.out.println("Mob's new shoulder slot: " + editingMob.getShoulderSlot());
	}// end setMobShoulderSlot()


	private static void setMobChestSlot() {
		// 
		System.out.println("Mob's current chest slot: " + editingMob.getChestSlot());
		System.out.println("Enter new item number to put in the chest slot.");
		kinput = input.nextLine();

		editingMob.setChestSlot(kinput);
		System.out.println("Mob's new chest slot: " + editingMob.getChestSlot());
	}// end setMobChestSlot()


	private static void setMobWristSlot() {
		// 
		System.out.println("Mob's current wrist slot: " + editingMob.getWristSlot());
		System.out.println("Enter new item number to put in the wrist slot.");
		kinput = input.nextLine();

		editingMob.setWristSlot(kinput);
		System.out.println("Mob's new wrist slot: " + editingMob.getWristSlot());
	}// end setMobWristSlot()


	private static void setMobHandSlot() {
		//
		System.out.println("Mob's current hand slot: " + editingMob.getHandSlot());
		System.out.println("Enter new item number to put in the hand slot.");
		kinput = input.nextLine();

		editingMob.setHeadSlot(kinput);
		System.out.println("Mob's new hand slot: " + editingMob.getHandSlot());
	}// end setMobhandSlot()


	private static void setMobFinger1Slot() {
		//
		System.out.println("Mob's current finger1 slot: " + editingMob.getFinger1());
		System.out.println("Enter new item number to put in the finger1 slot.");
		kinput = input.nextLine();

		editingMob.setFinger1(kinput);
		System.out.println("Mob's new finger1 slot: " + editingMob.getFinger1());
	}// end setMobFinger1Slot()


	private static void setMobFinger2Slot() {
		//
		System.out.println("Mob's current finger2 slot: " + editingMob.getFinger2());
		System.out.println("Enter new item number to put in the finger2 slot.");
		kinput = input.nextLine();

		editingMob.setFinger2(kinput);
		System.out.println("Mob's new finger2 slot: " + editingMob.getFinger2());
	}// end setMobFinger2Slot()


	private static void setMobWaistSlot() {
		//
		System.out.println("Mob's current waist slot: " + editingMob.getWaistSlot());
		System.out.println("Enter new item number to put in the waist slot.");
		kinput = input.nextLine();

		editingMob.setWaistSlot(kinput);
		System.out.println("Mob's new waist slot: " + editingMob.getWaistSlot());
	}// end setMobWaistSlot()


	private static void setMobLegSlot() {
		//
		System.out.println("Mob's current leg slot: " + editingMob.getLegSlot());
		System.out.println("Enter new item number to put in the leg slot.");
		kinput = input.nextLine();

		editingMob.setLegSlot(kinput);
		System.out.println("Mob's new leg slot: " + editingMob.getLegSlot());
	}// end setMobLegSlot()


	private static void setMobFootSlot() {
		//
		System.out.println("Mob's current foot slot: " + editingMob.getFootSlot());
		System.out.println("Enter new item number to put in the foot slot.");
		kinput = input.nextLine();

		editingMob.setFootSlot(kinput);
		System.out.println("Mob's new foot slot: " + editingMob.getFootSlot());
	}// end setMobFootSlot()


	private static void setMobTrinket1Slot() {
		//
		System.out.println("Mob's current trinket1 slot: " + editingMob.getTrinket1Slot());
		System.out.println("Enter new item number to put in the trinket1 slot.");
		kinput = input.nextLine();

		editingMob.setTrinket1Slot(kinput);
		System.out.println("Mob's new trinket1 slot: " + editingMob.getTrinket1Slot());
	}// end setMobTrinket1Slot()


	private static void setMobTrinket2Slot() {
		//
		System.out.println("Mob's current trinket2 slot: " + editingMob.getTrinket2Slot());
		System.out.println("Enter new item number to put in the trinket2 slot.");
		kinput = input.nextLine();

		editingMob.setTrinket2Slot(kinput);
		System.out.println("Mob's new trinket2 slot: " + editingMob.getTrinket2Slot());
	}// end setMobTrinket2Slot()


	private static void setMobWeaponSlot() {
		//
		System.out.println("Mob's current weapon slot: " + editingMob.getWeapon1Slot());
		System.out.println("Enter new item number to put in the weapon slot.");
		kinput = input.nextLine();

		editingMob.setWeapon1Slot(kinput);
		System.out.println("Mob's new weapon slot: " + editingMob.getWeapon1Slot());
	}// end setMobWeaponSlot()


	private static void setMobWeaponShieldSlot() {
		//
		System.out.println("Mob's current OH weapon/shield slot: " + editingMob.getWeaponShieldSlot());
		System.out.println("Enter new item number to put in the weapon/shield slot.");
		kinput = input.nextLine();

		editingMob.setWeaponShieldSlot(kinput);
		System.out.println("Mob's new OH weapon/shield slot: " + editingMob.getWeaponShieldSlot());
	}// end setMobNeckSlot()


	private static void setMobStam() {
		// attempts to set the mob's stamina value
		System.out.println("Mob's Stamina is currently: " + editingMob.getStam());
		System.out.println("Enter new mob Stamina value.");
		int iinput = input.nextInt();

		editingMob.setStam(iinput);
		System.out.println("Mob's Stamina has been change to: " + editingMob.getStam());


	}// end setMobStam()


	private static void setMobStr() {
		// attempts to set the mobs strength value
		System.out.println("Mob's Strength is currently: " + editingMob.getStr());
		System.out.println("Enter new mob Strength value.");
		int iinput = input.nextInt();

		editingMob.setStr(iinput);
		System.out.println("Mob's Strenth has been change to: " + editingMob.getStr());


	}// end setMobStr()


	private static void setMobInt() {
		// attempts to set the mobs intellect value
		System.out.println("Mob's Intellect is currently: " + editingMob.getIntel());
		System.out.println("Enter new mob Intellect value.");
		int iinput = input.nextInt();

		editingMob.setIntel(iinput);
		System.out.println("Mob's Intellect has been change to: " + editingMob.getIntel());


	} // end setMobInt()


	private static void setMobAgi() {
		// attempts to set the mobs agility value
		System.out.println("Mob's Agility is currently: " + editingMob.getAgility());
		System.out.println("Enter new mob Agility value.");
		int iinput = input.nextInt();

		editingMob.setAgility(iinput);
		System.out.println("Mob's Agility has been change to: " + editingMob.getAgility());


	} // end setMobAgi()


	private static void setObjName() {
		// attempts to set the object's name
		System.out.println("Current object name: " + editingObject.getObjName());
		System.out.println("Enter new object name.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();

		editingObject.setObjName(kinput);

		editingObject.returnObjectInfo();


	} // end setObjName


	private static void setObjShortDesc() {
		// attempts to set the object's short description
		editingObject.returnObjectInfo();
		System.out.println ("Current objects short desc: " + editingObject.getObjShortDesc());
		System.out.println("Enter new object short desc.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();

		editingObject.setObjShortDesc(kinput);

		editingObject.returnObjectInfo();

	} // end setObjShortDesc()


	private static void setObjLongDesc() {
		// attempts to set the object's long description
		editingObject.returnObjectInfo();
		System.out.println ("Current objects long desc: " + editingObject.getObjLongDesc());
		System.out.println("Enter new object long desc.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();

		editingObject.setObjLongDesc(kinput);

		editingObject.returnObjectInfo();


	} // end setObjLongDesc()


	private static void setObjExtDesc() {
		// attempts to set the objects keywords
		editingObject.returnObjectInfo();
		System.out.println ("Current objects extended desc: " + editingObject.getObjExtDesc());
		System.out.println("Enter new object extended desc.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();

		editingObject.setObjExtDesc(kinput);

		editingObject.returnObjectInfo();

	} // end setObjExtDesc


	private static void setObjKeyWords2() {
		System.out.println("Keywords are currently: " + Arrays.toString(editingObject.getObjKeyWords()));

		System.out.println("Set the first keyword");
		kinput = input.nextLine();
		editingObject.setObjKeyword1(kinput);

		System.out.println("Set the second keyword");
		kinput = input.nextLine();
		editingObject.setObjKeyword2(kinput);

		System.out.println("Set the third keyword");
		kinput = input.nextLine();
		editingObject.setObjKeyword3(kinput);


		System.out.println("The object's keywords have been changed to: " + Arrays.toString(editingObject.getObjKeyWords()));

	} // end setObjKeyWords2()


	private static void showObjInfo() {
		// shows the object's type-specific return
		// for use in look 1-6.obj
		String otype = editingObject.getObjType();
		switch (otype) {
		case "none": {
			//	editingObject.setObjType("none");
			editingObject.returnObjectFull();
			break;
		}
		case "weapon": {
			//	editingObject.setObjType("weapon");
			editingObject.returnObjWeapon();
			break;
		}
		case "armor": {
			//	editingObject.setObjType("armor");
			editingObject.returnObjArmor();
			break;
		}
		case "food": {
			//	editingObject.setObjType("food");
			editingObject.returnObjFood();
			break;
		}
		case "drink": {
			//	editingObject.setObjType("drink");
			editingObject.returnObjDrink();
			break;
		}
		case "potion": {
			//	editingObject.setObjType("potion");
			editingObject.returnObjPotion();
			break;
		}
		case "scroll": {
			//	editingObject.setObjType("scroll");
			editingObject.returnObjScroll();
			break;
		}
		case "wand": {
			//	editingObject.setObjType("wand");
			editingObject.returnObjWand();
			break;
		}
		case "treasure": {
			//	editingObject.setObjType("treasure");
			editingObject.returnObjTreasure();
			break;
		}
		case "coin": {
			//	editingObject.setObjType("coin");
			editingObject.returnObjCoin();
			break;
		}
		case "container": {
			//	editingObject.setObjType("container");
			editingObject.returnObjContainer();
			break;
		}
		case "sign": {
			//	editingObject.setObjType("sign");
			editingObject.returnObjSign();
			break;	
		}
		default: {
			//	System.out.println("Enter a valid object type.");
			//	setObjType2();
		}		
		} // end switch
		editingObject.returnObjectDefStats();


	} // end showObjInf()


	private static void setObjType2() {
		//
		// String objType = "none";// 16 // obj type // none, weapon (MH or OH), armor (armor, trinkets, shields), food, drink, potion?, scroll?, wand?, treasure?, coin?, trash?, containers?

		editingObject.returnObjectInfo();
		System.out.println ("Current objects type: " + editingObject.getObjType());
		System.out.println("Available object types: none, sign, weapon, armor (armor, trinkets, shields), food, drink, potion?, scroll?, wand?, treasure?, coin?, trash?, containers?");
		System.out.println("Enter new object type.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingObject.setObjType("none");
			break;
		}
		case "weapon": {
			editingObject.setObjType("weapon");
			break;
		}
		case "armor": {
			editingObject.setObjType("armor");
			break;
		}
		case "food": {
			editingObject.setObjType("food");
			break;
		}
		case "drink": {
			editingObject.setObjType("drink");
			break;
		}
		case "potion": {
			editingObject.setObjType("potion");
			break;
		}
		case "scroll": {
			editingObject.setObjType("scroll");
			break;
		}
		case "wand": {
			editingObject.setObjType("wand");
			break;
		}
		case "treasure": {
			editingObject.setObjType("treasure");
			break;
		}
		case "coin": {
			editingObject.setObjType("coin");
			break;
		}
		case "container": {
			editingObject.setObjType("container");
			break;
		}
		case "sign": {
			editingObject.setObjType("sign");
			break;				
		}
		default: {
			System.out.println("Enter a valid object type.");
			setObjType2();
		}
		} // end switch
		showObjInfo2(editingObject);

	}// end setObjType2()

	private static void showObjInfo3() {
		// shows the object's type-specific return
		// for use with lookObjByKyeword()
		// for use in look 1-6.obj
		String otype = lookObject.getObjType();
		switch (otype) {
		case "none": {
			//	editingObject.setObjType("none");
			lookObject.returnObjectFull();
			break;
		}
		case "weapon": {
			//	editingObject.setObjType("weapon");
			lookObject.returnObjWeapon();
			break;
		}
		case "armor": {
			//	editingObject.setObjType("armor");
			lookObject.returnObjArmor();
			break;
		}
		case "food": {
			//	editingObject.setObjType("food");
			lookObject.returnObjFood();
			break;
		}
		case "drink": {
			//	editingObject.setObjType("drink");
			lookObject.returnObjDrink();
			break;
		}
		case "potion": {
			//	editingObject.setObjType("potion");
			lookObject.returnObjPotion();
			break;
		}
		case "scroll": {
			//	editingObject.setObjType("scroll");
			lookObject.returnObjScroll();
			break;
		}
		case "wand": {
			//	editingObject.setObjType("wand");
			lookObject.returnObjWand();
			break;
		}
		case "treasure": {
			//	editingObject.setObjType("treasure");
			lookObject.returnObjTreasure();
			break;
		}
		case "coin": {
			//	editingObject.setObjType("coin");
			lookObject.returnObjCoin();
			break;
		}
		case "container": {
			//	editingObject.setObjType("container");
			lookObject.returnObjContainer();
			break;
		}
		case "sign": {
			//	editingObject.setObjType("sign");
			lookObject.returnObjSign();
			break;	
		}
		default: {
			//	System.out.println("Enter a valid object type.");
			//	setObjType2();
		}		
		} // end switch
		lookObject.returnObjectDefStats();


	} // end showObjInfo3()



	private static void setObjVal() {
		// TODO
	} // setObjVal()


	private static void setObjDur() {
		// sets the object durability
		editingObject.returnObjectInfo();
		System.out.println ("Current objects durability: " + editingObject.getDurability());
		System.out.println("Enter new object durability.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);

		if (iinput > 0) {
			editingObject.setDurability(iinput);

			editingObject.returnObjectInfo();

		}
		else {
			System.out.println("Please enter a valid durability.");
			setObjDur();
		}

	} // end setObjDur()


	private static void setTake() {
		// set if the object is takeable
		editingObject.returnObjectInfo();
		System.out.println ("Current objects takeability: " + editingObject.getTakeable());
		System.out.println("0 - not Takeable 1 - Takeable");
		System.out.println("Enter new object takeability.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		editingObject.setTakeable(iinput);

		//editingObject.returnObjectInfo();

		showObjInfo();



	} // end setTake() // sets if obj is takeable


	private static void setEquip() {
		// attempts to set the equip slot of the obj
		editingObject.returnObjectInfo();
		System.out.println ("Current objects equip slot: " + editingObject.getEquipSlot());
		System.out.println("Valid slots: none, head, neck, shoulders, chest, wrist, hands, finger1, finger2, waist, leg, foot, trinket1, trinket2, weapon, weaponshield");
		System.out.println("Enter new object equip slot.");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "head": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "neck": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "shoulders": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "chest": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "wrist": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "hands": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "finger1": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "finger2": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "waist": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "leg": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "foot": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "trinket1": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "trinket2": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "weapon": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		case "weaponshield": {
			editingObject.setEquipSlot(kinput);
			break;
		}
		default:{
			System.out.println("Not a valid slot");
		}
		}

	}// end setTake()


	private static void setwpnType() {
		// sets the weapon type
		//18 // weapon type // none, sword, dagger, hammer/mace, spear, whip
		editingObject.returnObjectInfo();
		System.out.println ("Current Weapon type: " + editingObject.getWeaponType());
		System.out.println("Vali Weapon Types: none, sword, dagger, hammer, spear, axe, whip");
		System.out.println("Enter new weapon type.");

		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingObject.setWeaponType("none");
			break;
		}// end case none
		case "sword": {
			editingObject.setWeaponType("sword");
			break;
		}
		case "dagger": {
			editingObject.setWeaponType("dagger");
			break;
		}// end case none
		case "hammer": {
			editingObject.setWeaponType("hammer");
			break;
		}// end case none

		case "spear": {
			editingObject.setWeaponType("spear");
			break;
		}// end case none
		case "axe": {
			editingObject.setWeaponType("axe");
			break;
		}// end case none
		case "whip": {
			editingObject.setWeaponType("whip");
			break;
		}// end case none
		default: {
			break;
		}
		}

	} // end setwpnType()

	private static void setwpnDmg() {
		// TODO
		// should be a XdY ?
		System.out.println ("Current Weapon Damage range: " + editingObject.getWeaponDmg());
		System.out.println("Valid Weapon damage ranges are 0d0 - 9d9");
		System.out.println("Enter new Minimum Weapon Damage.  Please enter 0 - 9");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		int min = input.nextInt();
		switch (min) {
		case 0: {
			t1=0;
			break;
		}
		case 1: {
			t1=1;
			break;
		}
		case 2: {
			t1=2;
			break;
		}
		case 3: {
			t1=3;
			break;
		}
		case 4: {
			t1=4;
			break;
		}
		case 5: {
			t1=5;
			break;
		}
		case 6: {
			t1=6;
			break;
		}
		case 7: {
			t1=7;
			break;
		}
		case 8: {
			t1=8;
			break;
		}
		case 9: {
			t1=9;
			break;
		}

		default: { 
			t1=0;
		}
		} // end switch (min)
		System.out.println("Enter new Maximum Weapon Damage.  Please enter 0 - 9");
		System.out.println(" ");
		System.out.println(editor + "Editor");
		int max = input.nextInt();
		switch (max) {
		case 0: {
			t2=0;
			break;
		}
		case 1: {
			t2=1;
			break;
		}
		case 2: {
			t2=2;
			break;
		}
		case 3: {
			t2=3;
			break;
		}
		case 4: {
			t2=4;
			break;
		}
		case 5: {
			t2=5;
			break;
		}
		case 6: {
			t2=6;
			break;
		}
		case 7: {
			t2=7;
			break;
		}
		case 8: {
			t2=8;
			break;
		}
		case 9: {
			t2=9;
			break;
		}

		default: { 
			t2=0; // lols
		}
		} // end switch (max)
		if (min > max) { 
			System.out.println("Maximum must be equal or higher than Minimum.  Please choose a Minimum and Maximum values.");
			setwpnDmg();
		}
		else {
			editingObject.setWeaponDmg(t1 + "d" + t2);
		}
		System.out.println ("New Weapon Damage range: " + editingObject.getWeaponDmg());

	} // end setwpnDmg()


	private static void setwpndmgType() {
		//20 // weapon dmg type // hits (default), slashes, pierces, pound, stab, sting
		editingObject.returnObjectInfo();
		System.out.println ("Current Weapon Damage type: " + editingObject.getWpndmgType());
		System.out.println("Valid Weapon Types: hit (default), slash, pierce , pound, stab, cleave, sting");
		System.out.println("Enter new Weapon Damage type.");

		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		switch (kinput) {
		case "hit": {
			editingObject.setWpndmgType("hit");
			break;
		}// end case none
		case "slash": {
			editingObject.setWpndmgType("slash");
			break;
		}
		case "pierce": {
			editingObject.setWpndmgType("pierce");
			break;
		}// end case none
		case "pound": {
			editingObject.setWpndmgType("pound");
			break;
		}// end case none
		case "stab": {
			editingObject.setWpndmgType("stab");
			break;
		}// end case none
		case "cleave": {
			editingObject.setWpndmgType("cleave");
			break;
		}// end case none
		case "sting": {
			editingObject.setWpndmgType("sting");
			break;
		}// end case none
		default: {
			break;
		}
		}

	} // end setwpndmgType


	//currently unused obj variable
	/*
	private static void setv21() {
		// unused

		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");
	} // end setv21 // unused place holder
	 */


	private static void setarmrType() {
		// 
		// armor type // none (0%), cloth (1-2%), leather (3-4%), mail (4-5%), plate (5-10%?), shields (5-10%)?
		editingObject.returnObjectInfo();
		System.out.println ("Current Armor type: " + editingObject.getArmorType());
		System.out.println("Valid Armor Types: none, cloth, leather, mail , plate");
		System.out.println("Enter new Armor type.");

		System.out.println(" ");
		System.out.println(editor + "Editor");
		kinput = input.nextLine();
		switch (kinput) {
		case "none": {
			editingObject.setArmorType("none");
			editingObject.setDmgRedux(0);
			break;
		}// end case none
		case "cloth": {
			editingObject.setArmorType("cloth");
			editingObject.setDmgRedux(1);
			break;
		} // end case "cloth"
		case "leather": {
			editingObject.setArmorType("leather");
			editingObject.setDmgRedux(2);
			break;
		}// end case "leather"
		case "mail": {
			editingObject.setArmorType("mail");
			editingObject.setDmgRedux(3);
			break;
		}// end case "mail"
		case "plate": {
			editingObject.setArmorType("plate");
			editingObject.setDmgRedux(4);
			break;
		}// end case "plate"

		default: {
			break;
		}
		}

	} // end setarmrType()

	private static void setdmgRed() {
		//  sets the damage redux value for the armor
		// 
		System.out.println ("Current Armor Damage Redux: " + editingObject.getDmgRedux());
		System.out.println("Valid Armor generally: none (0%), cloth (1%), leather (2%), mail (3%), plate (4%)");
		System.out.println("Please note that this is stat is pre-set via 'set obj armor type'");
		System.out.println("Enter new Damage Redux percentage");
		kinput = input.nextLine();
		switch (kinput) {
		case "0": {
			editingObject.setDmgRedux(0);	
			break;
		}
		case "1": {
			editingObject.setDmgRedux(1);
			break;
		}
		case "2": {
			editingObject.setDmgRedux(2);
			break;
		}
		case "3": {
			editingObject.setDmgRedux(3);
			break;
		}
		case "4": {
			editingObject.setDmgRedux(4);
			break;
		}
		case "5": {
			editingObject.setDmgRedux(5);
			break;
		}
		case "6": {
			editingObject.setDmgRedux(6);
			break;
		}
		case "7": {
			editingObject.setDmgRedux(7);
			break;
		}
		case "8": {
			editingObject.setDmgRedux(8);
			break;
		}
		case "9": {
			editingObject.setDmgRedux(9);
			break;
		}

		default: {

			break;
		}
		}
		System.out.println("Armor Damage Redux is now: " + editingObject.getDmgRedux());
	} // end setdmgRed()


	private static void sethpRes() {
		// restores a set amount of HPs to player
		System.out.println("The Food's current HP Restore amount is: " + editingObject.getHpRestore());
		System.out.println("Enter new HP Restore amount.");
		int iinput = input.nextInt();
		if (iinput >= 0) {
			editingObject.setHpRestore(iinput);	
		}
		else {
			System.out.println("The Food's HP Restore amount must be positive.");
			sethpRes();
		}

		System.out.println("The Food's new HP Restore amount is: " + editingObject.getHpRestore());

	} // end sethpRes()


	private static void setmpRes() {
		// restores a set amount of MPs to player
		System.out.println("The Drink's current Mana Restore amount is: " + editingObject.getMpRestore());
		System.out.println("Enter new Mana Restore amount.");
		int iinput = input.nextInt();
		if (iinput >= 0) {
			editingObject.setMpRestore(iinput);	
		}
		else {
			System.out.println("The Drink's Mana Restore amount must be positive.");
			setmpRes();
		}

		System.out.println("The Drink's new Mana Restore amount is: " + editingObject.getMpRestore());

	} // end setmpRes()


	private static void setpSpell() {
		// TODO


	} // end setpSpell()

	private static void setwSpell() {
		// TODO


	} // end setwSpell()


	private static void setwCharge() {
		// Set the wands charge count
		System.out.println("The Wand's current Charge count is: " + editingObject.getWandCharge());
		System.out.println("Enter new Wand Charge count.");
		int iinput = input.nextInt();
		if (iinput >= 0) {
			editingObject.setWandCharge(iinput);	
		}
		else {
			System.out.println("The Wand's Charge count must be positive.");
			setwCharge();
		}

		System.out.println("The Wand's new Charge count is: " + editingObject.getWandCharge());

	} // end setwCharge()


	private static void setcSize() {
		// sets the container size...may move to fixed size of 6 to match obj/mob-in-room 
		System.out.println("The object's Container Size setting is currently: " + editingObject.getCntSize());
		System.out.println("Enter new  Container Size. (1-6), 0 for not a container. Please change object type.");
		int iinput = input.nextInt();

		switch (iinput) {
		case 1: {
			editingObject.setCntSize(1);
			break;
		}
		case 2: {
			editingObject.setCntSize(2);
			break;
		}
		case 3: {
			editingObject.setCntSize(3);
			break;
		}
		case 4: {
			editingObject.setCntSize(4);
			break;
		}
		case 5: {
			editingObject.setCntSize(5);
			break;
		}
		case 6: {
			editingObject.setCntSize(6);
			break;
		}
		default: {
			System.out.println("Not valid input, exiting...");	
			break;
		}

		}

		System.out.println("The object's Container Size setting is now: " + editingObject.getCntSize());

	} //end setcSize()


	private static void setcCont() { // 31
		// TODO


	}// end setcCont()


	// currently unused obj fields
	/*
	private static void setv32() {
		// unused
	}
	private static void setv33() {
		// unused
	}
	private static void setv34() {
		// unused
	}
	private static void setv35() {
		// unused
	}
	private static void setv36() {
		// unused
	}
	private static void setv37() {
		// unused
	}
	private static void setv38() {
		// unused
	}
	private static void setv39() {
		// unused
	}
	private static void setv40() {
		// unused
	}
	private static void setv41() {
		// unused
	}
	private static void setv42() {
		// unused
	}
	private static void setv43() {
		// unused
	}
	private static void setv44() {
		// unused
	}
	private static void setv45() {
		// unused
	}
	 */

	private static void setbGlow() { //46
		// set te objects blue glow setting
		System.out.println("The object's Blue Glow setting is currently: " + editingObject.getBlueGlow());
		System.out.println("Enter new Blue Glow value.");
		int iinput = input.nextInt();
		switch (iinput) {
		case 1: {
			editingObject.setBlueGlow(1);			
			break;
		}
		case 0: {
			editingObject.setBlueGlow(0);			
			break;
		}
		default: {			
		}
		} // end setbGlow()	
		System.out.println("The object's Blue Blow setting is now: " + editingObject.getBlueGlow());


	} // end setbGlow()


	private static void setrGlow() { //47
		// set the objects red glow setting
		System.out.println("The object's Red Glow setting is currently: " + editingObject.getRedGlow());
		System.out.println("Enter new Red Glow value.  Please enter a 0 or 1.");
		int iinput = input.nextInt();
		switch (iinput) {
		case 1: {
			editingObject.setRedGlow(1);			
			break;
		}
		case 0: {
			editingObject.setRedGlow(0);			
			break;
		}
		default: {			
			break;
		}
		} // end setbGlow()	
		System.out.println("The object's Red Glow setting is now: " + editingObject.getRedGlow());


	} // end setrGlow()


	private static void sethums() { //48
		// set the objects hum setting
		System.out.println("The object's Hum setting is currently: " + editingObject.getHum());
		System.out.println("Enter new Hum setting.  Please enter a 0 or 1.");
		int iinput = input.nextInt();
		switch (iinput) {
		case 1: {
			editingObject.setHum(1);			
			break;
		}
		case 0: {
			editingObject.setHum(0);			
			break;
		}
		default: {			
		}
		} // end setbGlow()	
		System.out.println("The object's Hum setting is now: " + editingObject.getHum());

	} // end sethums()


	private static void setcurseditem() {
		// sets the objects cursed (item) setting
		System.out.println("The object's Cursed setting is currently: " + editingObject.getCursed());
		System.out.println("Enter new Cursed value.  Please enter a 0 or 1");
		int iinput = input.nextInt();
		switch (iinput) {
		case 1: {
			editingObject.setCursed(1);			
			break;
		}
		case 0: {
			editingObject.setCursed(0);			
			break;
		}
		default: {			
		}
		} // end setbGlow()	
		System.out.println("The object's Cursed setting is now: " + editingObject.getCursed());

	} // end setcurseditem()


	private static void setSpeech1(mob m) {
		// sets the mob's first speech
		System.out.println("");
		System.out.println("Enter new first speech");
		System.out.println("If you wish to keep the current speech/line, press enter/return");
		kinput = input.nextLine();
		if (kinput == "") {
			m.setV47(m.getV47());
		}
		else { 
			m.setV47(kinput); 
		}
		System.out.println("New first Speech: " + m.getV47());
	} // end setSpeech1(mob m)


	private static void setSpeech2(mob m) {
		// sets the mobs second speech
		System.out.println("");
		System.out.println("Enter new second speech");
		System.out.println("If you wish to keep the current speech/line, press enter/return");
		kinput = input.nextLine();
		if (kinput == "") {
			m.setV48(m.getV48());
		}
		else { 
			m.setV48(kinput); 
		}
		System.out.println("New second Speech: " + m.getV48());
	} // end setSpeech2(mob m)


	private static void setSpeech3(mob m) {
		// sets the mobs third speech
		System.out.println("");
		System.out.println("Enter new third speech");
		System.out.println("If you wish to keep the current speech/line, press enter/return");
		kinput = input.nextLine();
		if (kinput == "") {
			m.setV49(m.getV49());
		}
		else { 
			m.setV49(kinput); 
		}
		System.out.println("New third Speech: " + m.getV49());
	} // end setSpeech3(mob m)


	private static void setMobTalker(mob m) {
		// set mob talker state
		String tstate = "";
		if (m.getV46() == 1) {
			tstate = "talker";
		}
		else { tstate = "not talker";
		}
		System.out.println("The mob's talker state is: " + m.getV46() + " or " + tstate);
		System.out.println("Enter new talker state. Please enter a 0 or 1");
		int iinput = input.nextInt();
		switch(iinput) {
		case 0: {
			m.setV46(0);
			break;	
		}
		case 1: {
			m.setV46(1);

			System.out.println("");
			System.out.println("First Speech: " + m.getV47());
			System.out.println("");
			System.out.println("Second Speech: " + m.getV48());
			System.out.println("");
			System.out.println("Third Speech: " + m.getV49());

			setSpeech1(m);
			setSpeech2(m);
			setSpeech3(m);

			System.out.println("");
			System.out.println("New first Speech: " + m.getV47());
			System.out.println("New second Speech: " + m.getV48());
			System.out.println("New third Speech: " + m.getV49());

			break;
		}
		default: {
			break;
		}
		} // end switch(iinput)

	} // end setMobTalker


	private static void lookRoomMob() throws Exception {
		// looks at the individual mobs in the room
		System.out.println("Which mob would you like to looke at?");
		kinput = input.nextLine();
		switch (kinput) { // end switch (kinput)
		case "look 1.mob": {
			if (tmob0.getMobNum()>0) {
				lookMob(tmob0);
				mSlot = "tmob0";
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 2.mob": {
			if (tmob1.getMobNum()>0) {
				lookMob(tmob1);
				mSlot = "tmob1";
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 3.mob": {
			if (tmob2.getMobNum()>0) {
				lookMob(tmob2);
				mSlot = "tmob2";
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 4.mob": {
			if (tmob3.getMobNum()>0) {
				lookMob(tmob3);
				mSlot = "tmob3";
			}
			break;
		}
		case "look 5.mob": {
			if (tmob4.getMobNum()>0) {
				lookMob(tmob4);
				mSlot = "tmob4";
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		case "look 6.mob": {
			if (tmob5.getMobNum()>0) {
				lookMob(tmob5);
				mSlot = "tmob5";
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}

		// aslo do #.mob, #'s instead of look #.mob
		case "1.mob": {
			if (tmob0.getMobNum()>0) {
				lookMob(tmob0);
				mSlot = "tmob0";
			}
			break;
		}
		case "2.mob": {
			if (tmob1.getMobNum()>0) {
				lookMob(tmob1);
				mSlot = "tmob1";
			}
			break;
		}
		case "3.mob": {
			if (tmob2.getMobNum()>0) {
				lookMob(tmob2);
				mSlot = "tmob2";
			}
			break;
		}
		case "4.mob": {
			if (tmob3.getMobNum()>0) {
				lookMob(tmob3);
				mSlot = "tmob3";
			}
			break;
		}
		case "5.mob": {
			if (tmob4.getMobNum()>0) {
				lookMob(tmob4);
				mSlot = "tmob4";
			}
			break;
		}
		case "6.mob": {
			if (tmob5.getMobNum()>0) {
				lookMob(tmob5);
				mSlot = "tmob5";
			}
			break;
		}

		// also look at "1", assume mob
		case "1": {
			if (tmob0.getMobNum()>0) {
				lookMob(tmob0);
				mSlot = "tmob0";
			}
			break;
		}
		case "2": {
			if (tmob1.getMobNum()>0) {
				lookMob(tmob1);
				mSlot = "tmob1";
			}
			break;
		}
		case "3": {
			if (tmob2.getMobNum()>0) {
				lookMob(tmob2);
				mSlot = "tmob2";
			}
			break;
		}
		case "4": {
			if (tmob3.getMobNum()>0) {
				lookMob(tmob3);
				mSlot = "tmob3";
			}
			break;
		}
		case "5": {
			if (tmob4.getMobNum()>0) {
				lookMob(tmob4);
				mSlot = "tmob4";
			}
			break;
		}
		case "6": {
			if (tmob5.getMobNum()>0) {
				lookMob(tmob5);
				mSlot = "tmob5";
			}
			break;
		}


		default: {
			System.out.println("No suck mob exists.");
		}
		} // end switch (kinput)
	} // end lookRoomMob()



	private static void gotoRoom2(int i) throws Exception {
		if (i < nextAvailRoom ) {
			buildCurrentRoom(i);
			curRmNum = newRoom.getRoomNum();
			System.out.println("You appear with a crackle of sparks and a puff of smoke.");
			commandAnalyzer("look");
		}
		else {
			System.out.println("Not a valid room");
		}
	}  // end gotoRoom2()

	private static void gotoRoomSample2(int rnum) throws Exception {
		// uses nested if/else statements
		// attempts to go to the passed room number 

		int rToGoTo = rnum; // passed room number

		int r00 = currentZone.rm00.getRoomNum();
		int r01 = currentZone.rm01.getRoomNum();
		int r02 = currentZone.rm02.getRoomNum();
		int r03 = currentZone.rm03.getRoomNum();
		int r04 = currentZone.rm04.getRoomNum();
		int r05 = currentZone.rm05.getRoomNum();
		int r06 = currentZone.rm06.getRoomNum();
		int r07 = currentZone.rm07.getRoomNum();
		int r08 = currentZone.rm08.getRoomNum();
		int r09 = currentZone.rm09.getRoomNum();

		int r10 = currentZone.rm10.getRoomNum();
		int r11 = currentZone.rm11.getRoomNum();
		int r12 = currentZone.rm12.getRoomNum();
		int r13 = currentZone.rm13.getRoomNum();
		int r14 = currentZone.rm14.getRoomNum();
		int r15 = currentZone.rm15.getRoomNum();
		int r16 = currentZone.rm16.getRoomNum();
		int r17 = currentZone.rm17.getRoomNum();
		int r18 = currentZone.rm18.getRoomNum();
		int r19 = currentZone.rm19.getRoomNum();

		int r20 = currentZone.rm20.getRoomNum();
		int r21 = currentZone.rm21.getRoomNum();
		int r22 = currentZone.rm22.getRoomNum();
		int r23 = currentZone.rm23.getRoomNum();
		int r24 = currentZone.rm24.getRoomNum();
		int r25 = currentZone.rm25.getRoomNum();
		int r26 = currentZone.rm26.getRoomNum();
		int r27 = currentZone.rm27.getRoomNum();
		int r28 = currentZone.rm28.getRoomNum();
		int r29 = currentZone.rm29.getRoomNum();

		int r30 = currentZone.rm30.getRoomNum();
		int r31 = currentZone.rm31.getRoomNum();
		int r32 = currentZone.rm32.getRoomNum();
		int r33 = currentZone.rm33.getRoomNum();
		int r34 = currentZone.rm34.getRoomNum();
		int r35 = currentZone.rm35.getRoomNum();
		int r36 = currentZone.rm36.getRoomNum();
		int r37 = currentZone.rm37.getRoomNum();
		int r38 = currentZone.rm38.getRoomNum();
		int r39 = currentZone.rm39.getRoomNum();

		int r40 = currentZone.rm40.getRoomNum();
		int r41 = currentZone.rm41.getRoomNum();
		int r42 = currentZone.rm42.getRoomNum();
		int r43 = currentZone.rm43.getRoomNum();
		int r44 = currentZone.rm44.getRoomNum();
		int r45 = currentZone.rm45.getRoomNum();
		int r46 = currentZone.rm46.getRoomNum();
		int r47 = currentZone.rm47.getRoomNum();
		int r48 = currentZone.rm48.getRoomNum();
		int r49 = currentZone.rm49.getRoomNum();

		int r50 = currentZone.rm50.getRoomNum();
		int r51 = currentZone.rm51.getRoomNum();
		int r52 = currentZone.rm52.getRoomNum();
		int r53 = currentZone.rm53.getRoomNum();
		int r54 = currentZone.rm54.getRoomNum();
		int r55 = currentZone.rm55.getRoomNum();
		int r56 = currentZone.rm56.getRoomNum();
		int r57 = currentZone.rm57.getRoomNum();
		int r58 = currentZone.rm58.getRoomNum();
		int r59 = currentZone.rm59.getRoomNum();

		int r60 = currentZone.rm60.getRoomNum();
		int r61 = currentZone.rm61.getRoomNum();
		int r62 = currentZone.rm62.getRoomNum();
		int r63 = currentZone.rm63.getRoomNum();
		int r64 = currentZone.rm64.getRoomNum();
		int r65 = currentZone.rm65.getRoomNum();
		int r66 = currentZone.rm66.getRoomNum();
		int r67 = currentZone.rm67.getRoomNum();
		int r68 = currentZone.rm68.getRoomNum();
		int r69 = currentZone.rm69.getRoomNum();

		int r70 = currentZone.rm70.getRoomNum();
		int r71 = currentZone.rm71.getRoomNum();
		int r72 = currentZone.rm72.getRoomNum();
		int r73 = currentZone.rm73.getRoomNum();
		int r74 = currentZone.rm74.getRoomNum();
		int r75 = currentZone.rm75.getRoomNum();
		int r76 = currentZone.rm76.getRoomNum();
		int r77 = currentZone.rm77.getRoomNum();
		int r78 = currentZone.rm78.getRoomNum();
		int r79 = currentZone.rm79.getRoomNum();

		int r80 = currentZone.rm80.getRoomNum();
		int r81 = currentZone.rm81.getRoomNum();
		int r82 = currentZone.rm82.getRoomNum();
		int r83 = currentZone.rm83.getRoomNum();
		int r84 = currentZone.rm84.getRoomNum();
		int r85 = currentZone.rm85.getRoomNum();
		int r86 = currentZone.rm86.getRoomNum();
		int r87 = currentZone.rm87.getRoomNum();
		int r88 = currentZone.rm88.getRoomNum();
		int r89 = currentZone.rm89.getRoomNum();

		int r90 = currentZone.rm90.getRoomNum();
		int r91 = currentZone.rm91.getRoomNum();
		int r92 = currentZone.rm92.getRoomNum();
		int r93 = currentZone.rm93.getRoomNum();
		int r94 = currentZone.rm94.getRoomNum();
		int r95 = currentZone.rm95.getRoomNum();
		int r96 = currentZone.rm96.getRoomNum();
		int r97 = currentZone.rm97.getRoomNum();
		int r98 = currentZone.rm98.getRoomNum();
		int r99 = currentZone.rm99.getRoomNum();



		// nested if/else test



		//
		// paste into next Else statement, rename the r01's to correspond 
		// if(r01 == rToGoTo) {
		//	buildCurrentRoomSample(rm01, rToGoTo);
		//	curRmNum = curRoom.getRoomNum();
		//	System.out.println("You appear with a crackle of sparks and a puff of smoke.czr01");
		//	commandAnalyzer("null");
		//	} // end if(r01 == rToGoTo) {
		// else {
		// next if(r02 ....keep going for all the potential rooms
		//}

		if (rToGoTo<nextAvailRoom) {
			
			if(r00 == rToGoTo) {
				buildCurrentRoomSample(currentZone.rm00, rToGoTo);
				//curRmNum = currentZone.rm00.getRoomNum();
				curRmNum = rToGoTo;
				newRoom = currentZone.rm00;
				buildCurrentRoom(curRmNum);
				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz0");
				commandAnalyzer("null");
			} // end if(r00 == rToGoTo) {
			else {
				if(r01 == rToGoTo) {
					buildCurrentRoomSample(currentZone.rm01, rToGoTo);
					//curRmNum = currentZone.rm01.getRoomNum();
					curRmNum = rToGoTo;
					buildCurrentRoom(curRmNum);
					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz1");
					commandAnalyzer("null");
				} // end if(r01 == rToGoTo) {
				else {
					// next if(r02 ....
					if(r02 == rToGoTo) {
						buildCurrentRoomSample(currentZone.rm02, rToGoTo);
						//curRmNum = currentZone.rm02.getRoomNum();
						curRmNum = rToGoTo;
						buildCurrentRoom(curRmNum);
						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz2");
						commandAnalyzer("null");
					} // end if(r01 == rToGoTo) {
					else {
						// next if(r02 ....
						if(r03== rToGoTo) {
							buildCurrentRoomSample(currentZone.rm03, rToGoTo);
							curRmNum = rToGoTo;
							//curRmNum = currentZone.rm03.getRoomNum();
							buildCurrentRoom(curRmNum);
							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz3");
							commandAnalyzer("null");
						} // end if(r01 == rToGoTo) {
						else {
							// next if(r02 ....
							if(r04 == rToGoTo) {
								buildCurrentRoomSample(currentZone.rm04, rToGoTo);
								curRmNum = rToGoTo;
								buildCurrentRoom(curRmNum);
								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz4");
								commandAnalyzer("null");
							} // end if(r01 == rToGoTo) {
							else {
								// next if(r02 ....
								if(r05 == rToGoTo) {
									buildCurrentRoomSample(currentZone.rm05, rToGoTo);
									//curRmNum = currentZone.rm00.getRoomNum();
									curRmNum = rToGoTo;
									buildCurrentRoom(curRmNum);
									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz5");
									commandAnalyzer("null");
								} // end if(r01 == rToGoTo) {
								else {
									// next if(r02 ....
									if(r06 == rToGoTo) {
										buildCurrentRoomSample(currentZone.rm06, rToGoTo);
										curRmNum = currentZone.rm00.getRoomNum();
										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz6");
										commandAnalyzer("null");
									} // end if(r01 == rToGoTo) {
									else {
										// next if(r02 ....keep going for all the potential rooms
										// next if(r02 ....
										if(r07 == rToGoTo) {
											buildCurrentRoomSample(currentZone.rm07, rToGoTo);
											curRmNum = curRoom.getRoomNum();
											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz7");
											commandAnalyzer("null");
										} // end if(r01 == rToGoTo) {
										else {
											// next if(r02 ....
											if(r08 == rToGoTo) {
												buildCurrentRoomSample(currentZone.rm08, rToGoTo);
												curRmNum = curRoom.getRoomNum();
												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz8");
												commandAnalyzer("null");
											} // end if(r01 == rToGoTo) {
											else {
												// next if(r02 ....keep going for all the potential rooms
												// next if(r02 ....
												if(r09 == rToGoTo) {
													buildCurrentRoomSample(currentZone.rm09, rToGoTo);
													curRmNum = curRoom.getRoomNum();
													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz9");
													commandAnalyzer("null");
												} // end if(r01 == rToGoTo) {
												else {
													// next if(r02 ....keep going for all the potential rooms
													// next if(r02 ....
													if(r10 == rToGoTo) {
														buildCurrentRoomSample(currentZone.rm10, rToGoTo);
														curRmNum = curRoom.getRoomNum();
														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz10");
														commandAnalyzer("null");
													} // end if(r01 == rToGoTo) {
													else {
														// next if(r02 ....keep going for all the potential rooms
														// next if(r02 ....
														if(r11 == rToGoTo) {
															buildCurrentRoomSample(currentZone.rm11, rToGoTo);
															curRmNum = curRoom.getRoomNum();
															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz11");
															commandAnalyzer("null");
														} // end if(r01 == rToGoTo) {
														else {
															// next if(r02 ....keep going for all the potential rooms
															// next if(r02 ....
															if(r12 == rToGoTo) {
																buildCurrentRoomSample(currentZone.rm12, rToGoTo);
																curRmNum = curRoom.getRoomNum();
																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz12");
																commandAnalyzer("null");
															} // end if(r01 == rToGoTo) {
															else {
																// next if(r02 ....keep going for all the potential rooms
																// next if(r02 ....
																if(r13 == rToGoTo) {
																	buildCurrentRoomSample(currentZone.rm13, rToGoTo);
																	curRmNum = curRoom.getRoomNum();
																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz13");
																	commandAnalyzer("null");
																} // end if(r01 == rToGoTo) {
																else {
																	// next if(r02 ....keep going for all the potential rooms
																	// next if(r02 ....
																	if(r14 == rToGoTo) {
																		buildCurrentRoomSample(currentZone.rm14, rToGoTo);
																		curRmNum = curRoom.getRoomNum();
																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz14");
																		commandAnalyzer("null");
																	} // end if(r01 == rToGoTo) {
																	else {
																		// next if(r02 ....keep going for all the potential rooms
																		// next if(r02 ....
																		if(r15 == rToGoTo) {
																			buildCurrentRoomSample(currentZone.rm15, rToGoTo);
																			curRmNum = curRoom.getRoomNum();
																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz15");
																			commandAnalyzer("null");
																		} // end if(r01 == rToGoTo) {
																		else {
																			// next if(r02 ....keep going for all the potential rooms
																			// next if(r02 ....
																			if(r16 == rToGoTo) {
																				buildCurrentRoomSample(currentZone.rm16, rToGoTo);
																				curRmNum = curRoom.getRoomNum();
																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz16");
																				commandAnalyzer("null");
																			} // end if(r01 == rToGoTo) {
																			else {
																				// next if(r02 ....keep going for all the potential rooms
																				// next if(r02 ....
																				if(r17 == rToGoTo) {
																					buildCurrentRoomSample(currentZone.rm17, rToGoTo);
																					curRmNum = curRoom.getRoomNum();
																					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz17");
																					commandAnalyzer("null");
																				} // end if(r01 == rToGoTo) {
																				else {
																					// next if(r02 ....keep going for all the potential rooms
																					// next if(r02 ....
																					if(r18 == rToGoTo) {
																						buildCurrentRoomSample(currentZone.rm18, rToGoTo);
																						curRmNum = curRoom.getRoomNum();
																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz18");
																						commandAnalyzer("null");
																					} // end if(r01 == rToGoTo) {
																					else {
																						// next if(r02 ....keep going for all the potential rooms
																						// next if(r02 ....
																						if(r19 == rToGoTo) {
																							buildCurrentRoomSample(currentZone.rm19, rToGoTo);
																							curRmNum = curRoom.getRoomNum();
																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz19");
																							commandAnalyzer("null");
																						} // end if(r01 == rToGoTo) {
																						else {
																							// next if(r02 ....keep going for all the potential rooms
																							// next if(r02 ....
																							if(r20 == rToGoTo) {
																								buildCurrentRoomSample(currentZone.rm20, rToGoTo);
																								curRmNum = curRoom.getRoomNum();
																								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz20");
																								commandAnalyzer("null");
																							} // end if(r01 == rToGoTo) {
																							else {
																								// next if(r02 ....keep going for all the potential rooms
																								// next if(r02 ....
																								if(r21 == rToGoTo) {
																									buildCurrentRoomSample(currentZone.rm21, rToGoTo);
																									curRmNum = curRoom.getRoomNum();
																									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz21");
																									commandAnalyzer("null");
																								} // end if(r01 == rToGoTo) {
																								else {
																									// next if(r02 ....keep going for all the potential rooms
																									// next if(r02 ....
																									if(r22 == rToGoTo) {
																										buildCurrentRoomSample(currentZone.rm22, rToGoTo);
																										curRmNum = curRoom.getRoomNum();
																										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz22");
																										commandAnalyzer("null");
																									} // end if(r01 == rToGoTo) {
																									else {
																										// next if(r02 ....keep going for all the potential rooms
																										// next if(r02 ....
																										if(r23 == rToGoTo) {
																											buildCurrentRoomSample(currentZone.rm23, rToGoTo);
																											curRmNum = curRoom.getRoomNum();
																											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz23");
																											commandAnalyzer("null");
																										} // end if(r01 == rToGoTo) {
																										else {
																											// next if(r02 ....keep going for all the potential rooms
																											// next if(r02 ....
																											if(r24 == rToGoTo) {
																												buildCurrentRoomSample(currentZone.rm24, rToGoTo);
																												curRmNum = curRoom.getRoomNum();
																												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz24");
																												commandAnalyzer("null");
																											} // end if(r01 == rToGoTo) {
																											else {
																												// next if(r02 ....keep going for all the potential rooms
																												// next if(r02 ....
																												if(r25 == rToGoTo) {
																													buildCurrentRoomSample(currentZone.rm25, rToGoTo);
																													curRmNum = curRoom.getRoomNum();
																													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz25");
																													commandAnalyzer("null");
																												} // end if(r01 == rToGoTo) {
																												else {
																													// next if(r02 ....keep going for all the potential rooms
																													// next if(r02 ....
																													if(r26 == rToGoTo) {
																														buildCurrentRoomSample(currentZone.rm26, rToGoTo);
																														curRmNum = curRoom.getRoomNum();
																														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz26");
																														commandAnalyzer("null");
																													} // end if(r01 == rToGoTo) {
																													else {
																														// next if(r02 ....keep going for all the potential rooms
																														// next if(r02 ....
																														if(r27 == rToGoTo) {
																															buildCurrentRoomSample(currentZone.rm27, rToGoTo);
																															curRmNum = curRoom.getRoomNum();
																															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz27");
																															commandAnalyzer("null");
																														} // end if(r01 == rToGoTo) {
																														else {
																															// next if(r02 ....keep going for all the potential rooms
																															// next if(r02 ....
																															if(r28 == rToGoTo) {
																																buildCurrentRoomSample(currentZone.rm28, rToGoTo);
																																curRmNum = curRoom.getRoomNum();
																																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz28");
																																commandAnalyzer("null");
																															} // end if(r01 == rToGoTo) {
																															else {
																																// next if(r02 ....keep going for all the potential rooms
																																// next if(r02 ....
																																if(r29 == rToGoTo) {
																																	buildCurrentRoomSample(currentZone.rm29, rToGoTo);
																																	curRmNum = curRoom.getRoomNum();
																																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz29");
																																	commandAnalyzer("null");
																																} // end if(r01 == rToGoTo) {
																																else {
																																	// next if(r02 ....keep going for all the potential rooms
																																	// next if(r02 ....
																																	if(r30 == rToGoTo) {
																																		buildCurrentRoomSample(currentZone.rm30, rToGoTo);
																																		curRmNum = curRoom.getRoomNum();
																																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz30");
																																		commandAnalyzer("null");
																																	} // end if(r01 == rToGoTo) {
																																	else {
																																		// next if(r02 ....keep going for all the potential rooms
																																		// next if(r02 ....
																																		if(r31 == rToGoTo) {
																																			buildCurrentRoomSample(currentZone.rm31, rToGoTo);
																																			curRmNum = curRoom.getRoomNum();
																																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz31");
																																			commandAnalyzer("null");
																																		} // end if(r01 == rToGoTo) {
																																		else {
																																			// next if(r02 ....keep going for all the potential rooms
																																			// next if(r02 ....
																																			if(r32 == rToGoTo) {
																																				buildCurrentRoomSample(currentZone.rm32, rToGoTo);
																																				curRmNum = curRoom.getRoomNum();
																																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz32");
																																				commandAnalyzer("null");
																																			} // end if(r01 == rToGoTo) {
																																			else {
																																				// next if(r02 ....keep going for all the potential rooms
																																				// next if(r02 ....
																																				if(r33 == rToGoTo) {
																																					buildCurrentRoomSample(currentZone.rm33, rToGoTo);
																																					curRmNum = curRoom.getRoomNum();
																																					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz33");
																																					commandAnalyzer("null");
																																				} // end if(r01 == rToGoTo) {
																																				else {
																																					// next if(r02 ....keep going for all the potential rooms
																																					// next if(r02 ....
																																					if(r34 == rToGoTo) {
																																						buildCurrentRoomSample(currentZone.rm34, rToGoTo);
																																						curRmNum = curRoom.getRoomNum();
																																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz34");
																																						commandAnalyzer("null");
																																					} // end if(r01 == rToGoTo) {
																																					else {
																																						// next if(r02 ....keep going for all the potential rooms
																																						// next if(r02 ....
																																						if(r35 == rToGoTo) {
																																							buildCurrentRoomSample(currentZone.rm35, rToGoTo);
																																							curRmNum = curRoom.getRoomNum();
																																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz35");
																																							commandAnalyzer("null");
																																						} // end if(r01 == rToGoTo) {
																																						else {
																																							// next if(r02 ....keep going for all the potential rooms
																																							// next if(r02 ....
																																							if(r36 == rToGoTo) {
																																								buildCurrentRoomSample(currentZone.rm36, rToGoTo);
																																								curRmNum = curRoom.getRoomNum();
																																								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz36");
																																								commandAnalyzer("null");
																																							} // end if(r01 == rToGoTo) {
																																							else {
																																								// next if(r02 ....keep going for all the potential rooms
																																								// next if(r02 ....
																																								if(r37 == rToGoTo) {
																																									buildCurrentRoomSample(currentZone.rm37, rToGoTo);
																																									curRmNum = curRoom.getRoomNum();
																																									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz37");
																																									commandAnalyzer("null");
																																								} // end if(r01 == rToGoTo) {
																																								else {
																																									// next if(r02 ....keep going for all the potential rooms
																																									// next if(r02 ....
																																									if(r38 == rToGoTo) {
																																										buildCurrentRoomSample(currentZone.rm38, rToGoTo);
																																										curRmNum = curRoom.getRoomNum();
																																										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz38");
																																										commandAnalyzer("null");
																																									} // end if(r01 == rToGoTo) {
																																									else {
																																										// next if(r02 ....keep going for all the potential rooms
																																										// next if(r02 ....
																																										if(r39 == rToGoTo) {
																																											buildCurrentRoomSample(currentZone.rm39, rToGoTo);
																																											curRmNum = curRoom.getRoomNum();
																																											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz39");
																																											commandAnalyzer("null");
																																										} // end if(r01 == rToGoTo) {
																																										else {
																																											// next if(r02 ....keep going for all the potential rooms
																																											// next if(r02 ....
																																											if(r40 == rToGoTo) {
																																												buildCurrentRoomSample(currentZone.rm40, rToGoTo);
																																												curRmNum = curRoom.getRoomNum();
																																												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz40");
																																												commandAnalyzer("null");
																																											} // end if(r01 == rToGoTo) {
																																											else {
																																												// next if(r02 ....keep going for all the potential rooms
																																												// next if(r02 ....
																																												if(r41 == rToGoTo) {
																																													buildCurrentRoomSample(currentZone.rm41, rToGoTo);
																																													curRmNum = curRoom.getRoomNum();
																																													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz41");
																																													commandAnalyzer("null");
																																												} // end if(r01 == rToGoTo) {
																																												else {
																																													// next if(r02 ....keep going for all the potential rooms
																																													// next if(r02 ....
																																													if(r42 == rToGoTo) {
																																														buildCurrentRoomSample(currentZone.rm42, rToGoTo);
																																														curRmNum = curRoom.getRoomNum();
																																														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz42");
																																														commandAnalyzer("null");
																																													} // end if(r01 == rToGoTo) {
																																													else {
																																														// next if(r02 ....keep going for all the potential rooms
																																														// next if(r02 ....
																																														if(r43 == rToGoTo) {
																																															buildCurrentRoomSample(currentZone.rm43, rToGoTo);
																																															curRmNum = curRoom.getRoomNum();
																																															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz43");
																																															commandAnalyzer("null");
																																														} // end if(r01 == rToGoTo) {
																																														else {
																																															// next if(r02 ....keep going for all the potential rooms
																																															// next if(r02 ....
																																															if(r44 == rToGoTo) {
																																																buildCurrentRoomSample(currentZone.rm44, rToGoTo);
																																																curRmNum = curRoom.getRoomNum();
																																																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz44");
																																																commandAnalyzer("null");
																																															} // end if(r01 == rToGoTo) {
																																															else {
																																																// next if(r02 ....keep going for all the potential rooms
																																																// next if(r02 ....
																																																if(r45 == rToGoTo) {
																																																	buildCurrentRoomSample(currentZone.rm45, rToGoTo);
																																																	curRmNum = curRoom.getRoomNum();
																																																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz45");
																																																	commandAnalyzer("null");
																																																} // end if(r01 == rToGoTo) {
																																																else {
																																																	// next if(r02 ....keep going for all the potential rooms
																																																	// next if(r02 ....
																																																	if(r46 == rToGoTo) {
																																																		buildCurrentRoomSample(currentZone.rm46, rToGoTo);
																																																		curRmNum = curRoom.getRoomNum();
																																																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz46");
																																																		commandAnalyzer("null");
																																																	} // end if(r01 == rToGoTo) {
																																																	else {
																																																		// next if(r02 ....keep going for all the potential rooms
																																																		// next if(r02 ....
																																																		if(r47 == rToGoTo) {
																																																			buildCurrentRoomSample(currentZone.rm47, rToGoTo);
																																																			curRmNum = curRoom.getRoomNum();
																																																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz47");
																																																			commandAnalyzer("null");
																																																		} // end if(r01 == rToGoTo) {
																																																		else {
																																																			// next if(r02 ....keep going for all the potential rooms
																																																			// next if(r02 ....
																																																			if(r48 == rToGoTo) {
																																																				buildCurrentRoomSample(currentZone.rm48, rToGoTo);
																																																				curRmNum = curRoom.getRoomNum();
																																																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz48");
																																																				commandAnalyzer("null");
																																																			} // end if(r01 == rToGoTo) {
																																																			else {
																																																				// next if(r02 ....keep going for all the potential rooms
																																																				// next if(r02 ....
																																																				if(r49 == rToGoTo) {
																																																					buildCurrentRoomSample(currentZone.rm49, rToGoTo);
																																																					curRmNum = curRoom.getRoomNum();
																																																					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz49");
																																																					commandAnalyzer("null");
																																																				} // end if(r01 == rToGoTo) {
																																																				else {
																																																					// next if(r02 ....keep going for all the potential rooms
																																																					// next if(r02 ....
																																																					if(r50 == rToGoTo) {
																																																						buildCurrentRoomSample(currentZone.rm50, rToGoTo);
																																																						curRmNum = curRoom.getRoomNum();
																																																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz50");
																																																						commandAnalyzer("null");
																																																					} // end if(r01 == rToGoTo) {
																																																					else {
																																																						// next if(r02 ....keep going for all the potential rooms
																																																						// next if(r02 ....
																																																						if(r51 == rToGoTo) {
																																																							buildCurrentRoomSample(currentZone.rm51, rToGoTo);
																																																							curRmNum = curRoom.getRoomNum();
																																																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz51");
																																																							commandAnalyzer("null");
																																																						} // end if(r01 == rToGoTo) {
																																																						else {
																																																							// next if(r02 ....keep going for all the potential rooms
																																																							// next if(r02 ....
																																																							if(r52 == rToGoTo) {
																																																								buildCurrentRoomSample(currentZone.rm52, rToGoTo);
																																																								curRmNum = curRoom.getRoomNum();
																																																								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz52");
																																																								commandAnalyzer("null");
																																																							} // end if(r01 == rToGoTo) {
																																																							else {
																																																								// next if(r02 ....keep going for all the potential rooms
																																																								// next if(r02 ....
																																																								if(r53 == rToGoTo) {
																																																									buildCurrentRoomSample(currentZone.rm53, rToGoTo);
																																																									curRmNum = curRoom.getRoomNum();
																																																									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz53");
																																																									commandAnalyzer("null");
																																																								} // end if(r01 == rToGoTo) {
																																																								else {
																																																									// next if(r02 ....keep going for all the potential rooms
																																																									// next if(r02 ....
																																																									if(r54 == rToGoTo) {
																																																										buildCurrentRoomSample(currentZone.rm54, rToGoTo);
																																																										curRmNum = curRoom.getRoomNum();
																																																										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz54");
																																																										commandAnalyzer("null");
																																																									} // end if(r01 == rToGoTo) {
																																																									else {
																																																										// next if(r02 ....keep going for all the potential rooms
																																																										// next if(r02 ....
																																																										if(r55 == rToGoTo) {
																																																											buildCurrentRoomSample(currentZone.rm55, rToGoTo);
																																																											curRmNum = curRoom.getRoomNum();
																																																											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz55");
																																																											commandAnalyzer("null");
																																																										} // end if(r01 == rToGoTo) {
																																																										else {
																																																											// next if(r02 ....keep going for all the potential rooms
																																																											// next if(r02 ....
																																																											if(r56 == rToGoTo) {
																																																												buildCurrentRoomSample(currentZone.rm57, rToGoTo);
																																																												curRmNum = curRoom.getRoomNum();
																																																												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz56");
																																																												commandAnalyzer("null");
																																																											} // end if(r01 == rToGoTo) {
																																																											else {
																																																												// next if(r02 ....keep going for all the potential rooms
																																																												// next if(r02 ....
																																																												if(r57 == rToGoTo) {
																																																													buildCurrentRoomSample(currentZone.rm57, rToGoTo);
																																																													curRmNum = curRoom.getRoomNum();
																																																													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz57");
																																																													commandAnalyzer("null");
																																																												} // end if(r01 == rToGoTo) {
																																																												else {
																																																													// next if(r02 ....keep going for all the potential rooms
																																																													// next if(r02 ....
																																																													if(r58 == rToGoTo) {
																																																														buildCurrentRoomSample(currentZone.rm58, rToGoTo);
																																																														curRmNum = curRoom.getRoomNum();
																																																														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz58");
																																																														commandAnalyzer("null");
																																																													} // end if(r01 == rToGoTo) {
																																																													else {
																																																														// next if(r02 ....keep going for all the potential rooms
																																																														// next if(r02 ....
																																																														if(r59 == rToGoTo) {
																																																															buildCurrentRoomSample(currentZone.rm59, rToGoTo);
																																																															curRmNum = curRoom.getRoomNum();
																																																															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz59");
																																																															commandAnalyzer("null");
																																																														} // end if(r01 == rToGoTo) {
																																																														else {
																																																															// next if(r02 ....keep going for all the potential rooms
																																																															// next if(r02 ....
																																																															if(r60 == rToGoTo) {
																																																																buildCurrentRoomSample(currentZone.rm60, rToGoTo);
																																																																curRmNum = curRoom.getRoomNum();
																																																																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz60");
																																																																commandAnalyzer("null");
																																																															} // end if(r01 == rToGoTo) {
																																																															else {
																																																																// next if(r02 ....keep going for all the potential rooms
																																																																// next if(r02 ....
																																																																if(r61 == rToGoTo) {
																																																																	buildCurrentRoomSample(currentZone.rm61, rToGoTo);
																																																																	curRmNum = curRoom.getRoomNum();
																																																																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz61");
																																																																	commandAnalyzer("null");
																																																																} // end if(r01 == rToGoTo) {
																																																																else {
																																																																	// next if(r02 ....keep going for all the potential rooms
																																																																	// next if(r02 ....
																																																																	if(r62 == rToGoTo) {
																																																																		buildCurrentRoomSample(currentZone.rm62, rToGoTo);
																																																																		curRmNum = curRoom.getRoomNum();
																																																																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz62");
																																																																		commandAnalyzer("null");
																																																																	} // end if(r01 == rToGoTo) {
																																																																	else {
																																																																		// next if(r02 ....keep going for all the potential rooms
																																																																		// next if(r02 ....
																																																																		if(r63 == rToGoTo) {
																																																																			buildCurrentRoomSample(currentZone.rm63, rToGoTo);
																																																																			curRmNum = curRoom.getRoomNum();
																																																																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz63");
																																																																			commandAnalyzer("null");
																																																																		} // end if(r01 == rToGoTo) {
																																																																		else {
																																																																			// next if(r02 ....keep going for all the potential rooms
																																																																			// next if(r02 ....
																																																																			if(r64 == rToGoTo) {
																																																																				buildCurrentRoomSample(currentZone.rm64, rToGoTo);
																																																																				curRmNum = curRoom.getRoomNum();
																																																																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz64");
																																																																				commandAnalyzer("null");
																																																																			} // end if(r01 == rToGoTo) {
																																																																			else {
																																																																				// next if(r02 ....keep going for all the potential rooms
																																																																				// next if(r02 ....
																																																																				if(r65 == rToGoTo) {
																																																																					buildCurrentRoomSample(currentZone.rm65, rToGoTo);
																																																																					curRmNum = curRoom.getRoomNum();
																																																																					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz65");
																																																																					commandAnalyzer("null");
																																																																				} // end if(r01 == rToGoTo) {
																																																																				else {
																																																																					// next if(r02 ....keep going for all the potential rooms
																																																																					// next if(r02 ....
																																																																					if(r66 == rToGoTo) {
																																																																						buildCurrentRoomSample(currentZone.rm66, rToGoTo);
																																																																						curRmNum = curRoom.getRoomNum();
																																																																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz66");
																																																																						commandAnalyzer("null");
																																																																					} // end if(r01 == rToGoTo) {
																																																																					else {
																																																																						// next if(r02 ....keep going for all the potential rooms
																																																																						// next if(r02 ....
																																																																						if(r67 == rToGoTo) {
																																																																							buildCurrentRoomSample(currentZone.rm67, rToGoTo);
																																																																							curRmNum = curRoom.getRoomNum();
																																																																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz67");
																																																																							commandAnalyzer("null");
																																																																						} // end if(r01 == rToGoTo) {
																																																																						else {
																																																																							// next if(r02 ....keep going for all the potential rooms
																																																																							// next if(r02 ....
																																																																							if(r68 == rToGoTo) {
																																																																								buildCurrentRoomSample(currentZone.rm68, rToGoTo);
																																																																								curRmNum = curRoom.getRoomNum();
																																																																								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz68");
																																																																								commandAnalyzer("null");
																																																																							} // end if(r01 == rToGoTo) {
																																																																							else {
																																																																								// next if(r02 ....keep going for all the potential rooms
																																																																								// next if(r02 ....
																																																																								if(r69 == rToGoTo) {
																																																																									buildCurrentRoomSample(currentZone.rm69, rToGoTo);
																																																																									curRmNum = curRoom.getRoomNum();
																																																																									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz69");
																																																																									commandAnalyzer("null");
																																																																								} // end if(r01 == rToGoTo) {
																																																																								else {
																																																																									// next if(r02 ....keep going for all the potential rooms
																																																																									// next if(r02 ....
																																																																									if(r70 == rToGoTo) {
																																																																										buildCurrentRoomSample(currentZone.rm70, rToGoTo);
																																																																										curRmNum = curRoom.getRoomNum();
																																																																										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz70");
																																																																										commandAnalyzer("null");
																																																																									} // end if(r01 == rToGoTo) {
																																																																									else {
																																																																										// next if(r02 ....keep going for all the potential rooms
																																																																										// next if(r02 ....
																																																																										if(r71 == rToGoTo) {
																																																																											buildCurrentRoomSample(currentZone.rm71, rToGoTo);
																																																																											curRmNum = curRoom.getRoomNum();
																																																																											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz71");
																																																																											commandAnalyzer("null");
																																																																										} // end if(r01 == rToGoTo) {
																																																																										else {
																																																																											// next if(r02 ....keep going for all the potential rooms
																																																																											// next if(r02 ....
																																																																											if(r72 == rToGoTo) {
																																																																												buildCurrentRoomSample(currentZone.rm72, rToGoTo);
																																																																												curRmNum = curRoom.getRoomNum();
																																																																												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz72");
																																																																												commandAnalyzer("null");
																																																																											} // end if(r01 == rToGoTo) {
																																																																											else {
																																																																												// next if(r02 ....keep going for all the potential rooms
																																																																												// next if(r02 ....
																																																																												if(r73 == rToGoTo) {
																																																																													buildCurrentRoomSample(currentZone.rm73, rToGoTo);
																																																																													curRmNum = curRoom.getRoomNum();
																																																																													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz73");
																																																																													commandAnalyzer("null");
																																																																												} // end if(r01 == rToGoTo) {
																																																																												else {
																																																																													// next if(r02 ....keep going for all the potential rooms
																																																																													// next if(r02 ....
																																																																													if(r74 == rToGoTo) {
																																																																														buildCurrentRoomSample(currentZone.rm74, rToGoTo);
																																																																														curRmNum = curRoom.getRoomNum();
																																																																														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz74");
																																																																														commandAnalyzer("null");
																																																																													} // end if(r01 == rToGoTo) {
																																																																													else {
																																																																														// next if(r02 ....keep going for all the potential rooms
																																																																														// next if(r02 ....
																																																																														if(r75 == rToGoTo) {
																																																																															buildCurrentRoomSample(currentZone.rm75, rToGoTo);
																																																																															curRmNum = curRoom.getRoomNum();
																																																																															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz75");
																																																																															commandAnalyzer("null");
																																																																														} // end if(r01 == rToGoTo) {
																																																																														else {
																																																																															// next if(r02 ....keep going for all the potential rooms
																																																																															// next if(r02 ....
																																																																															if(r76 == rToGoTo) {
																																																																																buildCurrentRoomSample(currentZone.rm76, rToGoTo);
																																																																																curRmNum = curRoom.getRoomNum();
																																																																																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz76");
																																																																																commandAnalyzer("null");
																																																																															} // end if(r01 == rToGoTo) {
																																																																															else {
																																																																																// next if(r02 ....keep going for all the potential rooms
																																																																																// next if(r02 ....
																																																																																if(r77 == rToGoTo) {
																																																																																	buildCurrentRoomSample(currentZone.rm77, rToGoTo);
																																																																																	curRmNum = curRoom.getRoomNum();
																																																																																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz77");
																																																																																	commandAnalyzer("null");
																																																																																} // end if(r01 == rToGoTo) {
																																																																																else {
																																																																																	// next if(r02 ....keep going for all the potential rooms
																																																																																	// next if(r02 ....
																																																																																	if(r78 == rToGoTo) {
																																																																																		buildCurrentRoomSample(currentZone.rm78, rToGoTo);
																																																																																		curRmNum = curRoom.getRoomNum();
																																																																																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz78");
																																																																																		commandAnalyzer("null");
																																																																																	} // end if(r01 == rToGoTo) {
																																																																																	else {
																																																																																		// next if(r02 ....keep going for all the potential rooms
																																																																																		// next if(r02 ....
																																																																																		if(r79 == rToGoTo) {
																																																																																			buildCurrentRoomSample(currentZone.rm79, rToGoTo);
																																																																																			curRmNum = curRoom.getRoomNum();
																																																																																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz79");
																																																																																			commandAnalyzer("null");
																																																																																		} // end if(r01 == rToGoTo) {
																																																																																		else {
																																																																																			// next if(r02 ....keep going for all the potential rooms
																																																																																			// next if(r02 ....
																																																																																			if(r80 == rToGoTo) {
																																																																																				buildCurrentRoomSample(currentZone.rm80, rToGoTo);
																																																																																				curRmNum = curRoom.getRoomNum();
																																																																																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz80");
																																																																																				commandAnalyzer("null");
																																																																																			} // end if(r01 == rToGoTo) {
																																																																																			else {
																																																																																				// next if(r02 ....keep going for all the potential rooms
																																																																																				// next if(r02 ....
																																																																																				if(r81 == rToGoTo) {
																																																																																					buildCurrentRoomSample(currentZone.rm81, rToGoTo);
																																																																																					curRmNum = curRoom.getRoomNum();
																																																																																					System.out.println("You appear with a crackle of sparks and a puff of smoke.cz81");
																																																																																					commandAnalyzer("null");
																																																																																				} // end if(r01 == rToGoTo) {
																																																																																				else {
																																																																																					// next if(r02 ....keep going for all the potential rooms
																																																																																					// next if(r02 ....
																																																																																					if(r82 == rToGoTo) {
																																																																																						buildCurrentRoomSample(currentZone.rm82, rToGoTo);
																																																																																						curRmNum = curRoom.getRoomNum();
																																																																																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz82");
																																																																																						commandAnalyzer("null");
																																																																																					} // end if(r01 == rToGoTo) {
																																																																																					else {
																																																																																						// next if(r02 ....keep going for all the potential rooms
																																																																																						// next if(r02 ....
																																																																																						if(r83 == rToGoTo) {
																																																																																							buildCurrentRoomSample(currentZone.rm83, rToGoTo);
																																																																																							curRmNum = curRoom.getRoomNum();
																																																																																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz83");
																																																																																							commandAnalyzer("null");
																																																																																						} // end if(r01 == rToGoTo) {
																																																																																						else {
																																																																																							// next if(r02 ....keep going for all the potential rooms
																																																																																							// next if(r02 ....
																																																																																							if(r84 == rToGoTo) {
																																																																																								buildCurrentRoomSample(currentZone.rm84, rToGoTo);
																																																																																								curRmNum = curRoom.getRoomNum();
																																																																																								System.out.println("You appear with a crackle of sparks and a puff of smoke.cz84");
																																																																																								commandAnalyzer("null");
																																																																																							} // end if(r01 == rToGoTo) {
																																																																																							else {
																																																																																								// next if(r02 ....keep going for all the potential rooms
																																																																																								// next if(r02 ....
																																																																																								if(r85 == rToGoTo) {
																																																																																									buildCurrentRoomSample(currentZone.rm85, rToGoTo);
																																																																																									curRmNum = curRoom.getRoomNum();
																																																																																									System.out.println("You appear with a crackle of sparks and a puff of smoke.cz85");
																																																																																									commandAnalyzer("null");
																																																																																								} // end if(r01 == rToGoTo) {
																																																																																								else {
																																																																																									// next if(r02 ....keep going for all the potential rooms
																																																																																									// next if(r02 ....
																																																																																									if(r86 == rToGoTo) {
																																																																																										buildCurrentRoomSample(currentZone.rm86, rToGoTo);
																																																																																										curRmNum = curRoom.getRoomNum();
																																																																																										System.out.println("You appear with a crackle of sparks and a puff of smoke.cz86");
																																																																																										commandAnalyzer("null");
																																																																																									} // end if(r01 == rToGoTo) {
																																																																																									else {
																																																																																										// next if(r02 ....keep going for all the potential rooms
																																																																																										// next if(r02 ....
																																																																																										if(r87 == rToGoTo) {
																																																																																											buildCurrentRoomSample(currentZone.rm87, rToGoTo);
																																																																																											curRmNum = curRoom.getRoomNum();
																																																																																											System.out.println("You appear with a crackle of sparks and a puff of smoke.cz86");
																																																																																											commandAnalyzer("null");
																																																																																										} // end if(r01 == rToGoTo) {
																																																																																										else {
																																																																																											// next if(r02 ....keep going for all the potential rooms
																																																																																											// next if(r02 ....
																																																																																											if(r88 == rToGoTo) {
																																																																																												buildCurrentRoomSample(currentZone.rm88, rToGoTo);
																																																																																												curRmNum = curRoom.getRoomNum();
																																																																																												System.out.println("You appear with a crackle of sparks and a puff of smoke.cz88");
																																																																																												commandAnalyzer("null");
																																																																																											} // end if(r01 == rToGoTo) {
																																																																																											else {
																																																																																												// next if(r02 ....keep going for all the potential rooms
																																																																																												// next if(r02 ....
																																																																																												if(r89 == rToGoTo) {
																																																																																													buildCurrentRoomSample(currentZone.rm89, rToGoTo);
																																																																																													curRmNum = curRoom.getRoomNum();
																																																																																													System.out.println("You appear with a crackle of sparks and a puff of smoke.cz89");
																																																																																													commandAnalyzer("null");
																																																																																												} // end if(r01 == rToGoTo) {
																																																																																												else {
																																																																																													// next if(r02 ....keep going for all the potential rooms
																																																																																													// next if(r02 ....
																																																																																													if(r90 == rToGoTo) {
																																																																																														buildCurrentRoomSample(currentZone.rm90, rToGoTo);
																																																																																														curRmNum = curRoom.getRoomNum();
																																																																																														System.out.println("You appear with a crackle of sparks and a puff of smoke.cz90");
																																																																																														commandAnalyzer("null");
																																																																																													} // end if(r01 == rToGoTo) {
																																																																																													else {
																																																																																														// next if(r02 ....keep going for all the potential rooms
																																																																																														// next if(r02 ....
																																																																																														if(r91 == rToGoTo) {
																																																																																															buildCurrentRoomSample(currentZone.rm91, rToGoTo);
																																																																																															curRmNum = curRoom.getRoomNum();
																																																																																															System.out.println("You appear with a crackle of sparks and a puff of smoke.cz91");
																																																																																															commandAnalyzer("null");
																																																																																														} // end if(r01 == rToGoTo) {
																																																																																														else {
																																																																																															// next if(r02 ....keep going for all the potential rooms
																																																																																															// next if(r02 ....
																																																																																															if(r92 == rToGoTo) {
																																																																																																buildCurrentRoomSample(currentZone.rm92, rToGoTo);
																																																																																																curRmNum = curRoom.getRoomNum();
																																																																																																System.out.println("You appear with a crackle of sparks and a puff of smoke.cz92");
																																																																																																commandAnalyzer("null");
																																																																																															} // end if(r01 == rToGoTo) {
																																																																																															else {
																																																																																																// next if(r02 ....keep going for all the potential rooms
																																																																																																// next if(r02 ....
																																																																																																if(r93 == rToGoTo) {
																																																																																																	buildCurrentRoomSample(currentZone.rm93, rToGoTo);
																																																																																																	curRmNum = curRoom.getRoomNum();
																																																																																																	System.out.println("You appear with a crackle of sparks and a puff of smoke.cz93");
																																																																																																	commandAnalyzer("null");
																																																																																																} // end if(r01 == rToGoTo) {
																																																																																																else {
																																																																																																	// next if(r02 ....keep going for all the potential rooms
																																																																																																	// next if(r02 ....
																																																																																																	if(r94 == rToGoTo) {
																																																																																																		buildCurrentRoomSample(currentZone.rm94, rToGoTo);
																																																																																																		curRmNum = curRoom.getRoomNum();
																																																																																																		System.out.println("You appear with a crackle of sparks and a puff of smoke.cz94");
																																																																																																		commandAnalyzer("null");
																																																																																																	} // end if(r01 == rToGoTo) {
																																																																																																	else {
																																																																																																		// next if(r02 ....keep going for all the potential rooms
																																																																																																		// next if(r02 ....
																																																																																																		if(r95 == rToGoTo) {
																																																																																																			buildCurrentRoomSample(currentZone.rm95, rToGoTo);
																																																																																																			curRmNum = curRoom.getRoomNum();
																																																																																																			System.out.println("You appear with a crackle of sparks and a puff of smoke.cz95");
																																																																																																			commandAnalyzer("null");
																																																																																																		} // end if(r01 == rToGoTo) {
																																																																																																		else {
																																																																																																			// next if(r02 ....keep going for all the potential rooms
																																																																																																			// next if(r02 ....
																																																																																																			if(r96 == rToGoTo) {
																																																																																																				buildCurrentRoomSample(currentZone.rm96, rToGoTo);
																																																																																																				curRmNum = curRoom.getRoomNum();
																																																																																																				System.out.println("You appear with a crackle of sparks and a puff of smoke.cz96");
																																																																																																				commandAnalyzer("null");
																																																																																																			} // end if(r01 == rToGoTo) {
																																																																																																			else {
																																																																																																				// next if(r02 ....keep going for all the potential rooms
																																																																																																				// next if(r02 ....
																																																																																																				if(r97 == rToGoTo) {
																																																																																																					buildCurrentRoomSample(currentZone.rm97, rToGoTo);
																																																																																																					curRmNum = curRoom.getRoomNum();
																																																																																																					System.out.println("You appear with a crackle of sparks and a puff of smoke.c97");
																																																																																																					commandAnalyzer("null");
																																																																																																				} // end if(r01 == rToGoTo) {
																																																																																																				else {
																																																																																																					// next if(r02 ....keep going for all the potential rooms
																																																																																																					// next if(r02 ....
																																																																																																					if(r98 == rToGoTo) {
																																																																																																						buildCurrentRoomSample(currentZone.rm98, rToGoTo);
																																																																																																						curRmNum = curRoom.getRoomNum();
																																																																																																						System.out.println("You appear with a crackle of sparks and a puff of smoke.cz98");
																																																																																																						commandAnalyzer("null");
																																																																																																					} // end if(r01 == rToGoTo) {
																																																																																																					else {
																																																																																																						// next if(r02 ....keep going for all the potential rooms
																																																																																																						// next if(r02 ....
																																																																																																						if(r99 == rToGoTo) {
																																																																																																							buildCurrentRoomSample(currentZone.rm99, rToGoTo);
																																																																																																							curRmNum = curRoom.getRoomNum();
																																																																																																							System.out.println("You appear with a crackle of sparks and a puff of smoke.cz99");
																																																																																																							commandAnalyzer("null");
																																																																																																						} // end if(r01 == rToGoTo) {
																																																																																																						else {
																																																																																																							System.out.println("Room is not inside currentZone: " + currentZone.getZoneNum() + ":" + currentZone.getZoneName() + ", moving on...");
																																																																																																						}
																																																																																																					}
																																																																																																				}
																																																																																																			}
																																																																																																		}
																																																																																																	}
																																																																																																}
																																																																																															}
																																																																																														}
																																																																																													}
																																																																																												}
																																																																																											}
																																																																																										}
																																																																																									}
																																																																																								}
																																																																																							}
																																																																																						}
																																																																																					}
																																																																																				}
																																																																																			}
																																																																																		}
																																																																																	}
																																																																																}
																																																																															}
																																																																														}
																																																																													}
																																																																												}
																																																																											}
																																																																										}
																																																																									}
																																																																								}
																																																																							}
																																																																						}
																																																																					}
																																																																				}
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}				
			}

			// put repeat for previousZone, nextzone1...
			
			
			/* 
			 * 
			// chage currentZone to previousZone...
			// r00 = currentZone.rm00.getRoomNum();

*/

		} // end if (rToGoTo<nextAvailRoom) {
		else { // rToGoTo>=nextAvailRoom, or the room is not loaded
			//	System.out.println("Your power fizzles out and you go nowhere.0");
			System.out.println("You have picked a room beyond the edges of the world.0  Edge:" + nextAvailRoom);
		}

	} // end gotoRoomSample2(i)
	private	static void gotoRoomSample(int i) throws Exception {
		// TODO
		int rToGoTo = i;
		int r00 = currentZone.rm00.getRoomNum();
		int r01 = currentZone.rm01.getRoomNum();
		int r02 = currentZone.rm02.getRoomNum();
		int r03 = currentZone.rm03.getRoomNum();
		int r04 = currentZone.rm04.getRoomNum();
		int r05 = currentZone.rm05.getRoomNum();
		int r06 = currentZone.rm06.getRoomNum();
		int r07 = currentZone.rm07.getRoomNum();
		int r08 = currentZone.rm08.getRoomNum();
		int r09 = currentZone.rm09.getRoomNum();

		int r10 = currentZone.rm10.getRoomNum();
		int r11 = currentZone.rm11.getRoomNum();
		int r12 = currentZone.rm12.getRoomNum();
		int r13 = currentZone.rm13.getRoomNum();
		int r14 = currentZone.rm14.getRoomNum();
		int r15 = currentZone.rm15.getRoomNum();
		int r16 = currentZone.rm16.getRoomNum();
		int r17 = currentZone.rm17.getRoomNum();
		int r18 = currentZone.rm18.getRoomNum();
		int r19 = currentZone.rm19.getRoomNum();

		int r20 = currentZone.rm20.getRoomNum();
		int r21 = currentZone.rm21.getRoomNum();
		int r22 = currentZone.rm22.getRoomNum();
		int r23 = currentZone.rm23.getRoomNum();
		int r24 = currentZone.rm24.getRoomNum();
		int r25 = currentZone.rm25.getRoomNum();
		int r26 = currentZone.rm26.getRoomNum();
		int r27 = currentZone.rm27.getRoomNum();
		int r28 = currentZone.rm28.getRoomNum();
		int r29 = currentZone.rm29.getRoomNum();

		int r30 = currentZone.rm30.getRoomNum();
		int r31 = currentZone.rm31.getRoomNum();
		int r32 = currentZone.rm32.getRoomNum();
		int r33 = currentZone.rm33.getRoomNum();
		int r34 = currentZone.rm34.getRoomNum();
		int r35 = currentZone.rm35.getRoomNum();
		int r36 = currentZone.rm36.getRoomNum();
		int r37 = currentZone.rm37.getRoomNum();
		int r38 = currentZone.rm38.getRoomNum();
		int r39 = currentZone.rm39.getRoomNum();

		int r40 = currentZone.rm40.getRoomNum();
		int r41 = currentZone.rm41.getRoomNum();
		int r42 = currentZone.rm42.getRoomNum();
		int r43 = currentZone.rm43.getRoomNum();
		int r44 = currentZone.rm44.getRoomNum();
		int r45 = currentZone.rm45.getRoomNum();
		int r46 = currentZone.rm46.getRoomNum();
		int r47 = currentZone.rm47.getRoomNum();
		int r48 = currentZone.rm48.getRoomNum();
		int r49 = currentZone.rm49.getRoomNum();

		int r50 = currentZone.rm50.getRoomNum();
		int r51 = currentZone.rm51.getRoomNum();
		int r52 = currentZone.rm52.getRoomNum();
		int r53 = currentZone.rm53.getRoomNum();
		int r54 = currentZone.rm54.getRoomNum();
		int r55 = currentZone.rm55.getRoomNum();
		int r56 = currentZone.rm56.getRoomNum();
		int r57 = currentZone.rm57.getRoomNum();
		int r58 = currentZone.rm58.getRoomNum();
		int r59 = currentZone.rm59.getRoomNum();

		int r60 = currentZone.rm60.getRoomNum();
		int r61 = currentZone.rm61.getRoomNum();
		int r62 = currentZone.rm62.getRoomNum();
		int r63 = currentZone.rm63.getRoomNum();
		int r64 = currentZone.rm64.getRoomNum();
		int r65 = currentZone.rm65.getRoomNum();
		int r66 = currentZone.rm66.getRoomNum();
		int r67 = currentZone.rm67.getRoomNum();
		int r68 = currentZone.rm68.getRoomNum();
		int r69 = currentZone.rm69.getRoomNum();

		int r70 = currentZone.rm70.getRoomNum();
		int r71 = currentZone.rm71.getRoomNum();
		int r72 = currentZone.rm72.getRoomNum();
		int r73 = currentZone.rm73.getRoomNum();
		int r74 = currentZone.rm74.getRoomNum();
		int r75 = currentZone.rm75.getRoomNum();
		int r76 = currentZone.rm76.getRoomNum();
		int r77 = currentZone.rm77.getRoomNum();
		int r78 = currentZone.rm78.getRoomNum();
		int r79 = currentZone.rm79.getRoomNum();

		int r80 = currentZone.rm80.getRoomNum();
		int r81 = currentZone.rm81.getRoomNum();
		int r82 = currentZone.rm82.getRoomNum();
		int r83 = currentZone.rm83.getRoomNum();
		int r84 = currentZone.rm84.getRoomNum();
		int r85 = currentZone.rm85.getRoomNum();
		int r86 = currentZone.rm86.getRoomNum();
		int r87 = currentZone.rm87.getRoomNum();
		int r88 = currentZone.rm88.getRoomNum();
		int r89 = currentZone.rm89.getRoomNum();

		int r90 = currentZone.rm90.getRoomNum();
		int r91 = currentZone.rm91.getRoomNum();
		int r92 = currentZone.rm92.getRoomNum();
		int r93 = currentZone.rm93.getRoomNum();
		int r94 = currentZone.rm94.getRoomNum();
		int r95 = currentZone.rm95.getRoomNum();
		int r96 = currentZone.rm96.getRoomNum();
		int r97 = currentZone.rm97.getRoomNum();
		int r98 = currentZone.rm98.getRoomNum();
		int r99 = currentZone.rm99.getRoomNum();
		
		
		
		if (rToGoTo<nextAvailRoom) {

			if(r00 == rToGoTo) {
				buildCurrentRoomSample(rm00, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.0");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.0");
			}
			if(r01 == rToGoTo) {
				buildCurrentRoomSample(rm01, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.1");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.1");
			}
			if(r02 == rToGoTo) {
				buildCurrentRoomSample(rm02, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.2");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.2");
			}
			if(r03 == rToGoTo) {
				buildCurrentRoomSample(rm03, rToGoTo);

				curRmNum = rm03.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.3");

				buildCurrentRoom(curRmNum);

				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.3");
			}
			if(r04 == rToGoTo) {
				buildCurrentRoomSample(rm04, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.4");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.4");
			}
			if(r05 == rToGoTo) {
				buildCurrentRoomSample(rm05, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.5");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.5");
			}
			if(r06 == rToGoTo) {
				buildCurrentRoomSample(rm06, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.6");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.6");
			}
			if(r07 == rToGoTo) {
				buildCurrentRoomSample(rm07, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.7");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.7");
			}
			if(r08 == rToGoTo) {
				buildCurrentRoomSample(rm08, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.8");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.8");
			}
			if(r09 == rToGoTo) {
				buildCurrentRoomSample(rm09, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.9");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.9");
			}

			// add if(r10-19 
			if(r10 == rToGoTo) {
				buildCurrentRoomSample(rm10, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.10");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.10");
			}
			if(r11 == rToGoTo) {
				buildCurrentRoomSample(rm11, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.11");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.11");
			}
			if(r12 == rToGoTo) {
				buildCurrentRoomSample(rm12, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.12");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.12");
			}
			if(r13 == rToGoTo) {
				buildCurrentRoomSample(rm13, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.13");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.13");
			}
			if(r14 == rToGoTo) {
				buildCurrentRoomSample(rm14, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.14");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.14");
			}
			if(r15 == rToGoTo) {
				buildCurrentRoomSample(rm15, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.15");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.15");
			}
			if(r16 == rToGoTo) {
				buildCurrentRoomSample(rm16, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.16");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.16");
			}
			if(r17 == rToGoTo) {
				buildCurrentRoomSample(rm17, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.17");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.17");
			}
			if(r18 == rToGoTo) {
				buildCurrentRoomSample(rm18, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.18");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.18");
			}
			if(r19 == rToGoTo) {
				buildCurrentRoomSample(rm19, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.19");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.19");
			}


			// add if(r20-29 
			if(r20 == rToGoTo) {
				buildCurrentRoomSample(rm20, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.20");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.20");
			}
			if(r21 == rToGoTo) {
				buildCurrentRoomSample(rm21, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.21");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.21");
			}
			if(r22 == rToGoTo) {
				buildCurrentRoomSample(rm22, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.22");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.22");
			}
			if(r23 == rToGoTo) {
				buildCurrentRoomSample(rm23, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.23");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.23");
			}
			if(r24 == rToGoTo) {
				buildCurrentRoomSample(rm24, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.24");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.24");
			}
			if(r25 == rToGoTo) {
				buildCurrentRoomSample(rm25, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.25");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.25");
			}
			if(r26 == rToGoTo) {
				buildCurrentRoomSample(rm26, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.26");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.26");
			}
			if(r27 == rToGoTo) {
				buildCurrentRoomSample(rm27, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.27");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.27");
			}
			if(r28 == rToGoTo) {
				buildCurrentRoomSample(rm28, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.28");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.28");
			}
			if(r29 == rToGoTo) {
				buildCurrentRoomSample(rm29, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.29");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.29");
			}

			// add if(r30-39 
			if(r30 == rToGoTo) {
				buildCurrentRoomSample(rm30, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.30");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.30");
			}
			if(r31 == rToGoTo) {
				buildCurrentRoomSample(rm31, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.31");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.31");
			}
			if(r32 == rToGoTo) {
				buildCurrentRoomSample(rm32, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.32");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.32");
			}
			if(r33 == rToGoTo) {
				buildCurrentRoomSample(rm33, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.33");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.33");
			}
			if(r34 == rToGoTo) {
				buildCurrentRoomSample(rm34, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.34");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.34");
			}
			if(r35 == rToGoTo) {
				buildCurrentRoomSample(rm35, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.35");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.35");
			}
			if(r36 == rToGoTo) {
				buildCurrentRoomSample(rm36, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.36");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.36");
			}
			if(r37 == rToGoTo) {
				buildCurrentRoomSample(rm37, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.37");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.37");
			}
			if(r38 == rToGoTo) {
				buildCurrentRoomSample(rm38, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.38");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.38");
			}
			if(r39 == rToGoTo) {
				buildCurrentRoomSample(rm39, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.39");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.39");
			}

			// add if(r40-49 
			if(r40 == rToGoTo) {
				buildCurrentRoomSample(rm40, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.40");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.40");
			}
			if(r41 == rToGoTo) {
				buildCurrentRoomSample(rm41, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.41");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.41");
			}
			if(r42 == rToGoTo) {
				buildCurrentRoomSample(rm42, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.42");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.42");
			}
			if(r43 == rToGoTo) {
				buildCurrentRoomSample(rm43, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.43");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.43");
			}
			if(r44 == rToGoTo) {
				buildCurrentRoomSample(rm44, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.44");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.44");
			}
			if(r45 == rToGoTo) {
				buildCurrentRoomSample(rm45, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.45");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.45");
			}
			if(r46 == rToGoTo) {
				buildCurrentRoomSample(rm46, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.46");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.46");
			}
			if(r47 == rToGoTo) {
				buildCurrentRoomSample(rm47, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.47");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.47");
			}
			if(r48 == rToGoTo) {
				buildCurrentRoomSample(rm48, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.48");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.48");
			}
			if(r49 == rToGoTo) {
				buildCurrentRoomSample(rm49, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.49");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.49");
			}
			
			// add if(r50-59 
			if(r50 == rToGoTo) {
				buildCurrentRoomSample(rm50, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.50");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.50");
			}
			if(r51 == rToGoTo) {
				buildCurrentRoomSample(rm51, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.51");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.51");
			}
			if(r52 == rToGoTo) {
				buildCurrentRoomSample(rm52, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.52");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.52");
			}
			if(r53 == rToGoTo) {
				buildCurrentRoomSample(rm53, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.53");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.53");
			}
			if(r54 == rToGoTo) {
				buildCurrentRoomSample(rm54, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.54");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.54");
			}
			if(r55 == rToGoTo) {
				buildCurrentRoomSample(rm55, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.55");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.55");
			}
			if(r56 == rToGoTo) {
				buildCurrentRoomSample(rm56, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.56");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.56");
			}
			if(r57 == rToGoTo) {
				buildCurrentRoomSample(rm57, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.57");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.57");
			}
			if(r58 == rToGoTo) {
				buildCurrentRoomSample(rm58, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.58");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.58");
			}
			if(r59 == rToGoTo) {
				buildCurrentRoomSample(rm59, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.59");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.59");
			}

			// add if(r60-69 
			if(r60 == rToGoTo) {
				buildCurrentRoomSample(rm60, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.60");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.60");
			}
			if(r61 == rToGoTo) {
				buildCurrentRoomSample(rm61, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.61");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.61");
			}
			if(r62 == rToGoTo) {
				buildCurrentRoomSample(rm62, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.62");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.62");
			}
			if(r63 == rToGoTo) {
				buildCurrentRoomSample(rm63, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.63");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.63");
			}
			if(r64 == rToGoTo) {
				buildCurrentRoomSample(rm64, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.64");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.64");
			}
			if(r65 == rToGoTo) {
				buildCurrentRoomSample(rm65, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.65");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.65");
			}
			if(r66 == rToGoTo) {
				buildCurrentRoomSample(rm66, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.66");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.66");
			}
			if(r67 == rToGoTo) {
				buildCurrentRoomSample(rm67, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.67");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.67");
			}
			if(r68 == rToGoTo) {
				buildCurrentRoomSample(rm68, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.68");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.68");
			}
			if(r69 == rToGoTo) {
				buildCurrentRoomSample(rm69, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.69");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.69");
			}

			// add if(r70-79 
			if(r70 == rToGoTo) {
				buildCurrentRoomSample(rm70, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.70");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.70");
			}
			if(r71 == rToGoTo) {
				buildCurrentRoomSample(rm71, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.71");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.71");
			}
			if(r72 == rToGoTo) {
				buildCurrentRoomSample(rm72, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.72");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.72");
			}
			if(r73 == rToGoTo) {
				buildCurrentRoomSample(rm73, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.73");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.73");
			}
			if(r74 == rToGoTo) {
				buildCurrentRoomSample(rm74, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.74");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.74");
			}
			if(r75 == rToGoTo) {
				buildCurrentRoomSample(rm75, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.75");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.75");
			}
			if(r76 == rToGoTo) {
				buildCurrentRoomSample(rm76, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.76");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.76");
			}
			if(r77 == rToGoTo) {
				buildCurrentRoomSample(rm77, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.77");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.77");
			}
			if(r78 == rToGoTo) {
				buildCurrentRoomSample(rm78, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.78");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.78");
			}
			if(r79 == rToGoTo) {
				buildCurrentRoomSample(rm79, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.79");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.79");
			}

			// add if(r80-89 
			if(r80 == rToGoTo) {
				buildCurrentRoomSample(rm80, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.80");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.80");
			}
			if(r81 == rToGoTo) {
				buildCurrentRoomSample(rm81, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.81");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.81");
			}
			if(r82 == rToGoTo) {
				buildCurrentRoomSample(rm82, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.82");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.82");
			}
			if(r83 == rToGoTo) {
				buildCurrentRoomSample(rm83, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.83");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.83");
			}
			if(r84 == rToGoTo) {
				buildCurrentRoomSample(rm84, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.84");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.84");
			}
			if(r85 == rToGoTo) {
				buildCurrentRoomSample(rm85, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.85");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.85");
			}
			if(r86 == rToGoTo) {
				buildCurrentRoomSample(rm86, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.86");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.86");
			}
			if(r87 == rToGoTo) {
				buildCurrentRoomSample(rm87, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.87");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.87");
			}
			if(r88 == rToGoTo) {
				buildCurrentRoomSample(rm88, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.88");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.88");
			}
			if(r89 == rToGoTo) {
				buildCurrentRoomSample(rm89, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.89");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.89");
			}

			// add if(r10-19 
			if(r90 == rToGoTo) {
				buildCurrentRoomSample(rm90, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.90");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.90");
			}
			if(r91 == rToGoTo) {
				buildCurrentRoomSample(rm91, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.91");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.91");
			}
			if(r92 == rToGoTo) {
				buildCurrentRoomSample(rm92, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.92");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.92");
			}
			if(r93 == rToGoTo) {
				buildCurrentRoomSample(rm93, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.93");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.93");
			}
			if(r94 == rToGoTo) {
				buildCurrentRoomSample(rm94, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.94");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.94");
			}
			if(r95 == rToGoTo) {
				buildCurrentRoomSample(rm95, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.95");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.95");
			}
			if(r96 == rToGoTo) {
				buildCurrentRoomSample(rm96, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.96");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.96");
			}
			if(r97 == rToGoTo) {
				buildCurrentRoomSample(rm97, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.97");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.97");
			}
			if(r98 == rToGoTo) {
				buildCurrentRoomSample(rm98, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.98");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.98");
			}
			if(r99 == rToGoTo) {
				buildCurrentRoomSample(rm99, rToGoTo);
				curRmNum = curRoom.getRoomNum();
				System.out.println("You appear with a crackle of sparks and a puff of smoke.99");
				commandAnalyzer("null");
			}
			else {
				System.out.println("Your power fizzles out and you go nowhere.99");
			}


			// end currentZone

			// copy r00.. to newRoom .. buildCurrentRoom(curRmNum);
			
			
			
		}
		else {//The room # does not exist in the DB
			System.out.println("Not a valid room");  
		}
	} // end gotoRoomSample

	private static void gotoRoom() throws Exception {
		// attempts to teleport to desired room
		System.out.println("What room would you like to goto?");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		if (iinput < nextAvailRoom ) {

			buildCurrentRoom(iinput);
			curRmNum = iinput;
			System.out.println("You appear with a crackle of sparks and a puff of smoke.");
			commandAnalyzer("null");
		}
		else {
			System.out.println("Not a valid room");

		}
	} // end gotoRoom()


	private static void setTerrain() throws Exception {
		// sets the terrain type
		if (editor == "room") {
			newRoom.returnRoomInfo2();

			System.out.println("Current terrain setting: " + newRoom.getTerrain());
			System.out.println("0/other = void, 1 = Temperate, 2 = Arrid/Desert, 3 = Tundra/Ice, 4 = Tropical ");

			System.out.println(editor + "Editor");
			int iinput = input.nextInt();
			switch (iinput) {
			case 0: {
				newRoom.setTerrain(iinput);
				break;
			}
			case 1: {
				newRoom.setTerrain(iinput);
				break;
			}
			case 2: {
				newRoom.setTerrain(iinput);
				break;
			}
			case 3: {
				newRoom.setTerrain(iinput);
				break;
			}
			case 4: {
				newRoom.setTerrain(iinput);
				break;
			}
			// add additional terrains/climates here and in RainyWeather3

			default: {
				System.out.println("Invalid terrain/climate setting.");
				setTerrain();
			}
			}

			newRoom.returnRoomInfo2();

		}
		else {
			System.out.println("Not in the room editor.");

		}
	} // end setTerrain()


	private static void exchangeCoins() throws Exception {
		//
		// attempts to exchange coins
		playerCoins(); // output current coins

		System.out.println("How many coins would you like to exchange?");
		System.out.println("The going exchange rate is 1 plat = 10 gold, 1 gold = 100 silver, 1 silver = 100 copper.");
		System.out.println("This must be in the format of <0,0,0,0 coins>.");
		kinput = input.nextLine();

		/*
		 * 	switch with a regex in the default
		 *     switch (s) {
        		case "m": print(); continue;
        		case "s": stat(); break;
        		case "q": return;
        		default:
            	if (s.matches("[A-Z]{1}[a-z]{2}\\d{1,}")) { // 1 uppercase, 2 lowercase, atleast one digit
                	filminfo( s );
            	}
            	break;
    			}
		 */
		switch (kinput) {
		case "": {
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		}
		default: {
			String split[] = kinput.split(" ");
			String coins = split[0].toString();
			String[] exchange = coins.split(",");
			//		System.out.println(split[0]);// array tests
			//		System.out.println(coins);// array tests
			//		System.out.println(Arrays.toString(exchange));// array tests

			int plat = 0 + Integer.parseInt(exchange[0]);
			int gold = 0 + Integer.parseInt(exchange[1]);
			int silver = 0 + Integer.parseInt(exchange[2]);
			int copper = 0 + Integer.parseInt(exchange[3]);

			int excC = 0;
			int excS = 0;
			int excG = 0;
			int excP = 0;
			int exchC = 0;
			int exchS = 0;
			int exchG = 0;
			int crem = 0;
			int srem = 0;
			int grem = 0;
			if (playerinventory.getPmobcopper() >= copper) {
				if (copper > 100) {
					exchC = copper/100;
					crem = copper % 100;
					excC = copper - crem;

					System.out.println(exchC);
					System.out.println(crem);

					playerinventory.setPmobcopper(playerinventory.getPmobcopper() - copper);
					playerinventory.setPmobcopper(playerinventory.getPmobcopper() + crem);
					playerinventory.setPmobsilver(playerinventory.getPmobsilver() + exchC);

				} // end copper
				else {
					System.out.println("You do not have enough copper coins for that.");
				}
			}
			if (playerinventory.getPmobsilver() >= silver) {
				if (silver > 100) {
					exchS = silver/100;
					srem = silver % 100;
					excS = silver - srem;

					System.out.println(exchS);
					System.out.println(srem);

					playerinventory.setPmobsilver(playerinventory.getPmobsilver() - silver);
					playerinventory.setPmobsilver(playerinventory.getPmobsilver() + srem);
					playerinventory.setPmobgold(playerinventory.getPmobgold() + exchS);
				}
				else {
					System.out.println("You do not have enough silver coins for that.");
				}
			}
			if (playerinventory.getPmobgold() >= gold) {
				if (gold > 10) {
					exchG = gold/100;
					grem = gold % 100;
					exchG = gold - grem;

					System.out.println(exchG);
					System.out.println(grem);

					playerinventory.setPmobgold(playerinventory.getPmobgold() - gold);
					playerinventory.setPmobgold(playerinventory.getPmobgold() + grem);
					playerinventory.setPmobplat(playerinventory.getPmobplat() + exchG);
				}
				else {
					System.out.println("You do not have enough gold coins for that.");
				}
			}
			if (playerinventory.getPmobplat() >= plat) {
				if (plat >= 1) {
					excP = plat;
				}
			}
			else {
				System.out.println("You do not have enough platinum coins for that.");
			}

			System.out.println("You have exchanged " + excP+excG + " platinum, " + excG + " gold, " + excS + " silver, " + excC + " copper for "
					+ exchG + " platinum, " + exchS + " gold, " + exchC + " silver, " + crem + " copper coins.");

			playerCoins(); // output total after exchange

		}
		}

	} // end exchangeCoins();


	private static void destroyObj() {
		// TODO
		// destroys object from player inventory
		System.out.println("Which object would you like to drop?");
		int iinput = input.nextInt();
		if (iinput > 0) { // iinput cannot be 0 or negative
			// check if item # is in inventory
			if (pinv0.getObjNum() == iinput) {
				// do stuff here
				System.out.println(pinv0.getObjNum());  // for testing
			}
			else if (pinv1.getObjNum() == iinput) {
				// do stuff here
				System.out.println(pinv0.getObjNum());  // for testing
			}
		}
	} // end destroyObj


	private static void dropObj() {
		// attempts to drop an item from your inventory
		System.out.println("Which object would you like to drop?");
		System.out.println("Remember, the room has a limited amount of space");
		int iinput = input.nextInt();
		if (iinput > 0) { // iinput cannot be 0 or negative
			// check if item # is in inventory
			if (pinv0.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv0";
				dropObj2(swapObj, inv);
			}
			else if (pinv1.getObjNum() == iinput) {
				inv = "pinv1";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv2.getObjNum() == iinput) {
				inv = "pinv2";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv3.getObjNum() == iinput) {
				inv = "pinv3";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv4.getObjNum() == iinput) {
				inv = "pinv4";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv5.getObjNum() == iinput) {
				inv = "pinv5";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv6.getObjNum() == iinput) {
				inv = "pinv6";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv7.getObjNum() == iinput) {
				inv = "pinv7";
				loadObject(swapObj,iinput);
				dropObj2(swapObj, inv);
			}
			else if (pinv8.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv8";
				dropObj2(swapObj, inv);
			}
			else if (pinv9.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv9";
				dropObj2(swapObj, inv);
			}

			// add in else if for pinv10-19
			else if (pinv10.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv10";
				dropObj2(swapObj, inv);
			}
			else if (pinv11.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv11";
				dropObj2(swapObj, inv);
			}
			else if (pinv12.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv12";
				dropObj2(swapObj, inv);
			}
			else if (pinv13.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv13";
				dropObj2(swapObj, inv);
			}
			else if (pinv14.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv14";
				dropObj2(swapObj, inv);
			}
			else if (pinv15.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv15";
				dropObj2(swapObj, inv);
			}
			else if (pinv16.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv16";
				dropObj2(swapObj, inv);
			}
			else if (pinv17.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv17";
				dropObj2(swapObj, inv);
			}
			else if (pinv18.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv18";
				dropObj2(swapObj, inv);
			}
			else if (pinv19.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv19";
				dropObj2(swapObj, inv);
			} 
			//  pinv 20-29

			else if (pinv20.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv20";
				dropObj2(swapObj, inv);
			}
			else if (pinv21.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv21";
				dropObj2(swapObj, inv);
			}
			else if (pinv22.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv22";
				dropObj2(swapObj, inv);
			}
			else if (pinv23.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv23";
				dropObj2(swapObj, inv);
			}
			else if (pinv24.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv24";
				dropObj2(swapObj, inv);
			}
			else if (pinv25.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv25";
				dropObj2(swapObj, inv);
			}
			else if (pinv26.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv26";
				dropObj2(swapObj, inv);
			}
			else if (pinv27.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv27";
				dropObj2(swapObj, inv);
			}
			else if (pinv28.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv28";
				dropObj2(swapObj, inv);
			}
			else if (pinv29.getObjNum() == iinput) {
				loadObject(swapObj,iinput);
				inv = "pinv29";
				dropObj2(swapObj, inv);
			}

			else { System.out.println("You do not have anything like that."); }
		}
	} // end dropObj

	private static void dropObj2(objects objtoDrop1, String inv) {
		// check if ground has room and swaps item
		if (tobj0.getObjNum() == 0 ) {
			String inv2 = "tobj0";
			swapObj3(objtoDrop1, tobj0, playerinventory, inv2);
		}
		else if (tobj1.getObjNum() == 0) {
			String inv2 = "tobj1";
			swapObj3(objtoDrop1, tobj1, playerinventory, inv2);
		}
		else if (tobj1.getObjNum() == 0) {
			String inv2 = "tobj1";
			swapObj3(objtoDrop1, tobj1, playerinventory, inv2);
		}
		else if (tobj3.getObjNum() == 0) {
			String inv2 = "tobj3";
			swapObj3(objtoDrop1, tobj3, playerinventory, inv2);
		}
		else if (tobj4.getObjNum() == 0) {
			String inv2 = "tobj4";
			swapObj3(objtoDrop1, tobj4, playerinventory, inv2);
		}
		else if (tobj5.getObjNum() == 0) {
			String inv2 = "tobj5";
			swapObj3(objtoDrop1, tobj5, playerinventory, inv2);
		}
		// tobj0-tob5 are full
		else {
			System.out.println("The room has too many objects in it.");
		}
	} // end dropObj2



	private static void editObj() {
		//
		// enters the mob editor
		System.out.println("Attempting to enter the obj editor...");
		editor = "object";
		objCommands();

		System.out.println("Enter obj number to edit.");
		kinput = input.nextLine();
		int tempint = Integer.parseInt(kinput);
		editingObject.setObjNum(tempint);

		if (tempint < nextAvailObj) {
			editingObject.setObjNum(tempint);
			editingObject.setObjName(Objects[tempint][1]);
			editingObject.setObjShortDesc(Objects[tempint][2]);
			editingObject.setObjLongDesc(Objects[tempint][3]);
			editingObject.setObjExtDesc(Objects[tempint][4]);

			String t = Objects[tempint][5];
			t.replace("[", "");
			t.replace("]", "");
			String[] t2 = t.split(",");
			editingObject.setObjKeyWords(t2);

			editingObject.setAddStr(Integer.parseInt(Objects[tempint][6]));
			editingObject.setAddStam(Integer.parseInt(Objects[tempint][7]));
			editingObject.setAddInt(Integer.parseInt(Objects[tempint][8]));
			editingObject.setAddAgi(Integer.parseInt(Objects[tempint][9]));
			editingObject.setAddHP(Integer.parseInt(Objects[tempint][10]));
			editingObject.setAddMP(Integer.parseInt(Objects[tempint][11]));
			editingObject.setDurability(Integer.parseInt(Objects[tempint][12]));
			editingObject.setTakeable(Integer.parseInt(Objects[tempint][13]));
			editingObject.setEquipSlot(Objects[tempint][14]);

			editingObject.setObjval(Objects[tempint][15]);

			editingObject.setObjType(Objects[tempint][16]);

			editingObject.setStackSize(Integer.parseInt(Objects[tempint][17]));

			editingObject.setWeaponType(Objects[tempint][18]);
			editingObject.setWeaponDmg(Objects[tempint][19]);
			editingObject.setWpndmgType(Objects[tempint][20]);

			editingObject.setV21(Objects[tempint][21]); // unused

			editingObject.setArmorType(Objects[tempint][22]);
			editingObject.setDmgRedux(Integer.parseInt(Objects[tempint][23]));
			editingObject.setHpRestore(Integer.parseInt(Objects[tempint][24]));
			editingObject.setMpRestore(Integer.parseInt(Objects[tempint][25]));
			editingObject.setPotSpell(Objects[tempint][26]);
			editingObject.setScrollSpell(Objects[tempint][27]);
			editingObject.setWandSpell(Objects[tempint][28]);
			editingObject.setWandCharge(Integer.parseInt(Objects[tempint][29]));
			editingObject.setCntSize(Integer.parseInt(Objects[tempint][30]));

			String temp = Objects[tempint][31];
			temp = temp.replace("[", "");
			temp = temp.replace("]", "");
			temp = temp.strip();
			String[] split = temp.split(",");		

			editingObject.setCntCont(split);

			editingObject.setV21(Objects[tempint][32]);  // unused
			editingObject.setV21(Objects[tempint][33]); // unused
			editingObject.setV21(Objects[tempint][34]); // unused
			editingObject.setV21(Objects[tempint][35]); // unused
			editingObject.setV21(Objects[tempint][36]); // unused
			editingObject.setV21(Objects[tempint][37]); // unused
			editingObject.setV21(Objects[tempint][38]); // unused
			editingObject.setV21(Objects[tempint][39]); // unused
			editingObject.setV21(Objects[tempint][40]); // unused

			editingObject.setV21(Objects[tempint][41]); // unused
			editingObject.setV21(Objects[tempint][42]); // unused
			editingObject.setV21(Objects[tempint][43]); // unused
			editingObject.setV21(Objects[tempint][44]); // unused
			editingObject.setV21(Objects[tempint][45]); // unused

			editingObject.setBlueGlow(Integer.parseInt(Objects[tempint][46]));
			editingObject.setRedGlow(Integer.parseInt(Objects[tempint][47]));
			editingObject.setHum(Integer.parseInt(Objects[tempint][48]));
			editingObject.setCursed(Integer.parseInt(Objects[tempint][49]));


			editingObject.returnObjectFull();

			System.out.println(" ");
			System.out.println(" ");
			System.out.println(editor + "Editor");
		}

		else {
			System.out.println("No such obj exists.");
		}

	} // end editObj()

	private static void editObj2(int objint) {
		// enters the obj editor
		System.out.println("Attempting to enter the obj editor...");
		editor = "object";
		objCommands();

		System.out.println("");

		editingObject.setObjNum(objint);
		editingObject.setObjName(Objects[objint][1]);
		editingObject.setObjShortDesc(Objects[objint][2]);
		editingObject.setObjLongDesc(Objects[objint][3]);
		editingObject.setObjExtDesc(Objects[objint][4]);

		String t = Objects[objint][5];
		t.replace("[", "");
		t.replace("]", "");
		String[] t2 = t.split(",");
		editingObject.setObjKeyWords(t2);

		editingObject.setAddStr(Integer.parseInt(Objects[objint][6]));
		editingObject.setAddStam(Integer.parseInt(Objects[objint][7]));
		editingObject.setAddInt(Integer.parseInt(Objects[objint][8]));
		editingObject.setAddAgi(Integer.parseInt(Objects[objint][9]));
		editingObject.setAddHP(Integer.parseInt(Objects[objint][10]));
		editingObject.setAddMP(Integer.parseInt(Objects[objint][11]));
		editingObject.setDurability(Integer.parseInt(Objects[objint][12]));
		editingObject.setTakeable(Integer.parseInt(Objects[objint][13]));
		editingObject.setEquipSlot(Objects[objint][14]);

		editingObject.setObjval(Objects[objint][15]);

		editingObject.setObjType(Objects[objint][16]);

		editingObject.setStackSize(Integer.parseInt(Objects[objint][17]));

		editingObject.setWeaponType(Objects[objint][18]);
		editingObject.setWeaponDmg(Objects[objint][19]);
		editingObject.setWpndmgType(Objects[objint][20]);

		editingObject.setV21(Objects[objint][21]); // unused

		editingObject.setArmorType(Objects[objint][22]);
		editingObject.setDmgRedux(Integer.parseInt(Objects[objint][23]));
		editingObject.setHpRestore(Integer.parseInt(Objects[objint][24]));
		editingObject.setMpRestore(Integer.parseInt(Objects[objint][25]));
		editingObject.setPotSpell(Objects[objint][26]);
		editingObject.setScrollSpell(Objects[objint][27]);
		editingObject.setWandSpell(Objects[objint][28]);
		editingObject.setWandCharge(Integer.parseInt(Objects[objint][29]));
		editingObject.setCntSize(Integer.parseInt(Objects[objint][30]));

		t = Objects[objint][31];
		t.replace("[", "");
		t.replace("]", "");
		String[] t3 = t.split(",");
		//	editingObject.setObjKeyWords(t2);
		editingObject.setCntCont(t3);

		editingObject.setV21(Objects[objint][32]);  // unused
		editingObject.setV21(Objects[objint][33]); // unused
		editingObject.setV21(Objects[objint][34]); // unused
		editingObject.setV21(Objects[objint][35]); // unused
		editingObject.setV21(Objects[objint][36]); // unused
		editingObject.setV21(Objects[objint][37]); // unused
		editingObject.setV21(Objects[objint][38]); // unused
		editingObject.setV21(Objects[objint][39]); // unused
		editingObject.setV21(Objects[objint][40]); // unused

		editingObject.setV21(Objects[objint][41]); // unused
		editingObject.setV21(Objects[objint][42]); // unused
		editingObject.setV21(Objects[objint][43]); // unused
		editingObject.setV21(Objects[objint][44]); // unused
		editingObject.setV21(Objects[objint][45]); // unused

		editingObject.setBlueGlow(Integer.parseInt(Objects[objint][46]));
		editingObject.setRedGlow(Integer.parseInt(Objects[objint][47]));
		editingObject.setHum(Integer.parseInt(Objects[objint][48]));
		editingObject.setCursed(Integer.parseInt(Objects[objint][49]));


		editingObject.returnObjectFull();
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");

	} // end editObj2(int objint)


	private static void takeObja() {
		// ask which items to take

		// attemps to take object from ground
		System.out.println("Which object would you like to take?");
		kinput = input.nextLine();
		switch (kinput) {
		case "1": {
			if (tobj0.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj0.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 0);
				takeObj2(tobj0);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "1"
		case "2": {
			if (tobj1.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj1.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 1);
				takeObj2(tobj1);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "2"
		case "3": {
			if (tobj2.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj2.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 2);
				takeObj2(tobj2);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "3"
		case "4": {
			if (tobj3.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj3.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 3);
				takeObj2(tobj3);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "4"
		case "5": {
			if (tobj4.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj4.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 4);
				takeObj2(tobj4);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "5"
		case "6": {
			if (tobj5.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj5.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 5);
				takeObj2(tobj5);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "6"
		case "1.obj": {
			if (tobj0.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj0.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 0);
				takeObj2(tobj0);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "1.obj"
		case "2.obj": {
			if (tobj1.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj1.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 1);
				takeObj2(tobj1);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "2.obj"
		case "3.obj": {
			if (tobj2.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj2.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 2);
				takeObj2(tobj2);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "3.obj"
		case "4.obj": {
			if (tobj3.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj3.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 3);
				takeObj2(tobj3);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "4.obj"
		case "5.obj": {
			if (tobj4.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj4.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 4);
				takeObj2(tobj4);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "5.obj"
		case "6.obj": {
			if (tobj5.getTakeable() == 1) { // if the obj is takeable
				System.out.println("You pick up " + tobj5.getObjShortDesc() + " from the ground.");
				newRoom.setObjNumAtPos(0, 5);
				takeObj2(tobj5);
			}
			else { System.out.println("You cannot take that.");
			}
			break;
		} // end case "6.obj"


		case "all 1.corpse": {
			// TODO
			// need to do swap obj to inventory on death for mobs
			// need to do mob inventory stuffs first
			takeObjb(tmob0);
			break;
		}
		case "all 2.corpse": {
			takeObjb(tmob1);
			break;
		}
		case "all 3.corpse": {
			takeObjb(tmob2);
			break;
		}
		case "all 4.corpse": {
			takeObjb(tmob3);
			break;
		}
		case "all 5.corpse": {
			takeObjb(tmob4);
			break;
		}
		case "all 6.corpse": {
			takeObjb(tmob5);
			break;
		}


		default: { System.out.println("You cannot do that."); }
		}
	} // end takeObj


	private static void takeObjb(mob toLoot) {
		// TODO Auto-generated method stub
		// take stuff from mob corpse?
		System.out.println("This is not yet made");
	}


	private static void takeObj2(objects objtotake) {
		// check the inventory for available spot

		// pinv0-9
		if (playerinventory.getPmobInv0() == 0) {
			inv = "pinv0";
			swapObj2(objtotake,pinv0,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv1() == 0) {
			inv = "pinv1";
			swapObj2(objtotake,pinv1,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv2() == 0) {
			inv = "pinv2";
			swapObj2(objtotake,pinv2,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv3() == 0) {
			inv = "pinv3";
			swapObj2(objtotake,pinv3,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv4() == 0) {
			inv = "pinv4";
			swapObj2(objtotake,pinv4,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv5() == 0) {
			inv = "pinv5";
			swapObj2(objtotake,pinv5,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv6() == 0) {
			inv = "pinv6";
			swapObj2(objtotake,pinv6,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv7() == 0) {
			inv = "pinv7";
			swapObj2(objtotake,pinv7,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv8() == 0) {
			inv = "pinv8";
			swapObj2(objtotake,pinv8,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv9() == 0) {
			inv = "pinv9";
			swapObj2(objtotake,pinv9,playerinventory,inv);
		}
		// pinv10-19
		if (playerinventory.getPmobInv10() == 0) {
			inv = "pinv10";
			swapObj2(objtotake,pinv10,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv11() == 0) {
			inv = "pinv11";
			swapObj2(objtotake,pinv11,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv12() == 0) {
			inv = "pinv12";
			swapObj2(objtotake,pinv12,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv13() == 0) {
			inv = "pinv13";
			swapObj2(objtotake,pinv13,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv14() == 0) {
			inv = "pinv14";
			swapObj2(objtotake,pinv14,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv15() == 0) {
			inv = "pinv15";
			swapObj2(objtotake,pinv15,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv16() == 0) {
			inv = "pinv16";
			swapObj2(objtotake,pinv16,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv17() == 0) {
			inv = "pinv17";
			swapObj2(objtotake,pinv17,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv18() == 0) {
			inv = "pinv18";
			swapObj2(objtotake,pinv18,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv19() == 0) {
			inv = "pinv19";
			swapObj2(objtotake,pinv19,playerinventory,inv);
		}
		// pinv20-29
		if (playerinventory.getPmobInv20() == 0) {
			inv = "pinv20";
			swapObj2(objtotake,pinv20,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv21() == 0) {
			inv = "pinv21";
			swapObj2(objtotake,pinv21,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv22() == 0) {
			inv = "pinv22";
			swapObj2(objtotake,pinv22,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv23() == 0) {
			inv = "pinv23";
			swapObj2(objtotake,pinv23,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv24() == 0) {
			inv = "pinv24";
			swapObj2(objtotake,pinv24,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv25() == 0) {
			inv = "pinv25";
			swapObj2(objtotake,pinv25,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv26() == 0) {
			inv = "pinv26";
			swapObj2(objtotake,pinv26,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv27() == 0) {
			inv = "pinv27";
			swapObj2(objtotake,pinv27,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv28() == 0) {
			inv = "pinv28";
			swapObj2(objtotake,pinv28,playerinventory,inv);
		}
		else if (playerinventory.getPmobInv29() == 0) {
			inv = "pinv29";
			swapObj2(objtotake,pinv29,playerinventory,inv);
		}
		else {
			System.out.println("No room in your inventory for the " + objtotake.getObjShortDesc() + ".");
		}
	}  // end takeObj2


	private static void remObj2() {
		//trying diff approach
		System.out.println("Which object/slot would you like to remove?");
		kinput = input.nextLine();
		switch (kinput) {
		case "helm": {
			inv = "helm";
			int iinput = phelm.getObjNum();

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(phelm,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(phelm,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(phelm,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(phelm,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(phelm,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(phelm,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(phelm,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(phelm,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(phelm,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(phelm,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(phelm,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(phelm,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(phelm,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(phelm,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(phelm,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(phelm,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(phelm,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(phelm,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(phelm,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(phelm,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(phelm,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(phelm,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(phelm,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(phelm,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(phelm,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(phelm,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(phelm,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(phelm,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(phelm,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(phelm,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }
			break;
		}

		case "neck": {
			inv = "neck";
			int iinput = pneck.getObjNum();
			//			System.out.println(pneck.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pneck,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pneck,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pneck,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pneck,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pneck,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pneck,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pneck,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pneck,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pneck,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pneck,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pneck,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pneck,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pneck,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pneck,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pneck,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pneck,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pneck,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pneck,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pneck,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pneck,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pneck,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pneck,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pneck,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pneck,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pneck,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pneck,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pneck,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pneck,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pneck,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pneck,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "shoulders": {
			inv = "shoulders";
			int iinput = pshoulders.getObjNum();
			//			System.out.println(pshoulders.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pshoulders,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pshoulders,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pshoulders,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pshoulders,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pshoulders,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pshoulders,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pshoulders,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pshoulders,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pshoulders,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pshoulders,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pshoulders,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pshoulders,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pshoulders,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pshoulders,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pshoulders,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pshoulders,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pshoulders,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pshoulders,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pshoulders,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pshoulders,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pshoulders,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pshoulders,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pshoulders,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pshoulders,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pshoulders,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pshoulders,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pshoulders,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pshoulders,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pshoulders,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pshoulders,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "chest": {
			inv = "chest";
			int iinput = pchest.getObjNum();
			//			System.out.println(pchest.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pchest,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pchest,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pchest,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pchest,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pchest,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pchest,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pchest,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pchest,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pchest,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pchest,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pchest,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pchest,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pchest,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pchest,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pchest,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pchest,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pchest,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pchest,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pchest,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pchest,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pchest,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pchest,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pchest,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pchest,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pchest,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pchest,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pchest,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pchest,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pchest,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pchest,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "wrist": {
			inv = "wrist";
			int iinput = pwrist.getObjNum();
			//			System.out.println(pwrist.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pwrist,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pwrist,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pwrist,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pwrist,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pwrist,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pwrist,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pwrist,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pwrist,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pwrist,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pwrist,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pwrist,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pwrist,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pwrist,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pwrist,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pwrist,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pwrist,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pwrist,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pwrist,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pwrist,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pwrist,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pwrist,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pwrist,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pwrist,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pwrist,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pwrist,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pwrist,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pwrist,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pwrist,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pwrist,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pwrist,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "hands": {
			inv = "hands";
			int iinput = phands.getObjNum();
			//			System.out.println(phands.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(phands,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(phands,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(phands,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(phands,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(phands,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(phands,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(phands,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(phands,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(phands,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(phands,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(phands,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(phands,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(phands,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(phands,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(phands,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(phands,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(phands,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(phands,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(phands,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(phands,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(phands,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(phands,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(phands,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(phands,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(phands,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(phands,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(phands,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(phands,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(phands,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(phands,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "finger1": {
			inv = "finger1";
			int iinput = pfinger1.getObjNum();
			//			System.out.println(pfinger1.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pfinger1,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pfinger1,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pfinger1,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pfinger1,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pfinger1,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pfinger1,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pfinger1,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pfinger1,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pfinger1,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pfinger1,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pfinger1,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pfinger1,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pfinger1,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pfinger1,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pfinger1,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pfinger1,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pfinger1,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pfinger1,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pfinger1,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pfinger1,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pfinger1,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pfinger1,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pfinger1,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pfinger1,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pfinger1,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pfinger1,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pfinger1,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pfinger1,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pfinger1,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pfinger1,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "finger2": {
			inv = "finger2";
			int iinput = pfinger2.getObjNum();
			//			System.out.println(pfinger2.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pfinger2,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pfinger2,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pfinger2,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pfinger2,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pfinger2,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pfinger2,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pfinger2,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pfinger2,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pfinger2,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pfinger2,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pfinger2,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pfinger2,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pfinger2,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pfinger2,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pfinger2,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pfinger2,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pfinger2,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pfinger2,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pfinger2,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pfinger2,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pfinger2,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pfinger2,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pfinger2,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pfinger2,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pfinger2,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pfinger2,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pfinger2,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pfinger2,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pfinger2,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pfinger2,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}

		case "waist": {
			inv = "waist";
			int iinput = pwaist.getObjNum();
			//			System.out.println(pwaist.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pwaist,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pwaist,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pwaist,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pwaist,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pwaist,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pwaist,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pwaist,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pwaist,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pwaist,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pwaist,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pwaist,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pwaist,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pwaist,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pwaist,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pwaist,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pwaist,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pwaist,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pwaist,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pwaist,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pwaist,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pwaist,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pwaist,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pwaist,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pwaist,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pwaist,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pwaist,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pwaist,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pwaist,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pwaist,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pwaist,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "leg": {
			inv = "leg";
			int iinput = pleg.getObjNum();
			//			System.out.println(pleg.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pleg,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pleg,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pleg,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pleg,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pleg,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pleg,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pleg,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pleg,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pleg,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pleg,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pleg,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pleg,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pleg,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pleg,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pleg,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pleg,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pleg,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pleg,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pleg,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pleg,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pleg,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pleg,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pleg,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pleg,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pleg,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pleg,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pleg,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pleg,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pleg,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pleg,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "foot": {
			inv = "foot";
			int iinput = pfoot.getObjNum();
			//			System.out.println(pfoot.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pfoot,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pfoot,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pfoot,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pfoot,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pfoot,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pfoot,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pfoot,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pfoot,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pfoot,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pfoot,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pfoot,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pfoot,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pfoot,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pfoot,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pfoot,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pfoot,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pfoot,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pfoot,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pfoot,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pfoot,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pfoot,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pfoot,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pfoot,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pfoot,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pfoot,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pfoot,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pfoot,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pfoot,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pfoot,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pfoot,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "trinket1": {
			inv = "trinket1";
			int iinput = ptrinket1.getObjNum();
			//			System.out.println(ptrinket1.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(ptrinket1,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(ptrinket1,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(ptrinket1,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(ptrinket1,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(ptrinket1,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(ptrinket1,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(ptrinket1,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(ptrinket1,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(ptrinket1,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(ptrinket1,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(ptrinket1,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(ptrinket1,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(ptrinket1,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(ptrinket1,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(ptrinket1,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(ptrinket1,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(ptrinket1,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(ptrinket1,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(ptrinket1,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(ptrinket1,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(ptrinket1,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(ptrinket1,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(ptrinket1,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(ptrinket1,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(ptrinket1,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(ptrinket1,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(ptrinket1,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(ptrinket1,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(ptrinket1,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(ptrinket1,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "trinket2": {
			inv = "trinket2";
			int iinput = ptrinket2.getObjNum();
			//			System.out.println(ptrinket2.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(ptrinket2,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(ptrinket2,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(ptrinket2,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(ptrinket2,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(ptrinket2,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(ptrinket2,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(ptrinket2,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(ptrinket2,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(ptrinket2,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(ptrinket2,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(ptrinket2,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(ptrinket2,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(ptrinket2,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(ptrinket2,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(ptrinket2,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(ptrinket2,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(ptrinket2,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(ptrinket2,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(ptrinket2,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(ptrinket2,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(ptrinket2,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(ptrinket2,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(ptrinket2,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(ptrinket2,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(ptrinket2,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(ptrinket2,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(ptrinket2,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(ptrinket2,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(ptrinket2,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(ptrinket2,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}
		case "weapon": {
			inv = "weapon1";
			int iinput = pweapon1.getObjNum();
			//			System.out.println(pweapon1.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pweapon1,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pweapon1,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pweapon1,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pweapon1,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pweapon1,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pweapon1,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pweapon1,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pweapon1,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pweapon1,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pweapon1,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pweapon1,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pweapon1,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pweapon1,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pweapon1,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pweapon1,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pweapon1,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pweapon1,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pweapon1,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pweapon1,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pweapon1,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pweapon1,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pweapon1,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pweapon1,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pweapon1,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pweapon1,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pweapon1,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pweapon1,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pweapon1,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pweapon1,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pweapon1,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}

		case "offhand": {
			inv = "weapshi";
			int iinput = pweapshi.getObjNum();
			//			System.out.println(pweapshi.getObjNum());

			if (playerinventory.getPmobInv0() == 0) {
				swapObj(pweapshi,pinv0,playerinventory,inv);
				playerinventory.setPmobInv0(iinput);
			}
			else if (playerinventory.getPmobInv1() == 0) {
				swapObj(pweapshi,pinv1,playerinventory,inv);
				playerinventory.setPmobInv1(iinput);
			}
			else if (playerinventory.getPmobInv2() == 0) {
				swapObj(pweapshi,pinv2,playerinventory,inv);
				playerinventory.setPmobInv2(iinput);
			}
			else if (playerinventory.getPmobInv3() == 0) {
				swapObj(pweapshi,pinv3,playerinventory,inv);
				playerinventory.setPmobInv3(iinput);
			}
			else if (playerinventory.getPmobInv4() == 0) {
				swapObj(pweapshi,pinv4,playerinventory,inv);
				playerinventory.setPmobInv4(iinput);
			}
			else if (playerinventory.getPmobInv5() == 0) {
				swapObj(pweapshi,pinv5,playerinventory,inv);
				playerinventory.setPmobInv5(iinput);
			}
			else if (playerinventory.getPmobInv6() == 0) {
				swapObj(pweapshi,pinv6,playerinventory,inv);
				playerinventory.setPmobInv6(iinput);
			}
			else if (playerinventory.getPmobInv7() == 0) {
				swapObj(pweapshi,pinv7,playerinventory,inv);
				playerinventory.setPmobInv7(iinput);
			}
			else if (playerinventory.getPmobInv8() == 0) {
				swapObj(pweapshi,pinv8,playerinventory,inv);
				playerinventory.setPmobInv8(iinput);
			}
			else if (playerinventory.getPmobInv9() == 0) {
				swapObj(pweapshi,pinv9,playerinventory,inv);
				playerinventory.setPmobInv9(iinput);
			}

			else if (playerinventory.getPmobInv10() == 0) {
				swapObj(pweapshi,pinv10,playerinventory,inv);
				playerinventory.setPmobInv10(iinput);
			}
			else if (playerinventory.getPmobInv11() == 0) {
				swapObj(pweapshi,pinv11,playerinventory,inv);
				playerinventory.setPmobInv11(iinput);
			}
			else if (playerinventory.getPmobInv12() == 0) {
				swapObj(pweapshi,pinv12,playerinventory,inv);
				playerinventory.setPmobInv12(iinput);
			}
			else if (playerinventory.getPmobInv13() == 0) {
				swapObj(pweapshi,pinv13,playerinventory,inv);
				playerinventory.setPmobInv13(iinput);
			}
			else if (playerinventory.getPmobInv14() == 0) {
				swapObj(pweapshi,pinv14,playerinventory,inv);
				playerinventory.setPmobInv14(iinput);
			}
			else if (playerinventory.getPmobInv15() == 0) {
				swapObj(pweapshi,pinv15,playerinventory,inv);
				playerinventory.setPmobInv15(iinput);
			}
			else if (playerinventory.getPmobInv16() == 0) {
				swapObj(pweapshi,pinv16,playerinventory,inv);
				playerinventory.setPmobInv16(iinput);
			}
			else if (playerinventory.getPmobInv17() == 0) {
				swapObj(pweapshi,pinv17,playerinventory,inv);
				playerinventory.setPmobInv17(iinput);
			}
			else if (playerinventory.getPmobInv18() == 0) {
				swapObj(pweapshi,pinv18,playerinventory,inv);
				playerinventory.setPmobInv18(iinput);
			}
			else if (playerinventory.getPmobInv19() == 0) {
				swapObj(pweapshi,pinv19,playerinventory,inv);
				playerinventory.setPmobInv19(iinput);
			}

			else if (playerinventory.getPmobInv20() == 0) {
				swapObj(pweapshi,pinv20,playerinventory,inv);
				playerinventory.setPmobInv20(iinput);
			}
			else if (playerinventory.getPmobInv21() == 0) {
				swapObj(pweapshi,pinv21,playerinventory,inv);
				playerinventory.setPmobInv21(iinput);
			}
			else if (playerinventory.getPmobInv22() == 0) {
				swapObj(pweapshi,pinv22,playerinventory,inv);
				playerinventory.setPmobInv22(iinput);
			}
			else if (playerinventory.getPmobInv23() == 0) {
				swapObj(pweapshi,pinv23,playerinventory,inv);
				playerinventory.setPmobInv23(iinput);
			}
			else if (playerinventory.getPmobInv24() == 0) {
				swapObj(pweapshi,pinv24,playerinventory,inv);
				playerinventory.setPmobInv24(iinput);
			}
			else if (playerinventory.getPmobInv25() == 0) {
				swapObj(pweapshi,pinv25,playerinventory,inv);
				playerinventory.setPmobInv25(iinput);
			}
			else if (playerinventory.getPmobInv26() == 0) {
				swapObj(pweapshi,pinv26,playerinventory,inv);
				playerinventory.setPmobInv26(iinput);
			}
			else if (playerinventory.getPmobInv27() == 0) {
				swapObj(pweapshi,pinv27,playerinventory,inv);
				playerinventory.setPmobInv27(iinput);
			}
			else if (playerinventory.getPmobInv28() == 0) {
				swapObj(pweapshi,pinv28,playerinventory,inv);
				playerinventory.setPmobInv28(iinput);
			}
			else if (playerinventory.getPmobInv29() == 0) {
				swapObj(pweapshi,pinv29,playerinventory,inv);
				playerinventory.setPmobInv29(iinput);
			}

			else { System.out.println("You do not have any free inventory slots."); }

			break;
		}

		default: {
			System.out.println("You do not have one of those equipped.");
		}
		}

	} // end remObj2


	private static void equipObj() throws Exception {
		// attempts to equip obj from player inventory
		System.out.println("Which object would you like to equip?");
		kinput = input.nextLine();
		int iinput = Integer.parseInt(kinput);
		// load a temp obj
		if (iinput < nextAvailObj) {
			loadObject(tempObj, iinput);
		}

		// check if input is in inventory
		if (playerinventory.getPmobInv0() == iinput) {
			loadObject(pinv0,tempObj.getObjNum());
			inv = "pinv0";
			equipObj2(tempObj,iinput,inv);
		}
		else if (playerinventory.getPmobInv1() == iinput) {
			inv = "pinv1";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv1,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv2() == iinput) {
			inv = "pinv2";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv2,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv3() == iinput) {
			inv = "pinv3";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv3,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv4() == iinput) {
			inv = "pinv4";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv4,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv5() == iinput) {
			inv = "pinv5";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv5,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv6() == iinput) {
			inv = "pinv6";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv6,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv7() == iinput) {
			inv = "pinv7";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv7,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv8() == iinput) {
			inv = "pinv8";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv8,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv9() == iinput) {
			inv = "pinv9";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv9,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv10() == iinput) {
			inv = "pinv10";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv10,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv11() == iinput) {
			inv = "pinv11";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv11,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv12() == iinput) {
			inv = "pinv12";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv12,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv13() == iinput) {
			inv = "pinv13";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv13,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv14() == iinput) {
			inv = "pinv14";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv14,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv15() == iinput) {
			inv = "pinv15";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv15,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv16() == iinput) {
			inv = "pinv16";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv16,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv17() == iinput) {
			inv = "pinv17";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv17,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv18() == iinput) {
			inv = "pinv18";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv18,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv19() == iinput) {
			inv = "pinv19";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv19,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv20() == iinput) {
			inv = "pinv20";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv20,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv21() == iinput) {
			inv = "pinv21";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv21,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv22() == iinput) {
			inv = "pinv22";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv22,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv23() == iinput) {
			inv = "pinv23";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv23,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv24() == iinput) {
			inv = "pinv24";
			equipObj2(tempObj,iinput, inv);
			loadObject(pinv24,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv25() == iinput) {
			inv = "pinv25";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv25,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv26() == iinput) {
			inv = "pinv26";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv26,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv27() == iinput) {
			inv = "pinv27";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv27,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv28() == iinput) {
			inv = "pinv28";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv28,tempObj.getObjNum());
		}
		else if (playerinventory.getPmobInv29() == iinput) {
			inv = "pinv29";
			equipObj2(tempObj,iinput,inv);
			loadObject(pinv29,tempObj.getObjNum());
		}

		// item not in inventory
		else {
			System.out.println("You do not have that item.");
		}
	} // end equipObj()


	private static void equipObj2(objects o, int iinput, String inv) {
		//
		String tet = inv;
		String eSlot = o.getEquipSlot();

		switch (eSlot) {
		case "head": {
			swapObj(o,phelm,playerinventory,tet);
			break;
		}
		case "neck": {
			swapObj(o,pneck,playerinventory,tet);
			break;
		}
		case "shoulders": {
			swapObj(o,pshoulders,playerinventory,tet);
			break;
		}
		case "chest": {
			swapObj(o,pchest,playerinventory,tet);
			break;
		}
		case "wrist": {
			swapObj(o,pwrist,playerinventory,tet);
			break;
		}
		case "hands": {
			swapObj(o,phands,playerinventory,tet);
			break;
		}
		case "finger1": {
			swapObj(o,pfinger1,playerinventory,tet);
			break;
		}
		case "finger2": {
			swapObj(o,pfinger2,playerinventory,tet);
			break;
		}
		case "waist": {
			swapObj(o,pwaist,playerinventory,tet);
			break;
		}
		case "leg": {
			swapObj(o,pleg,playerinventory,tet);
			break;
		}
		case "foot": {
			swapObj(o,pfoot,playerinventory,tet);
			break;
		}
		case "trinket1": {
			swapObj(o,ptrinket1,playerinventory,tet);
			break;
		}
		case "trinket2": {
			swapObj(o,ptrinket2,playerinventory,tet);
			break;
		}
		case "weapon": {
			swapObj(o,pweapon1,playerinventory,tet);
			break;
		}
		case "weaponshield": {
			swapObj(o,pweapshi,playerinventory,tet);
			break;
		}
		case "none": {
			System.out.println("You cannot equip that item.");
			break;
		}
		default: {
			System.out.println("Invalid equip slot.");
		}
		} // end switch (eSlot)

	} // end equipObj2



	private static void swapObj3(objects a, objects b, inventory pinv, String inv2) {
		// attempts to swap obj from inventory to ground

		// testing the drop location
		//	if (a.getObjNum() != 0) {
		//		System.out.println("You drop the " + a.getObjShortDesc() + " to the " + inv2 + ".");
		//	}

		invSlot = inv2;

		switch (invSlot) {
		case "tobj0": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the first spot.");
			loadObject(tobj0,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 0);
			break;
		}
		case "tobj1": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the second spot.");
			loadObject(tobj1,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 1);
			break;
		}
		case "tobj2": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the middle spot.");
			loadObject(tobj2,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 2);
			break;
		}
		case "tobj3": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the fourth spot.");
			loadObject(tobj3,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 3);
			break;
		}
		case "tobj4": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the fifth spot.");
			loadObject(tobj4,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 4);
			break;
		}
		case "tobj5": {
			System.out.println("You drop the " + a.getObjShortDesc() + " to the final spot.");
			loadObject(tobj1,a.getObjNum());
			newRoom.setObjNumAtPos(a.getObjNum(), 5);
			break;
		}
		default: { }
		}


		switch(inv) {
		case "pinv0": {
			loadObject(pinv0, 0);
			pinv0.setObjNum(0);
			playerinventory.setPmobInv0(0);
			break;
		}
		case "pinv1": {
			loadObject(pinv1, 0);
			pinv1.setObjNum(0);
			playerinventory.setPmobInv1(0);
			break;
		}
		case "pinv2": {
			loadObject(pinv2, 0);
			pinv2.setObjNum(0);
			playerinventory.setPmobInv2(0);
			break;
		}
		case "pinv3": {
			loadObject(pinv3, 0);
			pinv3.setObjNum(0);
			playerinventory.setPmobInv3(0);
			break;
		}
		case "pinv4": {
			loadObject(pinv4, 0);
			pinv4.setObjNum(0);
			playerinventory.setPmobInv4(0);
			break;
		}
		case "pinv5": {
			loadObject(pinv5, 0);
			pinv5.setObjNum(0);
			playerinventory.setPmobInv5(0);
			break;
		}
		case "pinv6": {
			loadObject(pinv6, 0);
			pinv6.setObjNum(0);
			playerinventory.setPmobInv6(0);
			break;
		}
		case "pinv7": {
			loadObject(pinv7, 0);
			pinv7.setObjNum(0);
			playerinventory.setPmobInv7(0);
			break;
		}
		case "pinv8": {
			loadObject(pinv8, 0);
			pinv8.setObjNum(0);
			playerinventory.setPmobInv8(0);
			break;
		}
		case "pinv9": {
			loadObject(pinv9, 0);
			pinv9.setObjNum(0);
			playerinventory.setPmobInv9(0);
			break;
		}

		case "pinv10": {
			loadObject(pinv10, 0);
			pinv10.setObjNum(0);
			playerinventory.setPmobInv10(0);
			break;
		}
		case "pinv11": {
			loadObject(pinv11, 0);
			pinv11.setObjNum(0);
			playerinventory.setPmobInv11(0);
			break;
		}
		case "pinv12": {
			loadObject(pinv12, 0);
			pinv12.setObjNum(0);
			playerinventory.setPmobInv12(0);
			break;
		}
		case "pinv13": {
			loadObject(pinv13, 0);
			pinv13.setObjNum(0);
			playerinventory.setPmobInv13(0);
			break;
		}
		case "pinv14": {
			loadObject(pinv14, 0);
			pinv14.setObjNum(0);
			playerinventory.setPmobInv14(0);
			break;
		}
		case "pinv15": {
			loadObject(pinv15, 0);
			pinv15.setObjNum(0);
			playerinventory.setPmobInv15(0);
			break;
		}
		case "pinv16": {
			loadObject(pinv16, 0);
			pinv16.setObjNum(0);
			playerinventory.setPmobInv16(0);
			break;
		}
		case "pinv17": {
			loadObject(pinv17, 0);
			pinv17.setObjNum(0);
			playerinventory.setPmobInv17(0);
			break;
		}
		case "pinv18": {
			loadObject(pinv18, 0);
			pinv18.setObjNum(0);
			playerinventory.setPmobInv18(0);
			break;
		}
		case "pinv19": {
			loadObject(pinv19, 0);
			pinv19.setObjNum(0);
			playerinventory.setPmobInv19(0);
			break;
		}

		case "pinv20": {
			loadObject(pinv20, 0);
			pinv20.setObjNum(0);
			playerinventory.setPmobInv20(0);
			break;
		}
		case "pinv21": {
			loadObject(pinv21, 0);
			pinv21.setObjNum(0);
			playerinventory.setPmobInv21(0);
			break;
		}
		case "pinv22": {
			loadObject(pinv22, 0);
			pinv22.setObjNum(0);
			playerinventory.setPmobInv22(0);
			break;
		}
		case "pinv23": {
			loadObject(pinv23, 0);
			pinv23.setObjNum(0);
			playerinventory.setPmobInv23(0);
			break;
		}
		case "pinv24": {
			loadObject(pinv24, 0);
			pinv24.setObjNum(0);
			playerinventory.setPmobInv24(0);
			break;
		}
		case "pinv25": {
			loadObject(pinv25, 0);
			pinv25.setObjNum(0);
			playerinventory.setPmobInv25(0);
			break;
		}
		case "pinv26": {
			loadObject(pinv26, 0);
			pinv26.setObjNum(0);
			playerinventory.setPmobInv26(0);
			break;
		}
		case "pinv27": {
			loadObject(pinv27, 0);
			pinv27.setObjNum(0);
			playerinventory.setPmobInv27(0);
			break;
		}
		case "pinv28": {
			loadObject(pinv28, 0);
			pinv28.setObjNum(0);
			playerinventory.setPmobInv28(0);
			break;
		}
		case "pinv29": {
			loadObject(pinv29, 0);
			pinv29.setObjNum(0);
			playerinventory.setPmobInv29(0);
			break;
		}

		default: { }
		}
	} // end swapObj3


	private static void swapObj2(objects a, objects b, inventory pinv, String inv) {
		// attempts to swap obj from ground to inventory

		// swap the objects
		//		int a, b, temp;
		//		a = 15;	 // item supposedly in inventory
		//		b = 27;
		//		temp = invObj;
		//		System.out.println("Before swapping : a, b = "+a+", "+ + b);
		//		temp = a; //
		//		a = b;	  //
		//		b = temp; //
		//		System.out.println("After swapping : a, b = "+a+", "+ + b);
		//		Before swapping : a, b = 15, 27
		//		After swapping : a, b = 27, 15


		if (a.getObjNum() != 0) {
			System.out.println("You take the " + a.getObjShortDesc() + " (pre swapped).");
		}
		loadObject(swapObj,a.getObjNum());
		swapObj.setObjNum(a.getObjNum());
		loadObject(a,b.getObjNum());
		a.setObjNum(b.getObjNum());
		loadObject(b,swapObj.getObjNum());
		b.setObjNum(swapObj.getObjNum());
		System.out.println("You got the " + b.getObjShortDesc() + " (swapped from ground).");
		invSlot = inv;

		switch (invSlot) {
		// pinv0-9
		case "pinv0":{
			loadObject(pinv0,b.getObjNum());
			pinv.setPmobInv0(b.getObjNum());
			pinv0.setObjNum(b.getObjNum());
			playerinventory.setPmobInv0(b.getObjNum());
			System.out.println("inv slot 0 loaded");
			break;
		}
		case "pinv1":{
			loadObject(pinv1,b.getObjNum());
			pinv.setPmobInv1(b.getObjNum());
			pinv1.setObjNum(b.getObjNum());
			playerinventory.setPmobInv1(b.getObjNum());
			System.out.println("inv slot 1 loaded");
			break;
		}
		case "pinv2": {
			loadObject(pinv2,b.getObjNum());
			pinv.setPmobInv2(b.getObjNum());
			pinv2.setObjNum(b.getObjNum());
			playerinventory.setPmobInv2(b.getObjNum());
			System.out.println("inv slot 2 loaded");
			break;
		}
		case "pinv3":{
			loadObject(pinv3,b.getObjNum());
			pinv.setPmobInv3(b.getObjNum());
			pinv3.setObjNum(b.getObjNum());
			playerinventory.setPmobInv3(b.getObjNum());
			System.out.println("inv slot 3 loaded with " + playerinventory.getPmobInv3());
			break;
		}
		case "pinv4":{
			loadObject(pinv4,b.getObjNum());
			pinv.setPmobInv4(b.getObjNum());
			pinv4.setObjNum(b.getObjNum());
			playerinventory.setPmobInv4(b.getObjNum());
			System.out.println("inv slot 4 loaded");
			break;
		}
		case "pinv5":{
			loadObject(pinv5,b.getObjNum());
			pinv.setPmobInv5(b.getObjNum());
			pinv5.setObjNum(b.getObjNum());
			playerinventory.setPmobInv5(b.getObjNum());
			System.out.println("inv slot 5 loaded");
			break;
		}
		case "pinv6":{
			loadObject(pinv6,b.getObjNum());
			pinv.setPmobInv6(b.getObjNum());
			pinv6.setObjNum(b.getObjNum());
			playerinventory.setPmobInv6(b.getObjNum());
			System.out.println("inv slot 6 loaded");
			break;
		}
		case "pinv7":{
			loadObject(pinv7,a.getObjNum());
			pinv.setPmobInv7(b.getObjNum());
			pinv7.setObjNum(b.getObjNum());
			playerinventory.setPmobInv7(b.getObjNum());
			System.out.println("inv slot 7 loaded");
			break;
		}
		case "pinv8":{
			loadObject(pinv8,b.getObjNum());
			pinv.setPmobInv8(b.getObjNum());
			pinv8.setObjNum(b.getObjNum());
			playerinventory.setPmobInv8(b.getObjNum());
			System.out.println("inv slot 8 loaded");
			break;
		}
		case "pinv9":{
			loadObject(pinv9,b.getObjNum());
			pinv.setPmobInv9(b.getObjNum());
			pinv9.setObjNum(b.getObjNum());
			playerinventory.setPmobInv9(b.getObjNum());
			System.out.println("inv slot 9 loaded");
			break;
		}
		// pinv10-19
		case "pinv10":{
			loadObject(pinv10,a.getObjNum());
			pinv.setPmobInv10(b.getObjNum());
			pinv10.setObjNum(b.getObjNum());
			playerinventory.setPmobInv10(b.getObjNum());
			break;
		}
		case "pinv11":{
			loadObject(pinv11,b.getObjNum());
			pinv.setPmobInv11(b.getObjNum());
			pinv11.setObjNum(b.getObjNum());
			playerinventory.setPmobInv11(b.getObjNum());
			break;
		}
		case "pinv12": {
			loadObject(pinv2,b.getObjNum());
			pinv.setPmobInv12(b.getObjNum());
			pinv12.setObjNum(b.getObjNum());
			playerinventory.setPmobInv12(b.getObjNum());
			break;
		}
		case "pinv13":{
			loadObject(pinv13,b.getObjNum());
			pinv.setPmobInv13(b.getObjNum());
			pinv13.setObjNum(b.getObjNum());
			playerinventory.setPmobInv13(b.getObjNum());
			break;
		}
		case "pinv14":{
			loadObject(pinv14,a.getObjNum());
			pinv.setPmobInv14(b.getObjNum());
			pinv14.setObjNum(b.getObjNum());
			playerinventory.setPmobInv14(b.getObjNum());
			break;
		}
		case "pinv15":{
			loadObject(pinv15,b.getObjNum());
			pinv.setPmobInv15(b.getObjNum());
			pinv15.setObjNum(b.getObjNum());
			playerinventory.setPmobInv15(b.getObjNum());
			break;
		}
		case "pinv16":{
			loadObject(pinv16,b.getObjNum());
			pinv.setPmobInv16(b.getObjNum());
			pinv16.setObjNum(b.getObjNum());
			playerinventory.setPmobInv16(b.getObjNum());
			break;
		}
		case "pinv17":{
			loadObject(pinv17,b.getObjNum());
			pinv.setPmobInv17(b.getObjNum());
			pinv17.setObjNum(b.getObjNum());
			playerinventory.setPmobInv17(b.getObjNum());
			break;
		}
		case "pinv18":{
			loadObject(pinv18,b.getObjNum());
			pinv.setPmobInv18(b.getObjNum());
			pinv18.setObjNum(b.getObjNum());
			playerinventory.setPmobInv18(b.getObjNum());
			break;
		}
		case "pinv19":{
			loadObject(pinv19,b.getObjNum());
			pinv.setPmobInv19(b.getObjNum());
			pinv19.setObjNum(b.getObjNum());
			playerinventory.setPmobInv19(b.getObjNum());
			break;
		}
		// pinv20-29
		case "pinv20":{
			loadObject(pinv20,b.getObjNum());
			pinv.setPmobInv20(b.getObjNum());
			pinv20.setObjNum(b.getObjNum());
			playerinventory.setPmobInv20(b.getObjNum());
			break;
		}
		case "pinv21":{
			loadObject(pinv21,b.getObjNum());
			pinv.setPmobInv21(b.getObjNum());
			pinv21.setObjNum(b.getObjNum());
			playerinventory.setPmobInv21(b.getObjNum());
			break;
		}
		case "pinv22": {
			loadObject(pinv22,b.getObjNum());
			pinv.setPmobInv22(b.getObjNum());
			pinv22.setObjNum(b.getObjNum());
			playerinventory.setPmobInv22(b.getObjNum());
			break;
		}
		case "pinv23":{
			loadObject(pinv23,b.getObjNum());
			pinv.setPmobInv23(b.getObjNum());
			pinv23.setObjNum(b.getObjNum());
			playerinventory.setPmobInv23(b.getObjNum());
			break;
		}
		case "pinv24":{
			loadObject(pinv24,b.getObjNum());
			pinv.setPmobInv24(b.getObjNum());
			pinv24.setObjNum(b.getObjNum());
			playerinventory.setPmobInv24(b.getObjNum());
			break;
		}
		case "pinv25":{
			loadObject(pinv25,b.getObjNum());
			pinv.setPmobInv25(b.getObjNum());
			pinv25.setObjNum(b.getObjNum());
			playerinventory.setPmobInv25(b.getObjNum());
			break;
		}
		case "pinv26":{
			loadObject(pinv26,b.getObjNum());
			pinv.setPmobInv26(b.getObjNum());
			pinv26.setObjNum(b.getObjNum());
			playerinventory.setPmobInv26(b.getObjNum());
			break;
		}
		case "pinv27":{
			loadObject(pinv27,b.getObjNum());
			pinv.setPmobInv27(b.getObjNum());
			pinv27.setObjNum(b.getObjNum());
			playerinventory.setPmobInv27(b.getObjNum());
			break;
		}
		case "pinv28":{
			loadObject(pinv28,b.getObjNum());
			pinv.setPmobInv28(b.getObjNum());
			pinv28.setObjNum(b.getObjNum());
			playerinventory.setPmobInv28(b.getObjNum());
			break;
		}
		case "pinv29":{
			loadObject(pinv29,b.getObjNum());
			pinv.setPmobInv29(b.getObjNum());
			pinv29.setObjNum(b.getObjNum());
			playerinventory.setPmobInv29(b.getObjNum());
			break;
		}
		default: { }
		}

	} // end swapObj2


	private static void swapObj(objects a, objects b, inventory i, String inv) {
		// swap the objects
		//		int a, b, temp;
		//		a = 15;	 // item supposedly in inventory
		//		b = 27;
		//		temp = invObj;
		//		System.out.println("Before swapping : a, b = "+a+", "+ + b);
		//		temp = a; //
		//		a = b;	  //
		//		b = temp; //
		//		System.out.println("After swapping : a, b = "+a+", "+ + b);
		//		Before swapping : a, b = 15, 27
		//		After swapping : a, b = 27, 15

		if (a.getObjNum() != 0) {
			System.out.println("You stop using the " + b.getObjShortDesc() + ".");
		}
		loadObject(swapObj,a.getObjNum());
		swapObj.setObjNum(a.getObjNum());
		loadObject(a,b.getObjNum());
		a.setObjNum(b.getObjNum());
		loadObject(b,swapObj.getObjNum());
		b.setObjNum(swapObj.getObjNum());

		if (a.getObjNum() != 0) {
			if (!"weapon".equalsIgnoreCase(a.getEquipSlot()) ) {
				System.out.println("You wear the " + b.getObjShortDesc() + ".");
			}
			else {
				System.out.println("You wield the " + b.getObjShortDesc() + ".");
			}
		}

		invSlot = inv;

		System.out.println(invSlot);

		switch (invSlot) {
		case "pinv0":{
			loadObject(pinv0,a.getObjNum());
			break;
		}
		case "pinv1":{
			loadObject(pinv1,a.getObjNum());
			break;
		}
		case "pinv2": {
			loadObject(pinv2,a.getObjNum());
			break;
		}
		case "pinv3":{
			loadObject(pinv3,a.getObjNum());
			break;
		}
		case "pinv4":{
			loadObject(pinv4,a.getObjNum());
			break;
		}
		case "pinv5":{
			loadObject(pinv5,a.getObjNum());
			break;
		}
		case "pinv6":{
			loadObject(pinv6,a.getObjNum());
			break;
		}
		case "pinv7":{
			loadObject(pinv7,a.getObjNum());
			break;
		}
		case "pinv8":{
			loadObject(pinv8,a.getObjNum());
			break;
		}
		case "pinv9":{
			loadObject(pinv9,a.getObjNum());
			break;
		}

		case "pinv10":{
			loadObject(pinv10,a.getObjNum());
			break;
		}
		case "pinv11":{
			loadObject(pinv11,a.getObjNum());
			break;
		}
		case "pinv12": {
			loadObject(pinv2,a.getObjNum());
			break;
		}
		case "pinv13":{
			loadObject(pinv13,a.getObjNum());
			break;
		}
		case "pinv14":{
			loadObject(pinv14,a.getObjNum());
			break;
		}
		case "pinv15":{
			loadObject(pinv15,a.getObjNum());
			break;
		}
		case "pinv16":{
			loadObject(pinv16,a.getObjNum());
			break;
		}
		case "pinv17":{
			loadObject(pinv17,a.getObjNum());
			break;
		}
		case "pinv18":{
			loadObject(pinv18,a.getObjNum());
			break;
		}
		case "pinv19":{
			loadObject(pinv19,a.getObjNum());
			break;
		}

		case "pinv20":{
			loadObject(pinv20,a.getObjNum());
			break;
		}
		case "pinv21":{
			loadObject(pinv21,a.getObjNum());
			break;
		}
		case "pinv22": {
			loadObject(pinv22,a.getObjNum());
			break;
		}
		case "pinv23":{
			loadObject(pinv23,a.getObjNum());
			break;
		}
		case "pinv24":{
			loadObject(pinv24,a.getObjNum());
			break;
		}
		case "pinv25":{
			loadObject(pinv25,a.getObjNum());
			break;
		}
		case "pinv26":{
			loadObject(pinv26,a.getObjNum());
			break;
		}
		case "pinv27":{
			loadObject(pinv27,a.getObjNum());
			break;
		}
		case "pinv28":{
			loadObject(pinv28,a.getObjNum());
			break;
		}
		case "pinv29":{
			loadObject(pinv29,a.getObjNum());
			break;
		}


		default: { } // do nothing, item not in inventory slots
		}
	} // end swapObj(obj1, obj2)


	private static void rent() throws IOException {
		// restores player to full health and mana
		System.out.println("The innkeeper glances at you with indifference and tosses out a room key.");

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		System.out.println("You feel completely restored.");

		checkPlayerMaxHP();
		checkPlayerMaxMP();
		player1.setPlayerMP(player1.getPlayerMaxMP());
		System.out.println("Your Mana completely refills.");

		player1.setPlayerHP(player1.getPlayerMaxHP() );
		System.out.println("Your Health completely refills.");


		System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP()  );
		System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLHPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
				"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
				playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());


		psave();

	} // end rent()


	private static void camp() throws IOException {
		// restores player to 90% health and mana
		System.out.println("You pitch a tent and lie down beside a small fire, lit to ward off the cold.");

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(10);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		System.out.println("You feel mostly restored.");

		checkPlayerMaxHP();
		checkPlayerMaxMP();
		int MPPerc = 0;
		MPPerc = (int) calculatePercentage(player1.getPlayerMP(), player1.getPlayerMaxMP());
		//		calculatePercentage(player1.getPlayerMP(), player1.getPlayerMaxMP());
		player1.setPlayerMP(MPPerc);
		System.out.println("Your Mana mostly refills.");

		int HPPerc = 0;
		HPPerc = (int) calculatePercentage(player1.getPlayerMP(), player1.getPlayerMaxMP());
		player1.setPlayerHP(HPPerc);
		System.out.println("Your Health mostly refills.");


		System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP()  );
		System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLHPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
				"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
				playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

		psave();


	} // end camp()


	private static void zsave () throws IOException {
		// save the zone stuffs
		writeZonetoZoneArray();
		writeZScriptstoFile();
	}

	private static void writeZonetoZoneArray() {
		// TODO Auto-generated method stub

	}




	private static void writeZScriptstoFile() {
		// TODO Auto-generated method stub

	}




	private static void wsave() throws IOException {
		// save the rooms/world
		writeRmToWorldArray();
		writeWorldFile();
	} // end wsave


	private static void writeRmToWorldArray() {
		// attempts to update the World[] array with the current rooms information
		// this works
		System.out.println("Writing the room to the World Array");

		int rmNum = newRoom.getRoomNum();

		World[rmNum][0] = String.valueOf(rmNum); //0
		World[rmNum][1] = newRoom.getRoomName(); //1
		World[rmNum][2] = newRoom.getRoomShortDesc(); //2
		World[rmNum][3] = newRoom.getRoomLongDesc(); //3
		World[rmNum][4] = String.valueOf(newRoom.getExitN()); //4
		World[rmNum][5] = String.valueOf(newRoom.getExitNE()); //5
		World[rmNum][6] = String.valueOf(newRoom.getExitE()); //6
		World[rmNum][7] = String.valueOf(newRoom.getExitSE()); //7
		World[rmNum][8] = String.valueOf(newRoom.getExitS()); //8
		World[rmNum][9] = String.valueOf(newRoom.getExitSW()); //9
		World[rmNum][10] = String.valueOf(newRoom.getExitW()); //10
		World[rmNum][11] = String.valueOf(newRoom.getExitNW()); //11
		World[rmNum][12] = String.valueOf(newRoom.getExitU()); //12
		World[rmNum][13] = String.valueOf(newRoom.getExitD()); //13
		String tmobInRoom = newRoom.getMobsInRoom();
		tmobInRoom = tmobInRoom.replace("[", "");
		tmobInRoom = tmobInRoom.replace("]", "");
		World[rmNum][14] = tmobInRoom; //14 mobsinroom
		String tobjInRoom =  newRoom.getObjsInRoom();
		tobjInRoom = tobjInRoom.replace("[", "");
		tobjInRoom = tobjInRoom.replace("]", "");
		World[rmNum][15] = tobjInRoom;//15 objinroom
		World[rmNum][16] = String.valueOf(newRoom.getLit()); //16
		World[rmNum][17] = String.valueOf(newRoom.getCamp()); //17
		World[rmNum][18] = String.valueOf(newRoom.getRent()); //18
		World[rmNum][19] = String.valueOf(newRoom.getInside()); //19
		World[rmNum][20] = String.valueOf(newRoom.getTerrain()); //20
		World[rmNum][21] = String.valueOf(newRoom.getBank()); //21

		World[rmNum][22] = newRoom.dNStatus;
		World[rmNum][23] = newRoom.dNEStatus;
		World[rmNum][24] = newRoom.dEStatus;
		World[rmNum][25] = newRoom.dSEStatus;
		World[rmNum][26] = newRoom.dSStatus;
		World[rmNum][27] = newRoom.dSWStatus;
		World[rmNum][28] = newRoom.dWStatus;
		World[rmNum][29] = newRoom.dNWStatus;
		World[rmNum][30] = newRoom.dUStatus;
		World[rmNum][31] = newRoom.dDStatus;

		World[rmNum][32] = newRoom.v32;
		World[rmNum][33] = newRoom.v33;
		World[rmNum][34] = newRoom.v34;
		World[rmNum][35] = newRoom.v35;
		World[rmNum][36] = newRoom.v36;
		World[rmNum][37] = newRoom.v37;
		World[rmNum][38] = newRoom.v38;
		World[rmNum][39] = newRoom.v39;

		World[rmNum][40] = newRoom.v40;
		World[rmNum][41] = newRoom.v41;
		World[rmNum][42] = newRoom.v42;
		World[rmNum][43] = newRoom.v43;
		World[rmNum][44] = newRoom.v44;
		World[rmNum][45] = newRoom.v45;
		World[rmNum][46] = newRoom.v46;
		World[rmNum][47] = newRoom.v47;
		World[rmNum][48] = newRoom.v48;
		World[rmNum][49] = newRoom.v49;

		System.out.println("Done writing the room to the Array.");
		System.out.println(World[rmNum][1]);
	}// writeRmToWorldArray()


	private static void writeWorldFile() {
		// write World arr to file
		// this works

		try {

			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(worldPath, false));
			String altoFile = "";

			for (int i=0; i < nextAvailRoom; i++) {
				altoFile = World[i][0] + "|" + World[i][1] + "|" + World[i][2] + "|" + World[i][3] + "|" + World[i][4] + "|" + World[i][5] + "|" + World[i][6] + "|" + World[i][7] + "|" + World[i][8] + "|" + World[i][9] + "|" + World[i][10] + "|" + World[i][11] + "|" + World[i][12] + "|" + World[i][13] + "|" + World[i][14] + "|" + World[i][15] + "|" + World[i][16] + "|" + World[i][17] + "|" + World[i][18] + "|" + World[i][19] + "|" + World[i][20] + "|" + World[i][21] + "|" + World[i][22] + "|" + World[i][23] + "|" + World[i][24] + "|" + World[i][25] + "|" + World[i][26] + "|" + World[i][27] + "|" + World[i][28] + "|" + World[i][29] + "|" + World[i][30] + "|" + World[i][31] + "|" + World[i][32] + "|" + World[i][33] + "|" + World[i][34] + "|" + World[i][35] + "|" + World[i][36] + "|" + World[i][37] + "|" + World[i][38] + "|" + World[i][39] + "|" + World[i][40] + "|" + World[i][41] + "|" + World[i][42] + "|" + World[i][43] + "|" + World[i][44] + "|" + World[i][45] + "|" + World[i][46] + "|" + World[i][47] + "|" + World[i][48] + "|" + World[i][49];

				outtoFile.write(altoFile);
				outtoFile.newLine();
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end writeWorldFile


	private static void psave() throws IOException {
		// save the player
		writeCharToCharArray(player1.getPlayerNum());  // write player current stats/gear to array
		writeadminLoginArray(player1.getPlayerNum());  // write player login and location to array
		writePInvArray(playerinventory.getPmobid());  // write the players inventory to its array

		writeCharstoFile();
		writeLoginToadminLoginFile();
		writePInvFile();

	} // end psave


	private static void writeCharstoFile() {
		// write Char arr to file
		//	System.out.println("Working on writeCharstoFile()");
		//	System.out.println("Writing the Chars the file with writeCharstoFile()");
		//	System.out.println("This works correctly.");

		try {

			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(charPath, false));
			String altoFile = "";

			for (int i=0; i < nextAvailChar; i++) {
				altoFile = Chars[i][0] + "|" + Chars[i][1] + "|" + Chars[i][2] + "|" + Chars[i][3]+ "|" + Chars[i][4]+ "|" + Chars[i][5]+ "|" +
						Chars[i][6]+ "|" + Chars[i][7]+ "|" + Chars[i][8]+ "|" + Chars[i][9]+ "|" + Chars[i][10]+ "|" + Chars[i][11]+ "|" +
						Chars[i][12]+ "|" + Chars[i][13]+ "|" + Chars[i][14]+ "|" + Chars[i][15]+ "|" + Chars[i][16]+ "|" + Chars[i][17]+
						"|" + Chars[i][18]+ "|" + Chars[i][19]+ "|" + Chars[i][20]+ "|" + Chars[i][21]+ "|" + Chars[i][22]+ "|" +
						Chars[i][23]+ "|" + Chars[i][24]+ "|" + Chars[i][25]+ "|" + Chars[i][26]+ "|" + Chars[i][27]+ "|" + Chars[i][28]+
						"|" + Chars[i][29]+ "|" + Chars[i][30]+ "|" + Chars[i][31]+ "|" + Chars[i][32]+ "|" + Chars[i][33]+ "|" +
						Chars[i][34]+ "|" + Chars[i][35]+ "|" + Chars[i][36]+ "|" + Chars[i][37]+ "|" + Chars[i][38]+ "|" + Chars[i][39]+
						"|" + Chars[i][40]+ "|" + Chars[i][41]+ "|" + Chars[i][42]+ "|" + Chars[i][43]+ "|" + Chars[i][44]+ "|" +
						Chars[i][45]+ "|" + Chars[i][46]+ "|" + Chars[i][47]+ "|" + Chars[i][48]+ "|" + Chars[i][49];

				//	System.out.println(altoFile);

				outtoFile.write(altoFile);
				outtoFile.newLine();

				//	System.out.println(altoFile);
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end writeCharstoFile


	private static void writeadminLoginArray(int i) {
		// write the adminLogin to the array

		System.out.println("Writing the Char to adminLogin with writeadminLoginArray()");

		charsFile[i][0] = String.valueOf(player1.getPlayerNum());
		charsFile[i][1] = player1.getPlayerName();
		charsFile[i][2] = charsFile[i][2];
		charsFile[i][3] = String.valueOf(newRoom.getRoomNum());

	} // end writeadminLoginArray(int i)


	private static void writeLoginToadminLoginFile() throws IOException {
		// write adminLogin arr to file
		//	System.out.println("Writing the charLogin writeLoginToAdminLoginFile()");
		//	System.out.println("This works to correctkly write the current charLogin file (updates for room changes)");
		try {
			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(charLoginPath, false));
			String altoFile = "";
			for (int i=0; i < nextAvailChar; i++) {
				altoFile = charsFile[i][0] + "|" + charsFile[i][1] + "|" + charsFile[i][2] + "|" + charsFile[i][3];
				System.out.println(altoFile);
				outtoFile.write(altoFile);
				outtoFile.newLine();

				//	System.out.println(altoFile);
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	} // end writeLoginToadminLoginFile


	@SuppressWarnings("unused")
	private static void writePBankFile() {
		// TODO Auto-generated method stub
		System.out.println("Banking not yet implimented.");
	} // end writePBankFile()


	private static void writePInvArray(int playerNum) {
		// write the player inventory to array

		System.out.println("Writing the playerinventory to pinventory.txt writePInvArray()");

		pInventory[playerNum][0] = String.valueOf(playerinventory.getPmobid());// = 0; //0
		pInventory[playerNum][1] = playerinventory.getPmobname();// = ""; //1
		pInventory[playerNum][2] = String.valueOf(playerinventory.getPmobplat());// = 0; //2
		pInventory[playerNum][3] = String.valueOf(playerinventory.getPmobgold());// = 0; //3
		pInventory[playerNum][4] = String.valueOf(playerinventory.getPmobsilver());// = 0; //4
		pInventory[playerNum][5] = String.valueOf(playerinventory.getPmobcopper());//= 0; //5
		pInventory[playerNum][6] = String.valueOf(playerinventory.getPmobLHPot());//= 0; //6
		pInventory[playerNum][7] = String.valueOf(playerinventory.getPmobLMPot());//= 0; //7
		pInventory[playerNum][8] = String.valueOf(playerinventory.getPmobHPot());//= 0; //8
		pInventory[playerNum][9] = String.valueOf(playerinventory.getPmobMPot());//= 0; //9
		pInventory[playerNum][10] = String.valueOf(playerinventory.getPmobGHPot());//= 0; //10
		pInventory[playerNum][11] = String.valueOf(playerinventory.getPmobGMPot());//= 0; //11
		pInventory[playerNum][12] = String.valueOf(playerinventory.getPmobMHPot());//= 0; //12
		pInventory[playerNum][13] = String.valueOf(playerinventory.getPmobMMPot());//= 0; //13
		pInventory[playerNum][14] = playerinventory.getBlank0();//= "null"; //14
		pInventory[playerNum][15] = String.valueOf(playerinventory.getPmobInv0());//= 0; //15
		pInventory[playerNum][16] = String.valueOf(playerinventory.getPmobInv1());//= 0; //16
		pInventory[playerNum][17] = String.valueOf(playerinventory.getPmobInv2());//= 0; //17
		pInventory[playerNum][18] = String.valueOf(playerinventory.getPmobInv3());//= 0; //18
		pInventory[playerNum][19] = String.valueOf(playerinventory.getPmobInv4());//= 0; //19
		pInventory[playerNum][20] = String.valueOf(playerinventory.getPmobInv5());//= 0; //20
		pInventory[playerNum][21] = String.valueOf(playerinventory.getPmobInv6());//= 0; //21
		pInventory[playerNum][22] = String.valueOf(playerinventory.getPmobInv7());//= 0; //22
		pInventory[playerNum][23] = String.valueOf(playerinventory.getPmobInv8());//= 0; //23
		pInventory[playerNum][24] = String.valueOf(playerinventory.getPmobInv9());//= 0; //24
		pInventory[playerNum][25] = String.valueOf(playerinventory.getPmobInv10());//= 0; //25
		pInventory[playerNum][26] = String.valueOf(playerinventory.getPmobInv11());//= 0; //26
		pInventory[playerNum][27] = String.valueOf(playerinventory.getPmobInv12());//= 0; //27
		pInventory[playerNum][28] = String.valueOf(playerinventory.getPmobInv13());//= 0; //28
		pInventory[playerNum][29] = String.valueOf(playerinventory.getPmobInv14());//= 0; //29
		pInventory[playerNum][30] = String.valueOf(playerinventory.getPmobInv15());//= 0; //30
		pInventory[playerNum][31] = String.valueOf(playerinventory.getPmobInv16());//= 0; //31
		pInventory[playerNum][32] = String.valueOf(playerinventory.getPmobInv17());//= 0; //32
		pInventory[playerNum][33] = String.valueOf(playerinventory.getPmobInv18());//= 0; //33
		pInventory[playerNum][34] = String.valueOf(playerinventory.getPmobInv19());//= 0; //34
		pInventory[playerNum][35] = String.valueOf(playerinventory.getPmobInv20());//= 0; //35
		pInventory[playerNum][36] = String.valueOf(playerinventory.getPmobInv21());//= 0; //36
		pInventory[playerNum][37] = String.valueOf(playerinventory.getPmobInv22());//= 0; //37
		pInventory[playerNum][38] = String.valueOf(playerinventory.getPmobInv23());//= 0; //38
		pInventory[playerNum][39] = String.valueOf(playerinventory.getPmobInv24());//= 0; //39
		pInventory[playerNum][40] = String.valueOf(playerinventory.getPmobInv25());//= 0; //40
		pInventory[playerNum][41] = String.valueOf(playerinventory.getPmobInv26());//= 0; //41
		pInventory[playerNum][42] = String.valueOf(playerinventory.getPmobInv27());//= 0; //42
		pInventory[playerNum][43] = String.valueOf(playerinventory.getPmobInv28());//= 0; //43
		pInventory[playerNum][44] = String.valueOf(playerinventory.getPmobInv29());//= 0; //44
		pInventory[playerNum][45] = String.valueOf(playerinventory.getBlank1()); //45
		pInventory[playerNum][46] = String.valueOf(playerinventory.getBlank2());// //46
		pInventory[playerNum][47] = String.valueOf(playerinventory.getBlank3());// //47
		pInventory[playerNum][48] = String.valueOf(playerinventory.getBlank4());// //48
		pInventory[playerNum][49] = playerinventory.getBlank5();// //49

		// 	System.out.println(playerinventory.getPmobid() + "=" + player1.getPlayerNum() + ":" + pInventory[playerinventory.getPmobid()][0] + "=" + Chars[player1.getPlayerNum()][0] );
		//	System.out.println(playerinventory.getPmobname() + "=" + player1.getPlayerName());
	} // end writePInvArray


	private static void writePInvFile() {
		// write the player inventory array to file

		//	System.out.println("Need to impliment writePInvFile()");
		// write adminLogin arr to file
		//	System.out.println("Writing the pInventory with writePInvFile()");
		// System.out.println("This works to correctly write the current charLogin file (updates for room changes)");
		try {

			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(pinvPath, false));
			String altoFile = "";

			for (int i=0; i < nextAvailInv; i++) {
				altoFile = pInventory[i][0] + "|" + pInventory[i][1] + "|" + pInventory[i][2] + "|" + pInventory[i][3] + "|" + pInventory[i][4] + "|" + pInventory[i][5] + "|"
						+ pInventory[i][6] + "|" + pInventory[i][7] + "|" + pInventory[i][8] + "|" + pInventory[i][9] + "|" + pInventory[i][10] + "|" + pInventory[i][11]
								+ "|" + pInventory[i][12] + "|" + pInventory[i][13] + "|" + pInventory[i][14] + "|" + pInventory[i][15] + "|" + pInventory[i][16] + "|" + pInventory[i][17]
										+ "|" + pInventory[i][18] + "|" + pInventory[i][19] + "|" + pInventory[i][20] + "|" + pInventory[i][21] + "|" + pInventory[i][22] + "|" + pInventory[i][23]
												+ "|" + pInventory[i][24] + "|" + pInventory[i][25] + "|" + pInventory[i][26] + "|" + pInventory[i][27] + "|" + pInventory[i][28] + "|"
												+ pInventory[i][29] + "|" + pInventory[i][30] + "|" + pInventory[i][31] + "|" + pInventory[i][32] + "|" + pInventory[i][33] + "|" + pInventory[i][34]
														+ "|" + pInventory[i][35] + "|" + pInventory[i][36] + "|" + pInventory[i][37] + "|" + pInventory[i][38] + "|" + pInventory[i][39] + "|"
														+ pInventory[i][40] + "|" + pInventory[i][41] + "|" + pInventory[i][42] + "|" + pInventory[i][43] + "|" + pInventory[i][44] + "|" + pInventory[i][45] + "|"
														+ pInventory[i][46] + "|" + pInventory[i][47] + "|" + pInventory[i][48] + "|" + pInventory[i][49];

				System.out.println(altoFile);

				outtoFile.write(altoFile);
				outtoFile.newLine();

				//	System.out.println(altoFile);
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end writePInvFile();


	private static void osave() {
		// save the objects
		writeObjToArray(editingObject);
		writeObjFile();
	} // end osave


	private static void writeObjToArray(objects o) {
		// write the object to the object array

		//	System.out.println("Working on implimenting writeObjToArray()");
		int i = o.getObjNum();
		Objects[i][0] = String.valueOf(o.getObjNum());
		Objects[i][1] = o.getObjName();
		Objects[i][2] = o.getObjShortDesc();
		Objects[i][3] = o.getObjLongDesc();
		Objects[i][4] = o.getObjExtDesc();
		Objects[i][5] = Arrays.toString(o.getObjKeyWords());

		String t = Arrays.toString(o.getObjKeyWords());
		t = t.replace("[", "");
		t = t.replace("]", "");
		t = t.replace(" ", "");
		Objects[i][5] = t.strip();
		Objects[i][6] = String.valueOf(o.getAddStr());
		Objects[i][7] = String.valueOf(o.getAddStam());
		Objects[i][8] = String.valueOf(o.getAddInt());
		Objects[i][9] = String.valueOf(o.getAddAgi());
		Objects[i][10] = String.valueOf(o.getAddHP());
		Objects[i][11] = String.valueOf(o.getAddMP());
		Objects[i][12] = String.valueOf(o.getDurability());
		Objects[i][13] = String.valueOf(o.getTakeable());
		Objects[i][14] = o.getEquipSlot();

		// add additional ass needed

		Objects[i][15] = o.getObjval();
		Objects[i][16] = o.getObjType();
		Objects[i][17] = String.valueOf(o.getStackSize());
		Objects[i][18] = o.getWeaponType();
		Objects[i][19] = String.valueOf(o.getWeaponDmg());
		Objects[i][20] = o.getWpndmgType();

		Objects[i][21] = o.getV21(); // unused

		Objects[i][22] = o.getArmorType();
		Objects[i][23] = String.valueOf(o.getDmgRedux());

		Objects[i][24] = String.valueOf(o.getHpRestore());
		Objects[i][25] = String.valueOf(o.getMpRestore());

		Objects[i][26] = o.getPotSpell();
		Objects[i][27] = o.getScrollSpell();
		Objects[i][28] = o.getWandSpell();
		Objects[i][29] = String.valueOf(o.getWandCharge());

		Objects[i][30] = String.valueOf(o.getCntSize());


		t = Arrays.toString(o.getCntCont());
		t = t.replace("[", "");
		t = t.replace("]", "");
		t = t.replace(" ", "");
		Objects[i][31] = t.strip();
		//Objects[i][31] = o.getCntCont();

		Objects[i][32] = o.getV32();
		Objects[i][33] = o.getV33();
		Objects[i][34] = o.getV34();
		Objects[i][35] = o.getV35();
		Objects[i][36] = o.getV36();
		Objects[i][37] = o.getV37();
		Objects[i][38] = o.getV38();
		Objects[i][39] = o.getV39();
		Objects[i][40] = o.getV40();

		Objects[i][41] = o.getV41();
		Objects[i][42] = o.getV42(); 
		Objects[i][43] = o.getV43();
		Objects[i][44] = o.getV44();
		Objects[i][45] = o.getV45();
		Objects[i][46] = String.valueOf(o.getBlueGlow());
		Objects[i][47] = String.valueOf(o.getRedGlow());
		Objects[i][48] = String.valueOf(o.getHum());
		Objects[i][49] = String.valueOf(o.getCursed());

		// System.out.println("Done writing the object to the Array");
		// System.out.println(Objects[0][1]); // testing contents of array
		// System.out.println(Objects[i][1]); // testing contents of array

	} // end writeObjToArray


	private static void writeObjFile() {
		// write the object array to file
		// System.out.println("Worling on implimenting writeObjFile()");
		//	System.out.println("This works properly");


		try {

			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(objPath, false));
			String altoFile = "";

			//	editingObject = new objects();

			for (int i=0; i < nextAvailObj; i++) {
				altoFile = Objects[i][0] + "|" + Objects[i][1] + "|" + Objects[i][2] + "|" + Objects[i][3] + "|" + Objects[i][4] + "|" + Objects[i][5] + "|" + Objects[i][6] + "|" + Objects[i][7] + "|" + Objects[i][8] + "|" + Objects[i][9] + "|" + Objects[i][10] + "|" + Objects[i][11] + "|" + Objects[i][12] + "|" + Objects[i][13] + "|" + Objects[i][14] + "|" + Objects[i][15] + "|" + Objects[i][16] + "|" + Objects[i][17] + "|" + Objects[i][18] + "|" + Objects[i][19] + "|" + Objects[i][20] + "|" + Objects[i][21] + "|" + Objects[i][22] + "|" + Objects[i][23] + "|" + Objects[i][24] + "|" + Objects[i][25] + "|" + Objects[i][26] + "|" + Objects[i][27] + "|" + Objects[i][28] + "|" + Objects[i][29] + "|" + Objects[i][30] + "|" + Objects[i][31] + "|" + Objects[i][32] + "|" + Objects[i][33] + "|" + Objects[i][34] + "|" + Objects[i][35] + "|" + Objects[i][36] + "|" + Objects[i][37] + "|" + Objects[i][38] + "|" + Objects[i][39] + "|" + Objects[i][40] + "|" + Objects[i][41] + "|" + Objects[i][42] + "|" + Objects[i][43] + "|" + Objects[i][44] + "|" + Objects[i][45] + "|" + Objects[i][46] + "|" + Objects[i][47] + "|" + Objects[i][48] + "|" + Objects[i][49];

				//	System.out.println("manual string: " + altoFile);
				//	buildCurrentRoom2(i);
				//	outtoFile.write(newRoom2.toString());
				outtoFile.write(altoFile);
				outtoFile.newLine();

				//	System.out.println("bcr2: " + newRoom2.toString());
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end writeObjFile


	private static void msave() throws IOException {
		// save the mobs
		writeMobToArray(editingMob);
		writeMobFile();
		writeMobInvArray(editingMob);
		writeMobInvFile();
	} // end msave()


	private static void writeMobInvArray(mob mobNum) {
		// writes the mob's inventory to array
		//	System.out.println("writeMobInvArray - Works now!");

		int minvNum = mobNum.getMobNum();
		mInventory[minvNum][0] = String.valueOf(editingMobInventory.getPmobid());// = 0; //0
		mInventory[minvNum][1] = mobNum.getMobName();// = ""; //1
		mInventory[minvNum][2] = String.valueOf(editingMobInventory.getPmobplat());// = 0; //2
		mInventory[minvNum][3] = String.valueOf(editingMobInventory.getPmobgold());// = 0; //3
		mInventory[minvNum][4] = String.valueOf(editingMobInventory.getPmobsilver());// = 0; //4
		mInventory[minvNum][5] = String.valueOf(editingMobInventory.getPmobcopper());//= 0; //5
		mInventory[minvNum][6] = String.valueOf(editingMobInventory.getPmobLHPot());//= 0; //6
		mInventory[minvNum][7] = String.valueOf(editingMobInventory.getPmobLMPot());//= 0; //7
		mInventory[minvNum][8] = String.valueOf(editingMobInventory.getPmobHPot());//= 0; //8
		mInventory[minvNum][9] = String.valueOf(editingMobInventory.getPmobMPot());//= 0; //9
		mInventory[minvNum][10] = String.valueOf(editingMobInventory.getPmobGHPot());//= 0; //10
		mInventory[minvNum][11] = String.valueOf(editingMobInventory.getPmobGMPot());//= 0; //11
		mInventory[minvNum][12] = String.valueOf(editingMobInventory.getPmobMHPot());//= 0; //12
		mInventory[minvNum][13] = String.valueOf(editingMobInventory.getPmobMMPot());//= 0; //13
		mInventory[minvNum][14] = editingMobInventory.getBlank0();//= "null"; //14
		mInventory[minvNum][15] = String.valueOf(editingMobInventory.getPmobInv0());//= 0; //15
		mInventory[minvNum][16] = String.valueOf(editingMobInventory.getPmobInv1());//= 0; //16
		mInventory[minvNum][17] = String.valueOf(editingMobInventory.getPmobInv2());//= 0; //17
		mInventory[minvNum][18] = String.valueOf(editingMobInventory.getPmobInv3());//= 0; //18
		mInventory[minvNum][19] = String.valueOf(editingMobInventory.getPmobInv4());//= 0; //19
		mInventory[minvNum][20] = String.valueOf(editingMobInventory.getPmobInv5());//= 0; //20
		mInventory[minvNum][21] = String.valueOf(editingMobInventory.getPmobInv6());//= 0; //21
		mInventory[minvNum][22] = String.valueOf(editingMobInventory.getPmobInv7());//= 0; //22
		mInventory[minvNum][23] = String.valueOf(editingMobInventory.getPmobInv8());//= 0; //23
		mInventory[minvNum][24] = String.valueOf(editingMobInventory.getPmobInv9());//= 0; //24
		mInventory[minvNum][25] = String.valueOf(editingMobInventory.getPmobInv10());//= 0; //25
		mInventory[minvNum][26] = String.valueOf(editingMobInventory.getPmobInv11());//= 0; //26
		mInventory[minvNum][27] = String.valueOf(editingMobInventory.getPmobInv12());//= 0; //27
		mInventory[minvNum][28] = String.valueOf(editingMobInventory.getPmobInv13());//= 0; //28
		mInventory[minvNum][29] = String.valueOf(editingMobInventory.getPmobInv14());//= 0; //29
		mInventory[minvNum][30] = String.valueOf(editingMobInventory.getPmobInv15());//= 0; //30
		mInventory[minvNum][31] = String.valueOf(editingMobInventory.getPmobInv16());//= 0; //31
		mInventory[minvNum][32] = String.valueOf(editingMobInventory.getPmobInv17());//= 0; //32
		mInventory[minvNum][33] = String.valueOf(editingMobInventory.getPmobInv18());//= 0; //33
		mInventory[minvNum][34] = String.valueOf(editingMobInventory.getPmobInv19());//= 0; //34
		mInventory[minvNum][35] = String.valueOf(editingMobInventory.getPmobInv20());//= 0; //35
		mInventory[minvNum][36] = String.valueOf(editingMobInventory.getPmobInv21());//= 0; //36
		mInventory[minvNum][37] = String.valueOf(editingMobInventory.getPmobInv22());//= 0; //37
		mInventory[minvNum][38] = String.valueOf(editingMobInventory.getPmobInv23());//= 0; //38
		mInventory[minvNum][39] = String.valueOf(editingMobInventory.getPmobInv24());//= 0; //39
		mInventory[minvNum][40] = String.valueOf(editingMobInventory.getPmobInv25());//= 0; //40
		mInventory[minvNum][41] = String.valueOf(editingMobInventory.getPmobInv26());//= 0; //41
		mInventory[minvNum][42] = String.valueOf(editingMobInventory.getPmobInv27());//= 0; //42
		mInventory[minvNum][43] = String.valueOf(editingMobInventory.getPmobInv28());//= 0; //43
		mInventory[minvNum][44] = String.valueOf(editingMobInventory.getPmobInv29());//= 0; //44
		mInventory[minvNum][45] = String.valueOf(editingMobInventory.getBlank1()); //45
		mInventory[minvNum][46] = String.valueOf(editingMobInventory.getBlank2());// //46
		mInventory[minvNum][47] = String.valueOf(editingMobInventory.getBlank3());// //47
		mInventory[minvNum][48] = String.valueOf(editingMobInventory.getBlank4());// //48
		mInventory[minvNum][49] = editingMobInventory.getBlank5();// //49

		//		System.out.println(editingMobInventory.getPmobid() + "=" + editingMob.getMobNum() + ":" + mInventory[editingMobInventory.getPmobid()][0] + "=" + Mobs[editingMob.getMobNum()][0] );
		//		System.out.println(editingMobInventory.getPmobname() + "=" + editingMob.getMobName());



	} // end writeMonInvArray(mob m)


	private static void writeMobInvFile() {
		// write the mob inventory array to file
		//	System.out.println("Need to impliment writePInvFile()");
		// write adminLogin arr to file
		//	System.out.println("Writing the pInventory with writePInvFile()");
		//System.out.println("This works to correctly write the current charLogin file (updates for room changes)");
		try {

			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(minvPath, false));
			String altoFile = "";

			for (int i=0; i < nextAvailmInv; i++) {
				altoFile = mInventory[i][0] + "|" + mInventory[i][1] + "|" + mInventory[i][2] + "|" + mInventory[i][3] + "|" + mInventory[i][4] + "|" + mInventory[i][5] + "|"
						+ mInventory[i][6] + "|" + mInventory[i][7] + "|" + mInventory[i][8] + "|" + mInventory[i][9] + "|" + mInventory[i][10] + "|" + mInventory[i][11]
								+ "|" + mInventory[i][12] + "|" + mInventory[i][13] + "|" + mInventory[i][14] + "|" + mInventory[i][15] + "|" + mInventory[i][16] + "|" + mInventory[i][17]
										+ "|" + mInventory[i][18] + "|" + mInventory[i][19] + "|" + mInventory[i][20] + "|" + mInventory[i][21] + "|" + mInventory[i][22] + "|" + mInventory[i][23]
												+ "|" + mInventory[i][24] + "|" + mInventory[i][25] + "|" + mInventory[i][26] + "|" + mInventory[i][27] + "|" + mInventory[i][28] + "|"
												+ mInventory[i][29] + "|" + mInventory[i][30] + "|" + mInventory[i][31] + "|" + mInventory[i][32] + "|" + mInventory[i][33] + "|" + mInventory[i][34]
														+ "|" + mInventory[i][35] + "|" + mInventory[i][36] + "|" + mInventory[i][37] + "|" + mInventory[i][38] + "|" + mInventory[i][39] + "|"
														+ mInventory[i][40] + "|" + mInventory[i][41] + "|" + mInventory[i][42] + "|" + mInventory[i][43] + "|" + mInventory[i][44] + "|" + mInventory[i][45] + "|"
														+ mInventory[i][46] + "|" + mInventory[i][47] + "|" + mInventory[i][48] + "|" + mInventory[i][49];

				//	System.out.println(altoFile);

				outtoFile.write(altoFile);
				outtoFile.newLine();

				//	System.out.println(altoFile);
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	} // end writeMobInvFile()


	private static void writeMobToArray(mob m) {
		// write the mob to the mob array
		// this works

		int i = m.getMobNum();
		Mobs[i][0] = String.valueOf(editingMob.getMobNum()); // 0
		Mobs[i][1] = m.getMobName();
		Mobs[i][2] = m.getMobShortDesc();
		Mobs[i][3] = m.getMobLongDesc();
		//	Mobs[i][4] = Arrays.toString(m.getMobKeyWords());
		String t = Arrays.toString(m.getMobKeyWords());
		t = t.replace("[", "");
		t = t.replace("]", "");
		t = t.replace(" ", "");
		Mobs[i][4] = t.strip();

		Mobs[i][5] = String.valueOf(m.getMobHP());
		Mobs[i][6] = String.valueOf(m.getMobMP());
		Mobs[i][7] = String.valueOf(m.getMobLvl()); // lvl
		Mobs[i][8] = String.valueOf(m.getStam());
		Mobs[i][9] = String.valueOf(m.getStr());

		Mobs[i][10] = String.valueOf(m.getIntel());
		Mobs[i][11] = String.valueOf(m.getAgility());
		Mobs[i][12] = m.getHeadSlot();
		Mobs[i][13] = m.getNeckSlot();
		Mobs[i][14] = m.getShoulderSlot();
		Mobs[i][15] = m.getChestSlot();
		Mobs[i][16] = m.getWristSlot();
		Mobs[i][17] = m.getHandSlot();
		Mobs[i][18] = m.getFinger1();
		Mobs[i][19] = m.getFinger2();

		Mobs[i][20] = m.getWaistSlot();
		Mobs[i][21] = m.getLegSlot();
		Mobs[i][22] = m.getFootSlot();
		Mobs[i][23] = m.getTrinket1Slot();
		Mobs[i][24] = m.getTrinket2Slot();
		Mobs[i][25] = m.getWeapon1Slot();
		Mobs[i][26] = m.getWeaponShieldSlot();
		Mobs[i][27] = m.getMobRace();
		Mobs[i][28] = m.getMobSubRace();
		Mobs[i][29] = m.getMobRank();

		Mobs[i][30] = String.valueOf(m.getMobXPVal());
		Mobs[i][31] = String.valueOf(m.getMobIsAlive());
		Mobs[i][32] = m.getMobGender();
		Mobs[i][33] = m.getMobClass();

		Mobs[i][34] = String.valueOf(m.getAttackable());
		Mobs[i][35] = String.valueOf(m.getWanders());
		Mobs[i][36] = m.getV36();
		Mobs[i][37] = m.getV37();
		Mobs[i][38] = m.getV38();
		Mobs[i][39] = m.getV39();

		Mobs[i][40] = m.getV40();
		Mobs[i][41] = m.getV41();
		Mobs[i][42] = m.getV42();
		Mobs[i][43] = m.getV43();
		Mobs[i][44] = m.getV44();
		Mobs[i][45] = m.getV45();
		Mobs[i][46] = String.valueOf(m.getV46());
		Mobs[i][47] = m.getV47();
		Mobs[i][48] = m.getV48();
		Mobs[i][49] = m.getV49();

		//	System.out.println(Mobs[i][1]); // testing the write to array

		System.out.println("Done writing mob to array.");
	} // end writeMobToArray


	private static void writeCharToCharArray(int i) {
		// write the character to the Char array
		// System.out.println("Writing the Char to Char Array with writeCharToCharArray()");

		// Write the Char to the Char Array
		Chars[i][0] = String.valueOf(i); //0
		Chars[i][1] = player1.getPlayerName(); //1
		Chars[i][2] = player1.getPlayerShortDesc(); //2
		Chars[i][3] = player1.getPlayerLongDesc(); //3
		String tkeyw = Arrays.toString(player1.getPlayerKeyWords()).strip();
		tkeyw = tkeyw.replace("[", "").strip();
		tkeyw = tkeyw.replace("]", "").strip();
		tkeyw = tkeyw.replace(" ", "");
		Chars[i][4] = tkeyw;
		Chars[i][5] = String.valueOf(player1.getPlayerHP()); //5
		Chars[i][6] = String.valueOf(player1.getPlayerMP()); //6
		Chars[i][7] = String.valueOf(player1.getPlayerLvl()); //7
		Chars[i][8] = String.valueOf(player1.getStam());
		Chars[i][9] = String.valueOf(player1.getStr());
		Chars[i][10] = String.valueOf(player1.getIntel());
		Chars[i][11] = String.valueOf(player1.getAgility());
		Chars[i][12] = player1.getHandSlot();
		Chars[i][13] = player1.getNeckSlot();
		Chars[i][14] = player1.getShoulderSlot();
		Chars[i][15] = player1.getChestSlot();
		Chars[i][16] = player1.getWristSlot();
		Chars[i][17] = player1.getHandSlot();
		Chars[i][18] = player1.getFinger1();
		Chars[i][19] = player1.getFinger2();
		Chars[i][20] = player1.getWaistSlot();
		Chars[i][21] = player1.getLegSlot();
		Chars[i][22] = player1.getFootSlot();
		Chars[i][23] = player1.getTrinket1Slot();
		Chars[i][24] = player1.getTrinket2Slot();
		Chars[i][25] = player1.getWeapon1Slot();
		Chars[i][26] = player1.getWeaponShieldSlot();
		Chars[i][27] = player1.getPlayerRace();
		Chars[i][28] = player1.getPlayerSubRace();
		Chars[i][29] = player1.getPlayerTier();
		Chars[i][30] = String.valueOf(player1.getPlayerXP());
		Chars[i][31] = String.valueOf(player1.getPlayerLvl());
		Chars[i][32] = player1.getPlayerGender();
		Chars[i][33] = player1.getPlayerClass();
		Chars[i][34] = player1.getBlank1();
		Chars[i][35] = player1.getBlank2();
		Chars[i][36] = player1.getBlank3();
		Chars[i][37] = player1.getBlank4();
		Chars[i][38] = player1.getBlank5();
		Chars[i][39] = player1.getBlank6();
		Chars[i][40] = player1.getBlank7();
		Chars[i][41] = player1.getBlank8();
		Chars[i][42] = player1.getBlank9();
		Chars[i][43] = player1.getBlank10();
		Chars[i][44] = player1.getBlank11();
		Chars[i][45] = player1.getBlank12();
		Chars[i][46] = player1.getBlank13();
		Chars[i][47] = player1.getBlank14();
		Chars[i][48] = player1.getBlank15();
		Chars[i][49] = player1.getBlank16();

	} // end writeCharToCharArray()


	private static void writeMobFile() {
		// write the mob array to file
		// this works!
		try {
			BufferedWriter outtoFile = new BufferedWriter(new FileWriter(mobPath, false));
			String altoFile = "";
			for (int i=0; i < nextAvailMob; i++) {
				altoFile = Mobs[i][0] + "|" + Mobs[i][1] + "|" + Mobs[i][2] + "|" + Mobs[i][3] + "|" + Mobs[i][4] + "|" + Mobs[i][5] + "|" + Mobs[i][6] + "|" + Mobs[i][7] + "|" + Mobs[i][8] + "|" + Mobs[i][9] + "|" + Mobs[i][10] + "|" + Mobs[i][11] + "|" + Mobs[i][12] + "|" + Mobs[i][13] + "|" + Mobs[i][14] + "|" + Mobs[i][15] + "|" + Mobs[i][16] + "|" + Mobs[i][17] + "|" + Mobs[i][18] + "|" + Mobs[i][19] + "|" + Mobs[i][20] + "|" + Mobs[i][21] + "|" + Mobs[i][22] + "|" + Mobs[i][23] + "|" + Mobs[i][24] + "|" + Mobs[i][25] + "|" + Mobs[i][26] + "|" + Mobs[i][27] + "|" + Mobs[i][28] + "|" + Mobs[i][29] + "|" + Mobs[i][30] + "|" + Mobs[i][31] + "|" + Mobs[i][32] + "|" + Mobs[i][33] + "|" + Mobs[i][34] + "|" + Mobs[i][35] + "|" + Mobs[i][36] + "|" + Mobs[i][37] + "|" + Mobs[i][38] + "|" + Mobs[i][39] + "|" + Mobs[i][40] + "|" + Mobs[i][41] + "|" + Mobs[i][42] + "|" + Mobs[i][43] + "|" + Mobs[i][44] + "|" + Mobs[i][45] + "|" + Mobs[i][46] + "|" + Mobs[i][47] + "|" + Mobs[i][48] + "|" + Mobs[i][49];
				outtoFile.write(altoFile);
				outtoFile.newLine();
			}
			outtoFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end writeMobFile


	private static void mobCommands() {
		// TODO 

		System.out.println("Valid commands are: ");
		System.out.println("commands");
		System.out.println("create mob");
		System.out.println("edit mob");
		System.out.println("");

		System.out.println("defaults");
		System.out.println("reset mob");
		System.out.println("set mob attackable");
		System.out.println("set mob class");
		System.out.println("set mob gender");
		System.out.println("set mob keywords");
		System.out.println("set mob level");
		System.out.println("set mob long desc");
		System.out.println("set mob name");
		System.out.println("set mob xp");
		System.out.println("set mob race - currently this is cosmetic");
		System.out.println("set mob rank - currently this is cosmetic");
		System.out.println("set mob short desc");

		System.out.println("set mob subrace - this is cosmetic");
		System.out.println("set mob talker");
		System.out.println("");

		System.out.println("set mob agility");
		System.out.println("set mob intellect");
		System.out.println("set mob strength");
		System.out.println("set mob stamina");
		System.out.println("");

		// mob equipment slots (not inventory)
		System.out.println("Mob Equipment");
		System.out.println("set mob chest slot");
		System.out.println("set mob finger1 slot");
		System.out.println("set mob finger2 slot");
		System.out.println("set mob foot slot");
		System.out.println("set mob hand slot");
		System.out.println("set mob head slot");
		System.out.println("set mob leg slot");
		System.out.println("set mob neck slot");
		System.out.println("set mob shoulder slot");
		System.out.println("set mob trinket1 slot");
		System.out.println("set mob trinket2 slot");
		System.out.println("set mob waist slot");
		System.out.println("set mob weapon1 slot");
		System.out.println("set mob weaponshield slot");

		System.out.println("");
		System.out.println("show all mobs - lists all the mobs by mob id and mob name");
		System.out.println("show mob - displays the mob currently being edited");


	} // end mobCommands()




	private static void playerCommands() {
		// TODO 
		System.out.println("Valid commands are: ");
		System.out.println("commands");

		System.out.println("attack 1-5.mob");
		System.out.println("look 1-5.mob");
		System.out.println("north/north east/east/south east/south/south west/west/north west/up down - attempts to walk in the indicated direction");


		System.out.println("coins");
		System.out.println("drink");
		System.out.println("eat");
		System.out.println("equipment");
		System.out.println("inventory");
		System.out.println("roll");
		System.out.println("score");

		System.out.println("frown");
		System.out.println("ponder");
		System.out.println("sigh");


	} // end playerCommands()



	private static void roomCommands() {
		// lists the commands available in the Room Editor
		System.out.println("Valid commands are: ");
		System.out.println("commands");
		System.out.println("create room");
		System.out.println("edit room");
		System.out.println("");

		System.out.println("set room name"); //1
		System.out.println("set room short desc"); //2
		System.out.println("set room long desc"); //3
		System.out.println("");

		System.out.println("set exit <dir>"); //4-13
		System.out.println("set mob <1-6>"); //14
		System.out.println("set obj <1-6>"); //15
		System.out.println("");

		System.out.println("set lit"); //16
		System.out.println("set camp"); //17
		System.out.println("set rent"); //18
		System.out.println("set indoor setting"); // 19
		System.out.println("set terrain"); //20
		System.out.println("set bank"); //21

		System.out.println(" ");
		System.out.println(" ");
		System.out.println("csave");

	}// end roomCommands()


	private static void objCommands() {
		// list of object editor commands
		System.out.println("Valid commands are: ");
		System.out.println("commands");
		System.out.println("create obj");
		System.out.println("edit obj");
		System.out.println("");
		System.out.println("set obj name"); // moved to setObjName()
		System.out.println("set obj short desc");
		System.out.println("set obj long desc");
		System.out.println("set obj extended desc");
		System.out.println("set obj keywords");
		System.out.println("set obj durability");	
		System.out.println("set obj takeable");
		System.out.println("set obj type");
		System.out.println("set obj value");
		System.out.println("set obj equip slot");
		System.out.println("");

		System.out.println("set obj add hp");
		System.out.println("set obj add mp");
		System.out.println("set obj add agi");
		System.out.println("set obj add int");
		System.out.println("set obj add sta");
		System.out.println("set obj add str");
		System.out.println("");

		System.out.println("set obj blue glow");
		System.out.println("set obj red glow");
		System.out.println("set obj hum");
		System.out.println("set obj cursed");
		System.out.println("");

		System.out.println("Object Type Specific commands");
		System.out.println("set obj hp restore");
		System.out.println("set obj mp restore");
		System.out.println("set obj wand spell");
		System.out.println("set obj wand charge");
		System.out.println("set obj weapon type");
		System.out.println("set obj weapon damage");
		System.out.println("set obj weapon damage type");
		System.out.println("set obj damage reduction");
		System.out.println("set obj container size");
		System.out.println("set obj container contents");
		System.out.println("set obj potion spell");

		System.out.println("");
		System.out.println("");
		System.out.println("show obj"); // displays the current obj in editor
		System.out.println("");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("csave");
	} // end objCommands





	private static void genCommands() {
		// list of the general (non editor specific) commands
		System.out.println("Valid commands are: ");
		System.out.println("attack <1.mob-6.mob> - starts a Turn-based attack sequence with the designaged mob");
		System.out.println("camp - camps (if possible) for a period of time, restoring (or lowering) you to most of your health and mana.");
		System.out.println("camp out - camps and exits out of the game to the menu");
		System.out.println("cast cosmos <1.mob-6.mob>");
		System.out.println("cast cure-light - casts cure light (wounds) on self, heals for a small amount");
		System.out.println("cast cure-serious - casts cure serious (wounds) on self, heals for a moderate amount");
		System.out.println("commands - lists the valid commands");
		System.out.println("<dir> - atttempts to move in a direction");
		System.out.println("drop obj - drops the designated item to the ground (if space avail).");
		System.out.println("equipment - lists the players currently equipped items");
		System.out.println("equip obj - wears the designated piece of equipment");
		System.out.println("exchange coins - if at a bank, attempts to exchange coins");
		System.out.println("exit - exits the game");
		System.out.println("inventory - lists the players current coins, potions and inventory");
		System.out.println("look - looks at the current room");
		System.out.println("look <dir> - attempts to look in a direction, should tell you if a room has mobs, objects or is too dark.");
		System.out.println("look <1.mob-6.mob> - attempts to look at the designated mob");
		System.out.println("look <1.obj-6.obj> - attempts to look at the designated object");
		System.out.println("quaff <LHP-HP-GHP-MMP> - quaffs the appropriate level healing potion");
		System.out.println("quaff <LMP-MP-GMP-MMP> - quaffs the appropriate level mana potion");
		System.out.println("remove obj - attempts to remove the equipped item");
		System.out.println("rent - rents (if possible) for a period of time, restoring all of your health and mana.");
		System.out.println("rent out - rents (if possible) and exits to the game menu");
		System.out.println("score - list the players current stats and scores");
		System.out.println("take obj - takes an item from room");
		System.out.println("time - gives game time information");



		System.out.println("");
		System.out.println("Privileged Commands");
		System.out.println("create obj - creates a new obj to build");
		System.out.println("create mob - creates a new mob to build");
		System.out.println("create room - creates a new room to build");
		System.out.println("csave - saves the editor");
		System.out.println("edit mob - puts you into the mob editor");
		System.out.println("edit obj - puts you into the object editor");
		System.out.println("edit room - puts your into the room editor");
		System.out.println("goto room - attempts to bring you to the listed room");
		System.out.println("list rooms - lists all of the current rooms");
		System.out.println("list objects - lists all of the current objects");
		System.out.println("list mobs - lists all of the current mobs");


	}



	private static void castCosmos2(mob m, player p) throws Exception {
		// mob casts cosmos at player

		//player1 = p;
		System.out.println("" + p.getPlayerName() + " " + p.getPlayerHP());

		int cosmosCost = 35; // cosmos cost 35 mana

		m.setMP(m.getMP() - cosmosCost);

		System.out.println(m.getMobName() + " attempts to cast Cosmos Arrow of Pain at " + p.getPlayerName());

		int max = (m.getIntel())/2;
		int min = 1;
		Random rand = new Random();

		int randomNum = rand.nextInt((max - min) + 1);
		System.out.println(m.getMobName() + " fired a shadowy arrow dealing " + randomNum + " damage.");
		p.setPlayerHP(p.getPlayerHP() - randomNum);
		System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMobMP() + "/" + m.getMaxMP() );

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		randomNum = rand.nextInt((max - min) + 1);
		System.out.println(m.getMobName() + " fired a shadowy arrow dealing " + randomNum + " damage.");
		p.setPlayerHP(p.getPlayerHP() - randomNum);
		System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMobMP() + "/" + m.getMaxMP() );

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		randomNum = rand.nextInt((max - min) + 1);
		System.out.println(m.getMobName() + " fired a shadowy arrow dealing " + randomNum + " damage.");
		p.setPlayerHP(p.getPlayerHP() - randomNum);
		System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMP() + "/" + m.getMaxMP() );

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		if (p.getPlayerHP()<=0){
			// death stuff
			System.out.println("Your body has been wracked by too much agony, and you succumbed to your pain.");
			System.out.println(p.getPlayerName() + " (the player) has died. 1");
			System.out.println("You have DIED!");
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			System.out.println("Reload your character: " + p.getPlayerName());
			loginSys3();

		}
	} // end castCosmos()

	private static void lookObj(objects o) {
		// replaced by showObjInfo3()

		/*
		System.out.println("From lookObj(o)");
		System.out.println("Object Number: " + o.getObjNum());
		System.out.println("Object Name: " + o.getObjName());
		System.out.println("Object Short Desc: " + o.getObjShortDesc());
		System.out.println("Object Long Desc: " + o.getObjLongDesc());
		System.out.println("Keywords: "+ Arrays.toString(o.getObjKeyWords()));
		System.out.println("Keyword 1: " + o.getKeyWord(0) + "  Keyword 2: " + o.getKeyWord(1) + "  Keyword 3: " + o.getKeyWord(2));

		System.out.println("Base Stamina: " + o.getAddStam() + "   Strength: " + o.getAddStr() + "   Intelligence: " + o.getAddInt() + "   Agility: " + o.getAddAgi());
		 */


	} // end lookObj

	private static void lookObjByKeyword() {

		System.out.println("Which object do you wish to you look at?"); 
		String tempkinput = input.nextLine();

		// mob keywords to strings for comparison
		String to0kw0 = tobj0.getKeyWord(0);
		String to0kw1 = tobj0.getKeyWord(1);
		String to0kw2 = tobj0.getKeyWord(2);
		String to1kw0 = tobj1.getKeyWord(0);
		String to1kw1 = tobj1.getKeyWord(1);
		String to1kw2 = tobj1.getKeyWord(2);
		String to2kw0 = tobj2.getKeyWord(0);
		String to2kw1 = tobj2.getKeyWord(1);
		String to2kw2 = tobj2.getKeyWord(2);
		String to3kw0 = tobj3.getKeyWord(0);
		String to3kw1 = tobj3.getKeyWord(1);
		String to3kw2 = tobj3.getKeyWord(2);
		String to4kw0 = tobj4.getKeyWord(0);
		String to4kw1 = tobj4.getKeyWord(1);
		String to4kw2 = tobj4.getKeyWord(2);
		String to5kw0 = tobj5.getKeyWord(0);
		String to5kw1 = tobj5.getKeyWord(1);
		String to5kw2 = tobj5.getKeyWord(2);

		lookObject.resetObject();
		if ( to0kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj0.getObjNum());
			showObjInfo3();
		}
		else if ( to0kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj0.getObjNum());
			showObjInfo3();
		}
		else if ( to0kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj0.getObjNum());
			showObjInfo3();
		}
		else if ( to1kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj1.getObjNum());
			showObjInfo3();	
		}
		else if ( to1kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj1.getObjNum());
			showObjInfo3();
		}
		else if ( to1kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj1.getObjNum());
			showObjInfo3();
		}
		else if ( to2kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj2.getObjNum());
			showObjInfo3();
		}
		else if ( to2kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj2.getObjNum());
			showObjInfo3();	
		}
		else if ( to2kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj2.getObjNum());
			showObjInfo3();	
		}
		else if ( to3kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj3.getObjNum());
			showObjInfo3();
		}
		else if ( to3kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj3.getObjNum());
			showObjInfo3();
		}
		else if ( to3kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj3.getObjNum());
			showObjInfo3();	
		}
		else if ( to4kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj4.getObjNum());
			showObjInfo3();	
		}
		else if ( to4kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj4.getObjNum());
			showObjInfo3();	
		}
		else if ( to4kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj4.getObjNum());
			showObjInfo3();
		}
		else if ( to5kw0.equals(tempkinput)) {
			loadObject(lookObject,tobj5.getObjNum());
			showObjInfo3();
		}
		else if ( to5kw1.equals(tempkinput)) {
			loadObject(lookObject,tobj5.getObjNum());
			showObjInfo3();
		}
		else if ( to5kw2.equals(tempkinput)) {
			loadObject(lookObject,tobj5.getObjNum());
			showObjInfo3();
		}
		else {
			System.out.println("You do not see any such object in the room.");
		}	
		lookObject.resetObject();

	} // lookObjByKeyword()

	private static void lookMobByKeyword() {

		System.out.println("Which mob do you wish to you look at?"); 
		String tempkinput = input.nextLine();

		// mob keywords to strings for comparison
		String tm0kw0 = tmob0.getKeyWord(0);
		String tm0kw1 = tmob0.getKeyWord(1);
		String tm0kw2 = tmob0.getKeyWord(2);
		String tm1kw0 = tmob1.getKeyWord(0);
		String tm1kw1 = tmob1.getKeyWord(1);
		String tm1kw2 = tmob1.getKeyWord(2);
		String tm2kw0 = tmob2.getKeyWord(0);
		String tm2kw1 = tmob2.getKeyWord(1);
		String tm2kw2 = tmob2.getKeyWord(2);
		String tm3kw0 = tmob3.getKeyWord(0);
		String tm3kw1 = tmob3.getKeyWord(1);
		String tm3kw2 = tmob3.getKeyWord(2);
		String tm4kw0 = tmob4.getKeyWord(0);
		String tm4kw1 = tmob4.getKeyWord(1);
		String tm4kw2 = tmob4.getKeyWord(2);
		String tm5kw0 = tmob5.getKeyWord(0);
		String tm5kw1 = tmob5.getKeyWord(1);
		String tm5kw2 = tmob5.getKeyWord(2);

		
		
		

		//
		// TEST START
		//
		
			
			
		// test if keyword has 1.kw, 2.kw, 3.kw, 4.kw, 5.k5 6.kw
		String s = tempkinput;
		if(s.contains("."))
		{
			System.out.println("string contains dot");
			String[] keyinput = new String[2];
			keyinput[0]="";
			keyinput[1]="";
			keyinput=s.split(".");
			String k1 = keyinput[0];
			String k2 = keyinput[1];
			
			

			switch(k1) {
			case "1":{
				// 
			}
			case "2":{
				// 
			}
			case "3":{
				
			}
			case "4":{
				
			}
			case "5":{
				
			}
			case "6":{
				// should only be tmob5 left?
			}
			default:
			{
				// not a valid "." input
			}
			}
			
			
			
			// if 1.
			//if(pmob[5].equals(zero)) {
			if(keyinput[0].equals(one)) {
				// TODO
			}
			else { } // does not equal 1

			// if 2.
			if(keyinput[0].equals(two)) {
				// TODO
			}
			else { } // does not equal 2

			// if 3.
			if(keyinput[0].equals(three)) {
				// TODO
			}
			else { } // does not equal 3

			// if 4.
			if(keyinput[0].equals(four)) {
				//TODO
			}
			else { } // does not equal 4 

			// if 5.
			if(keyinput[0].equals(five)) {
				//TODO
			}
			else { } // does not equal 5

			// if 6.
			if(keyinput[0].equals(six)) {
				//TODO
				// this must be tmob5, HAH!
			}
			else { } // does not equal 6

			// shoud be done?

		}
		else {
			System.out.println("no dot in string ");
		}

		//
		// END OF TEST 1., 2. 3. 4. 5. 6.
		//


		
		
		// this works for just keyword, but not 1.kw 2.kw or 3.kw ... yet

		if ( tm0kw0.equals(tempkinput)) {
			lookMob(tmob0);
		}
		else if ( tm0kw1.equals(tempkinput)) {
			lookMob(tmob0);
		}
		else if ( tm0kw2.equals(tempkinput)) {
			lookMob(tmob0);
		}
		else if ( tm1kw0.equals(tempkinput)) {
			lookMob(tmob1);
		}
		else if ( tm1kw1.equals(tempkinput)) {
			lookMob(tmob1);
		}
		else if ( tm1kw2.equals(tempkinput)) {
			lookMob(tmob1);
		}
		else if ( tm2kw0.equals(tempkinput)) {
			lookMob(tmob2);
		}
		else if ( tm2kw1.equals(tempkinput)) {
			lookMob(tmob2);
		}
		else if ( tm2kw2.equals(tempkinput)) {
			lookMob(tmob2);
		}
		else if ( tm3kw0.equals(tempkinput)) {
			lookMob(tmob3);
		}
		else if ( tm3kw1.equals(tempkinput)) {
			lookMob(tmob3);
		}
		else if ( tm3kw2.equals(tempkinput)) {
			lookMob(tmob3);
		}
		else if ( tm4kw0.equals(tempkinput)) {
			lookMob(tmob4);
		}
		else if ( tm4kw1.equals(tempkinput)) {
			lookMob(tmob4);
		}
		else if ( tm4kw2.equals(tempkinput)) {
			lookMob(tmob4);
		}
		else if ( tm5kw0.equals(tempkinput)) {
			lookMob(tmob5);
		}
		else if ( tm5kw1.equals(tempkinput)) {
			lookMob(tmob5);
		}
		else if ( tm5kw2.equals(tempkinput)) {
			lookMob(tmob5);
		}

		else {
			System.out.println("You do not see any such mob in the room.");
		}		

	} // end lookMobByKeyword()

	private static void lookMob(mob m) {
		System.out.println("From lookMob(m)");
		System.out.println("Mob Number: " + m.getMobNum());
		System.out.println("Mob Name: " + m.getMobName());
		System.out.println("Description: " + m.getMobLongDesc());
		System.out.println("Keywords: "+ Arrays.toString(m.getMobKeyWords()));
		System.out.println("Keyword 1: " + m.getKeyWord(0) + "  Keyword 2: " + m.getKeyWord(1) + "  Keyword 3: " + m.getKeyWord(2));
		System.out.println("Class: [" + m.getMobClass() + "]");
		System.out.println("Race: [" + m.getmobRace() + "]  Subrace: [" + m.getmobSubRace() + "]  Level: [" + m.getMobLvl() + "]   Rank: [" + m.getmobRank() + "]");
		System.out.println("HPs: [" + m.getMobHP() + "/" + m.getMaxHP() + "]   MPs: [" + m.getMobMP() + "/" + m.getMaxMP() + "]");
		System.out.println("Base Stamina: " + m.getStam() + "   Strength: " + m.getStr() + "   Intelligence: " + m.getIntel() + "   Agility: " + m.getAgility());
		System.out.println("Equiped Items -------------------------------------------------------------");
		if (mhelm.getObjNum() != 0) { System.out.println("Head Slot: " + " [" + mhelm.getObjNum() + "] " + mhelm.getObjShortDesc() + " " + mhelm.getObjGlows()); }
		if (mneck.getObjNum() != 0) { System.out.println("Neck Slot: " + " [" + mneck.getObjNum() + "] " + mneck.getObjShortDesc() + " " + mneck.getObjGlows()); }
		if (mshoulders.getObjNum() != 0) { System.out.println("Shoulder Slot: " + " [" + mshoulders.getObjNum() + "] " + mshoulders.getObjShortDesc() + " " + mshoulders.getObjGlows()); }
		if (mchest.getObjNum() != 0) { System.out.println("Chest Slot: " + " [" + mchest.getObjNum() + "] " + mchest.getObjShortDesc() + " " + mchest.getObjGlows()); }
		if (mwrist.getObjNum() != 0) { System.out.println("Wrist Slot: " + " [" + mwrist.getObjNum() + "] " + mwrist.getObjShortDesc() + " " + mwrist.getObjGlows()); }
		if (mhands.getObjNum() != 0) { System.out.println("Hand Slot: " + " [" + mhands.getObjNum() + "] " + mhands.getObjShortDesc() + " " + mhands.getObjGlows());	}
		if (mfinger1.getObjNum() != 0) { System.out.println("Finger Slot: " + " [" + mfinger1.getObjNum() + "] " + mfinger1.getObjShortDesc() + " " + mfinger1.getObjGlows()); }
		if (mfinger2.getObjNum() != 0) { System.out.println("Finger Slot: " + " [" + mfinger2.getObjNum() + "] " + mfinger2.getObjShortDesc() + " " + mfinger2.getObjGlows()); }
		if (mwaist.getObjNum() != 0) { System.out.println("Waist Slot: " + " [" + mwaist.getObjNum() + "] " + mwaist.getObjShortDesc() + " " + mwaist.getObjGlows()); }
		if (mleg.getObjNum() != 0) { System.out.println("Leg Slot: " + " [" + mleg.getObjNum() + "] " + mleg.getObjShortDesc() + " " + mleg.getObjGlows()); }
		if (mfoot.getObjNum() != 0) { System.out.println("Foot Slot: " + " [" + mfoot.getObjNum() + "] " + mfoot.getObjShortDesc() + " " + mfoot.getObjGlows()); }
		if (mtrinket1.getObjNum() != 0) { System.out.println("Trinket Slot: " + " [" + mtrinket1.getObjNum() + "] " + mtrinket1.getObjShortDesc() + " " + mtrinket1.getObjGlows()); }
		if (mtrinket2.getObjNum() != 0) { System.out.println("Trinket Slot: " + " [" + mtrinket2.getObjNum() + "] " + mtrinket2.getObjShortDesc() + " " + mtrinket2.getObjGlows()); }
		if (mweapon1.getObjNum() != 0) { System.out.println("Weapon Slot: " + " [" + mweapon1.getObjNum() + "] " + mweapon1.getObjShortDesc() + " " + mweapon1.getObjGlows()); }
		if (mweapshi.getObjNum() != 0) { System.out.println("Offhand Slot: " + " [" + mweapshi.getObjNum() + "] "  + mweapshi.getObjShortDesc() + " " + mweapshi.getObjGlows()); }

		mobInv();

	}// end lookMob()


	private static void playerCoins() {
		// displays the players current coins
		System.out.println("Output using playerCoins()");
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("Coins: " + playerinventory.getPmobplat() + "p, " + playerinventory.getPmobgold() + "g, " + playerinventory.getPmobsilver() + "s, " + playerinventory.getPmobcopper() + "c");
		System.out.println("---------------------------------------------------------------------------");

	} // end playerCoins()

	private static void mobInv() {
		//	System.out.println("---------------------------------------------------------------------------");
		System.out.println("Inventory Items -----------------------------------------------------------");
		// copy most of below code?
		// displays the mobs inventory
		switch (mSlot) {
		case "tmob0": {

			if (mob0inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m0inv0.getObjNum() + "] " + m0inv0.getObjShortDesc() + m0inv0.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m0inv1.getObjNum() + "] " + m0inv1.getObjShortDesc() + m0inv1.getObjGlows());	}
			else { }
			if (mob0inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m0inv2.getObjNum() + "] " + m0inv2.getObjShortDesc() + m0inv2.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m0inv3.getObjNum() + "] " + m0inv3.getObjShortDesc() + m0inv3.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m0inv4.getObjNum() + "] " + m0inv4.getObjShortDesc() + m0inv4.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m0inv5.getObjNum() + "] " + m0inv5.getObjShortDesc() + m0inv5.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m0inv6.getObjNum() + "] " + m0inv6.getObjShortDesc() + m0inv6.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m0inv7.getObjNum() + "] " + m0inv7.getObjShortDesc() + m0inv7.getObjGlows());	}
			else { }
			if (mob0inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m0inv8.getObjNum() + "] " + m0inv8.getObjShortDesc() + m0inv8.getObjGlows());	}
			else {  }
			if (mob0inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m0inv9.getObjNum() + "] " + m0inv9.getObjShortDesc() + m0inv9.getObjGlows());	}
			else {  }

			if (mob0inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m0inv5.getObjNum() + "] " + m0inv10.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m0inv5.getObjNum() + "] " + m0inv11.getObjShortDesc());	}
			else { }
			if (mob0inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m0inv5.getObjNum() + "] " + m0inv12.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m0inv5.getObjNum() + "] " + m0inv13.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m0inv5.getObjNum() + "] " + m0inv14.getObjShortDesc());	}
			else { }
			if (mob0inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m0inv5.getObjNum() + "] " + m0inv15.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m0inv5.getObjNum() + "] " + m0inv16.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m0inv5.getObjNum() + "] " + m0inv17.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m0inv5.getObjNum() + "] " + m0inv18.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m0inv5.getObjNum() + "] " + m0inv19.getObjShortDesc());	}
			else {  }

			if (mob0inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m0inv5.getObjNum() + "] " + m0inv20.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m0inv5.getObjNum() + "] " + m0inv21.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m0inv5.getObjNum() + "] " + m0inv22.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m0inv5.getObjNum() + "] " + m0inv23.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m0inv5.getObjNum() + "] " + m0inv24.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m0inv5.getObjNum() + "] " + m0inv25.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m0inv5.getObjNum() + "] " + m0inv26.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m0inv5.getObjNum() + "] " + m0inv27.getObjShortDesc());	}
			else { }
			if (mob0inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m0inv5.getObjNum() + "] " + m0inv28.getObjShortDesc());	}
			else {  }
			if (mob0inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m0inv5.getObjNum() + "] " + m0inv29.getObjShortDesc());	}
			else {  }
			break;
		}

		case "tmob1": {
			if (mob1inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m1inv0.getObjNum() + "] " + m1inv0.getObjShortDesc() + m1inv0.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m1inv1.getObjNum() + "] " + m1inv1.getObjShortDesc() + m1inv1.getObjGlows());	}
			else { }
			if (mob1inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m1inv2.getObjNum() + "] " + m1inv2.getObjShortDesc() + m1inv2.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m1inv3.getObjNum() + "] " + m1inv3.getObjShortDesc() + m1inv3.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m1inv4.getObjNum() + "] " + m1inv4.getObjShortDesc() + m1inv4.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m1inv5.getObjNum() + "] " + m1inv5.getObjShortDesc() + m1inv5.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m1inv6.getObjNum() + "] " + m1inv6.getObjShortDesc() + m1inv6.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m1inv7.getObjNum() + "] " + m1inv7.getObjShortDesc() + m1inv7.getObjGlows());	}
			else { }
			if (mob1inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m1inv8.getObjNum() + "] " + m1inv8.getObjShortDesc() + m1inv8.getObjGlows());	}
			else {  }
			if (mob1inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m1inv9.getObjNum() + "] " + m1inv9.getObjShortDesc() + m1inv9.getObjGlows());	}
			else {  }

			if (mob1inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m1inv5.getObjNum() + "] " + m1inv10.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m1inv5.getObjNum() + "] " + m1inv11.getObjShortDesc());	}
			else { }
			if (mob1inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m1inv5.getObjNum() + "] " + m1inv12.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m1inv5.getObjNum() + "] " + m1inv13.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m1inv5.getObjNum() + "] " + m1inv14.getObjShortDesc());	}
			else { }
			if (mob1inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m1inv5.getObjNum() + "] " + m1inv15.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m1inv5.getObjNum() + "] " + m1inv16.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m1inv5.getObjNum() + "] " + m1inv17.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m1inv5.getObjNum() + "] " + m1inv18.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m1inv5.getObjNum() + "] " + m1inv19.getObjShortDesc());	}
			else {  }

			if (mob1inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m1inv5.getObjNum() + "] " + m1inv20.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m1inv5.getObjNum() + "] " + m1inv21.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m1inv5.getObjNum() + "] " + m1inv22.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m1inv5.getObjNum() + "] " + m1inv23.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m1inv5.getObjNum() + "] " + m1inv24.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m1inv5.getObjNum() + "] " + m1inv25.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m1inv5.getObjNum() + "] " + m1inv26.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m1inv5.getObjNum() + "] " + m1inv27.getObjShortDesc());	}
			else { }
			if (mob1inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m1inv5.getObjNum() + "] " + m1inv28.getObjShortDesc());	}
			else {  }
			if (mob1inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m1inv5.getObjNum() + "] " + m1inv29.getObjShortDesc());	}
			else {  }
			break;
		}

		case "tmob2": {
			if (mob2inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m2inv0.getObjNum() + "] " + m2inv0.getObjShortDesc() + m2inv0.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m2inv1.getObjNum() + "] " + m2inv1.getObjShortDesc() + m2inv1.getObjGlows());	}
			else { }
			if (mob2inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m2inv2.getObjNum() + "] " + m2inv2.getObjShortDesc() + m2inv2.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m2inv3.getObjNum() + "] " + m2inv3.getObjShortDesc() + m2inv3.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m2inv4.getObjNum() + "] " + m2inv4.getObjShortDesc() + m2inv4.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m2inv5.getObjNum() + "] " + m2inv5.getObjShortDesc() + m2inv5.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m2inv6.getObjNum() + "] " + m2inv6.getObjShortDesc() + m2inv6.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m2inv7.getObjNum() + "] " + m2inv7.getObjShortDesc() + m2inv7.getObjGlows());	}
			else { }
			if (mob2inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m2inv8.getObjNum() + "] " + m2inv8.getObjShortDesc() + m2inv8.getObjGlows());	}
			else {  }
			if (mob2inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m2inv9.getObjNum() + "] " + m2inv9.getObjShortDesc() + m2inv9.getObjGlows());	}
			else {  }

			if (mob2inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m2inv5.getObjNum() + "] " + m2inv10.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m2inv5.getObjNum() + "] " + m2inv11.getObjShortDesc());	}
			else { }
			if (mob2inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m2inv5.getObjNum() + "] " + m2inv12.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m2inv5.getObjNum() + "] " + m2inv13.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m2inv5.getObjNum() + "] " + m2inv14.getObjShortDesc());	}
			else { }
			if (mob2inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m2inv5.getObjNum() + "] " + m2inv15.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m2inv5.getObjNum() + "] " + m2inv16.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m2inv5.getObjNum() + "] " + m2inv17.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m2inv5.getObjNum() + "] " + m2inv18.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m2inv5.getObjNum() + "] " + m2inv19.getObjShortDesc());	}
			else {  }

			if (mob2inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m2inv5.getObjNum() + "] " + m2inv20.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m2inv5.getObjNum() + "] " + m2inv21.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m2inv5.getObjNum() + "] " + m2inv22.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m2inv5.getObjNum() + "] " + m2inv23.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m2inv5.getObjNum() + "] " + m2inv24.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m2inv5.getObjNum() + "] " + m2inv25.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m2inv5.getObjNum() + "] " + m2inv26.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m2inv5.getObjNum() + "] " + m2inv27.getObjShortDesc());	}
			else { }
			if (mob2inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m2inv5.getObjNum() + "] " + m2inv28.getObjShortDesc());	}
			else {  }
			if (mob2inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m2inv5.getObjNum() + "] " + m2inv29.getObjShortDesc());	}
			else {  }
			break;
		}

		case "tmob3": {
			if (mob3inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m3inv0.getObjNum() + "] " + m3inv0.getObjShortDesc() + m3inv0.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m3inv1.getObjNum() + "] " + m3inv1.getObjShortDesc() + m3inv1.getObjGlows());	}
			else { }
			if (mob3inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m3inv2.getObjNum() + "] " + m3inv2.getObjShortDesc() + m3inv2.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m3inv3.getObjNum() + "] " + m3inv3.getObjShortDesc() + m3inv3.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m3inv4.getObjNum() + "] " + m3inv4.getObjShortDesc() + m3inv4.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m3inv5.getObjNum() + "] " + m3inv5.getObjShortDesc() + m3inv5.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m3inv6.getObjNum() + "] " + m3inv6.getObjShortDesc() + m3inv6.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m3inv7.getObjNum() + "] " + m3inv7.getObjShortDesc() + m3inv7.getObjGlows());	}
			else { }
			if (mob3inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m3inv8.getObjNum() + "] " + m3inv8.getObjShortDesc() + m3inv8.getObjGlows());	}
			else {  }
			if (mob3inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m3inv9.getObjNum() + "] " + m3inv9.getObjShortDesc() + m3inv9.getObjGlows());	}
			else {  }

			if (mob3inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m3inv5.getObjNum() + "] " + m3inv10.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m3inv5.getObjNum() + "] " + m3inv11.getObjShortDesc());	}
			else { }
			if (mob3inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m3inv5.getObjNum() + "] " + m3inv12.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m3inv5.getObjNum() + "] " + m3inv13.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m3inv5.getObjNum() + "] " + m3inv14.getObjShortDesc());	}
			else { }
			if (mob3inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m3inv5.getObjNum() + "] " + m3inv15.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m3inv5.getObjNum() + "] " + m3inv16.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m3inv5.getObjNum() + "] " + m3inv17.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m3inv5.getObjNum() + "] " + m3inv18.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m3inv5.getObjNum() + "] " + m3inv19.getObjShortDesc());	}
			else {  }

			if (mob3inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m3inv5.getObjNum() + "] " + m3inv20.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m3inv5.getObjNum() + "] " + m3inv21.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m3inv5.getObjNum() + "] " + m3inv22.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m3inv5.getObjNum() + "] " + m3inv23.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m3inv5.getObjNum() + "] " + m3inv24.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m3inv5.getObjNum() + "] " + m3inv25.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m3inv5.getObjNum() + "] " + m3inv26.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m3inv5.getObjNum() + "] " + m3inv27.getObjShortDesc());	}
			else { }
			if (mob3inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m3inv5.getObjNum() + "] " + m3inv28.getObjShortDesc());	}
			else {  }
			if (mob3inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m3inv5.getObjNum() + "] " + m3inv29.getObjShortDesc());	}
			else {  }
			break;
		}

		case "tmob4": {
			if (mob4inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m4inv0.getObjNum() + "] " + m4inv0.getObjShortDesc() + m4inv0.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m4inv1.getObjNum() + "] " + m4inv1.getObjShortDesc() + m4inv1.getObjGlows());	}
			else { }
			if (mob4inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m4inv2.getObjNum() + "] " + m4inv2.getObjShortDesc() + m4inv2.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m4inv3.getObjNum() + "] " + m4inv3.getObjShortDesc() + m4inv3.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m4inv4.getObjNum() + "] " + m4inv4.getObjShortDesc() + m4inv4.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m4inv5.getObjNum() + "] " + m4inv5.getObjShortDesc() + m4inv5.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m4inv6.getObjNum() + "] " + m4inv6.getObjShortDesc() + m4inv6.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m4inv7.getObjNum() + "] " + m4inv7.getObjShortDesc() + m4inv7.getObjGlows());	}
			else { }
			if (mob4inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m4inv8.getObjNum() + "] " + m4inv8.getObjShortDesc() + m4inv8.getObjGlows());	}
			else {  }
			if (mob4inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m4inv9.getObjNum() + "] " + m4inv9.getObjShortDesc() + m4inv9.getObjGlows());	}
			else {  }

			if (mob4inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m4inv5.getObjNum() + "] " + m4inv10.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m4inv5.getObjNum() + "] " + m4inv11.getObjShortDesc());	}
			else { }
			if (mob4inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m4inv5.getObjNum() + "] " + m4inv12.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m4inv5.getObjNum() + "] " + m4inv13.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m4inv5.getObjNum() + "] " + m4inv14.getObjShortDesc());	}
			else { }
			if (mob4inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m4inv5.getObjNum() + "] " + m4inv15.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m4inv5.getObjNum() + "] " + m4inv16.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m4inv5.getObjNum() + "] " + m4inv17.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m4inv5.getObjNum() + "] " + m4inv18.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m4inv5.getObjNum() + "] " + m4inv19.getObjShortDesc());	}
			else {  }

			if (mob4inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m4inv5.getObjNum() + "] " + m4inv20.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m4inv5.getObjNum() + "] " + m4inv21.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m4inv5.getObjNum() + "] " + m4inv22.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m4inv5.getObjNum() + "] " + m4inv23.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m4inv5.getObjNum() + "] " + m4inv24.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m4inv5.getObjNum() + "] " + m4inv25.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m4inv5.getObjNum() + "] " + m4inv26.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m4inv5.getObjNum() + "] " + m4inv27.getObjShortDesc());	}
			else { }
			if (mob4inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m4inv5.getObjNum() + "] " + m4inv28.getObjShortDesc());	}
			else {  }
			if (mob4inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m4inv5.getObjNum() + "] " + m4inv29.getObjShortDesc());	}
			else {  }
			break;
		}

		case "tmob5": {
			if (mob5inventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + m5inv0.getObjNum() + "] " + m5inv0.getObjShortDesc() + m5inv0.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + m5inv1.getObjNum() + "] " + m5inv1.getObjShortDesc() + m5inv1.getObjGlows());	}
			else { }
			if (mob5inventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + m5inv2.getObjNum() + "] " + m5inv2.getObjShortDesc() + m5inv2.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + m5inv3.getObjNum() + "] " + m5inv3.getObjShortDesc() + m5inv3.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + m5inv4.getObjNum() + "] " + m5inv4.getObjShortDesc() + m5inv4.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + m5inv5.getObjNum() + "] " + m5inv5.getObjShortDesc() + m5inv5.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + m5inv6.getObjNum() + "] " + m5inv6.getObjShortDesc() + m5inv6.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + m5inv7.getObjNum() + "] " + m5inv7.getObjShortDesc() + m5inv7.getObjGlows());	}
			else { }
			if (mob5inventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + m5inv8.getObjNum() + "] " + m5inv8.getObjShortDesc() + m5inv8.getObjGlows());	}
			else {  }
			if (mob5inventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + m5inv9.getObjNum() + "] " + m5inv9.getObjShortDesc() + m5inv9.getObjGlows());	}
			else {  }

			if (mob5inventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + m5inv5.getObjNum() + "] " + m5inv10.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + m5inv5.getObjNum() + "] " + m5inv11.getObjShortDesc());	}
			else { }
			if (mob5inventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + m5inv5.getObjNum() + "] " + m5inv12.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + m5inv5.getObjNum() + "] " + m5inv13.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + m5inv5.getObjNum() + "] " + m5inv14.getObjShortDesc());	}
			else { }
			if (mob5inventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + m5inv5.getObjNum() + "] " + m5inv15.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + m5inv5.getObjNum() + "] " + m5inv16.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + m5inv5.getObjNum() + "] " + m5inv17.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + m5inv5.getObjNum() + "] " + m5inv18.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + m5inv5.getObjNum() + "] " + m5inv19.getObjShortDesc());	}
			else {  }

			if (mob5inventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + m5inv5.getObjNum() + "] " + m5inv20.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + m5inv5.getObjNum() + "] " + m5inv21.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + m5inv5.getObjNum() + "] " + m5inv22.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + m5inv5.getObjNum() + "] " + m5inv23.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + m5inv5.getObjNum() + "] " + m5inv24.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + m5inv5.getObjNum() + "] " + m5inv25.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + m5inv5.getObjNum() + "] " + m5inv26.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + m5inv5.getObjNum() + "] " + m5inv27.getObjShortDesc());	}
			else { }
			if (mob5inventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + m5inv5.getObjNum() + "] " + m5inv28.getObjShortDesc());	}
			else {  }
			if (mob5inventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + m5inv5.getObjNum() + "] " + m5inv29.getObjShortDesc());	}
			else {  }
			break;
		}
		default: { }
		} // end switch

		//	System.out.println("need to add inventory, not just equipped items");
	}// end mobInv()

	private static void playerInv() {
		// displays the player current inventory
		System.out.println("Output using playerInv()");
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("Coins: " + playerinventory.getPmobplat() + "p, " + playerinventory.getPmobgold() + "g, " + playerinventory.getPmobsilver() + "s, " + playerinventory.getPmobcopper() + "c");
		System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
				"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
				playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("Inventory Items -----------------------------------------------------------");
		if (playerinventory.getPmobInv0() != 0) { System.out.println("Inv Slot 0: [" + pinv0.getObjNum() + "] " + pinv0.getObjShortDesc() + pinv0.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv1() != 0) { System.out.println("Inv Slot 1: [" + pinv1.getObjNum() + "] " + pinv1.getObjShortDesc() + pinv1.getObjGlows());	}
		else { }
		if (playerinventory.getPmobInv2() != 0) { System.out.println("Inv Slot 2: [" + pinv2.getObjNum() + "] " + pinv2.getObjShortDesc() + pinv2.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv3() != 0) { System.out.println("Inv Slot 3: [" + pinv3.getObjNum() + "] " + pinv3.getObjShortDesc() + pinv3.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv4() != 0) { System.out.println("Inv Slot 4: [" + pinv4.getObjNum() + "] " + pinv4.getObjShortDesc() + pinv4.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv5() != 0) { System.out.println("Inv Slot 5: [" + pinv5.getObjNum() + "] " + pinv5.getObjShortDesc() + pinv5.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv6() != 0) { System.out.println("Inv Slot 6: [" + pinv6.getObjNum() + "] " + pinv6.getObjShortDesc() + pinv6.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv7() != 0) { System.out.println("Inv Slot 7: [" + pinv7.getObjNum() + "] " + pinv7.getObjShortDesc() + pinv7.getObjGlows());	}
		else { }
		if (playerinventory.getPmobInv8() != 0) { System.out.println("Inv Slot 8: [" + pinv8.getObjNum() + "] " + pinv8.getObjShortDesc() + pinv8.getObjGlows());	}
		else {  }
		if (playerinventory.getPmobInv9() != 0) { System.out.println("Inv Slot 9: [" + pinv9.getObjNum() + "] " + pinv9.getObjShortDesc() + pinv9.getObjGlows());	}
		else {  }

		if (playerinventory.getPmobInv10() != 0) { System.out.println("Inv Slot 10: [" + pinv10.getObjNum() + "] " + pinv10.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv11() != 0) { System.out.println("Inv Slot 11: [" + pinv11.getObjNum() + "] " + pinv11.getObjShortDesc());	}
		else { }
		if (playerinventory.getPmobInv12() != 0) { System.out.println("Inv Slot 12: [" + pinv12.getObjNum() + "] " + pinv12.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv13() != 0) { System.out.println("Inv Slot 13: [" + pinv13.getObjNum() + "] " + pinv13.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv14() != 0) { System.out.println("Inv Slot 14: [" + pinv14.getObjNum() + "] " + pinv14.getObjShortDesc());	}
		else { }
		if (playerinventory.getPmobInv15() != 0) { System.out.println("Inv Slot 15: [" + pinv15.getObjNum() + "] " + pinv15.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv16() != 0) { System.out.println("Inv Slot 16: [" + pinv16.getObjNum() + "] " + pinv16.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv17() != 0) { System.out.println("Inv Slot 17: [" + pinv17.getObjNum() + "] " + pinv17.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv18() != 0) { System.out.println("Inv Slot 18: [" + pinv18.getObjNum() + "] " + pinv18.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv19() != 0) { System.out.println("Inv Slot 19: [" + pinv19.getObjNum() + "] " + pinv19.getObjShortDesc());	}
		else {  }

		if (playerinventory.getPmobInv20() != 0) { System.out.println("Inv Slot 20: [" + pinv20.getObjNum() + "] " + pinv20.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv21() != 0) { System.out.println("Inv Slot 21: [" + pinv21.getObjNum() + "] " + pinv21.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv22() != 0) { System.out.println("Inv Slot 22: [" + pinv22.getObjNum() + "] " + pinv22.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv23() != 0) { System.out.println("Inv Slot 23: [" + pinv23.getObjNum() + "] " + pinv23.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv24() != 0) { System.out.println("Inv Slot 24: [" + pinv24.getObjNum() + "] " + pinv24.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv25() != 0) { System.out.println("Inv Slot 25: [" + pinv25.getObjNum() + "] " + pinv25.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv26() != 0) { System.out.println("Inv Slot 26: [" + pinv26.getObjNum() + "] " + pinv26.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv27() != 0) { System.out.println("Inv Slot 27: [" + pinv27.getObjNum() + "] " + pinv27.getObjShortDesc());	}
		else { }
		if (playerinventory.getPmobInv28() != 0) { System.out.println("Inv Slot 28: [" + pinv28.getObjNum() + "] " + pinv28.getObjShortDesc());	}
		else {  }
		if (playerinventory.getPmobInv29() != 0) { System.out.println("Inv Slot 29: [" + pinv29.getObjNum() + "] " + pinv29.getObjShortDesc());	}
		else {  }

	}// end playerInv()


	private static void playerEQ() {
		// displays the current player equipment



		System.out.println("Output using playerEQ()");
		System.out.println("Equiped Items -----------------------------------------------------------");
		if (phelm.getObjNum() != 0) { System.out.println("Head Slot: [" + phelm.getObjNum() + "] " + phelm.getObjShortDesc() + " " + phelm.getObjGlows());	}
		else { System.out.println("Head Slot: [" + phelm.getObjNum() + "] none" ); }
		if (pneck.getObjNum() != 0) { System.out.println("Neck Slot [: "+ pneck.getObjNum() + "] " + pneck.getObjShortDesc() + " " + pneck.getObjGlows()); }
		else { System.out.println("Neck Slot: ["+ pneck.getObjNum() + "] none"  ); }
		if (pshoulders.getObjNum() != 0) { System.out.println("Shoulder Slot: ["+ pshoulders.getObjNum() + "] " + pshoulders.getObjShortDesc() + " " + pshoulders.getObjGlows()); }
		else { System.out.println("Shoulder Slot: ["+ pshoulders.getObjNum() + "] none" ); }
		if (pchest.getObjNum() != 0) { System.out.println("Chest Slot: ["+ pchest.getObjNum() + "] "  + pchest.getObjShortDesc() + " " + pchest.getObjGlows()); }
		else { System.out.println("Chest Slot: ["+ pchest.getObjNum() + "] none" ); }
		if (pwrist.getObjNum() != 0) { System.out.println("Wrist Slot: ["+ pwrist.getObjNum() + "] " + pwrist.getObjShortDesc() + " " + pwrist.getObjGlows()); }
		else { System.out.println("Wrist Slot: ["+ pwrist.getObjNum() + "] none" ); }
		if (phands.getObjNum() != 0) { System.out.println("Hand Slot: ["+ phands.getObjNum() + "] " + phands.getObjShortDesc() + " " + phands.getObjGlows()); }
		else { System.out.println("Hand Slot: ["+ phands.getObjNum() + "] none" ); }
		if (pfinger1.getObjNum() != 0) { System.out.println("Finger1 Slot: ["+ pfinger1.getObjNum() + "] " + pfinger1.getObjShortDesc() + " " + pfinger1.getObjGlows()); }
		else { System.out.println("Finger1 Slot: ["+ pfinger1.getObjNum() + "] none" ); }
		if (pfinger2.getObjNum() != 0) { System.out.println("Finger2 Slot: ["+ pfinger2.getObjNum() + "] " + pfinger2.getObjShortDesc() + " " + pfinger2.getObjGlows()); }
		else { System.out.println("Finger2 Slot: ["+ pfinger2.getObjNum() + "] none" ); }
		if (pwaist.getObjNum() != 0) { System.out.println("Waist Slot:[ "+ pwaist.getObjNum() + "] " + pwaist.getObjShortDesc() + " " + pwaist.getObjGlows()); }
		else { System.out.println("Waist Slot: ["+ pwaist.getObjNum() + "] none" ); }
		if (pleg.getObjNum() != 0) { System.out.println("Leg Slot: [" + pleg.getObjNum() + "]" + pleg.getObjShortDesc() + " " + pleg.getObjGlows()); }
		else { System.out.println("Leg Slot: ["+ pleg.getObjNum() + "] none" ); }
		if (pfoot.getObjNum() != 0) { System.out.println("Foot Slot: ["+ pfoot.getObjNum() + "] " + pfoot.getObjShortDesc() + " " + pfoot.getObjGlows()); }
		else { System.out.println("Foot Slot: ["+ pfoot.getObjNum() + "] none" ); }
		if (ptrinket1.getObjNum() != 0) { System.out.println("Trinket1 Slot: ["+ ptrinket1.getObjNum() + "] " + ptrinket1.getObjShortDesc() + " " + ptrinket1.getObjGlows()); }
		else { System.out.println("Trinket1 Slot: ["+ ptrinket1.getObjNum() + "] none" ); }
		if (ptrinket2.getObjNum() != 0) { System.out.println("Trinket2 Slot: ["+ ptrinket2.getObjNum() + "] " + ptrinket2.getObjShortDesc() + " " + ptrinket2.getObjGlows()); }
		else { System.out.println("Trinket2 Slot: ["+ ptrinket2.getObjNum() + "] none" ); }
		if (pweapon1.getObjNum() != 0) { System.out.println("Weapon Slot: " + pweapon1.getObjNum() + "] " + pweapon1.getObjShortDesc() + " " + pweapon1.getObjGlows()); }
		else { System.out.println("Weapon Slot: ["+ pweapon1.getObjNum() + "] none" ); }
		if (pweapshi.getObjNum() != 0) { System.out.println("Offhand Slot: [" + pweapshi.getObjNum() + "] " + pweapshi.getObjShortDesc() + " " + pweapshi.getObjGlows()); }
		else { System.out.println("Offhand Slot: [" + pweapshi.getObjNum() + "] none" ); }

	} // end playerEQ()


	private static void playerScore() {
		// outputs the player score and equipment
		System.out.println("output from playerScore()");
		System.out.println("Player Name: " + player1.getPlayerName());
		System.out.println("Description: " + player1.getPlayerLongDesc());
		//		System.out.println("Keywords1: " + player1.getPlayerKeyWords().toString()); // this is garble (the actual array PlayerKeyWords)
		//		System.out.println("Keywords2: " + Arrays.toString(player1.getPlayerKeyWords())); // this is correctly outputing the keywords array
		String pkeywords = Arrays.toString(player1.getPlayerKeyWords());
		System.out.println("Keywords: " + pkeywords);
		System.out.println("Keyword1: [" + player1.getKeyWord(0).strip() + "]  Keyword2: [" + player1.getKeyWord(1).strip() + "]  Keyword3: [" + player1.getKeyWord(2).strip() + "]");
		System.out.println("Class: [" + player1.getPlayerClass() + "]");
		System.out.println("Race: [" + player1.getPlayerRace() + "]  Subrace: [" + player1.getPlayerSubRace() + "]  Level: [" + player1.getPlayerLvl() + "]   Tier: [" + player1.getPlayerTier() + "]");
		int xptoGain = 0;
		if (player1.getPlayerLvl() == 1) { xptoGain = xplvl2; }
		if (player1.getPlayerLvl() == 2) { xptoGain = xplvl3; }
		if (player1.getPlayerLvl() == 3) { xptoGain = xplvl4; }
		if (player1.getPlayerLvl() == 4) { xptoGain = xplvl5; }
		if (player1.getPlayerLvl() == 5) { xptoGain = xplvl6; }
		if (player1.getPlayerLvl() == 6) { xptoGain = xplvl7; }
		if (player1.getPlayerLvl() == 7) { xptoGain = xplvl8; }
		if (player1.getPlayerLvl() == 8) { xptoGain = xplvl9; }
		if (player1.getPlayerLvl() == 9) { xptoGain = xplvl10; }
		if (player1.getPlayerLvl() == 10) { xptoGain = xplvl11; }
		if (player1.getPlayerLvl() == 11) { xptoGain = xplvl12; }
		if (player1.getPlayerLvl() == 12) { xptoGain = xplvl13; }
		if (player1.getPlayerLvl() == 13) { xptoGain = xplvl14; }
		if (player1.getPlayerLvl() == 14) { xptoGain = xplvl15; }
		if (player1.getPlayerLvl() == 15) { xptoGain = xplvl16; }
		if (player1.getPlayerLvl() == 16) { xptoGain = xplvl17; }
		if (player1.getPlayerLvl() == 17) { xptoGain = xplvl18; }
		if (player1.getPlayerLvl() == 18) { xptoGain = xplvl19; }
		if (player1.getPlayerLvl() == 19) { xptoGain = xplvl20; }
		if (player1.getPlayerLvl() == 20) { xptoGain = xplvl21; }
		if (player1.getPlayerLvl() == 21) { xptoGain = xplvl22; }
		if (player1.getPlayerLvl() == 22) { xptoGain = xplvl23; }
		if (player1.getPlayerLvl() == 23) { xptoGain = xplvl24; }
		if (player1.getPlayerLvl() == 24) { xptoGain = xplvl25; }
		if (player1.getPlayerLvl() == 25) { xptoGain = xplvl26; }
		if (player1.getPlayerLvl() == 26) { xptoGain = xplvl27; }
		if (player1.getPlayerLvl() == 27) { xptoGain = xplvl28; }
		if (player1.getPlayerLvl() == 28) { xptoGain = xplvl29; }
		if (player1.getPlayerLvl() == 29) { xptoGain = xplvl30; }
		if (player1.getPlayerLvl() == 30) { xptoGain = xplvl31; }

		System.out.println("XP: [" + player1.getPlayerXP() + "/" + xptoGain + "]");

		System.out.println("Stamina: " + player1.getStam() + "  Strength: " + player1.getStr() + "   Intelligence: " + player1. getIntel() + "   Agility: " + player1.getAgility());
		int stambuff = 0 + phelm.getAddStam() + pneck.getAddStam() + pshoulders.getAddStam() + pchest.getAddStam() + pwrist.getAddStam()
		+ phands.getAddStam() + pfinger1.getAddStam() + pfinger2.getAddStam() + pwaist.getAddStam() + pleg.getAddStam()
		+ pfoot.getAddStam() + ptrinket1.getAddStam() + ptrinket2.getAddStam() + pweapon1.getAddStam() + pweapshi.getAddStam();
		System.out.println("Stamina Base + Gear: " + player1.getStam() + " + " + stambuff);
		//	player1.setStam(player1.getStam() + stambuff);

		int strbuff = 0 + phelm.getAddStr() + pneck.getAddStr() + pshoulders.getAddStr() + pchest.getAddStr() + pwrist.getAddStr()
		+ phands.getAddStr() + pfinger1.getAddStr() + pfinger2.getAddStr() + pwaist.getAddStr() + pleg.getAddStr()
		+ pfoot.getAddStr() + ptrinket1.getAddStr() + ptrinket2.getAddStr() + pweapon1.getAddStr() + pweapshi.getAddStr();
		System.out.println("Strength Base + Gear: " + player1.getStr() + " + " + strbuff);

		int intbuff = 0 + phelm.getAddInt() + pneck.getAddInt() + pshoulders.getAddInt() + pchest.getAddInt() + pwrist.getAddInt()
		+ phands.getAddInt() + pfinger1.getAddInt() + pfinger2.getAddInt() + pwaist.getAddInt() + pleg.getAddInt()
		+ pfoot.getAddInt() + ptrinket1.getAddInt() + ptrinket2.getAddInt() + pweapon1.getAddInt() + pweapshi.getAddInt();
		System.out.println("Intelligence Base + Gear: " + player1.getIntel() + " + " + intbuff);

		int agibuff = 0 + phelm.getAddAgi() + pneck.getAddAgi() + pshoulders.getAddAgi() + pchest.getAddAgi() + pwrist.getAddAgi()
		+ phands.getAddAgi() + pfinger1.getAddAgi() + pfinger2.getAddAgi() + pwaist.getAddAgi() + pleg.getAddAgi()
		+ pfoot.getAddAgi() + ptrinket1.getAddAgi() + ptrinket2.getAddAgi() + pweapon1.getAddAgi() + pweapshi.getAddAgi();
		System.out.println("Agility Base + Gear: " + player1.getAgility() + " + " + agibuff);

		int hpbuff = 0 + phelm.getAddHP() + pneck.getAddHP() + pshoulders.getAddHP() + pchest.getAddHP() + pwrist.getAddHP()
		+ phands.getAddHP() + pfinger1.getAddHP() + pfinger2.getAddHP() + pwaist.getAddHP() + pleg.getAddHP()
		+ pfoot.getAddHP() + ptrinket1.getAddHP() + ptrinket2.getAddHP() + pweapon1.getAddHP() + pweapshi.getAddHP();

		int mpbuff = 0 + phelm.getAddMP() + pneck.getAddMP() + pshoulders.getAddMP() + pchest.getAddMP() + pwrist.getAddMP()
		+ phands.getAddMP() + pfinger1.getAddMP() + pfinger2.getAddMP() + pwaist.getAddMP() + pleg.getAddMP()
		+ pfoot.getAddMP() + ptrinket1.getAddMP() + ptrinket2.getAddMP() + pweapon1.getAddMP() + pweapshi.getAddMP();

		player1.setPlayerMaxHP(((player1.getStam() + stambuff)*10) + hpbuff);
		player1.setPlayerMaxMP(((player1.getIntel() + intbuff)*10) + mpbuff);

		checkPlayerMaxHP();
		checkPlayerMaxMP();
		System.out.println("HPs: [" + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + "]   MPs: [" + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() +"]");
		//	System.out.println("You have " + curruncty[0] + " platinum coins, " + curruncty[1] + " gold coins, " + curruncty[2] + " silver, and " + curruncty[3] + " copper coins.");
		playerEQ();  // replaced below code

		/*
		System.out.println("Equiped Items -----------------------------------------------------------");
		System.out.println("Head Slot: " + phelm.getObjShortDesc());
		System.out.println("Neck Slot: " + pneck.getObjShortDesc());
		System.out.println("Shoulder Slot: " + pshoulders.getObjShortDesc());
	//	System.out.println("Chest Slot1: " + getChestSlot());
		System.out.println("Chest Slot: "  + pchest.getObjShortDesc());
		System.out.println("Wrist Slot: " + pwrist.getObjShortDesc());
		System.out.println("Hand Slot: " + phands.getObjShortDesc());
		System.out.println("Finger Slot: " + pfinger1.getObjShortDesc());
		System.out.println("Finger Slot: " + pfinger2.getObjShortDesc());
		System.out.println("Waist Slot: " + pwaist.getObjShortDesc());
		System.out.println("Leg Slot: " + pleg.getObjShortDesc());
		System.out.println("Foot Slot: " + pfoot.getObjShortDesc());
		System.out.println("Trinket Slot: " + ptrinket1.getObjShortDesc());
		System.out.println("Trinket Slot: " + ptrinket2.getObjShortDesc());
		System.out.println("Weapon Slot: " + pweapon1.getObjShortDesc());
		System.out.println("Offhand Slot: " + pweapshi.getObjShortDesc());
		 */

	} // end playerScore()


	private static void checkPlayerMaxMP() {
		// recalculates and sets player Max MP
		int intbuff = phelm.getAddInt() + pneck.getAddInt() + pshoulders.getAddInt() + pchest.getAddInt() + pwrist.getAddInt() + phands.getAddInt()
		+ pfinger1.getAddInt() + pfinger2.getAddInt() + pwaist.getAddInt() + pleg.getAddInt() + pfoot.getAddInt() + ptrinket1.getAddInt()
		+ ptrinket2.getAddInt() + pweapon1.getAddInt() + pweapshi.getAddInt();

		int mpbuff = phelm.getAddMP() + pneck.getAddMP() + pshoulders.getAddMP() + pchest.getAddMP() + pwrist.getAddMP() + phands.getAddMP()
		+ pfinger1.getAddMP() + pfinger2.getAddMP() + pwaist.getAddMP() + pleg.getAddMP() + pfoot.getAddMP() + ptrinket1.getAddMP()
		+ ptrinket2.getAddMP() + pweapon1.getAddMP() + pweapshi.getAddMP();

		int playerMaxMP = ((player1.getIntel() + intbuff)*10) + mpbuff + (50*player1.getPlayerLvl());

		player1.setPlayerMaxMP(playerMaxMP);
	}


	private static void checkPlayerMaxHP() {
		// recalculates and sets player Max HP
		int stambuff = 0 + phelm.getAddStam() + pneck.getAddStam() + pshoulders.getAddStam() + pchest.getAddStam() + pwrist.getAddStam() + phands.getAddStam()
		+ pfinger1.getAddStam() + pfinger2.getAddStam() + pwaist.getAddStam() + pleg.getAddStam() + pfoot.getAddStam() + ptrinket1.getAddStam()
		+ ptrinket2.getAddStam() + pweapon1.getAddStam() + pweapshi.getAddStam();

		int hpbuff = 0 + phelm.getAddHP() + pneck.getAddHP() + pshoulders.getAddHP() + pchest.getAddHP() + pwrist.getAddHP() + phands.getAddHP()
		+ pfinger1.getAddHP() + pfinger2.getAddHP() + pwaist.getAddHP() + pleg.getAddHP() + pfoot.getAddHP() + ptrinket1.getAddHP()
		+ ptrinket2.getAddHP() + pweapon1.getAddHP() + pweapshi.getAddHP();

		int playerMaxHP = ((player1.getStam() + stambuff)*10) + hpbuff + (50*player1.getPlayerLvl());

		player1.setPlayerMaxHP(playerMaxHP);
	}

	private static void checkMobMaxHP(mob m) {
		int stambuff = 0 + mhelm.getAddStam() + mneck.getAddStam() + mshoulders.getAddStam() + mchest.getAddStam() + mwrist.getAddStam() + mhands.getAddStam()
		+ mfinger1.getAddStam() + mfinger2.getAddStam() + mwaist.getAddStam() + mleg.getAddStam() + mfoot.getAddStam() + mtrinket1.getAddStam()
		+ mtrinket2.getAddStam() + mweapon1.getAddStam() + mweapshi.getAddStam();

		int hpbuff = 0 + mhelm.getAddHP() + mneck.getAddHP() + mshoulders.getAddHP() + mchest.getAddHP() + mwrist.getAddHP() + mhands.getAddHP()
		+ mfinger1.getAddHP() + mfinger2.getAddHP() + mwaist.getAddHP() + mleg.getAddHP() + mfoot.getAddHP() + mtrinket1.getAddHP()
		+ mtrinket2.getAddHP() + mweapon1.getAddHP() + mweapshi.getAddHP();

		int mobMaxHP = ((m.getStam() + stambuff)*10) + hpbuff + (50*m.getMobLvl());

		m.setMaxHP(mobMaxHP);
	}

	private static void checkMobMaxMP(mob m) {
		int intbuff = 0 + mhelm.getAddInt() + mneck.getAddInt() + mshoulders.getAddInt() + mchest.getAddInt() + mwrist.getAddInt() + mhands.getAddInt()
		+ mfinger1.getAddInt() + mfinger2.getAddInt() + mwaist.getAddInt() + mleg.getAddInt() + mfoot.getAddInt() + mtrinket1.getAddInt()
		+ mtrinket2.getAddInt() + mweapon1.getAddInt() + mweapshi.getAddInt();

		int mpbuff = 0 + mhelm.getAddMP() + mneck.getAddMP() + mshoulders.getAddMP() + mchest.getAddMP() + mwrist.getAddMP() + mhands.getAddMP()
		+ mfinger1.getAddMP() + mfinger2.getAddMP() + mwaist.getAddMP() + mleg.getAddMP() + mfoot.getAddMP() + mtrinket1.getAddMP()
		+ mtrinket2.getAddMP() + mweapon1.getAddMP() + mweapshi.getAddMP();

		int mobMaxMP = ((m.getIntel() + intbuff)*10) + mpbuff + (50*m.getMobLvl());

		m.setMaxMP(mobMaxMP);
	}

	private static void loadMob(mob m, int i) {
		// loads the mob
		m.setMobNum(i);
		//	m.setMobNum(i); //0
		m.setMobName(Mobs[i][1]); //1
		m.setMobShortDesc(Mobs[i][2]); //2
		m.setMobLongDesc(Mobs[i][3]); //3
		String[] mkw = Mobs[i][4].toString().split("//s+");
		m.setMobKeyWords(mkw);  //4
		if (m.getMobNum() != 0) { m.setMobHP(Integer.parseInt(Mobs[i][5])); }	{ } //m.setMobHP(100); } // mob hp
		if (m.getMobNum() != 0) { m.setMobMP(Integer.parseInt(Mobs[i][6])); } { } // m.setMobMP(100); } // mob mp
		if (m.getMobNum() != 0) { m.setMobLvl(Integer.parseInt(Mobs[i][7])); } { } //m.setMobLvl(1); }  // mob level
		if (m.getMobNum() != 0) { m.setStam(Integer.parseInt(Mobs[i][8])); } { } // m.setStam(10); }  // mob stam
		if (m.getMobNum() != 0) { m.setStr(Integer.parseInt(Mobs[i][9])); } { } // m.setStr(10); } // mob str
		if (m.getMobNum() != 0) { m.setIntel(Integer.parseInt(Mobs[i][10])); } { } // m.setIntel(10); } // mob int
		if (m.getMobNum() != 0) { m.setAgility(Integer.parseInt(Mobs[i][11])); } { } // m.setAgility(10); } // mob agi
		m.setHeadSlot(Mobs[i][12]); // head slot
		m.setNeckSlot(Mobs[i][13]);  // neck slot
		m.setShoulderSlot(Mobs[i][14]); // hands slot
		m.setChestSlot(Mobs[i][15]); // chest
		m.setWristSlot(Mobs[i][16]); // wrist
		m.setHandSlot(Mobs[i][17]); // hand
		m.setFinger1(Mobs[i][18]); // finger 1
		m.setFinger2(Mobs[i][19]); // finger 2
		m.setWaistSlot(Mobs[i][20]); // waist
		m.setLegSlot(Mobs[i][21]); // leg
		m.setFootSlot(Mobs[i][22]); // foot
		m.setTrinket1Slot(Mobs[i][23]); // trinket 1
		m.setTrinket2Slot(Mobs[i][24]); // trinket 2
		m.setWeapon1Slot(Mobs[i][25]); // weapon
		m.setWeaponShieldSlot(Mobs[i][26]); // weapon/shield
		m.setMobRace(Mobs[i][27]); // race
		m.setmobSubRace(Mobs[i][28]); // subrace
		m.setmobRank(Mobs[i][29]); // rank
		m.setMobXPVal(Integer.parseInt(Mobs[i][30])); // xp val
		m.setmobIsAlive(Integer.parseInt(Mobs[i][31]));
		m.setMobGender(Mobs[i][32]); // mob gender
		m.setMobClass(Mobs[i][33]); // mob class

		m.setAttackable(Integer.parseInt(Mobs[i][34]));
		m.setWanders(Integer.parseInt(Mobs[i][35]));
		m.setV36(Mobs[i][36]);
		m.setV37(Mobs[i][37]);
		m.setV38(Mobs[i][38]);
		m.setV39(Mobs[i][39]);
		m.setV40(Mobs[i][40]);
		m.setV41(Mobs[i][41]);
		m.setV42(Mobs[i][42]);
		m.setV43(Mobs[i][43]);
		m.setV44(Mobs[i][44]);
		m.setV45(Mobs[i][45]);
		m.setV46(Integer.parseInt(Mobs[i][46]));
		m.setV47(Mobs[i][47]);
		m.setV48(Mobs[i][48]);
		m.setV49(Mobs[i][49]);


		int hlmNum = Integer.parseInt(m.getHeadSlot());
		mhelm.resetObject();
		mhelm.setObjNum(hlmNum);
		loadObject(mhelm,mhelm.getObjNum());

		int necNum = Integer.parseInt(m.getNeckSlot());
		mneck.resetObject();
		mneck.setObjNum(necNum);
		loadObject(mneck,mneck.getObjNum());

		int shldNum = Integer.parseInt(m.getShoulderSlot());
		mshoulders.resetObject();
		mshoulders.setObjNum(shldNum);
		loadObject(mshoulders,mshoulders.getObjNum());

		int chestNum = Integer.parseInt(m.getChestSlot());
		mchest.resetObject();
		mchest.setObjNum(chestNum);
		loadObject(mchest,mchest.getObjNum());

		int wristNum = Integer.parseInt(m.getWristSlot());
		mwrist.resetObject();
		mwrist.setObjNum(wristNum);
		loadObject(mwrist,mwrist.getObjNum());

		int handNum = Integer.parseInt(m.getHandSlot());
		mhands.resetObject();
		mhands.setObjNum(handNum);
		loadObject(mhands,mhands.getObjNum());

		int fing1Num = Integer.parseInt(m.getFinger1());
		mfinger1.resetObject();
		mfinger1.setObjNum(fing1Num);
		loadObject(mfinger1,mfinger1.getObjNum());

		int fing2Num = Integer.parseInt(m.getFinger2());
		mfinger2.resetObject();
		mfinger2.setObjNum(fing2Num);
		loadObject(mfinger2,mfinger2.getObjNum());

		int waistNum = Integer.parseInt(m.getWaistSlot());
		mwaist.resetObject();
		mwaist.setObjNum(waistNum);
		loadObject(mwaist,mwaist.getObjNum());

		int legNum = Integer.parseInt(m.getLegSlot());
		mleg.resetObject();
		mleg.setObjNum(legNum);
		loadObject(mleg,mleg.getObjNum());

		int footNum = Integer.parseInt(m.getFootSlot());
		mfoot.resetObject();
		mfoot.setObjNum(footNum);
		loadObject(mfoot,mfoot.getObjNum());

		int trink1Num = Integer.parseInt(m.getHandSlot());
		mtrinket1.resetObject();
		mtrinket1.setObjNum(trink1Num);
		loadObject(mtrinket1,mtrinket1.getObjNum());

		int trink2Num = Integer.parseInt(m.getHandSlot());
		mtrinket2.resetObject();
		mtrinket2.setObjNum(trink2Num);
		loadObject(mtrinket2,mtrinket2.getObjNum());

		int weap1Num = Integer.parseInt(m.getWeapon1Slot());
		mweapon1.resetObject();
		mweapon1.setObjNum(weap1Num);
		loadObject(mweapon1,mweapon1.getObjNum());

		int weap2Num = Integer.parseInt(m.getWeaponShieldSlot());
		mweapshi.resetObject();
		mweapshi.setObjNum(weap2Num);
		loadObject(mweapshi,mweapshi.getObjNum());

		if (m.mobIsAlive == 1) {

			checkMobMaxHP(m);
			checkMobMaxMP(m);

			//load them at full health and mana
			m.setMobHP(m.getMaxHP());
			m.setMobMP(m.getMaxMP());
		}
		else {
			//m
		}

		// load the mobs inventory
		// may need to check on this
		loadMobInventory(m.getMobNum());

	}// end loadMob()


	private static void loadMobInventory(int i) {
		// load the mob's inventory and equipment
		if (tmob0.getMobNum() == i) {
			mob0inventory.resetInventory();
			mob0inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob0inventory.setPmobname(mInventory[i][1]);
			mob0inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob0inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob0inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob0inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob0inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob0inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob0inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob0inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob0inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob0inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob0inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob0inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob0inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob0inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob0inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob0inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob0inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob0inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob0inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob0inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob0inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob0inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob0inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob0inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob0inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob0inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob0inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob0inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob0inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob0inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob0inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob0inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob0inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob0inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob0inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob0inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob0inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob0inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob0inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob0inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob0inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob0inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob0inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob0inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob0inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob0inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob0inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob0inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m0inv0, mob0inventory.getPmobInv0());
			loadObject(m0inv1, mob0inventory.getPmobInv1());
			loadObject(m0inv2, mob0inventory.getPmobInv2());
			loadObject(m0inv3, mob0inventory.getPmobInv3());
			loadObject(m0inv4, mob0inventory.getPmobInv4());
			loadObject(m0inv5, mob0inventory.getPmobInv5());
			loadObject(m0inv6, mob0inventory.getPmobInv6());
			loadObject(m0inv7, mob0inventory.getPmobInv7());
			loadObject(m0inv8, mob0inventory.getPmobInv8());
			loadObject(m0inv9, mob0inventory.getPmobInv9());
			loadObject(m0inv10, mob0inventory.getPmobInv10());
			loadObject(m0inv11, mob0inventory.getPmobInv11());
			loadObject(m0inv12, mob0inventory.getPmobInv12());
			loadObject(m0inv13, mob0inventory.getPmobInv13());
			loadObject(m0inv14, mob0inventory.getPmobInv14());
			loadObject(m0inv15, mob0inventory.getPmobInv15());
			loadObject(m0inv16, mob0inventory.getPmobInv16());
			loadObject(m0inv17, mob0inventory.getPmobInv17());
			loadObject(m0inv18, mob0inventory.getPmobInv18());
			loadObject(m0inv19, mob0inventory.getPmobInv19());
			loadObject(m0inv20, mob0inventory.getPmobInv20());
			loadObject(m0inv21, mob0inventory.getPmobInv21());
			loadObject(m0inv22, mob0inventory.getPmobInv22());
			loadObject(m0inv23, mob0inventory.getPmobInv23());
			loadObject(m0inv24, mob0inventory.getPmobInv24());
			loadObject(m0inv25, mob0inventory.getPmobInv25());
			loadObject(m0inv26, mob0inventory.getPmobInv26());
			loadObject(m0inv27, mob0inventory.getPmobInv27());
			loadObject(m0inv28, mob0inventory.getPmobInv28());
			loadObject(m0inv29, mob0inventory.getPmobInv29());
		}
		if (tmob1.getMobNum() == i) {
			mob1inventory.resetInventory();
			mob1inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob1inventory.setPmobname(mInventory[i][1]);
			mob1inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob1inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob1inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob1inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob1inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob1inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob1inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob1inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob1inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob1inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob1inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob1inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob1inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob1inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob1inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob1inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob1inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob1inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob1inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob1inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob1inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob1inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob1inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob1inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob1inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob1inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob1inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob1inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob1inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob1inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob1inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob1inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob1inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob1inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob1inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob1inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob1inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob1inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob1inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob1inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob1inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob1inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob1inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob1inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob1inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob1inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob1inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob1inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m1inv0, mob1inventory.getPmobInv0());
			loadObject(m1inv1, mob1inventory.getPmobInv1());
			loadObject(m1inv2, mob1inventory.getPmobInv2());
			loadObject(m1inv3, mob1inventory.getPmobInv3());
			loadObject(m1inv4, mob1inventory.getPmobInv4());
			loadObject(m1inv5, mob1inventory.getPmobInv5());
			loadObject(m1inv6, mob1inventory.getPmobInv6());
			loadObject(m1inv7, mob1inventory.getPmobInv7());
			loadObject(m1inv8, mob1inventory.getPmobInv8());
			loadObject(m1inv9, mob1inventory.getPmobInv9());
			loadObject(m1inv10, mob1inventory.getPmobInv10());
			loadObject(m1inv11, mob1inventory.getPmobInv11());
			loadObject(m1inv12, mob1inventory.getPmobInv12());
			loadObject(m1inv13, mob1inventory.getPmobInv13());
			loadObject(m1inv14, mob1inventory.getPmobInv14());
			loadObject(m1inv15, mob1inventory.getPmobInv15());
			loadObject(m1inv16, mob1inventory.getPmobInv16());
			loadObject(m1inv17, mob1inventory.getPmobInv17());
			loadObject(m1inv18, mob1inventory.getPmobInv18());
			loadObject(m1inv19, mob1inventory.getPmobInv19());
			loadObject(m1inv20, mob1inventory.getPmobInv20());
			loadObject(m1inv21, mob1inventory.getPmobInv21());
			loadObject(m1inv22, mob1inventory.getPmobInv22());
			loadObject(m1inv23, mob1inventory.getPmobInv23());
			loadObject(m1inv24, mob1inventory.getPmobInv24());
			loadObject(m1inv25, mob1inventory.getPmobInv25());
			loadObject(m1inv26, mob1inventory.getPmobInv26());
			loadObject(m1inv27, mob1inventory.getPmobInv27());
			loadObject(m1inv28, mob1inventory.getPmobInv28());
			loadObject(m1inv29, mob1inventory.getPmobInv29());

		}
		if (tmob2.getMobNum() == i) {
			mob2inventory.resetInventory();

			//			System.out.println("Loading the player inventory with loadPlayerInventory(int i)");
			mob2inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob2inventory.setPmobname(mInventory[i][1]);
			mob2inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob2inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob2inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob2inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob2inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob2inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob2inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob2inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob2inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob2inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob2inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob2inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob2inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob2inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob2inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob2inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob2inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob2inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob2inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob2inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob2inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob2inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob2inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob2inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob2inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob2inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob2inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob2inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob2inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob2inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob2inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob2inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob2inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob2inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob2inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob2inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob2inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob2inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob2inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob2inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob2inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob2inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob2inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob2inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob2inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob2inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob2inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob2inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m2inv0, mob2inventory.getPmobInv0());
			loadObject(m2inv1, mob2inventory.getPmobInv1());
			loadObject(m2inv2, mob2inventory.getPmobInv2());
			loadObject(m2inv3, mob2inventory.getPmobInv3());
			loadObject(m2inv4, mob2inventory.getPmobInv4());
			loadObject(m2inv5, mob2inventory.getPmobInv5());
			loadObject(m2inv6, mob2inventory.getPmobInv6());
			loadObject(m2inv7, mob2inventory.getPmobInv7());
			loadObject(m2inv8, mob2inventory.getPmobInv8());
			loadObject(m2inv9, mob2inventory.getPmobInv9());
			loadObject(m2inv10, mob2inventory.getPmobInv10());
			loadObject(m2inv11, mob2inventory.getPmobInv11());
			loadObject(m2inv12, mob2inventory.getPmobInv12());
			loadObject(m2inv13, mob2inventory.getPmobInv13());
			loadObject(m2inv14, mob2inventory.getPmobInv14());
			loadObject(m2inv15, mob2inventory.getPmobInv15());
			loadObject(m2inv16, mob2inventory.getPmobInv16());
			loadObject(m2inv17, mob2inventory.getPmobInv17());
			loadObject(m2inv18, mob2inventory.getPmobInv18());
			loadObject(m2inv19, mob2inventory.getPmobInv19());
			loadObject(m2inv20, mob2inventory.getPmobInv20());
			loadObject(m2inv21, mob2inventory.getPmobInv21());
			loadObject(m2inv22, mob2inventory.getPmobInv22());
			loadObject(m2inv23, mob2inventory.getPmobInv23());
			loadObject(m2inv24, mob2inventory.getPmobInv24());
			loadObject(m2inv25, mob2inventory.getPmobInv25());
			loadObject(m2inv26, mob2inventory.getPmobInv26());
			loadObject(m2inv27, mob2inventory.getPmobInv27());
			loadObject(m2inv28, mob2inventory.getPmobInv28());
			loadObject(m2inv29, mob2inventory.getPmobInv29());

		}
		if (tmob3.getMobNum() == i) {
			mob3inventory.resetInventory();
			mob3inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob3inventory.setPmobname(mInventory[i][1]);
			mob3inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob3inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob3inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob3inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob3inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob3inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob3inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob3inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob3inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob3inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob3inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob3inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob3inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob3inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob3inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob3inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob3inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob3inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob3inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob3inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob3inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob3inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob3inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob3inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob3inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob3inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob3inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob3inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob3inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob3inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob3inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob3inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob3inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob3inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob3inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob3inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob3inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob3inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob3inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob3inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob3inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob3inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob3inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob3inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob3inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob3inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob3inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob3inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m3inv0, mob3inventory.getPmobInv0());
			loadObject(m3inv1, mob3inventory.getPmobInv1());
			loadObject(m3inv2, mob3inventory.getPmobInv2());
			loadObject(m3inv3, mob3inventory.getPmobInv3());
			loadObject(m3inv4, mob3inventory.getPmobInv4());
			loadObject(m3inv5, mob3inventory.getPmobInv5());
			loadObject(m3inv6, mob3inventory.getPmobInv6());
			loadObject(m3inv7, mob3inventory.getPmobInv7());
			loadObject(m3inv8, mob3inventory.getPmobInv8());
			loadObject(m3inv9, mob3inventory.getPmobInv9());
			loadObject(m3inv10, mob3inventory.getPmobInv10());
			loadObject(m3inv11, mob3inventory.getPmobInv11());
			loadObject(m3inv12, mob3inventory.getPmobInv12());
			loadObject(m3inv13, mob3inventory.getPmobInv13());
			loadObject(m3inv14, mob3inventory.getPmobInv14());
			loadObject(m3inv15, mob3inventory.getPmobInv15());
			loadObject(m3inv16, mob3inventory.getPmobInv16());
			loadObject(m3inv17, mob3inventory.getPmobInv17());
			loadObject(m3inv18, mob3inventory.getPmobInv18());
			loadObject(m3inv19, mob3inventory.getPmobInv19());
			loadObject(m3inv20, mob3inventory.getPmobInv20());
			loadObject(m3inv21, mob3inventory.getPmobInv21());
			loadObject(m3inv22, mob3inventory.getPmobInv22());
			loadObject(m3inv23, mob3inventory.getPmobInv23());
			loadObject(m3inv24, mob3inventory.getPmobInv24());
			loadObject(m3inv25, mob3inventory.getPmobInv25());
			loadObject(m3inv26, mob3inventory.getPmobInv26());
			loadObject(m3inv27, mob3inventory.getPmobInv27());
			loadObject(m3inv28, mob3inventory.getPmobInv28());
			loadObject(m3inv29, mob3inventory.getPmobInv29());

		}
		if (tmob4.getMobNum() == i) {
			mob4inventory.resetInventory();
			mob4inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob4inventory.setPmobname(mInventory[i][1]);
			mob4inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob4inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob4inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob4inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob4inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob4inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob4inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob4inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob4inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob4inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob4inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob4inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob4inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob4inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob4inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob4inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob4inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob4inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob4inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob4inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob4inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob4inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob4inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob4inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob4inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob4inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob4inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob4inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob4inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob4inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob4inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob4inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob4inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob4inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob4inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob4inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob4inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob4inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob4inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob4inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob4inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob4inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob4inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob4inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob4inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob4inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob4inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob4inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m4inv0, mob4inventory.getPmobInv0());
			loadObject(m4inv1, mob4inventory.getPmobInv1());
			loadObject(m4inv2, mob4inventory.getPmobInv2());
			loadObject(m4inv3, mob4inventory.getPmobInv3());
			loadObject(m4inv4, mob4inventory.getPmobInv4());
			loadObject(m4inv5, mob4inventory.getPmobInv5());
			loadObject(m4inv6, mob4inventory.getPmobInv6());
			loadObject(m4inv7, mob4inventory.getPmobInv7());
			loadObject(m4inv8, mob4inventory.getPmobInv8());
			loadObject(m4inv9, mob4inventory.getPmobInv9());
			loadObject(m4inv10, mob4inventory.getPmobInv10());
			loadObject(m4inv11, mob4inventory.getPmobInv11());
			loadObject(m4inv12, mob4inventory.getPmobInv12());
			loadObject(m4inv13, mob4inventory.getPmobInv13());
			loadObject(m4inv14, mob4inventory.getPmobInv14());
			loadObject(m4inv15, mob4inventory.getPmobInv15());
			loadObject(m4inv16, mob4inventory.getPmobInv16());
			loadObject(m4inv17, mob4inventory.getPmobInv17());
			loadObject(m4inv18, mob4inventory.getPmobInv18());
			loadObject(m4inv19, mob4inventory.getPmobInv19());
			loadObject(m4inv20, mob4inventory.getPmobInv20());
			loadObject(m4inv21, mob4inventory.getPmobInv21());
			loadObject(m4inv22, mob4inventory.getPmobInv22());
			loadObject(m4inv23, mob4inventory.getPmobInv23());
			loadObject(m4inv24, mob4inventory.getPmobInv24());
			loadObject(m4inv25, mob4inventory.getPmobInv25());
			loadObject(m4inv26, mob4inventory.getPmobInv26());
			loadObject(m4inv27, mob4inventory.getPmobInv27());
			loadObject(m4inv28, mob4inventory.getPmobInv28());
			loadObject(m4inv29, mob4inventory.getPmobInv29());

		}
		if (tmob5.getMobNum() == i) {
			mob5inventory.resetInventory();
			mob5inventory.setPmobid(Integer.parseInt(mInventory[i][0]));
			mob5inventory.setPmobname(mInventory[i][1]);
			mob5inventory.setPmobplat(Integer.parseInt(mInventory[i][2]));
			mob5inventory.setPmobgold(Integer.parseInt(mInventory[i][3]));
			mob5inventory.setPmobsilver(Integer.parseInt(mInventory[i][4]));
			mob5inventory.setPmobcopper(Integer.parseInt(mInventory[i][5]));
			mob5inventory.setPmobLHPot(Integer.parseInt(mInventory[i][6]));
			mob5inventory.setPmobLMPot(Integer.parseInt(mInventory[i][7]));
			mob5inventory.setPmobHPot(Integer.parseInt(mInventory[i][8]));
			mob5inventory.setPmobMPot(Integer.parseInt(mInventory[i][9]));
			mob5inventory.setPmobGHPot(Integer.parseInt(mInventory[i][10]));
			mob5inventory.setPmobGMPot(Integer.parseInt(mInventory[i][11]));
			mob5inventory.setPmobMHPot(Integer.parseInt(mInventory[i][12]));
			mob5inventory.setPmobMMPot(Integer.parseInt(mInventory[i][13]));
			mob5inventory.setBlank0(mInventory[i][14]); // currently not used, spacer in file
			mob5inventory.setPmobInv0(Integer.parseInt(mInventory[i][15]));
			mob5inventory.setPmobInv1(Integer.parseInt(mInventory[i][16]));
			mob5inventory.setPmobInv2(Integer.parseInt(mInventory[i][17]));
			mob5inventory.setPmobInv3(Integer.parseInt(mInventory[i][18]));
			mob5inventory.setPmobInv4(Integer.parseInt(mInventory[i][19]));
			mob5inventory.setPmobInv5(Integer.parseInt(mInventory[i][20]));
			mob5inventory.setPmobInv6(Integer.parseInt(mInventory[i][21]));
			mob5inventory.setPmobInv7(Integer.parseInt(mInventory[i][22]));
			mob5inventory.setPmobInv8(Integer.parseInt(mInventory[i][23]));
			mob5inventory.setPmobInv9(Integer.parseInt(mInventory[i][24]));
			mob5inventory.setPmobInv10(Integer.parseInt(mInventory[i][25]));
			mob5inventory.setPmobInv11(Integer.parseInt(mInventory[i][26]));
			mob5inventory.setPmobInv12(Integer.parseInt(mInventory[i][27]));
			mob5inventory.setPmobInv13(Integer.parseInt(mInventory[i][28]));
			mob5inventory.setPmobInv14(Integer.parseInt(mInventory[i][29]));
			mob5inventory.setPmobInv15(Integer.parseInt(mInventory[i][30]));
			mob5inventory.setPmobInv16(Integer.parseInt(mInventory[i][31]));
			mob5inventory.setPmobInv17(Integer.parseInt(mInventory[i][32]));
			mob5inventory.setPmobInv18(Integer.parseInt(mInventory[i][33]));
			mob5inventory.setPmobInv19(Integer.parseInt(mInventory[i][34]));
			mob5inventory.setPmobInv20(Integer.parseInt(mInventory[i][35]));
			mob5inventory.setPmobInv21(Integer.parseInt(mInventory[i][36]));
			mob5inventory.setPmobInv22(Integer.parseInt(mInventory[i][37]));
			mob5inventory.setPmobInv23(Integer.parseInt(mInventory[i][38]));
			mob5inventory.setPmobInv24(Integer.parseInt(mInventory[i][39]));
			mob5inventory.setPmobInv25(Integer.parseInt(mInventory[i][40]));
			mob5inventory.setPmobInv26(Integer.parseInt(mInventory[i][41]));
			mob5inventory.setPmobInv27(Integer.parseInt(mInventory[i][42]));
			mob5inventory.setPmobInv28(Integer.parseInt(mInventory[i][43]));
			mob5inventory.setPmobInv29(Integer.parseInt(mInventory[i][44]));

			// these are strings, currently not used
			mob5inventory.setBlank1(Integer.parseInt(mInventory[i][45])); // bank plat
			mob5inventory.setBlank2(Integer.parseInt(mInventory[i][46])); // bank gold
			mob5inventory.setBlank3(Integer.parseInt(mInventory[i][47])); // bank silver
			mob5inventory.setBlank4(Integer.parseInt(mInventory[i][48])); // bank copper?
			mob5inventory.setBlank5(mInventory[i][49]);

			// load the inventory objects
			loadObject(m5inv0, mob5inventory.getPmobInv0());
			loadObject(m5inv1, mob5inventory.getPmobInv1());
			loadObject(m5inv2, mob5inventory.getPmobInv2());
			loadObject(m5inv3, mob5inventory.getPmobInv3());
			loadObject(m5inv4, mob5inventory.getPmobInv4());
			loadObject(m5inv5, mob5inventory.getPmobInv5());
			loadObject(m5inv6, mob5inventory.getPmobInv6());
			loadObject(m5inv7, mob5inventory.getPmobInv7());
			loadObject(m5inv8, mob5inventory.getPmobInv8());
			loadObject(m5inv9, mob5inventory.getPmobInv9());
			loadObject(m5inv10, mob5inventory.getPmobInv10());
			loadObject(m5inv11, mob5inventory.getPmobInv11());
			loadObject(m5inv12, mob5inventory.getPmobInv12());
			loadObject(m5inv13, mob5inventory.getPmobInv13());
			loadObject(m5inv14, mob5inventory.getPmobInv14());
			loadObject(m5inv15, mob5inventory.getPmobInv15());
			loadObject(m5inv16, mob5inventory.getPmobInv16());
			loadObject(m5inv17, mob5inventory.getPmobInv17());
			loadObject(m5inv18, mob5inventory.getPmobInv18());
			loadObject(m5inv19, mob5inventory.getPmobInv19());
			loadObject(m5inv20, mob5inventory.getPmobInv20());
			loadObject(m5inv21, mob5inventory.getPmobInv21());
			loadObject(m5inv22, mob5inventory.getPmobInv22());
			loadObject(m5inv23, mob5inventory.getPmobInv23());
			loadObject(m5inv24, mob5inventory.getPmobInv24());
			loadObject(m5inv25, mob5inventory.getPmobInv25());
			loadObject(m5inv26, mob5inventory.getPmobInv26());
			loadObject(m5inv27, mob5inventory.getPmobInv27());
			loadObject(m5inv28, mob5inventory.getPmobInv28());
			loadObject(m5inv29, mob5inventory.getPmobInv29());

		}

	}


	private static void loadPlayer(int i) {

		System.out.println("Loading the player with id: " + i);

		// load player char from Chars array
		player1.setPlayerNum(i);
		player1.setPlayerName(Chars[i][1]);
		//	System.out.println(player1.getPlayerName());
		player1.setPlayerShortDesc(Chars[i][2]);
		player1.setPlayerLongDesc(Chars[i][3]);
		String[] pkw = Chars[i][4].toString().split(",");
		player1.setPlayerKeyWords(pkw);  //4
		player1.setPlayerHP(Integer.parseInt(Chars[i][5]));
		player1.setPlayerMP(Integer.parseInt(Chars[i][6]));
		player1.setPlayerLvl(Integer.parseInt(Chars[i][7]));
		player1.setStam(Integer.parseInt(Chars[i][8]));
		player1.setStr(Integer.parseInt(Chars[i][9]));
		player1.setIntel(Integer.parseInt(Chars[i][10]));
		player1.setAgility(Integer.parseInt(Chars[i][11]));
		player1.setHeadSlot(Chars[i][12]);
		player1.setNeckSlot(Chars[i][13]);
		player1.setShoulderSlot(Chars[i][14]);
		player1.setChestSlot(Chars[i][15]);
		player1.setWristSlot(Chars[i][16]);
		player1.setHandSlot(Chars[i][17]);
		player1.setFinger1(Chars[i][18]);
		player1.setFinger2(Chars[i][19]);
		player1.setWaistSlot(Chars[i][20]);
		player1.setLegSlot(Chars[i][21]);
		player1.setFootSlot(Chars[i][22]);
		player1.setTrinket1Slot(Chars[i][23]);
		player1.setTrinket2Slot(Chars[i][24]);
		player1.setWeapon1Slot(Chars[i][25]);
		player1.setWeaponShieldSlot(Chars[i][26]);
		player1.setPlayerRace(Chars[i][27]); // player race
		player1.setPlayerSubRace(Chars[i][28]);
		player1.setPlayerTier(Chars[i][29]); // tier
		player1.setPlayerXP(Integer.parseInt(Chars[i][30]));
		player1.setPlayerIsAlive(Integer.parseInt(Chars[i][31]));
		player1.setPlayerGender(Chars[i][32]);
		player1.setPlayerClass(Chars[i][33]);

		// filling rest of slots from array, these are strings, but should be set to Unused
		player1.setBlank1(Chars[i][34]);
		player1.setBlank2(Chars[i][35]);
		player1.setBlank3(Chars[i][36]);
		player1.setBlank4(Chars[i][37]);
		player1.setBlank5(Chars[i][38]);
		player1.setBlank6(Chars[i][39]);
		player1.setBlank7(Chars[i][40]);
		player1.setBlank8(Chars[i][41]);
		player1.setBlank9(Chars[i][42]);
		player1.setBlank10(Chars[i][43]);
		player1.setBlank11(Chars[i][44]);
		player1.setBlank12(Chars[i][45]);
		player1.setBlank13(Chars[i][46]);
		player1.setBlank14(Chars[i][47]);
		player1.setBlank15(Chars[i][48]);
		player1.setBlank16(Chars[i][49]);

		int hlmNum = Integer.parseInt(player1.getHeadSlot());
		phelm.setObjNum(hlmNum);
		loadObject(phelm,phelm.getObjNum());

		int necNum = Integer.parseInt(player1.getNeckSlot());
		pneck.setObjNum(necNum);
		loadObject(pneck,pneck.getObjNum());

		int shdNum = Integer.parseInt(player1.getShoulderSlot());
		pshoulders.setObjNum(shdNum);
		loadObject(pshoulders,pshoulders.getObjNum());

		int chestNum = Integer.parseInt(player1.getChestSlot());
		pchest.setObjNum(chestNum);
		loadObject(pchest,pchest.getObjNum());

		int wristNum = Integer.parseInt(player1.getWristSlot());
		pwrist.setObjNum(wristNum);
		loadObject(pwrist,pwrist.getObjNum());

		int handNum = Integer.parseInt(player1.getHandSlot());
		phands.setObjNum(handNum);
		loadObject(phands,phands.getObjNum());

		int fing1Num = Integer.parseInt(player1.getFinger1());
		pfinger1.setObjNum(fing1Num);
		loadObject(pfinger1,pfinger1.getObjNum());

		int fing2Num = Integer.parseInt(player1.getFinger2());
		pfinger2.setObjNum(fing2Num);
		loadObject(pfinger2,pfinger2.getObjNum());

		int waistNum = Integer.parseInt(player1.getWaistSlot());
		pwaist.setObjNum(waistNum);
		loadObject(pwaist,pwaist.getObjNum());

		int legNum = Integer.parseInt(player1.getLegSlot());
		pleg.setObjNum(legNum);
		loadObject(pleg,pleg.getObjNum());

		int footNum = Integer.parseInt(player1.getFootSlot());
		pfoot.setObjNum(footNum);
		loadObject(pfoot,pfoot.getObjNum());

		int trink1Num = Integer.parseInt(player1.getHandSlot());
		ptrinket1.setObjNum(trink1Num);
		loadObject(ptrinket1,ptrinket1.getObjNum());

		int trink2Num = Integer.parseInt(player1.getHandSlot());
		ptrinket2.setObjNum(trink2Num);
		loadObject(ptrinket2,ptrinket2.getObjNum());

		int weap1Num = Integer.parseInt(player1.getWeapon1Slot());
		pweapon1.setObjNum(weap1Num);
		loadObject(pweapon1,pweapon1.getObjNum());

		int weap2Num = Integer.parseInt(player1.getWeaponShieldSlot());
		pweapshi.setObjNum(weap2Num);
		loadObject(pweapshi,pweapshi.getObjNum());

		// recalc playerMaxMP and playerMaxHP
		checkPlayerMaxHP();
		checkPlayerMaxMP();

		//load the inventory!
		loadPlayerInventory(i);

	} // end loadPlayer()

	private static void loadPlayerInventory(int i) {
		// load the player inventory from array
		System.out.println("Loading the player inventory with id: " + i);
		playerinventory.setPmobid(Integer.parseInt(pInventory[i][0]));
		playerinventory.setPmobname(pInventory[i][1]);
		playerinventory.setPmobplat(Integer.parseInt(pInventory[i][2]));
		playerinventory.setPmobgold(Integer.parseInt(pInventory[i][3]));
		playerinventory.setPmobsilver(Integer.parseInt(pInventory[i][4]));
		playerinventory.setPmobcopper(Integer.parseInt(pInventory[i][5]));
		playerinventory.setPmobLHPot(Integer.parseInt(pInventory[i][6]));
		playerinventory.setPmobLMPot(Integer.parseInt(pInventory[i][7]));
		playerinventory.setPmobHPot(Integer.parseInt(pInventory[i][8]));
		playerinventory.setPmobMPot(Integer.parseInt(pInventory[i][9]));
		playerinventory.setPmobGHPot(Integer.parseInt(pInventory[i][10]));
		playerinventory.setPmobGMPot(Integer.parseInt(pInventory[i][11]));
		playerinventory.setPmobMHPot(Integer.parseInt(pInventory[i][12]));
		playerinventory.setPmobMMPot(Integer.parseInt(pInventory[i][13]));
		playerinventory.setBlank0(pInventory[i][14]); // currently not used, spacer in file
		playerinventory.setPmobInv0(Integer.parseInt(pInventory[i][15]));
		playerinventory.setPmobInv1(Integer.parseInt(pInventory[i][16]));
		playerinventory.setPmobInv2(Integer.parseInt(pInventory[i][17]));
		playerinventory.setPmobInv3(Integer.parseInt(pInventory[i][18]));
		playerinventory.setPmobInv4(Integer.parseInt(pInventory[i][19]));
		playerinventory.setPmobInv5(Integer.parseInt(pInventory[i][20]));
		playerinventory.setPmobInv6(Integer.parseInt(pInventory[i][21]));
		playerinventory.setPmobInv7(Integer.parseInt(pInventory[i][22]));
		playerinventory.setPmobInv8(Integer.parseInt(pInventory[i][23]));
		playerinventory.setPmobInv9(Integer.parseInt(pInventory[i][24]));
		playerinventory.setPmobInv10(Integer.parseInt(pInventory[i][25]));
		playerinventory.setPmobInv11(Integer.parseInt(pInventory[i][26]));
		playerinventory.setPmobInv12(Integer.parseInt(pInventory[i][27]));
		playerinventory.setPmobInv13(Integer.parseInt(pInventory[i][28]));
		playerinventory.setPmobInv14(Integer.parseInt(pInventory[i][29]));
		playerinventory.setPmobInv15(Integer.parseInt(pInventory[i][30]));
		playerinventory.setPmobInv16(Integer.parseInt(pInventory[i][31]));
		playerinventory.setPmobInv17(Integer.parseInt(pInventory[i][32]));
		playerinventory.setPmobInv18(Integer.parseInt(pInventory[i][33]));
		playerinventory.setPmobInv19(Integer.parseInt(pInventory[i][34]));
		playerinventory.setPmobInv20(Integer.parseInt(pInventory[i][35]));
		playerinventory.setPmobInv21(Integer.parseInt(pInventory[i][36]));
		playerinventory.setPmobInv22(Integer.parseInt(pInventory[i][37]));
		playerinventory.setPmobInv23(Integer.parseInt(pInventory[i][38]));
		playerinventory.setPmobInv24(Integer.parseInt(pInventory[i][39]));
		playerinventory.setPmobInv25(Integer.parseInt(pInventory[i][40]));
		playerinventory.setPmobInv26(Integer.parseInt(pInventory[i][41]));
		playerinventory.setPmobInv27(Integer.parseInt(pInventory[i][42]));
		playerinventory.setPmobInv28(Integer.parseInt(pInventory[i][43]));
		playerinventory.setPmobInv29(Integer.parseInt(pInventory[i][44]));

		// these are strings, currently not used
		playerinventory.setBlank1(Integer.parseInt(pInventory[i][45])); // bank plat
		playerinventory.setBlank2(Integer.parseInt(pInventory[i][46])); // bank gold
		playerinventory.setBlank3(Integer.parseInt(pInventory[i][47])); // bank silver
		playerinventory.setBlank4(Integer.parseInt(pInventory[i][48])); // bank copper?
		playerinventory.setBlank5(pInventory[i][49]);

		// load the inventory objects
		loadObject(pinv0, playerinventory.getPmobInv0());
		loadObject(pinv1, playerinventory.getPmobInv1());
		loadObject(pinv2, playerinventory.getPmobInv2());
		loadObject(pinv3, playerinventory.getPmobInv3());
		loadObject(pinv4, playerinventory.getPmobInv4());
		loadObject(pinv5, playerinventory.getPmobInv5());
		loadObject(pinv6, playerinventory.getPmobInv6());
		loadObject(pinv7, playerinventory.getPmobInv7());
		loadObject(pinv8, playerinventory.getPmobInv8());
		loadObject(pinv9, playerinventory.getPmobInv9());
		loadObject(pinv10, playerinventory.getPmobInv10());
		loadObject(pinv11, playerinventory.getPmobInv11());
		loadObject(pinv12, playerinventory.getPmobInv12());
		loadObject(pinv13, playerinventory.getPmobInv13());
		loadObject(pinv14, playerinventory.getPmobInv14());
		loadObject(pinv15, playerinventory.getPmobInv15());
		loadObject(pinv16, playerinventory.getPmobInv16());
		loadObject(pinv17, playerinventory.getPmobInv17());
		loadObject(pinv18, playerinventory.getPmobInv18());
		loadObject(pinv19, playerinventory.getPmobInv19());
		loadObject(pinv20, playerinventory.getPmobInv20());
		loadObject(pinv21, playerinventory.getPmobInv21());
		loadObject(pinv22, playerinventory.getPmobInv22());
		loadObject(pinv23, playerinventory.getPmobInv23());
		loadObject(pinv24, playerinventory.getPmobInv24());
		loadObject(pinv25, playerinventory.getPmobInv25());
		loadObject(pinv26, playerinventory.getPmobInv26());
		loadObject(pinv27, playerinventory.getPmobInv27());
		loadObject(pinv28, playerinventory.getPmobInv28());
		loadObject(pinv29, playerinventory.getPmobInv29());

	} // end loadPlayerInventory(int i)


	private static void loadObject(objects o, int oNum) {
		// load all the object stuff from the Objects array
		if (oNum < 0) { }
		else {
			o.setObjNum(oNum); //0
			o.setObjName(Objects[oNum][1]); //1
			o.setObjShortDesc(Objects[oNum][2]); //2 short desc (a spanglehelm)
			o.setObjLongDesc(Objects[oNum][3]); //3 long desc
			o.setObjExtDesc(Objects[oNum][4]); //4 extended desc
			String t = Objects[oNum][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			o.setObjKeyWords(t.split(",")); //5 keywords hopefully
			o.setAddStr(Integer.parseInt(Objects[oNum][6]));
			o.setAddStam(Integer.parseInt(Objects[oNum][7]));
			o.setAddInt(Integer.parseInt(Objects[oNum][8]));
			o.setAddAgi(Integer.parseInt(Objects[oNum][9]));
			o.setAddHP(Integer.parseInt(Objects[oNum][10]));
			o.setAddMP(Integer.parseInt(Objects[oNum][11]));
			o.setDurability(Integer.parseInt(Objects[oNum][12]));
			o.setTakeable(Integer.parseInt(Objects[oNum][13]));
			String es = Objects[oNum][14];
			o.setEquipSlot(es);

			o.setObjval(Objects[oNum][15]);
			o.setObjType(Objects[oNum][16]); // obj type
			o.setStackSize(Integer.parseInt(Objects[oNum][17])); // stack size
			o.setWeaponType(Objects[oNum][18]); // weapon type
			o.setWeaponDmg(Objects[oNum][19]); // weapon dmg
			o.setWpndmgType(Objects[oNum][20]); // wpn dmg type

			o.setV21(Objects[oNum][21]); // unused

			o.setArmorType(Objects[oNum][22]); // armor type
			o.setDmgRedux(Integer.parseInt(Objects[oNum][23])); // dmg redux ( 0-10?)
			o.setHpRestore(Integer.parseInt(Objects[oNum][24]));	// food HP restore
			o.setMpRestore(Integer.parseInt(Objects[oNum][25])); // drink MP restore
			o.setPotSpell(Objects[oNum][26]); // potion // buff? special effect? self-target spell?
			o.setScrollSpell(Objects[oNum][27]); // scroll // spell? either self-target or attack?
			o.setWandSpell(Objects[oNum][28]); // wand // spell // attack spell
			o.setWandCharge(Integer.parseInt(Objects[oNum][29])); // wand charges (0-5)
			o.setCntSize(Integer.parseInt(Objects[oNum][30])); // container size



			t = Objects[oNum][31];
			t.replace("[", "");
			t.replace("]", "");
			String[] t3 = t.split(",");
			//	editingObject.setObjKeyWords(t2);
			o.setCntCont(t3);
			//o.setCntCont(Objects[oNum][31]); // container contents?

			o.setV32(Objects[oNum][32]);
			o.setV33(Objects[oNum][33]);
			o.setV34(Objects[oNum][34]);
			o.setV35(Objects[oNum][35]);
			o.setV36(Objects[oNum][36]);
			o.setV37(Objects[oNum][37]);
			o.setV38(Objects[oNum][38]);
			o.setV39(Objects[oNum][39]);
			o.setV40(Objects[oNum][40]);
			o.setV41(Objects[oNum][41]);

			o.setV42(Objects[oNum][42]);
			o.setV43(Objects[oNum][43]);
			o.setV44(Objects[oNum][44]);
			o.setV45(Objects[oNum][45]);

			String bg = Objects[oNum][46];
			String rg = Objects[oNum][47];
			String hm = Objects[oNum][48];
			String cr = Objects[oNum][49];
			switch (bg) {
			case "0":{
				o.setBlueGlow(0);
				break;
			}
			default: o.setBlueGlow(1);
			}
			switch (rg) {
			case "0":{
				o.setRedGlow(0);
				break;
			}
			default: o.setRedGlow(1);
			}
			switch (hm) {
			case "0":{
				o.setHum(0);
				break;
			}
			default: o.setHum(1);
			}
			switch (cr) {
			case "0":{
				o.setCursed(0);
				break;
			}
			default: o.setCursed(1);
			}

		}
	} // end loadObject


	private static int d20() {
		// pure d20 roller for whatever need
		int max = 20; //  20, duh
		int min = 1; // 1, duh
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}



	private static void resetMobStats() {
		editingMob.resetStats();
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(editor + "Editor");

	}

	private static int roll(int mi, int ma) {
		// min/max roller for whatever needs
		int min = mi;
		int max = ma;
		Random rand = new Random();
		int roll = rand.nextInt((max - min) + 1) + min;  // the +1 is so you do not roll a 0
		return roll;
	}



	public static void look2(String l) throws IOException {
		// shorter room look for editor
		if ("null".equalsIgnoreCase(l)) {
			newRoom.returnRoomInfo2();
		}
	} // end look2


	public static void lookSample(room CR, String loo) throws Exception {
		// displays room, mobs and objs to player
		String tmobsar = CR.getMobsInRoom();
		tmobsar = tmobsar.replace("[", "");
		tmobsar = tmobsar.replace("]", "");
		tmobsar = tmobsar.replace(" ", "");
		String[] tmobsarr = tmobsar.split(",");

		String tobjsar = CR.getObjsInRoom();
		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");
		tobjsar = tobjsar.replace(" ", "");
		String[] tobjsarr = tobjsar.split(",");

		//if no input after look
		if ("null".equalsIgnoreCase(loo)) {
			// show the room
			CR.returnRoomInfo();


			//show mobs if they are in room
			if ("0".equalsIgnoreCase(tmobsarr[0])) {	}  // do nothing if 0 (skip to next if)
			else {
				if (tmob0.getMobIsAlive() == 1) { System.out.println("You see " + tmob0.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob0.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[1])) {	}
			else {
				if (tmob1.getMobIsAlive() == 1) { System.out.println("You see " + tmob1.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob1.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[2])) {	}
			else {
				if (tmob2.getMobIsAlive() == 1) { System.out.println("You see " + tmob2.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob2.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[3])) {	}
			else {
				if (tmob3.getMobIsAlive() == 1) { System.out.println("You see " + tmob3.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob3.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[4])) {	}
			else {
				if (tmob4.getMobIsAlive() == 1) { System.out.println("You see " + tmob4.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob4.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[5])) {	}
			else {
				if (tmob5.getMobIsAlive() == 1) { System.out.println("You see " + tmob5.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob5.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[0]) && "0".equalsIgnoreCase(tmobsarr[1]) && "0".equalsIgnoreCase(tmobsarr[2]) && "0".equalsIgnoreCase(tmobsarr[3]) && "0".equalsIgnoreCase(tmobsarr[4]) && "0".equalsIgnoreCase(tmobsarr[5])) {
				System.out.println("You do not see any creatures nearby.");
			}

			//show objs if they are in room
			if ("0".equalsIgnoreCase(tobjsarr[0].strip())) {	}
			else { 
				if (tobj0.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj0.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj0.getObjShortDesc() + ".") ;
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[1].strip())) {	}
			else { 
				if (tobj1.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj1.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj1.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[2].strip())) {	}
			else { 
				if (tobj2.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj2.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj2.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[3].strip())) {	}
			else { 
				if (tobj3.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj3.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj3.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[4].strip())) {	}
			else { 
				if (tobj4.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj4.getObjShortDesc() + "."); }
				else {				
					System.out.println("You see " + tobj4.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[5].strip())) {	}
			else { 
				if (tobj5.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj5.getObjShortDesc() + "."); }
				else {					
					System.out.println("You see " + tobj5.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[0].strip()) && "0".equalsIgnoreCase(tobjsarr[1].strip()) && "0".equalsIgnoreCase(tobjsarr[2].strip()) && "0".equalsIgnoreCase(tobjsarr[3].strip()) && "0".equalsIgnoreCase(tobjsarr[4].strip()) && "0".equalsIgnoreCase(tobjsarr[5].strip())) {
				System.out.println("You do not see anything of note.");
			}


			// display the player info
			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP());
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

		} // end if ("null".equalsIgnoreCase(l)) {


		//directional looks
		else if ("north".equalsIgnoreCase(loo) && newRoom.getExitN() != 0) {
			System.out.println("You see " + exN.getRoomShortDesc() + ".");
			if ((exN.getMobNumAtPos(0) != "0") && (exN.getMobNumAtPos(1) != "0") && (exN.getMobNumAtPos(2) != "0") && (exN.getMobNumAtPos(3) != "0") && (exN.getMobNumAtPos(4) != "0") && (exN.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north".equalsIgnoreCase(loo) && newRoom.getExitN() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(loo) && newRoom.getExitNE() != 0) {
			System.out.println("You see " + exNE.getRoomShortDesc() + ".");
			if ((exNE.getMobNumAtPos(0) != "0") && (exNE.getMobNumAtPos(1) != "0") && (exNE.getMobNumAtPos(2) != "0") && (exNE.getMobNumAtPos(3) != "0") && (exNE.getMobNumAtPos(4) != "0") && (exNE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(loo) && newRoom.getExitNE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("east".equalsIgnoreCase(loo) && newRoom.getExitE() != 0) {
			System.out.println("You see " + exE.getRoomShortDesc() + ".");
			if ((exE.getMobNumAtPos(0) != "0") && (exE.getMobNumAtPos(1) != "0") && (exE.getMobNumAtPos(2) != "0") && (exE.getMobNumAtPos(3) != "0") && (exE.getMobNumAtPos(4) != "0") && (exE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("east".equalsIgnoreCase(loo) && newRoom.getExitE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south east".equalsIgnoreCase(loo) && newRoom.getExitSE() != 0) {
			System.out.println("You see " + exSE.getRoomShortDesc() + ".");
			if ((exSE.getMobNumAtPos(0) != "0") && (exSE.getMobNumAtPos(1) != "0") && (exSE.getMobNumAtPos(2) != "0") && (exSE.getMobNumAtPos(3) != "0") && (exSE.getMobNumAtPos(4) != "0") && (exSE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south east".equalsIgnoreCase(loo) && newRoom.getExitSE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south".equalsIgnoreCase(loo) && newRoom.getExitS() != 0) {
			System.out.println("You see " + exS.getRoomShortDesc() + ".");
			if ((exS.getMobNumAtPos(0) != "0") && (exS.getMobNumAtPos(1) != "0") && (exS.getMobNumAtPos(2) != "0") && (exS.getMobNumAtPos(3) != "0") && (exS.getMobNumAtPos(4) != "0") && (exS.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south".equalsIgnoreCase(loo) && newRoom.getExitS() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south west".equalsIgnoreCase(loo) && newRoom.getExitSW() != 0) {
			System.out.println("You see " + exSW.getRoomShortDesc() + ".");
			if ((exSW.getMobNumAtPos(0) != "0") && (exSW.getMobNumAtPos(1) != "0") && (exSW.getMobNumAtPos(2) != "0") && (exSW.getMobNumAtPos(3) != "0") && (exSW.getMobNumAtPos(4) != "0") && (exSW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south west".equalsIgnoreCase(loo) && newRoom.getExitSW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("west".equalsIgnoreCase(loo) && newRoom.getExitW() != 0) {
			System.out.println("You see " + exW.getRoomShortDesc() + ".");
			if ((exW.getMobNumAtPos(0) != "0") && (exW.getMobNumAtPos(1) != "0") && (exW.getMobNumAtPos(2) != "0") && (exW.getMobNumAtPos(3) != "0") && (exW.getMobNumAtPos(4) != "0") && (exW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("west".equalsIgnoreCase(loo) && newRoom.getExitW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north west".equalsIgnoreCase(loo) && newRoom.getExitNW() != 0) {
			System.out.println("You see " + exNW.getRoomShortDesc() + ".");
			if ((exNW.getMobNumAtPos(0) != "0") && (exNW.getMobNumAtPos(1) != "0") && (exNW.getMobNumAtPos(2) != "0") && (exNW.getMobNumAtPos(3) != "0") && (exNW.getMobNumAtPos(4) != "0") && (exNW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north west".equalsIgnoreCase(loo) && newRoom.getExitNW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("up".equalsIgnoreCase(loo) && newRoom.getExitU() != 0) {
			System.out.println("You see " + exU.getRoomShortDesc() + ".");
			if ((exU.getMobNumAtPos(0) != "0") && (exU.getMobNumAtPos(1) != "0") && (exU.getMobNumAtPos(2) != "0") && (exU.getMobNumAtPos(3) != "0") && (exU.getMobNumAtPos(4) != "0") && (exU.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("up".equalsIgnoreCase(loo) && newRoom.getExitU() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("down".equalsIgnoreCase(loo) && newRoom.getExitD() != 0) {
			System.out.println("You see " + exD.getRoomShortDesc() + ".");
			if ((exD.getMobNumAtPos(0) != "0") && (exD.getMobNumAtPos(1) != "0") && (exD.getMobNumAtPos(2) != "0") && (exD.getMobNumAtPos(3) != "0") && (exD.getMobNumAtPos(4) != "0") && (exD.getMobNumAtPos(5) != "0")) {
				//	System.out.println("1"); // you see no creatures
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("down".equalsIgnoreCase(loo) && newRoom.getExitD() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}

	} // end lookSampler()
	public static void look(String l) throws Exception {
		// displays room, mobs and objs to player
		String tmobsar = newRoom.getMobsInRoom();
		tmobsar = tmobsar.replace("[", "");
		tmobsar = tmobsar.replace("]", "");
		tmobsar = tmobsar.replace(" ", "");
		String[] tmobsarr = tmobsar.split(",");

		String tobjsar = newRoom.getObjsInRoom();
		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");
		tobjsar = tobjsar.replace(" ", "");
		String[] tobjsarr = tobjsar.split(",");

		//if no input after look
		if ("null".equalsIgnoreCase(l)) {
			// show the room
			newRoom.returnRoomInfo();


			//show mobs if they are in room
			if ("0".equalsIgnoreCase(tmobsarr[0])) {	}  // do nothing if 0 (skip to next if)
			else {
				if (tmob0.getMobIsAlive() == 1) { System.out.println("You see " + tmob0.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob0.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[1])) {	}
			else {
				if (tmob1.getMobIsAlive() == 1) { System.out.println("You see " + tmob1.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob1.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[2])) {	}
			else {
				if (tmob2.getMobIsAlive() == 1) { System.out.println("You see " + tmob2.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob2.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[3])) {	}
			else {
				if (tmob3.getMobIsAlive() == 1) { System.out.println("You see " + tmob3.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob3.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[4])) {	}
			else {
				if (tmob4.getMobIsAlive() == 1) { System.out.println("You see " + tmob4.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob4.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[5])) {	}
			else {
				if (tmob5.getMobIsAlive() == 1) { System.out.println("You see " + tmob5.getMobShortDesc() + "."); }	 // output the mob if tmob0.getMobIsAlive() == 1 (its Alive still)
				else { System.out.println("You see the corpse of " + tmob5.getMobShortDesc() + "."); } // tells you the mob is dead in the room. tmob0.getMobIsAlive() != 1 (its dead)
			}
			if ("0".equalsIgnoreCase(tmobsarr[0]) && "0".equalsIgnoreCase(tmobsarr[1]) && "0".equalsIgnoreCase(tmobsarr[2]) && "0".equalsIgnoreCase(tmobsarr[3]) && "0".equalsIgnoreCase(tmobsarr[4]) && "0".equalsIgnoreCase(tmobsarr[5])) {
				System.out.println("You do not see any creatures nearby.");
			}

			//show objs if they are in room
			if ("0".equalsIgnoreCase(tobjsarr[0].strip())) {	}
			else { 
				if (tobj0.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj0.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj0.getObjShortDesc() + ".") ;
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[1].strip())) {	}
			else { 
				if (tobj1.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj1.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj1.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[2].strip())) {	}
			else { 
				if (tobj2.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj2.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj2.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[3].strip())) {	}
			else { 
				if (tobj3.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj3.getObjShortDesc() + "."); }
				else {
					System.out.println("You see " + tobj3.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[4].strip())) {	}
			else { 
				if (tobj4.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj4.getObjShortDesc() + "."); }
				else {				
					System.out.println("You see " + tobj4.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[5].strip())) {	}
			else { 
				if (tobj5.getDurability() <= 0) { System.out.println("You see the tattered remains of " + tobj5.getObjShortDesc() + "."); }
				else {					
					System.out.println("You see " + tobj5.getObjShortDesc() + ".");
				}
			}
			if ("0".equalsIgnoreCase(tobjsarr[0].strip()) && "0".equalsIgnoreCase(tobjsarr[1].strip()) && "0".equalsIgnoreCase(tobjsarr[2].strip()) && "0".equalsIgnoreCase(tobjsarr[3].strip()) && "0".equalsIgnoreCase(tobjsarr[4].strip()) && "0".equalsIgnoreCase(tobjsarr[5].strip())) {
				System.out.println("You do not see anything of note.");
			}


			// display the player info
			System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP());
			System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
					"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
					playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

		} // end if ("null".equalsIgnoreCase(l)) {


		//directional looks
		else if ("north".equalsIgnoreCase(l) && newRoom.getExitN() != 0) {
			System.out.println("You see " + exN.getRoomShortDesc() + ".");
			if ((exN.getMobNumAtPos(0) != "0") && (exN.getMobNumAtPos(1) != "0") && (exN.getMobNumAtPos(2) != "0") && (exN.getMobNumAtPos(3) != "0") && (exN.getMobNumAtPos(4) != "0") && (exN.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north".equalsIgnoreCase(l) && newRoom.getExitN() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(l) && newRoom.getExitNE() != 0) {
			System.out.println("You see " + exNE.getRoomShortDesc() + ".");
			if ((exNE.getMobNumAtPos(0) != "0") && (exNE.getMobNumAtPos(1) != "0") && (exNE.getMobNumAtPos(2) != "0") && (exNE.getMobNumAtPos(3) != "0") && (exNE.getMobNumAtPos(4) != "0") && (exNE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(l) && newRoom.getExitNE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("east".equalsIgnoreCase(l) && newRoom.getExitE() != 0) {
			System.out.println("You see " + exE.getRoomShortDesc() + ".");
			if ((exE.getMobNumAtPos(0) != "0") && (exE.getMobNumAtPos(1) != "0") && (exE.getMobNumAtPos(2) != "0") && (exE.getMobNumAtPos(3) != "0") && (exE.getMobNumAtPos(4) != "0") && (exE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("east".equalsIgnoreCase(l) && newRoom.getExitE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south east".equalsIgnoreCase(l) && newRoom.getExitSE() != 0) {
			System.out.println("You see " + exSE.getRoomShortDesc() + ".");
			if ((exSE.getMobNumAtPos(0) != "0") && (exSE.getMobNumAtPos(1) != "0") && (exSE.getMobNumAtPos(2) != "0") && (exSE.getMobNumAtPos(3) != "0") && (exSE.getMobNumAtPos(4) != "0") && (exSE.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south east".equalsIgnoreCase(l) && newRoom.getExitSE() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south".equalsIgnoreCase(l) && newRoom.getExitS() != 0) {
			System.out.println("You see " + exS.getRoomShortDesc() + ".");
			if ((exS.getMobNumAtPos(0) != "0") && (exS.getMobNumAtPos(1) != "0") && (exS.getMobNumAtPos(2) != "0") && (exS.getMobNumAtPos(3) != "0") && (exS.getMobNumAtPos(4) != "0") && (exS.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south".equalsIgnoreCase(l) && newRoom.getExitS() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south west".equalsIgnoreCase(l) && newRoom.getExitSW() != 0) {
			System.out.println("You see " + exSW.getRoomShortDesc() + ".");
			if ((exSW.getMobNumAtPos(0) != "0") && (exSW.getMobNumAtPos(1) != "0") && (exSW.getMobNumAtPos(2) != "0") && (exSW.getMobNumAtPos(3) != "0") && (exSW.getMobNumAtPos(4) != "0") && (exSW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south west".equalsIgnoreCase(l) && newRoom.getExitSW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("west".equalsIgnoreCase(l) && newRoom.getExitW() != 0) {
			System.out.println("You see " + exW.getRoomShortDesc() + ".");
			if ((exW.getMobNumAtPos(0) != "0") && (exW.getMobNumAtPos(1) != "0") && (exW.getMobNumAtPos(2) != "0") && (exW.getMobNumAtPos(3) != "0") && (exW.getMobNumAtPos(4) != "0") && (exW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("west".equalsIgnoreCase(l) && newRoom.getExitW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north west".equalsIgnoreCase(l) && newRoom.getExitNW() != 0) {
			System.out.println("You see " + exNW.getRoomShortDesc() + ".");
			if ((exNW.getMobNumAtPos(0) != "0") && (exNW.getMobNumAtPos(1) != "0") && (exNW.getMobNumAtPos(2) != "0") && (exNW.getMobNumAtPos(3) != "0") && (exNW.getMobNumAtPos(4) != "0") && (exNW.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north west".equalsIgnoreCase(l) && newRoom.getExitNW() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("up".equalsIgnoreCase(l) && newRoom.getExitU() != 0) {
			System.out.println("You see " + exU.getRoomShortDesc() + ".");
			if ((exU.getMobNumAtPos(0) != "0") && (exU.getMobNumAtPos(1) != "0") && (exU.getMobNumAtPos(2) != "0") && (exU.getMobNumAtPos(3) != "0") && (exU.getMobNumAtPos(4) != "0") && (exU.getMobNumAtPos(5) != "0")) {
				//	System.out.println("no creatures");
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("up".equalsIgnoreCase(l) && newRoom.getExitU() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("down".equalsIgnoreCase(l) && newRoom.getExitD() != 0) {
			System.out.println("You see " + exD.getRoomShortDesc() + ".");
			if ((exD.getMobNumAtPos(0) != "0") && (exD.getMobNumAtPos(1) != "0") && (exD.getMobNumAtPos(2) != "0") && (exD.getMobNumAtPos(3) != "0") && (exD.getMobNumAtPos(4) != "0") && (exD.getMobNumAtPos(5) != "0")) {
				//	System.out.println("1"); // you see no creatures
			}
			else { System.out.println("You see some shadows stirring in the other room.2"); }
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("down".equalsIgnoreCase(l) && newRoom.getExitD() == 0) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}




	} // end look()


	private static void castFireball(player p, mob m) throws Exception {

		int fireballCost = 50; // fireball costs 50 mana
		if (p.getPlayerMP() < fireballCost) {
			System.out.println("You do not have enough mana to cast that spell.");

		}
		else {
			p.setPlayerMP(p.getPlayerMP() - fireballCost);

			System.out.println(p.getPlayerName() + " attempts to cast Fireball at " + m.getShortDesc() + ".");

			int max = (p.getIntel())/2;
			int min = 1;
			Random rand = new Random();

			int randomNum = rand.nextInt((max - min) + 1) + 10;
			System.out.println("You shoot a ball of flames at " + m.getMobShortDesc() + ", hitting them for " + randomNum + " damage.");
			m.setMobHP(m.getMobHP() - randomNum);


			if (m.getMobHP()<=0) {
				System.out.println("Your Fireball has killed " + m.getMobShortDesc() + ".");
			}
			if (m.getMobHP()<=0){
				// death stuff
				System.out.println(m.getMobName() + " has died.");
				System.out.println("Player HPs: " + p.getPlayerHP());
				m.setmobIsAlive(0);
				//	checkXP();
				//	p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
				//	System.out.println("You have gained " + m.getMobXPVal() + " xp.");
				//	System.out.println("Your current xp is " + p.getPlayerXP());

				deathStuff(m);

			} // end if mob hp <= 0
			attackTar3b(p, m, 1);
		} // end successful cast of Fireball
	} // end of castFireball

	private static void castCosmos(player p, mob m) throws Exception {

		int cosmosCost = 35; // cosmos costs 35 mana
		p.setPlayerMP(p.getPlayerMP() - cosmosCost);

		System.out.println(p.getPlayerName() + " attempts to cast Cosmos Arrow of Pain at " + m.getShortDesc());

		int max = (p.getIntel())/2;
		int min = 1;
		Random rand = new Random();

		int randomNum = rand.nextInt((max - min) + 1);
		System.out.println("You fire a shadowy arrow dealing " + randomNum + " damage.");
		m.setMobHP(m.getMobHP() - randomNum);
		if (m.getMobHP()<=0) {
			System.out.println("Your Cosmos Arrows of Pain have killed " + m.getMobShortDesc());
		}
		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		randomNum = rand.nextInt((max - min) + 1);
		System.out.println("You fire a shadowy arrow dealing " + randomNum + " damage.");
		m.setMobHP(m.getMobHP() - randomNum);
		if (m.getMobHP()<=0) {
			System.out.println("Your Cosmos Arrows of Pain burn " + m.getMobShortDesc() + " to a crisp.");
		}
		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		randomNum = rand.nextInt((max - min) + 1);
		System.out.println("You fire a shadowy arrow dealing " + randomNum + " damage.");
		m.setMobHP(m.getMobHP() - randomNum);
		if (m.getMobHP()<=0) {
			System.out.println("Your Cosmos Arrows of Pain burn " + m.getMobShortDesc() + " to a crisp.");
		}
		System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() +   " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMobMP() + "/" + m.getMaxMP());
		System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
				"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
				playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

		// put in a pause
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		if (m.getMobHP()<=0){
			// death stuff
			System.out.println(m.getMobName() + " has died.");
			System.out.println("Player HPs: " + p.getPlayerHP());
			m.setmobIsAlive(0);
			//	checkXP();
			//	p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
			//	System.out.println("You have gained " + m.getMobXPVal() + " xp.");
			//	System.out.println("Your current xp is " + p.getPlayerXP());

			deathStuff(m);

		}

		try {
			attackTar3b(p, m, 1);

		} catch (IOException e) {

			e.printStackTrace();
		}
		//	RegenTask3(); // works here runs indefinately till back at Max MP, halts all input till MP is full
	} // end castCosmos()




	@SuppressWarnings("unused")
	private static void breakStuff(objects o) throws Exception {
		System.out.println("You have broken " + o.getObjShortDesc());
		o.setObjShortDesc("the remains of " + o.getObjShortDesc() + ".");		// if container, drop stuff?


		kinput = input.nextLine();
		commandAnalyzer(kinput);
	}

	private static void deathStuff(mob m) {
		// XP, Coins, Potions on mob death based on mob Lvl
		//		System.out.println(m.getMobName() + " has died.");
		System.out.print("Player HPs: " + player1.getPlayerHP());
		System.out.println("  Player MPs: " + player1.getPlayerMP());

		m.setmobIsAlive(0);
		m.setAttackable(0);

		/*
		 *   lvl 1 mob = 75 XP
		 *   mob XP = 75 * (1.2^mob lvl)
		 * 	 player XP decreased by 20% per level ABOVE the mobs
		 *   player XP increases by 20% per level BELOW the mobs
		 *   (m.getMobXPVal() * (1 + (0.2*(m.getMobLvl() - player1.getPlayerLvl()))));
		 *
		 *   being in a group/party increases mob XP to (2 * mob XP)/(# party members)
		 *
		 *   (((player1.getPlayerLvl() - m.getMobLvl())*0.2) * m.getMobXPVal());
		 */

		// XP gained
		int xpgained = 0;

		int lvlDiff = m.getMobLvl() - player1.getPlayerLvl();
		if (lvlDiff < 0) {
			xpgained = (int) (m.getMobXPVal() * (1 + (0.2*(m.getMobLvl() - player1.getPlayerLvl()))));
			System.out.println("Mob/Player level diff: " + (m.getMobLvl() - player1.getPlayerLvl()) + " levels.");
			player1.setPlayerXP(player1.getPlayerXP() + xpgained);
			System.out.print("Mob default XP: " + m.getMobXPVal() + ".  ");
			System.out.println("You have gained " + xpgained + " xp.");
			checkXP(xpgained);
		}
		if  (lvlDiff == 0) {
			xpgained = m.getMobXPVal();
			System.out.println("Mob/Player level diff: " + (m.getMobLvl() - player1.getPlayerLvl()) + " levels.");
			player1.setPlayerXP(player1.getPlayerXP() + xpgained);
			System.out.print("Mob default XP: " + m.getMobXPVal() + ".  ");
			System.out.println("You have gained " + xpgained + " xp.");
			checkXP(xpgained);
		}
		if (lvlDiff > 0) {
			xpgained = (int) (m.getMobXPVal() * ((0.2*(m.getMobLvl() - player1.getPlayerLvl()))));
			System.out.println("Mob/Player level diff: " + (m.getMobLvl() - player1.getPlayerLvl()) + " levels.");
			player1.setPlayerXP(player1.getPlayerXP() + xpgained);
			System.out.print("Mob default XP: " + m.getMobXPVal() + ".  ");
			System.out.println("You have gained " + xpgained + " xp.");
			checkXP(xpgained);
		}


		// coins gained
		int ccoinsgained = 0;
		int scoinsgained = 0;
		int gcoinsgained = 0;
		int pcoinsgained = 0;
		// random copper coins based on mob level
		for (int i = 0; i < m.getMobLvl(); i++) {
			ccoinsgained = ccoinsgained + roll(0,10);
			//	playerinventory.setPmobcopper(playerinventory.getPmobcopper() + roll(0,20));
		}

		if ((5 < m.getMobLvl()) && (m.getMobLvl() < 9)) {
			for (int i = 0; i < 5; i++) {
				ccoinsgained = ccoinsgained + roll(0,10);
				scoinsgained = scoinsgained + roll(0,2);
			}
		}
		if ((10 < m.getMobLvl()) &&  (m.getMobLvl() < 15)) {
			for (int i = 0; i < 5; i++) {
				ccoinsgained = ccoinsgained + roll(0,10);
				scoinsgained = scoinsgained + roll(0,4);
			}
		}
		if ((15 < m.getMobLvl()) &&  (m.getMobLvl() <= 19)) {
			for (int i = 0; i < 5; i++) {
				ccoinsgained = ccoinsgained + roll(0,50);
				gcoinsgained = gcoinsgained + roll(0,1);
				scoinsgained = scoinsgained + roll(0,4);
			}
		}
		if ((20 < m.getMobLvl()) &&  (m.getMobLvl() <= 24)) {
			for (int i = 0; i < 5; i++) {
				ccoinsgained = ccoinsgained + roll(0,100);
				gcoinsgained = gcoinsgained + roll(0,2);
				scoinsgained = scoinsgained + roll(0,6);
			}
		}
		if ((25 < m.getMobLvl()) &&  (m.getMobLvl() <= 31)) {
			for (int i = 0; i < 5; i++) {
				ccoinsgained = ccoinsgained + roll(0,100);
				pcoinsgained = pcoinsgained + roll(0,1);
				gcoinsgained = gcoinsgained + roll(0,3);
				scoinsgained = scoinsgained + roll(0,8);
			}
		}


		playerinventory.setPmobcopper(playerinventory.getPmobcopper() + ccoinsgained);
		playerinventory.setPmobsilver(playerinventory.getPmobsilver() + scoinsgained);
		playerinventory.setPmobgold(playerinventory.getPmobgold() + gcoinsgained);
		playerinventory.setPmobplat(playerinventory.getPmobplat() + pcoinsgained);
		System.out.println("You have gained " + pcoinsgained + "p, " + gcoinsgained + "g, " + scoinsgained + "s, " + ccoinsgained + "c coins.");




		// H pots gained by level
		int LHP = 0;
		int HP = 0;
		int GHP = 0;
		int MHP = 0;
		if ((0 < m.getMobLvl()) && (m.getMobLvl() < 6)) {
			for (int i = 0; i < 5; i++) {
				int lhpperc = roll(0,100);
				switch (lhpperc) {
				case 1:{
					playerinventory.setPmobLHPot(playerinventory.getPmobLHPot() + 1);
					//System.out.println("You have gained a Lesser Healing Potion.");
					LHP = LHP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobLHPot(playerinventory.getPmobLHPot() + 1);
					//System.out.println("You have gained a Lesser Healing Potion.");
					LHP = LHP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (LHP != 0) {	System.out.println("You have gained " + LHP + " Lesser Healing Pots."); }
		}
		if ((6 < m.getMobLvl()) && (m.getMobLvl() < 12)) {
			for (int i = 0; i < 5; i++) {
				int hpperc = roll(0,100);
				switch (hpperc) {
				case 1:{
					playerinventory.setPmobHPot(playerinventory.getPmobHPot() + 1);
					//System.out.println("You have gained a Healing Potion.");
					HP = HP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobHPot(playerinventory.getPmobHPot() + 1);
					//System.out.println("You have gained a Healing Potion.");
					HP = HP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (HP != 0) {	System.out.println("You have gained " + HP + " Healing Pots."); }
		}
		if ((12 < m.getMobLvl()) && (m.getMobLvl() < 18)) {
			for (int i = 0; i < 5; i++) {
				int ghpperc = roll(0,100);
				switch (ghpperc) {
				case 1:{
					playerinventory.setPmobGHPot(playerinventory.getPmobGHPot() + 1);
					//System.out.println("You have gained a Greater Healing Potion.");
					GHP = GHP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobGHPot(playerinventory.getPmobGHPot() + 1);
					//System.out.println("You have gained a Greater Healing Potion.");
					GHP = GHP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (GHP != 0) {	System.out.println("You have gained " + GHP + " Greater Healing Pots."); }
		}
		if ((18 < m.getMobLvl()) && (m.getMobLvl() < 24)) {
			for (int i = 0; i < 5; i++) {
				int mhpperc = roll(0,100);
				switch (mhpperc) {
				case 1:{
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (MHP != 0) {	System.out.println("You have gained " + MHP + " Major Healing Pots."); }
		}

		if ((24 < m.getMobLvl()) && (m.getMobLvl() < 30)) {
			for (int i = 0; i < 5; i++) {
				int mhpperc = roll(0,100);
				switch (mhpperc) {
				case 1:{
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				case 3:{
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				case 4:{
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				case 5:{
					playerinventory.setPmobMHPot(playerinventory.getPmobMHPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MHP = MHP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (MHP != 0) {	System.out.println("You have gained " + MHP + " Major Healing Pots."); }
		}
		// end of H Pots


		// M pots gained by level
		int LMP = 0;
		int MP = 0;
		int GMP = 0;
		int MMP = 0;
		if ((0 < m.getMobLvl()) && (m.getMobLvl() < 6)) {
			for (int i = 0; i < 5; i++) {
				int lmpperc = roll(0,100);
				switch (lmpperc) {
				case 1:{
					playerinventory.setPmobLMPot(playerinventory.getPmobLMPot() + 1);
					//System.out.println("You have gained a Lesser Healing Potion.");
					LMP = LMP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobLMPot(playerinventory.getPmobLMPot() + 1);
					//System.out.println("You have gained a Lesser Healing Potion.");
					LMP = LMP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (LMP != 0) {	System.out.println("You have gained " + LMP + " Lesser Mana Pots."); }
		}
		if ((6 < m.getMobLvl()) && (m.getMobLvl() < 12)) {
			for (int i = 0; i < 5; i++) {
				int mpperc = roll(0,100);
				switch (mpperc) {
				case 1:{
					playerinventory.setPmobMPot(playerinventory.getPmobMPot() + 1);
					//System.out.println("You have gained a Healing Potion.");
					MP = MP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobMPot(playerinventory.getPmobMPot() + 1);
					//System.out.println("You have gained a Healing Potion.");
					MP = MP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (MP != 0) {	System.out.println("You have gained " + MP + " Mana Pots."); }
		}
		if ((12 < m.getMobLvl()) && (m.getMobLvl() < 18)) {
			for (int i = 0; i < 5; i++) {
				int gmpperc = roll(0,100);
				switch (gmpperc) {
				case 1:{
					playerinventory.setPmobGMPot(playerinventory.getPmobGMPot() + 1);
					//System.out.println("You have gained a Greater Healing Potion.");
					GMP = GMP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobGMPot(playerinventory.getPmobGMPot() + 1);
					//System.out.println("You have gained a Greater Healing Potion.");
					GMP = GMP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (GMP != 0) {	System.out.println("You have gained " + GMP + " Greater Mana Pots."); }
		}
		if ((18 < m.getMobLvl()) && (m.getMobLvl() < 24)) {
			for (int i = 0; i < 5; i++) {
				int mmpperc = roll(0,100);
				switch (mmpperc) {
				case 1:{
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				default: { }
				}
			} // end for (int i = 0; i < 5; i++)
			if (MMP != 0) {	System.out.println("You have gained " + MMP + " Major Mana Pots."); }
		}
		if ((24 < m.getMobLvl()) && (m.getMobLvl() < 30)) {
			for (int i = 0; i < 5; i++) {
				int mmpperc = roll(0,100);
				switch (mmpperc) {
				case 1:{
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				case 2: {
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				case 3: {
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				case 4: {
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				case 5: {
					playerinventory.setPmobMMPot(playerinventory.getPmobMMPot() + 1);
					//System.out.println("You have gained a Major Healing Potion.");
					MMP = MMP + 1;
					break;
				}
				default: { }
				} // end switch
			} // end for (int i = 0; i < 5; i++)
			if (MMP != 0) {	System.out.println("You have gained " + MMP + " Major Mana Pots."); }
		}
		// end of M Pots


		System.out.println("Player HPs: " + player1.getPlayerHP() + "/" + player1.getPlayerMaxHP() + " Player MPs: " + player1.getPlayerMP() + "/" + player1.getPlayerMaxMP() );
		System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLHPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
				"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
				playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

		// add item loots here?

		mobItemstoInventory(m);

		writeMobToArray(m);
		writeMobInvArray(m);


	} // end deathStuff() // loot stuffs


	// if mob has items, move them to player inventory
	private static void mobItemstoInventory(mob m) {
		// if mob inv has item, move to player inventory
		if (m0inv0.getObjNum() > -1 ) {


		}

	}




	private static void checkXP(int xp) {
		// check to see if the XP is enough to level up
		if(player1.getPlayerLvl() < 1) {
			if ((player1.getPlayerXP() + xp) <= xplvl1) {
				// System.out.println("do nothing");
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 2) {
			if ((player1.getPlayerXP() + xp) <= xplvl2) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 3) {
			if ((player1.getPlayerXP() + xp) <= xplvl3) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 4) {
			if ((player1.getPlayerXP() + xp) <= xplvl4) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 5) {
			if ((player1.getPlayerXP() + xp) <= xplvl5) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 6) {
			if ((player1.getPlayerXP() + xp) <= xplvl6) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 7) {
			if ((player1.getPlayerXP() + xp) <= xplvl7) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 8) {
			if ((player1.getPlayerXP() + xp) <= xplvl8) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 9) {
			if ((player1.getPlayerXP() + xp) <= xplvl9) {
			}
		}
		if(player1.getPlayerLvl() < 10) {
			if ((player1.getPlayerXP() + xp) <= xplvl10) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 11) {
			if ((player1.getPlayerXP() + xp) <= xplvl11) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 12) {
			if ((player1.getPlayerXP() + xp) <= xplvl12) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 13) {
			if ((player1.getPlayerXP() + xp) <= xplvl13) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 14) {
			if ((player1.getPlayerXP() + xp) <= xplvl14) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 15) {
			if ((player1.getPlayerXP() + xp) <= xplvl15) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 16) {
			if ((player1.getPlayerXP() + xp) <= xplvl16) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 17) {
			if ((player1.getPlayerXP() + xp) <= xplvl17) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 18) {
			if ((player1.getPlayerXP() + xp) <= xplvl18) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 19) {
			if ((player1.getPlayerXP() + xp) <= xplvl19) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 20) {
			if ((player1.getPlayerXP() + xp) <= xplvl20) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 21) {
			if ((player1.getPlayerXP() + xp) <= xplvl21) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 22) {
			if ((player1.getPlayerXP() + xp) <= xplvl22) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 23) {
			if ((player1.getPlayerXP() + xp) <= xplvl23) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 24) {
			if ((player1.getPlayerXP() + xp) <= xplvl24) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 25) {
			if ((player1.getPlayerXP() + xp) <= xplvl25) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 26) {
			if ((player1.getPlayerXP() + xp) <= xplvl26) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 27) {
			if ((player1.getPlayerXP() + xp) <= xplvl27) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 28) {
			if ((player1.getPlayerXP() + xp) <= xplvl28) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 29) {
			if ((player1.getPlayerXP() + xp) <= xplvl29) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 30) {
			if ((player1.getPlayerXP() + xp) <= xplvl30) {
			}
			else {
				levelUp();
			}
		}
		if(player1.getPlayerLvl() < 31) {
			if ((player1.getPlayerXP() + xp) <= xplvl31) {
			}
			else {
				levelUp();
			}
		}
	}// end checkXP


	private static void moblvlUp(mob m, int lvl) {
		// 
		// for use with defaults when making mobs
		// levels the mob up to the appropriate level
		/*
		 * mob defaults
		m.setMobHP(100);
		m.setMobMP(100);
		m.setStam(10);
		m.setStr(10);
		m.setIntel(10);
		m.setAgility(10);
		 */
		//	m.resetStats();

		for (int i=0; i < lvl; i++) {
			int ckStr = roll(1,3);
			int ckStam = roll(1,3);
			int ckInt = roll(1,3);
			int ckAgi = roll(1,3);


			switch (ckStr) {
			case 1:{
				m.setStr(m.getStr() + 1);
				//	System.out.println("Tough break, man. No strength gained.");
				break;
			}
			case 2:{
				m.setStr(m.getStr() + 1);
				//	System.out.println("You have gained 1 strength.");
				break;
			}
			case 3:{
				//	System.out.println("You have gained 1 strength.");
				break;
			}
			default: { }
			}
			switch (ckStam) {
			case 1:{
				m.setStam(m.getStam() + 1);
				//	System.out.println("Tough break, man. No stamina gained");
				break;
			}
			case 2:{
				m.setStam(m.getStam() + 1);
				//	System.out.println("You have gained 1 stamina.");
				break;
			}
			case 3:{

				//	System.out.println("You have gained 1 stamina.");
				break;
			}
			default: { }
			}
			switch (ckInt) {
			case 1:{
				m.setIntel(m.getIntel() + 1);
				//	System.out.println("Tough break, man. No intellect gained.");
				break;
			}
			case 2:{
				m.setIntel(m.getIntel() + 1);
				//	System.out.println("You have gained 1 intellect.");
				break;
			}
			case 3: {

				//	System.out.println("You have gained 1 intellect.");
				break;
			}
			default: { }
			}
			switch (ckAgi) {
			case 1:{
				//	System.out.println("Tough break, man. No agility gained.");
				break;
			}
			case 2:{
				m.setAgility(m.getAgility() + 1);
				//	System.out.println("You have gained 1 Agility.");
				break;
			}
			case 3:{
				m.setAgility(m.getAgility() + 1);
				//	System.out.println("You have gained 1 Agility.");
				break;
			}
			default: { }

			} // end switch ckAgi


			// XP increaser
			// this works
			int newXP = (int) Math.round(m.getMobXPVal() * 1.15);
			m.setMobXPVal(newXP);


			// end XP increaser



			// increment mob HP/MP
			// not working :( another function must be checking these values
			int newMaxHP = m.getMaxHP() + 50;
			int newMaxMP = m.getMaxMP() + 50;
			m.setMaxHP(newMaxHP);
			m.setMaxMP(newMaxMP);



		} // end for loop

		try {
			msave();
		} catch (IOException e) {

			e.printStackTrace();
		}
	} // end moblvlUp(int lvl)

	private static void talker() {
		// if mob is talker, makes random speech from mobs list v47, v48, v49
		// currently works, set to run on the suntimer schedule (morning, noon, evening, night)
		// says 1 random line, or nothing from the mobs speech lines
		if (tmob0.getMobIsAlive() == 1) {
			//	System.out.println("Mob is alive");
			int t = tmob0.getV46();
			//	System.out.println(tmob5.getV46());
			if (t == 1)  {
				//		System.out.println("Mob is talker");
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1;
				switch (strand) {
				case 1: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				case 3: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob0.getMobName() + " says '" + tmob0.getV49() + "'");
						break;
					}
					case 4: {
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)

			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob0.getAlive() == 1)	
		if (tmob1.getMobIsAlive() == 1) {
			//	System.out.println("Mob is alive");
			int t = tmob1.getV46();
			//	System.out.println(tmob5.getV46());
			if (t == 1)  {
				//		System.out.println("Mob is talker");
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1;
				switch (strand) {
				case 1: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				case 3: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob1.getMobName() + " says '" + tmob1.getV49() + "'");
						break;
					}
					case 4: {
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)

			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob1.getAlive() == 1)	
		if (tmob2.getMobIsAlive() == 1) {
			//	System.out.println("Mob is alive");
			int t = tmob2.getV46();
			//	System.out.println(tmob5.getV46());
			if (t == 1)  {
				//		System.out.println("Mob is talker");
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1;
				switch (strand) {
				case 1: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				case 3: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob2.getMobName() + " says '" + tmob2.getV49() + "'");
						break;
					}
					case 4: {
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)

			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob2.getAlive() == 1)
		if (tmob3.getMobIsAlive() == 1) {
			//	System.out.println("Mob is alive");
			int t = tmob3.getV46();
			//	System.out.println(tmob5.getV46());
			if (t == 1)  {
				//		System.out.println("Mob is talker");
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1;
				switch (strand) {
				case 1: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				case 3: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob3.getMobName() + " says '" + tmob3.getV49() + "'");
						break;
					}
					case 4: {
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)

			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob3.getAlive() == 1)	
		if (tmob4.getMobIsAlive() == 1) {
			//	System.out.println("Mob is alive");
			int t = tmob4.getV46();
			//	System.out.println(tmob5.getV46());
			if (t == 1)  {
				//		System.out.println("Mob is talker");
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1;
				switch (strand) {
				case 1: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				case 3: {
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob4.getMobName() + " says '" + tmob4.getV49() + "'");
						break;
					}
					case 4: {
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)

			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob4.getAlive() == 1)	
		if (tmob5.getMobIsAlive() == 1) { // mob is alive
			int t = tmob5.getV46();
			if (t == 1)  {
				Random speechTimer = new Random();
				int strand = speechTimer.nextInt(4) + 1; // rand num 1-4, 1-3 says something, 4 does nothing
				switch (strand) {
				case 1: { // case 1, say something
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1; // pick rand num 1-3, used to switch up the msg order
					switch (smsg) { // output random msg
					case 1: { // msg 1
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV47() + "'");
						break;
					}
					case 2: { // msg 2
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV48() + "'");
						break;
					}
					case 3: { //msg 3
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 2
				case 2: { // case 2, say something
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: { // msg 1
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV47() + "'");
						break;
					}
					case 2: { // msg 2
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV48() + "'");
						break;
					}
					case 3: { // msg 3
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV49() + "'");
						break;
					}
					default: {}
					}
					break;
				}
				// case 3
				case 3: { // case 3, say something
					Random speechMsg = new Random();
					int smsg = speechMsg.nextInt(3) + 1;
					switch (smsg) {
					case 1: {
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV47() + "'");
						break;
					}
					case 2: {
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV48() + "'");
						break;
					}
					case 3: {
						System.out.println(tmob5.getMobName() + " says '" + tmob5.getV49() + "'");
						break;
					}
					case 4: { // case 4, say nothing
						break;
					}
					default: {}
					}
					break;
				}		
				default: {}
				} // end switch(strand)
			} // end if
			//else { System.out.println("Mob not talker"); }
		} // end if(tmob5.getAlive() == 1)	

	}// end talker()


	@SuppressWarnings("unused")
	private static void tierUp() {
		// TODO raise stats by tier amounts
		/*
		 * 	Player Tier ranks:
		 * 		players can have ranks, higher ranks increase their health and damage and available spells/abilities
		 * 		Tier 0 - default tier
		 * 		Tier 1 - hp, dps increase by 125%? or flat amount?
		 * 		Tier 2 - hp, dps increase 150%
		 * 		Tier 3 - hp, dps increase 175%
		 * 		Tier 4 - hp, dps increase 200%
		 * 		Tier Imm - hp, dps increase 1000%
		 * 		Tier GImm - access to dev tools
		 */
		/*
		 * 	mob ranks:
		 * 		mobs can have ranks, higher ranks increase their health and damage
		 * 		tier 0/null/common/normal - hp, dps the same
		 * 		tier 1/elite - hp, dps increase by 125%
		 * 		tier 2/chieftain - hp, dps increase 150%
		 * 		tier 3/lord - hp, dps increase 175%
		 * 		high lord - hp, dps increase 200%
		 * 		great lord - hp, dps increase 225%
		 * 		grand lord - hp, dps increase 250%
		 * 		Mythic - hp, dps increase 300%
		 * 		Archaic Species - hp, dps increase by 750%
		 * 		God Rank - hp, dps increase 1000%
		 */
	}

	private static void levelUp() {
		// chance to add 1 to each stat, reset XP to 0
		System.out.println("Congratulations! You have gained a level!");
		// roll to see if stat is gained
		int ckStr = roll(1,3);
		int ckStam = roll(1,3);
		int ckInt = roll(1,3);
		int ckAgi = roll(1,3);

		switch (ckStr) {
		case 1:
			System.out.println("Tough break man. No Strength gained.");
			break;
		case 2:
			player1.setStr(player1.getStr() + 1);
			System.out.println("You have gained 1 Strength.");
			break;
		case 3:
			player1.setStr(player1.getStr() + 1);
			System.out.println("You have gained 1 Strength.");
			break;
		default: { }
		}
		switch (ckStam) {
		case 1:
			System.out.println("Tough break man. No Stamina gained");
			break;
		case 2:
			player1.setStam(player1.getStam() + 1);
			System.out.println("You have gained 1 Stamina.");
			break;
		case 3:
			player1.setStam(player1.getStam() + 1);
			System.out.println("You have gained 1 Stamina.");
			break;
		default: { }
		}
		switch (ckInt) {
		case 1:
			System.out.println("Tough break man. No Intellect gained.");
			break;
		case 2:
			player1.setIntel(player1.getIntel() + 1);
			System.out.println("You have gained 1 Intellect.");
			break;
		case 3:
			player1.setIntel(player1.getIntel() + 1);
			System.out.println("You have gained 1 Intellect.");
			break;
		default: { }
		}
		switch (ckAgi) {
		case 1:
			System.out.println("Tough break man. No Agility gained.");
			break;
		case 2:
			player1.setAgility(player1.getAgility() + 1);
			System.out.println("You have gained 1 Agility.");
			break;
		case 3:
			player1.setAgility(player1.getAgility() + 1);
			System.out.println("You have gained 1 Agility.");
			break;
		default: { }
		}

		player1.setPlayerLvl(player1.getPlayerLvl() + 1); // add a level!
		player1.setPlayerXP(0); // set XP back to 0
		System.out.println("Resetting XP to 0.");

		// show how much XP to level
		xptoLevel();

		checkPlayerMaxHP();
		checkPlayerMaxMP();
		player1.setPlayerHP(player1.getPlayerMaxHP());
		player1.setPlayerMP(player1.getPlayerMaxMP());

	}// end levelUp

	public static double calculatePercentage(double obtained, double total) {
		// calculates a percentage
		return obtained * 100 / total;
	}

	private static void xptoLevel() {
		// tells the player how much XP they need to reach the next level
		System.out.println("From xptoLevel()");

		switch(player1.getPlayerLvl()) {
		case 0: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl1) + " to reach level 1.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl1);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 1: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl2) + " to reach level 2.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl2);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 2: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl3) + " to reach level 3.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl3);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 3: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl4) + " to reach level 4.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl4);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 4: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl5) + " to reach level 5.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl5);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 5: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl6) + " to reach level 6.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl6);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 6: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl7) + " to reach level 7.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl7);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 7: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl8) + " to reach level 8.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl8);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 8: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl9) + " to reach level 9.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl9);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 9: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl10) + " to reach level 10");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl10);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 10: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl11) + " to reach level 11.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl11);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 11: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl12) + " to reach level 12.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl12);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 12: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl13) + " to level 13.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl13);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 13: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl14) + " to level 14.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl4);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 14: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl15) + " to level 15.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl15);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 15: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(-player1.getPlayerXP() - xplvl16) + " to level 16.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl16);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 16: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl17) + " to level 17.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl17);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 17: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl18) + " to level 18.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl18);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 18: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl19) + " to level 19.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl19);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 19: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl20) + " to level 20.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl20);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 20: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need" + -1*(player1.getPlayerXP() - xplvl21) + " to level 21.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl21);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 21: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl22) + " to level 22.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl22);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 22: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl23) + " to level 23.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl23);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 23: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl24) + " to level 24.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl24);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 24: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl25) + " to level 25.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl25);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 25: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl26) + " to level 26.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl26);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 26: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl27) + " to level 27.");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl27);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 27: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl28) + " to level 28");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl28);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 28: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl29) + " to level 29");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl29);
			System.out.println("You are " + perc + " of the way done with this level.");
			break;
		}
		case 29: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl30) + " to level 30");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl30);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		case 30: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You have " + player1.getPlayerXP() + " xp.");
			System.out.println("You need " + -1*(player1.getPlayerXP() - xplvl31) + " to level 31");
			double perc = calculatePercentage( player1.getPlayerXP(), xplvl31);
			System.out.println("You are " + perc + "% of the way done with this level.");
			break;
		}
		default: {
			System.out.println("Player level: " + player1.getPlayerLvl());
			System.out.println("You cannot gain anymore XP.");
		}


		}// end switch(player1.getPlayerLvl())

	} // end xptoLevel()



	private static void castHealingRain(player player12) {
		// TODO Auto-generated method stub
		// HoT's not avail right now




	}


	// heals for between 30-40% player max health per cast
	private static void castCureCrit(player p) {
		//int hCost = 50;
		int hCost2 = (int) p.getPlayerMaxMP()/100 * 30; // cure crit costs 30% max mana

		int max = (int) (p.getPlayerMaxHP()/100) * 40; // max is 40% of max HP
		int min = (int) (p.getPlayerMaxHP()/100) * 30; // min is 30% of max HP

		if (p.getPlayerMP() >= hCost2) {
			p.setPlayerMP(p.getPlayerMP() - hCost2);
			Random rand = new Random();

			int hrand = rand.nextInt((max - min) + 1) + min;
			System.out.println("You cast Cure Critical Wounds at " + p.getPlayerName());
			System.out.println("Healing " + p.getPlayerName() + " for " + hrand + " health at the cost of " + hCost2 + " mana.");
			if ((p.getPlayerHP() + hrand) < p.getPlayerMaxHP()) {
				p.setPlayerHP(p.getPlayerHP() + hrand);
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}
			else {
				p.setPlayerHP(p.getPlayerMaxHP());
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}
		}
		else {
			System.out.println("You do not have enough mana for that.");
		}
	} // end castCureCrit(player p)


	// heals for between 20 - 30% player max health per cast
	private static void castCureSer(player p) {

		// int hCost = 35;
		int hCost2 = (int) p.getPlayerMaxMP()/100 * 20;  // cure-serious costs 20% max mana

		int max = (int) (p.getPlayerMaxHP()/100) * 30; // max is 30% of max HP
		int min = (int) (p.getPlayerMaxHP()/100) * 20; // min is 20% of max HP

		if (p.getPlayerMP() >= hCost2) {
			p.setPlayerMP(p.getPlayerMP() - hCost2);
			Random rand = new Random();

			int hrand = rand.nextInt((max - min) + 1) + min;
			System.out.println("You cast Cure Serious Wounds at " + p.getPlayerName());
			System.out.println("Healing " + p.getPlayerName() + " for " + hrand + " health at the cost of " + hCost2 + " mana.");
			if ((p.getPlayerHP() + hrand) < p.getPlayerMaxHP()) {
				p.setPlayerHP(p.getPlayerHP() + hrand);
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}
			else {
				p.setPlayerHP(p.getPlayerMaxHP());
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}
		}
		else {
			System.out.println("You do not have enough mana for that.");
		}
	} // end castHeal


	// heals for between 10-20% player max health per cast
	private static void castCureLight(player p) {
		//int lhCost = 20; // currently spell cost is static
		int hCost2 = (int) p.getPlayerMaxMP()/100 * 10; // cure-light costs 20% max mana

		int max = (int) (p.getPlayerMaxHP()/100) * 20; // max is 20% of max HP
		int min = (int) (p.getPlayerMaxHP()/100) * 10; // min is 10% of max HP

		if (p.getPlayerMP() >= hCost2) {
			p.setPlayerMP(p.getPlayerMP() - hCost2);
			Random rand = new Random();

			int hrand = rand.nextInt((max - min) + 1) + min;
			System.out.println("You cast Cure Light Wounds at " + p.getPlayerName());
			System.out.println("Healing " + p.getPlayerName() + " for " + hrand + " health at the cost of " + hCost2 + " mana.");
			if ((p.getPlayerHP() + hrand) < p.getPlayerMaxHP()) {
				p.setPlayerHP(p.getPlayerHP() + hrand);
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}
			else {
				p.setPlayerHP(p.getPlayerMaxHP());
				System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP());
			}

		}
		else {
			System.out.println("You do not have enough mana for that.");
		}
	} // end castLH()


	public static void attackObj(player p, objects o, int a) throws Exception {
		// attack an object
		if (o.getObjNum() > -1) {
			// obj has 0 or less Durability
			for (int i=0;i < a; i++) {
				// obj dur = 0, "indestructable"
				if (o.durability < 1) {
					System.out.println("You cannot attack " + o.getObjShortDesc() + ".");

					kinput = input.nextLine();
					commandAnalyzer(kinput);
					break;
				}

				else if (o.durability > 0) {
					// TO DO damage obj, break obj, drop objs if container
					int mhmax = p.getStr()/2;
					int mhmin = p.getStr()/4;
					int ohmax = p.getStr()/4;
					int ohmin = p.getStr()/8;

					Random rand = new Random();
					int randomNum;
					int rroll = roll(0,100);
					if (rroll <= (p.getAgility()/4)) {
						randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
						randomNum = randomNum*2;
						System.out.println("Critical Hit! You " + pweapon1.getWpndmgType() + " " + o.getObjName() + " for " + randomNum + " damage.");
						o.setDurability(o.getDurability()-randomNum);
					}
					else {
						randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
						System.out.println("You " + pweapon1.getWpndmgType() + " " + o.getObjName() + " for " + randomNum + " damage.");
						o.setDurability(o.getDurability()-randomNum);
					}
					// end MH attack on obj

					// put OH attacks here
					switch (p.getPlayerClass()) {
					case "barbarian":				{
						rroll = roll(0,100);
						if (rroll <= (p.getAgility())) {
							randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
							if (rroll <= (p.getAgility()/2)) {
								System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
							else {
								System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum/2 + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
						}
						break;
					}

					case "fighter":				{
						rroll = roll(0,100);
						if (rroll <= (p.getAgility())) {
							randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
							if (rroll <= (p.getAgility()/2)) {
								System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
							else {
								System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum/2 + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
						}
						break;
					}

					case "rogue":
					{
						rroll = roll(0,100);
						if (rroll <= (p.getAgility())) {
							randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
							if (rroll <= (p.getAgility()/2)) {
								System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
							else {
								System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + o.getObjName() + " for " + randomNum/2 + " damage.");
								o.setDurability(o.getDurability()-randomNum);
							}
						}
						break;
					}
					default: { }
					}// end switch (m.getPlayerClass())
				}
			}
		}
		else {
			System.out.println("No such object exists.");
		}
	}
	// end attack obj


	public static void attackIndef(player p, mob m) throws Exception {
		// attempts to attack the mob indefinitely
		// not yet working properly
		System.out.println("Attempting to attack " + m.getMobShortDesc() + ".");


		// check to see if in combat, new feature? does nothing right now

		if (inCombat == 0) {
			inCombat = 1;
		}
		else {
			inCombat = 1;
		} // end inCombat check
		while (m.getMobHP() > 0) {
			if (m.getmobIsAlive() == 1) {
				if (p.getPlayerHP() > 0) {
					if(m.getMobHP() > 0) {
						int mdodgeroll = roll(0,100);
						int mdodgechance = m.getAgility()/3;
						if (mdodgeroll >  mdodgechance) {
							int mhmax = p.getStr();
							int mhmin = p.getStr()/2;
							int ohmax = p.getStr()/2;
							int ohmin = p.getStr()/4;
							Random rand = new Random();
							int randomNum;
							int rroll = roll(0,100);
							if (rroll <= (p.getAgility()/2)) {
								randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
								randomNum = randomNum*2;
								System.out.println("Critical Hit! You " + pweapon1.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
								m.setMobHP(m.getMobHP()-randomNum);
							}
							else {
								randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
								System.out.println("You " + pweapon1.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
								m.setMobHP(m.getMobHP()-randomNum);
							}

							// offhand attacks
							switch (p.getPlayerClass()) {
							case "barbarian": {
								rroll = roll(0,100);
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							} // end case "barbarian"
							case "fighter": {
								rroll = roll(0,100);
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							}
							case "rogue": {
								rroll = roll(0,100);
								randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							}
							default: { }
							}// end switch (p.getPlayerClass())

							if (m.getMobHP() > 0) {
								int pdodgeroll = roll(0,100);
								int pdodgechance = player1.getAgility()/3;
								if (pdodgeroll > pdodgechance) {
									int max2 = m.getStr();
									int min2 = m.getStr()/2;
									randomNum = rand.nextInt((max2 - min2) + 1) + min2;
									rroll = roll(0,100);
									if (rroll <= (m.getAgility()/2)) {
										randomNum = randomNum*2;
										System.out.println("Critical Hit! " + m.getMobName() + " " + mweapon1.getWpndmgType() + "s you for " + randomNum + " damage.");
										p.setPlayerHP(p.getPlayerHP()-randomNum);
									}
									else {
										System.out.println(m.getMobName() + " " + mweapon1.getWpndmgType() + "s you for " + randomNum + " damage.");
										p.setPlayerHP(p.getPlayerHP()-randomNum);
									}
									switch (m.getMobClass()) {
									case "barbarian": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "barbarian"
									case "fighter": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "fighter"
									case "rogue": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "rogue
									default: { }
									}// end switch (m.getPlayerClass())

								}
								else {
									System.out.println("You dodged " + m.getMobName() + "'s attack.");
								}

								System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMobMP() + "/" + m.getMaxMP() );
								System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
										"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
										playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());

								//kinput = input.next();  // breaks the loop, takes input from player
								//	commandAnalyzer(kinput);


								// *frownie face* Sorry duder, you died, lets try and log back in to your last save
								// this is an HP check for player health,
								if (p.getPlayerHP() <= 0) {
									p.setPlayerIsAlive(0);
									System.out.println(p.getPlayerName() + " (the player) has died.");
									System.out.println("You have DIED!");
									try {
										TimeUnit.SECONDS.sleep(3);
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}
									System.out.println("Reload your character: " + p.getPlayerName());
									try {
										loginSys3();
									} catch (Exception e) {
										e.printStackTrace();
									}
									break;

								}
								// not sure, this block makes sense but seems redundant, here to be safe
								// this is a STATE check for playerIsAlive, the state changed to 0 in above HP check
								if (p.getPlayerIsAlive() == 0) {
									System.out.println("You have DIED!");
									try {
										TimeUnit.SECONDS.sleep(3);
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}
									System.out.println("Reload your character: " + p.getPlayerName());
									try {
										loginSys3();
									} catch (Exception e) {
										//
										e.printStackTrace();
									}
									break;
								}

								if (m.getMobHP() > 0) {
									// put in a pause
									try {
										TimeUnit.SECONDS.sleep(1);  // pause in seconds
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}

									//	System.out.println("something."); // making sure the loop fires
								}

								// seems like this should be here? I havent seen this one fire
								else {
									System.out.println(m.getMobName() + " has died.");
									System.out.println("Player HPs: " + p.getPlayerHP()+   " Player MPs: " + p.getPlayerMP());
									System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
											"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
											playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
									m.setmobIsAlive(0);
									//		p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
									//		System.out.println("You have gained " + m.getMobXPVal() + " xp.");
									//		System.out.println("Your current xp is " + p.getPlayerXP());
									deathStuff(m);
									//	hpRegen();
									break;
								}
							} // end if(m.getMobHP() > 0)
							// this one gives you the the output on mob death
							else {
								//	System.out.println(m.getMobName() + " has died.2");
								//	System.out.println("Player HPs: " + p.getPlayerHP());
								System.out.println(m.getMobName() + " has died.");
								System.out.println("Player HPs: " + p.getPlayerHP()+   " Player MPs: " + p.getPlayerMP());
								System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
										"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
										playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
								m.setmobIsAlive(0);
								//	p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
								//	System.out.println("You have gained " + m.getMobXPVal() + " xp.");
								//	System.out.println("Your current xp is " + p.getPlayerXP());
								//	RegenTask2();
								deathStuff(m);
								break;
							}

						}
						else {
							System.out.println(m.getMobName() + " dodges your attack.");
						}
					} // end if (m.getMobHP()>0)
				} // end if (p.getPlayerHP() > 0)
				else {
					// not sure, you might be dead here, so lets just reload the character?
					// havent seen this block actually fire, but this SHOULD be here in theory
					System.out.println(p.getPlayerName() + " (the player) has died.2");
					loadPlayer(player1.getPlayerNum()); // reload the player from array (last "save")
				} // end else (p.getPlayerHP() <= 0)
			} // end if(m.getIsAlive() == 1)
			else {
				// **do nothing in this block to complete combat round without further attacks**
				// if m.getMobIsAlive != 1, ie the mob is dead
				System.out.println("It (" + m.getMobShortDesc() + ") is already dead."); // ** MUTE THIS** tells you mob is dead for remaining attacks from combat seq
				System.out.println("Attack a different target."); // **MUTE THIS** reminds you to attack something that is ALIVE
				break;
			}
			if (!input2.isEmpty()) {
				System.out.println("Input received: " + input2);
				input2 = ""; // Clear input
			}
		}
		//	break; // stops loop after 1
		kinput = input.next();  // takes in command after combat sequence ends, which game would have done anyways
		commandAnalyzer(kinput);

	} // end attackIndef

	public static void attackTar3b(player p, mob m, int a) throws Exception {
		// player p is the player doing the attacks, mob m is the mob being attacked, int a is the number of attacks before next command input (0<a<=5 recommended)
		for (int i=0; i < a; i++) {
			if (m.getmobIsAlive() == 1) {
				if (p.getPlayerHP() > 0) {
					if(m.getMobHP() > 0) {
						int mdodgeroll = roll(0,100);
						int mdodgechance = m.getAgility()/3;
						if (mdodgeroll >  mdodgechance) {
							int mhmax = p.getStr();
							int mhmin = p.getStr()/2;
							int ohmax = p.getStr()/2;
							int ohmin = p.getStr()/4;
							Random rand = new Random();
							int randomNum;
							int rroll = roll(0,100);
							if (rroll <= (p.getAgility()/2)) {
								randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
								randomNum = randomNum*2;
								System.out.println("Critical Hit! You " + pweapon1.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
								m.setMobHP(m.getMobHP()-randomNum);
							}
							else {
								randomNum = rand.nextInt((mhmax - mhmin) + 1) + mhmin;
								System.out.println("You " + pweapon1.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
								m.setMobHP(m.getMobHP()-randomNum);
							}

							// offhand attacks
							switch (p.getPlayerClass()) {
							case "barbarian": {
								rroll = roll(0,100);
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							} // end case "barbarian"
							case "fighter": {
								rroll = roll(0,100);
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							}
							case "rogue": {
								rroll = roll(0,100);
								randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
								if (rroll <= (p.getAgility())) {
									randomNum = rand.nextInt((ohmax - ohmin) + 1) + ohmin;
									if (rroll <= (p.getAgility()/2)) {
										System.out.println("Critical Hit! Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
									else {
										System.out.println("Your offhand " + pweapshi.getWpndmgType() + " " + m.getMobName() + " for " + randomNum/2 + " damage.");
										m.setMobHP(m.getMobHP()-randomNum);
									}
								}
								break;
							}
							default: { }
							}// end switch (p.getPlayerClass())


							if (m.getMobHP() > 0) {
								int pdodgeroll = roll(0,100);
								int pdodgechance = player1.getAgility()/3;
								if (pdodgeroll > pdodgechance) {
									int max2 = m.getStr();
									int min2 = m.getStr()/2;
									randomNum = rand.nextInt((max2 - min2) + 1) + min2;
									rroll = roll(0,100);
									if (rroll <= (m.getAgility()/2)) {
										randomNum = randomNum*2;
										System.out.println("Critical Hit! " + m.getMobName() + " " + mweapon1.getWpndmgType() + "s you for " + randomNum + " damage.");
										p.setPlayerHP(p.getPlayerHP()-randomNum);
									}
									else {
										System.out.println(m.getMobName() + " " + mweapon1.getWpndmgType() + "s you for " + randomNum + " damage.");
										p.setPlayerHP(p.getPlayerHP()-randomNum);
									}
									switch (m.getMobClass()) {
									case "barbarian": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "barbarian"
									case "fighter": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "fighter"
									case "rogue": {
										rroll = roll(0,100);
										if (rroll <= (m.getAgility())) {
											if (rroll <= (m.getAgility()/2)) {
												randomNum = randomNum*2;
												System.out.println("Critical Hit! " + m.getMobName() + " offhand " + mweapon1.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
											else {
												System.out.println(m.getMobName() + " offhand" + mweapshi.getWpndmgType() + "s you for " + randomNum/2 + " damage.");
												m.setMobHP(m.getMobHP()-randomNum);
											}
										}
										break;
									} // end case "rogue
									default: { }
									}// end switch (m.getPlayerClass())

								}
								else {
									System.out.println("You dodged " + m.getMobName() + "'s attack.");
								}

								System.out.println("Player HPs: " + p.getPlayerHP() + "/" + p.getPlayerMaxHP() + " Player MPs: " + p.getPlayerMP() + "/" + p.getPlayerMaxMP() + " Mob HPs: " + m.getMobHP() + "/" + m.getMaxHP() + " Mob MPs: " + m.getMobMP() + "/" + m.getMaxMP() );
								System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
										"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
										playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
								// *frownie face* Sorry duder, you died, lets try and log back in to your last save
								// this is an HP check for player health,
								if (p.getPlayerHP() <= 0) {
									p.setPlayerIsAlive(0);
									System.out.println(p.getPlayerName() + " (the player) has died.");
									System.out.println("You have DIED!");
									try {
										TimeUnit.SECONDS.sleep(3);
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}
									System.out.println("Reload your character: " + p.getPlayerName());
									loginSys3();

									break;

								}
								// not sure, this block makes sense but seems redundant, here to be safe
								// this is a STATE check for playerIsAlive, the state changed to 0 in above HP check
								if (p.getPlayerIsAlive() == 0) {
									System.out.println("You have DIED!");
									try {
										TimeUnit.SECONDS.sleep(3);
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}
									System.out.println("Reload your character: " + p.getPlayerName());
									loginSys3();
									break;
								}

								if (m.getMobHP() > 0) {
									// put in a pause
									try {
										TimeUnit.SECONDS.sleep(1);  // pause in seconds
									} catch (InterruptedException ex) {
										ex.printStackTrace();
									}

									//	System.out.println("something."); // making sure the loop fires
								}

								// seems like this should be here? I havent seen this one fire
								else {
									System.out.println(m.getMobName() + " has died.");
									System.out.println("Player HPs: " + p.getPlayerHP()+   " Player MPs: " + p.getPlayerMP());
									System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
											"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
											playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
									m.setmobIsAlive(0);
									//		p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
									//		System.out.println("You have gained " + m.getMobXPVal() + " xp.");
									//		System.out.println("Your current xp is " + p.getPlayerXP());
									deathStuff(m);
									//	hpRegen();
									break;
								}
							} // end if(m.getMobHP() > 0)
							// this one gives you the the output on mob death
							else {
								//	System.out.println(m.getMobName() + " has died.2");
								//	System.out.println("Player HPs: " + p.getPlayerHP());
								System.out.println(m.getMobName() + " has died.");
								System.out.println("Player HPs: " + p.getPlayerHP()+   " Player MPs: " + p.getPlayerMP());
								System.out.println("Lesser H-Pot: " + playerinventory.getPmobLHPot() + "  Lesser M-Pot: " + playerinventory.getPmobLMPot() + "  Healing Pot: "  + playerinventory.getPmobHPot() +
										"  Mana Pot: " + playerinventory.getPmobMPot() + "  Greater H-Pot: " + playerinventory.getPmobGHPot() + "  Greater M-Pot: " + playerinventory.getPmobGMPot() + "  Major H-Pot: " +
										playerinventory.getPmobMHPot() +	"  Major M-Pot: " + playerinventory.getPmobMMPot());
								m.setmobIsAlive(0);
								//	p.setPlayerXP(p.getPlayerXP() + m.getMobXPVal());
								//	System.out.println("You have gained " + m.getMobXPVal() + " xp.");
								//	System.out.println("Your current xp is " + p.getPlayerXP());
								//	RegenTask2();
								deathStuff(m);
								break;
							}

						}
						else {
							System.out.println(m.getMobName() + " dodges your attack.");
						}
					} // end if (m.getMobHP()>0)

				} // end if (p.getPlayerHP() > 0)
				else {
					// not sure, you might be dead here, so lets just reload the character?
					// havent seen this block actually fire, but this SHOULD be here in theory
					System.out.println(p.getPlayerName() + " (the player) has died.2");
					loadPlayer(player1.getPlayerNum()); // reload the player from array (last "save")
				} // end else (p.getPlayerHP() <= 0)
			} // end if(m.getIsAlive() == 1)
			else {
				// **do nothing in this block to complete combat round without furthing attacks**
				// if m.getMobIsAlive != 1, ie the mob is dead
				System.out.println("It (" + m.getMobShortDesc() + ") is already dead."); // ** MUTE THIS** tells you mob is dead for remaining attacks from combat seq
				System.out.println("Attack a different target."); // **MUTE THIS** reminds you to attack something that is ALIVE
				break;
			}
			//	break; // stops loop after 1
		} // end for loop

	} // end attackTar3


	private class RainyWeather3 extends TimerTask {
		// rainyweather3() attempt2 to use cases for days
		// terrweather() attempts to use cases for terrain and inoutside

		@Override
		public void run() {
			// check the day, inc the day
			switch (raintime) {
			// raintime 0 // day 0
			case 0: {
				inoutside = newRoom.getInside();
				terrweather(); // terrweather() attempts to use cases for terrain and inoutside to set weather, allows for easy add of more terrain/climates
				raintime = 1;
				break;
			} // end raintime 0 // day 0
			// raintime 1 // day 1
			case 1: {
				terrweather();
				raintime = 2;
				break;
			} // end raintime 1 // day 1
			// raintime 2 // day 2
			case 2: {
				terrweather();
				raintime = 3;
				break;
			} // end raintime 2 // day 2
			// raintime 3 // day 3
			case 3: {
				terrweather();
				raintime = 4;
				break;
			} // end raintime 3 // day 3
			// raintime 4 // day 4
			case 4: {
				terrweather();
				raintime = 5;
				break;
			} // end raintime 4 // day 4
			// raintime 5 // day 5
			case 5: {
				terrweather();
				raintime = 6;
				break;
			} // end raintime 5 // day 5
			// raintime 6 // day 6
			case 6: {
				terrweather();
				raintime = 7;
				break;
			} // end raintime 6 // day 6
			// raintime 7 // day 7
			case 7: {
				terrweather();
				raintime = 8;
				break;
			} // end raintime 7 // day 7
			// raintime 0 // day 0
			case 8: {
				terrweather();
				raintime = 9;
				break;
			} // end raintime 8 // day 8
			// raintime 9 // day 9
			case 9: {
				terrweather();
				raintime = 10;
				break;
			} // end raintime 9 // day 9
			// raintime 10 // day 10
			case 10: {
				terrweather();
				raintime = 11;
				break;
			} // end raintime 10 // day 10
			// raintime 11 // day 11
			case 11: {
				terrweather();
				raintime = 12;
				break;
			} // end raintime 11 // day 11
			// raintime 12 // day 12
			case 12: {
				terrweather();
				raintime = 13;
				break;
			} // end raintime 12 // day 12
			// raintime 13 // day 13
			case 13: {
				terrweather();
				raintime = 14;
				break;
			} // end raintime 13 // day 13
			// raintime 14 // day 14
			case 14: {
				terrweather();
				raintime = 15;
				break;
			} // end raintime 14 // day 14
			// raintime 15 // day 15
			case 15: {
				terrweather();
				raintime = 16;
				break;
			} // end raintime 15 // day 15
			// raintime 16 // day 16
			case 16: {
				terrweather();
				raintime = 17;
				break;
			} // end raintime 6 // day 6
			// raintime 17 // day 17
			case 17: {
				terrweather();
				raintime = 18;
				break;
			} // end raintime 17 // day 17
			// raintime 18 // day 18
			case 18: {
				terrweather();
				raintime = 19;
				break;
			} // end raintime 18 // day 18
			// raintime 19 // day 19
			case 19: {
				terrweather();
				raintime = 20;
				break;
			} // end raintime 19 // day 19
			// raintime 20 // day 20
			case 20: {
				terrweather();
				raintime = 21;
				break;
			} // end raintime 20 // day 20
			// raintime 21 // day 21
			case 21: {
				terrweather();
				raintime = 22;
				break;
			} // end raintime 21 // day 21
			// raintime 22 // day 22
			case 22: {
				terrweather();
				raintime = 23;
				break;
			} // end raintime 22 // day 22
			// raintime 23 // day 23
			case 23: {
				terrweather();
				raintime = 24;
				break;
			} // end raintime 23 // day 23
			// raintime 24 // day 24
			case 24: {
				terrweather();
				raintime = 25;
				break;
			} // end raintime 24 // day 24
			// raintime 25 // day 25
			case 25: {
				terrweather();
				raintime = 26;
				break;
			} // end raintime 25 // day 25
			// raintime 26 // day 26
			case 26: {
				terrweather();
				raintime = 27;
				break;
			} // end raintime 26 // day 26
			// raintime 27 // day 27
			case 27: {
				terrweather();
				raintime = 28;
				break;
			} // end raintime 27 // day 27
			// raintime 28 // day 28
			case 28: {
				terrweather();
				raintime = 29;
				break;
			} // end raintime 28 // day 28
			// raintime 29 // day 29
			case 29: {
				terrweather();
				raintime = 0;
				break;
			} // end raintime 29 // day 29
			default: { }
			} // end switch (raintime)
		}// end run()
	} // end RainyWeather3


	private void terrweather() {
		// terrweather() attempts to use cases for terrain and inoutside
		// inoutside = newRoom.getInside();
		int terr = newRoom.getTerrain();
		int one = 1;

		//terr 0
		String void1 = "A windless breeze gently ruffles the dust.";
		String void2 = "An oppressive feeling falls from the sky.";
		String void3 = "A gentle emptiness surrounds you.";
		//terr 1
		String temperate1 = "The skies begin to clear.";
		String temperate2 = "The wind blows and the weather cools.";
		String temperate3 = "The clouds move in.";
		String temperate4 = "It pours heavily.";
		String temperate5 = "A gentle fog covers the land.";
		String temperate6 = "The weather warms and the clouds clear off.";
		String temperate7 = "A great wind brushes by.";
		// terr 2
		String arrid1 = "It feels hot and dry.";
		String arrid2 = "The arrid wind dries your skin.";
		String arrid3 = "The desert air bakes the sky.";
		String arrid4 = "A few streams of cloud cross the sky.";
		// terr 3
		String icy1 = "A cruel, frigid wind bites at you.";
		String icy2 = "The skies clear and the temperature drops.";
		String icy3 = "A few flurries of snow drift by.";
		String icy4 = "The skies darken as it snows heavily.";
		String icy5 = "A frigid chill pervades the air.";
		String icy6 = "A great blizzard brews in the distance.";
		String icy7 = "The skies clear as the snow flurries ease.";
		// terr 4
		String tropical1 = "The clouds clear off and the humidity rises.";
		String tropical2 = "An oppresive heat and humidity set in.";
		String tropical3 = "The temperature dips slightly as the clouds clear off.";
		String tropical4 = "It pours heavily.";
		String tropical5 = "It drizzles steadily.";
		String tropical6 = "It begins to sprinkles lightly.";
		String tropical7 = "A light fog covers the land.";


		/*
		 * terr 0 void
		System.out.println(void1);
		weatherstatus = "clear";
		System.out.println(void2);
		weatherstatus = "overcast";
		System.out.println(void3);
		weatherstatus = "clear";
		 */

		/*
		 * terr 1 temperate
		System.out.println(temperate1);
		weatherstatus = "clear";
		System.out.println(temperate2);
		weatherstatus = "clear";
		System.out.println(temperate3);
		weatherstatus = "cloudy";
		System.out.println(temperate4);
		weatherstatus = "raining";
		System.out.println(temperate5);
		weatherstatus = "foggy";
		System.out.println(temperate6);
		weatherstatus = "clear";
		System.out.println(temperate7);
		weatherstatus = "clear";
		 */

		/*
		 * terr 2, arid
		System.out.println(arrid1);
		weatherstatus = "clear";
		System.out.println(arrid2);
		weatherstatus = "clear";
		System.out.println(arrid3);
		weatherstatus = "clear";
		System.out.println(arrid4);
		weatherstatus = "cloudy";
		 */

		/*
		 * terr 3, icy/tundra
		System.out.println(icy1);
		weatherstatus = "clear";
		System.out.println(icy2);
		weatherstatus = "clear";
		System.out.println(icy3);
		weatherstatus = "snowing";
		System.out.println(icy4);
		weatherstatus = "snowing";
		System.out.println(icy5);
		weatherstatus = "clear";
		System.out.println(icy6);
		weatherstatus = "snowing";
		System.out.println(icy7);
		weatherstatus = "clear";
		 */

		/*
		 * 	terr 4, tropical
		 System.out.println(tropical1);
		 weatherstatus = "clear";
		 System.out.println(tropical2);
		 weatherstatus = "clear";
		 System.out.println(tropical3);
		 weatherstatus = "clear";
		 System.out.println(tropical4);
		 weatherstatus = "raining";
		 System.out.println(tropical5);
		 weatherstatus = "raining";
		 System.out.println(tropical6);
		 weatherstatus = "raining";
		 System.out.println(tropical7);
		 weatherstatus = "foggy";
		 */


		switch(terr) {

		// terr 0
		case 0: {
			inoutside = newRoom.getInside();
			int voidweather = roll(1,9);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {
				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (voidweather == 1) {	weatherstatus = "clear"; }
				if (voidweather == 2) {	weatherstatus = "overcast";	}
				if (voidweather == 3) {	weatherstatus = "clear";	}
			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (voidweather == 1) {	System.out.println(void1);	weatherstatus = "clear"; }
				if (voidweather == 2) {	System.out.println(void2);	weatherstatus = "overcast";	}
				if (voidweather == 3) {	System.out.println(void3);	weatherstatus = "clear"; }
			}
			break;
		} // end case 0: terr 0, void
		// terr 1
		case 1: {
			inoutside = newRoom.getInside();
			int tempweather = roll(1,14);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {
				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (tempweather == 1) {	weatherstatus = "clear";	}
				if (tempweather == 2) {	weatherstatus = "clear";	}
				if (tempweather == 3) {	weatherstatus = "cloudy";	}
				if (tempweather == 4) {	weatherstatus = "raining";	}
				if (tempweather == 5) {	weatherstatus = "foggy";	}
				if (tempweather == 6) {	weatherstatus = "clear";	}
				if (tempweather == 7) { weatherstatus = "clear";	}
			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (tempweather == 1) {	weatherstatus = "clear";	System.out.println(temperate1);	}
				if (tempweather == 2) {	weatherstatus = "clear";	System.out.println(temperate2);	}
				if (tempweather == 3) {	weatherstatus = "cloudy";	System.out.println(temperate3);	}
				if (tempweather == 4) {	weatherstatus = "raining";	System.out.println(temperate4);	}
				if (tempweather == 5) {	weatherstatus = "foggy";	System.out.println(temperate5);	}
				if (tempweather == 6) {	weatherstatus = "clear";	System.out.println(temperate6);	}
				if (tempweather == 7) { weatherstatus = "clear";	System.out.println(temperate7);	}
			}
			break;
		} // end case 1: terr 1, temperate
		// terr 2
		case 2: {
			inoutside = newRoom.getInside();
			int aridweather = roll(1,12);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {
				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (aridweather == 1) {	weatherstatus = "clear";	}
				if (aridweather == 2) {	weatherstatus = "clear";	}
				if (aridweather == 3) {	weatherstatus = "clear";	}
				if (aridweather == 4) {	weatherstatus = "cloudy";	}
			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (aridweather == 1) {	weatherstatus = "clear";	System.out.println(arrid1);	}
				if (aridweather == 2) {	weatherstatus = "clear";	System.out.println(arrid2);	}
				if (aridweather == 3) {	weatherstatus = "clear";	System.out.println(arrid3); }
				if (aridweather == 4) {	weatherstatus = "cloudy";	System.out.println(arrid4); }
			}
			break;
		} // end case 2: terr 2, arid/desert
		// terr 3
		case 3: {
			inoutside = newRoom.getInside();
			int icyweather = roll(1,14);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {
				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (icyweather == 1) {	weatherstatus = "clear";	}
				if (icyweather == 2) {	weatherstatus = "clear";	}
				if (icyweather == 3) {	weatherstatus = "snowing";	}
				if (icyweather == 4) {	weatherstatus = "snowing";	}
				if (icyweather == 5) {	weatherstatus = "clear";	}
				if (icyweather == 6) {	weatherstatus = "snowing";	}
				if (icyweather == 7) {	weatherstatus = "clear";	}
			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (icyweather == 1) {	weatherstatus = "clear";	System.out.println(icy1);	}
				if (icyweather == 2) {	weatherstatus = "clear";	System.out.println(icy2);	}
				if (icyweather == 3) {	weatherstatus = "snowing";	System.out.println(icy3);	}
				if (icyweather == 4) {	weatherstatus = "snowing";	System.out.println(icy4);	}
				if (icyweather == 5) {	weatherstatus = "clear";	System.out.println(icy5);	}
				if (icyweather == 6) {	weatherstatus = "snowing";	System.out.println(icy6);	}
				if (icyweather == 7) {	weatherstatus = "clear";	System.out.println(icy7);	}
			}
			break;
		} // end case 3: terr 3, icy/tundra
		// terr 4
		case 4: {
			inoutside = newRoom.getInside();
			// terr 4, tropical,
			int tropicalweather = roll(1,14);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {
				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (tropicalweather == 1) {	weatherstatus = "clear";	}
				if (tropicalweather == 2) {	weatherstatus = "clear";	}
				if (tropicalweather == 3) {	weatherstatus = "clear";	}
				if (tropicalweather == 4) {	weatherstatus = "raining";	}
				if (tropicalweather == 5) {	weatherstatus = "raining";	}
				if (tropicalweather == 6) {	weatherstatus = "raining";	}
				if (tropicalweather == 7) {	weatherstatus = "foggy";	}

			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (tropicalweather == 1) {	weatherstatus = "clear";	System.out.println(tropical1);	}
				if (tropicalweather == 2) {	weatherstatus = "clear";	System.out.println(tropical2);	}
				if (tropicalweather == 3) {	weatherstatus = "clear";	System.out.println(tropical3);	}
				if (tropicalweather == 4) {	weatherstatus = "raining";	System.out.println(tropical4);	}
				if (tropicalweather == 5) {	weatherstatus = "raining";	System.out.println(tropical5);	}
				if (tropicalweather == 6) {	weatherstatus = "raining";	System.out.println(tropical6);	}
				if (tropicalweather == 7) {	weatherstatus = "foggy";	System.out.println(tropical7);	}
			}
			break;
		} // end case 4: terr 4, tropical
		default: { }

		// add additional terrains here


		/*
		 * SAMPLE MORE TERRAINS
		  	String terr?Weather1 = "";
		  	case ?: {
		  	inoutside = newRoom.getInside();
			int ?weather = roll(1,8);  // double the weather types so we have blank/no-update days
			if (inoutside == one) {

				// System.out.println("Currently Indoors."); // update weather status, but output nothing
				if (?weather == 1) {	weatherstatus = "clear";	}

			}
			else {
				// System.out.println("Currently Outdoors."); // update weather status, output the weather string
				if (?weather == 1) {	weatherstatus = "clear";	System.out.println(terr?Weather1);	}
			}
			break;
		} // end case ?: terr ?,


		 */ // END SAMPLE



		} // end swtich (terr)
	} // end terrweather


	private class SunTask extends TimerTask {
		// Sun cycle
		@Override
		public void run() {
			inoutside = newRoom.getInside();
			if (daytime == 0) {
				if (inoutside == 1) {
					//	System.out.println("day " + daynum + " " + weekDay);
					//System.out.println("You are currently indoors - suntimer morning");
					sunstatus = "hidden";
					daynum++; // 			
					daytime = 1;
				}
				else {
					//	System.out.println("day " + daynum + " " + weekDay);
					System.out.println("The twin suns spiral around each other as they rise in the eastern sky.");
					sunstatus = "visible";
					daytime = 1;
					daynum++;

				}



				//trying a regen statement?
				try {
					mobWanderTest();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				playerRegen();
				mobRegen();
				talker();
			}

			else if (daytime == 1) {
				if (inoutside == 1) {
					//	System.out.println("You are currently indoors - suntimer noon");
					sunstatus = "hidden";
					daytime = 2;
				}
				else {
					System.out.println("The suns reach a blazing apex.");
					sunstatus = "visible";
					daytime = 2;
				}

				//trying a regen statement?
				try {
					mobWanderTest();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				playerRegen();
				mobRegen();
				talker();
			}

			else if (daytime == 2) {
				if (inoutside == 1) {
					//	System.out.println("You are currently indoors - suntimer evening");
					sunstatus = "hidden";
					daytime = 3;
				}
				else {
					//	System.out.println("The suns spiral and fade in the western horizon.");
					sunstatus = "visible";
					daytime = 3;
				}

				//trying a regen statement?
				try {
					mobWanderTest();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				playerRegen();
				mobRegen();
				talker();
			}

			else if (daytime == 3) {
				if (inoutside == 1) {
					//	System.out.println("You are currently indoors - suntimer night");
					sunstatus = "hidden";
					daytime = 0;
				}
				else {
					System.out.println("The night has reached is darkest hour.");
					sunstatus = "hidden";
					daytime = 0;
				}


				// happen 4x per game "day" regardless of which timeblock
				try {
					mobWanderTest();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				playerRegen();
				mobRegen();
				talker();


				incCalendar(); // this works

			}	
		}		
	} // end SunTask


	private void incCalendar() {
		// increments the calendar days and the months
		// respawnMobs() is called in // weeks of month section

		// days of week
		dayofWeek++;

		if (dayofWeek == 0) {
			weekDay="Primeday";
		}
		if (dayofWeek == 1) {
			weekDay="Flowday";
		}
		if (dayofWeek == 2) {
			weekDay="Midspire";
		}
		if (dayofWeek == 3) {
			weekDay="Thriveday";
		}
		if (dayofWeek == 4) {			
			weekDay="Freewind";
			System.out.println("The your chores for the week have ended, enjoy " + weekDay + ".");
			dayofWeek=0;
			weekofMonth++;

			// respawnMobs(); // use Weekly for testing, use Monthly for game play

		}

		// weeks of month
		if (weekofMonth == 0) {
			week = "Dawnweek";
		}
		if (weekofMonth == 1) {
			week = "Sprightweek";
		}
		if (weekofMonth == 2) {
			week = "Hearthweek";				
		}
		if (weekofMonth == 3) {
			week = "Crestweek";
		}
		if (weekofMonth == 4) {
			week = "Driftweek";
		}
		if (weekofMonth == 5) {
			week = "Duskweek";
			System.out.println("Another month has swiftly passed by.");
			weekofMonth = 0;
			monthofYear++;

			respawnMobs(); // this works, resets all mobs to isAlive in array
		}

		// months of year
		if (monthofYear == 0) {
			month = "Frostmere";
		}
		if (monthofYear == 1) {
			month = "Emberthaw";
		}
		if (monthofYear == 2) {
			month = "Blossary";
		}
		if (monthofYear == 3) {
			month = "Greenveil";
		}
		if (monthofYear == 4) {
			month = "Suncrest";
		}
		if (monthofYear == 5) {
			month = "Flamepeak";
		}
		if (monthofYear == 6) {
			month = "Harvestine";
		}
		if (monthofYear == 7) {
			month = "Amberfall";
		}
		if (monthofYear == 8) {
			month = "Leafturn";
		}
		if (monthofYear == 9) {
			month = "Shadowveil";
		}
		if (monthofYear == 10) {
			month = "Frostfall";
		}
		if (monthofYear == 11)  {
			month = "Snowbloom";
			monthofYear = 0;
			year++;
			System.out.println("Congratulations! Another year has passed.");
		}			
	} // end incCalendar()

	private void zoneLoadSample(zone z0ne) {
		// TODO
		// this is supposed to spawn/respawn all the mobs in zone z0ne .... to be run on timer, or on demand (zload?)

		
		//int[] myints = {1, 2, 3, 4, 5};
		//for(int i : myints) {  // for all ints i in myints[]
		//    System.out.println(i);
		// }

		// zoneScript do something!
		
		
	}
	private void respawnMobsSample() {
		// TODO
		System.out.println("Mobs respawning in zone: " + currentZone.getZoneName() + " .  Please be careful.");
		if(currentZone.rm00.tmob0.getMobNum()!=0) {
			currentZone.rm00.tmob0.setmobIsAlive(1); // is alive
		}
		if(currentZone.rm00.tmob1.getMobNum()!=0) {
			currentZone.rm00.tmob1.setmobIsAlive(1); // is alive
		}
		if(currentZone.rm00.tmob2.getMobNum()!=0) {
			currentZone.rm00.tmob2.setmobIsAlive(1); // is alive
		}
		if(currentZone.rm00.tmob0.getMobNum()!=0) {
			currentZone.rm00.tmob3.setmobIsAlive(1); // is alive
		}
		if(currentZone.rm00.tmob0.getMobNum()!=0) {
			currentZone.rm00.tmob4.setmobIsAlive(1); // is alive 
		}
		if(currentZone.rm00.tmob0.getMobNum()!=0) {
			currentZone.rm00.tmob5.setmobIsAlive(1); // is alive
		}
	}// end respawnMobsSample()
	private void respawnMobs() {
		// Reset all mobs in array to isAlive state of 1 or alive

		System.out.println("Mobs respawning.  Please be careful.");	 // to be muted when this works

		// for all mobs in the array, reset [31] or isAlive to "1" 
		for (int i=0; i < nextAvailMob; i++) {		
			Mobs[i][31] = "1"; // back alive
		}
	} // end respawnMobs()	

	private void mobWanderMoveTest(int mPos ,int mnum, int room) throws Exception {
		// attempts to move the mob to the next available room?
		String mobarr = World[room][14]; // whats in the room
		int mobToMove = mnum; // the mob number from Mob array
		// int mobPos = mPos; // 0-5, the mobs position in the room its moving from's array? // to be used later
		String zero = "0"; // zero is "0" for obvious reasons

		String StringmobToMove = Integer.toString(mobToMove);
		//	System.out.println("Mob array for room number: " + room);
		//	System.out.println("Room to potentially enter's Array value: " + mobarr);
		String[] pmob = new String[6];
		mobarr.replace(" ","");
		pmob=mobarr.split(",");


		// this works to next else if
		if(pmob[0].equals(zero)) {
			pmob[0]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			//	System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob0.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);
			//	newRoom.setMobsInRoom(newRoom.getMobsInRoom());


			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);

		} // if working, repeat for pmob1-5

		else {}

		if(pmob[1].equals(zero)) {
			pmob[1]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			//		System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob1.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);
			//	newRoom.setMobsInRoom(newRoom.getMobsInRoom());


			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);
		} // if working, repeat for pmob1-5
		else {}
		if(pmob[2].equals(zero)) {
			pmob[2]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob0.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);

			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);
		} // if working, repeat for pmob1-5
		else {}
		if(pmob[3].equals(zero)) {
			pmob[3]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob0.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);

			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);
		} // if working, repeat for pmob1-5
		else {}
		if(pmob[4].equals(zero)) {
			pmob[4]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			//	System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob0.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);

			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);
		} 
		else {}
		if(pmob[5].equals(zero)) {
			pmob[5]=StringmobToMove;

			String tempstring = Arrays.toString(pmob);
			//	System.out.println("Value to be saved World array: " + tempstring); // to be muted if working
			World[room][14]=tempstring; // properly updates mob into new room
			// need to take mob out of current room		

			System.out.println("You see " + tmob0.getMobShortDesc()+ " leave the room."); // to be muted if working
			tmob0.setMobNum(0); // 
			tmob0.reset();
			loadMob(tmob0,0);
			newRoom.setMobNumAtPos(0,0);

			// testing this part
			// need to update World[curRmNum][mobarray] to have a 0 in pos 0
			String newMobsInRoomArr = newRoom.getMobsInRoom();
			World[curRmNum][14] = newMobsInRoomArr;

			buildCurrentRoom(curRmNum);
		} 
		else { // else do nothing, duh, dont want to spam the player
			//	System.out.println("There were no empty slots for the mob to move into."); 
		}

	} // end mobWanderMoveTest

	private void mobWanderTest() throws Exception {
		// so far this is working, but only lets the mobs in the current room move out, not move from them beyond (double triple quad moves?)
		int i=0;
		int EN=0;
		int ENE=0;
		int EE=0;
		int ESE=0;
		int ES=0;
		int ESW=0;
		int EW=0;
		int ENW=0;
		int EU=0;
		int ED=0;

		if (tmob0.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob0.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob0.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob0.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob0.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob0.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob0.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob0.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob0.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob0.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob0.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob0.getWanders()==1) // repeat for tmob1-5

		if (tmob1.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob1.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob1.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob1.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob1.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob1.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob1.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob1.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob1.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob1.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob1.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob1.getWanders()==1) // repeat for tmob1-5
		if (tmob2.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob2.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob2.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob2.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob2.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob2.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob2.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob2.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob2.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob2.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob2.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob0.getWanders()==1) // repeat for tmob1-5
		if (tmob3.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob3.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob3.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob3.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob3.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob3.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob3.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob3.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob3.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob3.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob0.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob3.getWanders()==1) // repeat for tmob1-5
		if (tmob4.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob4.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob4.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob4.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob4.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob4.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob4.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob4.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob4.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob4.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob4.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob4.getWanders()==1) // repeat for tmob1-5
		if (tmob5.getWanders()==1) { // repeat for tmob1-5?
			//	System.out.println("1.Mob (" + tmob0.getMobShortDesc() + ") tries wander off."); // to be muted if working

			if(newRoom.getExitN()!=0) {
				i++;
				EN=newRoom.getExitN();
			}
			if(newRoom.getExitNE()!=0) {
				i++;
				ENE=newRoom.getExitNE();
			}
			if(newRoom.getExitE()!=0) {
				i++;
				EE=newRoom.getExitE();
			}
			if(newRoom.getExitSE()!=0) {
				i++;
				ESE=newRoom.getExitSE();
			}
			if(newRoom.getExitS()!=0) {
				i++;
				ES=newRoom.getExitS();
			}
			if(newRoom.getExitSW()!=0) {
				i++;
				ESW=newRoom.getExitSW();
			}
			if(newRoom.getExitW()!=0) {
				i++;
				EW=newRoom.getExitW();
			}
			if(newRoom.getExitNW()!=0) {
				i++;
				ENW=newRoom.getExitNW();
			}
			if(newRoom.getExitU()!=0) {
				i++;
				EU=newRoom.getExitU();
			}
			if(newRoom.getExitD()!=0) {
				i++;
				ED=newRoom.getExitD();
			}

			//		System.out.println("The mob had " + i + " exits to choose from."); // to be muted if working
			int ii = roll(0,i);
			//	System.out.println("The mob chose exit " + ii); // to be muted if working
			switch (ii) {
			case 0: {
				//System.out.println("The mob attempted to exit North to room numer " + EN); // to be muted if working
				// add code block here to move mob to next 
				mobWanderMoveTest(0,tmob5.getMobNum(),EN); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 1: {
				//System.out.println("The mob attempted to exit to North East room number " + ENE);
				mobWanderMoveTest(0,tmob5.getMobNum(),ENE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 2: {
				//System.out.println("The mob attempted to exit East to room number " + EE);
				mobWanderMoveTest(0,tmob5.getMobNum(),EE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 3: {
				//System.out.println("The mob attempted to exit South East to room number " + ESE);
				mobWanderMoveTest(0,tmob5.getMobNum(),ESE); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 4: {
				//System.out.println("The mob attempted to exit South to room number " + ES);
				mobWanderMoveTest(0,tmob5.getMobNum(),ES); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 5: {
				//System.out.println("The mob attempted to exit South West to room number " + ESW);
				mobWanderMoveTest(0,tmob5.getMobNum(),ESW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 6: {
				//System.out.println("The mob attempted to exit West to room number " + EW);
				mobWanderMoveTest(0,tmob5.getMobNum(),EW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 7: {
				//System.out.println("The mob attempted to exit North West to room number " + ENW);
				mobWanderMoveTest(0,tmob5.getMobNum(),ENW); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 8: {
				//System.out.println("The mob attempted to exit Up to room number " + EU);
				mobWanderMoveTest(0,tmob5.getMobNum(),EU); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}
			case 9: {
				//	System.out.println("The mob attempted to exit Down to room number " + ED);
				mobWanderMoveTest(0,tmob5.getMobNum(),ED); // dont worry about the 0 for now, to be used later (the first value is their position in the currents room mob array. '0 for tmob0')
				break;
			}

			default: {
				// System.out.println("The Mob cannot wander."); // to be muted when working
			}
			}
		} // end if (tmob0.getWanders()==1) // repeat for tmob1-5
	}// end mobWanderTest()


	private class Moon1Task extends TimerTask {
		// Xifos, largest moon
		@Override
		public void run() {
			int one = 1;
			if (weatherstatus == "clear") {
				inoutside = newRoom.getInside();
				if (inoutside == one) {
					//			System.out.println("Currently Indoors - Xifos moonrise timer ");
					moon1status = "hidden";
					moontime1 = 1;
				}
				else {
					// you are outdoors, output the moon
					// System.out.println("Currently Outdoors.");
					System.out.println("Xifos, the largest of the moons, rises in the northern sky.");
					moon1status = "visible";
					moontime1 = 1;
				}

			} // end (weatherstatus == "clear")
			else {  // weather != clear
				if (inoutside == one) {
					//			System.out.println("Currently Indoors - Xifos moonrise timer ");
					moon1status = "hidden";
					moontime1 = 1;
				}
				else {
					// you are outdoors, output the moon
					// System.out.println("Currently Outdoors.");
					// System.out.println("It is too overcast to see Xifos.");
					moontime1 = 1;
					moon1status = "hidden";
				}
			}

			if (moontime1 == 1) {
				inoutside = newRoom.getInside();
				if (weatherstatus == "clear") {
					if (inoutside == one) {
						//	System.out.println("Currently Indoors.");
						moon1status = "hidden";
						moontime1 = 2;
					}
					else {
						//	System.out.println("Xifos ascends to its apex.");
						moon1status = "visible";
						moontime1 = 2;
					}
				} // end (weatherstatus == "clear")
				else {
					if (inoutside == one) {
						//			System.out.println("Currently Indoors - Xifos moonrise timer ");
						moon1status = "hidden";
						moontime1 = 2;
					}
					else {
						// you are outdoors, output the moon
						// System.out.println("Currently Outdoors.");
						// System.out.println("It is too overcast to see Xifos.");
						moontime1 = 2;
						moon1status = "hidden";
					}
				}
			} // end if (moontime1 == 1)

			else if (moontime1 == 2) {
				inoutside = newRoom.getInside();
				if (weatherstatus == "clear") {
					if (inoutside == one) {
						// System.out.println("Currently Indoors.");
						moon1status = "hidden";
						moontime1 = 3;
					}
					else {
						System.out.println("Xifos sinks in the south.");
						moon1status = "visble";
						moontime1 = 3;
					}
				} // end (weatherstatus == "clear")

				else {
					if (inoutside == one) {
						//			System.out.println("Currently Indoors - Xifos moonrise timer ");
						moon1status = "hidden";
						moontime1 = 3;
					}
					else {
						// you are outdoors, output the moon
						// System.out.println("Currently Outdoors.");
						System.out.println("It is too cloudy to see Xifos.");
						moon1status = "hidden";
						moontime1 = 3;
					}
				}
			} // end else if (moontime1 == 2)

			// moon on other side of planet
			else if (moontime1 == 3) {
				inoutside = newRoom.getInside();
				moon1status = "hidden";
				moontime1 = 4;
			}
			else if (moontime1 == 4) {
				inoutside = newRoom.getInside();
				moon1status = "hidden";
				moontime1 = 5;
			}
			else  {
				inoutside = newRoom.getInside();
				moon1status = "hidden";
				moontime1 = 0;
			}

			// happen regardless of timeblock 
			if (regrowthCast > 0) {
				regrowthHeal(); // cast regrowth HoT spell
				regrowthCast++;
			}
			if (regrowthCast == 8) { // 
				regrowthCast = 0;
			}
		} // end run()
	}// end Moon1Task

	private class Moon2Task extends TimerTask {
		// Cristos, the smallest/fastest of the moons
		@Override
		public void run() {
			//		int inoutside = newRoom.getInside();   // are we inside our outside? 0=outside, 1=inside
			int one = 1;

			if (moontime2 == 0 ) {
				inoutside = newRoom.getInside();
				if (weatherstatus == "clear") {
					if (inoutside == one) {
						//		System.out.println("Currently Indoors - Cristos moonrise timer");
						moontime2 = 1;
						moon2status = "hidden";
					}
					else {
						System.out.println("Cristos appears briefly on the horizon.");
						moontime2 = 1;
						moon2status = "visible";
					}
				} // end weatherstatus == "clear"
				else {
					if (inoutside == one) {
						//		System.out.println("Currently Indoors - Cristos moonrise timer");
						moontime2 = 1;
						moon2status = "hidden";
					}
					else {
						//	System.out.println("It is too overcast to see Cristos.");
						moontime2 = 1;
						moon2status = "hidden";
					}
				}
			}

			// moon on other side of planet
			else {
				moontime2 = 0;
				moon2status = "hidden";
			}

			// happens regardless of moon phase timebblock

			// someone cast Rejuv on you
			if (rejuvCast > 0) {
				rejuvHeal(); 
				rejuvCast++;
			}
			// Rejuv ticked 12 times?
			if (rejuvCast == 12) {
				rejuvCast = 0;
			}

		} // end run()
	} // end Moon2Task


	private class Moon3Task extends TimerTask {
		// Mithos, mid-size/speed moon
		@Override
		public void run() {
			int one = 1;
			if (moontime3 == 0) {
				inoutside = newRoom.getInside();
				if (weatherstatus == "clear") {
					if (inoutside == one) {
						// you are indoors, do not output the moon
						//	System.out.println("Currently Indoors - Mithos moonrise timer");
						moontime3 = 1;
						moon3status = "hidden";
					}
					else {
						System.out.println("Mithos rises in the southeastern sky.");
						moontime3 = 1;
						moon3status = "visible";
					}
				}
				else { // weatherstatus != "clear"
					if (inoutside == one) {
						// you are indoors, do not output the moon
						//	System.out.println("Currently Indoors - Mithos moonrise timer");
						moontime3 = 1;
						moon3status = "hidden";
					}
					else {
						//	System.out.println("It is too overcase to see Mithos");
						moontime3 = 1;
						moon3status = "hidden";
					}
				}
			} // end if (moontime3 == 0)

			else if (moontime3 == 1) {
				if (weatherstatus == "clear") {
					inoutside = newRoom.getInside();
					if (inoutside == one) {
						// you are indoors, do not output the moon
						//	System.out.println("Currently Indoors.");
						moontime3 = 2;
						moon3status = "hidden";
					}
					else {
						System.out.println("Mithos progresses across the majority of the sky.");
						moontime3 = 2;
						moon3status = "visible";
					}
				}
				else { // weatherstatus != "clear"
					if (inoutside == one) {
						// you are indoors, do not output the moon
						//	System.out.println("Currently Indoors - Mithos moonrise timer");
						moontime3 = 2;
						moon3status = "hidden";
					}
					else {
						//	System.out.println("It is too overcase to see Mithos");
						moontime3 = 2;
						moon3status = "hidden";
					}
				}
			} // end else if (moontime3 == 1)

			// moon on other side of planet
			else {
				//	System.out.println("Moon Currently On Other Side - Mithos moonrise timer");
				moontime3 = 0;
				moon3status = "hidden";
			}
			if (regenCast > 0) {
				regenHeal();
				regenCast++;
			}
			if (regenCast == 7) {
				regenCast = 0;
			}
		} // end run()

	} // end Moon3Task


	public static void displayCurrentTime() throws Exception {
		// displays current time weather and climate
		long endTime   = System.nanoTime();
		long totalTime = (endTime - startTime) / 1000000000; // move to seconds~!
		SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm:ss");
		String time = localDateFormat.format(new Date());
		System.out.println("Day: [" + daynum + "]" + " " + weekDay);
		System.out.println("Current Time: " + totalTime); // add "time"
		System.out.println("Current local time: " + time);
		System.out.println("It is currently the " + daynum + " day of the " + year + " year.");
		System.out.println("To immportals it appears to be day " + daynum + " of the " + year + " year.");
		System.out.println("But to mortals it is known as " + weekDay + ", the " + dayofWeek + " day of " + week + ", the " + weekofMonth + " week of the month of " + month + ", the " + monthofYear + " month of the year.");

		int inout= newRoom.getInside(); // check whether room is an Inside or Outside room
		int one = 1; // Room is Inside
		if (inout==one)	{
			System.out.println("Currently: Inside");
		}
		else {
			System.out.println("Currently: Outside");
		}
		System.out.println("Suns: [" + sunstatus + "]");
		System.out.println("Moons: Xifos [" + moon1status + "] Critos [" + moon2status + "] Mithos [" + moon3status + "]");
		System.out.print("Climate: [" + newRoom.getTerrain() + "]" + " ");
		if (newRoom.getTerrain() ==  1) {
			System.out.println("The terrain and climate is temperate and moderate.");
		}
		else if (newRoom.getTerrain() == 2) {
			System.out.println("The weather is dry and arrid.");
		}
		else if (newRoom.getTerrain() == 3) {
			System.out.println("The environment is frigid and harse.");
		}
		else {
			System.out.println("You are currently in a void.");
		}
		System.out.println("Weather Status: [" + weatherstatus + "]");
		try {
			Thread.sleep(5000);

			look("null");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	} // end displayCurrentTime()


	public void rejuvHeal1(int slvl) {
		// runs off Moon2Task
		checkPlayerMaxHP();

		int healthRestore = 50 * slvl;

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);
		System.out.println("Level " + slvl + " Rejuvination heals you for " + healthRestore + " health.");	

		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	} // end rejuvHeal1(int slvl)


	public void rejuvHeal() {
		// runs off Moon2Task
		checkPlayerMaxHP();

		int healthRestore = 50;

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);
		System.out.println("Rejuvination heals you for " + healthRestore + " health.");	

		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	} // end rejuvHeal()


	public void regrowthHeal1(int slvl) {
		// runs off Moon1Task
		checkPlayerMaxHP();

		int healthRestore = 40 * slvl;

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);

		System.out.println("Level " + slvl + " Regrowth heals you for " + healthRestore + " health.");
		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	} // end regrowthHeal1(int slvl)


	public void regrowthHeal() {
		// runs off Moon1Task
		checkPlayerMaxHP();

		int healthRestore = 40;

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);

		System.out.println("Regrowth heals you for " + healthRestore + " health.");
		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	}// end regrowthHeal()


	public void regenHeal1(int slvl) {

		// runs off Moon3Task

		checkPlayerMaxHP();

		int healthRestore = 10 * slvl; // 10 hps 

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);
		System.out.println("Level " + slvl + " Regen heals you for " + healthRestore + " health.");
		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	} // end regenHeal1(int slvl)


	public void regenHeal() {
		// runs off Moon3Task

		checkPlayerMaxHP();

		int healthRestore = 10; // 10 hps 

		player1.setPlayerHP(player1.getPlayerHP() + healthRestore);
		System.out.println("Regen heals you for " + healthRestore + " health.");
		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
	} // end regenHeal()


	public void mobRegen() {
		// regens mobs HP/MPs, called by Suntimer
		// currently regns 1/50 of max HP/MP per Suntimer, but only when in same room as player, mobs reset when player re-enters room

		if (tmob0.mobIsAlive == 1) {
			checkMobMaxHP(tmob0);
			checkMobMaxMP(tmob0);
			int mob0HPRestore = (int) tmob0.getMaxHP()/100;
			int mob0MPRestore = (int) tmob0.getMaxMP()/100;

			if (tmob0.getMobHP() < tmob0.getMaxHP()) {
				mob0HPRestore = mob0HPRestore*hpRegenPer;
				tmob0.setMobHP(tmob0.getMobHP() +	mob0HPRestore);
			}
			if (tmob0.getMobMP() < tmob0.getMaxMP()) {
				mob0MPRestore = mob0MPRestore*manaRegenPer;
				tmob0.setMobMP(tmob0.getMobMP() +	mob0MPRestore);
			}
		}
		if (tmob1.mobIsAlive == 1) {
			checkMobMaxHP(tmob1);
			checkMobMaxMP(tmob1);
			int mob1HPRestore = (int) tmob1.getMaxHP()/100;
			int mob1MPRestore = (int) tmob1.getMaxMP()/100;

			if (tmob1.getMobHP() < tmob1.getMaxHP()) {
				mob1HPRestore = mob1HPRestore*hpRegenPer;
				tmob1.setMobHP(tmob1.getMobHP() +	mob1HPRestore);
			}
			if (tmob1.getMobMP() < tmob1.getMaxMP()) {
				mob1MPRestore = mob1MPRestore*manaRegenPer;
				tmob1.setMobMP(tmob1.getMobMP() +	mob1MPRestore);
			}
		}
		if (tmob2.mobIsAlive == 1) {
			checkMobMaxHP(tmob2);
			checkMobMaxMP(tmob2);
			int mob2HPRestore = (int) tmob2.getMaxHP()/100;
			int mob2MPRestore = (int) tmob2.getMaxMP()/100;

			if (tmob2.getMobHP() < tmob2.getMaxHP()) {
				mob2HPRestore = mob2HPRestore*hpRegenPer;
				tmob2.setMobHP(tmob2.getMobHP() +	mob2HPRestore);
			}
			if (tmob2.getMobMP() < tmob2.getMaxMP()) {
				mob2MPRestore = mob2MPRestore*manaRegenPer;
				tmob2.setMobMP(tmob2.getMobMP() +	mob2MPRestore);
			}
		}
		if (tmob3.mobIsAlive== 1) {
			checkMobMaxHP(tmob3);
			checkMobMaxMP(tmob3);
			int mob3HPRestore = (int) tmob3.getMaxHP()/100;
			int mob3MPRestore = (int) tmob3.getMaxMP()/100;

			if (tmob3.getMobHP() < tmob3.getMaxHP()) {
				mob3HPRestore = mob3HPRestore*hpRegenPer;
				tmob3.setMobHP(tmob3.getMobHP() +	mob3HPRestore);
			}
			if (tmob3.getMobMP() < tmob3.getMaxMP()) {
				mob3MPRestore = mob3MPRestore*manaRegenPer;
				tmob3.setMobMP(tmob3.getMobMP() +	mob3MPRestore);
			}
		}
		if (tmob4.mobIsAlive== 1) {
			checkMobMaxHP(tmob4);
			checkMobMaxMP(tmob4);
			int mob4HPRestore = (int) tmob4.getMaxHP()/100;
			int mob4MPRestore = (int) tmob4.getMaxMP()/100;

			if (tmob4.getMobHP() < tmob4.getMaxHP()) {
				mob4HPRestore = mob4HPRestore*hpRegenPer;
				tmob4.setMobHP(tmob4.getMobHP() +	mob4HPRestore);
			}
			if (tmob4.getMobMP() < tmob4.getMaxMP()) {
				mob4MPRestore = mob4MPRestore*manaRegenPer;
				tmob4.setMobMP(tmob4.getMobMP() +	mob4MPRestore);
			}
		}
		if (tmob5.mobIsAlive== 1) {
			checkMobMaxHP(tmob5);
			checkMobMaxMP(tmob5);
			int mob5HPRestore = (int) tmob5.getMaxHP()/100;
			int mob5MPRestore = (int) tmob5.getMaxMP()/100;

			if (tmob5.getMobHP() < tmob5.getMaxHP()) {
				mob5HPRestore = mob5HPRestore*hpRegenPer;
				tmob5.setMobHP(tmob5.getMobHP() +	mob5HPRestore);
			}
			if (tmob5.getMobMP() < tmob5.getMaxMP()) {
				mob5MPRestore = mob5MPRestore*manaRegenPer;
				tmob5.setMobMP(tmob5.getMobMP() +	mob5MPRestore);
			}
		}
	}// end mobRegen()

	public void playerRegen() {
		// regens player HP/MPs, called by SunTask
		// currently regns 1/50 of max HP/MP per SunTask
		checkPlayerMaxHP();
		checkPlayerMaxMP();
		int healthRestore = (int) player1.getPlayerMaxHP()/100;
		int manaRestore = (int) player1.getPlayerMaxMP()/100;
		if (player1.getPlayerHP() < player1.getPlayerMaxHP())  {
			healthRestore = healthRestore*hpRegenPer;
			player1.setPlayerHP(player1.getPlayerHP() + healthRestore);
			System.out.println("Restoring " + healthRestore +" health.");
		}
		if (player1.getPlayerMP() < player1.getPlayerMaxMP() ) {
			manaRestore = manaRestore*manaRegenPer;
			player1.setPlayerMP(player1.getPlayerMP() + manaRestore);
			System.out.println("Restoring " + manaRestore + " mana.");
		}
		if (player1.getPlayerHP() > player1.getPlayerMaxHP()) {
			player1.setPlayerHP(player1.getPlayerMaxHP());
		}
		if (player1.getPlayerMP() > player1.getPlayerMaxMP()) {
			player1.setPlayerMP(player1.getPlayerMaxMP());
		}
	}// end regen statement

	public static void gameMemory() {
		Runtime runtime = Runtime.getRuntime();

		long maxMemory = runtime.maxMemory();
		long allocatedMemory = runtime.totalMemory();
		long freeMemory = runtime.freeMemory();

		System.out.println("Max memory (bytes): " + maxMemory);
		System.out.println("Allocated memory (bytes): " + allocatedMemory);
		System.out.println("Free memory (bytes): " + freeMemory);
		System.out.println("Used memory (bytes): " + (allocatedMemory - freeMemory));
	}// end gameEmemory

	public static void sysStatus() {
		// 
		// shows system stats and info
		System.out.println("Game Designer: " + gameDesigner);
		System.out.println("Game Version: " + gameVersion);
		System.out.println("Game Dedication: " + gameDedication);

		System.out.println("Total numer of Zones: " + nextAvailZone);
		System.out.println("Total number of Rooms: " + nextAvailRoom);
		System.out.println("Total number of Mobs: " + nextAvailMob);
		System.out.println("Total number of Objects: " + nextAvailObj);
		System.out.println("Total number of characters: " + nextAvailChar);

		System.out.println("Total game memory: ");
		gameMemory();
	}// end sysStatus



	public static void buildCurrentRoom2(int i) {
		// to be used for file write of World Array
		// create new/current room

		newRoom2.setRoomNum(i);
		newRoom2.setRoomName(World[i][1]);
		newRoom2.setRoomShortDesc(World[i][2]);
		newRoom2.setRoomLongDesc(World[i][3]);
		newRoom2.setExitN(Integer.parseInt(World[i][4]));
		newRoom2.setExitNE(Integer.parseInt(World[i][5]));
		newRoom2.setExitE(Integer.parseInt(World[i][6]));
		newRoom2.setExitSE(Integer.parseInt(World[i][7]));
		newRoom2.setExitS(Integer.parseInt(World[i][8]));
		newRoom2.setExitSW(Integer.parseInt(World[i][9]));
		newRoom2.setExitW(Integer.parseInt(World[i][10]));
		newRoom2.setExitNW(Integer.parseInt(World[i][11]));
		newRoom2.setExitU(Integer.parseInt(World[i][12]));
		newRoom2.setExitD(Integer.parseInt(World[i][13]));
		newRoom2.setMobsInRoom(World[i][14].split(", "));
		newRoom2.setObjsInRoom(World[i][15].split(", "));
		newRoom2.setLit(Integer.parseInt(World[i][16]));
		newRoom2.setCamp(Integer.parseInt(World[i][17]));
		newRoom2.setRent(Integer.parseInt(World[i][18]));
		newRoom2.setInside(Integer.parseInt(World[i][19]));
		newRoom2.setTerrain(Integer.parseInt(World[i][20]));
		newRoom2.setBank(Integer.parseInt(World[i][21]));

		newRoom2.setdNStatus(World[i][22]);
		newRoom2.setdNEStatus(World[i][23]);
		newRoom2.setdEStatus(World[i][24]);
		newRoom2.setdSEStatus(World[i][25]);
		newRoom2.setdSStatus(World[i][26]);
		newRoom2.setdSWStatus(World[i][27]);
		newRoom2.setdWStatus(World[i][28]);
		newRoom2.setdNWStatus(World[i][29]);
		newRoom2.setdUStatus(World[i][30]);
		newRoom2.setdDStatus(World[i][31]);

		newRoom2.setV32(World[i][32]);
		newRoom2.setV33(World[i][33]);
		newRoom2.setV34(World[i][34]);
		newRoom2.setV35(World[i][35]);
		newRoom2.setV36(World[i][36]);
		newRoom2.setV37(World[i][37]);
		newRoom2.setV38(World[i][38]);
		newRoom2.setV39(World[i][39]);
		newRoom2.setV40(World[i][40]);
		newRoom2.setV41(World[i][41]);
		newRoom2.setV42(World[i][42]);
		newRoom2.setV43(World[i][43]);
		newRoom2.setV44(World[i][44]);
		newRoom2.setV45(World[i][45]);
		newRoom2.setV46(World[i][46]);
		newRoom2.setV47(World[i][47]);
		newRoom2.setV48(World[i][48]);
		newRoom2.setV49(World[i][49]);

	} // end buildCurrentRoom2

	public static void buildCurrentRoom(int i) throws Exception {
		newRoom = new room();

		// attempts to build the designated room number
		curRmNum = i; // the room we are building!

		// need these to reset the mobs/objs to null states
		tmob0 = new mob();
		tmob1 = new mob();
		tmob2 = new mob();
		tmob3 = new mob();
		tmob4 = new mob();
		tmob5 = new mob();

		tobj0 = new objects();
		tobj1 = new objects();
		tobj2 = new objects();
		tobj3 = new objects();
		tobj4 = new objects();
		tobj5 = new objects();

		// create new/current room
		newRoom.resetRoom();
		newRoom.setRoomNum(i);
		newRoom.setRoomName(World[i][1]);
		newRoom.setRoomShortDesc(World[i][2]);
		newRoom.setRoomLongDesc(World[i][3]);

		newRoom.setExitN(Integer.parseInt(World[i][4]));
		newRoom.setExitNE(Integer.parseInt(World[i][5]));
		newRoom.setExitE(Integer.parseInt(World[i][6]));
		newRoom.setExitSE(Integer.parseInt(World[i][7]));
		newRoom.setExitS(Integer.parseInt(World[i][8]));
		newRoom.setExitSW(Integer.parseInt(World[i][9]));
		newRoom.setExitW(Integer.parseInt(World[i][10]));
		newRoom.setExitNW(Integer.parseInt(World[i][11]));
		newRoom.setExitU(Integer.parseInt(World[i][12]));
		newRoom.setExitD(Integer.parseInt(World[i][13]));

		String arg = World[i][14].toString();
		String tstring = arg.replace("[", "").strip();
		tstring = tstring.replace("]", "").strip();
		tstring = tstring.replace(" ", "");
		tstring = tstring.replace("null", "0").strip();
		String[] arr = tstring.split(",");
		newRoom.setMobsInRoom(arr);

		arg = World[curRmNum][15].toString();
		tstring = arg.replace("[", "");
		tstring = tstring.replace("]", "");
		tstring = tstring.replace(" ", "");
		tstring = tstring.replace("null", "0").strip();
		arr = tstring.split(",");
		newRoom.setObjsInRoom(arr);

		newRoom.setLit(Integer.parseInt(World[curRmNum][16]));
		newRoom.setCamp(Integer.parseInt(World[curRmNum][17]));
		newRoom.setRent(Integer.parseInt(World[curRmNum][18]));
		newRoom.setInside(Integer.parseInt(World[curRmNum][19]));
		newRoom.setTerrain(Integer.parseInt(World[curRmNum][20]));
		newRoom.setBank(Integer.parseInt(World[curRmNum][21]));


		newRoom.setdNStatus(World[curRmNum][22]);
		newRoom.setdNEStatus(World[curRmNum][23]);
		newRoom.setdEStatus(World[curRmNum][24]);
		newRoom.setdSEStatus(World[curRmNum][25]);
		newRoom.setdSStatus(World[curRmNum][26]);
		newRoom.setdSWStatus(World[curRmNum][27]);
		newRoom.setdWStatus(World[curRmNum][28]);
		newRoom.setdNWStatus(World[curRmNum][29]);
		newRoom.setdUStatus(World[curRmNum][30]);
		newRoom.setdDStatus(World[curRmNum][31]);


		inoutside = newRoom.getInside();
		// create rooms for various directions

		int eN = newRoom.getExitN();
		int eNE = newRoom.getExitNE();
		int eE = newRoom.getExitE();
		int eSE = newRoom.getExitSE();
		int eS = newRoom.getExitS();
		int eSW = newRoom.getExitSW();
		int eW = newRoom.getExitW();
		int eNW = newRoom.getExitNW();
		int eU = newRoom.getExitU();
		int eD = newRoom.getExitD();

		if (0 != eN) {
			int t = Integer.parseInt(World[i][4]);
			exN.setRoomNum(t);
		}
		if (0 != eNE) {
			int t = Integer.parseInt(World[i][5]);
			exNE.setRoomNum(t);
		}
		if (0 != eE) {
			int t = Integer.parseInt(World[1][6]);
			exE.setRoomNum(t);
		}
		if (0 != eSE) {
			int t = Integer.parseInt(World[1][7]);
			exSE.setRoomNum(t);
		}
		if (0 != eS) {
			int t = Integer.parseInt(World[1][8]);
			exS.setRoomNum(t);
		}
		if (0 != eSW) {
			int t = Integer.parseInt(World[1][9]);
			exSW.setRoomNum(t);
		}
		if (0 != eW) {
			int t = Integer.parseInt(World[1][10]);
			exW.setRoomNum(t);
		}
		if (0 != eNW) {
			int t = Integer.parseInt(World[1][11]);
			exNW.setRoomNum(t);
		}
		if (eU != 0) {
			int t = Integer.parseInt(World[1][12]);
			exU.setRoomNum(t);
		}
		if (0 != eD) {
			int t = Integer.parseInt(World[1][13]);
			exD.setRoomNum(t);
		}
		if (0 != eN) {
			exN.setRoomShortDesc(World[eN][2]);
		}
		if (0 != eNE) {
			exNE.setRoomShortDesc(World[eNE][2]);
		}
		if (0 != eE) {
			exE.setRoomShortDesc(World[eE][2]);
		}
		if (0 != eSE) {
			exSE.setRoomShortDesc(World[eSE][2]);
		}
		if (0 != eS) {
			exS.setRoomShortDesc(World[eS][2]);
		}
		if (0 != eSW) {
			exSW.setRoomShortDesc(World[eSW][2]);
		}
		if (0 != eW) {
			exW.setRoomShortDesc(World[eW][2]);
		}
		if (0 != eNW) {
			exNW.setRoomShortDesc(World[eNW][2]);
		}
		if (0 != eU) {
			exU.setRoomShortDesc(World[eU][2]);
		}
		if (0 != eD) {
			exD.setRoomShortDesc(World[eD][2]);
		}

		// create the mobs for the room
		String tmobsar = newRoom.getMobsInRoom();

		tmobsar = tmobsar.replace("[", "");
		tmobsar = tmobsar.replace("]", "").strip();

		String[] tmobsarr = tmobsar.split(",");

		String tobjsar = newRoom.getObjsInRoom();

		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");

		String[] tobjsarr = tobjsar.split(",");

		tmob0.setMobNum(Integer.parseInt(tmobsarr[0].strip()));
		tmob1.setMobNum(Integer.parseInt(tmobsarr[1].strip()));
		tmob2.setMobNum(Integer.parseInt(tmobsarr[2].strip()));
		tmob3.setMobNum(Integer.parseInt(tmobsarr[3].strip()));
		tmob4.setMobNum(Integer.parseInt(tmobsarr[4].strip()));
		tmob5.setMobNum(Integer.parseInt(tmobsarr[5].strip()));

		tobj0.setObjNum(Integer.parseInt(tobjsarr[0].strip()));
		tobj1.setObjNum(Integer.parseInt(tobjsarr[1].strip()));
		tobj2.setObjNum(Integer.parseInt(tobjsarr[2].strip()));
		tobj3.setObjNum(Integer.parseInt(tobjsarr[3].strip()));
		tobj4.setObjNum(Integer.parseInt(tobjsarr[4].strip()));
		tobj5.setObjNum(Integer.parseInt(tobjsarr[5].strip()));

		int t0 = i;
		int t1 = i;
		int t2 = i;
		int t3 = i;
		int t4 = i;
		int t5 = i;

		if (Integer.parseInt(tmobsarr[0].strip()) != Integer.parseInt("0")) {
			t0 =Integer.parseInt(tmobsarr[0].strip());
			loadMob(tmob0,t0);
			loadMobInventory(t0);
		}
		if  (Integer.parseInt(tmobsarr[1].strip()) != Integer.parseInt("0")) {
			t1 =Integer.parseInt(tmobsarr[1].strip());
			loadMob(tmob1,t1);
			loadMobInventory(t1);
		}
		if (Integer.parseInt(tmobsarr[2].strip()) != Integer.parseInt("0")) {
			t2 =Integer.parseInt(tmobsarr[2].strip());
			loadMob(tmob2,t2);
			loadMobInventory(t2);
		}
		if (Integer.parseInt(tmobsarr[3].strip()) != Integer.parseInt("0")) {
			t3 =Integer.parseInt(tmobsarr[3].strip());
			loadMob(tmob3,t3);
			loadMobInventory(t3);
		}
		if (Integer.parseInt(tmobsarr[4].strip()) != Integer.parseInt("0")) {
			t4 =Integer.parseInt(tmobsarr[4].strip());
			loadMob(tmob4,t4);
			loadMobInventory(t4);
		}
		if (Integer.parseInt(tmobsarr[5].strip()) != Integer.parseInt("0")) {
			t5 =Integer.parseInt(tmobsarr[5].strip());
			loadMob(tmob5,t5);
			loadMobInventory(t5);
		}


		//		System.out.println(arg);
		//		System.out.println(tstring);
		//		System.out.println(arr[0]);


		// create the objs for the room
		if (tobjsarr[0].strip() != "0") {
			t0 = Integer.parseInt(tobjsarr[0].strip());
			loadObject(tobj0,t0);
		}
		if  (Integer.parseInt(tobjsarr[1].strip()) != Integer.parseInt("0")) {
			t1 = Integer.parseInt(tobjsarr[1].strip());
			loadObject(tobj1,t1);
		}
		if  (Integer.parseInt(tobjsarr[2].strip()) != Integer.parseInt("0")) {
			t2 = Integer.parseInt(tobjsarr[2].strip());
			loadObject(tobj2,t2);
		}
		if  (Integer.parseInt(tobjsarr[3].strip()) != Integer.parseInt("0")) {
			t3 = Integer.parseInt(tobjsarr[3].strip());
			loadObject(tobj3,t3);
		}
		if  (Integer.parseInt(tobjsarr[4].strip()) != Integer.parseInt("0")) {
			t4 = Integer.parseInt(tobjsarr[4].strip());
			loadObject(tobj4,t4);
		}
		if  (Integer.parseInt(tobjsarr[5].strip()) != Integer.parseInt("0")) {
			t5 = Integer.parseInt(tobjsarr[5].strip());
			loadObject(tobj5,t5);
		}










	} // end buildCurrentRoom()


	public void start() {
		// START THE WORLD!
		// cancel/clear any existing timers
		suntimer.cancel();
		moontimer1.cancel();
		moontimer2.cancel();
		moontimer3.cancel();
		raintimer.cancel();

		// make new timers
		suntimer = new Timer("Sunrise");
		moontimer1 = new Timer("Moon1rise");
		moontimer2 = new Timer("Moon2rise");
		moontimer3 = new Timer("Moon3rise");
		raintimer = new Timer("Rainy Weather");

		Date executionDate = new Date(); // no params = now
		Date executionDate1 = new Date();
		Date executionDate2 = new Date();
		Date executionDate3 = new Date();
		Date executionDate4 = new Date();

		// start the timers
		suntimer.scheduleAtFixedRate(task, executionDate, sundelay);
		moontimer1.scheduleAtFixedRate(task1, executionDate1, moon1delay);
		moontimer2.scheduleAtFixedRate(task2, executionDate2, moon2delay);
		moontimer3.scheduleAtFixedRate(task3, executionDate3, moon3delay);
		raintimer.scheduleAtFixedRate(task4, executionDate4, rainyweather);

	}  // end start()

	public void stop() {
		// cancel/clear any existing timers
		suntimer.cancel();
		moontimer1.cancel();
		moontimer2.cancel();
		moontimer3.cancel();
		raintimer.cancel();

	}

} // end engine







////////////////////////////////////////////////////////////////////////////////////////////
//
//    DEVELOPMENT IDEAS
//
//
////////////////////////////////////////////////////////////////////////////////////////////

/*
 *
 *   XP for lvl 1-2 = 1000 XP, lvl 2-3 = 1500, lvl 3-4 = 2250, 3375, 5063, 7594...
 *   XP increases by 1.5x per subsequent level
 *
 *   lvl 1 mob = 75 XP
 *   mob XP = 75 * (1.2^mob lvl)
 * 	 player XP decreased by 20% per level ABOVE the mobs
 *   player XP increases by 20% per level BELOW the mobs
 *
 *   being in a group/party increases mob XP to (2 * mob XP)/(# party members)
 *
 *
 *
 * 	mob ranks:
 * 		mobs can have ranks, higher ranks increase their health and damage
 * 		null/common/normal - hp, dps the same
 * 		elite - hp, dps increase by 125%
 * 		chieftain - hp, dps increase 150%
 * 		lord - hp, dps increase 175%
 * 		high lord - hp, dps increase 200%
 * 		great lord - hp, dps increase 225%
 * 		grand lord - hp, dps increase 250%
 * 		Mythic - hp, dps increase 300%
 * 		God Rank - hp, dps increase 1000%
 *
 *
 *  Player Tiers:
 *  	Players start at tier 0, increase 1 tier every 10 levels?
 *  	spells and abilities are unlocked depending on player tier
 *
 *
 *  Player Classes:
 *  	Warrior
 *  	Mage
 * 		Cleric
 * 		Druid
 * 		Assassin
 * 		Ranger
 *
 */






