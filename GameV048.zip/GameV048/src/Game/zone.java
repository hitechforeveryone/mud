package Game;
//TODO
// THE GAME CURRENTLY DOES NOT USE THIS AT ALL THIS IS FOR DESIGN PURPOSES

/////////////////////////////////
// zone should have 100 rooms in it (0-99), the array will continue to build around you if you skip a room
// each room can have up to 6 mobs and 6 objects in it
/////////////////////////////////

public class zone {
	// TODO

	int zoneNum = 0; //0 // should be up to 6 digits?    
	String zoneOwner = "none"; //1 Char name?
	String zoneName = "none"; //2 optional
	int zoneResetState = 0; // states are 
	int resetTimer; //3 time till zone reloads, in weeks or months? not sure how this will work just yet

	mob tmob0 = new mob();
	mob tmob1 = new mob();
	mob tmob2 = new mob();
	mob tmob3 = new mob();
	mob tmob4 = new mob();
	mob tmob5 = new mob();
	
	objects tobj0 = new objects();
	objects tobj1 = new objects();
	objects tobj2 = new objects();
	objects tobj3 = new objects();
	objects tobj4 = new objects();
	objects tobj5 = new objects();
	
	String rmNums; // = "00,01,02,03,04,05,06,07,08,09,10,01,02,03,04,05,06,07,08,09,20,01,02,03,04,05,06,07,08,09,30,01,02,03,04,05,06,07,08,09,40,01,02,03,04,05,06,07,08,09,50,01,02,03,04,05,06,07,08,09,60,01,02,03,04,05,06,07,08,09,70,01,02,03,04,05,06,07,08,09,80,01,02,03,04,05,06,07,08,09,90,01,02,03,04,05,06,07,08,09, ";
	room rm00 = new room(); // should be 2 digits, this is separate from the room's ID number
	room rm01 = new room();
	room rm02 = new room();
	room rm03 = new room();
	room rm04 = new room();
	room rm05 = new room();
	room rm06 = new room();
	room rm07 = new room();
	room rm08 = new room();
	room rm09 = new room();

	room rm10;
	room rm11;
	room rm12;
	room rm13;
	room rm14;
	room rm15;
	room rm16;
	room rm17;
	room rm18;
	room rm19;

	room rm20;
	room rm21;
	room rm22;
	room rm23;
	room rm24;
	room rm25;
	room rm26;
	room rm27;
	room rm28;
	room rm29;

	room rm30;
	room rm31;
	room rm32;
	room rm33;
	room rm34;
	room rm35;
	room rm36;
	room rm37;
	room rm38;
	room rm39;

	room rm40;
	room rm41;
	room rm42;
	room rm43;
	room rm44;
	room rm45;
	room rm46;
	room rm47;
	room rm48;
	room rm49;

	room rm50;
	room rm51;
	room rm52;
	room rm53;
	room rm54;
	room rm55;
	room rm56;
	room rm57;
	room rm58;
	room rm59;

	room rm60;
	room rm61;
	room rm62;
	room rm63;
	room rm64;
	room rm65;
	room rm66;
	room rm67;
	room rm68;
	room rm69;

	room rm70;
	room rm71;
	room rm72;
	room rm73;
	room rm74;
	room rm75;
	room rm76;
	room rm77;
	room rm78;
	room rm79;

	room rm80;
	room rm81;
	room rm82;
	room rm83;
	room rm84;
	room rm85;
	room rm86;
	room rm87;
	room rm88;
	room rm89;

	room rm90;
	room rm91;
	room rm92;
	room rm93;
	room rm94;
	room rm95;
	room rm96;
	room rm97;
	room rm98;
	room rm99;




	public void resetZone() {
		zoneNum = 0; //0 // should be up to 6 digits?    
		zoneOwner = "none"; //1 Char name?
		zoneName = "none"; //2 optional
		resetTimer = 300; //3 time till zone reloads, in weeks or months? not sure how this will work just yet
		
		String newString="";//
	
		rmNums = newString; // = "00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,08,09,40,01,02,03,04,05,06,07,08,09,50,01,02,03,04,05,06,07,08,09,60,01,02,03,04,05,06,07,08,09,70,01,02,03,04,05,06,07,08,09,80,01,02,03,04,05,06,07,08,09,90,01,02,03,04,05,06,07,08,09, ";
		
		tmob0 = new mob();
		tmob1 = new mob();
		tmob2 = new mob();
		tmob3 = new mob();
		tmob4 = new mob();
		tmob5 = new mob();
		
		tobj0 = new objects();
		tobj1 = new objects();
		tobj2 = new objects();
		tobj3 = new objects();
		tobj4 = new objects();
		tobj5 = new objects();
		
		rm00 = new room(); // should be 2 digits, this is separate from the room's ID number
		rm01 = new room();
		rm02 = new room();
		rm03 = new room();
		rm04 = new room();
		rm05 = new room();
		rm06 = new room();
		rm07 = new room();
		rm08 = new room();
		rm09 = new room();

		rm10 = new room();
		rm11 = new room();
		rm12 = new room();
		rm13 = new room();
		rm14 = new room();
		rm15 = new room();
		rm16 = new room();
		rm17 = new room();
		rm18 = new room();
		rm19 = new room();

		rm20 = new room();
		rm21 = new room();
		rm22 = new room();
		rm23 = new room();
		rm24 = new room();
		rm25 = new room();
		rm26 = new room();
		rm27 = new room();
		rm28 = new room();
		rm29 = new room();

		rm30 = new room();
		rm31 = new room();
		rm32 = new room();
		rm33 = new room();
		rm34 = new room();
		rm35 = new room();
		rm36 = new room();
		rm37 = new room();
		rm38 = new room();
		rm39 = new room();

		rm40 = new room();
		rm41 = new room();
		rm42 = new room();
		rm43 = new room();
		rm44 = new room();
		rm45 = new room();
		rm46 = new room();
		rm47 = new room();
		rm48 = new room();
		rm49 = new room();

		rm50 = new room();
		rm51 = new room();
		rm52 = new room();
		rm53 = new room();
		rm54 = new room();
		rm55 = new room();
		rm56 = new room();
		rm57 = new room();
		rm58 = new room();
		rm59 = new room();

		rm60 = new room();
		rm61 = new room();
		rm62 = new room();
		rm63 = new room();
		rm64 = new room();
		rm65 = new room();
		rm66 = new room();
		rm67 = new room();
		rm68 = new room();
		rm69 = new room();

		rm70 = new room();
		rm71 = new room();
		rm72 = new room();
		rm73 = new room();
		rm74 = new room();
		rm75 = new room();
		rm76 = new room();
		rm77 = new room();
		rm78 = new room();
		rm79 = new room();

		rm80 = new room();
		rm81 = new room();
		rm82 = new room();
		rm83 = new room();
		rm84 = new room();
		rm85 = new room();
		rm86 = new room();
		rm87 = new room();
		rm88 = new room();
		rm89 = new room();

		rm90 = new room();
		rm91 = new room();
		rm92 = new room();
		rm93 = new room();
		rm94 = new room();
		rm95 = new room();
		rm96 = new room();
		rm97 = new room();
		rm98 = new room();
		rm99 = new room();


	} // end resetZone()




	public int getZoneNum() {
		return zoneNum;
	}




	public void setZoneNum(int zoneNum) {
		this.zoneNum = zoneNum;
	}




	public String getZoneOwner() {
		return zoneOwner;
	}




	public void setZoneOwner(String zoneOwner) {
		this.zoneOwner = zoneOwner;
	}




	public String getZoneName() {
		return zoneName;
	}




	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}




	public int getResetTimer() {
		return resetTimer;
	}




	public void setResetTimer(int resetTimer) {
		this.resetTimer = resetTimer;
	}




	public room getRm00() {
		return rm00;
	}




	public void setRm00(room rm00) {
		this.rm00 = rm00;
	}




	public room getRm01() {
		return rm01;
	}




	public void setRm01(room rm01) {
		this.rm01 = rm01;
	}




	public room getRm02() {
		return rm02;
	}




	public void setRm02(room rm02) {
		this.rm02 = rm02;
	}




	public room getRm03() {
		return rm03;
	}




	public void setRm03(room rm03) {
		this.rm03 = rm03;
	}




	public room getRm04() {
		return rm04;
	}




	public void setRm04(room rm04) {
		this.rm04 = rm04;
	}




	public room getRm05() {
		return rm05;
	}




	public void setRm05(room rm05) {
		this.rm05 = rm05;
	}




	public room getRm06() {
		return rm06;
	}




	public void setRm06(room rm06) {
		this.rm06 = rm06;
	}




	public room getRm07() {
		return rm07;
	}




	public void setRm07(room rm07) {
		this.rm07 = rm07;
	}




	public room getRm08() {
		return rm08;
	}




	public void setRm08(room rm08) {
		this.rm08 = rm08;
	}




	public room getRm09() {
		return rm09;
	}




	public void setRm09(room rm09) {
		this.rm09 = rm09;
	}




	public room getRm10() {
		return rm10;
	}




	public void setRm10(room rm10) {
		this.rm10 = rm10;
	}




	public room getRm11() {
		return rm11;
	}




	public void setRm11(room rm11) {
		this.rm11 = rm11;
	}




	public room getRm12() {
		return rm12;
	}




	public void setRm12(room rm12) {
		this.rm12 = rm12;
	}




	public room getRm13() {
		return rm13;
	}




	public void setRm13(room rm13) {
		this.rm13 = rm13;
	}




	public room getRm14() {
		return rm14;
	}




	public void setRm14(room rm14) {
		this.rm14 = rm14;
	}




	public room getRm15() {
		return rm15;
	}




	public void setRm15(room rm15) {
		this.rm15 = rm15;
	}




	public room getRm16() {
		return rm16;
	}




	public void setRm16(room rm16) {
		this.rm16 = rm16;
	}




	public room getRm17() {
		return rm17;
	}




	public void setRm17(room rm17) {
		this.rm17 = rm17;
	}




	public room getRm18() {
		return rm18;
	}




	public void setRm18(room rm18) {
		this.rm18 = rm18;
	}




	public room getRm19() {
		return rm19;
	}




	public void setRm19(room rm19) {
		this.rm19 = rm19;
	}




	public room getRm20() {
		return rm20;
	}




	public void setRm20(room rm20) {
		this.rm20 = rm20;
	}




	public room getRm21() {
		return rm21;
	}




	public void setRm21(room rm21) {
		this.rm21 = rm21;
	}




	public room getRm22() {
		return rm22;
	}




	public void setRm22(room rm22) {
		this.rm22 = rm22;
	}




	public room getRm23() {
		return rm23;
	}




	public void setRm23(room rm23) {
		this.rm23 = rm23;
	}




	public room getRm24() {
		return rm24;
	}




	public void setRm24(room rm24) {
		this.rm24 = rm24;
	}




	public room getRm25() {
		return rm25;
	}




	public void setRm25(room rm25) {
		this.rm25 = rm25;
	}




	public room getRm26() {
		return rm26;
	}




	public void setRm26(room rm26) {
		this.rm26 = rm26;
	}




	public room getRm27() {
		return rm27;
	}




	public void setRm27(room rm27) {
		this.rm27 = rm27;
	}




	public room getRm28() {
		return rm28;
	}




	public void setRm28(room rm28) {
		this.rm28 = rm28;
	}




	public room getRm29() {
		return rm29;
	}




	public void setRm29(room rm29) {
		this.rm29 = rm29;
	}




	public room getRm30() {
		return rm30;
	}




	public void setRm30(room rm30) {
		this.rm30 = rm30;
	}




	public room getRm31() {
		return rm31;
	}




	public void setRm31(room rm31) {
		this.rm31 = rm31;
	}




	public room getRm32() {
		return rm32;
	}




	public void setRm32(room rm32) {
		this.rm32 = rm32;
	}




	public room getRm33() {
		return rm33;
	}




	public void setRm33(room rm33) {
		this.rm33 = rm33;
	}




	public room getRm34() {
		return rm34;
	}




	public void setRm34(room rm34) {
		this.rm34 = rm34;
	}




	public room getRm35() {
		return rm35;
	}




	public void setRm35(room rm35) {
		this.rm35 = rm35;
	}




	public room getRm36() {
		return rm36;
	}




	public void setRm36(room rm36) {
		this.rm36 = rm36;
	}




	public room getRm37() {
		return rm37;
	}




	public void setRm37(room rm37) {
		this.rm37 = rm37;
	}




	public room getRm38() {
		return rm38;
	}




	public void setRm38(room rm38) {
		this.rm38 = rm38;
	}




	public room getRm39() {
		return rm39;
	}




	public void setRm39(room rm39) {
		this.rm39 = rm39;
	}




	public room getRm40() {
		return rm40;
	}




	public void setRm40(room rm40) {
		this.rm40 = rm40;
	}




	public room getRm41() {
		return rm41;
	}




	public void setRm41(room rm41) {
		this.rm41 = rm41;
	}




	public room getRm42() {
		return rm42;
	}




	public void setRm42(room rm42) {
		this.rm42 = rm42;
	}




	public room getRm43() {
		return rm43;
	}




	public void setRm43(room rm43) {
		this.rm43 = rm43;
	}




	public room getRm44() {
		return rm44;
	}




	public void setRm44(room rm44) {
		this.rm44 = rm44;
	}




	public room getRm45() {
		return rm45;
	}




	public void setRm45(room rm45) {
		this.rm45 = rm45;
	}




	public room getRm46() {
		return rm46;
	}




	public void setRm46(room rm46) {
		this.rm46 = rm46;
	}




	public room getRm47() {
		return rm47;
	}




	public void setRm47(room rm47) {
		this.rm47 = rm47;
	}




	public room getRm48() {
		return rm48;
	}




	public void setRm48(room rm48) {
		this.rm48 = rm48;
	}




	public room getRm49() {
		return rm49;
	}




	public void setRm49(room rm49) {
		this.rm49 = rm49;
	}




	public room getRm50() {
		return rm50;
	}




	public void setRm50(room rm50) {
		this.rm50 = rm50;
	}




	public room getRm51() {
		return rm51;
	}




	public void setRm51(room rm51) {
		this.rm51 = rm51;
	}




	public room getRm52() {
		return rm52;
	}




	public void setRm52(room rm52) {
		this.rm52 = rm52;
	}




	public room getRm53() {
		return rm53;
	}




	public void setRm53(room rm53) {
		this.rm53 = rm53;
	}




	public room getRm54() {
		return rm54;
	}




	public void setRm54(room rm54) {
		this.rm54 = rm54;
	}




	public room getRm55() {
		return rm55;
	}




	public void setRm55(room rm55) {
		this.rm55 = rm55;
	}




	public room getRm56() {
		return rm56;
	}




	public void setRm56(room rm56) {
		this.rm56 = rm56;
	}




	public room getRm57() {
		return rm57;
	}




	public void setRm57(room rm57) {
		this.rm57 = rm57;
	}




	public room getRm58() {
		return rm58;
	}




	public void setRm58(room rm58) {
		this.rm58 = rm58;
	}




	public room getRm59() {
		return rm59;
	}




	public void setRm59(room rm59) {
		this.rm59 = rm59;
	}




	public room getRm60() {
		return rm60;
	}




	public void setRm60(room rm60) {
		this.rm60 = rm60;
	}




	public room getRm61() {
		return rm61;
	}




	public void setRm61(room rm61) {
		this.rm61 = rm61;
	}




	public room getRm62() {
		return rm62;
	}




	public void setRm62(room rm62) {
		this.rm62 = rm62;
	}




	public room getRm63() {
		return rm63;
	}




	public void setRm63(room rm63) {
		this.rm63 = rm63;
	}




	public room getRm64() {
		return rm64;
	}




	public void setRm64(room rm64) {
		this.rm64 = rm64;
	}




	public room getRm65() {
		return rm65;
	}




	public void setRm65(room rm65) {
		this.rm65 = rm65;
	}




	public room getRm66() {
		return rm66;
	}




	public void setRm66(room rm66) {
		this.rm66 = rm66;
	}




	public room getRm67() {
		return rm67;
	}




	public void setRm67(room rm67) {
		this.rm67 = rm67;
	}




	public room getRm68() {
		return rm68;
	}




	public void setRm68(room rm68) {
		this.rm68 = rm68;
	}




	public room getRm69() {
		return rm69;
	}




	public void setRm69(room rm69) {
		this.rm69 = rm69;
	}




	public room getRm70() {
		return rm70;
	}




	public void setRm70(room rm70) {
		this.rm70 = rm70;
	}




	public room getRm71() {
		return rm71;
	}




	public void setRm71(room rm71) {
		this.rm71 = rm71;
	}




	public room getRm72() {
		return rm72;
	}




	public void setRm72(room rm72) {
		this.rm72 = rm72;
	}




	public room getRm73() {
		return rm73;
	}




	public void setRm73(room rm73) {
		this.rm73 = rm73;
	}




	public room getRm74() {
		return rm74;
	}




	public void setRm74(room rm74) {
		this.rm74 = rm74;
	}




	public room getRm75() {
		return rm75;
	}




	public void setRm75(room rm75) {
		this.rm75 = rm75;
	}




	public room getRm76() {
		return rm76;
	}




	public void setRm76(room rm76) {
		this.rm76 = rm76;
	}




	public room getRm77() {
		return rm77;
	}




	public void setRm77(room rm77) {
		this.rm77 = rm77;
	}




	public room getRm78() {
		return rm78;
	}




	public void setRm78(room rm78) {
		this.rm78 = rm78;
	}




	public room getRm79() {
		return rm79;
	}




	public void setRm79(room rm79) {
		this.rm79 = rm79;
	}




	public room getRm80() {
		return rm80;
	}




	public void setRm80(room rm80) {
		this.rm80 = rm80;
	}




	public room getRm81() {
		return rm81;
	}




	public void setRm81(room rm81) {
		this.rm81 = rm81;
	}




	public room getRm82() {
		return rm82;
	}




	public void setRm82(room rm82) {
		this.rm82 = rm82;
	}




	public room getRm83() {
		return rm83;
	}




	public void setRm83(room rm83) {
		this.rm83 = rm83;
	}




	public room getRm84() {
		return rm84;
	}




	public void setRm84(room rm84) {
		this.rm84 = rm84;
	}




	public room getRm85() {
		return rm85;
	}




	public void setRm85(room rm85) {
		this.rm85 = rm85;
	}




	public room getRm86() {
		return rm86;
	}




	public void setRm86(room rm86) {
		this.rm86 = rm86;
	}




	public room getRm87() {
		return rm87;
	}




	public void setRm87(room rm87) {
		this.rm87 = rm87;
	}




	public room getRm88() {
		return rm88;
	}




	public void setRm88(room rm88) {
		this.rm88 = rm88;
	}




	public room getRm89() {
		return rm89;
	}




	public void setRm89(room rm89) {
		this.rm89 = rm89;
	}




	public room getRm90() {
		return rm90;
	}




	public void setRm90(room rm90) {
		this.rm90 = rm90;
	}




	public room getRm91() {
		return rm91;
	}




	public void setRm91(room rm91) {
		this.rm91 = rm91;
	}




	public room getRm92() {
		return rm92;
	}




	public void setRm92(room rm92) {
		this.rm92 = rm92;
	}




	public room getRm93() {
		return rm93;
	}




	public void setRm93(room rm93) {
		this.rm93 = rm93;
	}




	public room getRm94() {
		return rm94;
	}




	public void setRm94(room rm94) {
		this.rm94 = rm94;
	}




	public room getRm95() {
		return rm95;
	}




	public void setRm95(room rm95) {
		this.rm95 = rm95;
	}




	public room getRm96() {
		return rm96;
	}




	public void setRm96(room rm96) {
		this.rm96 = rm96;
	}




	public room getRm97() {
		return rm97;
	}




	public void setRm97(room rm97) {
		this.rm97 = rm97;
	}




	public room getRm98() {
		return rm98;
	}




	public void setRm98(room rm98) {
		this.rm98 = rm98;
	}




	public room getRm99() {
		return rm99;
	}




	public void setRm99(room rm99) {
		this.rm99 = rm99;
	}


	public void returnZoneInfo() {
		// returns relevant info for the zone
				System.out.println("from returnZoneInfo()");
				System.out.println("Zone ID Num: " + getZoneNum()); //0
				System.out.println("Zone Owner: " + getZoneOwner()); //1
				System.out.println("Zone Name: " + getZoneName()); //2
				System.out.println("Zone ResetTimer: " + getResetTimer()); //2
				
				// add more zone info here // room # and room names?
	}

	@Override
	public String toString() {
		return getZoneNum() + "|" + getZoneOwner() + "|" + getZoneName() + "|" + getResetTimer() + "|" + getRm00() + "|" 
				+ getRm01() + "|" + getRm02() + "|" + getRm03() + "|" + getRm04() + "|" + getRm05() + "|" + getRm06() + "|" + getRm07() 
				+ "|" + getRm08() + "|" + getRm09() + "|" + getRm10() + "|" + getRm11() + "|" + getRm12() + "|" + getRm13() + "|" + getRm14()
				+ "|" + getRm15() + "|" + getRm16() + "|" + getRm17() + "|" + getRm18() + "|" + getRm19() + "|" + getRm20() + "|" + getRm21()
				+ "|" + getRm22() + "|" + getRm23() + "|" + getRm24() + "|" + getRm25() + "|" + getRm26() + "|" + getRm27() + "|" + getRm28()
				+ "|" + getRm29() + "|" + getRm30() + "|" + getRm31() + "|" + getRm32() + "|" + getRm33() + "|" + getRm34() + "|" + getRm35()
				+ "|" + getRm36() + "|" + getRm37() + "|" + getRm38() + "|" + getRm39() + "|" + getRm40() + "|" + getRm41() + "|" + getRm42()
				+ "|" + getRm43() + "|" + getRm44() + "|" + getRm45() + "|" + getRm46() + "|" + getRm47() + "|" + getRm48() + "|" + getRm49()
				+ "|" + getRm50() + "|" + getRm51() + "|" + getRm52() + "|" + getRm53() + "|" + getRm54() + "|" + getRm55() + "|" + getRm56()
				+ "|" + getRm57() + "|" + getRm58() + "|" + getRm59() + "|" + getRm60() + "|" + getRm61() + "|" + getRm62() + "|" + getRm63()
				+ "|" + getRm64() + "|" + getRm65() + "|" + getRm66() + "|" + getRm67() + "|" + getRm68() + "|" + getRm69() + "|" + getRm70()
				+ "|" + getRm71() + "|" + getRm72() + "|" + getRm73() + "|" + getRm74() + "|" + getRm75() + "|" + getRm76() + "|" + getRm77()
				+ "|" + getRm78() + "|" + getRm79() + "|" + getRm80() + "|" + getRm81() + "|" + getRm82() + "|" + getRm83() + "|" + getRm84()
				+ "|" + getRm85() + "|" + getRm86() + "|" + getRm87() + "|" + getRm88() + "|" + getRm89() + "|" + getRm90() + "|" + getRm91()
				+ "|" + getRm92() + "|" + getRm93() + "|" + getRm94() + "|" + getRm95() + "|" + getRm96() + "|" + getRm97() + "|" + getRm98()
				+ "|" + getRm99() ;
	}


	

	
	

} // end zone ....





// TODO
// scripts which load mobs and objs? doors? // load next zone

// roomScript srm00;  // create as needed? // set mob and obj defaults to all 0s?
// setObj0(0,100);setObj1(0,100);setOBj2(0,100);setObj3(0,100);setObj4(0,100);setObj5(0,100); //  set the obj to 0 at 100%?

// setMob0(0,100);setMob1(0,100);setMob2(0,100);setMob3(0,100);setMob4(0,100);setMob5(0,100); // set the mob to 0 at 100%?

// tmob0Head(0,1000;tmob0Neck(0,100);tmob0Shoulder(0,100);tmob0Chest(0,100);tmob0Wrist(0,100);tmob0Hand(0,100);tmob0Finger1(0,100);tmob0Finger2(0,100);
// tmob0Waist(0,100);tmob0Leg(0,100);tmob0Foot(0,100);tmob0Trinket1(0,100);tmob0Trinket2(0,100);tmob0Weapon1(0,100);tmob0Weaponshield(0,100); // set all equip to obj 0 at 100%?

// script load zone xxxxxx
//		to be used for loading next zones
//		to be used for loading the 6 objs in the rooms
//		to be used for loading the 6 mobs in the rooms
//		to be used for loading the equip on the mobs



