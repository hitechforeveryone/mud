package Game;

import java.util.Arrays;

// TODO
// This is supposed to be a collection of rm#'s, the objs and the mobs with their load %'s InRooms, door states//status
// to be used with load/reloading zones? zone timers? for zone resets?

public class zoneScript {
	int zoneNum = 0;

	// rmID #'s to load from db?
	int rm00ID = 0;
	int rm01ID = 0;
	int rm02ID = 0;
	int rm03ID = 0;
	int rm04ID = 0;
	int rm05ID = 0;
	int rm06ID = 0;
	int rm07ID = 0;
	int rm08ID = 0;
	int rm09ID = 0;
	int rm10ID = 0;
	int rm11ID = 0;
	int rm12ID = 0;
	int rm13ID = 0;
	int rm14ID = 0;
	int rm15ID = 0;
	int rm16ID = 0;
	int rm17ID = 0;
	int rm18ID = 0;
	int rm19ID = 0;
	int rm20ID = 0;
	int rm21ID = 0;
	int rm22ID = 0;
	int rm23ID = 0;
	int rm24ID = 0;
	int rm25ID = 0;
	int rm26ID = 0;
	int rm27ID = 0;
	int rm28ID = 0;
	int rm29ID = 0;
	int rm30ID = 0;
	int rm31ID = 0;
	int rm32ID = 0;
	int rm33ID = 0;
	int rm34ID = 0;
	int rm35ID = 0;
	int rm36ID = 0;
	int rm37ID = 0;
	int rm38ID = 0;
	int rm39ID = 0;
	int rm40ID = 0;
	int rm41ID = 0;
	int rm42ID = 0;
	int rm43ID = 0;
	int rm44ID = 0;
	int rm45ID = 0;
	int rm46ID = 0;
	int rm47ID = 0;
	int rm48ID = 0;
	int rm49ID = 0;
	int rm50ID = 0;
	int rm51ID = 0;
	int rm52ID = 0;
	int rm53ID = 0;
	int rm54ID = 0;
	int rm55ID = 0;
	int rm56ID = 0;
	int rm57ID = 0;
	int rm58ID = 0;
	int rm59ID = 0;
	int rm60ID = 0;
	int rm61ID = 0;
	int rm62ID = 0;
	int rm63ID = 0;
	int rm64ID = 0;
	int rm65ID = 0;
	int rm66ID = 0;
	int rm67ID = 0;
	int rm68ID = 0;
	int rm69ID = 0;
	int rm70ID = 0;
	int rm71ID = 0;
	int rm72ID = 0;
	int rm73ID = 0;
	int rm74ID = 0;
	int rm75ID = 0;
	int rm76ID = 0;
	int rm77ID = 0;
	int rm78ID = 0;
	int rm79ID = 0;
	int rm80ID = 0;
	int rm81ID = 0;
	int rm82ID = 0;
	int rm83ID = 0;
	int rm84ID = 0;
	int rm85ID = 0;
	int rm86ID = 0;
	int rm87ID = 0;
	int rm88ID = 0;
	int rm89ID = 0;
	int rm90ID = 0;
	int rm91ID = 0;
	int rm92ID = 0;
	int rm93ID = 0;
	int rm94ID = 0;
	int rm95ID = 0;
	int rm96ID = 0;
	int rm97ID = 0;
	int rm98ID = 0;
	int rm99ID = 0;

	// rm00
	// rm00 tobj0
	String rm00obj0 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj0ID = 0; // obj ID num from db
	int rm00obj0Perc = 0; // load %
	int rm00obj0cCont0ID = 0; // slot 0
	int rm00obj0cCont0Perc = 0; //
	int rm00obj0cCont1ID = 0; // slot 1
	int rm00obj0cCont1Perc = 0; //
	int rm00obj0cCont2ID = 0; // slot 2
	int rm00obj0cCont2Perc = 0; //
	int rm00obj0cCont3ID = 0; // slot 3
	int rm00obj0cCont3Perc = 0; //
	int rm00obj0cCont4ID = 0; // slot 4
	int rm00obj0cCont4Perc = 0; //
	int rm00obj0cCont5ID = 0; // slot 5
	int rm00obj0cCont5Perc = 0; //
	// rm00 tobj1
	String rm00obj1 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj1ID = 0; // obj ID num from db
	int rm00obj1Perc = 0; // load %
	int rm00obj1cCont0ID = 0; // slot 0
	int rm00obj1cCont0Perc = 0; //
	int rm00obj1cCont1ID = 0; // slot 1
	int rm00obj1cCont1Perc = 0; //
	int rm00obj1cCont2ID = 0; // slot 2
	int rm00obj1cCont2Perc = 0; //
	int rm00obj1cCont3ID = 0; // slot 3
	int rm00obj1cCont3Perc = 0; //
	int rm00obj1cCont4ID = 0; // slot 4
	int rm00obj1cCont4Perc = 0; //
	int rm00obj1cCont5ID = 0; // slot 5
	int rm00obj1cCont5Perc = 0; //
	// rm00 tobj2
	String rm00obj2 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj2ID = 0; // obj ID num from db
	int rm00obj2Perc = 0; // load %
	int rm00obj2cCont0ID = 0; // slot 0
	int rm00obj2cCont0Perc = 0; //
	int rm00obj2cCont1ID = 0; // slot 1
	int rm00obj2cCont1Perc = 0; //
	int rm00obj2cCont2ID = 0; // slot 2
	int rm00obj2cCont2Perc = 0; //
	int rm00obj2cCont3ID = 0; // slot 3
	int rm00obj2cCont3Perc = 0; //
	int rm00obj2cCont4ID = 0; // slot 4
	int rm00obj2cCont4Perc = 0; //
	int rm00obj2cCont5ID = 0; // slot 5
	int rm00obj2cCont5Perc = 0; //
	// rm00 tobj3
	String rm00obj3 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj3ID = 0; // obj ID num from db
	int rm00obj3Perc = 0; // load %
	int rm00obj3cCont0ID = 0; // slot 0
	int rm00obj3cCont0Perc = 0; //
	int rm00obj3cCont1ID = 0; // slot 1
	int rm00obj3cCont1Perc = 0; //
	int rm00obj3cCont2ID = 0; // slot 2
	int rm00obj3cCont2Perc = 0; //
	int rm00obj3cCont3ID = 0; // slot 3
	int rm00obj3cCont3Perc = 0; //
	int rm00obj3cCont4ID = 0; // slot 4
	int rm00obj3cCont4Perc = 0; //
	int rm00obj3cCont5ID = 0; // slot 5
	int rm00obj3cCont5Perc = 0; //
	// rm00 tobj4
	String rm00obj4 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj4ID = 0; // obj ID num from db
	int rm00obj4Perc = 0; // load %
	int rm00obj4cCont0ID = 0; // slot 0
	int rm00obj4cCont0Perc = 0; //
	int rm00obj4cCont1ID = 0; // slot 1
	int rm00obj4cCont1Perc = 0; //
	int rm00obj4cCont2ID = 0; // slot 2
	int rm00obj4cCont2Perc = 0; //
	int rm00obj4cCont3ID = 0; // slot 3
	int rm00obj4cCont3Perc = 0; //
	int rm00obj4cCont4ID = 0; // slot 4
	int rm00obj4cCont4Perc = 0; //
	int rm00obj4cCont5ID = 0; // slot 5
	int rm00obj4cCont5Perc = 0; //
	// rm00 tobj5
	String rm00obj5 = "0/0,0/0/0/0/0/0,0/0/0/0/0/0"; // default 0 state?
	int rm00obj5ID = 0; // obj ID num from db
	int rm00obj5Perc = 0; // load %
	int rm00obj5cCont0ID = 0; // slot 0
	int rm00obj5cCont0Perc = 0; //
	int rm00obj5cCont1ID = 0; // slot 1
	int rm00obj5cCont1Perc = 0; //
	int rm00obj5cCont2ID = 0; // slot 2
	int rm00obj5cCont2Perc = 0; //
	int rm00obj5cCont3ID = 0; // slot 3
	int rm00obj5cCont3Perc = 0; //
	int rm00obj5cCont4ID = 0; // slot 4
	int rm00obj5cCont4Perc = 0; //
	int rm00obj5cCont5ID = 0; // slot 5
	int rm00obj5cCont5Perc = 0; //

	// rm00 tmob0
	String rm00mob0 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob0ID = 0;
	int rm00mob0Perc = 0; 
	int rm00mob0HeadID = 0;
	int rm00mob0HeadPerc = 0;
	int rm00mob0NeckID = 0;
	int rm00mob0NeckPerc = 0;
	int rm00mob0ShoulderID = 0;
	int rm00mob0ShoulderPerc = 0;
	int rm00mob0WristID = 0;
	int rm00mob0WristPerc = 0;
	int rm00mob0HandsID = 0;
	int rm00mob0HandsPerc = 0;
	int rm00mob0Finger1ID = 0;
	int rm00mob0Finger1Perc = 0;
	int rm00mob0Finger2ID = 0;
	int rm00mob0Finger2Perc = 0;
	int rm00mob0WaistID = 0;
	int rm00mob0WaistPerc = 0;
	int rm00mob0LegID = 0;
	int rm00mob0LegPerc = 0;
	int rm00mob0FootID = 0;
	int rm00mob0FootPerc = 0;
	int rm00mob0Trinket1ID = 0;
	int rm00mob0Trinket1Perc = 0;
	int rm00mob0Trinket2ID = 0;
	int rm00mob0Trinket2Perc = 0;
	int rm00mob0Weapon1ID = 0;
	int rm00mob0Weapon1Perc = 0;
	int rm00mob0WeaponShieldID = 0;
	int rm00mob0WeaponShieldPerc = 0;
	// rm00 tmob1
	String rm00mob1 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob1ID = 0;
	int rm00mob1Perc = 0; 
	int rm00mob1HeadID = 0;
	int rm00mob1HeadPerc = 0;
	int rm00mob1NeckID = 0;
	int rm00mob1NeckPerc = 0;
	int rm00mob1ShoulderID = 0;
	int rm00mob1ShoulderPerc = 0;
	int rm00mob1WristID = 0;
	int rm00mob1WristPerc = 0;
	int rm00mob1HandsID = 0;
	int rm00mob1HandsPerc = 0;
	int rm00mob1Finger1ID = 0;
	int rm00mob1Finger1Perc = 0;
	int rm00mob1Finger2ID = 0;
	int rm00mob1Finger2Perc = 0;
	int rm00mob1WaistID = 0;
	int rm00mob1WaistPerc = 0;
	int rm00mob1LegID = 0;
	int rm00mob1LegPerc = 0;
	int rm00mob1FootID = 0;
	int rm00mob1FootPerc = 0;
	int rm00mob1Trinket1ID = 0;
	int rm00mob1Trinket1Perc = 0;
	int rm00mob1Trinket2ID = 0;
	int rm00mob1Trinket2Perc = 0;
	int rm00mob1Weapon1ID = 0;
	int rm00mob1Weapon1Perc = 0;
	int rm00mob1WeaponShieldID = 0;
	int rm00mob1WeaponShieldPerc = 0;	
	// rm00 tmob2
	String rm00mob2 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob2ID = 0;
	int rm00mob2Perc = 0; 
	int rm00mob2HeadID = 0;
	int rm00mob2HeadPerc = 0;
	int rm00mob2NeckID = 0;
	int rm00mob2NeckPerc = 0;
	int rm00mob2ShoulderID = 0;
	int rm00mob2ShoulderPerc = 0;
	int rm00mob2WristID = 0;
	int rm00mob2WristPerc = 0;
	int rm00mob2HandsID = 0;
	int rm00mob2HandsPerc = 0;
	int rm00mob2Finger1ID = 0;
	int rm00mob2Finger1Perc = 0;
	int rm00mob2Finger2ID = 0;
	int rm00mob2Finger2Perc = 0;
	int rm00mob2WaistID = 0;
	int rm00mob2WaistPerc = 0;
	int rm00mob2LegID = 0;
	int rm00mob2LegPerc = 0;
	int rm00mob2FootID = 0;
	int rm00mob2FootPerc = 0;
	int rm00mob2Trinket1ID = 0;
	int rm00mob2Trinket1Perc = 0;
	int rm00mob2Trinket2ID = 0;
	int rm00mob2Trinket2Perc = 0;
	int rm00mob2Weapon1ID = 0;
	int rm00mob2Weapon1Perc = 0;
	int rm00mob2WeaponShieldID = 0;
	int rm00mob2WeaponShieldPerc = 0;	
	// rm00 tmob3
	String rm00mob3 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob3ID = 0;
	int rm00mob3Perc = 0; 
	int rm00mob3HeadID = 0;
	int rm00mob3HeadPerc = 0;
	int rm00mob3NeckID = 0;
	int rm00mob3NeckPerc = 0;
	int rm00mob3ShoulderID = 0;
	int rm00mob3ShoulderPerc = 0;
	int rm00mob3WristID = 0;
	int rm00mob3WristPerc = 0;
	int rm00mob3HandsID = 0;
	int rm00mob3HandsPerc = 0;
	int rm00mob3Finger1ID = 0;
	int rm00mob3Finger1Perc = 0;
	int rm00mob3Finger2ID = 0;
	int rm00mob3Finger2Perc = 0;
	int rm00mob3WaistID = 0;
	int rm00mob3WaistPerc = 0;
	int rm00mob3LegID = 0;
	int rm00mob3LegPerc = 0;
	int rm00mob3FootID = 0;
	int rm00mob3FootPerc = 0;
	int rm00mob3Trinket1ID = 0;
	int rm00mob3Trinket1Perc = 0;
	int rm00mob3Trinket2ID = 0;
	int rm00mob3Trinket2Perc = 0;
	int rm00mob3Weapon1ID = 0;
	int rm00mob3Weapon1Perc = 0;
	int rm00mob3WeaponShieldID = 0;
	int rm00mob3WeaponShieldPerc = 0;	
	//rm00 tmob4
	String rm00mob4 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob4ID = 0;
	int rm00mob4Perc = 0; 
	int rm00mob4HeadID = 0;
	int rm00mob4HeadPerc = 0;
	int rm00mob4NeckID = 0;
	int rm00mob4NeckPerc = 0;
	int rm00mob4ShoulderID = 0;
	int rm00mob4ShoulderPerc = 0;
	int rm00mob4WristID = 0;
	int rm00mob4WristPerc = 0;
	int rm00mob4HandsID = 0;
	int rm00mob4HandsPerc = 0;
	int rm00mob4Finger1ID = 0;
	int rm00mob4Finger1Perc = 0;
	int rm00mob4Finger2ID = 0;
	int rm00mob4Finger2Perc = 0;
	int rm00mob4WaistID = 0;
	int rm00mob4WaistPerc = 0;
	int rm00mob4LegID = 0;
	int rm00mob4LegPerc = 0;
	int rm00mob4FootID = 0;
	int rm00mob4FootPerc = 0;
	int rm00mob4Trinket1ID = 0;
	int rm00mob4Trinket1Perc = 0;
	int rm00mob4Trinket2ID = 0;
	int rm00mob4Trinket2Perc = 0;
	int rm00mob4Weapon1ID = 0;
	int rm00mob4Weapon1Perc = 0;
	int rm00mob4WeaponShieldID = 0;
	int rm00mob4WeaponShieldPerc = 0;
	//rm00 tmob5
	String rm00mob5 = "0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0,0/0/0/0/0/0/0/0/0/0/0/0/0/0/0";
	int rm00mob5ID = 0;
	int rm00mob5Perc = 0; 
	int rm00mob5HeadID = 0;
	int rm00mob5HeadPerc = 0;
	int rm00mob5NeckID = 0;
	int rm00mob5NeckPerc = 0;
	int rm00mob5ShoulderID = 0;
	int rm00mob5ShoulderPerc = 0;
	int rm00mob5WristID = 0;
	int rm00mob5WristPerc = 0;
	int rm00mob5HandsID = 0;
	int rm00mob5HandsPerc = 0;
	int rm00mob5Finger1ID = 0;
	int rm00mob5Finger1Perc = 0;
	int rm00mob5Finger2ID = 0;
	int rm00mob5Finger2Perc = 0;
	int rm00mob5WaistID = 0;
	int rm00mob5WaistPerc = 0;
	int rm00mob5LegID = 0;
	int rm00mob5LegPerc = 0;
	int rm00mob5FootID = 0;
	int rm00mob5FootPerc = 0;
	int rm00mob5Trinket1ID = 0;
	int rm00mob5Trinket1Perc = 0;
	int rm00mob5Trinket2ID = 0;
	int rm00mob5Trinket2Perc = 0;
	int rm00mob5Weapon1ID = 0;
	int rm00mob5Weapon1Perc = 0;
	int rm00mob5WeaponShieldID = 0;
	int rm00mob5WeaponShieldPerc = 0;
	
	//...
	
	
	
	// rm00 door state, status, key, short and long desc's
	String rm00dNfullStatus = "notDoor/open/0 (none)/none/none";//22 door N isdoor/state/key/short desc/long desc as string?
	String rm00dNEfullStatus = "notDoor/open/0 (none)/none/none";	
	String rm00dEfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dSEfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dSfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dSWfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dWfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dNWfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dUfullStatus = "notDoor/open/0 (none)/none/none";
	String rm00dDfullStatus = "notDoor/open/0 (none)/none/none"; // door D isDoor/state/key/short desc /long desc as string?

	String rm00dNFlag = "notDoor";
	String rm00dNState = "open";
	int rm00dNKey = 0;
	String rm00dNsDesc = "none";
	String rm00dNlDesc = "none";

	
	
	
	
	// ... repeat for rm001-99

	
	
	
	
	
	// for when player enters rm,X load zone Y
	// remember, only have up to 12 zones to load? currentZone, previousZone nextZone1-10
	// ZonestoLoad[x][y]
	// int[][] ZonestoLoad = new int[500][2]; // 100rms*5?zentries x 2 




}