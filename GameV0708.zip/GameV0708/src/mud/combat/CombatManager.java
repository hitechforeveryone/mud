package mud.combat;

import mud.config.Config;
import mud.core.*;
import mud.spell.effects.*;

import java.util.*;
import java.util.stream.Collectors;

public class CombatManager {
	private static final Random random = new Random();

	public static class CombatMessages {
	    public String attackerMsg;
	    public String targetMsg;
	    public String roomMsg;

	    public CombatMessages(String attackerMsg, String targetMsg, String roomMsg) {
	        this.attackerMsg = attackerMsg;
	        this.targetMsg = targetMsg;
	        this.roomMsg = roomMsg;
	    }
	}

	// -----------------------
	// PERFORM ATTACK REFACTORED
	// -----------------------
	public static String performAttack(Mob attacker, Mob target) {
	    if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
	        return "Invalid combatants.";
	    }

	    attacker.setInCombat(true);
	    target.setInCombat(true);

	    List<String> allMessages = new ArrayList<>();

	    ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
	    ObjectItem offHand  = attacker.getEquipment().get(EquipSlot.OFFHAND);

	    // MAIN ATTACK
	    allMessages.add(performSingleAttack(attacker, target, mainHand, false));

	    // SECONDHIT
	    if ((attacker.hasAffect(MobAffectFlag.SECONDHIT) || attacker.hasEffect("second_hit")) && mainHand == null) {
	        double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
	        if (Math.random() < chance) {
	            allMessages.add(performSingleAttack(attacker, target, null, true));
	        }
	    }

	    // DOUBLEATTACK
	    if ((attacker.hasAffect(MobAffectFlag.DOUBLEATTACK) || attacker.hasEffect("double_attack")) && mainHand != null && mainHand.isWeapon()) {
	        double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
	        if (Math.random() < chance) {
	            allMessages.add(performSingleAttack(attacker, target, mainHand, true));
	        }
	    }

	    // OFFHANDHIT
	    if ((attacker.hasAffect(MobAffectFlag.OFFHANDHIT) || attacker.hasEffect("offhand_hit")) && offHand == null) {
	        double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
	        if (Math.random() < chance) {
	            allMessages.add(performSingleAttack(attacker, target, null, true));
	        }
	    }

	    // DUALWIELD
	    if ((attacker.hasAffect(MobAffectFlag.DUALWIELD) || attacker.hasEffect("dual_wield")) && offHand != null && offHand.isWeapon()) {
	        double chance = Math.min(0.03 * attacker.getLevel(), 0.4);
	        if (Math.random() < chance) {
	            allMessages.add(performSingleAttack(attacker, target, offHand, true));
	        }
	    }

	    // Handle counter-attack
	    if (!target.isDead() && target.getTarget() == null) {
	        target.setTarget(attacker);
	        // Optionally, you could immediately perform a reactive attack:
	        // allMessages.add(performSingleAttack(target, attacker, target.getEquipment().get(EquipSlot.MAINHAND), false));
	    }



	    // Check for death AFTER all attacks
	    if (target.isDead() || target.getCurrentHP() <= 0) {
	        endCombat(attacker, target);
	    }

	    // Return combined messages for logging/testing
	    return String.join("\n", allMessages);
	    
	}

	// -----------------------
	// PERFORM SINGLE ATTACK REFACTORED
	// -----------------------
	private static String performSingleAttack(Mob attacker, Mob target, ObjectItem weapon, boolean isOffhand) {

	    double vorpalDamage = (weapon != null && weapon.isVorpal()) ? 1.25 : 1.0;
	    int intDamage = (weapon != null && weapon.isIntelligent()) ? weapon.getFlatDamage() : 0;

	    WeaponDamageType dmgType = (weapon != null && weapon.getDamageType() != null) ? weapon.getDamageType() : WeaponDamageType.HIT;
	    String icon = dmgType.getIcon();
	    String verb = dmgType.getPrettyName().toLowerCase();
	    String handLabel = isOffhand ? " (offhand)" : "";

	    int baseDamage = rollWeaponDamage(weapon, attacker);
	    int bonusDamage = attacker.getStat("Strength") / 2;
	    double scaledDamage = ((baseDamage * vorpalDamage) + intDamage + bonusDamage) * attacker.getRank().getMultiplier();
	    int totalDamage = (int) scaledDamage;

	    int totalDefenseBonus = target.getEquipment().values().stream()
	            .filter(obj -> obj != null && obj.getArmorType() != null)
	            .mapToInt(obj -> obj.getArmorType().getDefenseBonus())
	            .sum();
	    totalDefenseBonus = Math.min(totalDefenseBonus, 99);

	    if (handleDefensiveIllusions(attacker, target)) {
	        return "Your attack missed!"; // simplified legacy-friendly
	    }

	    double reduction = (1.0 - (totalDefenseBonus / 100.0));
	    int damageTaken = (int) Math.max(1, Math.round(totalDamage * reduction));
	    target.takeDamage(damageTaken);

	    if (weapon != null && weapon.getVampiricPercent() > 0) {
	        int vampHeal = (int) (damageTaken * weapon.getVampiricPercent());
	        if (vampHeal > 0) attacker.heal(vampHeal);
	    }

	    FireShieldEffect.onTargetHit(attacker, target, damageTaken);

	    if (target.getCurrentHP() <= 0) {
	        deathStuff(attacker, target);
	    }

	    // Return a single string for legacy code
	    return String.format("%s %s%s %s for %d damage! %s",
	            attacker.getMobName(), verb, handLabel, target.getMobName(), damageTaken, icon);
	}

	
	
	private static void endCombat(Mob attacker, Mob target) {
		attacker.setInCombat(false);
		target.setInCombat(false);
		attacker.setTarget(null);
		target.setTarget(null);
	}
	// end


	public static String getCombatStatus(Mob a, Mob b) {
		return a.getMobName() + ":HP: " + a.getCurrentHP() + "/" + a.getMaxHP() +
				" MP: " + a.getCurrentMP() + "/" + a.getMaxMP() + "  " +
				b.getMobName() + ":HP: " + b.getCurrentHP() + "/" + b.getMaxHP() +
				" MP: " + b.getCurrentMP() + "/" + b.getMaxMP();
	}

	

	public static void playerDeathStuff(Player target) {
		clearCombatState(target);
		target.setDead(true);
		target.setCurrentHP(0);

		target.removeAllCombatEffects(); // you should add this helper

		target.sendMessage("You have been slain!");

		Room room = target.getRoom();
		if (room != null)
			room.removeMob(target);

		target.setCurrentHP(1);
		target.setPendingLogout(true);

	}


	public static void deathStuff(Mob attacker, Mob target) {
		if (attacker == null || target == null) return;
		if (target.getCurrentHP() > 0) return;

		Room room = target.getRoom();
		if (room == null) return;

		// --- Stop all combat involving target ---
		clearCombatState(attacker);
		clearCombatState(target);
		clearAggroOn(target);

		target.setDead(true);

		// --- REINCARNATE ---
		if (target.hasAffect(MobAffectFlag.REINCARNATE)) {
			int remaining = target.getReincarnateRemaining();
			if (remaining > 0) {
				target.setReincarnateRemaining(remaining - 1);
				target.setCurrentHP(Math.max(1, target.getMaxHP() / 2));
				target.setDead(false);

				room.broadcastToRoom(
						target.getMobName() + " rises again! (" + (remaining - 1) + " reincarnations left)"
						);

				if (remaining - 1 <= 0)
					target.removeAffect(MobAffectFlag.REINCARNATE);

				return;
			}
		}

		// --- NOKILL ---
		if (target.hasAffect(MobAffectFlag.NOKILL)) {
			target.setCurrentHP(1);
			target.setDead(false);

			if (attacker instanceof Player)
				attacker.sendMessage("You cannot kill " + target.getMobName() + ".");

			clearCombatState(attacker);
			clearCombatState(target);
			clearAggroOn(target);

			return;
		}

		// --- PLAYER DEATH ---
		if (target instanceof Player player) {
			playerDeathStuff(player);
			return; // player handles its own removal
		}

		// --- NPC DEATH ---
		room.broadcastToRoom(target.getMobName() + " has been slain!");

		// XP reward
		// XP reward
		if (attacker instanceof Player p) {
		    p.gainExpShared(target.getExpReward());
		}
		// end



		// Loot → corpse
		List<ObjectItem> loot = target.dropAllLoot();
		ObjectItem corpse = new ObjectItem("corpse of " + target.getMobName());
		corpse.setShortDescription("a corpse of " + target.getShortDescription());

		corpse.setType(ObjectType.CONTAINER);
		String corpseKeys = "corpse, " + target.getMobName();
		corpse.setKeywords(corpseKeys);
		corpse.setContents(loot);
		corpse.setCorpse(true);
		corpse.setDecayTicks(4 * Config.ticksPerDay); // assuming 1 day = X ticks

		room.addObject(corpse);

		// Remove from world
		room.removeMob(target);
		target.setCurrentRoom(null);

		// --- BERSERK RETARGET ---
		if (attacker.hasEffect(EffectType.BERSERK)) {
			Mob next = room.findRandomHostile(attacker);
			if (next != null) {
				attacker.setTarget(next);
				attacker.setCurrentTarget(next);
				attacker.setInCombat(true);
				room.broadcastToRoom(
						attacker.getMobName() + " snarls and turns to fight " + next.getMobName() + "!"
						);
			}
		}
	}


	private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
		if (weapon == null || weapon.getDamageDice() == null) {
			int level = attacker.getLevel();
			if (level >= 75) return rollDice(4, 6);
			if (level >= 50) return rollDice(3, 6);
			if (level >= 20) return rollDice(2, 6);
			if (level >= 10) return rollDice(1, 8);
			return rollDice(1, 6);
		}

		String[] parts = weapon.getDamageDice().split("d");
		int num = Integer.parseInt(parts[0]);
		int sides = Integer.parseInt(parts[1]);

		return rollDice(num, sides) + weapon.getDamageBonus();
	}

	private static int rollDice(int num, int sides) {
		int total = 0;
		for (int i = 0; i < num; i++) {
			total += random.nextInt(sides) + 1;
		}
		return total;
	}

	private static void clearCombatState(Mob m) {
		if (m == null) return;
		m.setInCombat(false);
		m.setTarget(null);
		m.setCurrentTarget(null);
	}

	private static void clearAggroOn(Mob dead) {
		for (Mob m : WorldManager.getAllMobs()) {
			if (m.getTarget() == dead || m.getCurrentTarget() == dead) {
				clearCombatState(m);
			}
		}
	}

	private static boolean handleDefensiveIllusions(Mob attacker, Mob defender) {

		MirrorImageEffect mie = defender.getEffect(MirrorImageEffect.class);
		if (mie != null && mie.getImages() > 0) {
			if (mie.onIncomingAttack(attacker, defender)) {
				attacker.sendMessage("Your attack strikes a mirror image!");
				defender.sendMessage("An incoming attack shatters one of your mirror images!");
				if (defender.getRoom() != null)
					defender.getRoom().broadcastToExcept(attacker, defender,
							attacker.getMobName() + "'s attack strikes a mirror image!");
				return true;
			}
		}

		ShadowCloneEffect sce = defender.getEffect(ShadowCloneEffect.class);
		if (sce != null && sce.getImages() > 0) {
			if (sce.onIncomingAttack(attacker, defender)) {
				attacker.sendMessage("Your attack is intercepted by a shadow clone!");
				defender.sendMessage("A shadow clone absorbs the blow!");
				if (defender.getRoom() != null)
					defender.getRoom().broadcastToExcept(attacker, defender,
							attacker.getMobName() + "'s attack strikes a shadow clone!");
				return true;
			}
		}

		BoneShieldEffect bse = defender.getEffect(BoneShieldEffect.class);
		if (bse != null && bse.getImages() > 0) {
			if (bse.onIncomingAttack(attacker, defender)) {
				attacker.sendMessage("Your attack is absorbed by a bone shield!");
				defender.sendMessage("Your bone shield cracks under the blow!");
				if (defender.getRoom() != null)
					defender.getRoom().broadcastToExcept(attacker, defender,
							attacker.getMobName() + "'s attack strikes a bone shield!");
				return true;
			}
		}
		
		// more defensives/illusions go here
	
		

		return false;
	}



	
} // end combatManager
