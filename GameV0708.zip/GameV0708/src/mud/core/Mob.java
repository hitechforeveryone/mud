package mud.core;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import mud.server.ClientHandler;
import mud.spell.*;
import mud.spell.effects.*;
import mud.Shop.ShopProfile;

public class Mob implements HasKeywords {

	
	// Identity

	private String mobName = "Unknown";                 // Capitalized display name
	private String shortDescription = "an unknown figure";   // fragment like "a dark shadowy figure"
	private String longDescription = "";                // auto-generated if empty
	private String extendedDescription = "There's nothing particularly noteworthy about it."; // look/examine output
	private Room room;

	private Room currentRoom;

	private String race = "humanoid"; // enforced for players
	private String subrace = "none";
	private String mobType;

	private MobRank rank = MobRank.COMMON; // Default rank

	//protected Inventory inventory = new Inventory();
	private List<ObjectItem> inventory = new ArrayList<>();
	protected Map<EquipSlot, ObjectItem> equipment = new HashMap<>();

	protected Profession profession = Profession.NONE;
	protected SpellRegister spellRegister;

	private int level = 1; // 1-100

	private int baseHP;
	private int baseMP;

	// Base stats before equipment/effects
	private int baseStrength;
	private int baseStamina;
	private int baseIntellect;
	private int baseAgility;
	private int baseCharisma;
	private int baseHitroll;
	private int baseDamroll;

	// Current stats including buffs/equipment
	private int strength;
	private int stamina;
	private int intellect;
	private int agility;
	private int charisma;

	// Current and max HP/MP
	private int currentHP;
	private int maxHP;
	private int currentMP;
	private int maxMP;

	private int damageAbsorbPoints = 0;


	// Currency
	private int copper = 0;
	private int silver = 0;
	private int gold = 0;
	private int platinum = 0;

	private boolean canDualWield = false;

	protected List<Effect> activeEffects = new ArrayList<>();
	protected List<EffectType> actEffects = new ArrayList<>();
	private List<DamageReductionEffect> activeDamageReductions = new ArrayList<>();
	private List<HealOverTimeEffect> activeHealOverTimeEffects = new ArrayList<>();

	private Mob currentTarget;

	private Party party;
	// New flags:
	private boolean isBlacksmith = false;
	@SuppressWarnings("unused")
	private boolean isInnkeeper = false;
	@SuppressWarnings("unused")
	private boolean shopKeeper = false;

	public boolean isDead = false;
	//	private int behaviorFlags = 0;
	private Set<MobBehaviorFlag> behaviorFlags = EnumSet.noneOf(MobBehaviorFlag.class);
	private int affectFlags = 0;

	// Optional details for specific roles
	private String sentryDirection = null;
	private String sentryMessage = null;
	private List<String> speeches = new ArrayList<>();
	private int reincarnateMax = 0;
	private int reincarnateRemaining = 0;
	private int blacksmithFixCostPerDurability = 1; // Example

	private long lastAttackTime = 0;
	private static final long ATTACK_COOLDOWN_MS = 1000; // 1 second


	private static AtomicInteger nextId = new AtomicInteger(1); // Unique ID generator
	private int id;
	
	public Mob() {
		this.id = nextId.getAndIncrement();
		this.baseHP = 100;
		this.baseMP = 100;
		this.currentHP = baseHP;
		this.currentMP = baseMP;

	}

	public Mob(int id) {
		this.id = nextId.getAndIncrement();
	}

	public Mob(String mobName) {
		this.id = nextId.getAndIncrement();
		setMobName(mobName); // also sets shortDescription unless customized later
	}

	public Mob(String name, String description) {
		this(name);
		this.id = nextId.getAndIncrement();
		this.shortDescription = description;
		addKeyword(name);
		addKeyword("mob");
	}

	public Mob(String name, String description, String race, String subrace) {
		this(name, description);
		this.id = nextId.getAndIncrement();
		setRace(race);
		setSubrace(subrace);
	}

	public Mob(String name, Profession profession, SpellRegister spellRegister) {
		this(name);
		this.id = nextId.getAndIncrement();
		this.profession = profession;
		this.spellRegister = spellRegister;
		checkAndApplyPassiveSpells();
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}



	// --------- Race/Subrace -----------

	public void setRace(String race) {
		this.race = race.toLowerCase();
		addKeyword(this.race);
	}

	public void setSubrace(String subrace) {
		this.subrace = subrace.toLowerCase();
		addKeyword(this.subrace);
	}

	public String getRace() { return race; }
	public String getSubrace() { return subrace; }

	// --------- Equipment -----------

	public void equip(EquipSlot slot, ObjectItem item) {
		equipment.put(slot, item);
	}

	public ObjectItem unequip(EquipSlot slot) {
		ObjectItem removed = equipment.remove(slot);
		if (removed != null) {
			//	removed.setEquipSlot(null);
		}
		return removed;
	}

	public ObjectItem unequip(String keyword) {
		for (var entry : equipment.entrySet()) {
			ObjectItem item = entry.getValue();
			if (item != null && item.hasKeyword(keyword)) {
				equipment.remove(entry.getKey());
				//item.setEquipSlot(null);
				return item;
			}
		}
		return null;
	}

	public Map<EquipSlot, ObjectItem> getEquipment() {
		return equipment;
	}


	public int getBaseHP() { return baseHP; }
	public int getBaseMP() { return baseMP; }
	public void setBaseHP(int hp) { this.baseHP = hp; }
	public void setBaseMP(int mp) { this.baseMP = mp; }

	public int getCurrentHP() { return currentHP; }
	public int getCurrentMP() { return currentMP; }
	public void setCurrentHP(int hp) {
		this.currentHP = Math.max(0, Math.min(hp, getMaxHP()));
	}
	public void setCurrentMP(int mp) {
		this.currentMP = Math.max(0, Math.min(mp, getMaxMP()));
	}

	public int getMaxHP() {
		int base = (stamina * 10) + (strength * 2) + baseHP;
		int gearBonus = getEquippedBonus("HP");
		int effectBonus = getEffectBonus("HP");
		double scaled = (base + gearBonus + effectBonus) * rank.getMultiplier();
		return (int) Math.round(scaled);
	}

	public int getMaxMP() {
		int base = (intellect * 10) + baseMP + getEquippedBonus("MP") + getEffectBonus("MP");
		return base;
	}

	public int getStrength() { return strength; }
	public void setStrength(int val) { this.strength = val; }

	public int getStamina() { return stamina; }
	public void setStamina(int val) { this.stamina = val; }

	public int getIntellect() { return intellect; }
	public void setIntellect(int val) { this.intellect = val; }

	public int getAgility() { return agility; }
	public void setAgility(int val) { this.agility = val; }

	public int getCharisma() { return charisma; }
	public void setCharisma(int val) { this.charisma = val; }

	private int getEquippedBonus(String stat) {
		int total = 0;
		for (ObjectItem item : equipment.values()) {
			if (item == null) continue;
			switch (stat.toUpperCase()) {
			case "HP": total += item.getHpBonus(); break;
			case "MP": total += item.getMpBonus(); break;
			case "STRENGTH": total += item.getStrengthBonus(); break;
			case "STAMINA": total += item.getStaminaBonus(); break;
			case "INTELLECT": total += item.getIntellectBonus(); break;
			case "AGILITY": total += item.getAgilityBonus(); break;
			case "CHARISMA": total += item.getCharismaBonus(); break;
			case "HITROLL": total += item.getHitrollBonus(); break;
			case "DAMROLL": total += item.getDamrollBonus(); break;
			}
		}
		return total;
	}

	public int getEffectBonus(String stat) {
		int total = 0;
		for (Effect e : activeEffects) {
			switch (stat.toUpperCase()) {
			case "HP": total += e.getHpBonus(); break;
			case "MP": total += e.getMpBonus(); break;
			case "STRENGTH": total += e.getStrengthBonus(); break;
			case "STAMINA": total += e.getStaminaBonus(); break;
			case "INTELLECT": total += e.getIntellectBonus(); break;
			case "AGILITY": total += e.getAgilityBonus(); break;
			case "CHARISMA": total += e.getCharismaBonus();
			case "HITROLL": total += e.getHitrollBonus(); break;
			case "DAMROLL": total += e.getDamrollBonus(); break;
			}
		}
		return total;
	}

	// --------- Damage and healing -----------

	public int absorbDamage(int damage) {
		if (damageAbsorbPoints <= 0) return damage;
		int rem = damage - damageAbsorbPoints;
		if (rem < 0) {
			damageAbsorbPoints = -rem;
			return 0;
		} else {
			damageAbsorbPoints = 0;
			return rem;
		}
	}

	public void takeDamage(int damage) {
		int effective = absorbDamage(damage);
		currentHP -= effective;
		if (currentHP < 0) currentHP = 0;
	}

	public void takeDamage(int amount, MagicDamageType type) {
		// You can later use type for resistances
		this.takeDamage(amount); // fall back to basic method for now
	}

	public void heal(int amount) {
		if (amount <= 0) return;
		currentHP = currentHP + amount;
		if (currentHP >= maxHP) {
			currentHP = maxHP;
		}
	}

	public boolean isDead() {
		return isDead;
	}

	// --------- Damage Absorb -----------

	public int getDamageAbsorbPoints() {
		return damageAbsorbPoints;
	}

	public void setDamageAbsorbPoints(int val) {
		damageAbsorbPoints = val;
	}

	public boolean addDamageAbsorb(int amount) {
		if (damageAbsorbPoints > 0) return false;
		damageAbsorbPoints = amount;
		return true;
	}
	public boolean hasKeyword(String keyword) {
		if (keyword == null || keyword.isEmpty()) return false;
		String lower = keyword.toLowerCase();

		// Check keywords list
		for (String k : keywords) {
			String kk = k.toLowerCase();
			if (kk.equals(lower)) return true;
			if (kk.startsWith(lower)) return true;    // allows "swo" -> "sword"	
		}

		// Check mob name
		if (mobName.toLowerCase().equals(lower)) {
			return true;
		}

		// Check race
		if (race.toLowerCase().equals(lower)) {
			return true;
		}

		// Check subrace
		if (subrace.toLowerCase().equals(lower)) {
			return true;
		}

		return false;
	}



	// --------- Active Effects -----------

	public boolean hasEffect(String effectName) {
		if (activeEffects == null || activeEffects.isEmpty()) {
			//	System.out.println("🔍 No active effects.");
			return false;
		}

		for (Effect effect : activeEffects) {
			System.out.println("🔍 Checking effect: " + effect.getName());
			if (effect.getName().equalsIgnoreCase(effectName)) {
				//		System.out.println("✅ Matched effect: " + effectName);
				return true;
			}
		}

		return false;
	}

	public boolean hasEffect(EffectType type) {
		return actEffects.contains(type);
	}



	public void removeEffect(String name) {
		activeEffects.removeIf(e -> e.getName().equalsIgnoreCase(name));
	}

	public void addEffect(Effect effect) {
		if (effect != null && !hasEffect(effect.getName())) {
			activeEffects.add(effect);
			effect.onApply(this);
		}
	}

	public void addEffect(EffectType effect) {
		actEffects.add(effect);
	}

	public void tickEffects() {
		Iterator<Effect> it = activeEffects.iterator();
		while (it.hasNext()) {
			Effect effect = it.next();
			effect.tick();
			if (effect.isExpired()) {
				effect.onRemove();
				it.remove();
			}
		}
	}

	// --------- Damage Reduction Effects -----------

	public void addDamageReductionEffect(DamageReductionEffect effect) {
		activeDamageReductions.add(effect);
	}

	public int applyDamageReductions(int damage) {
		int reduced = damage;
		for (DamageReductionEffect e : activeDamageReductions) {
			reduced = e.reduceDamage(reduced);
		}
		return reduced;
	}

	// --------- Heal Over Time -----------

	public void addHealOverTimeEffect(HealOverTimeEffect effect) {
		if (effect != null) activeHealOverTimeEffects.add(effect);
	}

	// --------- Target -----------

	public Mob getTarget() {
		return currentTarget;
	}

	public void setTarget(Mob target) {
		this.currentTarget = target;
	}

	public boolean isAttacking() {
		return currentTarget != null;
	}

	// --------- Profession and Spells -----------

	public Profession getProfession() { return profession; }

	public void setProfession(Profession profession) {
		this.profession = profession;
		checkAndApplyPassiveSpells();
	}

	public SpellRegister getSpellRegister() { return spellRegister; }

	public void setSpellRegister(SpellRegister spellRegister) {
		this.spellRegister = spellRegister;
	}

	public Spell getSpellByName(String spellName) {
		if (spellRegister == null || profession == null || spellName == null) return null;
		return spellRegister.getSpell(profession, spellName.toLowerCase());
	}

	public boolean castSpell(String spellName, Mob target) {
		Spell spell = getSpellByName(spellName);
		if (spell == null) {
			sendMessage("You do not know a spell called '" + spellName + "'.");
			return false;
		}
		return spell.cast(this, target);
	}

	public void checkAndApplyPassiveSpells() {
		if (spellRegister == null || profession == null) return;

		for (String spellName : spellRegister.getSpellsFor(profession)) {
			Spell spell = spellRegister.getSpell(profession, spellName);
			if (spell instanceof DualWieldSpell dualWield) {
				dualWield.applyPassive(this);
			}
			if (spell instanceof DoubleAttackSpell doubleAttack) {
				doubleAttack.applyPassive(this);
			}
			if (spell instanceof OffhandHitSpell ohit) {
				ohit.applyPassive(this);
			}
			if (spell instanceof SecondHitSpell shit) {
				shit.applyPassive(this);
			}

			// Extend here for other passives
			
		}
	}

	// --------- Messaging -----------
	private transient ClientHandler handler;
	public void sendMessage(String message) {
		System.out.println("[Mob] " + getMobName() + ": " + message);

		if (handler != null) handler.sendMessage(message);

	}
	// === Client Connection ===
	public void setClientHandler(ClientHandler handler) {
		this.handler = handler;
	}

	public ClientHandler getClientHandler() {
		return handler;
	}
	// --------- Currency -----------

	public int getCopper() { return copper; }
	public int getSilver() { return silver; }
	public int getGold() { return gold; }
	public int getPlatinum() { return platinum; }

	public void addCopper(int amount) {
		copper += amount;
		normalizeCurrency();
	}

	public boolean subtractCopper(int amount) {
		convertToCopper();
		copper -= amount;
		if (copper < 0) copper = 0;
		normalizeCurrency();
		return true;
	}

	public int getTotalCopper() {
		return copper + (silver * 100) + (gold * 1000) + (platinum * 10000);
	}

	private void convertToCopper() {
		copper = getTotalCopper();
		silver = 0;
		gold = 0;
		platinum = 0;
	}

	private void normalizeCurrency() {
		int total = getTotalCopper();
		platinum = total / 10000;
		total %= 10000;
		gold = total / 1000;
		total %= 1000;
		silver = total / 100;
		copper = total % 100;
	}

	public String getMoneyString() {
		List<String> parts = new ArrayList<>();
		if (platinum > 0) parts.add(platinum + "p");
		if (gold > 0) parts.add(gold + "g");
		if (silver > 0) parts.add(silver + "s");
		if (copper > 0) parts.add(copper + "c");
		return parts.isEmpty() ? "no coins" : String.join(" ", parts);
	}


	// --------- Rank -----------

	public MobRank getRank() { return rank; }
	public void setRank(MobRank rank) { this.rank = rank; }


	// --------- Custom flags -----------

	public Room getCurrentRoom() {
		return currentRoom;
	}

	public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

	public String getMobType() {
		return mobType;
	}

	public void setMobType(String mobType) {
		this.mobType = mobType;
	}

	public int getBaseStrength() {
		return baseStrength;
	}

	public void setBaseStrength(int baseStrength) {
		this.baseStrength = baseStrength;
	}

	public int getBaseStamina() {
		return baseStamina;
	}

	public void setBaseStamina(int baseStamina) {
		this.baseStamina = baseStamina;
	}

	public int getBaseIntellect() {
		return baseIntellect;
	}

	public void setBaseIntellect(int baseIntellect) {
		this.baseIntellect = baseIntellect;
	}

	public int getBaseAgility() {
		return baseAgility;
	}

	public void setBaseAgility(int baseAgility) {
		this.baseAgility = baseAgility;
	}

	public boolean isCanDualWield() {
		return canDualWield;
	}

	public void setCanDualWield(boolean canDualWield) {
		this.canDualWield = canDualWield;
	}

	public Mob getCurrentTarget() {
		return currentTarget;
	}

	public void setCurrentTarget(Mob currentTarget) {
		this.currentTarget = currentTarget;
	}

	public List<Effect> getActiveEffects() {
		return activeEffects;
	}

	public List<DamageReductionEffect> getActiveDamageReductions() {
		return activeDamageReductions;
	}

	public List<HealOverTimeEffect> getActiveHealOverTimeEffects() {
		return activeHealOverTimeEffects;
	}

	public void setEquipment(Map<EquipSlot, ObjectItem> equipment) {
		this.equipment = equipment;
	}


	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public void setMaxMP(int maxMP) {
		this.maxMP = maxMP;
	}

	public void setCopper(int copper) {
		this.copper = copper;
	}

	public void setSilver(int silver) {
		this.silver = silver;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public void setPlatinum(int platinum) {
		this.platinum = platinum;
	}

	public void setShopInventory(List<ObjectItem> shopInventory) {
		this.shopInventory = shopInventory;
	}

	public int getStat(String statName) {
		return switch (statName.toLowerCase()) {
		case "strength" -> baseStrength + getEffectBonus("strength");
		case "stamina" -> baseStamina + getEffectBonus("stamina");
		case "intellect" -> baseIntellect + getEffectBonus("intellect");
		case "agility" -> baseAgility + getEffectBonus("agility");
		case "hp" -> baseHP + getEffectBonus("hitpoints");
		case "mp" -> baseMP + getEffectBonus("manapoints");
		case "hr" -> baseHitroll + getEffectBonus("hitroll");
		case "dr" -> baseDamroll + getEffectBonus("damroll");
		default -> 0;
		};
	} // end getStat

	public int getBaseHitroll() {
		return baseHitroll;
	}

	public void setBaseHitroll(int baseHitroll) {
		this.baseHitroll = baseHitroll;
	}

	public int getBaseDamroll() {
		return baseDamroll;
	}

	public void setBaseDamroll(int baseDamroll) {
		this.baseDamroll = baseDamroll;
	}



	public void setActiveEffects(List<Effect> activeEffects) {
		this.activeEffects = activeEffects;
	}

	public void setActiveDamageReductions(List<DamageReductionEffect> activeDamageReductions) {
		this.activeDamageReductions = activeDamageReductions;
	}

	public void setActiveHealOverTimeEffects(List<HealOverTimeEffect> activeHealOverTimeEffects) {
		this.activeHealOverTimeEffects = activeHealOverTimeEffects;
	}

	// Use consistently:
	public ObjectItem getEquippedItem(EquipSlot slot) {
		return equipment.get(slot);
	}
	public int getTierValue() {
		return rank.getTierValue();
	}




	public String getMobName() {
		return mobName;
	}

	public void setMobName(String mobName) {
		if (mobName == null || mobName.isBlank()) return;
		this.mobName = capitalize(mobName.trim());
		if (shortDescription == null || shortDescription.equals("an unknown figure")) {
			setShortDescription("a " + mobName.toLowerCase());
		}
	}

	public String capitalize(String input) {
		if (input == null || input.isEmpty()) return input;
		return input.substring(0, 1).toUpperCase() + input.substring(1);
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getLongDescription() {
		if (longDescription == null || longDescription.isBlank()) {
			return "You see " + shortDescription + " here.";
		}
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getExtendedDescription() {
		return extendedDescription;
	}

	public void setExtendedDescription(String extendedDescription) {
		this.extendedDescription = extendedDescription;
	}



	public static AtomicInteger getNextid() {
		return nextId;
	}

	public static void setNextid(AtomicInteger nextid) {
		nextId = nextid;
	}
	public boolean canAttack() {
		return System.currentTimeMillis() - lastAttackTime >= ATTACK_COOLDOWN_MS;
	}

	public void setLastAttackTime() {
		this.lastAttackTime = System.currentTimeMillis();
	}



	public static AtomicInteger getNextId() {
		return nextId;
	}

	public static void setNextId(AtomicInteger nextId) {
		Mob.nextId = nextId;
	}

	public boolean isBlacksmith() {
		return isBlacksmith;
	}

	public void setBlacksmith(boolean isBlacksmith) {
		this.isBlacksmith = isBlacksmith;
	}

	public boolean isInnkeeper() {
		return hasBehavior(MobBehaviorFlag.INNKEEPER);
	}

	public void setInnkeeper(boolean isInnkeeper) {
		this.isInnkeeper = isInnkeeper;
	}
	// Behavior flag helpers
	public boolean hasBehavior(MobBehaviorFlag flag) {
		return behaviorFlags.contains(flag);
	}

	public void addBehavior(MobBehaviorFlag flag) {
		behaviorFlags.add(flag);
	}

	public void removeBehavior(MobBehaviorFlag flag) {
		behaviorFlags.remove(flag);
	}

	// Convenience method:
	public boolean isTalker() {
		return hasBehavior(MobBehaviorFlag.TALKER);
	}

	public boolean isVisible() {
		return !hasEffect(EffectType.INVISIBILITY); // or similar
	}

	public boolean isVisibleTo(Player player) {
		if (hasEffect(EffectType.INVISIBILITY) && !player.canSeeInvisible()) return false;
		if (getCurrentRoom() == null || !getCurrentRoom().isLit()) return false;
		return true;
	}
	public boolean canSeeInvisible() {
		return hasEffect(EffectType.DETECT_INVISIBLE);
	}


	// Affect flag helpers
	public boolean hasAffect(MobAffectFlag flag) {
		return (affectFlags & flag.getBit()) != 0;
	}
	public void setAffect(MobAffectFlag flag) {
		affectFlags |= flag.getBit();
	}
	public void clearAffect(MobAffectFlag flag) {
		affectFlags &= ~flag.getBit();
	}
	public void toggleAffect(MobAffectFlag flag) {
		affectFlags ^= flag.getBit();
	}

	// Janitor logic (run each tick)
	public void maybeCleanRoom() {
		if (!hasBehavior(MobBehaviorFlag.JANITOR)) return;
		if (Math.random() < 0.33) {
			List<ObjectItem> trash = getRoom().getObjects().stream()
					.filter(o -> o.getObjectType() == ObjectType.TRASH)
					.toList();
			for (ObjectItem obj : trash) {
				getRoom().removeObject(obj);
				addObject(obj);
				getRoom().broadcastToRoom(getMobName() + " picks up " + obj.getName() + ".");
				break;
			}
		}
	}

	// Talker logic (tick)
	public void maybeTalk() {
		if (!hasBehavior(MobBehaviorFlag.TALKER)) return;
		if (speeches.isEmpty()) return;

		int roll = new Random().nextInt(speeches.size() + 1);
		if (roll < speeches.size()) {
			String speech = speeches.get(roll);
			getRoom().broadcastToRoom(getMobName() + " says: \"" + speech + "\"");
		}
	}

	public Set<MobBehaviorFlag> getBehaviorFlags() {
		return behaviorFlags;
	}

	public void setBehaviorFlags(Set<MobBehaviorFlag> behaviorFlags) {
		this.behaviorFlags = behaviorFlags;
	}


	public int getAffectFlags() {
		return affectFlags;
	}

	public void setAffectFlags(int affectFlags) {
		this.affectFlags = affectFlags;
	}

	public String getSentryDirection() {
		return sentryDirection;
	}

	public void setSentryDirection(String sentryDirection) {
		this.sentryDirection = sentryDirection;
	}

	public String getSentryMessage() {
		return sentryMessage;
	}

	public void setSentryMessage(String sentryMessage) {
		this.sentryMessage = sentryMessage;
	}

	public List<String> getSpeeches() {
		return speeches;
	}

	public void setSpeeches(List<String> speeches) {
		this.speeches = speeches;
	}

	public int getReincarnateMax() {
		return reincarnateMax;
	}

	public void setReincarnateMax(int reincarnateMax) {
		this.reincarnateMax = reincarnateMax;
	}

	public int getReincarnateRemaining() {
		return reincarnateRemaining;
	}

	public void setReincarnateRemaining(int reincarnateRemaining) {
		this.reincarnateRemaining = reincarnateRemaining;
	}

	public int getBlacksmithFixCostPerDurability() {
		return blacksmithFixCostPerDurability;
	}

	public void setBlacksmithFixCostPerDurability(int blacksmithFixCostPerDurability) {
		this.blacksmithFixCostPerDurability = blacksmithFixCostPerDurability;
	}
	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}
	public Zone getZone() {
		return (room != null) ? room.getZone() : null;
	}

	public World getWorld() {
		Zone zone = getZone();
		return (zone != null) ? zone.getWorld() : null;
	}
	public void addObject(ObjectItem obj) {
		if (obj != null) {
			inventory.add(obj);
		}
	}

	public void removeObject(ObjectItem obj) {
		inventory.remove(obj);
	}

	public List<ObjectItem> getInventory() {
		return inventory;
	}
	public void addItem(ObjectItem item) {
		inventory.add(item);
	}

	public void removeItem(ObjectItem item) {
		inventory.remove(item);
	}
	public ObjectItem findObjectByName(String name) {
		for (ObjectItem obj : inventory) {
			if (obj.getName().equalsIgnoreCase(name)) {
				return obj;
			}
		}
		return null;
	}

	public ObjectItem findItemByName(String name) {
		if (name == null || name.isBlank()) return null;

		for (ObjectItem item : inventory) {
			if (item == null || item.getName() == null) continue;

			if (item.getName().equalsIgnoreCase(name)) {
				return item;
			}

			// Optional: check keywords for match (if supported)
			if (item instanceof HasKeywords keyworded) {
				for (String keyword : keyworded.getKeywords()) {
					if (keyword != null && keyword.equalsIgnoreCase(name)) {
						return item;
					}
				}
			}
		}
		return null;
	}

	// Check for partial keyword match (e.g. "swo" matches "sword")
	public boolean matchesKeyword(String keyword) {
		if (keyword == null || keyword.isEmpty()) return false;
		String lower = keyword.toLowerCase();
		for (String k : keywords) {
			String kk = k.toLowerCase();
			if (kk.equals(lower)) return true;
			if (kk.startsWith(lower)) return true;    // allows "swo" -> "sword"
		}
		return false;
	}

	public int getMaxInventorySize() {
		return 30; // or make configurable
	}	
	@Override
	public Mob clone() {
		Mob copy = new Mob();
		copy.setId(this.id);
		copy.setMobName(this.mobName);
		copy.setShortDescription(this.shortDescription);
		copy.setExtendedDescription(this.extendedDescription);
		copy.keywords = new LinkedHashSet<>(this.keywords);

		copy.setLevel(this.level);
		copy.setProfession(this.profession);
		copy.setRace(this.race);
		copy.setSubrace(this.subrace);
		copy.setRank(this.rank);

		copy.setStrength(this.strength);
		copy.setStamina(this.stamina);
		copy.setAgility(this.agility);
		copy.setIntellect(this.intellect);

		copy.setMaxHP(this.maxHP);
		copy.setCurrentHP(this.maxHP);
		copy.setMaxMP(this.maxMP);
		copy.setCurrentMP(this.maxMP);

		copy.setBehaviorFlags(new HashSet<>(this.behaviorFlags));
		copy.setAffectFlags(this.affectFlags); // if this is a bitfield, just copy the int
		copy.setSpeeches(new ArrayList<>(this.speeches));

		copy.setSentryDirection(this.sentryDirection);
		copy.setSentryMessage(this.sentryMessage);
		copy.setReincarnateMax(this.reincarnateMax);
		copy.setReincarnateRemaining(this.reincarnateRemaining);


		copy.setShopKeeper(this.isShopKeeper());

		// Clone ShopProfile
		if (this.shopProfile != null) {
			copy.setShopProfile(this.shopProfile.copy());
		}


		// Clone ShopInventory
		if (this.shopInventory != null && !this.shopInventory.isEmpty()) {
			for (ObjectItem item : this.shopInventory) {
				copy.addShopItem(item.clone());
			}
		}
		if (copy.isShopKeeper() && copy.getTotalCopper() == 0) {
			copy.addCopper(50000); // 50 gold baseline
		}

		// Note: don't copy currentRoom; that's dynamic
		return copy;
	}

	// In Mob.java
	public Player cloneAsPlayer() {
		return new Player() {
			private final Mob mob = Mob.this;

			@Override
			public Room getRoom() { return mob.getRoom(); }
			@Override
			public void sendMessage(String msg) { System.out.println("[Mob " + mob.getMobName() + "] " + msg); }
			@Override
			public String getName() { return mob.getMobName(); }
			@Override
			public boolean isAdmin() { return false; }

			// delegate other Player methods as needed...
		};
	}


	public List<String> getBehaviorFlagsAsStrings() {
		return behaviorFlags.stream().map(Enum::name).toList();
	}

	public List<String> getAffectFlagsAsStrings() {
		List<String> flags = new ArrayList<>();
		for (MobAffectFlag flag : MobAffectFlag.values()) {
			if ((affectFlags & flag.getBit()) != 0) {
				flags.add(flag.name());
			}
		}
		return flags;
	}




	// Adds an affect flag using bitwise OR
	public void addAffect(MobAffectFlag flag) {
		affectFlags |= flag.getBit();
	}

	// Removes an affect flag using bitwise AND NOT
	public void removeAffect(MobAffectFlag flag) {
		affectFlags &= ~flag.getBit();
	}





	public class MobRaceStats {
		private static final Map<String, int[]> BASE_STATS = Map.ofEntries(
				Map.entry("NONE", new int[] {10, 10, 10, 10}),
				Map.entry("AQUATIC", new int[] {12, 15, 8, 7}),
				Map.entry("BEAST", new int[] {14, 12, 11, 5}),
				Map.entry("CRITTER", new int[] {3, 5, 18, 6}),
				Map.entry("DRAGONKIN", new int[] {20, 18, 10, 12}),
				Map.entry("ELEMENTAL", new int[] {16, 16, 9, 9}),
				Map.entry("FLYING", new int[] {8, 10, 16, 8}),
				Map.entry("HUMANOID", new int[] {10, 10, 10, 10}),
				Map.entry("GIANT", new int[] {22, 20, 6, 8}),
				Map.entry("MAGIC", new int[] {7, 9, 10, 18}),
				Map.entry("MECHANICAL", new int[] {15, 15, 5, 10}),
				Map.entry("PLANT", new int[] {11, 13, 7, 10}),
				Map.entry("UNDEAD", new int[] {13, 14, 8, 9})
				);

		public static int[] getBaseStats(String race) {
			return BASE_STATS.getOrDefault(race.toUpperCase(), new int[] {10, 10, 10, 10});
		}
	}

	public void regenerateStatsFromRaceLevelAndRank() {
		int[] base = MobStatTemplates.getBaseStats(this.race, this.subrace);
		double multiplier = (this.rank != null) ? this.rank.getMultiplier() : 1.0;

		// Per-level gain per stat
		int levelGain = this.level;

		this.strength  = (int) Math.round((base[0] + levelGain) * multiplier);
		this.stamina   = (int) Math.round((base[1] + levelGain) * multiplier);
		this.agility   = (int) Math.round((base[2] + levelGain) * multiplier);
		this.intellect = (int) Math.round((base[3] + levelGain) * multiplier);

		// HP and MP based on stamina and intellect
		this.maxHP = 100 + (this.stamina * 4);
		this.currentHP = maxHP;

		this.maxMP = 100 + (this.intellect * 2);
		this.currentMP = maxMP;
	} // end


	public String getKeywordSummary() {
		List<String> keywords = getKeywords();
		return String.join(", ", keywords);
	}

	/**
	 * Returns a specific keyword by index (0-based).
	 */
	public String getKeyword(int index) {
		List<String> keywords = getKeywords();
		if (index >= 0 && index < keywords.size()) {
			return keywords.get(index);
		}
		return "";
	}
	// --------- Keywords -----------
	private Set<String> keywords = new LinkedHashSet<>();

	public List<String> getKeywords() {
		Set<String> temp = new LinkedHashSet<>();

		temp.addAll(keywords);

		if (mobName != null) temp.add(mobName.toLowerCase());
		if (race != null) temp.add(race.toLowerCase());
		if (subrace != null) temp.add(subrace.toLowerCase());

		return new ArrayList<>(temp);
	}


	public void setKeywords(Set<String> keywords) {
		this.keywords.clear();
		if (keywords != null) this.keywords.addAll(keywords.stream().map(String::toLowerCase).toList());
	}

	public void addKeyword(String keyword) {
		if (keyword != null && !keyword.isBlank()) {
			this.keywords.add(keyword.toLowerCase());
		}
	}

	public String returnStatBlock() {
		StringBuilder sb = new StringBuilder();

		sb.append("Mob Number: ").append(getId()).append("\n");
		sb.append("Mob Name: ").append(getMobName()).append("\n");
		sb.append("Mob Short Desc: ").append(getShortDescription()).append("\n");
		sb.append("Mob Long Desc: ").append(getLongDescription()).append("\n");
		sb.append("Mob Ext Desc: ").append(getExtendedDescription()).append("\n");
		// Keywords
		sb.append("Keywords: ").append(getKeywordSummary()).append("\n");

		sb.append("Class: [").append(getProfession()).append("]\n");
		sb.append("Race: [").append(getRace()).append("]  Subrace: [")
		.append(getSubrace()).append("]  Level: [")
		.append(getLevel()).append("]   Rank: [")
		.append(getRank()).append("]\n");

		sb.append("XP Value: ").append(getExpReward()).append("\n");

		sb.append("HPs: [").append(this.getBaseHP()).append("/").append(this.getMaxHP()).append("]   MPs: [")
		.append(this.getBaseMP()).append("/").append(this.getMaxMP()).append("]\n");

		sb.append("Stamina: ").append(this.getStamina())
		.append("  Strength: ").append(this.getStrength())
		.append("   Intelligence: ").append(this.getIntellect())
		.append("   Agility: ").append(this.getAgility()).append("\n");

		// Behavior Flags
		sb.append("\nBehavior Flags: ");
		for (MobBehaviorFlag flag : MobBehaviorFlag.values()) {
			if (this.hasBehavior(flag)) {
				sb.append(flag.name()).append(" ");
			}
		}

		// Affect Flags
		sb.append("\nAffect Flags: ");
		for (MobAffectFlag flag : MobAffectFlag.values()) {
			if (this.hasAffect(flag)) {
				sb.append(flag.name()).append(" ");
			}
		}

		// Spell/Ability Effect Flags
		sb.append("\nEffect Flags: ");
		if (this.activeEffects.isEmpty()) {
			sb.append("None");
		}
		else {
			for (Effect effect : this.activeEffects) {
				sb.append(effect.getName()).append(" ");
			}
		}

		// Speeches
		sb.append("\nSpeeches: ");
		if (speeches.isEmpty()) {
			sb.append("None");
		}
		else {
			sb.append(getSpeeches());
		}


		return sb.toString();
	}

	public List<ObjectItem> dropAllLoot() {
		List<ObjectItem> loot = new ArrayList<>(this.inventory); // or whatever field stores their items
		this.inventory.clear(); // clear after dropping
		return loot;
	}

	private Room lastRoom;

	private boolean inCombat = false;

	public Room getLastRoom() {
		return lastRoom;
	}

	public void setLastRoom(Room lastRoom) {
		this.lastRoom = lastRoom;
	}

	public void passiveRegenTick() {
		if (isDead()) return;

		// No regen during combat
		if (getInCombat()) return;

		int maxHP = getMaxHP();
		int maxMP = getMaxMP();

		// -----------------------------
		// Base passive regen (everyone)
		// -----------------------------
		int hpRegen = Math.max(1, (int) (maxHP * 0.005)); // 0.5% HP
		int mpRegen = Math.max(1, (int) (maxMP * 0.01));  // 1% MP

		// ------------------------------------
		// Regeneration affect = BIG multiplier
		// ------------------------------------
		if (hasAffect(MobAffectFlag.REGENERATION)) {
			hpRegen += Math.max(2, (int) (maxHP * 0.04)); // +4% HP
			mpRegen += Math.max(2, (int) (maxMP * 0.06)); // +6% MP
		}

		setCurrentHP(Math.min(maxHP, getCurrentHP() + hpRegen));
		setCurrentMP(Math.min(maxMP, getCurrentMP() + mpRegen));
	}


	public void setInCombat(boolean b) {
		this.inCombat = b;

	}
	public boolean getInCombat() {
		return inCombat;
	}

	public List<EffectType> getActEffects() {
		return actEffects;
	}

	public void setActEffects(List<EffectType> actEffects) {
		this.actEffects = actEffects;
	}

	public void removeEffect(EffectType acteff) {
		actEffects.remove(acteff);
	}

	public void setDead(boolean isDead) {
		this.isDead = isDead;
	}

	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}

	private Mob Master = null;
	private Mob Pet = null;

	public Mob getMaster() {
		return Master;
	}

	public void setMaster(Mob master) {
		Master = master;
	}

	public Mob getPet() {
		return Pet;
	}

	public void setPet(Mob pet) {
		Pet = pet;
	}

	public <T extends Effect> T getEffect(Class<T> effectClass) {
		if (activeEffects == null || activeEffects.isEmpty()) return null;

		for (Effect e : activeEffects) {
			if (effectClass.isInstance(e)) {
				return effectClass.cast(e);
			}
		}

		return null;
	}

	private Mob chaseTarget; 
	public Mob getChaseTarget() { return chaseTarget; }
	public void setChaseTarget(Mob t) { chaseTarget = t; }

	public void clearEquipment() {
		if (equipment == null || equipment.isEmpty()) return;
		equipment.clear();
	} // end

	public void removeAllCombatEffects() {
		// TODO add more spell effects
		removeEffect(EffectType.POISON);
		removeEffect(EffectType.BLEED);
		removeEffect(EffectType.STUN);
		removeEffect(EffectType.BURN);
		removeEffect(EffectType.FROSTBITE);
		removeEffect(EffectType.CURSE);
		removeEffect(EffectType.BLESSING);
		removeEffect(EffectType.REGENERATION);
		removeEffect(EffectType.SHIELD);
		removeEffect(EffectType.SILENCE);
		removeEffect(EffectType.ROOT);
		removeEffect(EffectType.CONFUSE);
		removeEffect(EffectType.INVISIBILITY);
		removeEffect(EffectType.SANCTUARY);
		removeEffect(EffectType.DETECT_INVISIBLE);
		removeEffect(EffectType.FEAR);
		removeEffect(EffectType.CHARM);
		removeEffect(EffectType.FIRE_SHIELD);
		removeEffect(EffectType.TAME);



	}
	// end removeAllCombatEffects


	// --------------------
	// Shopkeeper Support
	// --------------------
	private List<ObjectItem> shopInventory = new ArrayList<>();
	private ShopProfile shopProfile;             // NEW

	public boolean isShopKeeper() {
		return hasBehavior(MobBehaviorFlag.SHOPKEEPER);
	}

	public void setShopKeeper(boolean val) {
		this.shopKeeper = val;
	}

	// --------------------
	// Shop Inventory
	// --------------------
	public List<ObjectItem> getShopInventory() {
		return shopInventory;
	}

	public void addShopItem(ObjectItem item) {
		if (shopInventory == null) {
			shopInventory = new ArrayList<>();
		}
		shopInventory.add(item);
	}

	// --------------------
	// Shop Profile
	// --------------------
	public ShopProfile getShopProfile() {
		return shopProfile;
	}

	public void setShopProfile(ShopProfile shopProfile) {
		this.shopProfile = shopProfile;
	}
	// end
	public void clearShopInventory() {
		if (shopInventory == null) {
			shopInventory = new ArrayList<>();
		} else {
			shopInventory.clear();
		}
	}

	public ObjectItem findShopItem(String name) {
		for (ObjectItem item : shopInventory) {
			if (item.matchesKeyword(name)) return item;
		}
		return null;
	}
	// end


	// bankStuff
	public boolean ownsVault;

	public boolean isBanker() {
		return hasBehavior(MobBehaviorFlag.BANKER);
	}

	public int getBaseCharisma() {
		return baseCharisma;
	}

	public void setBaseCharisma(int baseCharisma) {
		this.baseCharisma = baseCharisma;
	}

	// follower
	private Mob followTarget;

	public Mob getFollowTarget() {
		return followTarget;
	}

	public void setFollowTarget(Mob target) {
		this.followTarget = target;
	}

	public void stopFollowing() {
		this.followTarget = null;
	}

	private List<Mob> followers = new ArrayList<>();

	public List<Mob> getFollowers() { return followers; }

	public void addFollower(Mob m) {
		if (!followers.contains(m)) followers.add(m);
	}

	public void removeFollower(Mob m) {
		followers.remove(m);
	}

	public boolean isFollowing(Mob leader) {
		return getFollowTarget() == leader;
	}

	// --------- Level & Scaling -----------

	/*
	public void applyLevelScaling(int newLevel) {
		this.level = Math.max(1, Math.min(100, newLevel));
		this.baseStrength  = 5 + level * 2;
		this.baseStamina   = 5 + level * 3;
		this.baseIntellect = 5 + level * 2;
		this.baseAgility   = 5 + level * 2;

		this.baseHP = 50 + (level * 10) + (baseStamina * 2);
		this.baseMP = 20 + (level * 5) + (baseIntellect * 2);
		this.setCurrentHP(this.baseHP);
		this.setCurrentMP(this.baseMP);
	}
*/
/*
	public void levelUp(int newLevel) {
		this.level = newLevel;
		this.currentHP = getMaxHP();
		this.currentMP = getMaxMP();
	}
*/

	/*
	public long getExpReward() {
	    int level = getLevel();

	    long expToNextLevel = Leveling.getExpToNextLevel(level);

	    double basePercent = 0.08; // 8% of a level
	    double rankMultiplier = getRank().getMultiplier();

	    long reward = (long)(expToNextLevel * basePercent * rankMultiplier);

	    return Math.max(reward, 1);
	}	// end
*/	
	// --- Unified HP/MP calculation ---
	/*
	private void calculateHPMP() {
		int tierHP = getRank().getTierValue();
		int tierMP = getRank().getTierValue();
		int level = getLevel();

		int newMaxHP = tierHP + (tierHP * level);
		int newMaxMP = tierMP + (tierMP * level);

		setMaxHP(newMaxHP);
		setCurrentHP(newMaxHP);

		setMaxMP(newMaxMP);
		setCurrentMP(newMaxMP);
	}
*/
/*
	public void initializeStatsFromRace() {
		int[] base = MobStatTemplates.getBaseStats(this.race);
		setStrength(base[0]);
		setStamina(base[1]);
		setAgility(base[2]);
		setIntellect(base[3]);
		setCharisma(base[4]);

		// HP/MP and EXP
		calculateHPMP();
		setExp(calculateExpReward());
	}
*/
/*
	public void scaleStatsByLevel() {
		int[] base = MobStatTemplates.getBaseStats(this.race);
		int level = getLevel();

		// Scale core stats
		setStrength(base[0] + level / 2);
		setStamina(base[1] + level / 2);
		setAgility(base[2] + level / 2);
		setIntellect(base[3] + level / 2);
		setCharisma(base[4] + level / 2);

		// HP/MP and EXP
		calculateHPMP();
		setExp(calculateExpReward());
	}
*/	
/*	
	public long calculateExpReward() {
		int level = getLevel();
		long levelScaledExp = Math.round(getExpReward() * Math.pow(EXP_GROWTH, level - 1));
		return Math.max(levelScaledExp, 1);
	}
*/
	
	public void applyRankModifiers() {
		if (rank == null) return;

		double multiplier = rank.getMultiplier();

		strength = (int) Math.round(strength * multiplier);
		stamina = (int) Math.round(stamina * multiplier);
		agility = (int) Math.round(agility * multiplier);
		intellect = (int) Math.round(intellect * multiplier);

		maxHP = (int) Math.round(maxHP * multiplier);
		currentHP = maxHP;

		maxMP = (int) Math.round(maxMP * multiplier);
		currentMP = maxMP;
	}
	
/*
	public void initializeFromRaceAndRank() {
		initializeStatsFromRace();   // step 1
		scaleStatsByLevel();         // step 2 (optional or your logic)
		applyRankModifiers();        // step 3
	}
*/
	

	public long getExpReward() {
	    long expToNextLevel = Leveling.getExpToNextLevel(getLevel());
	    double basePercent = 0.08;
	    double rankMultiplier = getRank().getMultiplier();

	    return Math.max((long)(expToNextLevel * basePercent * rankMultiplier), 1);
	}
	public int getLevel() {
	    return level;
	}

	public void setLevel(int newLevel) {
	    this.level = Math.max(1, Math.min(100, newLevel));
	    recalculateStats();
	}	// end

	public void recalculateStats() {
	    int level = getLevel();
	    int[] base = MobStatTemplates.getBaseStats(this.race);

	    // Base stats from race + level
	    strength  = base[0] + level / 2;
	    stamina   = base[1] + level / 2;
	    agility   = base[2] + level / 2;
	    intellect = base[3] + level / 2;
	    charisma  = base[4] + level / 2;

	    // Rank scaling
	    if (rank != null) {
	        double mult = rank.getMultiplier();
	        strength  = (int)Math.round(strength  * mult);
	        stamina   = (int)Math.round(stamina   * mult);
	        agility   = (int)Math.round(agility   * mult);
	        intellect = (int)Math.round(intellect * mult);
	    }

	    // HP / MP
	    int tier = rank != null ? rank.getTierValue() : 0;

	    maxHP = tier + (tier * level) + (stamina * 2);
	    maxMP = tier + (tier * level) + (intellect * 2);

	    currentHP = maxHP;
	    currentMP = maxMP;
	}	// end
	
	public void initialize() {
	    recalculateStats();
	}	// end

	
} // end Mob
