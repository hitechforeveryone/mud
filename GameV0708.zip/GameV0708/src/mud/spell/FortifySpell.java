package mud.spell;

import java.util.*;

import mud.core.*;
import mud.spell.effects.*;

public class FortifySpell implements Spell {

    private int duration = 5; // Y rounds/ticks the wall lasts

    @Override
    public String getName() {
        return "fortify";
    }

    @Override
    public String getDescription() {
        return "Creates a fortification in a direction, blocking passage for a short time.";
    }

    @Override
    public boolean cast(Mob caster, Direction dir) {
        if (caster == null || caster.getCurrentRoom() == null) return false;

        Room room = caster.getCurrentRoom();
        Room targetRoom = room.getExit(dir);

        if (targetRoom == null) {
            caster.sendMessage("There is no exit " + dir.name().toLowerCase() + " to block.");
            return false;
        }

        // Check if already blocked
        if (room.hasEffectOnExit(dir, FortifyEffect.class)) {
            caster.sendMessage("There is already a fortification blocking that exit.");
            return false;
        }

        // Create effect
        FortifyEffect wall = new FortifyEffect(room, dir, duration);
        FortifyEffect oppWall = new FortifyEffect(targetRoom, dir.getOpposite(), duration);
        caster.getCurrentRoom().addExitEffect(dir, wall);

        
        // Messaging
        caster.sendMessage("You construct a steel fortifcation to the " + dir.name().toLowerCase() + "!");
        room.broadcastExcept(caster.getMobName() + " constructs a steel fortication to the " + dir.name().toLowerCase() + "!", caster);

        if (targetRoom != null) {
            targetRoom.broadcast("A fortification of steel rises from the " + dir.getOpposite().name().toLowerCase() + "!", null);
            targetRoom.addExitEffect(dir.getOpposite(), oppWall);
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Not used
        return false;
    }

    @Override
    public int getLevelRequired() {
        return 2;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return false;
    }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MECHANIC); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}


}
