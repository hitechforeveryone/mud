package mud.spell;

import java.util.HashSet;
import java.util.Set;

import mud.core.*;

public class PickLockSpell implements Spell {

    // 🎨 Flavor
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
	
    @Override
    public String getName() {
        return "pick.lock";
    }

    @Override
    public String getDescription() {
        return "Attempts to unlock a locked door without a key.";
    }

    // -----------------------------
    // Casting logic
    // -----------------------------

    @Override
    public boolean cast(Mob caster, Direction tarDir) {

        if (!(caster instanceof Player)) {
            caster.sendMessage("Only players can pick locks.");
            return false;
        }

        Player player = (Player) caster;
        Room room = player.getCurrentRoom();

        Door door = room.getDoor(tarDir);
        Room dest = room.getExit(tarDir);
        if (door == null) {
            player.sendMessage("There is no door in that direction.");
            return false;
        }

        if (!door.isLockable()) {
            player.sendMessage("That door cannot be picked.");
            return false;
        }

        if (!door.isLocked()) {
            player.sendMessage("That door is not locked.");
            return false;
        }

        // --------------------------------
        // Success check (simple + tunable)
        // --------------------------------
        int level = player.getLevel();
        int difficulty = 25; // base difficulty
        int roll = (int) (Math.random() * 100);

        if (roll > (level * 2) + difficulty) {
        	// 💬 Messages
        	caster.sendMessage(
        	    "You work the lock carefully, but it refuses to give."
        	);

        	caster.getCurrentRoom().broadcastExcept(
        	    caster.getMobName() + " fumbles with the lock, but fails to open it.",
        	    caster
        	);
            dest.broadcastToRoom("You hear a faint scraping sound from the other side of the door.");
            return false;
        }

        // --------------------------------
        // Unlock this door
        // --------------------------------
        door.setLocked(false);

        // Unlock destination door

        if (dest != null) {
            Direction reverse = tarDir.getOpposite();
            Door destDoor = dest.getDoor(reverse);
            if (destDoor != null) {
                destDoor.setLocked(false);
                dest.broadcastToRoom("You hear a faint click as the lock on the door is picked from the other side.");
            }
        }

     // 💬 Messages
        caster.sendMessage(
            "You kneel down and deftly work the lock until it clicks open."
        );

        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " kneels down and deftly picks the lock, opening it.",
            caster
        );


        return true;
    }

    // -----------------------------
    // Unused cast targets
    // -----------------------------

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        caster.sendMessage("Pick Locks must be used on a direction.");
        return false;
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        caster.sendMessage("Pick Locks must be used on a direction.");
        return false;
    }

    // -----------------------------
    // Spell metadata
    // -----------------------------

    @Override
    public Set<Profession> getProfessions() {
        Set<Profession> profs = new HashSet<>();
        profs.add(Profession.BARD);
        profs.add(Profession.ROGUE);
        return profs;
    }

    @Override
    public int getLevelRequired() {
        return 25;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return false;
    }

    @Override
    public boolean isDirectional() {
        return true;
    }

    @Override
    public boolean isAbility() {
        return true;
    }

    @Override
    public boolean isNPCCastable() {
        return false;
    }

    @Override
    public int getManaCost() {
        return 0; // ability-style
    }

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
// end PickLocksSpell
