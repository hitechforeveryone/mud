package mud.spell;

import mud.commands.CombatSpellHandler;
import mud.core.*;
import java.util.*;

public class LocateObjectSpell implements Spell {

    @Override
    public String getName() { return "locate.object"; }

    // New cast method accepting pre-parsed sections
    public boolean cast(Mob caster, String[] sections) {
        if (!(caster instanceof Player)) return false;
        Player player = (Player) caster;

        Room curRoom = player.getCurrentRoom();
        if (curRoom == null) { player.sendMessage("You are nowhere."); return false; }

        Zone zone = curRoom.getZone();
        if (zone == null) { player.sendMessage("You are not in a zone."); return false; }

        List<String> results = new ArrayList<>();

        // === Inventory first ===
        for (ObjectItem obj : player.getInventory()) {
            if (obj != null && CombatSpellHandler.matchesSections(obj.getName(), obj.getKeywords(), sections)) {
                results.add(formatResult(obj, player, "Inventory"));
            }
        }

        // === Search all rooms in zone ===
        for (Room room : zone.getRoomsAsList()) {

            // Room objects
            for (ObjectItem obj : room.getObjects()) {
                if (obj != null && CombatSpellHandler.matchesSections(obj.getName(), obj.getKeywords(), sections)) {
                    results.add(formatResult(obj, room));
                }
            }

            // Mob-held objects
            for (Mob mob : room.getMobs()) {
                if (mob == null) continue;

                // Inventory
                for (ObjectItem item : mob.getInventory()) {
                    if (item != null && CombatSpellHandler.matchesSections(item.getName(), item.getKeywords(), sections)) {
                        results.add(formatResult(item, mob, "Inventory"));
                    }
                }

                // Equipped
                for (ObjectItem item : mob.getEquipment().values()) {
                    if (item != null && CombatSpellHandler.matchesSections(item.getName(), item.getKeywords(), sections)) {
                        results.add(formatResult(item, mob, "Equipped"));
                    }
                }
            }
        }

        if (results.isEmpty()) {
            player.sendMessage("No objects matching \"" + String.join(".", sections) + "\" were found in this zone.");
        } else {
            player.sendMessage("Objects found:\n" + String.join("\n\n", results));
        }

        return true;
    }

    private String formatResult(ObjectItem obj, Room room) {
        return obj.getName() + " — Located in room:\n" + room.getDescription();
    }

    private String formatResult(ObjectItem obj, Mob mob, String location) {
        Room room = mob.getCurrentRoom();
        return obj.getName() + " — " + location + " of " + mob.getMobName() + " — Located in room:\n" + room.getDescription();
    }

    // --- unused signatures ---
    @Override public boolean cast(Mob caster, Mob target) { return false; }
    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    @Override public boolean cast(Mob caster, Mob target, String msg) { return cast(caster, msg.split("\\.")); }

    @Override public Set<Profession> getProfessions() { return Set.of(Profession.MAGE, Profession.BARD); }
    @Override public int getLevelRequired() { return 3; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 10; }
    @Override public String getDescription() { return "Locate objects anywhere in the current zone and display their room descriptions."; }
    @Override public int getDuration() { return 0; }
}
