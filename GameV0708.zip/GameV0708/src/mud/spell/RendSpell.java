package mud.spell;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.BleedEffect;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.EquipSlot;

public class RendSpell implements Spell {
	
    int duration = 5; // bleed duration
	
    @Override
    public String getName() {
        return "rend";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
    	
    	EquipSlot slot = EquipSlot.MAINHAND;
        if (target == null) {
            caster.sendMessage("There is no target to rend.");
            return false;
        }

        if (caster.getEquippedItem(slot) == null) {
            caster.sendMessage("You must wield a weapon to use Rend.");
            return false;
        }
        
        MagicDamageType damageType = MagicDamageType.BLEED;
        String icon = damageType.getIcon();
        String typeName = damageType.getPrettyName().toLowerCase();
        
        int casterStrength = caster.getStrength();
        int casterAgility = caster.getAgility();
        int baseDamage = 5; // optional flat base damage
        int tickDamage = (int) (baseDamage + (int)((casterStrength+casterAgility)/2) * 0.2); // 20% of strength added per tick


        BleedEffect effect = new BleedEffect(target, tickDamage, duration);
        target.addEffect(effect);
        target.addEffect(EffectType.BLEED);
        
        if (target.getTarget() == null) {
        	target.setTarget(caster);
        	caster.setTarget(target);
        }
        
        caster.sendMessage("You " + getName() + icon + " " + target.getMobName() + ", leaving them bleeding!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + getName() + "s you, causing you to " + typeName + "!");
            target.getCurrentRoom().broadcastExcept(caster.getMobName() +  getName() + "s " + target.getMobName() + ", causing them to " + typeName + "!", caster, target);
        } else {
            caster.getCurrentRoom().broadcastExcept(caster.getMobName() +  getName() + "s themselves, spilling blood from their wounds!", caster, null);
        }

        return true;
    }

    @Override
    public String getDescription() {
        return "Rends the target with a weapon, causing them to bleed over time. Damage scales with caster's Strength.";
    }

    @Override
    public int getLevelRequired() {
        return 0;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.WARRIOR, Profession.ROGUE); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return duration;
	}
} // end
