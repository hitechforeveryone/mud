package mud.spell;

import mud.spell.effects.PoisonEffect;
import mud.core.*;

import java.util.Random;
import java.util.Set;

public class PoisonSpell implements Spell {
    private static final Random random = new Random();
    private final MagicDamageType damageType = MagicDamageType.POISON;
    private final String icon = damageType.getIcon();
    
    int duration = random.nextInt(3) + 2; // 2–4 ticks
    
    @Override
    public String getName() {
        return "poison";
    }

    @Override
    public String getDescription() {
        return "Poisons your foe, dealing damage over time and weakening their body.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || target == null) return false;

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        if (caster == target) {
            if (caster instanceof Player player) {
                player.sendMessage("You cannot poison yourself!");
            }
            return false;
        }

        // Chance based on caster Intellect vs target Stamina
        int chance = 50 + (caster.getIntellect() - target.getStamina()) * 5;
        chance = Math.max(5, Math.min(chance, 95)); // clamp between 5–95%
        int roll = random.nextInt(100) + 1;

        if (roll <= chance) {

            int damagePerTick = Math.max(1, caster.getLevel()); // scale with level

            PoisonEffect poison = new PoisonEffect(target, duration, damagePerTick);
            target.addEffect(poison);
            target.addEffect(EffectType.POISON);

            if (caster instanceof Player playerCaster) {
                playerCaster.sendMessage("You poison " + target.getMobName() + " with a " + getName() + " " + icon + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You are poisoned by a " + getName() + " " + icon + " from " + caster.getMobName() + "!");
          
            }
            
            // set target and combat status
            if (target.getTarget() == null) {
            	target.setTarget(caster);
            	target.setInCombat(true);
            	caster.setTarget(target);
            	caster.setInCombat(true);
            }
            
            return true;
        } else {
            if (caster instanceof Player playerCaster) {
                playerCaster.sendMessage("Your " + getName() + " " + icon + " fails to poison them.");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to poison you with a " + getName() + " spell " + icon + " but failed.");
            }
            return false;
        }
    }

    @Override
    public int getLevelRequired() {
        return 2; // 
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.DRUID, Profession.SHAMAN, Profession.NECROMANCER); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return duration;
	}
}
// end
