package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.FrostbiteEffect;

import java.util.List;
import java.util.Set;

public class FrostNovaSpell implements Spell {

    private final MagicDamageType damageType = MagicDamageType.ICE;
    private final String icon = damageType.getIcon();
    private int duration;

    @Override
    public boolean cast(Mob caster, Mob ignoredTarget) {
        if (caster.getRoom() == null) {
            caster.sendMessage("You are nowhere! Cannot cast " + getName() + ".");
            return false;
        }

        List<Mob> mobsInRoom = caster.getRoom().getMobs();
        if (mobsInRoom == null || mobsInRoom.isEmpty()) {
            caster.sendMessage("There are no targets for " + getName() + ".");
            return false;
        }

        boolean hitAnyone = false;

        for (Mob target : mobsInRoom) {
            if (target == null || target == caster) continue;

            // Skip mobs in the caster's party (if party system exists)
            if (caster.getParty()!=null && caster.getParty().isMember(target)) { continue; } // skip party members

            // Skip already affected targets
            if (target.hasEffect(EffectType.FROSTBITE)) continue;

            duration = 5 + caster.getIntellect();
            
            // Apply FrostbiteEffect
            FrostbiteEffect frost = new FrostbiteEffect(target, duration);
            target.addEffect(frost);
            target.addEffect(EffectType.FROSTBITE);

            target.sendMessage("Freezing ice from " + getName().replace(".", " ") + icon + " binds you to the ground, preventing movement!");
            hitAnyone = true;
        }

        if (hitAnyone) {
            caster.sendMessage("You release a " + getName().replace(".", " ") + icon + " that freezes your enemies in place!");
            caster.getRoom().broadcastToExcept(caster, null,
                caster.getMobName() + " casts " + getName().replace(".", " ") + icon + ", freezing all enemies in place!");
            return true;
        } else {
            caster.sendMessage("There are no valid targets for " + getName() + ".");
            return false;
        }
    }

    @Override
    public String getName() {
        return "frostnova";
    }

    @Override
    public String getDescription() {
        return "Freezes all enemies in the room for a short duration, preventing movement.";
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false; // Must be cast on mobs in room, not directional
    }

    @Override
    public int getLevelRequired() {
        return 0;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

    @Override
    public boolean isAoE() {
        return true; // It's an AoE effect
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean isDirectional() {
        return false;
    }

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}
