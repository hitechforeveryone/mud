package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Profession;
import mud.core.ObjectItem;

public class FumbleSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.ARCANE;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "fumble";
    }

    @Override
    public String getDescription() {
        return "Causes the target to fumble, dropping any weapon they are holding.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            if (caster instanceof Player player) {
                player.sendMessage("There is no target to fumble.");
            }
            return false;
        }

        EquipSlot MAINHAND = EquipSlot.MAINHAND;
        ObjectItem weapon = target.getEquippedItem(MAINHAND);
        if (weapon == null) {
            if (caster instanceof Player player) {
                player.sendMessage(target.getMobName() + " is not wielding a weapon.");
            }
            return false;
        }

        // Simple opposed roll: caster Agility vs target Agility
        int casterCheck = (caster != null ? caster.getIntellect() : 10) + (int)(Math.random() * 20);
        int targetCheck = target.getAgility() + (int)(Math.random() * 20);

        if (casterCheck > targetCheck) {
            target.unequip(MAINHAND);
            target.getCurrentRoom().addObject(weapon);

            if (caster instanceof Player player) {
                player.sendMessage("You cause " + target.getMobName() + " to fumble " + icon + " and drop their weapon!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("A strange force causes you to fumble " + icon + " and drop your weapon!");
            }
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your fumble spell " + icon + " fizzles!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to make you fumble " + icon + " but failed!");
            }
            return false;
        }
    }

    @Override
    public int getLevelRequired() {
        return 3;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK, Profession.MECHANIC, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
} // end FumbleSpell
