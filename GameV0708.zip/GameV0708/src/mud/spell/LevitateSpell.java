package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.*;

public class LevitateSpell implements Spell {

    int duration; // adjust
	
    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) return false;

        // Already levitating?
        if (target.hasEffect(EffectType.LEVITATE)) {
            caster.sendMessage(target.getMobName() + " is already levitating.");
            return false;
        }

        int duration = 300; // adjust

        MobLevitateEffect eff = new MobLevitateEffect(caster, target, duration);
        target.addEffect(eff);

        caster.sendMessage("You lift " + target.getMobName() + " from the ground!");
        target.sendMessage("You feel yourself rise into the air!");
        Room room = caster.getCurrentRoom();
        if (room != null)
            room.broadcast(caster.getMobName() + " casts Levitate on " + target.getMobName() + ".", caster);

        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem target) {
        if (target == null) return false;

        // Already floating?
        if (target.hasEffect(ItemEffect.LEVITATE)) {
            caster.sendMessage(target.getName() + " is already levitating.");
            return false;
        }

        duration = 10 + caster.getIntellect();


        ItemLevitateEffect eff = new ItemLevitateEffect(caster, target, duration);
        target.addEffect(eff);

        caster.sendMessage("You cause " + target.getName() + " to float gracefully in the air.");
        Room room = caster.getCurrentRoom();
        if (room != null)
            room.broadcast(caster.getMobName() + " casts Levitate on " + target.getName() + ".", caster);

        return true;
    }

    // ---- Required Spell Interface Methods ----

    @Override
    public String getName() { return "levitate"; }

    @Override
    public String getDescription() {
        return "Causes a creature or object to levitate for a short duration.";
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MAGE, Profession.WARLOCK); // choose yours
    }

    @Override
    public int getLevelRequired() { return 3; }

    @Override
    public boolean isInstantCast() { return false; }

    @Override
    public boolean isAoE() { return false; }

    @Override
    public boolean isSelfTarget() { return false; }

    @Override
    public boolean isDirectional() { return false; }

    @Override
    public boolean isAbility() { return false; }

    @Override
    public boolean isNPCCastable() { return true; }

    @Override
    public int getManaCost() { return 10; }

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}
// end
