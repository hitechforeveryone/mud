package mud.spell;

import mud.core.*;

import java.util.*;

public class EarthquakeSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.EARTH;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "earthquake";
    }

    @Override
    public String getDescription() {
        return "Shake the ground violently, damaging all enemies in the room.";
    }

    @Override
    public boolean isAoE() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean isInstantCast() {
        return false; // requires 'cast' command
    }

    @Override
    public int getLevelRequired() {
        return 12;
    }


    @Override
    public boolean cast(Mob caster, Mob ignoredTarget) {

        Room room = caster.getCurrentRoom();
        if (room == null) {
            return false;
        }

        // Base damage (can scale however you'd like)
        int baseDamage = 15 + caster.getStrength();
        int scaledDamage = (int)(baseDamage * caster.getRank().getMultiplier());

        // Messages to caster
        caster.sendMessage("You slam your foot down, unleashing an " + getName() + "! " + icon);

        // Broadcast to room
        room.broadcastExcept(caster.getMobName() +
            " unleashes an earth-shattering " + getName() + "! " + icon, caster, null);

     // AoE logic
        List<Mob> mobList = room.getMobs();
        for (Mob m : mobList) {

            if (m == caster) continue; // skip caster
            if (caster.getParty()!=null && caster.getParty().isMember(m)) { continue; } // skip party members

            // Apply damage
            m.takeDamage(scaledDamage);

            // Auto-aggro
            if (!m.getInCombat()) {
                m.setTarget(caster);
                m.setInCombat(true);
            }
            if (!caster.getInCombat()) {
                caster.setTarget(m);
                caster.setInCombat(true);
            }

            // Messages to Mob (works for both Player and NPC)
            m.sendMessage("The ground ruptures beneath you! You take "
                    + scaledDamage + icon + " damage from " + caster.getMobName() + "'s " + getName() + "!");

            // Broadcast to room excluding caster and this mob
            room.broadcastExcept(
                    m.getMobName() + " is rocked by the " + getName() + "! " + icon,
                    caster,
                    m
            );
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false; // not a directional spell
    }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.DRUID, Profession.SHAMAN, Profession.MAGE); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
// end
