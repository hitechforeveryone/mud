package mud.spell;

import java.util.*;
import mud.core.*;

public class RestoreConjuringSpell implements Spell {

    @Override
    public String getName() { return "Restore.Conjuring"; }

    @Override
    public String getDescription() {
        return "Heals a summoned magical familiar, restoring health and stabilizing them.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Mob familiar = caster.getPet();
        if (familiar == null) {
            caster.sendMessage("You have no conjured familiar to restore.");
            return false;
        }

        int healAmount = Math.max(1, caster.getLevel() * 7);
        familiar.heal(healAmount);

        caster.sendMessage("You restore " + familiar.getMobName() + ", healing " + healAmount + " HP.");
        if (familiar.getCurrentRoom() != null) {
            familiar.getCurrentRoom().broadcastExcept(
                familiar.getMobName() + " glows briefly as " + caster.getMobName() + " restores them.",
                caster
            );
        }

        return true;
    }

    public Set<Profession> getProfessions() { return EnumSet.of(Profession.MAGE, Profession.WARLOCK); }
    public int getLevelRequired() { return 4; }
    public boolean isInstantCast() { return true; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 25; }
    public int getDuration() { return 0; }

    // unused overloads
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }
}
// end
