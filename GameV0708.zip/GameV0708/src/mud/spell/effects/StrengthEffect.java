package mud.spell.effects;

import mud.core.*;

public class StrengthEffect implements Effect {

    private final Mob target;
    private final int bonus;
    private int remainingTicks;

    public StrengthEffect(Mob target, int bonus, int durationTicks) {
        this.target = target;
        this.bonus = bonus;
        this.remainingTicks = durationTicks;
        onApply(target);
    }

    @Override
    public void tick() {
        remainingTicks--;
        if (remainingTicks <= 0) {
            onExpire(target);
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public String getName() {
        return "Strength";
    }

    @Override
    public EffectType getType() {
        return EffectType.STRENGTH;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public int getStrengthBonus() {
        return bonus;
    }

    @Override
    public void onApply(Mob target) {
        target.sendMessage("You feel your muscles surge with power!");
    }

    @Override
    public void onExpire(Mob target) {
        target.sendMessage("The effect of Strength fades.");
        target.removeEffect(EffectType.STRENGTH);
    }

    @Override
    public void onApply(Room room) {}
    @Override
    public void onRemove() {}
    
    @Override
    public Direction getDirection() {
        return null;
    }
}
