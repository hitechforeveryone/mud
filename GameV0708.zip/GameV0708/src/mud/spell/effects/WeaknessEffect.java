package mud.spell.effects;

import mud.core.*;;

public class WeaknessEffect implements Effect {

    private final Mob target;
    private final int penalty;
    private int remainingTicks;

    public WeaknessEffect(Mob target, int penalty, int durationTicks) {
        this.target = target;
        this.penalty = penalty;
        this.remainingTicks = durationTicks;
        onApply(target);
    }

    @Override
    public void tick() {
        remainingTicks--;
        if (remainingTicks <= 0) {
            onExpire(target);
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public String getName() {
        return "Weakness";
    }

    @Override
    public EffectType getType() {
        return EffectType.DEBUFF;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public int getStrengthBonus() {
        return -penalty;
    }

    @Override
    public void onApply(Mob target) {
        target.sendMessage("You feel your muscles weaken!");
    }

    @Override
    public void onExpire(Mob target) {
        target.sendMessage("The effect of Weakness fades.");
        target.removeEffect(EffectType.WEAKENESS);
    }

    @Override
    public void onApply(Room room) {}
    @Override
    public void onRemove() {}
    
    @Override
    public Direction getDirection() {
        return null;
    }
}
