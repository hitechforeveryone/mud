package mud.spell.effects;

import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class ShadowCloneEffect implements Effect {
    private static final CopyOnWriteArrayList<ShadowCloneEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();
    
    private final static MagicDamageType damageType = MagicDamageType.SHADOW;
    private final static String icon = damageType.getIcon();
    private final Mob target;
    private int images;
    private final int totalTicks;
    private int ticksPassed = 0;

    public ShadowCloneEffect(Mob target, int images, int durationTicks) {
        this.target = target;
        this.images = images;
        this.totalTicks = durationTicks;

        ACTIVE_EFFECTS.add(this);
        this.target.addEffect(this);
        this.target.addEffect(EffectType.SHADOW_CLONE);

        target.sendMessage("You are surrounded by shadowy clones!");
        Room r = target.getRoom();
        if (r != null) {
            r.broadcastExcept(target.getMobName() + " shimmers as multiple shadow clones appear!" + icon, target, null);
        }
    }

    public static void tickAll() {
        Iterator<ShadowCloneEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            ShadowCloneEffect effect = it.next();
            effect.tick();

            if (effect.isExpired()) {
                ACTIVE_EFFECTS.remove(effect);
                effect.target.removeEffect(EffectType.SHADOW_CLONE);
                effect.target.removeEffect(effect.getName());
                effect.target.sendMessage("Your shadow clones fade away." + icon);

                Room r = effect.target.getRoom();
                if (r != null) {
                    r.broadcastExcept(effect.target.getMobName() + "'s shadow clones fade away." + icon, effect.target, null);
                }
            }
        }
    }
    
    public void addImages(int amt) {
        if (amt <= 0) return;

        // Increase the image count
        this.images += amt;

        // Optional: cap images based on your spell design
        int maxImages = 6;
        if (this.images > maxImages) {
            this.images = maxImages;
        }
    }

    
    public boolean onIncomingAttack(Mob attacker, Mob target) {
        ShadowCloneEffect eff = target.getEffect(ShadowCloneEffect.class);
        if (eff == null) return false;

        if (eff.images > 0) {
            eff.images--;

            attacker.sendMessage("Your attack strikes a shadow clone, shattering it!");
            target.sendMessage("A shadow clone takes the hit!");

            // Attack is completely negated
            attacker.setTarget(null);
            attacker.setCurrentTarget(null);
            attacker.setInCombat(false);
            
            target.setTarget(null);
            target.setCurrentTarget(null);
            target.setInCombat(false);
            
            Room r = target.getRoom();
            if (r != null) {
                r.broadcastToExcept(attacker, target,
                        attacker.getMobName() + " strikes a shadow clone of " + target.getMobName() + "!");
            }

            return true; // attack blocked
        }

        return false; // no images left
    }

    @Override
    public void tick() {
        ticksPassed++;
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public String getName() {
        return "shadow clone";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public EffectType getType() {
        return EffectType.SHADOW_CLONE;
    }

    @Override
    public int getDuration() {
        return totalTicks - ticksPassed;
    }

    public int getImages() {
        return images;
    }

    @Override
    public Direction getDirection() {
        return null;
    }

    @Override
    public void onApply(Room room) {
        // unused
    }
}
// end