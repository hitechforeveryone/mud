package mud.spell.effects;

import mud.core.*;

public class SecondHitEffect implements Effect {

    private final Mob target;
    private final boolean permanent = true;
    MobAffectFlag SH = MobAffectFlag.SECONDHIT;
    
    public SecondHitEffect(Mob target) {
        this.target = target;
        this.target.setAffect(SH); // Enable double attack
    }

    @Override
    public void tick() {
        // Passive/permanent effects don’t need ticking logic
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent effect
    }

    @Override
    public String getName() {
        return "second_hit";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
    
    public void onRemove() {
    	target.removeAffect(SH);
    }

    @Override
    public int getHpBonus() {
        return 0;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public EffectType getType() {
        return null;
    }

    @Override
    public int getDuration() {
        return 0;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}

	public boolean isPermanent() {
		return permanent;
	}
} // end
