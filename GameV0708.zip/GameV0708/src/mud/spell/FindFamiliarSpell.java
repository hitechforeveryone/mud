package mud.spell;

import java.util.*;
import mud.core.*;

public class FindFamiliarSpell implements Spell {

    @Override
    public String getName() {
        return "Find.Familiar";
    }

    @Override
    public String getDescription() {
        return "Summons a magical familiar bound to the caster.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Attempt to summon a familiar without sending messages yet
        Mob familiar = SpellUtils.summonFamiliar(caster, SpellUtils.MAGIC_FAMILIARS);
        if (familiar == null) {
            caster.sendMessage("Your summoning fails.");
            return false;
        }

        // Force the familiar to have the current room
        Room current = caster.getCurrentRoom();
        familiar.setRoom(current);
        familiar.setCurrentRoom(current);

        if (!current.getMobs().contains(familiar)) {
            current.addMob(familiar);
        }

        // Ownership already set in summonFamiliarSilent
        caster.setPet(familiar);

        // Send dynamic success messages
        caster.sendMessage("You whisper an arcane incantation, and " + familiar.getMobName() + " answers your call.");
        current.broadcastExcept(familiar.getMobName() + " materializes beside " + caster.getMobName() + ".", caster);

        return true;
    }




    // --- unused overloads ---
    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }

    public Set<Profession> getProfessions() {
        return EnumSet.of(Profession.MAGE, Profession.WARLOCK);
    }

    public int getLevelRequired() { return 1; }
    public boolean isInstantCast() { return false; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 25; }
    public int getDuration() { return 0; }
}
// end
