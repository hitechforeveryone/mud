package mud.spell;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;
import mud.spell.effects.StunEffect;

import java.util.Random;
import java.util.Set;

public class HeadButtSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    private static final Random random = new Random();
    int duration = random.nextInt(2) + 1; // headbutt stuns 1–2 rounds
    
    @Override
    public String getName() {
        return "headbutt";
    }

    @Override
    public String getDescription() {
        return "Slam your head into your foe, dealing physical damage and possibly stunning them.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || target == null) {
            return false;
        }

        if (caster == target) {
            caster.sendMessage("You can't headbutt yourself.");
            return false;
        }

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        // Base damage
        int baseDamage = 10 + (caster.getStrength() / 2);
        int totalDamage = (int)(baseDamage * caster.getRank().getMultiplier());

        target.takeDamage(totalDamage);

        // Enter combat if not already
        if (!caster.getInCombat()) {
            caster.setTarget(target);
            caster.setInCombat(true);
        }
        if (!target.getInCombat()) {
            target.setTarget(caster);
            target.setInCombat(true);
        }

        // Messaging
        caster.sendMessage("You headbutt " + target.getMobName() + " for " + totalDamage + icon + " damage!");
        if (target instanceof Player tPlayer) {
            tPlayer.sendMessage(caster.getMobName() + " headbutts you for " + totalDamage + icon + " damage!");
        }
        caster.getCurrentRoom().broadcastExcept(caster.getMobName() + " headbutts " + target.getMobName() + " violently!", caster, target);

        // ---- STUN MECHANIC (similar to StunningBlow) ----
        int chance = 40 + (caster.getStrength() - target.getStamina()) * 5; // slightly weaker chance than StunningBlow
        int roll = random.nextInt(100) + 1;

        if (roll <= chance) {

            StunEffect stun = new StunEffect(target, duration);
            target.addEffect(stun);
            target.addEffect(EffectType.STUN);
            
            if (caster instanceof Player cPlayer) {
                cPlayer.sendMessage("Your headbutt dazes " + target.getMobName() + "! They are stunned!");
            }
            if (target instanceof Player tPlayer2) {
                tPlayer2.sendMessage("You are dazed by the headbutt and feel stunned!");
            }
        }

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 10;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return false;
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false;
    }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MONK);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return duration;
	}
} // end
