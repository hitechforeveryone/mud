package mud.spell;

import mud.core.*;
import java.util.*;

public class PickpocketSpell implements Spell {

    @Override
    public String getName() { return "Pickpocket"; }

    @Override
    public String getDescription() {
        return "Attempts to steal coins or items from a target's inventory without being noticed.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        return cast(caster, target, (String) null);
    }

    @Override
    public boolean cast(Mob caster, Mob target, String itemName) {
        if (target == null || caster == null) return false;
        Room room = caster.getCurrentRoom();
        if (room == null) return false;
        Random rand = new Random();

        // Check if caster is concealed
        boolean concealed = caster.hasAffect(MobAffectFlag.INVISIBLE) || caster.hasAffect(MobAffectFlag.HIDE);

        // Calculate base success chance
        // Base: 50% success if not concealed
        int baseChance = 50;

        // If invisible, +30% success
        if (caster.hasAffect(MobAffectFlag.INVISIBLE) || caster.hasAffect(MobAffectFlag.INVISIBLE) || caster.hasAffect(MobAffectFlag.HIDE)) baseChance += 30;

        // Increase success chance based on Agility (1% per point, capped at +20%)
        baseChance += Math.min(caster.getAgility(), 20);

        // Roll for success
        if (rand.nextInt(100) >= baseChance) {
            caster.sendMessage("You fail to find an opening to pickpocket " + target.getMobName() + ".");
            return false;
        }

        // --- Attempt coin theft ---
        if (itemName == null) {
            String coin = null;
            int steal = 1;

            if (target.getCopper() > 0) coin = "copper";
            else if (target.getSilver() > 0) coin = "silver";
            else if (target.getGold() > 0) coin = "gold";
            else if (target.getPlatinum() > 0) coin = "platinum";

            if (coin == null) {
                caster.sendMessage(target.getMobName() + " has no coins to steal.");
                return false;
            }

            switch (coin) {
                case "copper" -> { target.setCopper(target.getCopper() - steal); caster.setCopper(caster.getCopper() + steal); }
                case "silver" -> { target.setSilver(target.getSilver() - steal); caster.setSilver(caster.getSilver() + steal); }
                case "gold" -> { target.setGold(target.getGold() - steal); caster.setGold(caster.getGold() + steal); }
                case "platinum" -> { target.setPlatinum(target.getPlatinum() - steal); caster.setPlatinum(caster.getPlatinum() + steal); }
            }

            caster.sendMessage("You steal " + steal + " " + coin + " coin from " + target.getMobName() + ".");
        }
        // --- Attempt item theft ---
        else {
            ObjectItem stolenItem = null;
            for (ObjectItem obj : target.getInventory()) {
                if (obj.matchesKeyword(itemName) || obj.getName().equalsIgnoreCase(itemName)) {
                    stolenItem = obj;
                    break;
                }
            }

            if (stolenItem == null) {
                caster.sendMessage(target.getMobName() + " has no item matching '" + itemName + "'.");
                return false;
            }

            target.getInventory().remove(stolenItem);
            caster.getInventory().add(stolenItem);
            caster.sendMessage("You steal " + stolenItem.getName() + " from " + target.getMobName() + ".");
        }

        // Chance victim notices (5% if concealed, otherwise 10%)
        int noticeChance = concealed ? 5 : 10;
        if (rand.nextInt(100) < noticeChance) {
            target.sendMessage("You feel someone trying to steal from you!");
            room.broadcastToExcept(target, caster, caster.getMobName() + " has been caught trying to pickpocket " + target.getMobName() + "!");
            target.setTarget(caster);
            target.setInCombat(true);
            caster.setTarget(target);
            caster.setInCombat(true);
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) { return false; }

    @Override
    public boolean cast(Mob caster, Direction tarDir) { return false; }

    @Override
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }

    @Override
    public Set<Profession> getProfessions() { return Set.of(Profession.BARD, Profession.ROGUE); }

    @Override
    public int getLevelRequired() { return 5; }

    @Override
    public boolean isInstantCast() { return false; }

    @Override
    public boolean isAoE() { return false; }

    @Override
    public boolean isSelfTarget() { return false; }

    @Override
    public boolean isDirectional() { return false; }

    @Override
    public boolean isAbility() { return true; }

    @Override
    public boolean isNPCCastable() { return false; }

    @Override
    public int getManaCost() { return 10; }

    @Override
    public int getDuration() { return 0; }
} // end PickpocketSpell
