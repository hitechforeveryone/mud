package mud.spell;

import java.util.*;
import mud.core.*;


public class RaiseUndeadSpell implements Spell {

    @Override
    public String getName() {
        return "raise.undead";
    }

    @Override
    public String getDescription() {
        return "Raises an undead familiar bound to the caster's will.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Mob undead = SpellUtils.summonFamiliar(caster, SpellUtils.UNDEAD_FAMILIARS);
        if (undead == null) return false;

        // Messaging
        caster.sendMessage("You raise " + undead.getMobName() + " from the grave to serve you!");
        caster.getCurrentRoom().broadcastExcept(undead.getMobName() + " rises beside " + caster.getMobName() + ".", caster);

        return true;
    }


    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }

    public Set<Profession> getProfessions() {
        return EnumSet.of(Profession.NECROMANCER);
    }

    public int getLevelRequired() { return 1; }
    public boolean isInstantCast() { return false; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 30; }
    public int getDuration() { return 0; }
}
// end
