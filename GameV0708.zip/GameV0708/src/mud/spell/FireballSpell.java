package mud.spell;

import java.util.Set;

import mud.combat.CombatManager;
import mud.core.Mob;
import mud.core.Direction;
import mud.core.MagicDamageType;
import mud.core.MobRank;
import mud.core.ObjectItem;
import mud.core.Profession;

public class FireballSpell implements Spell {

    // 🎨 Flavor
    MagicDamageType damageType = MagicDamageType.FIRE;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
	
    @Override
    public String getName() {
        return "fireball";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to hit.");
            return false;
        }

        int manaCost = 15;
        if (caster.getCurrentMP() - manaCost < 0) {
        	caster.sendMessage("You do not have enough mana to cast that.");
        	return false;
        }
        else {
        	caster.setCurrentMP(caster.getCurrentMP()-manaCost);
        }
        
        
        // 🔥 Get damage type and caster's rank
   
        MobRank rank = caster.getRank();
        double multiplier = rank != null ? rank.getMultiplier() : 1.0;

        // 🔢 Calculate raw + scaled damage
        int baseDamage =  (int) (10 + (1.5 * caster.getIntellect()));
        caster.sendMessage(caster.getIntellect() + ":" + caster.getBaseIntellect());
        int finalDamage = (int) Math.round(baseDamage * multiplier);

        // 💥 Apply damage
        target.takeDamage(finalDamage, damageType);
        
        // set target and combat status
        if (target.getTarget() == null) {
        	target.setTarget(caster);
        	target.setInCombat(true);
        	caster.setTarget(target);
        	caster.setInCombat(true);
        }

        // 💬 Messages
        caster.sendMessage("You hurl a " + typeName + "ball " + icon + " at " + target.getMobName()
                + " for " + finalDamage + " damage!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " hits you with a " + typeName + "ball " + icon
                    + " for " + finalDamage + " damage!");
        }

        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " hurls a " + typeName + "ball " + icon + " at " + target.getMobName()
                + ", hitting for " + finalDamage + " damage!",
            caster, target
        );

        CombatManager.deathStuff(caster, target);
        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
