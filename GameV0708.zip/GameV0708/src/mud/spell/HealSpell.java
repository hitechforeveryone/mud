package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

public class HealSpell implements Spell {

    @Override
    public String getName() {
        return "heal";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to heal.");
            return false;
        }

        // Calculate heal amount (for example: base 20 + caster's Intellect)
        int healAmount = 20 + caster.getIntellect();

        // Heal the target
        target.heal(healAmount);

        // Notify both caster and target
        caster.sendMessage("You cast heal and restore " + healAmount + " health to " + target.getMobName() + ".");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " heals you for " + healAmount + " health.");
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Heals the target for a massive amount of health.";
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.PALADIN, Profession.DRUID); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
