package mud.spell;

import mud.core.*;
import mud.spell.effects.HazeOfDarknessEffect;

import java.util.Set;

public class HazeOfDarknessSpell implements Spell {

    int manaCost = 15;
    int duration; // duration of darkness
    
	@Override
    public String getName() {
        return "haze.of.darkness";
    }

    @Override
    public String getDescription() {
        return "A dark haze descends, plunging the room into darkness for a short duration.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Room room = caster.getCurrentRoom();
        if (room == null) return false;


        duration = 6 + caster.getIntellect();

        HazeOfDarknessEffect effect = new HazeOfDarknessEffect(room, duration);
        effect.tick(); // apply immediately

        room.broadcastToRoom(caster.capitalize(caster.getMobName())
                + " casts Haze of Darkness! A thick, black haze envelops the room.");

        return true;
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.NECROMANCER, Profession.WARLOCK);
    }

    @Override
    public int getLevelRequired() { return 1; }

    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
    @Override public boolean cast(Mob caster, Direction tarDir) { return false; }

    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return true; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return manaCost; }

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}
