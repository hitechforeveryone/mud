package mud.spell;

import mud.commands.CombatSpellHandler;
import mud.core.*;
import java.util.*;

public class LocateCreatureSpell implements Spell {

    @Override
    public String getName() {
        return "locate.creature";
    }

    /**
     * Cast using pre-parsed hierarchical sections (no numeric disambiguation)
     */
    public boolean cast(Mob caster, String[] sections) {
        if (!(caster instanceof Player)) return false;
        Player player = (Player) caster;

        Room curRoom = player.getCurrentRoom();
        if (curRoom == null) { player.sendMessage("You are nowhere."); return false; }

        Zone zone = curRoom.getZone();
        if (zone == null) { player.sendMessage("You are not in a zone."); return false; }

        List<Mob> matches = new ArrayList<>();

        for (Room room : zone.getRoomsAsList()) {
            for (Mob mob : room.getMobs()) {
                if (mob != null && CombatSpellHandler.matchesSections(mob.getMobName(), mob.getKeywords(), sections)) {
                    matches.add(mob);
                }
            }
        }

        if (matches.isEmpty()) {
            player.sendMessage("No creatures matching \"" + String.join(".", sections) + "\" were found in this zone.");
            return true;
        }

        // Always pick the first matching mob; handleCast already does any disambiguation
        Mob target = matches.get(0);
        Room mobRoom = target.getCurrentRoom();
        player.sendMessage("Creature located:\n" + formatResult(target, mobRoom));
        return true;
    }

    private String formatResult(Mob mob, Room room) {
        return mob.getMobName() + " — Located in room: " + room.getName() + " (" + room.getId() + ")\n"
                + room.getDescription();
    }

    // --- unused signatures ---
    @Override public boolean cast(Mob caster, Mob target) { return false; }
    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    @Override public boolean cast(Mob caster, Mob target, String msg) { return cast(caster, msg.split("\\.")); }

    @Override public Set<Profession> getProfessions() { return Set.of(Profession.HUNTER, Profession.WARLOCK, Profession.MAGE); }
    @Override public int getLevelRequired() { return 3; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 10; }
    @Override public String getDescription() { return "Locate a creature anywhere in the current zone and display its room description."; }
    @Override public int getDuration() { return 0; }
}
