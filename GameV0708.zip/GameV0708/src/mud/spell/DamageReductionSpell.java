package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Room;
import mud.spell.effects.DamageReductionEffect;

public class DamageReductionSpell implements Spell {

    @Override
    public String getName() {
        return "damage_reduction";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to protect.");
            return false;
        }

        int reductionPercent = 25; // 25% damage reduction
        int duration = 10; // lasts 10 ticks (adjust as needed)

        // Add effect to target
        target.addDamageReductionEffect(new DamageReductionEffect(target, reductionPercent, duration));
        target.addEffect(EffectType.SHIELD);

        // Messaging
        caster.sendMessage("You cast a protective aura on " + target.getMobName() + ", reducing damage taken by " + reductionPercent + "%.");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " casts a protective aura on you, reducing damage taken.");
        }

        Room room = caster.getCurrentRoom();
        if (room != null) {
            room.broadcastExcept(caster.getMobName() + " casts a glowing shield around " + target.getMobName() + ".", caster, target);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
