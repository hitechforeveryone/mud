package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.ConfusionEffect;

public class ConfusionSpell implements Spell {

    private final int duration = 8; // ticks

    @Override
    public String getName() {
        return "confusion";
    }

    @Override
    public String getDescription() {
        return "Scrambles the mind of the target, causing disorientation and random behavior.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("You have no target to confuse.");
            return false;
        }

        if (target.hasEffect(EffectType.CONFUSE)) {
            caster.sendMessage(target.getMobName() + " is already confused.");
            return false;
        }

        
        ConfusionEffect effect = new ConfusionEffect(target, duration);
        target.addEffect(effect);

        // Null out target’s aggression
        target.setTarget(null);
        target.setCurrentTarget(null);

        caster.sendMessage("You cloud " + target.getMobName() + "'s mind with confusion!");
        target.sendMessage("Your mind fogs over—you feel utterly confused!");

        if (caster.getRoom() != null) {
            caster.getRoom().broadcastExcept(
                caster.getMobName() + " casts confusion on " + target.getMobName() + "!",
                caster, target
            );
        }

        return true;
    }

    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
//    @Override public Object getProfession() { return null; }
    @Override public int getLevelRequired() { return 1; }

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return Set.of(Profession.BARD, Profession.WARLOCK);
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}
