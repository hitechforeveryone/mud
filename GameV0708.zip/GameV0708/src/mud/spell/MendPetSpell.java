package mud.spell;

import java.util.*;
import mud.core.*;

public class MendPetSpell implements Spell {

    @Override
    public String getName() { return "Mend.Pet"; }

    @Override
    public String getDescription() {
        return "Heals and stabilizes your tamed or summoned pet, restoring health over time.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster.getPet() == null) {
            caster.sendMessage("You have no pet to mend.");
            return false;
        }

        Mob pet = caster.getPet();
        int healAmount = Math.max(1, caster.getLevel() * 5);
        pet.heal(healAmount);

        caster.sendMessage("You mend " + pet.getMobName() + ", restoring " + healAmount + " HP.");
        if (pet.getCurrentRoom() != null) {
            pet.getCurrentRoom().broadcastExcept(
                pet.getMobName() + " is gently mended by " + caster.getMobName() + ".",
                caster
            );
        }

        return true;
    }

    public Set<Profession> getProfessions() {
        return EnumSet.of(Profession.HUNTER, Profession.DRUID);
    }
    public int getLevelRequired() { return 2; }
    public boolean isInstantCast() { return true; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 15; }
    public int getDuration() { return 0; }

    // unused overloads
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }
}
// end
