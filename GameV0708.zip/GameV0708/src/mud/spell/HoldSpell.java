package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.HoldEffect;

public class HoldSpell implements Spell {

	
    private final MagicDamageType damageType = MagicDamageType.ARCANE;
    private final String icon = damageType.getIcon();
    private int duration;


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        // Check if target is already Rooted
        if (target.hasEffect(EffectType.HOLD)) {
            caster.sendMessage(target.getMobName() + " is already immobilized by a " + getName().replace(".", " ") + icon + " spell.");
            return false;
        }

        duration = 5 + caster.getIntellect();
        
        // Apply WebEffect
        HoldEffect web = new HoldEffect(target, duration);
        target.addEffect(web);
        target.addEffect(EffectType.HOLD);

        target.sendMessage(caster.getMobName() + "s " + getName().replace(".", " ") + icon + " immobilizes you, preventing movement!");
        caster.sendMessage("You immobilize " + target.getMobName() + " with a " + getName().replace(".", " ") + icon + "!");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " casts a " + getName().replace(".", " ") + icon + " on " + target.getMobName() + "!");
        }
        return true;
    }

	@Override
	public String getName() {
		return "hold";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Arcanely bind the target into place, preventing movement.";
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// false, must be cast on mob
		return false;
	}

	@Override
	public int getLevelRequired() {
		// 
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// 
		return false;
	}

	@Override
	public boolean isAoE() {
		// 
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// 
		return false;
	}

	@Override
	public boolean isDirectional() {
		// 
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}
