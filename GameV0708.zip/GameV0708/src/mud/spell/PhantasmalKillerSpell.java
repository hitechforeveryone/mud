package mud.spell;

import java.util.*;
import mud.core.*;

public class PhantasmalKillerSpell implements Spell {

    @Override
    public String getName() {
        return "Phantasmal.Killer";
    }

    @Override
    public String getDescription() {
        return "Summons a terrifying phantasmal killer that relentlessly hunts its target.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || caster.getCurrentRoom() == null || target == null) {
            caster.sendMessage("You must focus on a target to summon a Phantasmal Killer.");
            return false;
        }

        // Summon the phantasmal killer
        Mob phantasm = SpellUtils.summonFamiliar(caster, SpellUtils.PHANTASMAL_KILLER);
        if (phantasm == null) {
            caster.sendMessage("Your summoning fails.");
            return false;
        }

        Room room = caster.getCurrentRoom();
        phantasm.setRoom(room);
        phantasm.setCurrentRoom(room);

        if (!room.getMobs().contains(phantasm)) {
            room.addMob(phantasm);
        }

        // Set phantasm behavior
        phantasm.addBehavior(MobBehaviorFlag.HUNTER);
        phantasm.setChaseTarget(target);
        phantasm.setTarget(target);
        phantasm.setInCombat(true);

        // Messages
        caster.sendMessage("You conjure a shadowy horror that lunges toward " + target.getMobName() + "!");
        room.broadcastExcept(phantasm.getMobName() + " materializes, its gaze locked on " + target.getMobName() + "!", caster);

        if (target instanceof Player playerTarget) {
            playerTarget.sendMessage("A horrifying figure emerges, its gaze fixed upon you!");
        }

        return true;
    }

    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
    @Override public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    @Override public boolean cast(Mob caster, Mob target, String msg) { return false; }
    @Override public boolean cast(Mob caster, Direction tarDir) { return false; }

    @Override public Set<Profession> getProfessions() {
        return EnumSet.of(Profession.WARLOCK, Profession.NECROMANCER);
    }

    @Override public int getLevelRequired() { return 10; }
    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 50; }
    @Override public int getDuration() { return 0; }

}
