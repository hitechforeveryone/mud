package mud.spell;

import java.util.*;
import mud.core.*;

public class RepairMachineSpell implements Spell {

    @Override
    public String getName() { return "Repair.Machine"; }

    @Override
    public String getDescription() {
        return "Restores health to a mechanical contraption or summoned construct.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Mob machine = caster.getPet();
        if (machine == null) {
            caster.sendMessage("You have no mechanical contraption to repair.");
            return false;
        }

        int repairAmount = Math.max(1, caster.getLevel() * 5);
        machine.heal(repairAmount);

        caster.sendMessage("You repair " + machine.getMobName() + ", restoring " + repairAmount + " HP.");
        if (machine.getCurrentRoom() != null) {
            machine.getCurrentRoom().broadcastExcept(
                machine.getMobName() + " is repaired by " + caster.getMobName() + ".",
                caster
            );
        }

        return true;
    }

    public Set<Profession> getProfessions() { return EnumSet.of(Profession.MECHANIC); }
    public int getLevelRequired() { return 3; }
    public boolean isInstantCast() { return true; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 20; }
    public int getDuration() { return 0; }

    // unused overloads
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }
}
// end
