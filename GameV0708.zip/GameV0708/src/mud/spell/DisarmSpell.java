package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Profession;
import mud.core.ObjectItem;

public class DisarmSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "disarm";
    }

    @Override
    public String getDescription() {
        return "Attempt to knock the weapon from your opponent's hands.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
    	
    	
        if (caster == null || target == null) {
            return false;
        }
        
        // both must have a MH equipped
        EquipSlot MAINHAND = EquipSlot.MAINHAND;                

        ObjectItem weapon = target.getEquippedItem(MAINHAND);
        if (weapon == null) {
            if (caster instanceof Player player) {
                player.sendMessage(target.getMobName() + " is not wielding a weapon.");
            }
            return false;
        }

        // Simple success roll: caster Agility vs target Agility
        int casterCheck = caster.getAgility() + (int)(Math.random() * 20);
        int targetCheck = target.getAgility() + (int)(Math.random() * 20);

        if (casterCheck > targetCheck) {
            target.unequip(MAINHAND);
            target.getCurrentRoom().addObject(weapon);

            if (caster instanceof Player player) {
                player.sendMessage("You " + getName() +  icon + " " + target.getMobName() + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You have been " + getName()+ "ed " +  icon + "by " + caster.getMobName() + "!");
            }
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your " + getName()+   icon + " attempt failed!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to " + getName() +  icon +  " you, but failed!");
            }
            return false;
        }
    }

    @Override
    public int getLevelRequired() {
        return 3; // Require some experience
    }

	@Override
	public boolean isInstantCast() {
		return true;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		   return Set.of(Profession.WARRIOR, Profession.ROGUE, Profession.MONK, Profession.MECHANIC); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
} // end DisarmSpell
