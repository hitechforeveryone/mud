package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Direction;
import mud.core.EffectType;
import mud.spell.effects.BlindEffect;
import mud.spell.effects.Effect;

import java.util.Iterator;
import java.util.Set;

public class CureBlindSpell implements Spell {

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        boolean removed = false;

        // 1. Remove the enum-based effect
        if (target.hasEffect(EffectType.BLIND)) {
            target.removeEffect(EffectType.BLIND);
            removed = true;
        }

        // 2. Remove any BlindEffect instance from active Effects list
        Iterator<Effect> it = target.getActiveEffects().iterator();
        while (it.hasNext()) {
            Effect e = it.next();

            if (e instanceof BlindEffect) {
                it.remove();        // remove from mob list
                ((BlindEffect) e).expire();  // run cleanup logic
                removed = true;
            }
        }

        if (removed) {
            target.sendMessage("Your vision clears as the blindness fades!");
            if (caster != target) {
                caster.sendMessage("You restore " + target.getMobName() + "'s sight.");
            }
            return true;
        }

        caster.sendMessage(target.getMobName() + " is not blinded.");
        return false;
    }

    @Override public String getName() { return "cure.blind"; }
    @Override public String getDescription() { return "Removes blindness from the target."; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.MAGE); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
