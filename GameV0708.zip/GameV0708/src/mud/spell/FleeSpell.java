package mud.spell;

import mud.commands.MovementHandler;
import mud.core.*;

import java.util.*;

public class FleeSpell implements Spell {

    private final Random random = new Random();
    private static final int DROP_CHANCE_PERCENT = 40; // tune as needed

    
    @Override
    public String getName() {
        return "flee";
    }

    @Override
    public String getDescription() {
        return "Attempt to escape from combat.";
    }

    // ------------------------------------------------------------
    // RANDOM FLEE (no direction specified)
    // ------------------------------------------------------------
    public boolean cast(Mob caster) {
        if (caster == null || caster.getCurrentRoom() == null) {
            caster.sendMessage("You are nowhere.");
            return false;
        }

        Room room = caster.getCurrentRoom();
        Map<Direction, Room> exits = room.getExits();

        if (exits == null || exits.isEmpty()) {
            caster.sendMessage("You have nowhere to flee!");
            return false;
        }

        List<Direction> validDirs = new ArrayList<>();
        for (Map.Entry<Direction, Room> e : exits.entrySet()) {
            if (e.getValue() != null)
                validDirs.add(e.getKey());
        }

        if (validDirs.isEmpty()) {
            caster.sendMessage("You try to flee, but all exits are blocked!");
            return false;
        }

        Direction dir = validDirs.get(random.nextInt(validDirs.size()));
        return fleeTo(caster, dir);
    }

    // ------------------------------------------------------------
    // DIRECTIONAL FLEE
    // ------------------------------------------------------------
    @Override
    public boolean cast(Mob caster, Direction dir) {
        if (dir == null) {
            caster.sendMessage("Flee where?");
            return false;
        }

        return fleeTo(caster, dir);
    }

    // ------------------------------------------------------------
    // CORE MOVE LOGIC
    // ------------------------------------------------------------
    private boolean fleeTo(Mob caster, Direction dir) {
        Room current = caster.getCurrentRoom();
        Room next = current.getExit(dir);

        if (next == null) {
            caster.sendMessage("You cannot flee that way!");
            return false;
        }
        

        
        // PANIC DROP CHECK
        maybeDropItem(caster, current);
        
        // --------------------
        // HARD BLOCK CHECK
        // --------------------
        if (MovementHandler.isMovementBlocked(caster, current, dir)) {
            caster.sendMessage("Your escape route is blocked!");
            current.broadcast(caster.getMobName() + " tries to flee, but is blocked!", caster);
            return false;
        }
        
        // Move
        current.removeMob(caster);
        next.addMob(caster);
        caster.setCurrentRoom(next);

        // Drop combat
        if (caster.getTarget() != null)
            caster.getTarget().setTarget(null);

        caster.setTarget(null);
        caster.setCurrentTarget(null);

        caster.sendMessage("You flee " + dir.name().toLowerCase() + "!");

        current.broadcast(caster.getMobName() + " flees " + dir.name().toLowerCase() + "!", caster);
        next.broadcast(caster.getMobName() + " rushes in, fleeing from battle.", caster);

        return true;
    }

    // ------------------------------------------------------------
    // ITEM DROP LOGIC
    // ------------------------------------------------------------
    private void maybeDropItem(Mob caster, Room room) {
        if (random.nextInt(100) >= DROP_CHANCE_PERCENT)
            return;

        List<ObjectItem> inventory = caster.getInventory();
        if (inventory == null || inventory.isEmpty())
            return;

        ObjectItem dropped = inventory.get(random.nextInt(inventory.size()));

        caster.getInventory().remove(dropped);
        room.addObject(dropped);

        caster.sendMessage("In your panic, you drop " + dropped.getName() + "!");
        room.broadcast(caster.getMobName() + " drops " + dropped.getName() + " while fleeing!", caster);
    }
    
    // ------------------------------------------------------------
    // Spell metadata
    // ------------------------------------------------------------
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAbility() { return true; }
    @Override public boolean isDirectional() { return true; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 0; }
    @Override public int getLevelRequired() { return 1; }
    @Override public Set<Profession> getProfessions() { return null; }

    @Override public boolean cast(Mob caster, Mob target) { return false; }
    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}
}
// end
