package mud.config;

public class ChangeLog {
	
	// v0.7.0.5 work object editor, obj file formating, equip/unequip/drop, player inventory work
		// Security Updates - LoginManager/PlayerLoader updated to use password hashing. plaintext password auto-removed/changed to hashpw on next player login/out
		// WorldManager Updates
		// Code Cleanup, unused removed, commene-out code removed
	// v0.7.0.4 casting system updates, spell registration/casting by profession, additional spells (cure light, cure serious, cure critical, lifebloom, silence/sonicdamp, poison, transport..), additional help files 
		// SpellRegister, spell register by profession and are only castable by said professions
		// fleshed-out behavior for most roomFlags
	// v0.7.0.3 basic mobAI implemented, more spells (track, disarm, double attack, dual wield, flee, fumble, disarm, headbutt, rend, gouge, smite/unholysmite, summon), work on zone scripts, work on Party system
	// v0.7.0.2 Zone exits work, work on spell system (heal, fireball, kick, punch, rescue)
	// v0.7.0.1 redesign of base structure on game, modularized game systems, work on Zone Exits, help files+editor
	// v0.7.0.0 created a Server and Client login system for game
	// v0.6.0.0 player objects gone, players are now Mobs
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux now
	// v0.5.0 introduces zone objects and zoneScript objects (not working)
	

}
