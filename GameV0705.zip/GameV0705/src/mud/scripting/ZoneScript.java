package mud.scripting;

import mud.core.Zone;
import java.util.*;

public interface ZoneScript {

    /**
     * Zone ID that this script applies to.
     */
    int getZoneId();

    /**
     * Retrieve all rooms in this zone.
     */
    List<Room> getRooms();

    /**
     * Retrieve all global recall nodes.
     */
    List<RecallNode> getRecallNodes();

    /**
     * Add a mob spawn to a specific room with optional equipment/inventory.
     */
    default void addMobToRoom(int roomId, Mob mob) {}

    /**
     * Add an object to a specific room, with optional contained objects.
     */
    default void addObjectToRoom(int roomId, ZoneObject object) {}

    /**
     * Set a door state for a given room and direction.
     */
    default void setDoorState(int roomId, String direction, DoorState state) {}

    /**
     * Add a trigger to a room.
     */
    default void addTriggerToRoom(int roomId, Trigger trigger) {}

    /**
     * Serialize this script to human-readable text or YAML format.
     */
    String serialize();

    /**
     * Apply this ZoneScript to the actual Zone instance.
     */
    void apply(Zone zone);

    // ---------------- Inner Classes for structured data ----------------

    class Room {
        public int roomId;
        public List<Mob> mobs;
        public List<ZoneObject> objects;
        public List<Door> doors;
        public List<Trigger> triggers;
    }

    class Mob {
        public int mobId;
        public int percent;
        public List<ZoneObject> equipment;
        public List<ZoneObject> inventory;
    }

    class ZoneObject {
        public int objectId;
        public int percent;
        public List<ZoneObject> contains;
    }

    class Door {
        public String direction;
        public boolean open;
        public boolean locked;
        public boolean remote;
    }

    class Trigger {
        public TriggerType type;
        public int chance;
        public ZoneAction actionType;
        public String actionDetail; // message, spell, exit, etc.
        public String objectType;   // for OnUse
        public int mobId;           // for OnDeath or OnTick actions
        public boolean player;      // for OnDeath
        public String textMatch;    // for OnSay
        public int ticks;           // for Wait triggers
    }

    enum TriggerType {
        ON_ENTER,
        ON_TICK,
        ON_CAST,
        ON_SAY,
        ON_USE,
        ON_DEATH
    }

    class RecallNode {
        public int roomId;
        public String description;
    }

    enum DoorState {
        OPEN,
        CLOSED,
        LOCKED
    }

    // Optional: keep global spawn maps for legacy support
    Map<Integer, Double> getMobSpawnChances();
    Map<Integer, Double> getObjectSpawnChances();
}
