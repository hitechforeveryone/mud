package mud.system;

import mud.core.*;
import mud.spell.TrackSpell;
import mud.spell.effects.*;
import mud.combat.CombatManager;
import mud.config.Config;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class GameClock {


	private static int currentTick = 0;
	private final int ticksPerDay = Config.ticksPerDay; // 60 ticks = 1 game day
	private int ticksPerWeatherUpdate = ticksPerDay / 4;
	private int ticksPerSpeech = ticksPerDay / 8;
	private final int sunriseTick = Config.sunriseTick; // example: tick 15
	private final int sunsetTick = Config.sunsetTick;  // example: tick 45
	private int lastTickOfDay = -1; //
	private int currentDay = 0;
	private int currentMonth = 0;
	private int currentWeek = 0;
	private int currentYear = 0;
	int currentHour;




	private final CalendarSystem calendar;
	private List<Moon> moons = new ArrayList<>();
	private int tickCounter = 0;

	private boolean previousDayState = true;


	public GameClock(CalendarSystem calendar) {
		this.calendar = calendar;
	}


	public void start() {
		//	tickMobMovement();
		startMobMovementTicker();
		startCombatTicker();    // 
		startWorldTicker();     // 

	}

	private void startWorldTicker() {
		Thread clockThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(10 * 1000); // 10-second global ticks
					tick();
					tickAllMobs();
				} catch (InterruptedException e) {
					System.err.println("GameClock interrupted.");
					break;
				}
			}
		});

		clockThread.setDaemon(true);
		clockThread.setName("GameClock-Thread");
		clockThread.start();
	}

	public void startCombatTicker() {
		Thread combatThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(1000); // 1 second ticks for combat
					tickCombat();       // run only combat logic
				} catch (InterruptedException e) {
					System.err.println("Combat thread interrupted.");
					break;
				}
			}
		});

		combatThread.setDaemon(true);
		combatThread.setName("CombatTick-Thread");
		combatThread.start();
	}

	private void startMobMovementTicker() {
		Thread mobMoveThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(5000); // Every 5 seconds
					// MobAI.tickMobMovement();

				} catch (InterruptedException e) {
					System.err.println("Mob movement thread interrupted.");
					break;
				}
			}
		});
		mobMoveThread.setDaemon(true);
		mobMoveThread.setName("MobMovement-Thread");
		mobMoveThread.start();
	}

	public void tick() {


		int currentGameHourTick = (int) Config.ticksPerDay / 8;

		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					for (Mob mob : room.getMobs()) {
						ObjectItem.processSapientItemWhispers(mob, currentGameHourTick);
					}

				}
			}

		}

		tickCounter++;
		int tickOfDay = tickCounter % ticksPerDay;


		if (tickOfDay == sunriseTick) {
		    System.out.println("SUNRISE TRIGGERED");
		    updateRoomLighting(false);   // sunrise → NOT night
		    System.out.println("Tick of Day: " + tickOfDay);
		    broadcastToOutsidePlayers("🌅 The sun rises on the world.");
		}   // ← YOU WERE MISSING THIS

		if (tickOfDay == sunsetTick) {
		    System.out.println("SUNSET TRIGGERED");
		    updateRoomLighting(true);    // sunset → night begins
		    System.out.println("Tick of Day: " + tickOfDay);
		    broadcastToOutsidePlayers("🌇 The sun sets over the land.");
		}


		if (tickCounter % ticksPerWeatherUpdate == 0) {
			System.out.println("[Weather] Ticking weather update...");
			for (World world : WorldManager.getAllWorlds()) {
				System.out.println("[Weather] World: " + world.getName());
				WeatherSystem.updateWeather(world);

			}
			// testing this
			sendMoons();
		}

		// Mob Speeches 
		// this works as intended
		if (tickCounter % ticksPerSpeech == 0) {


			System.out.println("[Speeches] Ticking Sapient Object speeches...");
			for (Mob mob : WorldManager.getAllMobs()) {
				for (ObjectItem obj : mob.getEquipment().values()) {
					if (obj != null && obj.isSapient() && obj.getSapientSpeeches() != null) {
						List<String> speeches = obj.getSapientSpeeches();


						// Skip if list is empty
						if (speeches.isEmpty()) {
							continue;
						}


						// Safe random index
						int randomIndex = ThreadLocalRandom.current().nextInt(speeches.size());
						String line = speeches.get(randomIndex);


						String randomSpeech = obj.getName() + " whispers '" + line + "'";


						mob.sendMessage(randomSpeech);
						mob.getRoom().broadcast(mob.getMobName() + "'s " + obj.getName() + " whispers to them.", mob);
					}
				}
			}

			// these work
			mobSpeechTick();
			underwaterTick();
		}


		spellTicks();



		// Mob Movement and MobBehavior stuff
		MobAI.tickMobBehavior(); // partly works, still adding AI stuff to this
		MobAI.tickMobMovement(); // this one works



		// ✅ Trigger advanceDay at END of tick cycle
		if (tickOfDay == ticksPerDay - 1) {

			advanceDay();   // This is now the only call
		}
		
	}

	private void underwaterTick() {
		// TODO Auto-generated method stub
		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					if (room.hasFlag(RoomFlag.UNDERWATER)) {
						for (Player p : room.getPlayers()) {
							if (!p.hasEffect(EffectType.UNDERWATER_BREATHING)) {
								int drownDmg = 0;
								drownDmg = (int) p.getMaxHP()/20;

								p.takeDamage(drownDmg, MagicDamageType.WATER);
								String icon = MagicDamageType.WATER.getIcon();
								//p.sendMessage(Ansi.RED + "-" + drownDmg + icon + Ansi.RESET);
								p.sendMessage("You feel a burning sensation in your chest as your run out of air.");
							}
						}
					}
				}
			}
		}
	}


	private void mobSpeechTick() {
		// TODO Auto-generated method stub
		System.out.println("[Speeches] Ticking Talker Mob speeches...");
		for (Mob mob: WorldManager.getAllMobs()) {
			if (mob.isTalker()) {
				Random random = new Random();
				int randomIndex = random.nextInt(mob.getSpeeches().size());

				String randomSpeech = mob.getMobName() + " says '" + mob.getSpeeches().get(randomIndex) + "'";

				mob.getRoom().broadcast(randomSpeech, mob);
			}
		}
	}


	private void objSpeachTick() {
		// TODO Auto-generated method stub
		System.out.println("[Speeches] Ticking Sapient Object speeches...");
		for (Mob mob: WorldManager.getAllMobs()) {
			for (ObjectItem obj : mob.getEquipment().values()) {
				if (obj.isSapient()==true && (obj.getSapientSpeeches()!=null)) {
					Random random = new Random();
					int randomIndex = random.nextInt(obj.getSapientSpeeches().size()+1);

					String randomSpeech = "" + obj.getName() + " whispers '" + obj.getSapientSpeeches().get(randomIndex) + "'";

					mob.sendMessage(randomSpeech);
					mob.getRoom().broadcast(mob.getMobName() + "'s " + obj.getName() + " whispers to them.", mob);					}
			}
		}	
	}


	public static void tickCombat() {
		Set<Mob> alreadyProcessed = new HashSet<>();

		for (Mob mob : WorldManager.getAllMobs()) {
			Mob target = mob.getTarget();

			// Skip invalid or already processed
			if (target == null || mob.isDead() || target.isDead() || alreadyProcessed.contains(mob) || alreadyProcessed.contains(target)) {
				continue;
			}

			if (mob.canAttack()) {
				StringBuilder roundSummary = new StringBuilder();

				// Mob attacks target
				roundSummary.append(CombatManager.performAttack(mob, target)).append("\n");
				mob.setLastAttackTime();

				// Check if target is still alive before they counterattack
				if (!target.isDead() && target.canAttack() && target.getTarget() == mob) {
					roundSummary.append(CombatManager.performAttack(target, mob)).append("\n");
					target.setLastAttackTime();
				}

				// Final HP/MP summary (if both still exist)
				if (!mob.isDead() && !target.isDead()) {
					roundSummary.append(CombatManager.getCombatStatus(mob, target));
				}

				// Send result to both players if applicable
				if (mob instanceof Player playerMob) {
					playerMob.sendMessage(roundSummary.toString().trim());
				}

				if (target instanceof Player playerTarget) {
					playerTarget.sendMessage(roundSummary.toString().trim());
				}

				// Log for debugging
				System.out.println("[Combat Tick] " + mob.getMobName() + " vs " + target.getMobName());
				System.out.println(roundSummary);

				// Mark both as processed
				alreadyProcessed.add(mob);
				alreadyProcessed.add(target);
			}
		}
	}




	public void advanceDay() {
		int lastAdvancedTick = -1;
		if (currentTick == lastAdvancedTick) {
			System.err.println("⚠️ Skipping duplicate advanceDay() call");
			return;
		}

		lastAdvancedTick = currentTick;
		currentTick += ticksPerDay;

		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				zone.incrementResetCounter();


				ZoneResetType type = zone.getResetType();
				int timer = zone.getResetTimer();

				if (timer <= 0) continue; // skip if no timer set

				boolean ready = zone.getDaysSinceReset() >= timer;

				if (!ready) continue;

				switch (type) {
				case NEVER: // default, zone never undocks/resets
					break;
				case WHEN_EMPTY: // Reset when empty
					if (!zone.hasPlayers()) zone.resetZone();
					break;

				case ALWAYS: // Always reset
					zone.resetZone();
					break;

				case RESET_AND_UNLOAD: // Reset and unload
					if (!zone.hasPlayers()) {
						zone.resetZone();
						WorldManager.unloadZone(zone);
					}                     
					break;

				default:

					break;
				}
			}
		}



		System.out.println("[GameClock] New day: " + getCurrentDateString());
		for (Player player : WorldManager.getActivePlayers()) {
			World world = player.getCurrentWorld();
			sendDateAndMoonInfo(player, world);
		}

	} // end advanceDay

	private void triggerEclipseEvent(Moon moon) {
		switch (moon.getEclipseType()) {
		case LUNAR:
			System.out.println("A lunar eclipse occurs on " + moon.getName() + "!");
			for (Player player : WorldManager.getActivePlayers()) {
				player.sendMessage("A lunar eclipse occurs on " + moon.getName() + "!");
			}
			break;
		case SOLAR:
			System.out.println("A solar eclipse occurs, darkening the sky!");
			for (Player player : WorldManager.getActivePlayers()) {
				player.sendMessage("A solar eclipse occurs, darkening the sky!");
			}
			break;
		}
		// Future: can hook this into MUD events for effects (vision changes, spells, etc.)
	}

	// --- Moon Management ---
	public void addMoon(Moon moon) {
		moons.add(moon);
	}

	public List<Moon> getMoons() {
		return moons;
	}

	public Moon getMoonByName(String name) {
		for (Moon m : moons) {
			if (m.getName().equalsIgnoreCase(name)) return m;
		}
		return null;
	}

	// --- Time of Day ---
	public boolean isNight() {
	    int tickOfDay = tickCounter % ticksPerDay;
	    return tickOfDay < sunriseTick || tickOfDay >= sunsetTick;
	}


	public boolean isDay() {
		return !isNight();
	}

	public static int getCurrentTick() {
		return currentTick;
	}

	public int getCurrentDayIndex() {
		return currentTick / ticksPerDay;
	}

	// --- Calendar Delegation ---
	public void sendTimeInfo(Player player, World world) {
		if (player == null || world == null) return;

		long tick = world.getClock().getCurrentTick();
		player.sendMessage("raw tick: " + tick);
		int ticksPerDay = Config.ticksPerDay;
		int ticksPerHour = ticksPerDay / 24;
		int hour = (int) ((tick % ticksPerDay) / ticksPerHour);

		String timeOfDay;
		if (hour >= 5 && hour < 8) {
			timeOfDay = "🌅 Dawn breaks across the sky.";
		} else if (hour >= 8 && hour < 12) {
			timeOfDay = "🌞 Morning light brightens the land.";
		} else if (hour >= 12 && hour < 17) {
			timeOfDay = "🌤 The sun shines brightly in the afternoon sky.";
		} else if (hour >= 17 && hour < 20) {
			timeOfDay = "🌇 The sky glows orange as dusk sets in.";
		} else if (hour >= 20 && hour < 23) {
			timeOfDay = "🌃 Night falls over the world.";
		} else {
			timeOfDay = "🌌 The deep stillness of midnight surrounds you.";
		}

		player.sendMessage("⏰ Time: Hour " + hour + ". " + timeOfDay);

		Zone zone = player.getCurrentRoom().getZone();
		if (zone != null && zone.getCurrentWeather() != null) {
			player.sendMessage("☁️ Weather: " + zone.getCurrentWeather().getDescription());
		}
	} // end


	public String getCurrentDateString() {
		int dayIndex = getCurrentDayIndex(); // This must be counting total in-game days.

		String dayName = calendar.getDayName(dayIndex);
		int week = calendar.getWeekOfMonth(dayIndex); // 0-based index
		String month = calendar.getMonthNameByDay(dayIndex); // ✅ FIXED
		int year = calendar.getYear(dayIndex);

		return String.format("%s, Week %d of %s, Year %d", dayName, week, month, year);
	}

	// Sends date and moons info to the player, including moon phases nicely formatted
	// Separate method to send info to player:
	public void sendDateAndMoonInfo(Player player, World world) {
		player.sendMessage("📅 Date: " + getCurrentDateString());

		if (player.getWorld().getMoons() != null ) {
			// Display the Full Moons
			for (Moon moon : moons) {
				moon.advance();

				if (moon.getPhase() == MoonPhase.FULL_MOON &&
						moon.getPreviousPhase() != MoonPhase.FULL_MOON) {

					String message = "🌕 " + moon.getName() + " is full, bathing the land in light.";
					broadcastToOutsidePlayers(message);
					if (moon.isEclipse()==true) {
						triggerEclipseEvent(moon);
					}
				}
			}
		} else {
			//player.sendMessage("🌙 No Moons");
		}

		Zone zone = player.getCurrentRoom().getZone();
		if (zone != null && zone.getCurrentWeather() != null) {
			player.sendMessage("☁️ Weather: " + zone.getCurrentWeather().getDescription());
		}
	}


	public void sendMoons() {
		for (World world : WorldManager.getAllWorlds()) {
			List<Moon> moons = world.getMoons();

			if (moons != null && !moons.isEmpty()) {
				// Advance each moon and notify players if it's full
				for (Moon moon : moons) {
				    MoonPhase previousPhase = moon.getPhase();
				     moon.advance();
					MoonPhase currentPhase = moon.getPhase();

					if (currentPhase == MoonPhase.FULL_MOON) {
						String message = "🌕 " + moon.getName() + " is full, bathing the land in light.";
						broadcastToOutsidePlayers(message);
						if (moon.isEclipse()) {
							triggerEclipseEvent(moon);
						}
					}
				}

				// Optional: check for grand celestial event if all moons are full
				boolean allFull = moons.stream().allMatch(m -> m.getPhase() == MoonPhase.NEW_MOON);
				if (allFull && world.isDay()) {
					triggerGrandCelestialEvent(world);
				}

			} else {
				for (Player player : WorldManager.getActivePlayers()) {
					if (player.getWorld() == world) {
						// player.sendMessage("🌙 No Moons");
					}
				}
			}
		}
	}

	private void triggerGrandCelestialEvent(World world) {
		// TODO Auto-generated method stub
		System.out.println("A grand solar event occurs, darkening the sky!");
		for (Player player : WorldManager.getActivePlayers()) {
			if (player.getWorld() == world) {
				player.sendMessage("A grand solar event occurs, darkening the sky!");
			}

		}


	}


	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";
		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}


	public CalendarSystem getCalendar() {
		return calendar;
	}
	private String capitalizeFirstLetter(String input) {
		if (input == null || input.isEmpty()) return input;
		return input.substring(0, 1).toUpperCase() + input.substring(1);
	}

	public String getSunriseTime() {
		return ticksToTimeString(sunriseTick);
	}

	public String getSunsetTime() {
		return ticksToTimeString(sunsetTick);
	}

	// Helper to convert tick to HH:mm format (assumes 60 ticks per 24 hours)
	private String ticksToTimeString(int tick) {
		// 60 ticks = 24 hours
		// So each tick = 24/60 = 0.4 hours = 24 minutes
		double hoursDecimal = (tick * 24.0) / ticksPerDay;
		int hours = (int) hoursDecimal;
		int minutes = (int) ((hoursDecimal - hours) * 60);

		String ampm = (hours >= 12) ? "PM" : "AM";
		int displayHour = hours % 12;
		if (displayHour == 0) displayHour = 12;

		return String.format("%02d:%02d %s", displayHour, minutes, ampm);
	}

	private void checkZoneReset(Zone zone, int currentDay) {
		// TODO HOOK THIS INTO DAY TICK
		ZoneResetType type = zone.getResetType();
		int timer = zone.getResetTimer();
		int last = zone.getLastResetDay();

		if (type == ZoneResetType.NEVER || timer <= 0) return; // never resets

		if ((currentDay - last) >= timer) {
			boolean hasPlayers = zone.hasPlayers();

			switch (type) {
			case ZoneResetType.NEVER:

			case ZoneResetType.WHEN_EMPTY:
				if (!hasPlayers) resetZone(zone, currentDay);
				break;

			case ZoneResetType.ALWAYS:
				resetZone(zone, currentDay);
				break;

			case ZoneResetType.RESET_AND_UNLOAD:
				resetZone(zone, currentDay);
				WorldManager.unloadZone(zone); // implement this logic if needed
				break;
			}
		}
	}


	private void broadcastToOutsidePlayers(String message) {
		System.out.println("📣 Broadcasting to outside players...");
		System.out.println("🧍 Active players: " + WorldManager.getActivePlayers().size());

		for (Player player : WorldManager.getActivePlayers()) {
			Room room = player.getCurrentRoom();
			if (room == null) {
				System.out.println("🚫 Player " + player.getName() + " is not in a room.");
				continue;
			}

			if (room.hasFlag(RoomFlag.OUTSIDE)) {
				System.out.println("✅ Sending sunrise/sunset to " + player.getName());
				player.sendMessage(message);
			} else {
				System.out.println("⛔ Room " + room.getId() + " is not outside for player " + player.getName());
			}
		}
	}

	private void updateRoomLighting(boolean isDay) { 
	    for (World world : WorldManager.getAllWorlds()) {
	        for (Zone zone : world.getZones()) {
	            for (Room room : zone.getRooms().values()) {

	                boolean hasLightSource = room.getObjects().stream()
	                        .anyMatch(obj -> obj.getType() == ObjectType.LIGHTSOURCE);

	                boolean lit = isDay || hasLightSource;
	                room.setLit(lit);

	                // THIS WAS WRONG — fixed
	                room.setNightTime(lit);
	            }
	        }
	    }
	}


	public void setMoons(List<Moon> moons) {
		this.moons = moons;
	}



	private void resetZone(Zone zone, int currentDay) {
		System.out.println("Resetting zone " + zone.getZoneId());
		zone.clearMobs(); // optionally remove mobs
		zone.clearObjects(); // optionally remove items
		zone.initialize(); // re-run script
		zone.setLastResetDay(currentDay);
	}

	public String getDayOfWeek() {
		return calendar.getDayName(getCurrentDay());
	}

	public String getFormattedDate() {
		return String.format("%s, Week %d of %s, Year %d", 
				getDayOfWeek(), currentWeek, getCurrentMonthName(), currentYear);
	}

	public String getCurrentMonthName() {
		return calendar.getMonthName(currentMonth);
	}
	public int getCurrentDayOfYear() {
		return (currentMonth * calendar.getDaysPerMonth()) + currentDay;
	}
	public int getCurrentDay() {
		return currentDay;
	}

	public int getCurrentMonth() {
		return currentMonth;
	}

	public int getCurrentWeek() {
		return currentWeek;
	}

	public int getCurrentYear() {
		return currentYear;
	}



	public String getFormattedTime(World world) {
		StringBuilder sb = new StringBuilder();

		int curTick = world.getClock().tickCounter;
		int dayOfYear = getCurrentDayOfYear();
		int currentMonth = getCurrentMonth();
		int currentWeek = getCurrentWeek();
		int currentYear = getCurrentYear();
		int currentHour = getCurrentTick(); // Or however you determine hour

		String dayName = calendar.getDayName(dayOfYear);
		String monthName = calendar.getMonthName(currentMonth);
		sb.append("📅 Date: ").append(dayName)
		.append(", Week ").append(currentWeek)
		.append(" of ").append(monthName)
		.append(", Year ").append(currentYear).append("\n");

		for (Moon moon : world.getMoons()) {
			MoonPhase phase = moon.getPhase();
			sb.append("🌙 ").append(moon.getName())
			.append(" — Phase: ").append(phase).append("\n");
		}

		String timeDesc = calendar.getTimeOfDay(curTick);
		sb.append("🕒 Time: ").append(timeDesc).append(" - Hour: ").append(ticksToTimeString(curTick));

		return sb.toString();
	}

	public void tickAllMobs() {
		for (Mob mob : WorldManager.getAllMobs()) {
			mob.passiveRegenTick();
		}
	}

	public void mobSpellsExpire() {
		// TODO
		// make these all expire
		// Mob Spells and Effect Ticks 
	}
	public void roomSpellsExpire() {
		// TODO
		// make these all expire
		// Room aoe Spells and Effect/ticks
	}

	public void spellTicks() {
		// TODO

		// Spells and Effect Ticks
		BerserkEffect.tickAll(); // attack next player
		BladestormEffect.tickAll(); 
		BleedEffect.tickAll();
		BlindEffect.tickAll();
		BoneShieldEffect.tickAll();

		CharmPersonEffect.tickAll();
		ConfusionEffect.tickAll();
		ContinualLightEffect.tickAll();
		CrushingGripEffect.tickAll();

		DancingLightsEffect.tickAll();

		EntangleEffect.tickAll();

		FearEffect.tickAll();
		FireShieldEffect.tickAll();
		FlameBarrierEffect.tickAll(); // icewall spoof
		ForcefulHandEffect.tickAll();
		FortifyEffect.tickAll(); // icewall spoof
		FrostbiteEffect.tickAll();

		HoldEffect.tickAll();

		IcewallEffect.tickAll(); // icewall temp block an exit
		ItemLevitateEffect.tickAll();
		ItemWaterWalkEffect.tickAll();

		LifeBloomEffect.tickAll();

		MirrorImageEffect.tickAll();
		MobLevitateEffect.tickAll();
		MobUnderwaterBreathingEffect.tickAll();
		MobWaterWalkEffect.tickAll();

		PoisonEffect.tickAll();
		PortalEffect.tickAll();

		RampartEffect.tickAll(); // icewall spoof
		RootEffect.tickAll();

		SapEffect.tickAll();
		ShadowCloneEffect.tickAll();
		SilenceEffect.tickAll();
		SpatialDisruptorEffect.tickAll(); // room nosumm
		StunEffect.tickAll(); // 

		TrackSpell.tick();

		WebEffect.tickAll();
		WormholeEffect.tickAll();
	}

} // end GameClock
