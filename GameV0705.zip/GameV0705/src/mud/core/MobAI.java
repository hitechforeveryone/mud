package mud.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import mud.spell.SpellManager;
import mud.spell.effects.*;

public class MobAI {

	public static void tickMobBehavior() {
		for (Mob mob : WorldManager.getAllMobs()) {
			Room room = mob.getCurrentRoom();
			if (room == null) continue; // skip if mob has no room

			
			// --- WIMPY ----
			// Clean & Correct WIMPY Flee Logic

			if (mob.hasBehavior(MobBehaviorFlag.WIMPY) && mob.getInCombat()) {
			    // Trigger flee when HP <= 20%
			    if (mob.getCurrentHP() <= mob.getMaxHP() / 5) {

			        Room current = mob.getCurrentRoom();
			        if (current == null) return;

			        Map<Direction, Room> exits = current.getExits();
			        if (exits == null || exits.isEmpty()) {
			            return; // No exits, cannot flee
			        }

			        // Collect functional exits
			        List<Direction> validDirs = new ArrayList<>();
			        for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
			            Direction dir = entry.getKey();
			            Room dest = entry.getValue();
			            if (dest == null) continue;

			            Door door = current.getDoor(dir);
			            if (door != null) {
			                if (!door.isOpen() || door.isLocked()) continue; // Skip blocked exits
			            }

			            // NEW: spell-based movement restrictions
			            if (isMovementBlocked(mob, mob.getCurrentRoom(), dir) == true) continue;
			            
			            validDirs.add(dir);
			        }

			        if (validDirs.isEmpty()) {
			            return; // No usable exits
			        }

			        // Pick random direction
			        Direction fleeDir = validDirs.get(new Random().nextInt(validDirs.size()));
			        Room escapeRoom = exits.get(fleeDir);

			        // Move mob
			        current.removeMob(mob);
			        escapeRoom.addMob(mob);
			        mob.setCurrentRoom(escapeRoom);
			        mob.setRoom(escapeRoom);

			        // Drop combat
			        if (mob.getCurrentTarget() != null) {
			            mob.getCurrentTarget().setTarget(null);
			        }
			        mob.setTarget(null);
			        mob.setInCombat(false);

			        // Output messaging
			        current.broadcast(mob.getMobName() + " flees to the " + fleeDir.name() + "!", mob);
			        escapeRoom.broadcast(mob.getMobName() + " rushes in, fleeing in terror!", mob);

			        System.out.println("DEBUG: " + mob.getMobName() + " fled " + fleeDir.name() + " to room " + escapeRoom.getId());
			    }
			}
						

			// --- CITYGUARD ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.CITYGUARD) && !mob.getInCombat()) {
				// check mobs and players in room
				List<Mob> potentialVictims = new ArrayList<>();
				potentialVictims.addAll(room.getMobs());
				potentialVictims.addAll(room.getPlayers());

				for (Mob victim : potentialVictims) {
					if (victim == mob) continue; // skip self
					if (!victim.getInCombat() || victim.getTarget() == null) continue;

					Mob aggressor = victim.getTarget();
					if (aggressor == mob) continue; // don’t rescue from self
					if (aggressor.getTarget() != victim) continue; // only intervene if aggressor is still fighting victim

					room.broadcast(mob.getMobName() + " intervenes to protect " + victim.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " rescued " + victim.getMobName() + " from " + aggressor.getMobName());

					// Guard takes over combat
					mob.setTarget(aggressor);
					mob.setInCombat(true);

					aggressor.setTarget(mob);
					aggressor.setInCombat(true);

					victim.setTarget(null);
					victim.setInCombat(false);

					break; // only rescue once per tick
				}
			}

			// --- ASSISTER ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.ASSISTER) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					if (player.getInCombat() && player.getTarget() != null) {
						room.broadcast(mob.getMobName() + " rushes to aid its ally against " + player.getMobName() + "!", mob);
						mob.setTarget(player);
						mob.setInCombat(true);
						break;
					}
				}
			}


			// --- AGGRESSIVE ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.AGGRESSIVE) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					System.out.println("DEBUG: Found player " + player.getMobName() + " in room " + room.getId());
				}

				for (Mob player : room.getPlayers()) {

					if (player == null) continue; // safety
					// Optional: skip dead/disconnected players here

					room.broadcast(mob.getMobName() + " snarls and attacks " + player.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " attacked " + player.getMobName());

					// Mob engages combat
					mob.setTarget(player);
					mob.setInCombat(true);

					// Player is now in combat with mob
					player.setTarget(mob);
					player.setInCombat(true);

					break; // only attack one player per tick
				}
			}


			// --- JANITOR ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.JANITOR)) {
				for (ObjectItem obj : new ArrayList<>(room.getObjects())) { // avoid CME
					if (obj.getObjectType() == ObjectType.TRASH || obj.getObjectType() == ObjectType.CONTAINER) {
						mob.addItem(obj);
						room.removeObject(obj);
						room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);
					}
				}
			}


			// --- HUNTER ---
			if (mob.hasBehavior(MobBehaviorFlag.HUNTER)) {

			    // If already chasing someone, make sure they're valid
			    Mob chaseTarget = mob.getChaseTarget();
			    if (chaseTarget != null) {

			        // Target must be alive, have a room, and remain in same zone
			        Room tRoom = chaseTarget.getCurrentRoom();
			        Room mRoom = mob.getCurrentRoom();

			        if (tRoom == null || mRoom == null || tRoom.getZone() != mRoom.getZone()) {
			            mob.setChaseTarget(null); // drop chase
			        } 
			        else if (tRoom == mRoom) {
			            // Already caught up — attack!
			            mRoom.broadcast(mob.getMobName() + " lunges at " + chaseTarget.getMobName() + "!", mob);
			            mob.setTarget(chaseTarget);
			            mob.setInCombat(true);
			            chaseTarget.setTarget(mob);
			            chaseTarget.setInCombat(true);
			            continue;
			        } 
			        else {
			            // Move one step toward target
			            Direction chaseDir = getBestChaseDirection(mob, chaseTarget);
			            if (chaseDir != null) {
			                Room next = mRoom.getExit(chaseDir);
			                if (next != null && !next.hasFlag(RoomFlag.NOMOB)) {

			                    // Handle doors
			                    Door door = mRoom.getDoor(chaseDir);
			                    if (door != null && door.isClosed()) {
			                        // Hunters can open but not pass locked doors
			                        if (!door.isLocked()) {
			                            door.setOpen(true);
			                            mRoom.broadcast(mob.getMobName() + " opens the " + door.getDoorName() + ".", mob);
			                        } else {
			                            // Door is locked → abort chase this tick
			                            continue;
			                        }
			                    }

			                    // Move mob
			                    mRoom.removeMob(mob);
			                    next.addMob(mob);
			                    mob.setCurrentRoom(next);
			                    next.broadcast(mob.getMobName() + " arrives, hunting someone.", mob);
			                }
			            }
			            continue; // hunter only does one thing per tick
			        }
			    }

			    // Not currently chasing — look for players in room
			    room = mob.getCurrentRoom();
			    if (room != null) {
			        for (Mob player : room.getPlayers()) {
			            mob.setChaseTarget(player);
			            room.broadcast(mob.getMobName() + " fixes its gaze on " + player.getMobName() + "!", mob);
			            break;
			        }
			    }
			}


			// --- HEALER ----
			if (mob.hasBehavior(MobBehaviorFlag.HEALER)) {

			     room = mob.getCurrentRoom();
			    if (room != null) {

			        // 1-in-10 chance
			        if (new Random().nextInt(10) == 0) {

			            // Find first healable target in room
			            Mob target = null; // can be Mob or Player

			            // Check mobs first
			            for (Mob m : room.getMobs()) {
			                if (m != mob && m.getCurrentHP() < m.getMaxHP()) {
			                    target = m;
			                    break;
			                }
			            }

			            // If none, check players
			            if (target == null) {
			                for (Player p : room.getPlayers()) {
			                    if (p.getCurrentHP() < p.getMaxHP()) {
			                        target = p;
			                        break;
			                    }
			                }
			            }

			            // If we have someone to heal, do it
			            if (target != null) {

			                SpellManager.castSpell("heal", mob, target);

			                room.broadcast(
			                    mob.getMobName() + " casts a healing spell on " + target.getMobName() + ".",
			                    mob
			                );
			            }
			        }
			    }
			}



			// Drop-in version of PICKPOCKET behavior, simplified to match your codebase
			// Uses only methods already present in your Mob/Player classes

			// --- PICKPOCKET ----
			if (mob.hasBehavior(MobBehaviorFlag.PICKPOCKET)) {
			    
			    Room r = mob.getCurrentRoom();
			    if (r == null) return;

			    
			    boolean concealed = false;
			   
			    if (mob.hasAffect(MobAffectFlag.INVISIBLE) || mob.hasAffect(MobAffectFlag.HIDE) ) {
			        concealed = true;
			    } 

			    // 1-in-10 chance per tick
			    if (!concealed || new Random().nextInt(10) != 0) {
			        // Still check other AI behaviors
			    } else {
			        // Attempt a theft
			        for (Mob victim : r.getPlayers()) {
			            if (victim == null) continue;
			            if (victim == mob) continue;
			            if (victim.getCurrentHP() <= 0) continue;

			            int steal = 0;
			            String coin = null;

			            if (victim.getCopper() > 0) {
			                steal = 1;
			                coin = "copper";
			            } else if (victim.getSilver() > 0) {
			                steal = 1;
			                coin = "silver";
			            } else if (victim.getGold() > 0) {
			                steal = 1;
			                coin = "gold";
			            } else if (victim.getPlatinum() > 0) {
			                steal = 1;
			                coin = "platinum";
			            }

			            if (coin == null) break; // nothing to steal

			            // Transfer coins
			            switch (coin) {
			                case "copper":
			                    victim.setCopper(victim.getCopper() - steal);
			                    mob.setCopper(mob.getCopper() + steal);
			                    break;
			                case "silver":
			                    victim.setSilver(victim.getSilver() - steal);
			                    mob.setSilver(mob.getSilver() + steal);
			                    break;
			                case "gold":
			                    victim.setGold(victim.getGold() - steal);
			                    mob.setGold(mob.getGold() + steal);
			                    break;
			                case "platinum":
			                    victim.setPlatinum(victim.getPlatinum() - steal);
			                    mob.setPlatinum(mob.getPlatinum() + steal);
			                    break;
			            }

			            // Notify the mob
			            mob.sendMessage("You steal " + steal + " " + coin + " coin from " + victim.getMobName() + ".");

			            // Chance the victim notices
			            if (new Random().nextInt(10) == 0) {
			                victim.sendMessage("You feel someone brush against your coin pouch!");
			                r.broadcastToExcept(victim, mob, mob.getMobName() + " has been caught trying to pickpocket " + victim.getMobName() + "!");

			                // Engage combat
			                victim.setTarget(mob);
			                victim.setInCombat(true);

			                mob.setTarget(victim);
			                mob.setInCombat(true);
			            }

			            break; // only pick one victim per tick
			        }
			    }
			}


			// --- USE_SPELLS ----
			if (mob.hasBehavior(MobBehaviorFlag.USE_SPELLS)) {
				// TODO: 
				// mob will attempt to cast spells in combat
			}

			// --- SCAVENGER ----
			// Picks up loose objects and attempts to wear usable gear
			if (mob.hasBehavior(MobBehaviorFlag.SCAVENGER)) {

			    // Copy list to avoid ConcurrentModificationException
			    List<ObjectItem> roomItems = new ArrayList<>(room.getObjects());

			    for (ObjectItem obj : roomItems) {

			        // Skip if object is not pickable
			        if (obj.hasEffect(ItemEffect.NOTAKE)) continue;

			        // Optional: skip coins or junk types if desired
			         if (obj.getType() == ObjectType.COIN) continue;



			        mob.addItem(obj);
			        room.removeObject(obj);

			        room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);

			        // ---- Attempt to Wear ----
			        if (obj.getEquipSlot() != null && !obj.getEquipSlot().isEmpty()) {

			            // Try each slot the item could fit
			            for (EquipSlot slot : obj.getEquipSlot()) {

			                ObjectItem currentlyWorn = mob.getEquipment().get(slot);

			                // If slot empty, auto-equip
			                if (currentlyWorn == null) {
			                    mob.equip(slot, obj);
			                    room.broadcast(mob.getMobName() + " wears " + obj.getName() + ".", mob);
			                    break;
			                }

			                // If filled, compare usefulness (simple compare by value or a stat)
			                if (obj.getValue() > currentlyWorn.getValue()) {
			                    mob.unequip(slot);
			                    mob.equip(slot, obj);
			                    room.broadcast(
			                        mob.getMobName() + " switches to " + obj.getName() + ".", 
			                        mob
			                    );
			                    break;
			                }
			            }
			        }
			    }
			}


			// --- other behaviors from MobBehaviorFlag go here ---

		}
	} // end tickMobBehavior()

	private static Direction getBestChaseDirection(Mob hunter, Mob target) {
	    Room start = hunter.getCurrentRoom();
	    Room goal = target.getCurrentRoom();
	    if (start == null || goal == null) return null;

	    int goalId = goal.getId();

	    Direction bestDir = null;
	    int bestDist = Integer.MAX_VALUE;

	    for (Map.Entry<Direction, Room> entry : start.getExits().entrySet()) {
	        Room r = entry.getValue();
	        if (r == null) continue;
	        if (r.getZone() != start.getZone()) continue;

	        int dist = Math.abs(r.getId() - goalId);
	        if (dist < bestDist) {
	            bestDist = dist;
	            bestDir = entry.getKey();
	        }
	    }

	    return bestDir;
	}



	public static void tickMobMovement() {
		for (World world : WorldManager.getAllWorlds()) {
			tickMobMovement(world);
		}
	}

	
	public static void tickMobMovement(World world) {
	    Map<Mob, Room> moves = new HashMap<>();

	    for (Room room : world.getRooms()) {
	        List<Mob> mobsCopy = new ArrayList<>(room.getMobs());

	        for (Mob mob : mobsCopy) {
	            if (mob == null) continue;

	            // 🚫 Do not wander if stationary
	            if (mob.hasBehavior(MobBehaviorFlag.STATIONARY)) continue;

	            // 🚫 NEW: Do not wander if in combat
	            if (mob.getInCombat()) continue;

	            Room currentRoom = mob.getCurrentRoom();
	            if (currentRoom == null) continue;

	            Zone currentZone = currentRoom.getZone();
	            if (currentZone == null) continue;

	            Map<Direction, Room> exits = currentRoom.getExits();
	            if (exits == null || exits.isEmpty()) continue;

	            List<Direction> validDirs = new ArrayList<>();

	            for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                Direction dir = entry.getKey();
	                Room dest = entry.getValue();

	                if (dest == null || dest.getZone() != currentZone || dest.hasFlag(RoomFlag.NOMOB)) continue;
	                if (isMovementBlocked(mob, currentRoom, dir)) continue;

	                Door door = currentRoom.getDoor(dir);
	                if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                if (dest == mob.getLastRoom()) continue;

	                validDirs.add(dir);
	            }

	            // If no valid dirs except lastRoom, loosen restriction
	            if (validDirs.isEmpty()) {
	                for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                    Direction dir = entry.getKey();
	                    Room dest = entry.getValue();

	                    if (dest == null || dest.getZone() != currentZone || dest.hasFlag(RoomFlag.NOMOB)) continue;
	                    if (isMovementBlocked(mob, currentRoom, dir)) continue;

	                    Door door = currentRoom.getDoor(dir);
	                    if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                    validDirs.add(dir);
	                }
	            }

	            if (!validDirs.isEmpty()) {
	                Direction chosen = validDirs.get(new Random().nextInt(validDirs.size()));
	                Room dest = currentRoom.getExit(chosen);

	                if (dest != null && !dest.hasFlag(RoomFlag.NOMOB)) {
	                    moves.put(mob, dest);
	                }
	            }
	        }
	    }

	    // Apply Wander moves
	    for (Map.Entry<Mob, Room> entry : moves.entrySet()) {
	        Mob mob = entry.getKey();
	        Room dest = entry.getValue();
	        Room currentRoom = mob.getCurrentRoom();

	        // Water logic
	        boolean hasBoat = false;
	        for (ObjectItem ob : mob.getInventory()) {
	            if (ob.getType() == ObjectType.BOAT) hasBoat = true;
	        }

	        if (dest.hasFlag(RoomFlag.ON_WATER) &&
	           (!mob.hasEffect(EffectType.WATER_WALK) && !hasBoat)) {
	            continue;
	        }

	        if (currentRoom != null) {
	            currentRoom.removeMob(mob);
	            currentRoom.broadcast(mob.getMobName() + " wanders.", mob);
	        }

	        mob.setCurrentRoom(dest);
	        dest.addMob(mob);
	        mob.setLastRoom(currentRoom);
	        dest.broadcast(mob.getMobName() + " arrives.", mob);

	        boolean levEquipped = false;
	        for (ObjectItem ob : mob.getEquipment().values()) {
	            if (ob.hasEffect(ItemEffect.LEVITATE)) levEquipped = true;
	        }

	        // Handle FALL flag
	        while (dest.hasFlag(RoomFlag.FALL) &&
	               (!mob.hasEffect(EffectType.LEVITATE) && !levEquipped)) {

	            Room fallDest = dest.getExit(Direction.DOWN);
	            if (fallDest == null) break;

	            dest.removeMob(mob);
	            dest.broadcast(mob.getMobName() + " falls downward.", mob);

	            mob.setCurrentRoom(fallDest);
	            fallDest.addMob(mob);
	            fallDest.broadcast(mob.getMobName() + " crashes in from above.", mob);

	            dest = fallDest;
	        }
	    }
	}



	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";
		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}

	// Checks whether a mob is prevented from moving in the given direction
	public static boolean isMovementBlocked(Mob mob, Room room, Direction dir) {

	    // 1) Room-level exit-blocking effects (Icewall, etc.)
	    if (room.hasEffectOnExit(dir, IcewallEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, FlameBarrierEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, FortifyEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, RampartEffect.class)) {
	        return true;
	    }
	    
	    

	    // 2) MOB-level "rooting" effects (player & mob)
	    if (mob.hasEffect(EffectType.HOLD)) return true; // arcane
	    if (mob.hasEffect(EffectType.STUN)) return true; // physical
	    if (mob.hasEffect(EffectType.WEB)) return true; // shadow
	    if (mob.hasEffect(EffectType.ROOT)) return true; // earth
	    if (mob.hasEffect(EffectType.ENTANGLE)) return true; // nature
	    if (mob.hasEffect(EffectType.FROSTBITE)) return true; // ice

	    // Add more here as you introduce new EffectTypes
	    System.out.println("Mob can move.");
	    return false;
	}



}
