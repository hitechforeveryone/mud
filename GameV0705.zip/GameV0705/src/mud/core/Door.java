package mud.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import mud.scripting.DoorState;

public class Door implements HasKeywords, Serializable {
	
	 private static final long serialVersionUID = 1L;
    private String doorName = "a door";              // User-friendly name
    private String shortDescription = "a door";      // Shown in exit list
    private String longDescription = "You see a door this way.";
    private List<String> keywords = new ArrayList<>();
    private boolean isLockable = true;
    private boolean isLocked = false;
    private boolean isOpen = false;
    


    // ─────────────────────────────────────────────────────────────────────────────
    // Constructors

    public Door() {}

    public Door(String name, boolean locked, boolean closed) {
        this.doorName = name != null ? name : "a door";
        this.shortDescription = name != null ? name : "a door";
        this.isLocked = locked;
        this.isOpen = !closed;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Name & Descriptions

    public String getDoorName() {
        return doorName;
    }

    public void setDoorName(String doorName) {
        if (doorName != null) this.doorName = doorName;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        if (shortDescription != null) this.shortDescription = shortDescription;
    }

    public String getFullDescription() {
        StringBuilder sb = new StringBuilder();
        sb.append(Character.toUpperCase(doorName.charAt(0)))
          .append(doorName.substring(1))
          .append(" stands here. It is ");

        sb.append(isOpen ? "open" : "closed");
        if (isLocked) {
            sb.append(" and locked.");
        } else {
            sb.append(".");
        }

        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Open/Close

    public boolean isOpen() {
        return isOpen;
    }

    public boolean isClosed() {
        return !isOpen;
    }

    public void setOpen(boolean open) {
        if (!isLocked) {
            this.isOpen = open;
        }
    }

    public void open() {
        if (!isLocked) {
            this.isOpen = true;
        }
    }

    public void close() {
        this.isOpen = false;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Lockable / Locked

    public boolean isLockable() {
        return isLockable;
    }

    public void setLockable(boolean lockable) {
        this.isLockable = lockable;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        if (isLockable) {
            this.isLocked = locked;
        }
    }

    public void lock() {
        if (isLockable) {
            this.isLocked = true;
        }
    }

    public void unlock() {
        if (isLockable) {
            this.isLocked = false;
        }
    }
    public void setClosed(boolean closed) {
        this.isOpen = !closed;
    }
    public Door(String name) {
        // add name and other keywords
        keywords.add(name.toLowerCase());
    }

    @Override
    public List<String> getKeywords() {
        return keywords;
    }
    public void addKeyword(String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            keywords.add(keyword.toLowerCase());
        }
    }

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}
	private DoorState state = DoorState.CLOSED;

	public void setState(DoorState state) {
	    this.state = state;
	    switch (state) {
	        case OPEN:
	            this.isOpen = true;
	            this.isLocked = false;
	            break;
	        case CLOSED:
	            this.isOpen = false;
	            this.isLocked = false;
	            break;
	        case LOCKED:
	            this.isOpen = false;
	            this.isLocked = true;
	            break;
	    }
	}


	public DoorState getState() {
	    return state;
	}

    private boolean isHidden = false;
	public boolean isHidden() {
		return isHidden;
	}
	public void setHidden(boolean hidden) {
	    this.isHidden = hidden;
	}
	private int doorKeyId = -1; // -1 indicates no key

	public int getDoorKeyId() {
	    return doorKeyId;
	}

	public void setDoorKeyId(int doorKeyId) {
	    this.doorKeyId = doorKeyId;
	}
}
// end Door
