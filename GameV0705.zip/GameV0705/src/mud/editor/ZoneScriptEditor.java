package mud.editor;

import mud.config.Config;
import mud.core.*;
import mud.scripting.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ZoneScriptEditor implements Editor {
	
	private final int zoneId;
	
    private final Map<Integer, Mob> roomMobs = new HashMap<>();
    private final Map<Integer, ObjectItem> roomObjects = new HashMap<>();
    private final Map<Integer, Map<String, DoorState>> doorStates = new HashMap<>();
    private final Set<Integer> recallNodes = new HashSet<>();
    private final Map<Integer, Map<Integer, List<Integer>>> nestedObjects = new HashMap<>();
    private final Map<Integer, Integer> mobCounts = new HashMap<>();
    
    private Player player;
    private BasicZoneScript zoneScript;
    private boolean finished = false;
    private ZoneScriptEditorState state = ZoneScriptEditorState.MAIN_MENU;

    private int editingRoomId = -1;
    private String editingDoorDirection = null;

    private int pendingMobId = -1;
    private int pendingObjectId = -1;
    private int pendingContainerObjectId = -1;

    private double pendingChance = 0.0;

    public ZoneScriptEditor(Player player, ZoneScript script) {
        this.player = player;
        this.zoneScript = (BasicZoneScript) script;
		this.zoneId = player.getCurrentZone().getZoneId();
    }

    @Override
    public void startEditing() {
        finished = false;
        state = ZoneScriptEditorState.MAIN_MENU;
        showMenu();
    }

    @Override
    public void stopEditing() {
        finished = true;
    }

    @Override
    public boolean isFinished() { return finished; }

    @Override
    public void tick() { }

    @Override
    public String getEditorName() { return "ZoneScriptEditor for Zone " + zoneScript.getZoneId(); }

    @Override
    public void showMenu() {
        player.sendMessage("\n--- Zone Script Editor ---");
        player.sendMessage("1) Edit Room Scripts");
        player.sendMessage("2) Show Script");
        player.sendMessage("3) Set Recall Nodes");
        player.sendMessage("4) Save Script and Exit Editor");
        player.sendMessage("5) Exit Without Saving");
        player.sendMessage("Type a command or option number:");
    }

    public void showScript() {
        player.sendMessage(zoneScript.serialize());
    }

    @Override
    public void handleInput(String input) {
        if (input == null || input.isBlank()) { player.sendMessage("Enter a command or 'menu'."); return; }
        input = input.trim();
        if (input.equalsIgnoreCase("menu")) { showMenu(); return; }
        if (input.equalsIgnoreCase("show")) { showScript(); return; }
        if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("done") || input.equalsIgnoreCase("quit")) { finished = true; player.sendMessage("Exiting editor."); return; }

        switch (state) {
            case MAIN_MENU -> handleMainMenu(input);
            case AWAITING_ROOM_ID -> handleRoomIdInput(input);
            case EDITING_ROOM_SCRIPT -> handleRoomScriptMenuInput(input);
            case AWAITING_ADD_MOB_ID -> handleMobIdInput(input);
            case AWAITING_MOB_LOAD_CHANCE -> handleMobLoadChance(input);
            case AWAITING_ADD_OBJECT_ID -> handleObjectIdInput(input);
            case AWAITING_OBJECT_LOAD_CHANCE -> handleObjectLoadChance(input);
            case AWAITING_DOOR_DIRECTION -> handleDoorDirection(input);
            case AWAITING_DOOR_STATE -> handleDoorState(input);
            case AWAITING_CONTAINER_OBJECT_ID -> handleContainerObjectId(input);
            case AWAITING_INNER_OBJECT_ID -> handleInnerObjectId(input);
            case AWAITING_RECALL_NODES -> handleRecallNodesInput(input);
        }
    }

    private void handleMainMenu(String input) {
        switch (input) {
            case "1" -> { player.sendMessage("Enter room ID to edit:"); state = ZoneScriptEditorState.AWAITING_ROOM_ID; }
            case "2" -> showScript();
            case "3" -> { player.sendMessage("Enter comma-separated Room IDs for recall nodes:"); state = ZoneScriptEditorState.AWAITING_RECALL_NODES; }
            case "4" -> { saveZoneScriptInternal(); finished = true; }
            case "5" -> { player.sendMessage("Exiting without saving."); finished = true; }
            default -> player.sendMessage("Invalid option.");
        }
    }

    private void handleRoomIdInput(String input) {
        try {
            int roomId = Integer.parseInt(input);
            Room room = player.getCurrentWorld().getRoom(player.getCurrentZone().getZoneId(), roomId);
            if (room == null) { player.sendMessage("Room not found."); return; }
            editingRoomId = roomId;
            state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
            showRoomScriptMenu(roomId);
        } catch (NumberFormatException e) { player.sendMessage("Invalid room ID."); }
    }

    private void showRoomScriptMenu(int roomId) {
        player.sendMessage("\n--- Editing Room " + roomId + " ---");
        player.sendMessage("1) Add Mob");
        player.sendMessage("2) Add Object");
        player.sendMessage("3) Add Object Inside Object");
        player.sendMessage("4) Set Door State");
        player.sendMessage("5) Back to Main Menu");
    }

    private void handleRoomScriptMenuInput(String input) {
        switch (input) {
            case "1" -> { player.sendMessage("Enter Mob ID to add:"); state = ZoneScriptEditorState.AWAITING_ADD_MOB_ID; }
            case "2" -> { player.sendMessage("Enter Object ID to add:"); state = ZoneScriptEditorState.AWAITING_ADD_OBJECT_ID; }
            case "3" -> { player.sendMessage("Enter container Object ID:"); state = ZoneScriptEditorState.AWAITING_CONTAINER_OBJECT_ID; }
            case "4" -> { player.sendMessage("Enter Door Direction:"); state = ZoneScriptEditorState.AWAITING_DOOR_DIRECTION; }
            case "5" -> { state = ZoneScriptEditorState.MAIN_MENU; showMenu(); }
            default -> player.sendMessage("Invalid option.");
        }
    }

    private void handleMobIdInput(String input) {
        try { pendingMobId = Integer.parseInt(input.trim()); player.sendMessage("Enter load chance (0-100%) for Mob ID " + pendingMobId + ":"); state = ZoneScriptEditorState.AWAITING_MOB_LOAD_CHANCE; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Mob ID."); }
    }

    private void handleMobLoadChance(String input) {
        try {
            double chance = Double.parseDouble(input.trim()) / 100.0;
            zoneScript.addMobToRoom(editingRoomId, pendingMobId, chance);
            player.sendMessage("Added Mob " + pendingMobId + " to room " + editingRoomId + " with " + (chance * 100) + "% chance.");
        } catch (NumberFormatException e) { player.sendMessage("Invalid chance."); }
        pendingMobId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleObjectIdInput(String input) {
        try { pendingObjectId = Integer.parseInt(input.trim()); player.sendMessage("Enter load chance (0-100%) for Object ID " + pendingObjectId + ":"); state = ZoneScriptEditorState.AWAITING_OBJECT_LOAD_CHANCE; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Object ID."); }
    }

    private void handleObjectLoadChance(String input) {
        try {
            double chance = Double.parseDouble(input.trim()) / 100.0;
            zoneScript.addObjectToRoom(editingRoomId, pendingObjectId, chance);
            player.sendMessage("Added Object " + pendingObjectId + " to room " + editingRoomId + " with " + (chance * 100) + "% chance.");
        } catch (NumberFormatException e) { player.sendMessage("Invalid chance."); }
        pendingObjectId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleDoorDirection(String input) { editingDoorDirection = input.toLowerCase(); player.sendMessage("Enter door state for '" + editingDoorDirection + "' (open, closed, locked):"); state = ZoneScriptEditorState.AWAITING_DOOR_STATE; }

    private void handleDoorState(String input) {
        mud.scripting.ZoneScript.DoorState doorState = switch (input.toLowerCase()) { case "open" -> ZoneScript.DoorState.OPEN; case "closed" -> ZoneScript.DoorState.CLOSED; case "locked" -> ZoneScript.DoorState.LOCKED; default -> null; };
        if (doorState == null) { player.sendMessage("Invalid door state."); return; }
        zoneScript.setDoorState(editingRoomId, editingDoorDirection, doorState);
        player.sendMessage("Door '" + editingDoorDirection + "' set to " + doorState);
        editingDoorDirection = null; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId);
    }

    private void handleContainerObjectId(String input) {
        try { pendingContainerObjectId = Integer.parseInt(input.trim()); player.sendMessage("Enter inner Object ID to put inside " + pendingContainerObjectId + ":"); state = ZoneScriptEditorState.AWAITING_INNER_OBJECT_ID; }
        catch (NumberFormatException e) { player.sendMessage("Invalid Object ID."); }
    }

    private void handleInnerObjectId(String input) {
        try { int innerId = Integer.parseInt(input.trim()); zoneScript.addObjectInsideObject(editingRoomId, pendingContainerObjectId, innerId); player.sendMessage("Added Object " + innerId + " inside " + pendingContainerObjectId);
        } catch (NumberFormatException e) { player.sendMessage("Invalid inner Object ID."); }
        finally { pendingContainerObjectId = -1; state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT; showRoomScriptMenu(editingRoomId); }
    }

    private void handleRecallNodesInput(String input) {
        String[] parts = input.split(",");
        for (String part : parts) {
            try { int roomId = Integer.parseInt(part.trim()); zoneScript.createRecallNode(roomId); player.sendMessage("Added room " + roomId + " as recall node."); }
            catch (NumberFormatException e) { player.sendMessage("Invalid room ID: " + part); }
        }
        state = ZoneScriptEditorState.MAIN_MENU; showMenu();
    }

    private boolean saveZoneScriptInternal() {
        Zone zone = player.getZone();
        if (zone == null) { player.sendMessage("Cannot save: Zone is null."); return false; }
        File file = new File(Config.SCRIPT_DIR, zone.getWorld().getWorldId() + "_" + zone.getZoneId() + ".Script.txt");
        try (FileWriter writer = new FileWriter(file)) { writer.write(zoneScript.serialize()); player.sendMessage("ZoneScript saved to " + file.getAbsolutePath()); return true; }
        catch (IOException e) { player.sendMessage("Failed to save ZoneScript: " + e.getMessage()); e.printStackTrace(); return false; }
    }


    public int getZoneId() {
        return zoneId;
    }

    public void addMobToRoom(int roomId, Mob mob) {
        roomMobs.put(roomId, mob);
    }

    public void addObjectToRoom(int roomId, ObjectItem obj) {
        roomObjects.put(roomId, obj);
    }

    public void setDoorState(int roomId, String direction, DoorState state) {
        doorStates.computeIfAbsent(roomId, k -> new HashMap<>()).put(direction, state);
    }

    public void addObjectInsideObject(int roomId, int containerId, int innerId) {
        nestedObjects.computeIfAbsent(roomId, k -> new HashMap<>())
                     .computeIfAbsent(containerId, k -> new ArrayList<>())
                     .add(innerId);
    }

    public Map<Integer, Map<String, DoorState>> getDoorStates() {
        return doorStates;
    }

    public Set<Integer> getRecallNodes() {
        return recallNodes;
    }

    public void addRecallNode(int roomId) {
        recallNodes.add(roomId);
    }

    public void addMobSpawnChance(int mobId, double chance, int count) {
        mobCounts.put(mobId, count);
        // Implementation to store chance if needed
    }

    public int getMobSpawnCount(int mobId) {
        return mobCounts.getOrDefault(mobId, 1);
    }

    public Map<Integer, Double> getMobSpawnChances() {
        return Collections.emptyMap();
    }

    public Map<Integer, Double> getObjectSpawnChances() {
        return Collections.emptyMap();
    }

    public void addMobSpawnChance(int mobId, double chance) {
        addMobSpawnChance(mobId, chance, 1);
    }
    
    
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("ZoneScript for Zone ID: ").append(zoneId).append("\n\n");

        if (!recallNodes.isEmpty()) {
            sb.append("Recall Nodes:\n");
            for (int id : recallNodes) {
                sb.append("  RoomID: ").append(id).append("\n");
            }
            sb.append("\n");
        }

        if (!doorStates.isEmpty()) {
            sb.append("Door States:\n");
            for (var roomEntry : doorStates.entrySet()) {
                int roomId = roomEntry.getKey();
                for (var dirEntry : roomEntry.getValue().entrySet()) {
                    sb.append("  Room ").append(roomId)
                      .append(" - ").append(dirEntry.getKey())
                      .append(": ").append(dirEntry.getValue()).append("\n");
                }
            }
            sb.append("\n");
        }

        if (!nestedObjects.isEmpty()) {
            sb.append("Nested Object Spawns:\n");
            for (var roomEntry : nestedObjects.entrySet()) {
                int roomId = roomEntry.getKey();
                for (var containerEntry : roomEntry.getValue().entrySet()) {
                    int containerId = containerEntry.getKey();
                    for (int innerId : containerEntry.getValue()) {
                        sb.append("  Room ").append(roomId)
                          .append(": ").append(innerId)
                          .append(" inside ").append(containerId).append("\n");
                    }
                }
            }
            sb.append("\n");
        }

        return sb.toString();
    }
	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return false;
	}
}
