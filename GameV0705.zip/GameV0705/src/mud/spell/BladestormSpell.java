package mud.spell;

import mud.core.Mob;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.core.ObjectItem;
import mud.spell.effects.BladestormEffect;

public class BladestormSpell implements Spell {

    private final MagicDamageType damageType = MagicDamageType.PHYSICAL;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "bladestorm";
    }

    @Override
    public String getDescription() {
        return "Unleash a rain of whirling weapons that strikes all enemies each tick!";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {

        // Must have a weapon equipped
        ObjectItem weapon = caster.getEquippedItem(EquipSlot.MAINHAND);
        if (weapon == null) {
            caster.sendMessage("You must wield a weapon to unleash a bladestorm.");
            return false;
        }

        int manaCost = 40;
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You lack the mana to unleash a bladestorm.");
            return false;
        }

        caster.setCurrentMP(caster.getCurrentMP() -manaCost);

        int durationTicks = 6;
        int baseDamage = (int) (weapon.rollDamage()/4 + caster.getStrength()/2);
        
        int scaledDamage = (int) ( baseDamage * caster.getRank().getMultiplier()) ;

        new BladestormEffect(caster, weapon, scaledDamage, durationTicks);

        caster.sendMessage("You unleash a furious rain of " + weapon.getWeaponType() + "s" + icon + "!");
        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " unleashes a furious rain of " + weapon.getWeaponType() + "s" + icon + "!",
            caster, null
        );

        return true;
    }

    @Override
    public int getLevelRequired() { return 5; }

    @Override
    public boolean isInstantCast() { return false; }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
	    return Set.of(Profession.WARRIOR, Profession.ROGUE); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end
