package mud.core.enums;

public enum Season {
    WINTER,
    SPRING,
    SUMMER,
    AUTUMN
} // end