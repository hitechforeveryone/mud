package mud.config;

public class ChangeLog {
	
	// v0.7.0.9
		// combatMangaer rewrite, handles combat only, death stuff (reincarnate/nokill checks) put into DeathManager
		// map system, World Map of Tithrius, zone maps for many zones, zone maps update/mark player position on map
		
	// v0.7.0.8 
		// loadZone update with traversal and exit checkers
		// exp/level consolidation
		// follow command
		// where command
		// expanded races/subraces
		// charisma stat added
		// spell cast handler fixed to allow target-less spell casting
		// findfamiliar/tamepet... spells using Master/Pet fields
		// Order command for pets and admin to control mobs
		// admin commands
		// Imm/Gimm only communication channel
		// party channel
		// eat/drink commands, hp/mp restore, if poisoned, poison player
		// quaff // to finish, need spells on items
		// use // to finish, need spells on items
		// recite // to finish, need spells on items
		// light, duration is "hourly" not ticks
		// additional spells
	// v0.7.0.7 work on Shops/Banks
		// combat manager cleanup
		// exp and leveling cleanup/consolidation
		// corpses are containers, "corpse" containers rot after 3 days and drop contents to room
		// additional help files
		// additional spells
		// Full Moon and Eclipse behaviors
	// v0.7.0.6 Zone Scripts! 
		// basic zone script editor // this needs work
		// parse and apply scripts to zones // this works if formatting is ensured
	// v0.7.0.5 work object editor, obj file formating, equip/unequip/drop, player inventory work
		// Security Updates - LoginManager/PlayerLoader updated to use password hashing. plaintext password auto-removed/changed to hashpw on next player login/out
		// WorldManager Updates
		// Code Cleanup, unused removed, commene-out code removed
	// v0.7.0.4 casting system updates, spell registration/casting by profession, additional spells (cure light, cure serious, cure critical, lifebloom, silence/sonicdamp, poison, transport..), additional help files 
		// SpellRegister, spell register by profession and are only castable by said professions
		// fleshed-out behavior for most roomFlags
	// v0.7.0.3 basic mobAI implemented, more spells (track, disarm, double attack, dual wield, flee, fumble, disarm, headbutt, rend, gouge, smite/unholysmite, summon), work on zone scripts, work on Party system
	// v0.7.0.2 Zone exits work, work on spell system (heal, fireball, kick, punch, rescue)
	// v0.7.0.1 redesign of base structure on game, modularized game systems, work on Zone Exits, help files+editor
	// v0.7.0.0 created a Server and Client login system for game
	// v0.6.0.0 player objects gone, players are now Mobs
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux now
	// v0.5.0 introduces zone objects and zoneScript objects (not working)
	

}
