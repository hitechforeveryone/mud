package mud.core;

public enum MobBehaviorFlag {
    STATIONARY(1 << 0),     // Default
    SENTRY(1 << 1),
    AGGRESSIVE(1 << 2),
    ASSISTER(1 << 3),
    JANITOR(1 << 4),
    TALKER(1 << 5),
    BANKER(1 << 6),
    BLACKSMITH(1 << 7),
    SHOPKEEPER(1 << 8),
    INNKEEPER(1 << 9),
    USE_SPELLS(1 << 10),
    REINCARNATE(1 << 11),
    HUNTER(1 << 12),
    CITYGUARD(1 << 13),
	PICKPOCKET(1 << 14),
	HEALER(1 << 15),
	WIMPY(1 << 16);

    private final int bit;
    MobBehaviorFlag(int bit) { this.bit = bit; }
    public int getBit() { return bit; }
}
