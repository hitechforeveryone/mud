package mud.core;

public enum EffectType {
	AOE,
	BERSERK,
	BLEED,
    BLESSING,
    BLIND,
    BUFF,
    BURN,
    CHARM,
    CONFUSE,
    CURSE,
    DETECT_INVISIBLE,
    INVISIBILITY,
    DISORIENT,

    ENTANGLE, // nature type snare effects
    FEAR,
    FIRE_SHIELD, 
    FORCEFUL_HAND,
    CRUSHING_GRIP,
    FROSTBITE, // ice type snare effects
    
    HOLD, // arcane type snare effects
    DOT,
    HOT,
    
    LEVITATE,
    MAGIC,
    POISON,
    REGENERATION,
    ROOT, // earth type snare effects
    SANCTUARY,
    SHIELD,
    SILENCE,
    STUN,
    TAME,
    UNDERWATER_BREATHING,
    WATER_WALK,
    ICEWALL,
    FIREWALL,
    EARTHWALL,
    METALWALL,
    MIRROR_IMAGE,
    SHADOW_CLONE,
    PORTAL,
    WEB, // shadow type snare effects

;

	public EffectType getType() {
		return this;
	}
}