package mud.core;

import mud.config.Config;
import mud.scripting.BasicZoneScript;
import mud.scripting.ZoneScript;
import mud.scripting.ZoneScriptRegistry;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;


public class Zone {
    private int zoneId;
    private Map<Integer, Room> rooms = new HashMap<>(); // max 100 entries
    private ZoneScript script;
    private String name; // zone name
    private String Owner; // zone owner/creator's name
    private Climate climate = Climate.NONE; //
    private WeatherType currentWeather = WeatherType.NONE;
    
    //private int resetType = 0;        // default: never resets, 0 by default (never resets), 1 resets when empty (of players) on resetTimer, 2 normally (while players inside) on resetTimer, 3 reset and undock/unload zone   
    private ZoneResetType resetType = ZoneResetType.NEVER;
    private int resetTimer = 0;       // in game days
    private int lastResetDay = 0;     // day index of last reset
    
    private String zoneScriptClassName = "mud.scripting.Zone0ZoneScript"; // Default fallback
    private transient ZoneScript zoneScript;

    private World parentWorld;
    
    private transient boolean saving = false;

    public void setSaving(boolean value) { this.saving = value; }
    public boolean isSaving() { return saving; }



    
    public Zone() {
        // Initialize defaults if needed
    }
    // Make sure zoneId is set via constructor or method:
    public Zone(int zoneId) {
        this.zoneId = zoneId;
    }

    public int getZoneId() {
        return zoneId;
    }

    public void addRoom(int index, Room room) {
        if (index >= 0 && index < 100) {
            rooms.put(index, room);
            room.setZone(this); // ✅ link back to zone
        }
    }


    public Room getRoom(int number) {
        return rooms.get(number);
    }
    
    public Room getRoomOrThrow(int number) {
        Room room = rooms.get(number);
        if (room == null) throw new IllegalArgumentException("Room " + number + " does not exist in zone " + zoneId);
        return room;
    }
    
    public void initialize() {
    	if (isSaving()) return;
        if (zoneScript == null) {
            System.err.println("⚠️ Warning: Zone " + zoneId + " has no script assigned.");
            return;
        }

        zoneScript.apply(this);
    }


    public boolean hasRoom(int number) {
        return rooms.containsKey(number);
    }
    public Map<Integer, Room> getRooms() {
        return Collections.unmodifiableMap(rooms);
    }
    public void removeRoom(int number) {
        rooms.remove(number);
    }

    public void setScript(ZoneScript script) {
    	// TODO FIND WHERE THIS IS BEING CALLED IN 
        if (script == null) {
            System.err.println("⚠️ Zone " + this.zoneId + ": Tried to assign null script!");
        } else {
            if (script.getZoneId() != this.zoneId) {
                throw new IllegalArgumentException("ZoneScript zoneId does not match Zone zoneId.");
            }
        }
        this.zoneScript = script;
    }

    @Override
    public String toString() {
        return "Zone{id=" + zoneId + ", rooms=" + rooms.size() + "}";
    }

	public ZoneScript getScript() {
		return script;
	}
	private World world;

	public World getWorld() {
	    return world;
	}

	public void setWorld(World world) {
	    this.world = world;
	}
	public List<Mob> getAllMobs() {
	    List<Mob> mobs = new ArrayList<>();
	    for (Room room : rooms.values()) {
	        mobs.addAll(room.getMobs());  // assumes Room has getMobs()
	    }
	    return mobs;
	}

	public List<ObjectItem> getAllObjects() {
	    List<ObjectItem> objects = new ArrayList<>();
	    for (Room room : rooms.values()) {
	        objects.addAll(room.getObjects()); // assumes Room has getObjects()
	    }
	    return objects;
	}

	public Room getRoomById(int roomId) {
	    // Assuming you have a Map<Integer, Room> rooms or similar:
	    return rooms.get(roomId);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setZoneId(int zoneId) {
		this.zoneId = zoneId;
	}

	public void setRooms(Map<Integer, Room> rooms) {
		this.rooms = rooms;
	}

	public String getOwner() {
		return Owner;
	}

	public void setOwner(String owner) {
		Owner = owner;
	}

	public ZoneScript getOrCreateScript() {
	    if (script != null) return script;

	    script = ZoneScriptRegistry.createForZone(this);
	    if (script == null) {
	        System.out.println("⚠️ Zone " + zoneId + " has no script registered, using blank script.");
	        script = new BasicZoneScript(this, zoneId);
	    }

	    setScript(script); // ✅ Ensure it's stored
	    return script;
	}




	public ZoneScript getZoneScript() {
	    return zoneScript;
	}

	public void setZoneScript(ZoneScript zoneScript) {
	    this.zoneScript = zoneScript;
	}
	public void setZoneScriptClassName(String className) {
	    this.zoneScriptClassName = className;
	}

	public String getZoneScriptClassName() {
	    return zoneScriptClassName;
	}

	public Climate getClimate() {
	    return climate;
	}

	public void setClimate(Climate climate) {
	    this.climate = climate;
	}

	public WeatherType getCurrentWeather() {
	    return currentWeather;
	}

	public void setCurrentWeather(WeatherType weather) {
	    this.currentWeather = weather;
	}
	/*
	public int getResetType() {
	    return resetType;
	}

	public void setResetType(int resetType) {
	    this.resetType = resetType;
	}
	*/
	// NEW
	public void setResetType(ZoneResetType resetType) {
	    this.resetType = resetType;
	}

	public ZoneResetType getResetType() {
	    return this.resetType;
	}


	public int getResetTimer() {
	    return resetTimer;
	}

	public void setResetTimer(int resetTimer) {
	    this.resetTimer = resetTimer;
	}

	public int getLastResetDay() {
	    return lastResetDay;
	}

	public void setLastResetDay(int lastResetDay) {
	    this.lastResetDay = lastResetDay;
	}
	
	public int getDaysSinceReset() { return lastResetDay; }
	public void setDaysSinceReset(int days) { this.lastResetDay = days; }
	
	public void incrementResetCounter() { this.lastResetDay++; }
	
	public void resetCounter() { this.lastResetDay = 0; }
	
	public boolean hasPlayers() {
	    for (Room room : getRooms().values()) {
	        if (room.hasPlayers()) return true;
	    }
	    return false;
	}
	
	public void clearMobs() {
	    for (Room room : getRooms().values()) {
	        room.getMobs().removeIf(mob -> !(mob instanceof Player));
	    }
	}
	/*
	public void clearMobs() {
	    for (Room room : getRooms().values()) {
	        room.clearMobs(); // assumes Room has a method for this
	    }
	}
*/
	
	public void clearObjects() {
	    for (Room room : getRooms().values()) {
	        room.getObjects().clear();
	    }
	}
	/*
	public void clearObjects() {
	    for (Room room : getRooms().values()) {
	        room.clearObjects();
	    }
	}
	*/
	
	public void resetZone() {
	    if (getScript() != null) {
	        System.out.println("Resetting zone " + zoneId + ": " + getName());
	        clearMobs();
	        clearObjects();
	        initialize(); // Re-run ZoneScript
	        resetCounter();
	    }
	}

	public void reapplyScriptIfMissing() {
	    if (this.script != null) return;

	    // Try to load from registry
	    ZoneScript fromRegistry = ZoneScriptRegistry.createForZone(this);
	    if (fromRegistry != null) {
	        this.script = fromRegistry;
	        System.out.println("✅ Reattached script to Zone " + this.zoneId);
	        return;
	    }

	    // Fallback to BasicZoneScript if registry has nothing
	    System.out.println("⚠️ No script found for Zone " + this.zoneId + ", using BasicZoneScript.");
	    this.script = new BasicZoneScript(this, this.zoneId);
	}

	
    public void setParentWorld(World world) {
        this.parentWorld = world;
    }

    public World getParentWorld() {
        return this.parentWorld;
    }

    public String returnStatBlock() {
        StringBuilder sb = new StringBuilder();

        sb.append("🌍 Zone ID: ").append(getZoneId()).append("\n");
        sb.append("Name: ").append(getName()).append("\n");
        sb.append("Owner: ").append(getOwner()).append("\n");
        sb.append("World: ").append(getWorld() != null ? getWorld().getName() : "None").append("\n"); // test line

        sb.append("Parent World: ").append(getParentWorld() != null ? getParentWorld().getName() : "None").append("\n");

        sb.append("Climate: ").append(getClimate()).append("\n");
        sb.append("Reset Type: ").append(getResetType()).append("\n");
        sb.append("Reset Timer: ").append(getResetTimer()).append("\n");

        // TODO
      //  sb.append("Recall Nodes: ").append(this.getScript().getRecallNodes()).append("\n");
        
        sb.append("Rooms in Zone:\n");
        for (Room room : getRooms().values()) {
            sb.append(" - ").append(room.getId()).append(" : ").append(room.getName()).append("\n");
        }

        return sb.toString();
    }

} // end Zone
