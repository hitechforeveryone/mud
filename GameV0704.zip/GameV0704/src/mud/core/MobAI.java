package mud.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import mud.spell.effects.FlameBarrierEffect;
import mud.spell.effects.FortifyEffect;
import mud.spell.effects.IcewallEffect;
import mud.spell.effects.RampartEffect;

public class MobAI {

	public static void tickMobBehavior() {
		for (Mob mob : WorldManager.getAllMobs()) {
			Room room = mob.getCurrentRoom();
			if (room == null) continue; // skip if mob has no room

			
			// --- WIMPY ----
			// Clean & Correct WIMPY Flee Logic

			if (mob.hasBehavior(MobBehaviorFlag.WIMPY) && mob.getInCombat()) {
			    // Trigger flee when HP <= 20%
			    if (mob.getCurrentHP() <= mob.getMaxHP() / 5) {

			        Room current = mob.getCurrentRoom();
			        if (current == null) return;

			        Map<Direction, Room> exits = current.getExits();
			        if (exits == null || exits.isEmpty()) {
			            return; // No exits, cannot flee
			        }

			        // Collect functional exits
			        List<Direction> validDirs = new ArrayList<>();
			        for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
			            Direction dir = entry.getKey();
			            Room dest = entry.getValue();
			            if (dest == null) continue;

			            Door door = current.getDoor(dir);
			            if (door != null) {
			                if (!door.isOpen() || door.isLocked()) continue; // Skip blocked exits
			            }

			            // NEW: spell-based movement restrictions
			            if (isMovementBlocked(mob, mob.getCurrentRoom(), dir) == true) continue;
			            
			            validDirs.add(dir);
			        }

			        if (validDirs.isEmpty()) {
			            return; // No usable exits
			        }

			        // Pick random direction
			        Direction fleeDir = validDirs.get(new Random().nextInt(validDirs.size()));
			        Room escapeRoom = exits.get(fleeDir);

			        // Move mob
			        current.removeMob(mob);
			        escapeRoom.addMob(mob);
			        mob.setCurrentRoom(escapeRoom);
			        mob.setRoom(escapeRoom);

			        // Drop combat
			        if (mob.getCurrentTarget() != null) {
			            mob.getCurrentTarget().setTarget(null);
			        }
			        mob.setTarget(null);
			        mob.setInCombat(false);

			        // Output messaging
			        current.broadcast(mob.getMobName() + " flees to the " + fleeDir.name() + "!", mob);
			        escapeRoom.broadcast(mob.getMobName() + " rushes in, fleeing in terror!", mob);

			        System.out.println("DEBUG: " + mob.getMobName() + " fled " + fleeDir.name() + " to room " + escapeRoom.getId());
			    }
			}
			

			
			

			// --- CITYGUARD ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.CITYGUARD) && !mob.getInCombat()) {
				// check mobs and players in room
				List<Mob> potentialVictims = new ArrayList<>();
				potentialVictims.addAll(room.getMobs());
				potentialVictims.addAll(room.getPlayers());

				for (Mob victim : potentialVictims) {
					if (victim == mob) continue; // skip self
					if (!victim.getInCombat() || victim.getTarget() == null) continue;

					Mob aggressor = victim.getTarget();
					if (aggressor == mob) continue; // don’t rescue from self
					if (aggressor.getTarget() != victim) continue; // only intervene if aggressor is still fighting victim

					room.broadcast(mob.getMobName() + " intervenes to protect " + victim.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " rescued " + victim.getMobName() + " from " + aggressor.getMobName());

					// Guard takes over combat
					mob.setTarget(aggressor);
					mob.setInCombat(true);

					aggressor.setTarget(mob);
					aggressor.setInCombat(true);

					victim.setTarget(null);
					victim.setInCombat(false);

					break; // only rescue once per tick
				}
			}

			// --- ASSISTER ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.ASSISTER) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					if (player.getInCombat() && player.getTarget() != null) {
						room.broadcast(mob.getMobName() + " rushes to aid its ally against " + player.getMobName() + "!", mob);
						mob.setTarget(player);
						mob.setInCombat(true);
						break;
					}
				}
			}


			// --- AGGRESSIVE ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.AGGRESSIVE) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					System.out.println("DEBUG: Found player " + player.getMobName() + " in room " + room.getId());
				}

				for (Mob player : room.getPlayers()) {

					if (player == null) continue; // safety
					// Optional: skip dead/disconnected players here

					room.broadcast(mob.getMobName() + " snarls and attacks " + player.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " attacked " + player.getMobName());

					// Mob engages combat
					mob.setTarget(player);
					mob.setInCombat(true);

					// Player is now in combat with mob
					player.setTarget(mob);
					player.setInCombat(true);

					break; // only attack one player per tick
				}
			}


			// --- JANITOR ---
			// will check when ObjectItems are finalized
			if (mob.hasBehavior(MobBehaviorFlag.JANITOR)) {
				for (ObjectItem obj : new ArrayList<>(room.getObjects())) { // avoid CME
					if (obj.getObjectType() == ObjectType.TRASH || obj.getObjectType() == ObjectType.CONTAINER) {
						mob.addItem(obj);
						room.removeObject(obj);
						room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);
					}
				}
			}


			// --- HUNTER ---
			if (mob.hasBehavior(MobBehaviorFlag.HUNTER)) {
				// TODO:
				// Track nearest player, move toward them across rooms (stay in Zone)
				// If in room with player, attack
			}


			// --- HEALER ----
			if (mob.hasBehavior(MobBehaviorFlag.HEALER)) {
				// TODO: 
				// If in room with mob/player && mob/player hp < 100, cast heal on mob/player

			}


			// --- PICKPOCKET ----
			if (mob.hasBehavior(MobBehaviorFlag.PICKPOCKET)) {
				// TODO: 
				// if in room with player, attempt to take coins from player
			}

			// --- USE_SPELLS ----
			if (mob.hasBehavior(MobBehaviorFlag.USE_SPELLS)) {
				// TODO: 
				// mob will attempt to cast spells in combat
			}


			// --- other behaviors from MobBehaviorFlag go here ---

		}
	} // end tickMobBehavior()

	


	public static void tickMobMovement() {
		for (World world : WorldManager.getAllWorlds()) {
			tickMobMovement(world);
		}
	}

	public static void tickMobMovement(World world) {
	    Map<Mob, Room> moves = new HashMap<>();

	    for (Room room : world.getRooms()) {
	        List<Mob> mobsCopy = new ArrayList<>(room.getMobs());

	        for (Mob mob : mobsCopy) {
	            if (mob == null || mob.hasBehavior(MobBehaviorFlag.STATIONARY)) continue;

	            Room currentRoom = mob.getCurrentRoom();
	            if (currentRoom == null) continue;

	            Zone currentZone = currentRoom.getZone();
	            if (currentZone == null) continue;

	            Map<Direction, Room> exits = currentRoom.getExits();
	            if (exits == null || exits.isEmpty()) continue;

	            List<Direction> validDirs = new ArrayList<>();

	            for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                Direction dir = entry.getKey();
	                Room dest = entry.getValue();

	                if (dest == null || dest.getZone() != currentZone || dest.hasFlag(RoomFlag.NOMOB)) continue;
	                if (isMovementBlocked(mob, currentRoom, dir)) continue;

	                Door door = currentRoom.getDoor(dir);
	                if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                if (dest == mob.getLastRoom()) continue;
	                validDirs.add(dir);
	            }

	            if (validDirs.isEmpty()) {
	                for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                    Direction dir = entry.getKey();
	                    Room dest = entry.getValue();

	                    if (dest == null || dest.getZone() != currentZone || dest.hasFlag(RoomFlag.NOMOB)) continue;
	                    if (isMovementBlocked(mob, currentRoom, dir)) continue;

	                    Door door = currentRoom.getDoor(dir);
	                    if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                    validDirs.add(dir);
	                }
	            }

	            if (!validDirs.isEmpty()) {
	                Direction chosen = validDirs.get(new Random().nextInt(validDirs.size()));
	                Room dest = currentRoom.getExit(chosen);

	                if (dest != null && !dest.hasFlag(RoomFlag.NOMOB)) {
	                    moves.put(mob, dest);
	                }
	            }
	        }
	    }

	    // Apply moves
	    for (Map.Entry<Mob, Room> entry : moves.entrySet()) {
	        Mob mob = entry.getKey();
	        Room dest = entry.getValue();
	        Room currentRoom = mob.getCurrentRoom();
	        
	        // handle dest ON_WATER flag
		    boolean hasBoat = false;	    
			for (ObjectItem ob : mob.getInventory())  {
				if (ob.getType() == ObjectType.BOAT) {
					hasBoat = true;
				}
			}           
            if (dest.hasFlag(RoomFlag.ON_WATER) && (!mob.hasEffect(EffectType.WATER_WALK) || hasBoat==false)) {
            	break;
            }
	        
            
            
	        if (currentRoom != null) {
	            currentRoom.removeMob(mob);
	            currentRoom.broadcast(mob.getMobName() + " wanders.", mob);
	        }

	        mob.setCurrentRoom(dest);
	        dest.addMob(mob);
	        mob.setLastRoom(currentRoom);
	        dest.broadcast(mob.getMobName() + " arrives.", mob);

		    boolean levEquipped = false;	    
			for (ObjectItem ob : mob.getEquipment().values())  {
				if (ob.hasEffect(ItemEffect.LEVITATE)) {
					levEquipped = true;
				}
			}
	        
	        // Handle FALL flag for mob movement
	        while (dest.hasFlag(RoomFlag.FALL) && (!mob.hasEffect(EffectType.LEVITATE) || levEquipped==false )) {
	            Room fallDest = dest.getExit(Direction.DOWN);
	            if (fallDest == null) break;

	            dest.removeMob(mob);
	            dest.broadcast(mob.getMobName() + " falls downward.", mob);

	            mob.setCurrentRoom(fallDest);
	            fallDest.addMob(mob);
	            fallDest.broadcast(mob.getMobName() + " crashes in from above.", mob);
	            dest = fallDest;
	        }
	        
	        
	        
	        
	    }
	}



	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";
		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}

	// Checks whether a mob is prevented from moving in the given direction
	public static boolean isMovementBlocked(Mob mob, Room room, Direction dir) {

	    // 1) Room-level exit-blocking effects (Icewall, etc.)
	    if (room.hasEffectOnExit(dir, IcewallEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, FlameBarrierEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, FortifyEffect.class)) {
	        return true;
	    }
	    if (room.hasEffectOnExit(dir, RampartEffect.class)) {
	        return true;
	    }
	    
	    

	    // 2) MOB-level "rooting" effects (player & mob)
	    if (mob.hasEffect(EffectType.HOLD)) return true; // arcane
	    if (mob.hasEffect(EffectType.STUN)) return true; // physical
	    if (mob.hasEffect(EffectType.WEB)) return true; // shadow
	    if (mob.hasEffect(EffectType.ROOT)) return true; // earth
	    if (mob.hasEffect(EffectType.ENTANGLE)) return true; // nature
	    if (mob.hasEffect(EffectType.FROSTBITE)) return true; // ice

	    // Add more here as you introduce new EffectTypes
	    System.out.println("Mob can move.");
	    return false;
	}



}
