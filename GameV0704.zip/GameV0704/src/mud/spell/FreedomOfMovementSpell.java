package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Direction;
import mud.spell.effects.Effect;
import mud.spell.effects.EntangleEffect;
import mud.spell.effects.FrostbiteEffect;
import mud.spell.effects.HoldEffect;
import mud.spell.effects.RootEffect;
import mud.spell.effects.StunEffect;
import mud.spell.effects.WebEffect;
import mud.core.EffectType;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class FreedomOfMovementSpell implements Spell {

    private static final EffectType[] BLOCKED = {
        EffectType.ROOT,
        EffectType.ENTANGLE,
        EffectType.WEB,
        EffectType.FROSTBITE,
        EffectType.HOLD,
        EffectType.STUN
    };
    
    private static final Set<Class<? extends Effect>> BLOCKED_CLASSES = Set.of(
    	    WebEffect.class,
    	    FrostbiteEffect.class,
    	    EntangleEffect.class,
    	    RootEffect.class,
    	    StunEffect.class,
    	    HoldEffect.class
    	);


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }
        
        boolean removedAny = false;

        Iterator<Effect> it = target.getActiveEffects().iterator();

        while (it.hasNext()) {
            Effect eff = it.next();

            if (eff instanceof WebEffect ||
                eff instanceof FrostbiteEffect ||
                eff instanceof EntangleEffect ||
                eff instanceof RootEffect ||
                eff instanceof HoldEffect ||
                eff instanceof StunEffect) {

                for (Class<? extends Effect> clazz : BLOCKED_CLASSES) {
                    if (clazz.isInstance(eff)) {
                        it.remove();
                        eff.onRemove();
                        break;
                    }
                }
            	
                target.getCurrentRoom().broadcastToRoom(target.getMobName() + "s  " + eff.getName() + " has been removed.");
            	
                it.remove();
                eff.onRemove(); // if your system supports callbacks
                
                removedAny = true;
               
            }
            return true;
        }


        if (!removedAny) {
            caster.sendMessage(target.getMobName() + " has no movement-restricting effects to remove.");
            return false;
        }

        return false;
    }

    @Override public String getName() { return "freedom.of.movement"; }
    @Override public boolean cast(Mob c, Direction d) { return false; }
    @Override public String getDescription() { return "Removes movement-impairing effects."; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
