package mud.spell;

import java.io.File;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Room;

public class SpellManager {
    private static SpellManager instance;
    private static final Map<String, Spell> spells = new ConcurrentHashMap<>();

    private SpellManager() {
        loadSpells();
    }

    public static synchronized SpellManager getInstance() {
        if (instance == null) {
            instance = new SpellManager();
        }
        return instance;
    }

    private void loadSpells() {
        try {
            String packageName = "mud.spell";
            String path = packageName.replace('.', '/');

            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            URL resource = cl.getResource(path);

            if (resource == null) {
                System.err.println("Could not find spell package: " + path);
                return;
            }

            if (resource.getProtocol().equals("file")) {
                // Running from IDE exploded directory
                File dir = new File(resource.toURI());
                loadFromDirectory(dir, packageName);
            }

            if (resource.getProtocol().equals("jar")) {
                // Running from JAR
                String jarPath = resource.getPath().substring(5, resource.getPath().indexOf("!"));
                loadFromJar(jarPath, path, packageName);
            }

        } catch (Exception e) {
            System.err.println("Failed to auto-load spells:");
            e.printStackTrace();
        }
    }

    private void loadFromDirectory(File dir, String packageName) throws Exception {
        for (File file : dir.listFiles((d, name) -> name.endsWith(".class") && !name.contains("$"))) {
            String className = file.getName().replace(".class", "");
            Class<?> clazz = Class.forName(packageName + "." + className);

            if (Spell.class.isAssignableFrom(clazz) && !Modifier.isAbstract(clazz.getModifiers())) {
                Spell spell = (Spell) clazz.getDeclaredConstructor().newInstance();
                registerSpell(spell);
                SpellRegister.getInstance().addSpell(spell);
                System.out.println("Loaded spell: " + className);
            }
        }
    }

    private void loadFromJar(String jarPath, String path, String packageName) throws Exception {
        try (java.util.jar.JarFile jar = new java.util.jar.JarFile(jarPath)) {

            jar.stream().forEach(entry -> {
                String name = entry.getName();

                if (name.startsWith(path) && name.endsWith(".class") && !name.contains("$")) {
                    String className = name
                            .replace('/', '.')
                            .replace(".class", "");

                    try {
                        Class<?> clazz = Class.forName(className);

                        if (Spell.class.isAssignableFrom(clazz) && !Modifier.isAbstract(clazz.getModifiers())) {
                            Spell spell = (Spell) clazz.getDeclaredConstructor().newInstance();
                            registerSpell(spell);
                            SpellRegister.getInstance().addSpell(spell);
                            System.out.println("Loaded spell from JAR: " + className);
                        }

                    } catch (Exception ignored) {}
                }
            });
        }
    }

    public String registerSpell(Spell spell) {
        if (spell == null || spell.getName() == null || spell.getName().isEmpty()) {
            throw new IllegalArgumentException("Spell and spell name must not be null or empty.");
        }
        spells.put(spell.getName().toLowerCase(), spell);
        return "Spell " + spell.getName() + " added.";
    }

    public static Spell getSpellByName(String name) {
        if (name == null) return null;
        return spells.get(name.toLowerCase());
    }

    public static String castSpell(String spellName, Mob caster, Mob target) {
        Spell spell = getSpellByName(spellName);
        if (spell == null) {
            return "No such spell: " + spellName;
        }

        boolean success = spell.cast(caster, target);
        return success ? spell.getName() + " was cast successfully." : "The spell failed.";
    }

    public static String castSpell(String spellName, Mob caster, String Dir) {
        Spell spell = getSpellByName(spellName);
        if (spell == null) {
            return "No such spell: " + spellName;
        }

        Direction tarDir = Direction.fromString(Dir);
        boolean success = spell.cast(caster, tarDir);
        return success ? spell.getName() + " was cast successfully." : "The spell failed.";
    }
    
    public static String castSpell(String spellName, Mob caster, ObjectItem obj) {
        Spell spell = getSpellByName(spellName);
        if (spell == null) return "No such spell: " + spellName;

        if (obj == null) return "You do not have such an object.";

        boolean success = spell.cast(caster, obj);
        return success ? spell.getName() + " was cast successfully." : "The spell failed.";
    }
    
    
    public static String listSpells() {
        getInstance(); // ensure initialized

        // Defensive check
        if (spells == null || spells.isEmpty()) {
            return "No spells registered.";
        }

        // Sort alphabetically
        List<String> names = new ArrayList<>(spells.keySet());
        Collections.sort(names);

        return "Available spells: " + String.join(", ", names);
    }
    // end


	public static String castSpell(String spellName, Player player, Room dest) {
		// TODO Auto-generated method stub
		return null;
	}
}
