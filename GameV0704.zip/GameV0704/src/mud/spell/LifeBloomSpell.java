package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.LifeBloomEffect;

public class LifeBloomSpell implements Spell {
	
    MagicDamageType damageType = MagicDamageType.NATURE;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "lifebloom";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to bloom.");
            return false;
        }

        // Scale healing with caster's Intellect: 50% of Int adds to tick, 100% to final bloom
        int intScalingTick = 5 + (int)(caster.getIntellect() * 0.5);
        int intScalingFinal = 30 + caster.getIntellect();
        int totalTicks = 3;

        LifeBloomEffect effect = new LifeBloomEffect(target, intScalingTick, intScalingFinal, totalTicks);
        target.addEffect(effect);
        target.addEffect(EffectType.HOT);

        caster.sendMessage("You begin a gentle bloom of life" + icon + " on " + target.getMobName() + ".");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " blesses you with a blooming life spell.");
            target.getCurrentRoom().broadcastExcept(caster.getMobName() + " casts Lifebloom " + icon + " on " + target.getMobName() + ".", caster, target);
        } else {
            caster.getCurrentRoom().broadcastExcept(caster.getMobName() + " casts Lifebloom " + icon + " on themselves.", caster, null);
        }


        if (caster.getTarget() != null && !caster.getTarget().isDead()) {
            StringBuilder sb = null;
        	sb.append("  ").append(caster.getTarget().getMobName()).append(":").append("HP: ").append(caster.getTarget().getCurrentHP()).append("/").append(caster.getTarget().getMaxHP()).append(" MP: ").append(caster.getTarget().getCurrentMP()).append("/").append(caster.getTarget().getMaxMP());
			caster.sendMessage(sb.toString());
		}


        return true;
    }

    @Override
    public String getDescription() {
        return "Gently heals a target over time, scaling with caster's Intellect.";
    }

    @Override
    public int getLevelRequired() {
        return 0;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.DRUID); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end
