package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EquipSlot;  // Import the nested enum explicitly
import mud.core.MagicDamageType;

public class KickSpell implements Spell {

    @Override
    public String getName() {
        return "kick";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        MagicDamageType damageType = MagicDamageType.PHYSICAL;
        String icon = damageType.getIcon();
        String typeName = damageType.getPrettyName().toLowerCase();
    	
        if (target == null) {
            caster.sendMessage("There is no target to kick.");
            return false;
        }

        if (target == caster) {
            caster.sendMessage("You can't kick yourself.");
            return false;
        }

        // Base damage for kick
        int baseDamage = 10 + caster.getStat("Strength") / 2;  // Use getStat() or getter for strength


        // Apply damage to target
        target.takeDamage(baseDamage);
        if (target.getTarget() == null) {
        	target.setTarget(caster);
        	caster.setTarget(target);
        }

        // Send messages
        caster.sendMessage("You deliver a powerful " + getName() + " to " + target.getMobName() + " for " + baseDamage + icon + " damage!");
        target.sendMessage(caster.getMobName() + getName() + "s you hard, dealing " + baseDamage + icon + " damage!");

        // Broadcast to others in the room except caster and target
        Room room = caster.getCurrentRoom();
        if (room != null) {
            room.broadcastExcept(caster.getMobName() + " kicks" + icon + " " + target.getMobName() + " with a fierce blow!", caster, target);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// can be used without cast command
		return true;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    //	return Set.of(Profession.MAGE, Profession.NECROMANCER,Profession.WARLOCK);
    	return null;
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}