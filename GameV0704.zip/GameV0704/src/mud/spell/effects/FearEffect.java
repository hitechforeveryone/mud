package mud.spell.effects;

import mud.core.Direction;
import mud.core.Door;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class FearEffect implements Effect {

    private static final Random RNG = new Random();
    private static final List<FearEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private int remainingTicks;

    public FearEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Fear";
    }

    @Override
    public EffectType getType() {
        return EffectType.FEAR;
    }

    @Override
    public void tick() {
        if (target == null || target.getCurrentRoom() == null) {
            remainingTicks = 0;
            return;
        }

        Room current = target.getCurrentRoom();
        Map<Direction, Room> exits = current.getExits();

        if (exits == null || exits.isEmpty()) {
            target.sendMessage("You tremble in terror but cannot find a way out!");
            remainingTicks = 0;
            return;
        }

        // Choose a valid flee direction
        List<Direction> dirs = exits.keySet().stream().toList();
        Direction fleeDir = dirs.get(RNG.nextInt(dirs.size()));
        Room nextRoom = exits.get(fleeDir);

        if (nextRoom == null) {
            remainingTicks = 0;
            return;
        }

        // Door logic — Fear should respect doors
        Door door = current.getDoor(fleeDir);
        if (door != null) {
            if (!door.isOpen()) {
                target.sendMessage("In panic you slam into the closed " + door.getDoorName() + "!");
                remainingTicks--;
                if (remainingTicks <= 0) expire();
                return;
            }
            if (door.isLocked()) {
                target.sendMessage("You cower in fear, the locked " + door.getDoorName() + " blocks your escape!");
                remainingTicks--;
                if (remainingTicks <= 0) expire();
                return;
            }
        }

        // Remove combat target
        if (target.getTarget() != null) {
            target.getTarget().setTarget(null);
        }
        target.setTarget(null);
        target.setCurrentTarget(null);

        // Announce flee movement
        target.sendMessage("In blind terror, you flee " + fleeDir.name().toLowerCase() + "!");
        current.broadcastExcept(target.getMobName() + " flees in terror " + fleeDir.name().toLowerCase() + "!", target);

        // Perform movement
        current.removeMob(target);
        nextRoom.addMob(target);
        target.setCurrentRoom(nextRoom);

        nextRoom.broadcastExcept(target.getMobName() + " stumbles in, eyes wide with terror!", target);

        // duration decrement
        remainingTicks--;
        if (remainingTicks <= 0) expire();
    }

    public static void tickAll() {
        Iterator<FearEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            FearEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
    
    public void expire() {
        target.removeEffect(EffectType.FEAR);
        target.getActiveEffects().remove(this);
        ACTIVE_EFFECTS.remove(this);
        target.sendMessage("Your fear subsides, and you regain control.");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() { return null; }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
// end