// ContinualLightEffect.java
package mud.spell.effects;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import mud.core.*;
import mud.spell.effects.Effect;

public class ContinualLightEffect implements Effect {

	private final Mob caster;
	private final ObjectItem target;
	private int duration;
	private boolean expired = false;

	public ContinualLightEffect(Mob caster, ObjectItem target, int duration) {
		this.caster = caster;
		this.target = target;
		this.duration = duration;

		// Apply glow immediately
		target.addEffect(ItemEffect.GLOW);
	}

	@Override
	public String getName() {
		return "Continual Light";
	}

	@Override
	public EffectType getType() {
		return EffectType.BUFF; // or UTILITY if you have it
	}

	@Override
	public boolean isExpired() {

		return expired;
	}

	@Override
	public void tick() {
		if (duration > 0) {
			duration--;
			return;
		}

		// Expire and remove glow
		if (!expired) {
			expired = true;
			target.removeEffect(ItemEffect.GLOW);
		}
	}
	private static final List<ContinualLightEffect> ACTIVE = new LinkedList<>();


	public static void register(ContinualLightEffect eff) {
		if (eff != null) ACTIVE.add(eff);
	}


	public static void tickAll() {
		Iterator<ContinualLightEffect> it = ACTIVE.iterator();
		while (it.hasNext()) {
			ContinualLightEffect eff = it.next();
			eff.tick();
			if (eff.isExpired()) {
				it.remove();
			}
		}
	}

	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub

	}
}
// end
