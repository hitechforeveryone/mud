package mud.spell.effects;

import java.util.*;

import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;


public class DancingLightsEffect implements Effect {

    private static final List<DancingLightsEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Room room;
    private final int totalTicks;
    private int ticksPassed = -1;
    private boolean applied = false;

    MagicDamageType damageType = MagicDamageType.LIGHT;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    public DancingLightsEffect(Room room, int totalTicks) {
        this.room = room;
        this.totalTicks = totalTicks;
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<DancingLightsEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            DancingLightsEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        ticksPassed++;

        if (!applied) {
            applied = true;
          //  room.setFlag(RoomFlag.LIT);
            room.setLit(true);
            room.broadcastToRoom("Soft magical lights float upward, illuminating the room " + icon + ".");
            return;
        }

        if (ticksPassed < totalTicks) {
            if (ticksPassed % 3 == 0) {
                room.broadcastToRoom("The dancing lights shimmer and drift lazily through the air " + icon + ".");
            }
        }

        if (ticksPassed == totalTicks) {
         //   room.removeFlag(RoomFlag.LIT);
            room.setLit(false);
            room.broadcastToRoom("The magical lights fade away, and the room dims once more.");
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public String getName() {
        return "DancingLights";
    }

    @Override
    public EffectType getType() {
        return EffectType.BUFF;
    }

    @Override
    public int getDuration() {
        return totalTicks;
    }

    @Override public int getHpBonus() { return 0; }
    @Override public int getStrengthBonus() { return 0; }
    @Override public mud.core.Mob getTarget() { return null; }
    @Override public Direction getDirection() { return null; }
    @Override public void onApply(Room room) {}
}
// end