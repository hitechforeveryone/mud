package mud.spell.effects;


import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class FlameBarrierEffect implements Effect {

    private final MagicDamageType damageType = MagicDamageType.FIRE;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
	private static final List<FlameBarrierEffect> ACTIVE_FIREWALLS = new CopyOnWriteArrayList<>();


	private final Room room;
	private Direction blockedDir;
	private int remainingTicks;


	public FlameBarrierEffect(Room room, Direction dir, int duration) {
		this.room = room;
		this.blockedDir = dir;
		this.remainingTicks = duration;
		ACTIVE_FIREWALLS.add(this);
	}


	// ---- GLOBAL TICKER ----
	public static void tickAll() {
		for (FlameBarrierEffect ef : ACTIVE_FIREWALLS) {
			ef.tick();
		}
	}


	// ---- INSTANCE TICK ----
	public void tick() {
		remainingTicks--;
		if (remainingTicks <= 0) {
			expire();
		}
	}


	public Direction getBlockedDir() {
		return blockedDir;
	}


	@Override
	public String getName() {
		return "Flame Barrier (" + blockedDir.name().toLowerCase() + ")";
	}


	private void expire() {
		ACTIVE_FIREWALLS.remove(this);


		// remove effect from room
		room.removeExitEffect(blockedDir, this);
		room.broadcastToRoom("The "+getName() +" to the " + blockedDir.name().toLowerCase() + " melts away.");
	}


	@Override
	public boolean isExpired() {
		return remainingTicks <= 0;
	}


	@Override
	public Mob getTarget() {
		return null; // Room-based effect
	}


	@Override
	public EffectType getType() {
		return EffectType.FIREWALL;
	}


	@Override
	public int getDuration() {
		return remainingTicks;
	}


	public Direction getDirection() {
		return blockedDir;
	}


	public void setDirection(Direction dir) {
		this.blockedDir = dir;
	}


	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}


} // end