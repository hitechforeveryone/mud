package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.MobAffectFlag;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;

import java.util.Set;

import mud.commands.CommandProcessor;
import mud.core.Direction;
import mud.core.ItemEffect;
import mud.core.MagicDamageType;

public class TransportSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "transport";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("You must specify someone to transport to.");
            return false;
        }

        // 🧠 Check if target is in the same world
        if (!caster.getWorld().equals(target.getWorld())) {
            caster.sendMessage(target.getMobName() + " is not in this world.");
            return false;
        }
        

        // 🚫 Check if caster/target room forbids teleporting
        Room targetRoom = target.getCurrentRoom();
        Room casterRoom = caster.getCurrentRoom();
        
        if (targetRoom == null) {
            caster.sendMessage("The transport spell fails — no such destination exists.");
            return false;
        }
        
        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A magical barrier prevents you from casting " + getName() + " to " + target.getMobName() + ".");
            return false;
        }
        
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A magical barrier prevents you from transporting to " + target.getMobName() + ".");
            return false;
        }


        
        // 🔮 Deduct mana
        int manaCost = 20;
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You do not have enough mana to cast Transport.");
            return false;
        }
        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // ✨ Perform transport
        caster.getCurrentRoom().removeMob(caster);
        targetRoom.addMob(caster);

        caster.setCurrentRoom(targetRoom);
        caster.setRoom(targetRoom);

        // 💬 Messaging
        caster.sendMessage("You cast " + getName() + " " + icon + " and are instantly transported to " + target.getMobName() + "!");
        target.sendMessage(caster.getMobName() + " suddenly appears next to you!");
        casterRoom.broadcastToRoom(caster.getMobName() + " vanishes in a flash of light!");
        targetRoom.broadcastExcept(caster.getMobName() + " appears next to " + target.getMobName() + " in a flash of light!", caster, target);

        CommandProcessor.lookRoom((Player) caster,caster.getCurrentRoom()); // display the room
        
        return true;
    }

    @Override
    public String getDescription() {
        return "Teleports you to the location of the target within the same zone, unless magically protected.";
    }

    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end TransportSpell
