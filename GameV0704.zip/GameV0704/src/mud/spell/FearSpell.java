package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Direction;
import mud.core.EffectType;
import mud.spell.effects.FearEffect;
import java.util.Random;
import java.util.Set;

public class FearSpell implements Spell {

    private static final int FEAR_TICKS = 4; // how long fear lasts

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast fear on.");
            return false;
        }

        if (target.hasEffect(EffectType.FEAR)) {
            caster.sendMessage(target.getMobName() + " is already terrified!");
            return false;
        }

        // Apply effect
        FearEffect effect = new FearEffect(target, FEAR_TICKS);
        target.addEffect(effect);
        target.addEffect(EffectType.FEAR);

        target.sendMessage("A wave of overwhelming terror grips you!");
        caster.sendMessage("You send " + target.getMobName() + " into a panic with Fear!");

        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(
                caster.getMobName() + " frightens " + target.getMobName() + " with a terrifying spell!");
        }

        return true;
    }

    @Override public String getName() { return "fear"; }
    @Override public String getDescription() { return "Causes the target to flee several rooms in terror."; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
