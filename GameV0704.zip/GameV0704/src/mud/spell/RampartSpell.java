package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;
import mud.core.Room;
import mud.spell.effects.RampartEffect;

public class RampartSpell implements Spell {

    private static final int DURATION_TICKS = 5; // Y rounds/ticks the wall lasts

    @Override
    public String getName() {
        return "rampart";
    }

    @Override
    public String getDescription() {
        return "Creates a rampart of stone in a direction, blocking passage for a short time.";
    }

    @Override
    public boolean cast(Mob caster, Direction dir) {
        if (caster == null || caster.getCurrentRoom() == null) return false;

        Room room = caster.getCurrentRoom();
        Room targetRoom = room.getExit(dir);

        if (targetRoom == null) {
            caster.sendMessage("There is no exit " + dir.name().toLowerCase() + " to block.");
            return false;
        }

        // Check if already blocked
        if (room.hasEffectOnExit(dir, RampartEffect.class)) {
            caster.sendMessage("There is already a rampart blocking that exit.");
            return false;
        }

        // Create effect
        RampartEffect wall = new RampartEffect(room, dir, DURATION_TICKS);
        RampartEffect oppWall = new RampartEffect(room, dir, DURATION_TICKS);
        caster.getCurrentRoom().addExitEffect(dir, wall);

        
        // Messaging
        caster.sendMessage("You raise a rampart of stone to the " + dir.name().toLowerCase() + "!");
        room.broadcastExcept(caster.getMobName() + " raises a rampart of stone to the " + dir.name().toLowerCase() + "!", caster);

        if (targetRoom != null) {
            targetRoom.broadcast("A rampart of stone rises from the " + dir.getOpposite().name().toLowerCase() + "!", null);
            targetRoom.addExitEffect(dir,oppWall);
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Not used
        return false;
    }

    @Override
    public int getLevelRequired() {
        return 2;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return false;
    }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.SHAMAN); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}


}
