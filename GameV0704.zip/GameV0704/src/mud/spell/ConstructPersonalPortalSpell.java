package mud.spell;

import mud.core.Mob;
import mud.core.MobAffectFlag;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.Room;
import mud.core.RoomFlag;

import java.util.Set;

import mud.core.Direction;
import mud.core.ItemEffect;
import mud.core.MagicDamageType;


public class ConstructPersonalPortalSpell implements Spell {


	MagicDamageType damageType = MagicDamageType.SUMMON;
	String icon = damageType.getIcon();
	String typeName = damageType.getPrettyName().toLowerCase();


	@Override
	public String getName() {
		return "construct.personal.portal";
	}


	@Override
	public String getDescription() {
		return "Opens a personal portal allowing the caster to travel instantly to a target within the zone. (transport spoof)";
	}


	@Override
	public boolean cast(Mob caster, Mob target) {
		if (target == null) {
			caster.sendMessage("You must specify someone to portal to.");
			return false;
		}

		Room casterRoom = caster.getCurrentRoom();
		Room targetRoom = target.getCurrentRoom();


		// Same zone check
		if (!casterRoom.getZone().equals(targetRoom.getZone())) {
			caster.sendMessage(target.getMobName() + " is not in this zone.");
			return false;
		}


		// NOTELEPORT flags
		if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("Mystic interference prevents you from opening a portal here.");
			return false;
		}


		if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("A strange force blocks your portal from forming at the target's location.");
			return false;
		}

		
		// Target protections
		// unneeded, we dont care if the target has NOSUMMON
		/*
		if (target.hasAffect(MobAffectFlag.NOSUMMON)) {
			caster.sendMessage(target.getMobName() + " is warded against portal magic!");
			return false;
		}
		for (ObjectItem equipped : target.getEquipment().values()) {
			if (equipped.hasEffect(ItemEffect.NOSUMMON)) {
				caster.sendMessage(target.getMobName() + " is protected by anti-portal magic.");
				return false;
			}
		}
		*/

		// Mana cost
		int manaCost = 35;
		if (caster.getCurrentMP() < manaCost) {
			caster.sendMessage("You lack the mana needed to construct a personal portal.");
			return false;
		}
		caster.setCurrentMP(caster.getCurrentMP() - manaCost);


		// Portal transfer
		casterRoom.broadcast(caster.getMobName() + " opens a swirling mechanical portal and steps through!", caster);


		casterRoom.removeMob(caster);
		targetRoom.addMob(caster);
		caster.setRoom(targetRoom);


		targetRoom.broadcast(caster.getMobName() + " emerges from a whirring gear-driven portal!", target);


		caster.sendMessage("You step through your personal portal and arrive near " + target.getMobName() + "!");
		// unneeded
		/*
		if (target != null) {
			target.getRoom().broadcast(caster.getMobName() + " arrives through a shimmering portal!",target);
		}
		 */

		return true;
	}

	@Override
	public int getLevelRequired() {
		return 8;
	}


	@Override
	public boolean isInstantCast() {
		return true;
	}


	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}


    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MECHANIC);
    }


	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}
}
// end