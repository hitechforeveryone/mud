package mud.scripting;

import mud.config.Config;
import mud.core.Zone;
import mud.scripting.ZoneAction;

import java.io.*;
import java.util.*;

public final class ZoneScriptTextParser {

    private enum Section {
        NONE,
        ROOMS,
        RECALL_NODES
    }

    private enum SubSection {
        NONE,
        MOBS,
        OBJECTS,
        DOORS,
        TRIGGERS
    }

    private ZoneScriptTextParser() {}

    public static BasicZoneScript read(Zone zone) throws IOException {
        File file = resolveScriptFile(zone);
        if (file == null || !file.exists()) return null;

        BasicZoneScript script = new BasicZoneScript(zone, zone.getZoneId());
        parseFile(file, script);
        return script;
    }

    private static File resolveScriptFile(Zone zone) {
        String worldPrefix = zone.getWorld() != null ? zone.getWorld().getWorldId() + "_" : "";
        String fileName = worldPrefix + zone.getZoneId() + ".Script.txt";
        File f = new File(Config.SCRIPT_DIR, fileName);
        return f.exists() ? f : null;
    }

    static void parseFile(File file, BasicZoneScript script) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            Section section = Section.NONE;
            SubSection subSection = SubSection.NONE;
            BasicZoneScript.Room currentRoom = null;

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Detect main sections
                if (line.startsWith("Rooms:")) {
                    section = Section.ROOMS;
                    continue;
                }
                if (line.startsWith("Recall Nodes:")) {
                    section = Section.RECALL_NODES;
                    continue;
                }

                if (section == Section.ROOMS) {
                    // Detect RoomID
                    if (line.startsWith("- RoomID:")) {
                        int roomId = Integer.parseInt(line.substring("- RoomID:".length()).trim());
                        currentRoom = script.createRoom(roomId);
                        script.getRooms().add(currentRoom);
                        subSection = SubSection.NONE;
                        continue;
                    }

                    // Detect subsections within a room
                    if (line.startsWith("Mobs:")) { subSection = SubSection.MOBS; continue; }
                    if (line.startsWith("Objects:")) { subSection = SubSection.OBJECTS; continue; }
                    if (line.startsWith("Doors:")) { subSection = SubSection.DOORS; continue; }
                    if (line.startsWith("Triggers:")) { subSection = SubSection.TRIGGERS; continue; }

                    // Parse lines according to current subsection
                    switch (subSection) {
                        case MOBS -> parseRoomMob(line, currentRoom);
                        case OBJECTS -> parseRoomObject(line, currentRoom);
                        case DOORS -> parseRoomDoor(line, currentRoom);
                        case TRIGGERS -> parseRoomTrigger(line, currentRoom);
                        default -> { }
                    }
                }
                else if (section == Section.RECALL_NODES) {
                    // Example: RoomID: 100
                    try {
                        int roomId = Integer.parseInt(line.replace("RoomID:", "").trim());
                        script.createRecallNode(roomId);
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    private static void parseRoomMob(String line, BasicZoneScript.Room room) {
        // Example: - MobID: 200, Percent: 50
        try {
            if (!line.startsWith("-")) return;
            line = line.substring(1).trim();
            int mobId = 0, percent = 100;
            String[] parts = line.split(",");
            for (String part : parts) {
                part = part.trim();
                if (part.startsWith("MobID:")) mobId = Integer.parseInt(part.substring(6).trim());
                if (part.startsWith("Percent:")) percent = Integer.parseInt(part.substring(8).trim());
            }
            BasicZoneScript.Mob mob = new BasicZoneScript.Mob();
            mob.mobId = mobId;
            mob.percent = percent;
            mob.equipment = new ArrayList<>();
            mob.inventory = new ArrayList<>();
            room.mobs.add(mob);
        } catch (Exception ignored) {}
    }

    private static void parseRoomObject(String line, BasicZoneScript.Room room) {
        // Example: - ObjectID: 600, Percent: 40
        try {
            if (!line.startsWith("-")) return;
            line = line.substring(1).trim();
            int objId = 0, percent = 100;
            String[] parts = line.split(",");
            for (String part : parts) {
                part = part.trim();
                if (part.startsWith("ObjectID:")) objId = Integer.parseInt(part.substring(9).trim());
                if (part.startsWith("Percent:")) percent = Integer.parseInt(part.substring(8).trim());
            }
            BasicZoneScript.ZoneObject obj = new BasicZoneScript.ZoneObject();
            obj.objectId = objId;
            obj.percent = percent;
            obj.contains = new ArrayList<>();
            room.objects.add(obj);
        } catch (Exception ignored) {}
    }

    private static void parseRoomDoor(String line, BasicZoneScript.Room room) {
        // Example: - Direction: NORTH, Open: false, Locked: true, Remote: false
        try {
            if (!line.startsWith("-")) return;
            line = line.substring(1).trim();
            BasicZoneScript.Door door = new BasicZoneScript.Door();
            String[] parts = line.split(",");
            for (String part : parts) {
                part = part.trim();
                if (part.startsWith("Direction:")) door.direction = part.substring(10).trim();
                else if (part.startsWith("Open:")) door.open = Boolean.parseBoolean(part.substring(5).trim());
                else if (part.startsWith("Locked:")) door.locked = Boolean.parseBoolean(part.substring(7).trim());
                else if (part.startsWith("Remote:")) door.remote = Boolean.parseBoolean(part.substring(7).trim());
            }
            room.doors.add(door);
        } catch (Exception ignored) {}
    }

    private static void parseRoomTrigger(String line, BasicZoneScript.Room room) {
        // Example: - Type: ON_ENTER, Chance: 100, Action: SAY, Detail: "Message"
        try {
            if (!line.startsWith("-")) return;
            line = line.substring(1).trim();
            BasicZoneScript.Trigger trigger = new BasicZoneScript.Trigger();
            trigger.player = false;
            trigger.ticks = 0;

            String[] parts = line.split(",");
            for (String part : parts) {
                part = part.trim();
                if (part.startsWith("Type:")) trigger.type = BasicZoneScript.TriggerType.valueOf(part.substring(5).trim());
                else if (part.startsWith("Chance:")) trigger.chance = Integer.parseInt(part.substring(7).trim());
                else if (part.startsWith("Action:")) trigger.actionType = ZoneAction.valueOf(part.substring(7).trim());
                else if (part.startsWith("Detail:")) trigger.actionDetail = part.substring(7).trim().replaceAll("^\"|\"$", "");
                else if (part.startsWith("TextMatch:")) trigger.textMatch = part.substring(10).trim();
                else if (part.startsWith("ObjectType:")) trigger.objectType = part.substring(11).trim();
                else if (part.startsWith("MobID:")) trigger.mobId = Integer.parseInt(part.substring(6).trim());
                else if (part.startsWith("Player:")) trigger.player = Boolean.parseBoolean(part.substring(7).trim());
                else if (part.startsWith("Ticks:")) trigger.ticks = Integer.parseInt(part.substring(6).trim());
            }
            room.triggers.add(trigger);
        } catch (Exception ignored) {}
    }
}
