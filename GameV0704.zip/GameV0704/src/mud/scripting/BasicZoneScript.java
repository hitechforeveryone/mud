package mud.scripting;

import mud.core.Zone;
import mud.scripting.ZoneAction;
import mud.scripting.DoorState;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BasicZoneScript implements ZoneScript {
	
	protected Zone zone;
	private final int zoneId;
	
	 private final Map<Integer, Map<Integer, Double>> roomMobChances = new HashMap<>(); // roomId -> mobId -> chance
	    private final Map<Integer, Map<Integer, Double>> roomObjectChances = new HashMap<>(); // roomId -> objectId -> chance
	    private final Map<Integer, Map<String, DoorState>> doorStates = new HashMap<>();
	    private final Set<Integer> recallNodes = new HashSet<>();
	    private final Map<Integer, Map<Integer, List<Integer>>> nestedObjects = new HashMap<>();

	    
	    
	    
    public BasicZoneScript(Zone zone, int zoneId) {
        this.zoneId = zoneId;
		this.zone = zone;
    }
    
    @Override
    public int getZoneId() {
    	return zoneId; // Default Zone ID for new scripts
    }

  //  @Override
  //  public List<RecallNode> getRecallNodes() {
  //      return Collections.emptyList(); // No default recall nodes
  //  }

    @Override
    public List<Room> getRooms() {
        return Collections.emptyList(); // No default rooms
    }

    @Override
    public void apply(Zone zone) {
        // No default implementation; override in actual zone scripts
    }

    @Override
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("ZoneScript for Zone ID: ").append(getZoneId()).append("\n\n");

        // ---------------- Recall Nodes ----------------
        List<RecallNode> recalls = getRecallNodes();
        if (recalls != null && !recalls.isEmpty()) {
            sb.append("Recall Nodes:\n");
            for (RecallNode node : recalls) {
                sb.append("  RoomID: ").append(node.roomId)
                  .append(", Description: ").append(node.description).append("\n");
            }
            sb.append("\n");
        }

        // ---------------- Rooms ----------------
        List<Room> rooms = getRooms();
        if (rooms != null && !rooms.isEmpty()) {
            sb.append("Rooms:\n");
            for (Room room : rooms) {
                sb.append("  RoomID: ").append(room.roomId).append("\n");

                // Mobs
                if (room.mobs != null && !room.mobs.isEmpty()) {
                    sb.append("    Mobs:\n");
                    for (Mob mob : room.mobs) {
                        sb.append("      MobID: ").append(mob.mobId)
                          .append(", Percent: ").append(mob.percent).append("%\n");

                        if (mob.equipment != null && !mob.equipment.isEmpty()) {
                            sb.append("        Equipment:\n");
                            for (ZoneObject eq : mob.equipment) {
                                sb.append("          ObjectID: ").append(eq.objectId)
                                  .append(", Percent: ").append(eq.percent).append("%\n");
                            }
                        }

                        if (mob.inventory != null && !mob.inventory.isEmpty()) {
                            sb.append("        Inventory:\n");
                            for (ZoneObject item : mob.inventory) {
                                sb.append("          ObjectID: ").append(item.objectId)
                                  .append(", Percent: ").append(item.percent).append("%\n");
                            }
                        }
                    }
                }

                // Objects
                if (room.objects != null && !room.objects.isEmpty()) {
                    sb.append("    Objects:\n");
                    for (ZoneObject obj : room.objects) {
                        sb.append("      ObjectID: ").append(obj.objectId)
                          .append(", Percent: ").append(obj.percent).append("%\n");

                        if (obj.contains != null && !obj.contains.isEmpty()) {
                            sb.append("        Contains:\n");
                            for (ZoneObject inner : obj.contains) {
                                sb.append("          ObjectID: ").append(inner.objectId)
                                  .append(", Percent: ").append(inner.percent).append("%\n");
                            }
                        }
                    }
                }

                // Doors
                if (room.doors != null && !room.doors.isEmpty()) {
                    sb.append("    Doors:\n");
                    for (Door door : room.doors) {
                        sb.append("      Direction: ").append(door.direction)
                          .append(", Open: ").append(door.open)
                          .append(", Locked: ").append(door.locked)
                          .append(", Remote: ").append(door.remote).append("\n");
                    }
                }

                // Triggers
                if (room.triggers != null && !room.triggers.isEmpty()) {
                    sb.append("    Triggers:\n");
                    for (Trigger trigger : room.triggers) {
                        sb.append("      Type: ").append(trigger.type)
                          .append(", Chance: ").append(trigger.chance)
                          .append("%, Action: ").append(trigger.actionType)
                          .append(", Detail: ").append(trigger.actionDetail).append("\n");

                        if (trigger.textMatch != null) {
                            sb.append("        TextMatch: ").append(trigger.textMatch).append("\n");
                        }
                        if (trigger.objectType != null) {
                            sb.append("        ObjectType: ").append(trigger.objectType).append("\n");
                        }
                        if (trigger.mobId > 0) {
                            sb.append("        MobID: ").append(trigger.mobId).append("\n");
                        }
                        sb.append("        Player: ").append(trigger.player)
                          .append(", Ticks: ").append(trigger.ticks).append("\n");
                    }
                }

                sb.append("\n"); // Blank line between rooms
            }
        }

        return sb.toString();
    }



    // ---------------- Optional helper constructors ----------------

    protected Room createRoom(int roomId) {
        Room room = new Room();
        room.roomId = roomId;
        room.mobs = Collections.emptyList();
        room.objects = Collections.emptyList();
        room.doors = Collections.emptyList();
        room.triggers = Collections.emptyList();
        return room;
    }

    protected Mob createMob(int mobId, int percent) {
        Mob mob = new Mob();
        mob.mobId = mobId;
        mob.percent = percent;
        mob.equipment = Collections.emptyList();
        mob.inventory = Collections.emptyList();
        return mob;
    }

    protected ZoneObject createObject(int objectId, int percent, List<ZoneObject> contains) {
        ZoneObject obj = new ZoneObject();
        obj.objectId = objectId;
        obj.percent = percent;
        obj.contains = contains != null ? contains : Collections.emptyList();
        return obj;
    }

    protected Door createDoor(String direction, boolean open, boolean locked, boolean remote) {
        Door door = new Door();
        door.direction = direction;
        door.open = open;
        door.locked = locked;
        door.remote = remote;
        return door;
    }

    protected Trigger createTrigger(TriggerType type, int chance, ZoneAction actionType, String actionDetail) {
        Trigger trigger = new Trigger();
        trigger.type = type;
        trigger.chance = chance;
        trigger.actionType = actionType;
        trigger.actionDetail = actionDetail;
        return trigger;
    }

    public RecallNode createRecallNode(int roomId) {
        RecallNode node = new RecallNode();
        node.roomId = roomId;
//        node.description = description;
        return node;
    }
    
    // New helper: add mob by ID and chance (0-1)
    public void addMobToRoom(int roomId, int mobId, double chance) {
        roomMobChances.computeIfAbsent(roomId, k -> new HashMap<>()).put(mobId, chance);
    }

    // New helper: add object by ID and chance (0-1)
    public void addObjectToRoom(int roomId, int objectId, double chance) {
        roomObjectChances.computeIfAbsent(roomId, k -> new HashMap<>()).put(objectId, chance);
    }

    @Override
    public void setDoorState(int roomId, String direction, DoorState state) {
        doorStates.computeIfAbsent(roomId, k -> new HashMap<>()).put(direction, state);
    }

    public void addObjectInsideObject(int roomId, int containerId, int innerId) {
        nestedObjects.computeIfAbsent(roomId, k -> new HashMap<>())
                     .computeIfAbsent(containerId, k -> new ArrayList<>())
                     .add(innerId);
    }
    
    public Map<Integer, Map<String, DoorState>> getDoorStates() {
        return doorStates;
    }

    @Override
    public List<RecallNode> getRecallNodes() {
        List<RecallNode> list = new ArrayList<>();
        for (int roomId : recallNodes) {
            RecallNode node = new RecallNode();
            node.roomId = roomId;
            list.add(node);
        }
        return list;
    }

    public void addRecallNode(int roomId) {
        recallNodes.add(roomId);
    }

    public Map<Integer, Double> getMobSpawnChances() {
        Map<Integer, Double> combined = new HashMap<>();
        roomMobChances.values().forEach(map -> map.forEach((k,v) -> combined.put(k, v)));
        return combined;
    }

    public Map<Integer, Double> getObjectSpawnChances() {
        Map<Integer, Double> combined = new HashMap<>();
        roomObjectChances.values().forEach(map -> map.forEach((k,v) -> combined.put(k, v)));
        return combined;
    }
    
    
} // end
