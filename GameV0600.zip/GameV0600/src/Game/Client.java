package Game;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client {
    private Socket socket;
    private BufferedReader reader;
    private BufferedWriter writer;
    private String username;
    private static final int PORT = 3030;
    private static final String HOST = "localhost";
    private static final int MAX_RETRIES = 5;
    private static final int RETRY_DELAY_MS = 3000;

    public Client(String username) {
        this.username = username;
        connectToServerWithRetries();
    }

    private void connectToServerWithRetries() {
        int attempt = 0;
        while (attempt < MAX_RETRIES) {
            try {
                this.socket = new Socket(HOST, PORT);
                this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.println("Connected to server on attempt " + (attempt + 1));
                return;
            } catch (IOException e) {
                attempt++;
                System.err.println("Connection failed (attempt " + attempt + "). Retrying in 3 seconds...");
                try {
                    Thread.sleep(RETRY_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        System.err.println("Failed to connect to the server after " + MAX_RETRIES + " attempts.");
        System.exit(1);
    }

    public void sendMessage() {
        try (Scanner scanner = new Scanner(System.in)) {
            writer.write(username);
            writer.newLine();
            writer.flush();

            while (socket.isConnected()) {
                String message = scanner.nextLine();
                if (message.startsWith("/")) {
                    sendCommand(message);
                } else {
                    sendToServer(username + ": " + message);
                }
            }
        } catch (IOException e) {
            System.err.println("Connection lost. Attempting to reconnect...");
            reconnect();
            sendMessage();
        }
    }

    private void sendCommand(String command) throws IOException {
        sendToServer("/command " + command);
        System.out.println("Sent command to server: " + command);
    }

    private void sendToServer(String message) throws IOException {
        writer.write(message);
        writer.newLine();
        writer.flush();
    }

    public void listenForMessages() {
        new Thread(() -> {
            try {
                String message;
                while ((message = reader.readLine()) != null) {
                    System.out.println(message);
                }
            } catch (IOException e) {
                System.err.println("Disconnected from server. Attempting to reconnect...");
                reconnect();
                listenForMessages();
            }
        }).start();
    }

    private void reconnect() {
        closeResources();
        connectToServerWithRetries();
        try {
            writer.write(username);
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            System.err.println("Reconnection failed during handshake.");
            System.exit(1);
        }
    }

    private void closeResources() {
        try {
            if (reader != null) reader.close();
            if (writer != null) writer.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("resource")
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        Client client = new Client(username);
        client.listenForMessages();
        client.sendMessage();
    }
}
