package Game;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class Server {
    private ServerSocket serverSocket;
    private final static int PORT = 3030;
    static final ConcurrentHashMap<String, ClientHandler> clients = new ConcurrentHashMap<>();
    static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public Server(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    } // end Server

    public void startServer() {
        try {
            while (!serverSocket.isClosed()) {
                Socket socket = serverSocket.accept();
                System.out.println("A new client is attempting to connect...");
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                String username = input.readLine();

                if (clients.containsKey(username)) {
                    System.out.println("Client " + username + " reconnected.");
                    clients.get(username).reconnect(socket, input, output);
                } else {
                    System.out.println("New client connected: " + username);
                    ClientHandler clientHandler = new ClientHandler(username, socket, input, output);
                    clients.put(username, clientHandler);
                    new Thread(clientHandler).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end startServer

    public void closeServerSocket() {
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end closeServerSocket

    public static void main(String[] args) throws IOException {
    	System.out.println("Starting the server!");
        ServerSocket serverSocket = new ServerSocket(PORT);
        Server server = new Server(serverSocket);
        Runtime.getRuntime().addShutdownHook(new Thread(){
            public void run() {
                try {
                    serverSocket.close();
                    scheduler.shutdownNow();
                    System.out.println("The server is shut down!");
                } catch (IOException e) { /* failed */ }
            }
        });
        server.startServer();
    } // end main
    
} // end Server

class ClientHandler implements Runnable {
    private String username;
    private Socket socket;
    private BufferedReader input;
    private PrintWriter output;
    private ScheduledFuture<?> disconnectTask;
    private boolean active = true;

    public ClientHandler(String username, Socket socket, BufferedReader input, PrintWriter output) {
        this.username = username;
        this.socket = socket;
        this.input = input;
        this.output = output;

    }

    public synchronized void reconnect(Socket newSocket, BufferedReader newInput, PrintWriter newOutput) {
        cancelDisconnectTask();
        try {
            if (this.socket != null) this.socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.socket = newSocket;
        this.input = newInput;
        this.output = newOutput;
        this.active = true;
        new Thread(this).start();
    }

    @Override
    public void run() {
        String message;
        try {
            while (socket.isConnected() && (message = input.readLine()) != null) {
                if (message.startsWith("/command")) {
                    handleCommand(message, username);
                } else {
                    System.out.println("Received from " + username + ": " + message);
                    output.println(username + ": " + message);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scheduleSocketClosure();
        }
    } // end run

    private void scheduleSocketClosure() {
        this.active = false;
        disconnectTask = Server.scheduler.schedule(() -> {
            if (!active) {
                System.out.println("Closing inactive client: " + username);
                Server.clients.remove(username);
                closeEverything(socket, input, output);
            }
        }, 10, TimeUnit.MINUTES);
    }

    private void cancelDisconnectTask() {
        if (disconnectTask != null && !disconnectTask.isCancelled()) {
            disconnectTask.cancel(true);
        }
    }
    

    private void handleCommand(String command, String username) throws Exception {
    	// PUT YOUR COMMANDS IN HERE!
        if (command.contains("/list")) {
            output.println("Server: List of players: " + String.join(", ", Server.clients.keySet()));
        } 
        else if (command.contains("/startgame")) {
            output.println("Server: Game has started!");
            
            engine.loginSys();


            output.flush();  // Ensure everything is sent immediately
        }
        else if (command.contains("/quit")) {
            output.println("Closing connection to server. Goodbye.");
            closeEverything(socket, input, output);
        }
        else {
            output.println("Server: Unknown command.");
        }
    } // end handleCommand

    
    
    private void closeEverything(Socket socket, BufferedReader input, PrintWriter output) {
        try {
            if (input != null) {
                input.close();
            }
            if (output != null) {
                output.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end closeEverything
} // end ClientHandler
