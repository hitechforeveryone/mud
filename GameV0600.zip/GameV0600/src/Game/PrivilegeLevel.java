package Game;

public enum PrivilegeLevel {
    PLAYER,
    MODERATOR,
    ADMIN
}
