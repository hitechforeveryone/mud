package Game;

public class inventory {
	int pmobid= 0; //0
	String pmobname= "mobname";; //1
	int pmobplat= 0; //2
	int pmobgold= 0; //3
	int pmobsilver= 0; //4
	int pmobcopper= 0; //5
	int pmobLHPot= 0; //6
	int pmobLMPot= 0; //7
	int pmobHPot= 0; //8
	int pmobMPot= 0; //9
	int pmobGHPot= 0; //10
	int pmobGMPot= 0; //11
	int pmobMHPot= 0; //12
	int pmobMMPot= 0; //13
	String blank0= "unused"; //14
	int pmobInv0= 0; //15
	int pmobInv1= 0; //16
	int pmobInv2= 0; //17
	int pmobInv3= 0; //18
	int pmobInv4= 0; //19
	int pmobInv5= 0; //20
	int pmobInv6= 0; //21
	int pmobInv7= 0; //22
	int pmobInv8= 0; //23
	int pmobInv9= 0; //24
	int pmobInv10= 0; //25
	int pmobInv11= 0; //26
	int pmobInv12= 0; //27
	int pmobInv13= 0; //28
	int pmobInv14= 0; //29
	int pmobInv15= 0; //30
	int pmobInv16= 0; //31
	int pmobInv17= 0; //32
	int pmobInv18= 0; //33
	int pmobInv19= 0; //34
	int pmobInv20= 0; //35
	int pmobInv21= 0; //36
	int pmobInv22= 0; //37
	int pmobInv23= 0; //38
	int pmobInv24= 0; //39
	int pmobInv25= 0; //40
	int pmobInv26= 0; //41
	int pmobInv27= 0; //42
	int pmobInv28= 0; //43
	int pmobInv29= 0; //44
	int blank1= 0; //45
	int blank2= 0; //46
	int blank3= 0; //47
	int blank4= 0; //48
	String blank5 = "unused"; //49


	public String getBlank0() {
		return blank0;
	}

	public int getBlank1() {
		return blank1;
	}

	public int getBlank2() {
		return blank2;
	}

	public int getBlank3() {
		return blank3;
	}

	public int getBlank4() {
		return blank4;
	}

	public String getBlank5() {
		return blank5;
	}

	public int getPmobcopper() {
		return pmobcopper;
	}

	public int getPmobGHPot() {
		return pmobGHPot;
	}

	public int getPmobGMPot() {
		return pmobGMPot;
	}

	public int getPmobgold() {
		return pmobgold;
	}

	public int getPmobHPot() {
		return pmobHPot;
	}

	public int getPmobid() {
		return pmobid;
	}

	public int getPmobInv0() {
		return pmobInv0;
	}

	public int getPmobInv1() {
		return pmobInv1;
	}

	public int getPmobInv10() {
		return pmobInv10;
	}

	public int getPmobInv11() {
		return pmobInv11;
	}

	public int getPmobInv12() {
		return pmobInv12;
	}

	public int getPmobInv13() {
		return pmobInv13;
	}

	public int getPmobInv14() {
		return pmobInv14;
	}

	public int getPmobInv15() {
		return pmobInv15;
	}

	public int getPmobInv16() {
		return pmobInv16;
	}

	public int getPmobInv17() {
		return pmobInv17;
	}

	public int getPmobInv18() {
		return pmobInv18;
	}

	public int getPmobInv19() {
		return pmobInv19;
	}

	public int getPmobInv2() {
		return pmobInv2;
	}

	public int getPmobInv20() {
		return pmobInv20;
	}

	public int getPmobInv21() {
		return pmobInv21;
	}

	public int getPmobInv22() {
		return pmobInv22;
	}

	public int getPmobInv23() {
		return pmobInv23;
	}

	public int getPmobInv24() {
		return pmobInv24;
	}

	public int getPmobInv25() {
		return pmobInv25;
	}

	public int getPmobInv26() {
		return pmobInv26;
	}

	public int getPmobInv27() {
		return pmobInv27;
	}

	public int getPmobInv28() {
		return pmobInv28;
	}

	public int getPmobInv29() {
		return pmobInv29;
	}

	public int getPmobInv3() {
		return pmobInv3;
	}

	public int getPmobInv4() {
		return pmobInv4;
	}

	public int getPmobInv5() {
		return pmobInv5;
	}

	public int getPmobInv6() {
		return pmobInv6;
	}

	public int getPmobInv7() {
		return pmobInv7;
	}

	public int getPmobInv8() {
		return pmobInv8;
	}

	public int getPmobInv9() {
		return pmobInv9;
	}

	public int getPmobLHPot() {
		return pmobLHPot;
	}

	public int getPmobLMPot() {
		return pmobLMPot;
	}

	public int getPmobMHPot() {
		return pmobMHPot;
	}

	public int getPmobMMPot() {
		return pmobMMPot;
	}

	public int getPmobMPot() {
		return pmobMPot;
	}

	public String getPmobname() {
		return pmobname;
	}

	public int getPmobplat() {
		return pmobplat;
	}

	public int getPmobsilver() {
		return pmobsilver;
	}

	public void setBlank0(String blank0) {
		this.blank0 = blank0;
	}

	public void setBlank1(int i) {
		this.blank1 = i;
	}

	public void setBlank2(int blank2) {
		this.blank2 = blank2;
	}

	public void setBlank3(int blank3) {
		this.blank3 = blank3;
	}

	public void setBlank4(int blank4) {
		this.blank4 = blank4;
	}

	public void setBlank5(String blank5) {
		this.blank5 = blank5;
	}

	public void setPmobcopper(int pmobcopper) {
		this.pmobcopper = pmobcopper;
	}

	public void setPmobGHPot(int pmobGHPot) {
		this.pmobGHPot = pmobGHPot;
	}

	public void setPmobGMPot(int pmobGMPot) {
		this.pmobGMPot = pmobGMPot;
	}

	public void setPmobgold(int pmobgold) {
		this.pmobgold = pmobgold;
	}

	public void setPmobHPot(int pmobHPot) {
		this.pmobHPot = pmobHPot;
	}

	public void setPmobid(int pmobid) {
		this.pmobid = pmobid;
	}

	public void setPmobInv0(int pmobInv0) {
		this.pmobInv0 = pmobInv0;
	}

	public void setPmobInv1(int pmobInv1) {
		this.pmobInv1 = pmobInv1;
	}

	public void setPmobInv10(int pmobInv10) {
		this.pmobInv10 = pmobInv10;
	}

	public void setPmobInv11(int pmobInv11) {
		this.pmobInv11 = pmobInv11;
	}

	public void setPmobInv12(int pmobInv12) {
		this.pmobInv12 = pmobInv12;
	}

	public void setPmobInv13(int pmobInv13) {
		this.pmobInv13 = pmobInv13;
	}

	public void setPmobInv14(int pmobInv14) {
		this.pmobInv14 = pmobInv14;
	}

	public void setPmobInv15(int pmobInv15) {
		this.pmobInv15 = pmobInv15;
	}

	public void setPmobInv16(int pmobInv16) {
		this.pmobInv16 = pmobInv16;
	}

	public void setPmobInv17(int pmobInv17) {
		this.pmobInv17 = pmobInv17;
	}

	public void setPmobInv18(int pmobInv18) {
		this.pmobInv18 = pmobInv18;
	}

	public void setPmobInv19(int pmobInv19) {
		this.pmobInv19 = pmobInv19;
	}

	public void setPmobInv2(int pmobInv2) {
		this.pmobInv2 = pmobInv2;
	}

	public void setPmobInv20(int pmobInv20) {
		this.pmobInv20 = pmobInv20;
	}

	public void setPmobInv21(int pmobInv21) {
		this.pmobInv21 = pmobInv21;
	}

	public void setPmobInv22(int pmobInv22) {
		this.pmobInv22 = pmobInv22;
	}

	public void setPmobInv23(int pmobInv23) {
		this.pmobInv23 = pmobInv23;
	}

	public void setPmobInv24(int pmobInv24) {
		this.pmobInv24 = pmobInv24;
	}

	public void setPmobInv25(int pmobInv25) {
		this.pmobInv25 = pmobInv25;
	}

	public void setPmobInv26(int pmobInv26) {
		this.pmobInv26 = pmobInv26;
	}

	public void setPmobInv27(int pmobInv27) {
		this.pmobInv27 = pmobInv27;
	}

	public void setPmobInv28(int pmobInv28) {
		this.pmobInv28 = pmobInv28;
	}

	public void setPmobInv29(int pmobInv29) {
		this.pmobInv29 = pmobInv29;
	}

	public void setPmobInv3(int pmobInv3) {
		this.pmobInv3 = pmobInv3;
	}

	public void setPmobInv4(int pmobInv4) {
		this.pmobInv4 = pmobInv4;
	}

	public void setPmobInv5(int pmobInv5) {
		this.pmobInv5 = pmobInv5;
	}

	public void setPmobInv6(int pmobInv6) {
		this.pmobInv6 = pmobInv6;
	}

	public void setPmobInv7(int pmobInv7) {
		this.pmobInv7 = pmobInv7;
	}

	public void setPmobInv8(int pmobInv8) {
		this.pmobInv8 = pmobInv8;
	}

	public void setPmobInv9(int pmobInv9) {
		this.pmobInv9 = pmobInv9;
	}

	public void setPmobLHPot(int pmobLHPot) {
		this.pmobLHPot = pmobLHPot;
	}

	public void setPmobLMPot(int pmobLMPot) {
		this.pmobLMPot = pmobLMPot;
	}

	public void setPmobMHPot(int pmobMHPot) {
		this.pmobMHPot = pmobMHPot;
	}

	public void setPmobMMPot(int pmobMMPot) {
		this.pmobMMPot = pmobMMPot;
	}

	public void setPmobMPot(int pmobMPot) {
		this.pmobMPot = pmobMPot;
	}

	public void setPmobname(String pmobname) {
		this.pmobname = pmobname;
	}

	public void setPmobplat(int pmobplat) {
		this.pmobplat = pmobplat;
	}

	public void setPmobsilver(int pmobsilver) {
		this.pmobsilver = pmobsilver;
	}

	public void resetInventory() {
		pmobid = 0; //0
		pmobname = "mobname"; //1
		pmobplat = 0; //2
		pmobgold = 0; //3
		pmobsilver = 0; //4
		pmobcopper= 0; //5
		pmobLHPot= 0; //6
		pmobLMPot= 0; //7
		pmobHPot= 0; //8
		pmobMPot= 0; //9
		pmobGHPot= 0; //10
		pmobGMPot= 0; //11
		pmobMHPot= 0; //12
		pmobMMPot= 0; //13
		blank0= "unused"; //14
		pmobInv0= 0; //15
		pmobInv1= 0; //16
		pmobInv2= 0; //17
		pmobInv3= 0; //18
		pmobInv4= 0; //19
		pmobInv5= 0; //20
		pmobInv6= 0; //21
		pmobInv7= 0; //22
		pmobInv8= 0; //23
		pmobInv9= 0; //24
		pmobInv10= 0; //25
		pmobInv11= 0; //26
		pmobInv12= 0; //27
		pmobInv13= 0; //28
		pmobInv14= 0; //29
		pmobInv15= 0; //30
		pmobInv16= 0; //31
		pmobInv17= 0; //32
		pmobInv18= 0; //33
		pmobInv19= 0; //34
		pmobInv20= 0; //35
		pmobInv21= 0; //36
		pmobInv22= 0; //37
		pmobInv23= 0; //38
		pmobInv24= 0; //39
		pmobInv25= 0; //40
		pmobInv26= 0; //41
		pmobInv27= 0; //42
		pmobInv28= 0; //43
		pmobInv29= 0; //44
		blank1= 0; //45
		blank2= 0; //46
		blank3= 0; //47
		blank4= 0; //48
		blank5= "unused"; //49
	}

	public void returnInventory() {
		System.out.println("Done from inventory.returnInvetory()");
		System.out.println("---------------------------------------------------");
		System.out.println("Coins: " + pmobplat + "p, " + pmobgold + "g, " + pmobsilver + "s, " + pmobcopper + "c");
		System.out.println("Lesser Healing Pot: " + pmobLHPot + "  Lesser Mana Pot: " + pmobLHPot + "  Healing Pot: "  + pmobHPot + 
				"  Mana Pot: " + pmobMPot + "  Greater H Pot: " + pmobGHPot + "  Greater M Pot: " + pmobGMPot + "  Major H Pot: " + 
				pmobMHPot +	"  Major M Pot: " + pmobMMPot);
		System.out.println("---------------------------------------------------");
		if (pmobInv0 == 0) { System.out.println("Inv Slot0: test"); }
		else {	System.out.println("Inv Slot0: " + pmobInv0); }
		if (pmobInv1 == 0) { System.out.println("Inv Slot1: none"); }
		else {	System.out.println("Inv Slot1: " + pmobInv1); }
		if ( pmobInv2 == 0) { System.out.println("Inv Slot2: none"); }
		else {	System.out.println("Inv Slot2: " + pmobInv2); }
		if (pmobInv3 == 0) { System.out.println("Inv Slot3: none"); }
		else {	System.out.println("Inv Slot3: " + pmobInv3); }
		if (pmobInv4 == 0) { System.out.println("Inv Slot4: none"); }
		else {	System.out.println("Inv Slot4: " + pmobInv4); }
		if (pmobInv5 == 0) { System.out.println("Inv Slot5: none"); }
		else {	System.out.println("Inv Slot5: " + pmobInv5); }
		if (pmobInv6 == 0) { System.out.println("Inv Slot6: none"); }
		else {	System.out.println("Inv Slot6: " + pmobInv6); }
		if (pmobInv7 == 0) { System.out.println("Inv Slot7: none"); }
		else {	System.out.println("Inv Slot7: " + pmobInv7); }
		if (pmobInv8 == 0) { System.out.println("Inv Slot8: none"); }
		else {	System.out.println("Inv Slot8: " + pmobInv8); }
		if (pmobInv9 == 0) { System.out.println("Inv Slot0: none"); }
		else {	System.out.println("Inv Slot9: " + pmobInv9); }
		if (pmobInv10 == 0) { System.out.println("Inv Slot10: none"); }
		else {	System.out.println("Inv Slot10: " + pmobInv10); }

	} // end returnInventory()

	public String toString() {
		return pmobid + "|" + pmobname + "|" + pmobplat + "|" + pmobgold + "|" + pmobsilver + "|" + pmobcopper + "|"
				+ pmobLHPot + "|" + pmobLMPot + "|" + pmobHPot + "|" + pmobMPot + "|" + pmobGHPot + "|" + pmobGMPot
				+ "|" + pmobMHPot + "|" + pmobMMPot + "|" + blank0 + "|" + pmobInv0 + "|" + pmobInv1 + "|" + pmobInv2
				+ "|" + pmobInv3 + "|" + pmobInv4 + "|" + pmobInv5 + "|" + pmobInv6 + "|" + pmobInv7 + "|" + pmobInv8
				+ "|" + pmobInv9 + "|" + pmobInv10 + "|" + pmobInv11 + "|" + pmobInv12 + "|" + pmobInv13 + "|"
				+ pmobInv14 + "|" + pmobInv15 + "|" + pmobInv16 + "|" + pmobInv17 + "|" + pmobInv18 + "|" + pmobInv19
				+ "|" + pmobInv20 + "|" + pmobInv21 + "|" + pmobInv22 + "|" + pmobInv23 + "|" + pmobInv24 + "|"
				+ pmobInv25 + "|" + pmobInv26 + "|" + pmobInv27 + "|" + pmobInv28 + "|" + pmobInv29 + "|" + blank1 + "|"
				+ blank2 + "|" + blank3 + "|" + blank4 + "|" + blank5;
	}

}
