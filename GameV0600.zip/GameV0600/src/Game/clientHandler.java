// FOR FUTURE USE
package Game;

import java.io.*;
import java.net.*;
import java.util.*;

public class clientHandler implements Runnable {
	// a clienthandler for testing multi-user on game
	public static ArrayList<clientHandler> clientHandlers = new ArrayList<>();
	private Socket socket;
	private BufferedReader bufferedReader;
	private BufferedWriter bufferedWriter;
	private String clientUserName;
	
	
	public  clientHandler(Socket socket) {
		try {
			this.socket = socket;
			this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			this.clientUserName = bufferedReader.readLine(); // read line from client
			clientHandlers.add(this);
			broadcastMessage("SERVER: " + clientUserName + " has entered the server.");
		} catch (IOException e) {
			closeEverything(socket, bufferedReader, bufferedWriter);
		}
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		String messageFromClient;
		
		while (socket.isConnected()) {
			try {
				messageFromClient = bufferedReader.readLine();
				broadcastMessage(messageFromClient);
				} catch (IOException e) {
					closeEverything(socket, bufferedReader, bufferedWriter);
					break;
				}
			
		}
		
	} // end run()
	
	
	public void broadcastMessage(String messageToSend) {
		for (clientHandler chandler : clientHandlers) {
			try {
			if (!chandler.clientUserName.equals(clientUserName)) {
				chandler.bufferedWriter.write(messageToSend);
				chandler.bufferedWriter.newLine();
				chandler.bufferedWriter.flush();
			}
		} catch (IOException e) {
			closeEverything(socket, bufferedReader, bufferedWriter);
		}
	}
	} // end broadcastMessage
	
	
	public void removeClientHandler() {
		clientHandlers.remove(this);
		broadcastMessage("SERVER: " + clientUserName + " has left the server.");
	} // end removeClientHandler

	
	public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
		removeClientHandler();
		try {
			if (bufferedReader != null) {
				bufferedReader.close();
			}
			if (bufferedWriter != null) {
				bufferedWriter.close();
			}
			if (socket != null) {
				socket.close();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	} // end closeEverything
}
