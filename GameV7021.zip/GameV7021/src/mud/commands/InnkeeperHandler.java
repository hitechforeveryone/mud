package mud.commands;

import java.util.*;

import mud.Shop.MailManager;
import mud.core.*;
import mud.core.enums.*;
import mud.server.BackupHandler;
import mud.system.PlayerLoader;

public class InnkeeperHandler {

	public static String handleRent(Player player) {
		if (player == null || player.getCurrentRoom() == null) {
			return "You are not in a valid location.";
		}

		Room room = player.getCurrentRoom();



		// Check for INNKEEPER mob
		boolean hasInnkeeper = room.getMobs().stream()
				.anyMatch(mob -> mob.hasBehavior(MobBehaviorFlag.INNKEEPER));

		if (!hasInnkeeper) {
			return "There’s no one here to rent you a room.";
		}

		// ✅ Passed all checks; proceed to rent
		player.setRentWorld(player.getCurrentWorld());
		player.setRentZone(player.getCurrentZone());
		player.setRentRoom(player.getCurrentRoom());

		// Save player
		PlayerLoader.save(player);
		BackupHandler.handleBackup(player, player.getName()); // backup  player

		// Remove player from current room
		room.removeMob(player);
		player.setCurrentRoom(null);
		player.setCurrentZone(null);
		player.setCurrentWorld(null);

		// Inform player
		player.sendMessage("You rent a cozy room and fall asleep. When you return, you’ll wake here rested and safe.");

		// Mark player for logout
		player.setPendingLogout(true);

		return null;
	} // end




	// Mail Stuff
	public static String handleMail(Player player, String[] tokens) {

		if (tokens.length < 2) {
			return "Usage: mail <send|list|read|delete>";
		}

		// Check for INNKEEPER mob
		Room room = player.getCurrentRoom();
		boolean hasInnkeeper = room.getMobs().stream()
				.anyMatch(mob -> mob.hasBehavior(MobBehaviorFlag.INNKEEPER));

		if (!hasInnkeeper) {
			return "There’s no one here for the mail.";
		}			

		String sub = tokens[1].toLowerCase();
		String playerName = player.getName();

		switch (sub) {


		case "take":
			if (tokens.length < 3) return "Usage: mail take <email #>";
			return handleTake(player, tokens);

		case "attach":
			if (tokens.length < 3) return "Usage: mail attach <item>";
			return handleAttach(player, tokens);

		case "clear":
			return handleClear(player);
		case "send":
			if (tokens.length < 3) {
				return "Usage: mail send <player>";
			}
			return handleSend(player, tokens);



		case "list":
			return handleList(playerName);

		case "read":
			if (tokens.length < 3) {
				return "Usage: mail read <#>";
			}
			return handleRead(playerName, tokens[2]);

		case "delete":
			if (tokens.length < 3) {
				return "Usage: mail delete <#>";
			}
			return handleDelete(playerName, tokens[2]);

		default:
			return "Unknown mail command.";
		}
	}


	private static String handleList(String playerName) {

		List<String> summary = MailManager.getMailSummary(playerName);

		if (summary.isEmpty()) {
			return "You have no mail.";
		}

		StringBuilder sb = new StringBuilder();
		sb.append("Your Mail:\n");

		for (String line : summary) {
			sb.append(line).append("\n");
		}

		return sb.toString();
	}


	private static String handleRead(String playerName, String indexStr) {
		int index;

		try {
			index = Integer.parseInt(indexStr) - 1; // convert to 0-based
		} catch (NumberFormatException e) {
			return "Invalid number.";
		}

		return MailManager.getMailContent(playerName, index);
	}


	private static String handleDelete(String playerName, String indexStr) {
		int index;

		try {
			index = Integer.parseInt(indexStr) - 1;
		} catch (NumberFormatException e) {
			return "Invalid number.";
		}

		boolean success = MailManager.deleteMail(playerName, index);

		return success ? "Mail deleted." : "Invalid mail selection.";
	}

	
	private static String handleSend(Player player, String[] tokens) {
		// mail send <recipient> subject | message
		String sender = player.getName();
		String recipient = tokens[2];

		if (!PlayerLoader.exists(recipient)) {
		    return "That recipient/player does not exist.";
		}
		
		// Rebuild the full input string
		String full = String.join(" ", tokens);

		// Split on first '|'
		int splitIndex = full.indexOf("|");
		if (splitIndex == -1) {
			return "You must separate subject and message with '|'";
		}

		String left = full.substring(0, splitIndex).trim();
		String message = full.substring(splitIndex + 1).trim();

		// Extract subject (everything after "mail send <player>")
		String[] leftParts = left.split(" ", 4);
		if (leftParts.length < 4) {
			return "You must provide a subject.";
		}

		String subject = leftParts[3];

		// Basic validation
		if (recipient.equalsIgnoreCase(sender)) {
			return "You cannot send mail to yourself.";
		}

		if (subject.isEmpty() || message.isEmpty()) {
			return "Subject and message cannot be empty.";
		}

		// Create mail
		Mail mail = MailManager.createMail(sender, recipient, subject, message);

		// attchments
		List<ObjectItem> attachments = player.getPendingMailAttachments();
		if (attachments != null && !attachments.isEmpty()) {
			for (ObjectItem obj : attachments) {
				player.getInventory().remove(obj); // REMOVE from player
				mail.addAttachment(obj);           // ADD to mail
			}

			attachments.clear(); // clear staging
		}

		// Send it
		MailManager.sendMail(sender, recipient, mail);


		return "Mail sent to " + recipient + ".";
	}
	
	
	/*

	private static String handleSend(Player player, String[] tokens) {
	//	 * possible upgraded for handleSend
	//   * breaks the command into sections
	
	
	    if (tokens.length < 3) return "Usage: mail send <recipient>";

	    String sender = player.getName();
	    String recipient = tokens[2];

	    if (recipient.equalsIgnoreCase(sender)) {
	        return "You cannot send mail to yourself.";
	    }

	    // Step 1: Ask for subject
	    player.sendMessage("Enter the subject of your mail:");
	    String subject = player.promptInput(); // your system needs to support blocking or async input
	    if (subject == null || subject.trim().isEmpty()) {
	        return "Mail cancelled: subject cannot be empty.";	        
	    }

	    // Step 2: Ask for message body (multi-line)
	    player.sendMessage("Enter the message. Type a single '.' on a line by itself to finish:");
	    StringBuilder messageBuilder = new StringBuilder();
	    while (true) {
	        String line = player.promptInput(); // read next line
	        if (line.equals(".")) break;       // end input
	        messageBuilder.append(line).append("\n");
	    }
	    String message = messageBuilder.toString().trim();
	    if (message.isEmpty()) {
	        return "Mail cancelled: message cannot be empty.";
	    }

	    // Step 3: Create mail
	    Mail mail = MailManager.createMail(sender, recipient, subject, message);

	    // Step 4: Add attachments if any
	    List<ObjectItem> attachments = player.getPendingMailAttachments();
	    if (!attachments.isEmpty()) {
	        for (ObjectItem obj : attachments) {
	            player.getInventory().remove(obj); // remove from player
	            mail.addAttachment(obj);           // add to mail
	        }
	        attachments.clear(); // clear staging
	    }

	    // Step 5: Send mail
	    MailManager.sendMail(sender, recipient, mail);

	    return "Mail successfully sent to " + recipient + ".";
	}
*/
	


	private static String handleAttach(Player player, String[] tokens) {

		if (tokens.length < 3) return "Usage: mail attach <item>";

		// Rebuild full item name from tokens[2] onward
		StringBuilder sb = new StringBuilder();
		for (int i = 2; i < tokens.length; i++) {
			sb.append(tokens[i]);
			if (i < tokens.length - 1) sb.append(" ");
		}
		String itemName = sb.toString().toLowerCase();

		// TODO
		// fall back // tokens[2] is keyword // parse keywords
		
		
		
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have anything.";

		for (ObjectItem i : inventory) {
			// check full name
			if (i != null && i.getName() != null && i.getName().toLowerCase().contains(itemName)) {
				player.getPendingMailAttachments().add(i); // add the correct object
				return i.getName() + " added to mail.";
			}
			
			// TODO
			// check vs keyword
			
		}

		return "You don't have an item matching '" + itemName + "'.";
	}


	private static String handleTake(Player player, String[] tokens) {
		if (tokens.length < 3) return "Usage: mail take <#|all>";

		String playerName = player.getName();
		List<Mail> mails = MailManager.loadMail(playerName);

		if (mails.isEmpty()) return "You have no mail.";

		
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null) {
			inventory = new ArrayList<>();
			player.setInventory(inventory);
		}

		if (tokens[2].equalsIgnoreCase("all")) {
			StringBuilder sb = new StringBuilder();
			int totalTaken = 0;

			for (Mail mail : mails) {
				List<ObjectItem> attachments = mail.getAttachments();
				if (attachments != null && !attachments.isEmpty()) {
					for (ObjectItem obj : attachments) {
						if (obj != null) {
							inventory.add(obj);
							sb.append("- ").append(obj.getName()).append("\n");
							totalTaken++;
						}
					}
					attachments.clear(); // clear attachments from this mail
				}
			}

			if (totalTaken == 0) return "There are no attachments in any of your mail.";

			// Save updated mail
			MailManager.saveMail(playerName, mails);

			return "You take all attachments from your mail:\n" + sb.toString();
		}

		// If not "all", treat as single mail index
		int index;
		try {
			index = Integer.parseInt(tokens[2]) - 1; // 0-based
		} catch (NumberFormatException e) {
			return "Invalid mail number.";
		}

		if (index < 0 || index >= mails.size()) {
			return "Invalid mail selection.";
		}

		Mail mail = mails.get(index);
		List<ObjectItem> attachments = mail.getAttachments();

		if (attachments == null || attachments.isEmpty()) {
			return "No attachments in this mail.";
		}

		StringBuilder sb = new StringBuilder();
		for (ObjectItem obj : attachments) {
			if (obj != null) {
				inventory.add(obj);
				sb.append("- ").append(obj.getName()).append("\n");
			}
		}

		// Clear attachments from the mail
		mail.getAttachments().clear();
		MailManager.saveMail(playerName, mails);

		return "You take the following items from the mail:\n" + sb.toString();
	}


	private static String handleClear(Player player) {
		player.getPendingMailAttachments().clear();
		return "Mail attachments cleared.";
	}


}
