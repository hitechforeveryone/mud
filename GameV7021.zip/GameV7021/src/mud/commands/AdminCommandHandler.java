package mud.commands;

import java.io.*;
import java.util.*;

import mud.config.*;
import mud.core.*;
import mud.core.enums.EquipSlot;
import mud.editor.*;
import mud.map.MapManager;
import mud.map.WorldMapManager;
import mud.map.ZoneMapManager;
import mud.scripting.*;
import mud.server.BackupHandler;
import mud.spell.*;
import mud.system.*;;

public class AdminCommandHandler {

	public static String handleWhere(Player player, String[] tokens) {
	    if (tokens.length < 2) {
	        return "Usage: where <mob|object>";
	    }

	    String keyword = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length)).toLowerCase();
	    StringBuilder sb = new StringBuilder();

	    List<String> mobResults = new ArrayList<>();
	    List<String> objResults = new ArrayList<>();

	    for (World world : WorldManager.getAllWorlds()) {
	        for (Zone zone : world.getZones()) {
	            for (Room room : zone.getRoomsAsList()) {

	                // ---- MOB SEARCH ----
	                for (Mob mob : room.getMobs()) {
	                    if (mob != null) {
	                        String lowerName = mob.getMobName().toLowerCase();
	                        boolean matches = lowerName.contains(keyword) || mob.hasKeyword(keyword);
	                        if (matches) {
	                            mobResults.add(formatResult(
	                                    mob.getMobName(),
	                                    "Mob",
	                                    world,
	                                    zone,
	                                    room
	                            ));
	                        }

	                        // ---- MOB INVENTORY / EQUIPMENT SEARCH ----
	                        for (ObjectItem item : mob.getInventory()) {
	                            if (item != null && (item.getName().toLowerCase().contains(keyword) || item.matchesKeyword(keyword))) {
	                                objResults.add(formatResult(
	                                        item.getName() + " (Inventory of " + mob.getMobName() + ")",
	                                        "Object",
	                                        world,
	                                        zone,
	                                        room
	                                ));
	                            }
	                        }
	                        for (ObjectItem item : mob.getEquipment().values()) {
	                            if (item != null && (item.getName().toLowerCase().contains(keyword) || item.matchesKeyword(keyword))) {
	                                objResults.add(formatResult(
	                                        item.getName() + " (Equipped by " + mob.getMobName() + ")",
	                                        "Object",
	                                        world,
	                                        zone,
	                                        room
	                                ));
	                            }
	                        }
	                    }
	                }

	                // ---- ROOM OBJECT SEARCH ----
	                for (ObjectItem obj : room.getObjects()) {
	                    if (obj != null) {
	                        String lowerName = obj.getName().toLowerCase();
	                        boolean matches = lowerName.contains(keyword) || obj.matchesKeyword(keyword);
	                        if (matches) {
	                            objResults.add(formatResult(
	                                    obj.getName(),
	                                    "Object",
	                                    world,
	                                    zone,
	                                    room
	                            ));
	                        }
	                    }
	                }
	            }
	        }
	    }

	    if (mobResults.isEmpty() && objResults.isEmpty()) {
	        return "You cannot locate anything matching \"" + keyword + "\".";
	    }

	    sb.append("Results for \"").append(keyword).append("\":\n\n");

	    if (!mobResults.isEmpty()) {
	        sb.append("[Mobs]\n");
	        mobResults.forEach(r -> sb.append(" ").append(r).append("\n"));
	        sb.append("\n");
	    }

	    if (!objResults.isEmpty()) {
	        sb.append("[Objects]\n");
	        objResults.forEach(r -> sb.append(" ").append(r).append("\n"));
	    }

	    return sb.toString().trim();
	}

	// formatResult unchanged except corrected worldId placeholder
	private static String formatResult(
	        String name,
	        String type,
	        World world,
	        Zone zone,
	        Room room
	) {
	    return String.format(
	            "%s: %s — World: %s (%s), Zone: %s (%d), Room: %s (%d)",
	            type,
	            name,
	            world.getName(),
	            String.valueOf(world.getWorldId()),
	            zone.getName(),
	            zone.getZoneId(),
	            room.getName(),
	            room.getId()
	    );
	}

	
	
	public static String handleKick(Player admin, String[] args) {
		if (args.length < 2) return "Usage: pkick <player>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		if (target == admin) return "You can't kick yourself.";
		target.sendMessage("You have been kicked by an admin.");
		target.getClientHandler().disconnect();
		return "Player " + target.getName() + " has been kicked.";
	}// end handleKick (pkick)

	public static String handleSummon(Player admin, String[] args) {
		// direct summons, not spell
		if (args.length < 2) return "Usage: summon <player>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		Room dest = admin.getCurrentRoom();
		target.getCurrentRoom().removeMob(target);
		dest.addMob(target);
		target.setCurrentRoom(dest);
		target.sendMessage("You have been summoned by an admin.");
		return "Player " + target.getName() + " summoned to your location.";
	}// end handleSummon

	public static String handleGoto(Player admin, String[] args) {
		// direct goto coords, not move N|E|S|W..
		if (args.length < 2) {
			return "Usage: goto <worldId|worldName> <zoneId> <roomId> | <mob/player name>";
		}

		if (args.length >= 4) {
			String worldIdOrName = args[1];
			int zoneId, roomId;

			try {
				zoneId = Integer.parseInt(args[2]);
				roomId = Integer.parseInt(args[3]);
			} catch (NumberFormatException e) {
				return "Zone ID and Room ID must be numbers.";
			}

			World targetWorld;
			try {
				int worldId = Integer.parseInt(worldIdOrName);
				targetWorld = WorldManager.getWorld(worldId);
			} catch (NumberFormatException e) {
				targetWorld = WorldManager.getWorldByName(worldIdOrName);
			}

			if (targetWorld == null) return "World '" + worldIdOrName + "' not found.";

			Zone targetZone = targetWorld.getZone(zoneId);
			if (targetZone == null) return "Zone " + zoneId + " not found in world " + targetWorld.getName();

			Room targetRoom = WorldManager.getRoom(targetWorld.getWorldId(), zoneId, roomId);
			if (targetRoom == null) return "Room " + roomId + " not found in Zone " + zoneId;

			// Ensure clean move
			Room currentRoom = admin.getCurrentRoom();
			if (currentRoom != null) {
				currentRoom.removeMob(admin);
			}

			// Double-check that the target room is the correct one
			System.out.println("[DEBUG] Attempting teleport to: World " + targetWorld.getWorldId() + ", Zone " + zoneId + ", Room " + roomId);
			System.out.println("[DEBUG] Resolved target room: " + targetRoom.getId() + " in Zone " + targetRoom.getZone().getZoneId() + ", World: " + targetRoom.getZone().getWorld().getWorldId());

			// Update all location fields properly
			targetRoom.addMob(admin);
			
			admin.setCurrentWorld(targetZone.getWorld());
			admin.setCurrentZone(targetZone);
			admin.setCurrentRoom(targetRoom);
			//admin.setRoom(targetRoom);  // <- Ensure setRoom also affects logical location


			targetRoom.broadcastExcept(admin.getName() + " suddenly appears in a flash of light!", admin);
			LookHandler.handleLook(admin, new String[]{"look"});

			return "You teleport to World " + targetWorld.getName() + ", Zone " + zoneId + ", Room " + roomId + ": " + targetRoom.getName();
		}

		// Fallback to mob/player name lookup
		World world = admin.getCurrentWorld();
		if (world == null) return "You are not in a world.";

		String targetName = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();

		for (Zone z : world.getZones()) {
			for (Room r : z.getRooms().values()) {
				for (Mob m : r.getMobs()) {
					if (m.getMobName().equalsIgnoreCase(targetName) || m.matchesKeyword(targetName)) {
						Room cur = admin.getCurrentRoom();
						if (cur != null) cur.removeMob(admin);
						admin.setCurrentWorld(world);
						admin.setCurrentZone(z);
						admin.setCurrentRoom(r);
						//admin.setRoom(r);
						r.addMob(admin);
						r.broadcastExcept(admin.getName() + " suddenly appears in a flash of light!", admin);
						LookHandler.handleLook(admin, new String[]{"look"});
						return "You teleport to " + m.getMobName() + "'s location in Zone " + z.getZoneId() + ", Room " + r.getId();
					}
				}
			}
		}

		return "Target '" + targetName + "' not found.";
	} // end handleGoto

	public static String handleSetLevel(Player admin, String[] args) {
		if (args.length < 3) return "Usage: setlevel <player> <level>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		try {
			int level = Integer.parseInt(args[2]);
			if (level < 1 || level > 100) return "Level must be 1–100.";
			target.setLevel(level);
			target.recalculateStats();
			
			return target.getName() + " is now level " + level + ".";
		} catch (NumberFormatException e) {
			return "Invalid level.";
		}
	}// end handleSetLevel
	
	public static String handleSetMobLevel(Player admin, String[] args) {
		if (args.length < 3) return "Usage: setmoblevel <mobId> <level>";
		
		int mobId = Integer.parseInt(args[1]);
		
		Mob target = WorldManager.getMobById(mobId, admin.getCurrentRoom());
		if (target == null) return "No such player.";
		try {
			int level = Integer.parseInt(args[2]);
			if (level < 1 || level > 100) return "Level must be 1–100.";
			target.setLevel(level);
			target.recalculateStats();
			WorldManager.saveMob(target);
			
			return target.getMobName() + " is now level " + level + ".";			
		} catch (NumberFormatException e) {
			return "Invalid level.";
		}
	}// end handleSetLevel
	

	// LIST COMMAND
	public static void handleList(Player player, String[] tokens) {
		if (tokens.length < 2) {
			player.sendMessage("List what? Options: player, world, zone, room, mob, object, spell");
			return;
		}

		String category = tokens[1].toLowerCase();

		switch (category) {

		//═══════════════════════════════════════════════
		// PLAYERS
		//═══════════════════════════════════════════════
		case "player":
		case "players": {
			player.sendMessage("🧍 Players Online:");

			List<Player> list = new ArrayList<>(WorldManager.getActivePlayers());
			list.sort(Comparator.comparingInt(Player::getId));

			for (Player p : list) {
				player.sendMessage("[" + p.getId() + "] - " + p.getName() +
						" (Level " + p.getLevel() + ")");
			}
			break;
		}

		//═══════════════════════════════════════════════
		// WORLDS
		//═══════════════════════════════════════════════
		case "world":
		case "worlds": {
			player.sendMessage("🌍 Worlds:");

			List<World> worlds = new ArrayList<>(WorldManager.getAllWorlds());
			//    worlds.sort(worlds.;

			for (World w : worlds) {
				player.sendMessage("[" + w.getWorldId() + "] - " + w.getName());
			}
			break;
		}

		//═══════════════════════════════════════════════
		// ZONES
		//═══════════════════════════════════════════════
		case "zone":
		case "zones": {
			if (player.getCurrentWorld() == null) {
				player.sendMessage("You are not in a world.");
				return;
			}

			player.sendMessage("🌐 Zones in world '" +
					player.getCurrentWorld().getWorldId() + "':");

			List<Zone> zones = new ArrayList<>(player.getCurrentWorld().getZones());
			zones.sort(Comparator.comparingInt(Zone::getZoneId));

			for (Zone z : zones) {
				player.sendMessage("[" + z.getZoneId() + "] - " + z.getName());
			}
			break;
		}

		//═══════════════════════════════════════════════
		// ROOMS
		//═══════════════════════════════════════════════
		case "room":
		case "rooms": {
			if (player.getCurrentZone() == null) {
				player.sendMessage("You are not in a zone.");
				return;
			}

			player.sendMessage("🏠 Rooms in zone '" +
					player.getCurrentZone().getZoneId() + "':");

			List<Room> rooms =
					new ArrayList<>(player.getCurrentZone().getRooms().values());
			rooms.sort(Comparator.comparingInt(Room::getId));

			for (Room r : rooms) {
				player.sendMessage("[" + r.getId() + "] - " + r.getName());
			}
			break;
		}

		//═══════════════════════════════════════════════
		// MOBS (FROM FILES)
		//═══════════════════════════════════════════════
		case "mob":
		case "mobs": {
			File dir = new File(Config.MOBS_DIR);
			if (!dir.exists() || !dir.isDirectory()) {
				player.sendMessage("No mobs directory found.");
				return;
			}

			File[] files = dir.listFiles((d, name) -> name.endsWith(".mob.txt"));
			if (files == null || files.length == 0) {
				player.sendMessage("No mobs have been created yet.");
				return;
			}

			// sort numerically by filename prefix
			Arrays.sort(files, Comparator.comparingInt(f -> {
				try { return Integer.parseInt(f.getName().replace(".mob.txt","")); }
				catch (Exception e) { return Integer.MAX_VALUE; }
			}));

			player.sendMessage("📜 Saved Mobs:");

			for (File file : files) {
				String mobId = file.getName().replace(".mob.txt", "");

				String name = "Unknown";
				String level = "?";

				try (BufferedReader br = new BufferedReader(new FileReader(file))) {
					String line;
					while ((line = br.readLine()) != null) {
						if (line.startsWith("MobName:"))
							name = line.substring(8).trim();
						else if (line.startsWith("Level:"))
							level = line.substring(6).trim();
						if (!name.equals("Unknown") && !level.equals("?")) break;
					}
				} catch (IOException e) {
					player.sendMessage("⚠️ Error reading: " + file.getName());
				}

				player.sendMessage("[" + mobId + "] - " + name +
						" (Level " + level + ")");
			}
			break;
		}

		//═══════════════════════════════════════════════
		// SPELLS
		//═══════════════════════════════════════════════
		case "spell":
		case "spells": {
			player.sendMessage(SpellManager.listSpells());
			break;
		}

		//═══════════════════════════════════════════════
		// OBJECTS (FROM FILES)
		//═══════════════════════════════════════════════
		case "object":
		case "objects": {
			File dir = new File(Config.OBJECTS_DIR);
			if (!dir.exists() || !dir.isDirectory()) {
				player.sendMessage("No objects directory found.");
				return;
			}

			File[] files = dir.listFiles((d, name) -> name.endsWith(".Object.txt"));
			if (files == null || files.length == 0) {
				player.sendMessage("No objects have been created yet.");
				return;
			}

			Arrays.sort(files, Comparator.comparingInt(f -> {
				try { return Integer.parseInt(f.getName().replace(".Object.txt","")); }
				catch (Exception e) { return Integer.MAX_VALUE; }
			}));

			player.sendMessage("📜 Saved Objects:");

			for (File file : files) {
				String objId = file.getName().replace(".Object.txt", "");

				String name = "Unknown";
				String shortDesc = "?";

				try (BufferedReader br = new BufferedReader(new FileReader(file))) {
					String line;
					while ((line = br.readLine()) != null) {
						if (line.startsWith("  Name:"))
							name = line.substring(7).trim();
						else if (line.startsWith("  Short Description:"))
							shortDesc = line.substring(20).trim();
						if (!name.equals("Unknown") && !shortDesc.equals("?")) break;
					}
				} catch (IOException e) {
					player.sendMessage("⚠️ Error reading: " + file.getName());
				}

				player.sendMessage("[" + objId + "] - " + name +
						" (" + shortDesc + ")");
			}
			break;
		}


		//═══════════════════════════════════════════════
		// RECALL NODES (FROM ZONESCRIPT)
		//═══════════════════════════════════════════════
		case "recall":
		case "recalls": {
			Zone zone = player.getCurrentZone();
			if (zone == null) {
				player.sendMessage("You are not in a zone.");
				return;
			}

			ZoneScript script = ZoneScriptRegistry.get(zone);
			if (script == null || script.getRecallNodes().isEmpty()) {
				player.sendMessage("📍 No recall nodes defined for this zone [" + zone.getZoneId() + "]");
				return;
			}

			player.sendMessage("📍 Recall Nodes for zone [" + zone.getZoneId() + "]:");

			List<ZoneScript.RecallNode> recalls =
					new ArrayList<>(script.getRecallNodes());

			recalls.sort(Comparator.comparingInt(r -> r.roomId));

			for (ZoneScript.RecallNode node : recalls) {
				player.sendMessage(" - Room " + node.roomId);
			}

			break;
		}


		//═══════════════════════════════════════════════
		// ZONE SCRIPTS (FILES)
		//═══════════════════════════════════════════════
		case "scripts":
		case "zonescript":
		case "zonescripts": {
			File dir = new File(Config.SCRIPT_DIR);
			if (!dir.exists() || !dir.isDirectory()) {
				player.sendMessage("No ZoneScript directory found.");
				return;
			}

			File[] files = dir.listFiles((d, name) -> name.endsWith(".Script.txt"));
			if (files == null || files.length == 0) {
				player.sendMessage("No ZoneScripts have been created yet.");
				return;
			}

			// Sort numerically by worldId and zoneId
			Arrays.sort(files, (f1, f2) -> {
				try {
					String n1 = f1.getName().replace(".Script.txt", "");
					String n2 = f2.getName().replace(".Script.txt", "");

					String[] parts1 = n1.split("_");
					String[] parts2 = n2.split("_");

					int world1 = Integer.parseInt(parts1[0]);
					int zone1  = Integer.parseInt(parts1[1]);
					int world2 = Integer.parseInt(parts2[0]);
					int zone2  = Integer.parseInt(parts2[1]);

					if (world1 != world2) return Integer.compare(world1, world2);
					return Integer.compare(zone1, zone2);
				} catch (Exception e) {
					return f1.getName().compareTo(f2.getName());
				}
			});

			player.sendMessage("📜 ZoneScripts:");

			for (File file : files) {
				String name = file.getName()
						.replace(".Script.txt", "")
						.replace("_", " → ");
				player.sendMessage(" - " + name);
			}
			break;
		}




		//═══════════════════════════════════════════════
		default:
			player.sendMessage("Unknown list category: " + category);
		}
	} // end handleList

	public static String handleLoad(Mob phantasm, String[] args) {
		if (args.length < 2) {
			return "Usage: load <mob|obj|zone> <mobid/objid/worldid> <zid>";
		}

		String type = args[0].toLowerCase();
		String idStr = args[1];

		int id;
		try {
			id = Integer.parseInt(idStr);
		} catch (NumberFormatException e) {
			return "Invalid ID. Please use a number.";
		}

		Room room = phantasm.getCurrentRoom();

		switch (type) {
		case "object":
		case "obj": {
			ObjectItem obj = ObjectManager.getObjectById(id);
			if (obj == null) {
				return "❌ Object ID " + id + " not found.";
			}

			if (phantasm.getInventory().size() >= phantasm.getMaxInventorySize()) {
				return "❌ Inventory full. Could not load object.";
			}

			phantasm.getInventory().add(obj);
			return "✅ Loaded object ID " + id + " into your inventory.";
		}
		case "mob": {
			Mob mob = MobManager.createMobById(id);

			// If not already registered, try loading from file
			if (mob == null) {
				mob = WorldManager.loadMob(String.valueOf(id));
				if (mob != null) {
					MobManager.registerMobTemplate(mob); // so it's available later
					mob = MobManager.createMobById(id);  // clone it fresh
				}
			}

			if (mob == null) {
				return "❌ Mob ID " + id + " not found (in memory or file).";
			}

			//mob.setRoom(room);
			room.addMob(mob);
			mob.setCurrentRoom(room);
			return "✅ Loaded mob ID " + id + " into the room.";
		}
		case "zone": {
			if (args.length < 3) {
				return "Usage: load <zone> <worldid> <zid>";
			}
			String wid = args[1];
			int zid = Integer.parseInt(args[2]);
			Zone zone = WorldManager.loadZone(wid, zid);
			
			zone.getParentWorld().addZone(zid, zone);
			
			return "✅ Loaded zone ID " + id + " into " + zone.getParentWorld().getName() + ".";
		}
		
		default:
			return "❌ Unknown type: " + type + ". Use 'object', 'obj', or 'mob'.";
		}
	} // end handleLoad
	
	public static String handleUnload(Player player, String[] tokens) {
		if (tokens.length < 3) {
			return "Usage: load <zone> <worldid> <zid>";
		}
		String wid = tokens[2];
		int zid = Integer.parseInt(tokens[3]);
		Zone zone = WorldManager.loadZone(wid, zid);
		
		WorldManager.unloadZone(zone);
		
		return "✅ UnLoaded zone ID " + zid + " from " + zone.getParentWorld().getName() + ".";
	}

	public static String handleTitle(Player player, String newTitle) {
		if (newTitle == null || newTitle.isBlank()) {
			return "Usage: title <your title>";
		}

		// Optional: minimum privilege level to set custom titles
		if (player.getPrivilegeLevel() < 1) {
			return "You do not have permission to set a custom title.";
		}

		if (newTitle.length() > 40) {
			return "Title too long (max 40 characters).";
		}

		// Basic sanitization (strip control characters)
		newTitle = newTitle.replaceAll("[^a-zA-Z0-9.,'\\-]", "");

		player.setPlayerTitle(newTitle);
		return "Your title has been set to: \"" + newTitle + "\"";
	} // end handleTitle

	public static String handleCSave(Player player, String[] args) throws Exception {
		Editor editor = player.getEditor();
		if (editor == null) {
			return "You are not currently editing anything.";
		}

		boolean success = editor.save();
		if (success) {
			return editor.getEditorName() + " saved successfully.";
		} else {
			return "Failed to save " + editor.getEditorName() + ".";
		}
	}// end handleCSave // might be redundant

	public static String handleCreate(Player player, String[] args) {
		if (args.length < 2) {
			return "Usage: create <world|zone|room|mob|player|object|spell|script> [name|id]";
		}

		String target = args[1].toLowerCase();
		String nameArg = (args.length >= 3) ? args[2] : null;

		switch (target) {
		case "world":
			if (nameArg == null) return "Usage: create world <name>";
			return handleCreateWorld(player, nameArg, CommandProcessor.worldManager);

		case "zone":
			if (nameArg == null) return "Usage: create zone <zoneId>";
			try {
				int zoneId = Integer.parseInt(nameArg);
				return handleCreateZone(player, zoneId);  // Create or edit zone + script
			} catch (NumberFormatException e) {
				return "Zone ID must be a number: " + nameArg;
			}

		case "room":
			if (nameArg == null) return "Usage: create room <roomId>";
			try {
				int roomId = Integer.parseInt(nameArg);
				return handleCreateRoom(player, roomId);
			} catch (NumberFormatException e) {
				return "Room ID must be a number: " + nameArg;
			}

		case "mob":
		case "player":
			if (nameArg == null) return "Usage: create " + target + " <name>";
			return handleCreateMob(player, nameArg); // You can later split mob/player handling if needed

		case "object":
			if (nameArg == null) return "Usage: create object <name>";
			return handleCreateObject(player, nameArg);

		case "spell":
			return "Spell creation is not implemented yet.";

		case "script":
		case "zonescript":
			return handleCreateZoneScript(player);

		default:
			return "Unknown create target: " + target;
		}
	} // end handleCreate


	@SuppressWarnings("static-access")
	private static String handleCreateWorld(Player player, String name, WorldManager worldManager) {
		if (name == null || name.isBlank()) {
			return "Please provide a world name. Usage: create world <name>";
		}

		name = name.toLowerCase(); // normalize world ID

		if (worldManager.worldExists(name)) {
			World existing = worldManager.getWorld(name);
			WorldEditor editor = new WorldEditor(existing, player, true);
			player.setEditor(editor);
			return "Editing existing world: " + existing.getName();
		} else {
			GameClock clock = new GameClock(WorldManager.GLOBAL_CALENDAR); // or however you create clocks
			World newWorld = new World(name, capitalize(name), clock);
			WorldEditor editor = new WorldEditor(newWorld, player, false);

			worldManager.addWorld(newWorld);
			player.setEditor(editor);
			return "Created and editing new world: " + newWorld.getName();
		}
	} // end handleCreateWorld

	private static String handleCreateZone(Player player, int newZoneNum) {
		World world = player.getCurrentWorld();
		if (world == null) return "You must be in a world to create a zone.";

		Zone zone = world.getZone(newZoneNum);
		if (zone != null) {
			ZoneEditor editor = new ZoneEditor(zone, player);
			player.setEditor(editor);
			editor.startEditing();
			return "Editing existing zone: " + newZoneNum;
		} else {
			Zone newZone = new Zone();
			newZone.setZoneId(newZoneNum);
			newZone.setWorld(world);
			newZone.setParentWorld(world);

			Room newRoom = new Room();
			newRoom.setId(0);
			newRoom.setZone(newZone);
			newZone.addRoom(0, newRoom); // Fixed from 1 -> 0 for default room

			// Add the new zone to the world
			world.addZone(newZoneNum, newZone);

			// Save the updated world
			if (WorldManager.saveWorld(world)) {
				player.sendMessage("✅ World updated and saved with new zone " + newZoneNum);
			} else {
				player.sendMessage("⚠️ Failed to save world after adding zone " + newZoneNum);
			}

			// Attempt to attach a ZoneScript if available
			String className = Config.SCRIPT_DIR + ".Zone" + newZoneNum + "ZoneScript";
			try {
				Class<?> clazz = Class.forName(className);
				Object scriptInstance = clazz.getDeclaredConstructor().newInstance();

				if (scriptInstance instanceof ZoneScript) {
					newZone.setScript((ZoneScript) scriptInstance);
					System.out.println("✅ ZoneScript " + className + " applied to zone " + newZoneNum);
				} else {
					System.err.println("⚠️ " + className + " does not implement ZoneScript.");
				}
			} catch (ClassNotFoundException e) {
				System.err.println("⚠️ ZoneScript class not found: " + className);
			} catch (Exception e) {
				System.err.println("❌ Failed to instantiate ZoneScript: " + e.getMessage());
				e.printStackTrace();
			}

			ZoneEditor editor = new ZoneEditor(newZone, player);
			player.setEditor(editor);
			editor.startEditing();

			return "Created and editing new zone: " + newZoneNum;
		}
	} // end handleCreateZone

	private static String handleCreateRoom(Player player, int newRoomNum) {
		Zone zone = player.getCurrentZone();
		if (zone == null) return "You must be in a zone to create a room.";
		Zone currentZone = player.getCurrentZone();
		Room newRoom = new Room();
		newRoom.setId(newRoomNum);
		newRoom.setZone(currentZone); 
		currentZone.addRoom(1, newRoom);
		return "";
	} // end handleCreateRoom

	private static String handleCreateMob(Player player, String id) {
		int requestedId = Integer.parseInt(id); // parsed from user input
		Mob mob = MobManager.createMobByIdOrNextFree(requestedId);
		if (mob.getId() != requestedId) {
			player.sendMessage("Requested Mob ID " + requestedId + " is taken. Created Mob with ID " + mob.getId());
		}
		MobEditor editor = new MobEditor(mob, player);
		editor.startEditing();

		player.setEditor(new MobEditor(mob,player));
		return "Created and editing new mob: " + mob.getMobName();
	} // end handleCreateMob

	private static String handleCreateObject(Player player, String name) {
		ObjectItem obj = new ObjectItem();
		if (name != null) obj.setName(name);

		player.setEditor(new ObjectEditor(obj, player));
		return "Created and editing new object: " + obj.getName();
	} // end handleCreateObject

	private static String handleCreateZoneScript(Player player) {
		Zone zone = player.getCurrentZone();
		if (zone == null) return "You must be in a zone to edit its script.";

		ZoneScript script = zone.getOrCreateScript(); // helper
		player.setEditor(new ZoneScriptEditor(player, script));

		handleEditScript(player);
		return "Editing zone script for zone: " + zone.getName();

	} // end handleCreateZoneScript

	public static String handleEdit(Player player, String[] tokens) {
		if (tokens.length < 2) {
			return "Usage: edit <world|zone|room|obj|mob|script> [args...]";
		}

		String subcommand = tokens[1].toLowerCase();

		switch (subcommand) {
		case "world": {
			World world = player.getCurrentWorld();
			if (world == null) return "You are not in a world.";
			WorldEditor worldEditor = new WorldEditor(world, player, false);
			player.setEditor(worldEditor);
			return handleEditWorld(player, tokens);
		}
		case "zone": {
			Zone zone = player.getCurrentZone();
			if (zone == null) return "You are not in a zone.";
			ZoneEditor zoneEditor = new ZoneEditor(zone, player);
			player.setEditor(zoneEditor);
			return handleEditZone(player, tokens);
		}
		case "room": {
			Room room = player.getCurrentRoom();
			if (room == null) return "You are not in a room.";
			RoomEditor roomEditor = new RoomEditor(room, player);
			player.setEditor(roomEditor);
			return handleEditRoom(player);
		}
		case "obj":
		case "object": {
			return handleEditObject(player, tokens);
		}
		case "mob": {
			return handleEditMob(player, tokens);
		}
		case "player": {	        	
			handleEditPlayer(player,tokens);
		}
		case "script": {
			handleEditScript(player, tokens);
		}
		default:
			return "Unknown edit target: " + subcommand;
		}
	} // end handleEdit

	private static String handleEditWorld(Player player, String[] tokens) {
		String worldId = tokens.length >= 3 ? tokens[2] : Config.DEFAULT_WORLD_ID;
		World world = WorldManager.getWorld(worldId);
		if (world == null) {
			return "World '" + worldId + "' not found.";
		}

		WorldEditor editor = new WorldEditor(world, player, false);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing existing world: " + world.getName();
	} // end handleEditWorld

	private static String handleEditZone(Player player, String[] tokens) {
		World world = player.getCurrentWorld();
		if (world == null) {
			return "You must be in a world to edit a zone.";
		}

		int zoneId;

		// Case: edit zone <zoneId>
		try {
			zoneId = Integer.parseInt(tokens[2]);
		} catch (NumberFormatException e) {
			return "Invalid zone number: " + tokens[2];
		}

		Zone zone = world.getZone(zoneId);
		if (zone == null) {
			return "Zone #" + zoneId + " does not exist in world '" + world.getWorldId() + "'.";
		}

		return "Editing zone #" + zoneId + " in world '" + world.getWorldId() + "'.";
	} // end handleEditZone

	private static String handleEditRoom(Player player) {
		Room currentRoom = player.getCurrentRoom();
		if (currentRoom == null) {
			return "You must be in a room to edit it.";
		}
		RoomEditor editor = new RoomEditor(currentRoom, player);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing current room: " + currentRoom.getName();
	} // end handleEditRoom


	private static String handleEditObject(Player player, String[] tokens) {
		ObjectItem targetObj = null;

		if (tokens.length < 3) {
			player.sendMessage("Please enter the object ID number to edit:");
			// Set player editor state to expect object ID input, if you have such a system
			// For example: player.setPendingInputState(InputState.OBJECT_ID_INPUT);
			return null; // Waiting for input
		}

		try {
			int objId = Integer.parseInt(tokens[2]);
			// Assume a global method to find object by ID, e.g.:
			targetObj = ObjectManager.getObjectById(objId);
			if (targetObj == null) {
				return "Object with ID " + objId + " not found.";
			}
		} catch (NumberFormatException e) {
			return "Invalid object ID.";
		}

		ObjectEditor editor = new ObjectEditor(targetObj, player);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing object: " + targetObj.getName() + " (ID: " + targetObj.getObjID() + ")";
	} // end handleEditObject

	private static String handleEditPlayer(Player player, String[] tokens) {
		if (tokens.length < 3) {
			return "Usage: edit player <name>";
		}

		String targetName = tokens[2];
		Player target = PlayerLoader.load(targetName);
		if (target == null) {
			return "Player not found: " + targetName;
		}

		PlayerEditor editor = new PlayerEditor(target, player);
		player.setEditor(editor);
		editor.startEditing();

		return null;
	} // end handleEditPlayer

	private static String handleEditMob(Player player, String[] tokens) {
		if (tokens.length < 3) {
			player.sendMessage("Please enter the Mob ID number to edit:");
			return null; // Waiting for input
		}

		Mob targetMob = null;
		int mobId;

		try {
			mobId = Integer.parseInt(tokens[2]);
		} catch (NumberFormatException e) {
			return "❌ Invalid Mob ID.";
		}

		// 1️⃣ Try to get mob from memory/templates
		targetMob = MobManager.getMobById(mobId);

		// 2️⃣ If not found, attempt to load from file
		if (targetMob == null) {
			targetMob = WorldManager.loadMob(String.valueOf(mobId));
			if (targetMob != null) {
				MobManager.registerMobTemplate(targetMob); // Add to registry
			}
		}

		// 3️⃣ If still null, create a new mob with that ID (or next free)
		if (targetMob == null) {
			targetMob = MobManager.createMobByIdOrNextFree(mobId);
			player.sendMessage("⚠️ Mob ID " + mobId + " not found. Created new mob with ID " + targetMob.getId());
		}

		// 4️⃣ Start editor
		MobEditor editor = new MobEditor(targetMob, player);
		player.setEditor(editor);
		editor.startEditing();

		return "🛠️ Editing mob: " + targetMob.getMobName() + " (ID: " + targetMob.getId() + ")";
	} // end handleEditMob

	public static void handleEditScript(Player player, String[] tokens) {
		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You must be in a world to edit zone scripts.");
			return;
		}

		Zone zone;
		if (tokens.length >= 3) {
			// Edit by specific zone ID
			int zoneId;
			try {
				zoneId = Integer.parseInt(tokens[2]);
			} catch (NumberFormatException e) {
				player.sendMessage("Invalid zone ID.");
				return;
			}

			zone = world.getZone(zoneId);
			if (zone == null) {
				player.sendMessage("Zone ID " + zoneId + " not found in world '" + world.getWorldId() + "'.");
				return;
			}
		} else {
			// Edit the current zone
			zone = player.getCurrentZone();
			if (zone == null) {
				player.sendMessage("You are not in a valid zone to edit its script.");
				return;
			}
		}

		ZoneScript script = zone.getScript();
		if (script == null) {
			player.sendMessage("⚠️ Zone " + zone.getZoneId() + " has no script assigned.");
			return;
		}

		player.sendMessage("Editing script: " + script.getZoneId());
		ZoneScriptEditor editor = new ZoneScriptEditor(player, script);
		player.setEditor(editor);
		editor.startEditing();  // will show menu
	} // handleEditScript

	private static String handleEditScript(Player player) {
		World world = player.getCurrentWorld();
		Zone zone = player.getCurrentZone();
		if (world == null || zone == null) return "You're not in a valid zone to edit its script.";

		return handleEditScriptByZoneId(player, zone.getZoneId());
	} // end handleEditScript

	private static String handleEditScriptByZoneId(Player player, int zoneId) {
		World world = player.getCurrentWorld();
		if (world == null) return "You must be inside a world to edit a script.";

		Zone zone = world.getZone(zoneId);
		if (zone.getScript() == null) {
			BasicZoneScript script = new BasicZoneScript(zone, zone.getZoneId());
			zone.setScript(script);
		}

		ZoneScript script = zone.getScript();
		if (script == null) return "Zone " + zoneId + " has no script assigned.";

		ZoneScriptEditor editor = new ZoneScriptEditor(player, script);
		player.setEditor(editor);
		editor.startEditing();

		return "Editing script for zone " + zoneId;
	} // end handleEditScriptByZoneId

	public static String handlePurge(Player admin, String[] tokens) {

		String targetName = null;
		
		if (tokens.length>1) {
			targetName = tokens[1];
		}
		// --- Permission check ---
		if (admin.getPrivilegeLevel() == 0) {
			return "You do not have permission to do that.";
		}

		Room room = admin.getCurrentRoom();
		int purgedCount = 0;

		// ======================
		// PURGE ALL MOBS
		// ======================
		if (targetName == null || targetName.isEmpty()) {

			List<Mob> mobsToPurge = new ArrayList<>();

			for (Mob mob : room.getMobs()) {
				if (mob instanceof Player) {
					continue;
				}
				mobsToPurge.add(mob); 
			}

			if (mobsToPurge.isEmpty()) {
				return "There are no mobs here to purge.";
			}

			for (Mob mob : mobsToPurge) {
				dropAllMobItems(mob, room);
				room.removeMob(mob);
				purgedCount++;
			}

			return "You purge " + purgedCount + " mob(s) from the room.";
		}

		// ======================
		// PURGE SINGLE TARGET
		// ======================
		Mob target = findMobInRoomByName(room, targetName);

		if (target == null) {
			return "You see no such creature here.";
		}

		if (target instanceof Player) {
			return "You cannot purge players.";
		}

		dropAllMobItems(target, room);
		room.removeMob(target);

		return "You purge " + target.getMobName() + " from existence.";
	}  	// end handlePurge

	private static void dropAllMobItems(Mob mob, Room room) {

		// --- Drop equipped items ---
		for (EquipSlot slot : EquipSlot.values()) {
			ObjectItem item = mob.getEquippedItem(slot);
			if (item != null) {
				mob.unequip(slot);
				room.addObject(item);
			}
		}

		// --- Drop inventory ---
		for (ObjectItem item : mob.getInventory()) {
			room.addObject(item);
		}
		mob.getInventory().clear();

		if (mob.getEquipment() != null) {
			for (Map.Entry<EquipSlot, ObjectItem> entry : mob.getEquipment().entrySet()) {
				ObjectItem loot = entry.getValue();
				if (loot != null) {
					room.addObject(loot);
					mob.unequip(entry.getKey()); // clear the slot
				}
			}
		}

	} // end dropAllMobItems

	private static Mob findMobInRoomByName(Room room, String name) {
		for (Mob mob : room.getMobs()) {
			if (mob.getMobName().equalsIgnoreCase(name) || mob.matchesKeyword(name)) {
				return mob;
			}
		}
		return null;
	} // end findMobInRoomByName
	

	public static String capitalize(String s) {
		if (s == null || s.isEmpty()) return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	} // end capitalize


	
	// --- SERVER COMMANDS ---
	public static void handleShutdown(Player player) {

	    System.out.println("🛑 Server shutdown initiated...");

	    // 1. Save all worlds
	    for (World w : WorldManager.getAllWorlds()) {
	        WorldManager.saveWorld(w);
	    }

	    // 2. Backup ALL players on disk
	    BackupHandler.backupAllPlayers();
	    MudLogger.logSystemEvent("Server Shut Down"); // log the event
	    
	    for (Player target : WorldManager.getActivePlayers()) {
		target.sendMessage("Server Restarted.");
		target.getClientHandler().disconnect();
	  
	    }
	    	    
	    System.out.println("✅ Shutdown save + backup complete.");
	    System.exit(0);
	}
	// end

	public static void handleRestart(Player player) {

	    System.out.println("🔄 Restarting server...");

	    // 1. Save all worlds
	    for (World w : WorldManager.getAllWorlds()) {
	        WorldManager.saveWorld(w);
	    }
	    
	    


	    // 2. Backup all players
	    BackupHandler.backupAllPlayers();
	    MudLogger.logSystemEvent("Server Restarted"); // log the event
	    
	    for (Player target : WorldManager.getActivePlayers()) {
		target.sendMessage("Server Restarted.");
		target.getClientHandler().disconnect();
	  
	    }
	    
	    // 3. Stop the global clock
	    GameClock clock = WorldManager.getGlobalClock();
	    if (clock != null) {
	        clock.stop();
	    }

	    // 4. Clear in-memory state
	    WorldManager.clear();

	    // 5. Reload from disk (same order as Server.main)
	    System.out.println("🌍 Reloading worlds...");
	    WorldManager.loadAll();

	    if (WorldManager.getAllWorlds().isEmpty()) {
	        World defaultWorld = WorldManager.createTithriusWorld();
	        WorldManager.registerWorld(defaultWorld);
	    }

	    HelpManager.loadAllFromDisk();
	    MapManager.loadAll(Config.MAPS_DIR);
	    ZoneMapManager.loadAll(Config.MAPS_DIR);
	    WorldMapManager.loadAll(Config.MAPS_DIR);

	    // 6. Restart the clock
	    WorldManager.getGlobalClock().start();

	    System.out.println("✅ Restart complete.");
	}
	// end
	
	public static String handleAbout(Player player) {
	    if (player == null) return "";

	    String border = "==================================================";

	    StringBuilder sb = new StringBuilder();
	    sb.append(border).append("\n");
	    sb.append(Config.gameName).append("\n");
	    sb.append("Version " + Config.gameVersion).append("\n");
	    sb.append(border).append("\n\n");

	    sb.append(" Engine Development Team:\n");
	    sb.append("   ").append(Config.engineDevTeam).append("\n\n");

	    sb.append(" Game Development Team:\n");
	    sb.append("   ").append(Config.gameDevTeam).append("\n\n");

	    sb.append(" Dedication:\n");
	    sb.append("   ").append(Config.gameDedication).append("\n\n");

	    sb.append(border).append("\n\n");
	    
	    sb.append(" History:\n");
	    sb.append("   ").append(Config.gameHistory).append("\n\n");

	    sb.append(border); 
	    

	    return sb.toString();
	}
	
	
} // end AdminCommandHandler
