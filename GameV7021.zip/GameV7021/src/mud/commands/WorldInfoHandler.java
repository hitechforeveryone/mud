package mud.commands;

import mud.config.*;
import mud.core.*;
import mud.core.enums.Climate;
import mud.core.enums.WeatherType;
import mud.system.*;

public class WorldInfoHandler {
	// all of the handlers that provide world information
	
	public static void handleTime(Player player) {
		if (player == null) return;

		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You are not currently in a world.");
			return;
		}

		GameClock clock = player.getCurrentWorld().getClock();
		if (clock == null) {
			player.sendMessage("World clock is unavailable.");
			return;
		}

		player.sendMessage(""+ clock.getFormattedTime(world));
	} // end handleTime

	public static void handleWeather(Player player) {
		if (player == null) return;

		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You are not currently in a world.");
			return;
		}

		Room currentRoom = player.getCurrentRoom();
		if (currentRoom == null) {
			player.sendMessage("You are nowhere.");
			return;
		}

		Zone zone = player.getCurrentZone();
		if (zone == null) {
			player.sendMessage("Weather data is unavailable for this area.");
			return;
		}

		// Get climate and base weather type for the zone
		Climate climate = zone.getClimate();
		WeatherType baseWeather = zone.getCurrentWeather(); // you could set this in zone based on climate

		// If no weather type is set, derive from climate
		if (baseWeather == null || baseWeather == WeatherType.NONE) {
			baseWeather = switch (climate) {
			case TEMPERATE, FOREST, PLAINS -> WeatherType.CLEAR;
			case DESERT -> WeatherType.HEATWAVE;
			case ARCTIC, COLD -> WeatherType.COLD_SNAP;
			case TROPICAL -> WeatherType.RAIN;
			case SWAMP -> WeatherType.FOG;
			case MOUNTAIN, HIGHLAND -> WeatherType.WINDY;
			case COASTAL -> WeatherType.WINDY;
			case BLIGHTED -> WeatherType.BLIGHT;
			case VOID -> WeatherType.VOID;
			default -> WeatherType.CLEAR;
			};
		}

		// Optional: Make the weather vary by time of day
		GameClock clock = world.getClock();
		long tick = clock != null ? GameClock.getCurrentTick() : 0;
		int hour = (int)((tick % Config.ticksPerDay) / (Config.ticksPerDay / 24));

		String timeModifier = "";
		if (hour >= 6 && hour < 12) timeModifier = "The morning sun lights the area. ";
		else if (hour >= 12 && hour < 18) timeModifier = "The afternoon heat settles in. ";
		else if (hour >= 18 && hour < 21) timeModifier = "Evening shadows lengthen. ";
		else timeModifier = "Night falls quietly. ";

		// Send player the weather info
		player.sendMessage("Zone: " + zone.getName());
		player.sendMessage("Climate: " + climate.name());
		player.sendMessage("Season: " + clock.getCurrentSeasonName());

		player.sendMessage("Weather: " + timeModifier + baseWeather.getDescription() );

	}

	public static void handleDate(Player player) {
		if (player == null) return;

		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You are not currently in a world.");
			return;
		}

		GameClock clock = world.getClock();
		String currentDate = "";
		CalendarSystem calendar = clock.getCalendar();
		int dayIndex = GameClock.getCurrentDayIndex(); // total in-game days elapsed

		String dayName = calendar.getDayOfWeekName(dayIndex);
	
		int weekOfMonth = calendar.getWeekOfMonth(dayIndex) ; // display as 1-based
		String monthName = calendar.getMonthNameByDay(dayIndex);
		int year = calendar.getYear(dayIndex);
		
		
		currentDate = "  Day: " + dayName + "  Week of Month: " + weekOfMonth + "  Month: " + monthName + "  Year: " + year + " of the current age.";
		
		player.sendMessage("Today is: " + currentDate);
	}
	public static void handleCalendar(Player player) {
		if (player == null) return;

		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You are not currently in a world.");
			return;
		}

		GameClock clock = world.getClock();
		if (clock == null) {
			player.sendMessage("World clock is unavailable.");
			return;
		}

		CalendarSystem calendar = clock.getCalendar();
		int dayIndex = GameClock.getCurrentDayIndex(); // total in-game days elapsed

		String dayName = calendar.getDayOfWeekName(dayIndex);
		int weekOfMonth = calendar.getWeekOfMonth(dayIndex) ; // display as 1-based
		String monthName = calendar.getMonthNameByDay(dayIndex);
		int year = calendar.getYear(dayIndex);
		String timeOfDay = calendar.getTimeOfDay(GameClock.getCurrentTick());

		// Build the nicely formatted output
		StringBuilder sb = new StringBuilder();
		sb.append("[GameClock] Current Date & Time:\n");
		sb.append("  Day: ").append(dayName).append("\n");
		sb.append("  Week of Month: ").append(weekOfMonth).append("\n");
		sb.append("  Month: ").append(monthName).append("\n");
		sb.append("  Year: ").append(year).append(" of the current age.\n");
		sb.append("  Time of Day: ").append(timeOfDay).append("\n");

		player.sendMessage(sb.toString());
	}

}
