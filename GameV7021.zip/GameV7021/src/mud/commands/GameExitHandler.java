package mud.commands;

import mud.core.*;
import mud.core.enums.*;
import mud.server.BackupHandler;
import mud.system.PlayerLoader;

public class GameExitHandler {

	public static String handleQuit(Player player) {
		PlayerLoader.save(player);
        BackupHandler.handleBackup(player, player.getName()); // backup  player

		if (player.getEditor() != null) {
			player.getEditor().stopEditing();
			player.setEditor(null);
		}
		player.sendMessage("You have exited to the login screen.");
		WorldManager.removePlayer(player);
		player.setPendingLogout(true);
		return "quit";
	}
	
	public static String handleCamp(Player player) {
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are not in a valid location.");
		}

		Room room = player.getCurrentRoom();

		// Check for CAMP flag
		if (!room.getFlags().contains(RoomFlag.CAMP)) {
			player.sendMessage("You can't safely camp here.");
		}

		// Store camp location (optional)
		player.setRentWorld(player.getCurrentWorld());
		player.setRentZone(player.getCurrentZone());
		player.setRentRoom(player.getCurrentRoom());

		// Save player
		PlayerLoader.save(player);
        BackupHandler.handleBackup(player, player.getName()); // backup  player

		// Remove player from room/zone/world
		room.removeMob(player);
		player.setCurrentRoom(null);
		player.setCurrentZone(null);
		player.setCurrentWorld(null);

		// Notify player and flag for logout
		player.sendMessage("You set up camp and rest for the night. When you return, you'll wake here, safe and sound.");
		player.setPendingLogout(true);

		return null;
	} // end


	/*
	 * moved to InnkeeperHandler
	public static String handleRent(Player player) {
		if (player == null || player.getCurrentRoom() == null) {
			return "You are not in a valid location.";
		}

		Room room = player.getCurrentRoom();

		// Check for RENT flag
		if (!room.getFlags().contains(RoomFlag.RENT)) {
			return "You can't rent a room here.";
		}

		// Check for INNKEEPER mob
		boolean hasInnkeeper = room.getMobs().stream()
				.anyMatch(mob -> mob.hasBehavior(MobBehaviorFlag.INNKEEPER));

		if (!hasInnkeeper) {
			return "There’s no one here to rent you a room.";
		}

		// ✅ Passed all checks; proceed to rent
		player.setRentWorld(player.getCurrentWorld());
		player.setRentZone(player.getCurrentZone());
		player.setRentRoom(player.getCurrentRoom());

		// Save player
		PlayerLoader.save(player);
        BackupHandler.handleBackup(player, player.getName()); // backup  player

		// Remove player from current room
		room.removeMob(player);
		player.setCurrentRoom(null);
		player.setCurrentZone(null);
		player.setCurrentWorld(null);

		// Inform player
		player.sendMessage("You rent a cozy room and fall asleep. When you return, you’ll wake here rested and safe.");

		// Mark player for logout
		player.setPendingLogout(true);

		return null;
	} // end
	*/

}
