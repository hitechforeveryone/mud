package mud.config;

public class ChangeLog {
	
	// v07.0.21
		// mail system
			//InnkeeperHandler - mail and rent handling at Innkeeper mobs
			// moved handleRent out of GameExitHandler
	// v07.0.20
		// Sentry behavior, if null/none block all, if specific only blocks that set of directions
	// v07.0.19
		// seasons and updated weather system
	// v07.0.18
		// mob editor updates for shopkeeper
	// v07.0.17
		// Zone Script Triggers, zone script editor updates
	// v07.0.16
		// mob TreasureValue - coin droppages + gems
	// v07.0.15
		// Standardization of Spells and Effects
	// v07.0.14
		// Room Editor updates for Zone Exits
		// RoomFlag SHIP - ignores ON_WATER for movement
	// v07.0.13
		// ZoneExit work, timed zexits
	// v07.0.12
	// v07.0.11
		// hidden doors, door lock/unlock update, doors key by keyword now, not just "door"
	// v07.0.10
		// log system
		// quaff - finished, potions target the user/caster
		// use - finished, wands target target, staffs target caster+party
		// recite - finished, scrolls target target
	// v07.0.9a
		// additional traversal tools with different types of checks
		// save/load of world state (save tick #, all else is calc from that)
		// player backups
		// /shutdown and /restartgame commands (these will backup players)
	// v0.7.0.9
		// combatMangaer rewrite, handles combat only, death stuff (reincarnate/nokill checks) put into DeathManager
		// map system, World Map of Tithrius, zone maps for many zones, zone maps update/mark player position on map
		// zone traversal tools to check if zone is navigable from room 0
	// v0.7.0.8 
		// loadZone update with traversal and exit checkers
		// exp/level consolidation
		// follow command
		// where command
		// expanded races/subraces
		// charisma stat added
		// spell cast handler fixed to allow target-less spell casting
		// findfamiliar/tamepet... spells using Master/Pet fields
		// Order command for pets and admin to control mobs
		// admin commands
		// Imm/Gimm only communication channel
		// party channel
		// eat/drink commands, hp/mp restore, if poisoned, poison player
		// quaff // to finish, need spells on items
		// use // to finish, need spells on items
		// recite // to finish, need spells on items
		// light, duration is "hourly" not ticks
		// additional spells
	// v0.7.0.7 work on Shops/Banks
		// combat manager cleanup
		// exp and leveling cleanup/consolidation
		// corpses are containers, "corpse" containers rot after 3 days and drop contents to room
		// additional help files
		// additional spells
		// Full Moon and Eclipse behaviors
	// v0.7.0.6 Zone Scripts! 
		// basic zone script editor - Recall Nodes, Mobs, Objects, Doors // this needs work
		// parse and apply scripts to zones // this works if formatting is ensured
	// v0.7.0.5 work object editor, obj file formating, equip/unequip/drop, player inventory work
		// Security Updates - LoginManager/PlayerLoader updated to use password hashing. plaintext password auto-removed/changed to hashpw on next player login/out
		// WorldManager Updates
		// Code Cleanup, unused removed, commene-out code removed
	// v0.7.0.4 casting system updates, spell registration/casting by profession, additional spells (cure light, cure serious, cure critical, lifebloom, silence/sonicdamp, poison, transport..), additional help files 
		// SpellRegister, spell register by profession and are only castable by said professions
		// fleshed-out behavior for most roomFlags
	// v0.7.0.3 basic mobAI implemented, more spells (track, disarm, double attack, dual wield, flee, fumble, disarm, headbutt, rend, gouge, smite/unholysmite, summon), work on zone scripts, work on Party system
	// v0.7.0.2 Zone exits work, work on spell system (heal, fireball, kick, punch, rescue)
	// v0.7.0.1 redesign of base structure on game, modularized game systems, work on Zone Exits, help files+editor
	// v0.7.0.0 created a Server and Client login system for game, no longer single player
	// v0.6.0.0 player objects gone, players are now Mobs
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux now
	// v0.5.0 introduces zone objects and zoneScript objects (not working)
	

}
