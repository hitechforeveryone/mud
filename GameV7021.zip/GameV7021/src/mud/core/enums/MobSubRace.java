package mud.core.enums;

// TODO

public enum MobSubRace {
    NONE(MobRace.NONE),

    // Aquatic subraces
    FISH(MobRace.AQUATIC),
    MERFOLK(MobRace.AQUATIC),
    SEASERPENT(MobRace.AQUATIC),
    KRAKEN(MobRace.AQUATIC),
    SHARK(MobRace.AQUATIC),
    WHALE(MobRace.AQUATIC),
    CRUSTACEAN(MobRace.AQUATIC),
    CEPHALOPOD(MobRace.AQUATIC),
    LEVIATHAN(MobRace.AQUATIC),
    SEA_ELDER(MobRace.AQUATIC),
    

    // Beast subraces
    WOLF(MobRace.BEAST),
    BEAR(MobRace.BEAST),
    LARGECAT(MobRace.BEAST),
    BOAR(MobRace.BEAST),
    CERVID(MobRace.BEAST),
    BOVIDAE(MobRace.BEAST),
    SNAKE(MobRace.BEAST),
    LIZARD(MobRace.BEAST),
    CHIMERA(MobRace.BEAST),
    

    // Critter subraces
    VERMIN(MobRace.CRITTER),
    INSECT(MobRace.CRITTER),
    RODENT(MobRace.CRITTER),
    SPIDER(MobRace.CRITTER),
    GIANT_ANT(MobRace.CRITTER),

    // Demon subraces
    IMPS(MobRace.DEMON),
    FIRE_DEMON(MobRace.DEMON),
    SHADOW_DEMON(MobRace.DEMON),
    HELLHOUND(MobRace.DEMON),
    SUCCUBUS(MobRace.DEMON),
    BALOR(MobRace.DEMON),
    VILE_SPIRIT(MobRace.DEMON),
    PIT_LORD(MobRace.DEMON),
    HELLSPAWN(MobRace.DEMON),
    ABYSSAL_WRAITH(MobRace.DEMON),
    FIRELORD(MobRace.DEMON),
    INFERNAL_ARCHON(MobRace.DEMON),
    
    
    // Dragonkin subraces
    TRUEDRAGON(MobRace.DRAGONKIN),
    DRAGONBLOOD(MobRace.DRAGONKIN),
    WYVERN(MobRace.DRAGONKIN),
    DRAKE(MobRace.DRAGONKIN),
    LANDDRAGON(MobRace.DRAGONKIN),
    WYRM(MobRace.DRAGONKIN),
    DRAGONKIN(MobRace.DRAGONKIN),
    DRAKONID(MobRace.DRAGONKIN),
    CELESTIAL_DRAGON(MobRace.DRAGONKIN),
    VOID_DRAGON(MobRace.DRAGONKIN),

    // Elemental subraces
    FIRE_ELEMENTAL(MobRace.ELEMENTAL),
    WATER_ELEMENTAL(MobRace.ELEMENTAL),
    EARTH_ELEMENTAL(MobRace.ELEMENTAL),
    AIR_ELEMENTAL(MobRace.ELEMENTAL),
    LAVA_ELEMENTAL(MobRace.ELEMENTAL),
    ICE_ELEMENTAL(MobRace.ELEMENTAL),
    STORM_ELEMENTAL(MobRace.ELEMENTAL),
    MUD_ELEMENTAL(MobRace.ELEMENTAL),
    MAGMA_ELEMENTAL(MobRace.ELEMENTAL),
    TWILIGHT_ELEMENTAL(MobRace.ELEMENTAL),
    

    // Flying subraces
    HARPY(MobRace.FLYING),
    AVIAN(MobRace.FLYING),
    CLOUD(MobRace.FLYING),
    ROOK(MobRace.FLYING),
    PHOENIX(MobRace.FLYING),

    // Humanoid subraces
    HUMAN(MobRace.HUMANOID),
    ELF(MobRace.HUMANOID),
    HALFELF(MobRace.HUMANOID),
    DWARF(MobRace.HUMANOID),
    ORC(MobRace.HUMANOID),
    TROLL(MobRace.HUMANOID),
    TAUREN(MobRace.HUMANOID),
    WERECREATURE(MobRace.HUMANOID),
    GNOME(MobRace.HUMANOID),
    HALFORC(MobRace.HUMANOID),
    DROW(MobRace.HUMANOID),

    // Giant subraces
    JOTUN(MobRace.GIANT),
    FIREGIANT(MobRace.GIANT),
    CLOUDGIANT(MobRace.GIANT),
    FROSTGIANT(MobRace.GIANT),
    STONEGIANT(MobRace.GIANT),
    STORMGIANT(MobRace.GIANT),
    HILLGIANT(MobRace.GIANT),
    OGRE(MobRace.GIANT),
    ETTIN(MobRace.GIANT),
    TITAN(MobRace.GIANT),
    

    // Magic subraces
    ARCANE_BEING(MobRace.MAGIC),
    FAE(MobRace.MAGIC),
    ILLUSION(MobRace.MAGIC),
    SPRITE(MobRace.MAGIC),

    
    // Mechanical subraces
    GOLEM(MobRace.MECHANICAL),
    AUTOMATON(MobRace.MECHANICAL),
    CLOCKWORK(MobRace.MECHANICAL),

    // Plant subraces
    VINEBEAST(MobRace.PLANT),
    TREANT(MobRace.PLANT),
    SPOREBORN(MobRace.PLANT),
    ENTLING(MobRace.PLANT),
    FLOWERSPIRIT(MobRace.PLANT),

    // Undead subraces
    SKELETON(MobRace.UNDEAD),
    GHOST(MobRace.UNDEAD),
    ZOMBIE(MobRace.UNDEAD),
    WIGHT(MobRace.UNDEAD),
    VAMPIRE(MobRace.UNDEAD),
    LICH(MobRace.UNDEAD),
    BANSHEE(MobRace.UNDEAD),
    DEATHKNIGHT(MobRace.UNDEAD),
    DRACOLICH(MobRace.UNDEAD),
    
    ;
    private final MobRace parentRace;

    MobSubRace(MobRace parentRace) {
        this.parentRace = parentRace;
    }

    public MobRace getParentRace() {
        return parentRace;
    }
}
