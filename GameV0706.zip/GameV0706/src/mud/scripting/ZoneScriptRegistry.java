package mud.scripting;

import mud.core.World;
import mud.core.Zone;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public final class ZoneScriptRegistry {

  //  private static final Map<Integer, ZoneScript> SCRIPTS = new HashMap<>();
    private static final Map<String, ZoneScript> SCRIPTS = new HashMap<>();


    private ZoneScriptRegistry() {}

    /* ======================================================
     * CREATE / LOAD
     * ====================================================== */
    public static ZoneScript createForZone(Zone zone) {
        String key = makeKey(zone);

        if (SCRIPTS.containsKey(key)) {
            ZoneScript existing = SCRIPTS.get(key);
            zone.setScript(existing);   // always attach
            return existing;
        }

        ZoneScript script = null;

        try {
            script = ZoneScriptTextParser.read(zone);
            if (script != null) {
                System.out.println("✅ Loaded ZoneScript (.txt) for zone "
                    + zone.getWorld().getWorldId() + ":" + zone.getZoneId());
            }
        } catch (IOException e) {
            System.err.println("❌ Failed to load ZoneScript (.txt) for zone "
                + zone.getZoneId() + ": " + e.getMessage());
        }

        if (script == null) {
            script = new BasicZoneScript(zone, zone.getZoneId());
        }

        zone.setScript(script);
        SCRIPTS.put(key, script);

        return script;
    }

    
    /*
    public static ZoneScript createForZone(Zone zone) {
        int zoneId = zone.getZoneId();

        // Reattach if already loaded
        if (SCRIPTS.containsKey(zoneId)) {
            ZoneScript existing = SCRIPTS.get(zoneId);
            zone.setScript(existing);
            return existing;
        }

        ZoneScript script = null;

        try {
            script = ZoneScriptTextParser.read(zone);
            if (script != null) {
                System.out.println(
                    "✅ Loaded ZoneScript (.txt) for zone "
                    + zone.getParentWorld().getWorldId() + ":" + zoneId
                );
            }
        } catch (IOException e) {
            System.err.println(
                "❌ Failed to load ZoneScript (.txt) for zone "
                + zoneId + ": " + e.getMessage()
            );
        }

        if (script == null) {
            script = new BasicZoneScript(zone, zoneId);
        }

        zone.setScript(script);
        SCRIPTS.put(zoneId, script);
        return script;
    }
*/

    /* ======================================================
     * ACCESS
     * ====================================================== */

    public static ZoneScript get(Zone zone) {
        return SCRIPTS.get(makeKey(zone));
    }

    public static boolean has(Zone zone) {
        return SCRIPTS.containsKey(makeKey(zone));
    }

    /*
    public static ZoneScript get(int zoneId) {
        return SCRIPTS.get(zoneId);
    }

    public static boolean has(int zoneId) {
        return SCRIPTS.containsKey(zoneId);
    }
*/
    /* ======================================================
     * LIFECYCLE
     * ====================================================== */

    public static void clear() {
        SCRIPTS.clear();
    }

    public static void unload(int zoneId) {
        SCRIPTS.remove(zoneId);
    }

    public static void registerDefaults(World world) {
        for (Zone zone : world.getZones()) {
            createForZone(zone);
        }
    }
    private static String makeKey(Zone zone) {
        return zone.getWorld().getWorldId() + ":" + zone.getZoneId();
    }

   
} // end
