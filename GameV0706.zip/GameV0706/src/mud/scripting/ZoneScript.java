package mud.scripting;

import mud.core.Direction;
import mud.core.EquipSlot;
import mud.core.MobManager;
import mud.core.ObjectItem;
import mud.core.ObjectManager;
import mud.core.Zone;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public interface ZoneScript {

    int getZoneId();

    List<Room> getRooms();
    List<RecallNode> getRecallNodes();

    void apply(Zone zone);

    /* =========================
     * Shared data contracts
     * ========================= */

    class Room {
        public int roomId;
        public List<Mob> mobs = new ArrayList<>();
        public List<ZoneObject> objects = new ArrayList<>();
        public List<Door> doors = new ArrayList<>();
        public List<Trigger> triggers = new ArrayList<>();
    }

    class Mob {
        public int mobId;
        public int percent = 100;
        public List<EquipmentEntry> equipment = new ArrayList<>();
        public List<ZoneObject> inventory = new ArrayList<>();
		public static void unequip(EquipSlot slot) {
			// TODO Auto-generated method stub
			
		}
    }

    class ZoneObject {
        public int objectId;
        public int percent = 100; 
        public List<ZoneObject> contains = new ArrayList<>();
		public int getObjectId() {
			return objectId;
		}
		public void setObjectId(int objectId) {
			this.objectId = objectId;
		}
		public int getPercent() {
			return percent;
		}
		public void setPercent(int percent) {
			this.percent = percent;
		}
		public List<ZoneObject> getContains() {
			return contains;
		}
		public void setContains(List<ZoneObject> contains) {
			this.contains = contains;
		}
    }

    public static class EquipmentEntry extends ZoneObject {
  //      public int objectId;
        public EquipSlot slot;     // store as string, map to EquipSlot later
   //     public int percent = 100;

		public EquipSlot getSlot() {
			return slot;
		}

		public void setSlot(EquipSlot slot) {
			this.slot = slot;
		}
    }

    class Door {
        public String direction;
        public boolean open;
        public boolean locked;
        public boolean remote;
    }

    class Trigger {
        public TriggerType type;
        public int chance = 100;
        public int ticks = 0;
        public boolean player = false;

        public ZoneAction actionType;
        public String actionDetail;

        public String textMatch;
        public String objectType;
        public String spell;
        public int mobId;
    }

    class RecallNode {
        public int roomId;
    }

    enum TriggerType {
        ON_ENTER,
        ON_TICK,
        ON_CAST,
        ON_SAY,
        ON_USE,
        ON_DEATH
    }
    default String returnRecallBlock() {
        StringBuilder sb = new StringBuilder();

        sb.append("📜 ZoneScript\n");
        sb.append("Zone ID: ").append(getZoneId()).append("\n");

        List<RecallNode> recalls = getRecallNodes();
        if (recalls == null || recalls.isEmpty()) {
            sb.append("Recall Nodes: None\n");
        } else {
            sb.append("Recall Nodes:\n");
            for (RecallNode node : recalls) {
                sb.append(" - Room ").append(node.roomId).append("\n");
            }
        }

        return sb.toString();
    } 
    default String returnStatBlock() {
        StringBuilder sb = new StringBuilder();

        sb.append("📜 ZoneScript\n");
        sb.append("Zone ID: ").append(getZoneId()).append("\n\n");

        // -----------------------
        // Recall Nodes
        // -----------------------
        List<RecallNode> recalls = getRecallNodes();
        if (recalls == null || recalls.isEmpty()) {
            sb.append("Recall Nodes: None\n");
        } else {
            sb.append("Recall Nodes:\n");
            for (RecallNode node : recalls) {
                sb.append(" - Room ").append(node.roomId).append("\n");
            }
        }

        // -----------------------
        // Rooms
        // -----------------------
        List<Room> rooms = getRooms();
        if (rooms == null || rooms.isEmpty()) {
            sb.append("\nNo rooms defined in script.\n");
            return sb.toString();
        }

        sb.append("\nRooms:\n");

        for (Room r : rooms) {
            sb.append(" Room ").append(r.roomId).append(":\n");

            // -----------------------
            // Doors
            // -----------------------
            if (r.doors != null && !r.doors.isEmpty()) {
                sb.append("  Doors:\n");
                for (Door d : r.doors) {
                    sb.append("   - ")
                      .append(d.direction)
                      .append(" [")
                      .append(d.open ? "open" : "closed");

                    if (d.locked) sb.append(", locked");
                    if (d.remote) sb.append(", remote");

                    sb.append("]\n");
                }
            }

            // -----------------------
            // Mobs
            // -----------------------
            if (r.mobs != null && !r.mobs.isEmpty()) {
                sb.append("  Mobs:\n");
                for (Mob m : r.mobs) {
                    sb.append("   - Mob ")
                      .append(m.mobId)
                      .append(" (")
                      .append(m.percent).append("%)\n");

                    // Equipment
                    if (m.equipment != null && !m.equipment.isEmpty()) {
                        sb.append("     Equipment:\n");
                        for (EquipmentEntry eq : m.equipment) {
                            sb.append("      - Object ")
                              .append(eq.objectId);
                              sb.append(" - Slot ")
                              .append(eq.slot)      
                              .append(" (")
                              .append(eq.percent).append("%)\n");
                        }
                    }

                    // Inventory
                    if (m.inventory != null && !m.inventory.isEmpty()) {
                        sb.append("     Inventory:\n");
                        for (ZoneObject inv : m.inventory) {
                            sb.append("      - Object ")
                              .append(inv.objectId)
                              .append(" (")
                              .append(inv.percent).append("%)\n");
                        }
                    }
                }
            }

            // -----------------------
            // Objects
            // -----------------------
            if (r.objects != null && !r.objects.isEmpty()) {
                sb.append("  Objects:\n");
                for (ZoneObject o : r.objects) {
                    sb.append("   - Object ")
                      .append(o.objectId)
                      .append(" (")
                      .append(o.percent).append("%)\n");

                    // Container contents
                    if (o.contains != null && !o.contains.isEmpty()) {
                        sb.append("     Contains:\n");
                        for (ZoneObject child : o.contains) {
                            sb.append("      - Object ")
                              .append(child.objectId)
                              .append(" (")
                              .append(child.percent).append("%)\n");
                        }
                    }
                }
            }
        }

        return sb.toString();
    } // end

    
    default void applyDoors(Zone zone) {

        if (getRooms() == null) return;

        for (ZoneScript.Room sRoom : getRooms()) {

            mud.core.Room room = zone.getRoomById(sRoom.roomId);
            if (room == null) continue;

            for (ZoneScript.Door sDoor : sRoom.doors) {

                Direction dir = Direction.fromString(sDoor.direction);
                mud.core.Door door = room.getDoor(dir);

                if (door == null) {
                    System.err.println(
                        "⚠️ ZoneScript: No door found for room "
                        + sRoom.roomId + " direction " + sDoor.direction
                    );
                    continue;
                }

                // ✅ RESET STATE (this is the key part)
                door.setOpen(sDoor.open);
                door.setLocked(sDoor.locked);
                door.setRemote(sDoor.remote);

                System.out.println(
                    "[DEBUG] Door reset via ZoneScript: Room "
                    + sRoom.roomId + " " + dir
                    + " open=" + sDoor.open
                    + " locked=" + sDoor.locked
                    + " remote=" + sDoor.remote
                );
            }
        }
    }

    default void applyMobs(Zone zone) {

        for (ZoneScript.Room scriptRoom : getRooms()) {
            mud.core.Room room = zone.getRoom(scriptRoom.roomId);
            if (room == null) continue;

            if (scriptRoom.mobs == null || scriptRoom.mobs.isEmpty()) continue;

            for (ZoneScript.Mob mobDef : scriptRoom.mobs) {

                if (!rollPercent(mobDef.percent)) continue;

                mud.core.Mob mob = MobManager.createMobById(mobDef.mobId);
                if (mob == null) {
                    System.err.println("[ZoneScript] Failed to create Mob ID " + mobDef.mobId);
                    continue;
                }

                // --------------------
                // Place mob in room
                // --------------------
                mob.setRoom(room);
                mob.setCurrentRoom(room);
                room.addMob(mob);

                System.out.println("[ZoneScript] Spawned Mob ID " + mobDef.mobId +
                                   " in Room " + room.getId());

                // Optional: clear default equipment if your mobs auto-spawn with fists/weapons
                mob.clearEquipment(); // if this method exists (recommended)

                // --------------------
                // Equipment
                // --------------------
                if (mobDef.equipment != null && !mobDef.equipment.isEmpty()) {
                    for (EquipmentEntry eqDef : mobDef.equipment) {

                        if (!rollPercent(eqDef.percent)) continue;

                        ObjectItem item = createObjectTree(eqDef);
                        if (item == null) continue;

                        if (eqDef.slot != null) {
                        	if (eqDef.slot != null) {
                        	    mob.equip(eqDef.slot, item);
                        	} else {
                        	    mob.addItem(item);
                                System.err.println("[ZoneScript] Equip failed: Mob "
                                        + mobDef.mobId + " Slot " + eqDef.slot
                                        + " Object " + eqDef.objectId);
                        	}

                        } else {
                            mob.addItem(item);
                        }
                    }
                }

                // --------------------
                // Inventory
                // --------------------
                if (mobDef.inventory != null && !mobDef.inventory.isEmpty()) {
                    for (ZoneScript.ZoneObject objDef : mobDef.inventory) {

                        if (!rollPercent(objDef.percent)) continue;

                        ObjectItem item = createObjectTree(objDef);
                        if (item != null) {
                            mob.addItem(item);
                        }
                    }
                }
            }
        }
        
        
    } // end

    
    public default void clearEquipment() {
        for (EquipSlot slot : EquipSlot.values()) {
            Mob.unequip(slot);
        }
    } // end




    default void applyObjects(Zone zone) {

        for (ZoneScript.Room scriptRoom : getRooms()) {
            mud.core.Room room = zone.getRoom(scriptRoom.roomId);
            if (room == null) continue;

            if (scriptRoom.objects == null) continue;

            for (ZoneScript.ZoneObject objDef : scriptRoom.objects) {

                if (!rollPercent(objDef.percent)) continue;

                ObjectItem item = createObjectTree(objDef);
                if (item != null) {
                    room.addObject(item);
                }
            }
        }
    } // end

    private ObjectItem createObjectTree(ZoneScript.ZoneObject objDef) {

        if (objDef == null) return null;

        if (!rollPercent(objDef.percent)) {
            return null;
        }

        ObjectItem obj = ObjectManager.createObjById(objDef.objectId);
        if (obj == null) {
            System.err.println(
                "[ZoneScript] Failed to create object ID " + objDef.objectId
            );
            return null;
        }

        // --------------------
        // Handle contained objects (containers)
        // --------------------
        if (objDef.contains != null && !objDef.contains.isEmpty()) {

            // Ensure contents list exists
            if (obj.getContents() == null) {
                obj.setContents(new ArrayList<>());
            }

            for (ZoneScript.ZoneObject childDef : objDef.contains) {
                ObjectItem child = createObjectTree(childDef);
                if (child != null) {
                    obj.getContents().add(child);
                }
            }
        }

        return obj;
    } // end


    private boolean rollPercent(int percent) {
        if (percent >= 100) return true;
        if (percent <= 0) return false;
        return ThreadLocalRandom.current().nextInt(100) < percent;
    } // end

    
    
    
} // end
