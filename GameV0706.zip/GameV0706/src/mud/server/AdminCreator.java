package mud.server;

import mud.core.*;
import mud.config.Config;
import mud.system.PlayerLoader;


public class AdminCreator {

    public static void createAdmin() {
        String name = "admin";
        String password = "admin";
        
        

        // Get or create the default world
        World world = WorldManager.getOrCreateWorld(Config.DEFAULT_WORLD_ID);

        // Get or create the default zone
        Zone zone = WorldManager.createOrAttachZone(world, Config.DEFAULT_LOGIN_ZONE);

        // Ensure the default login room exists
        Room room = zone.getRoom(Config.DEFAULT_LOGIN_ROOM);
        if (room == null) {
            room = new Room(Config.DEFAULT_LOGIN_ROOM);
            room.setName("Starting Room");
            room.setZone(zone);
            zone.addRoom(Config.DEFAULT_LOGIN_ROOM, room);
        }

        // If admin already exists, don't overwrite
        if (PlayerLoader.exists(name)) {
            System.out.println("Admin player already exists.");
            return;
        }

        // Create admin player
        Player admin = new Player(name);
        admin.setPassword(password);
        admin.setPrivilegeLevel(2); // Admin level
        admin.setLevel(100);        // Max level for testing
        admin.setExp(999999);       // Optional bonus XP
        admin.setPlayerTitle("Administrator of the MUD");

        // Set location
        admin.setCurrentWorld(world);
        admin.setCurrentZone(zone);
        admin.setCurrentRoom(room);

        // Save admin
        PlayerLoader.save(admin);
        System.out.println("Admin player created.");
    }

}
