package mud.core;

public enum EffectType {
	AOE,
	BLEED,
    BLESSING,
    BLIND,
    BLUR,
    BUFF,
    BURN,
    
    FIRE_SHIELD, 
    FORCEFUL_HAND,
    CRUSHING_GRIP,
    CURSE,
    DETECT_INVISIBLE,
    INVISIBILITY,
    
	BERSERK,
    DISORIENT,
    FEAR,
    CHARM,
    CONFUSE,
    SILENCE,
    STUN,
    TAME,
    
    FROSTBITE, // ice type snare effects
    WEB, // shadow type snare effects
    HOLD, // arcane type snare effects
    ENTANGLE, // nature type snare effects
    ROOT, // earth type snare effects
    
    ICEWALL, // room-ice type wall (exit blocker) effect
    FIREWALL, // room-fire type wall (exit blocker) effect
    EARTHWALL, // room-earth type wall (exit blocker) effect
    METALWALL, // room-metal type wall (exit blocker) effect
    
    DOT,
    HOT,
    
    LEVITATE,
    MAGIC,
    POISON,
    REGENERATION,

    SANCTUARY,
    SHIELD,

    UNDERWATER_BREATHING,
    WATER_WALK,
     
    MIRROR_IMAGE,
    SHADOW_CLONE,
    BONE_SHIELD,
    
    PORTAL,
    
    // more effects as needed

;

	public EffectType getType() {
		return this;
	}
}