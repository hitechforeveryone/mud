package mud.core;

// TODO

public enum MobSubRace {
    NONE(MobRace.NONE),

    // Aquatic subraces
    FISH(MobRace.AQUATIC),
    MERFOLK(MobRace.AQUATIC),
    SEASERPENT(MobRace.AQUATIC),
    KRAKEN(MobRace.AQUATIC),
    SHARK(MobRace.AQUATIC),
    WHALE(MobRace.AQUATIC),
    CRUSTACEAN(MobRace.AQUATIC),
    CEPHALOPOD(MobRace.AQUATIC),
    

    // Beast subraces
    WOLF(MobRace.BEAST),
    BEAR(MobRace.BEAST),
    LARGECAT(MobRace.BEAST),
    BOAR(MobRace.BEAST),
    CERVID(MobRace.BEAST),
    BOVIDAE(MobRace.BEAST),
    SNAKE(MobRace.BEAST),
    LIZARD(MobRace.BEAST),
    

    // Critter subraces
    VERMIN(MobRace.CRITTER),
    INSECT(MobRace.CRITTER),
    RODENT(MobRace.CRITTER),

    // Dragonkin subraces
    TRUEDRAGON(MobRace.DRAGONKIN),
    DRAGONBLOOD(MobRace.DRAGONKIN),
    WYVERN(MobRace.DRAGONKIN),
    DRAKE(MobRace.DRAGONKIN),
    LANDDRAGON(MobRace.DRAGONKIN),
    WYRM(MobRace.DRAGONKIN),
    DRAGONKIN(MobRace.DRAGONKIN),
    DRAKONID(MobRace.DRAGONKIN),

    // Elemental subraces
    FIRE_ELEMENTAL(MobRace.ELEMENTAL),
    WATER_ELEMENTAL(MobRace.ELEMENTAL),
    EARTH_ELEMENTAL(MobRace.ELEMENTAL),
    AIR_ELEMENTAL(MobRace.ELEMENTAL),

    // Flying subraces
    HARPY(MobRace.FLYING),
    AVIAN(MobRace.FLYING),
    CLOUD(MobRace.FLYING),

    // Humanoid subraces
    HUMAN(MobRace.HUMANOID),
    ELF(MobRace.HUMANOID),
    HALFELF(MobRace.HUMANOID),
    DWARF(MobRace.HUMANOID),
    ORC(MobRace.HUMANOID),
    TROLL(MobRace.HUMANOID),
    TAUREN(MobRace.HUMANOID),
    WERECREATURE(MobRace.HUMANOID),

    // Giant subraces
    JOTUN(MobRace.GIANT),
    FIREGIANT(MobRace.GIANT),
    CLOUDGIANT(MobRace.GIANT),
    FROSTGIANT(MobRace.GIANT),
    STONEGIANT(MobRace.GIANT),
    STORMGIANT(MobRace.GIANT),
    HILLGIANT(MobRace.GIANT),
    OGRE(MobRace.GIANT),
    ETTIN(MobRace.GIANT),
    

    // Magic subraces
    ARCANE_BEING(MobRace.MAGIC),
    FAE(MobRace.MAGIC),
    ILLUSION(MobRace.MAGIC),

    
    // Mechanical subraces
    GOLEM(MobRace.MECHANICAL),
    AUTOMATON(MobRace.MECHANICAL),
    CLOCKWORK(MobRace.MECHANICAL),

    // Plant subraces
    VINEBEAST(MobRace.PLANT),
    TREANT(MobRace.PLANT),
    SPOREBORN(MobRace.PLANT),

    // Undead subraces
    SKELETON(MobRace.UNDEAD),
    GHOST(MobRace.UNDEAD),
    ZOMBIE(MobRace.UNDEAD),
    WIGHT(MobRace.UNDEAD),
    VAMPIRE(MobRace.UNDEAD),
    LICH(MobRace.UNDEAD);

    private final MobRace parentRace;

    MobSubRace(MobRace parentRace) {
        this.parentRace = parentRace;
    }

    public MobRace getParentRace() {
        return parentRace;
    }
}
