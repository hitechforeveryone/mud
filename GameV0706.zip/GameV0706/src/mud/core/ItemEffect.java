package mud.core;

public enum ItemEffect {
    BLESSED("Blessed", "✨"),
    CURSED("Cursed", "☠️"),
    BURNING("Burning", "🔥"),
    DETECT_INVISISBLE("Detect Invisible","💫"),
    INVISIBLE("Invisible", "🔍"),
    GLOW("Glow", "✨"),
    HIDE("Hide","🚫"),
    HOLYSYMBOL("Holy", "✨"),
    HUMMING("Humming", "🎵"),
    VORPAL("Vorpal", "🗡️"),
    POISONED("Poisoned", "☣️"),
    LEVITATE("Levitate","🌪️"),
    MAGIC("Magic", "🔮"),
    NO_DROP("No Drop", "🚫"),
    NOIDLE("No Idle", "⏳"),
    NOTAKE("No Take", "✋"),
    NOBREAK("No Break", "🚫"),
    NORENT("No Rent","✖️"),
    NOSUMMON("No Summon","🚫🌀"),
    NOCHARM("No Charm","🚫"),
    SNEAK("Sneak","👣"),
    BERSERK("Berserk", "🔥"),
    WATER_WALK("Water Walk","🌪️"),

    ;

    private final String displayName;
    private final String emoji;

    ItemEffect(String displayName, String emoji) {
        this.displayName = displayName;
        this.emoji = emoji;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getEmoji() {
        return emoji;
    }
}
