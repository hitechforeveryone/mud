package mud.core;

public enum MagicDamageType {
	PHYSICAL("Physical", "💪"),
	BLEED("Bleed", "🩸"),
    FIRE("Fire", "🔥"),
    WATER("Water", "💧"),
    AIR("Air", "🌪️"),
    EARTH("Earth", "🌍"),
    NATURE("Nature", "🌿"),
    ICE("Ice", "❄️"),
    LIGHTNING("Lightning", "⚡"),
    ARCANE("Arcane", "💫"),
    HOLY("Holy", "✨"),
    SHADOW("Shadow", "🌑"),
    POISON("Poison", "☠️"),
    METAL("Metal", "⚙️"),
    LIGHT("Light", "☀"),
    SHIELD("Shield","⛨"),
    MAGNIFIER("Magnifier","🔍"),
	NECROMANCY("Necromancy","💀"),
	SUMMON("Summon","🕳️"),
	
	RANGED("Ranged", "🏹"),
    // add more here if needed
;

    private final String prettyName;
    private final String icon;

    MagicDamageType(String prettyName, String icon) {
        this.prettyName = prettyName;
        this.icon = icon;
    }

    public String getPrettyName() {
        return prettyName;
    }

    public String getIcon() {
        return icon;
    }

    public static MagicDamageType fromString(String input) {
        if (input == null) return null;
        String normalized = input.trim().toLowerCase();

        switch (normalized) {
        case "physical": return PHYSICAL;
        case "bleed": return BLEED;
            case "fire": return FIRE;
            case "ice": return ICE;
            case "lightning": return LIGHTNING;
            case "arcane": return ARCANE;
            case "holy": return HOLY;
            case "shadow": return SHADOW;
            case "poison": return POISON;
            case "nature": return NATURE;
            case "water": return WATER;
            case "air": return AIR;
            case "earth": return EARTH;
            case "metal": return METAL;
            case "light": return LIGHT;
            case "shield": return SHIELD;
            case "magnifier": return MAGNIFIER;
            case "necromancy": return NECROMANCY;
            case "summon": return SUMMON;
            default: return null;
        }
    }
}
// end MagicDamageType
