package mud.core;

public enum MobRank {
	
    COMMON(1.0, 50),
    ELITE(1.25, 60),
    CHIEFTAIN(1.5, 70),
    LORD(1.75, 80),
    HIGH_LORD(2.0, 90),
    GREAT_LORD(2.25, 100),
    GRAND_LORD(2.5, 125),
    MYTHIC(3.0, 150),
    ARCHAIC_SPECIES(5.0, 200),
    GOD_RANK(7.5, 300);

    private final double multiplier;
    private final int tierValue;

    MobRank(double multiplier, int tierValue) {
        this.multiplier = multiplier;
        this.tierValue = tierValue;
    }

    public double getMultiplier() {
        return multiplier;
    }

    public int getTierValue() {
        return tierValue;
    }
}
