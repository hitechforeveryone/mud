package mud.Shop;

import mud.core.Mob;
import mud.core.ObjectItem;

public class ShopManager {

    private static final double BUY_MODIFIER = 0.5;   // Shopkeeper buys at 50% value by default
    private static final double SELL_MODIFIER = 1.5;  // Shopkeeper sells at 150% value

    public static boolean canBuy(Mob shopkeeper, ObjectItem item) {
        return shopkeeper.isShopKeeper(); // you can expand with logic for banned item types
    }

    public static int getBuyPrice(ObjectItem item) {
        return (int)(item.getTotalValueInCopper() * BUY_MODIFIER);
    }

    public static int getSellPrice(ObjectItem item) {
        return (int)(item.getTotalValueInCopper() * SELL_MODIFIER);
    }

    public static boolean buyFromPlayer(Mob player, Mob shopkeeper, ObjectItem item) {
        if (!canBuy(shopkeeper, item)) return false;

        int price = getBuyPrice(item);
        player.getInventory().removeItem(item);
        shopkeeper.getInventory().addItem(item);
        player.addCopper(price);
        return true;
    }

    public static boolean sellToPlayer(Mob player, Mob shopkeeper, ObjectItem item) {
        if (!shopkeeper.getInventory().contains(item)) return false;

        int price = getSellPrice(item);
        if (player.getTotalCopper() < price) return false;

        shopkeeper.getInventory().removeItem(item);
        player.getInventory().addItem(item);
        player.subtractCopper(price);
        return true;
    }
}
