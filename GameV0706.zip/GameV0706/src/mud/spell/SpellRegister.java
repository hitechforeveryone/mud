package mud.spell;

import java.util.*;
import mud.core.Profession;

public class SpellRegister {

    private static final SpellRegister INSTANCE = new SpellRegister();

    private final Map<Profession, Map<String, Spell>> spellsByProfession;

    private SpellRegister() {
        spellsByProfession = new EnumMap<>(Profession.class);
        for (Profession prof : Profession.values()) {
            spellsByProfession.put(prof, new HashMap<>());
        }
    }

    public static SpellRegister getInstance() {
        return INSTANCE;
    }


    // ---- Register a spell ----
    public void addSpell(Spell spell) {
        if (spell == null) 
            throw new IllegalArgumentException("Spell cannot be null");

        Set<Profession> profs = spell.getProfessions();

        // If no professions assigned → register for ALL professions
        if (profs == null || profs.isEmpty()) {
            for (Profession prof : spellsByProfession.keySet()) {
                spellsByProfession.get(prof)
                    .put(spell.getName().toLowerCase(), spell);
            }
            return;
        }

        // Otherwise, register only for assigned professions
        for (Profession prof : profs) {
            spellsByProfession.get(prof)
                .put(spell.getName().toLowerCase(), spell);
        }
    }


    // ---- Get a spell ----
    public Spell getSpell(Profession profession, String spellName) {
        if (profession == null || spellName == null) return null;
        return spellsByProfession
                .get(profession)
                .get(spellName.toLowerCase());
    }

    public Collection<Spell> getSpellsForProfession(Profession profession) {
        if (profession == null) return Collections.emptyList();
        return Collections.unmodifiableCollection(
            spellsByProfession.get(profession).values()
        );
    }

    /**
     * Removes a spell by name from all professions it belongs to.
     */
    public boolean removeSpell(Spell spell) {
        if (spell == null) return false;
        boolean removed = false;

        for (Profession prof : spell.getProfessions()) {
            removed |= spellsByProfession.get(prof)
                    .remove(spell.getName().toLowerCase()) != null;
        }
        return removed;
    }

    /**
     * Gets all spell names registered for a profession.
     */
    public Set<String> getSpellsFor(Profession profession) {
        return spellsByProfession.getOrDefault(profession, Collections.emptyMap()).keySet();
    }

    /**
     * Gets all spells available to a set of professions.
     */
    // ---- Convenience: get all spells for multiple professions ----
    public Set<Spell> getSpellsForProfessions(Set<Profession> profs) {
        Set<Spell> result = new HashSet<>();

        for (Profession prof : profs) {
            result.addAll(getSpellsForProfession(prof));
        }

        return result;
    }
    
    
} // end
