package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.spell.effects.CharmPersonEffect;

public class CharmPersonSpell implements Spell {

    private final int DURATION_TICKS = 10; // Example: lasts 10 ticks

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to charm.");
            return false;
        }

        if (target.hasEffect(EffectType.CHARM)) {
            caster.sendMessage(target.getMobName() + " is already charmed.");
            return false;
        }

        CharmPersonEffect effect = new CharmPersonEffect(target, caster, DURATION_TICKS);
        target.addEffect(effect);
        target.addEffect(EffectType.CHARM);

        target.sendMessage("You feel compelled to obey " + caster.getMobName() + "!");
        caster.sendMessage("You charm " + target.getMobName() + " to assist you.");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " charms " + target.getMobName() + "!");
        }

        return true;
    }

    @Override public String getName() { return "charm.person"; }
    @Override public String getDescription() { return "Makes the target assist you for a limited time."; }
    @Override public boolean cast(Mob c, Direction d) { return false; }
//    @Override public Object getProfession() { return null; }
    @Override public int getLevelRequired() { return 1; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.BARD, Profession.MAGE);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

}
