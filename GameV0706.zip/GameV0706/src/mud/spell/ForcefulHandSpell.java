package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.spell.effects.ForcefulHandEffect;

public class ForcefulHandSpell implements Spell {

    private static final int DURATION = 20; // about 20 ticks (customize)

    @Override
    public String getName() {
        return "forceful.hand";
    }

    @Override
    public String getDescription() {
        return "Summons a floating black spectral hand to strike your foes during combat.";
    }

    @Override
    public boolean cast(Mob caster, Mob unused) {

        if (caster.hasEffect(EffectType.FORCEFUL_HAND)) {
            caster.sendMessage("You already have a Forceful Hand following you.");
            return false;
        }

        ForcefulHandEffect effect = new ForcefulHandEffect(caster, DURATION);
        caster.addEffect(effect);

        caster.getRoom().broadcast(
            caster.getMobName() + " summons a massive black spectral hand!",
            caster
        );

        caster.sendMessage("A black Forceful Hand materializes beside you.");

        return true;
    }

    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isInstantCast() { return true; }
    @Override public int getLevelRequired() { return 1; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK, Profession.NECROMANCER); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
