// New PortalSpell.java
// Draft implementation based on TransportSpell structure, adapted to create room-to-room portals


    // PortalSpell.java
package mud.spell;

import mud.core.*;
import mud.spell.effects.PortalEffect;

import java.util.Set;
import java.util.UUID;

public class PortalSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
	
    @Override
    public String getName() {
        return "portal";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("You must specify someone to open a portal to.");
            return false;
        }

        Room casterRoom = caster.getCurrentRoom();
        Room targetRoom = target.getCurrentRoom();

 //       Room targetRoom = findRoomByNameOrId(args);

        if (targetRoom == null) {
            caster.sendMessage("The portal spell fails — no such destination exists.");
            return false;
        }

        if (targetRoom == casterRoom) {
            caster.sendMessage("The portal spell fails — you cannot portal to the same room you are in.");
            return false;
        }
        if (casterRoom.getZone().getWorld() != targetRoom.getZone().getWorld()) {
            caster.sendMessage("This small of a portal would not reach that far!");
            return false;
        }
        
        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A magical barrier prevents portals from forming here.");
            return false;
        }
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A portal cannot form near " + target.getMobName() + ".");
            return false;
        }

        
        
        int manaCost = 30;
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You lack the mana to create a portal.");
            return false;
        }
        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // Unique portal link
        String portalId = UUID.randomUUID().toString();

        // Duration scaling by caster level
        int duration = 5 + caster.getLevel();

        // Create effects
        PortalEffect castREff = new PortalEffect(casterRoom, targetRoom, portalId, duration);
        PortalEffect tarREff = new PortalEffect(targetRoom, casterRoom, portalId, duration);
        
        casterRoom.addRoomEffect(castREff);
        targetRoom.addRoomEffect(tarREff);
        

        casterRoom.broadcastToRoom("A swirling magical portal tears open in the air!");
        targetRoom.broadcastToRoom("A swirling magical portal tears open in the air!");

        caster.sendMessage("You open a shimmering portal linking your location to " + target.getMobName() + "!");
        target.sendMessage("A shimmering portal materializes nearby, linked to " + caster.getMobName() + "!");

        return true;
    }

    @Override
    public String getDescription() {
        return "Creates a temporary portal linking your room with the target's room.";
    }

    @Override public int getLevelRequired() { return 5; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end PortalSpell
