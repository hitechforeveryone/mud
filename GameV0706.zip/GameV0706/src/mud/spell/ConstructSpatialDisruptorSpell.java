package mud.spell;

import mud.core.*;
import mud.spell.effects.*;
import java.util.*;


public class ConstructSpatialDisruptorSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "construct.spatial.disruptor";
    }

    @Override
    public String getDescription() {
        return "Creates a localized spatial distortion that prevents summoning and portal magic within the room for a short duration.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {

        Room room = caster.getCurrentRoom();

        // Already active?
        if (room.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("The spatial fabric here is already disrupted.");
            return false;
        }

        // Mana cost
        int manaCost = 40;
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You lack the mana required to construct a spatial disruptor.");
            return false;
        }

        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // Duration in ticks
        int durationTicks = 5; // Adjust as needed

    
        room.broadcastToRoom(caster.capitalize(caster.getMobName()) + " casts " + getName().replace(".", " ") + " disrupting the local spatial field! Summoning magic becomes impossible.");

        // Schedule removal by ticks

		SpatialDisruptorEffect disrupt = new SpatialDisruptorEffect(room, durationTicks);
		disrupt.tick();
		
        return true;
    }

    @Override
    public int getLevelRequired() {
        return 0; // Fill in later
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MECHANIC);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}
}
// end
