package mud.spell;

import mud.core.*;
import mud.spell.effects.*;

import java.util.*;

public class FreedomOfWillSpell implements Spell {
	
	// TODO
	// spells for these effects not written yet
	
	
    private static final EffectType[] BLOCKED = {
        EffectType.CHARM,
        EffectType.CONFUSE,
        EffectType.FEAR,
        EffectType.SILENCE,
        EffectType.BERSERK,
    //    EffectType.TAME, // used for pets
        EffectType.DISORIENT, // saps, etc
    };
    
    private static final Set<Class<? extends Effect>> BLOCKED_CLASSES = Set.of(
    		SilenceEffect.class,
    	    BerserkEffect.class,
    	    FearEffect.class,
    	    CharmPersonEffect.class,
    	    ConfusionEffect.class,
    	    SapEffect.class // disorients
    	 //   TameEffect.class // used for pets
    	);


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }
        
        boolean removedAny = false;

        Iterator<Effect> it = target.getActiveEffects().iterator();

        while (it.hasNext()) {
            Effect eff = it.next();

            // TODO
            // 
            if (eff instanceof SilenceEffect ||
                eff instanceof FearEffect ||
                eff instanceof BerserkEffect ||
                eff instanceof ConfusionEffect ||
                eff instanceof CharmPersonEffect ||
                eff instanceof SapEffect) 
            {

                for (Class<? extends Effect> clazz : BLOCKED_CLASSES) {
                    if (clazz.isInstance(eff)) {
                      	it.remove();
                        eff.onRemove();
                        break;
                    }
                }
            	
                target.getCurrentRoom().broadcastToRoom(eff.getName() + " has been removed.");
            	
                it.remove();
                eff.onRemove(); // if your system supports callbacks
                
                removedAny = true;
               
            }
            return true;
        }


        if (!removedAny) {
            caster.sendMessage(target.getMobName() + " has no mind-altering effects to remove.");
            return false;
        }

        return false;
    }

    @Override public String getName() { return "freedom.of.will"; }
    @Override public boolean cast(Mob c, Direction d) { return false; }
    @Override public String getDescription() { return "Removes mind-alter effects."; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
