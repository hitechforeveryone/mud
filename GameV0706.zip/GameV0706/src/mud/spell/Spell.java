// Spell.java (Interface)
package mud.spell;

import java.util.Set;
import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

public interface Spell {
    String getName();
    String getDescription();
    
    boolean cast(Mob caster, ObjectItem obj);
    boolean cast(Mob caster, Mob target);
    boolean cast(Mob caster, Direction tarDir);
    Set<Profession> getProfessions();
	int getLevelRequired();
	boolean isInstantCast();  // can be used without cast command // kick, track, rescue, monk spells, etc
	boolean isAoE(); // 
	boolean isSelfTarget(); // self or room target spells
	boolean isDirectional(); // for wall/barrier type spells
	boolean isAbility(); // for abilities
	boolean isNPCCastable();
	int getManaCost();
}