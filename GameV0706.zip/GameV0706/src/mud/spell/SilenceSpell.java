package mud.spell;

import mud.spell.effects.SilenceEffect;
import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;

import java.util.Random;
import java.util.Set;

public class SilenceSpell implements Spell {
    private static final Random random = new Random();
    private final MagicDamageType damageType = MagicDamageType.AIR;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "silence";
    }

    @Override
    public String getDescription() {
        return "Silences your foe, preventing them from casting spells for a short time.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || target == null) return false;

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        // Prevent casting on self unless debugging or testing
        if (caster == target) {
            if (caster instanceof Player player) {
                player.sendMessage("You cannot silence yourself!");
            }
            return false;
        }

        // Chance to succeed: based on caster Intellect vs target Intellect (or Stamina)
        int chance = 50 + (caster.getIntellect() - target.getIntellect()) * 5;
        chance = Math.max(5, Math.min(chance, 95)); // clamp 5–95%
        int roll = random.nextInt(100) + 1;

        if (roll <= chance) {
            int silenceTime = random.nextInt(3) + 1;
            SilenceEffect silence = new SilenceEffect(target, silenceTime);
            target.addEffect(silence);
            target.addEffect(EffectType.SILENCE);

            if (caster instanceof Player playerCaster) {
                playerCaster.sendMessage("You silence " + target.getMobName() + " with a " + getName() + " " + icon + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You are silenced by a " + getName() + " " + icon + " from " + caster.getMobName() + "!");
         
                // set target and combat status
                if (target.getTarget() == null) {
                	target.setTarget(caster);
                	target.setInCombat(true);
                	caster.setTarget(target);
                	caster.setInCombat(true);
                }
            }

            return true;
        } else {
            if (caster instanceof Player) {
                caster.sendMessage("Your " + getName() + " " + icon + " fails to silence them.");
            }
            if (target instanceof Player) {
                target.sendMessage(caster.getMobName() + " tried to silence you with a " + getName() + " " + icon + " but failed.");
            }
            return false;
        }
    }

    @Override
    public int getLevelRequired() {
        return 3;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.MAGE, Profession.NECROMANCER, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
// end
