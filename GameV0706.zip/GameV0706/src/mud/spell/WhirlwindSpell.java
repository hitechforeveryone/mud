package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;
import mud.core.Room;

import java.util.Set;

import mud.core.Direction;
import mud.core.EquipSlot;
import mud.core.MagicDamageType;

public class WhirlwindSpell implements Spell {

    private final MagicDamageType damageType = MagicDamageType.AIR;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "whirlwind";
    }

    @Override
    public String getDescription() {
        return "Unleashes a violent spinning attack, striking all enemies in the room who are not in your party.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
    	int baseDamage = 0;
        Room room = caster.getCurrentRoom();
        
        if (room == null) {
            caster.sendMessage("You cannot cast whirlwind here.");
            return false;
        }

        if (caster.getEquippedItem(EquipSlot.MAINHAND) == null) {
        	caster.sendMessage("You have no weapon equipped.");
        	return false;
        }
        else {
        	baseDamage = caster.getEquippedItem(EquipSlot.MAINHAND).rollDamage() + (caster.getAgility()/2);
        }
        
        caster.sendMessage("You unleash a raging " + getName() + icon + "!");
        room.broadcastExcept(caster.getMobName() + " unleashes a raging " + getName() + icon + "!", caster, null);

        for (Mob m : room.getMobs()) {
            if (m == caster) continue;

            boolean isAlly = false;
            if (caster instanceof Player pCaster) {
                if (pCaster.getParty() != null && pCaster.getParty().getMembers().contains(m)) {
                    isAlly = true;
                }
            }

            if (isAlly) {
                continue;
            }

            int dmg = baseDamage;
            m.takeDamage(dmg, damageType);

            m.sendMessage("You are slashed by " + caster.getMobName() + "'s " + getName() + icon + ", taking " + dmg + " " + typeName + " damage!");
            room.broadcastExcept(m.getMobName() + " is caught in the " + getName() + icon + ", taking damage!", m, caster);

            if (m.getTarget() == null) {
                m.setTarget(caster);
                caster.setTarget(m);
            }
        }

        return true;
    }


    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

	@Override
	public boolean isAoE() {
		
		return true;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.WARRIOR, Profession.ROGUE);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end
