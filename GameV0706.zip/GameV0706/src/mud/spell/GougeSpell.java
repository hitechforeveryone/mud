package mud.spell;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.BleedEffect;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.EquipSlot;

public class GougeSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.BLEED;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "gouge";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        EquipSlot slot = EquipSlot.MAINHAND;

        if (target == null) {
            caster.sendMessage("There is no target to gouge.");
            return false;
        }

        if (caster.getEquippedItem(slot) != null) {
            caster.sendMessage("You must be unarmed to use Gouge.");
            return false;
        }


        int casterStrength = caster.getStrength();
        int casterAgility = caster.getAgility();
        int baseDamage = 3; // smaller base for unarmed
        int tickDamage = (int) (baseDamage + (casterStrength + casterAgility) * 0.15); // 15% of combined stats
        int totalTicks = 4; // bleed duration

        BleedEffect effect = new BleedEffect(target, tickDamage, totalTicks);
        target.addEffect(effect);
        target.addEffect(EffectType.BLEED);

        caster.sendMessage("You " + getName() + icon + " " + target.getMobName() + ", causing them to bleed!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + getName() + "s you, causing you to " + typeName + "!");
            target.getCurrentRoom().broadcastExcept(caster.getMobName() +  getName() + "s " + target.getMobName() + ", causing them to " + typeName + "!", caster, target);
        } else {
            caster.getCurrentRoom().broadcastExcept(caster.getMobName() +  getName() + "s themselves, bleeding from their wounds!", caster, null);
        }

        return true;
    }

    @Override
    public String getDescription() {
        return "Gouges the target while unarmed, causing them to bleed over time. Damage scales with caster's Strength and Agility.";
    }

    @Override
    public int getLevelRequired() {
        return 0;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MONK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
} // end
