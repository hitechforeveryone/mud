package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.MobAffectFlag;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.ItemEffect;
import mud.core.MagicDamageType;

public class SummonSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
	
    @Override
    public String getName() {
        return "summon";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("You must specify someone to summon.");
            return false;
        }

        // 🧠 Check if target is in the same zone
        if (!caster.getCurrentRoom().getZone().equals(target.getCurrentRoom().getZone())) {
            caster.sendMessage(target.getMobName() + " is not in this zone.");
            return false;
        }

        // 🧠 Check if target is in the same world
        if (!caster.getWorld().equals(target.getWorld())) {
            caster.sendMessage(target.getMobName() + " is not in this world.");
            return false;
        }        
        
        // 🚫 Check if target room forbids summoning
        Room targetRoom = target.getCurrentRoom();
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A strange force prevents you from summoning " + target.getMobName() + ".");
            return false;
        }
        
        // 🚫 Check if target room forbids summoning
        Room casterRoom = caster.getCurrentRoom();
        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A strange force prevents you from summoning " + target.getMobName() + ".");
            return false;
        }

        // 🚫 Check if target has NOSUMMON affect
        if (target.hasAffect(MobAffectFlag.NOSUMMON)) {
            caster.sendMessage(target.getMobName() + " resists your summoning attempt!");
            return false;
        }

        // 🚫 Check if target has NOSUMMON item equipped
        for (ObjectItem equipped : target.getEquipment().values()) {
            if (equipped.hasEffect(ItemEffect.NOSUMMON)) {
                caster.sendMessage(target.getMobName() + " cannot be summoned due to magical protection.");
                return false;
            }
        }

        // 🔮 Deduct mana
        int manaCost = 20;
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You do not have enough mana to cast Summon.");
            return false;
        }
        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // ✨ Perform summon
        target.getCurrentRoom().removeMob(target);
        caster.getCurrentRoom().addMob(target);
        
        target.setCurrentRoom(caster.getCurrentRoom());
        target.setRoom(caster.getCurrentRoom());
        

        // 💬 Messaging
        caster.sendMessage("You cast " + getName() + " " + icon + ", pulling " + target.getMobName() + " to your side!");
        target.sendMessage("You feel a magical pull and suddenly appear next to " + caster.getMobName() + "!");
        caster.getCurrentRoom().broadcastExcept(target.getMobName() + " suddenly appears out of thin air!", caster, target);
        targetRoom.broadcastToRoom(target.getMobName() + " disappears in a flash of light!");

        return true;
    }

    @Override
    public String getDescription() {
        return "Pulls a target from elsewhere in the current zone to your location, unless magically protected.";
    }

    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end SummonSpell
