package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.EntangleEffect;

public class EntangleSpell implements Spell {

	
    private final MagicDamageType damageType = MagicDamageType.NATURE;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
    
    private int durationTicks;


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        // Check if target is already entangled
        if (target.hasEffect(EffectType.ENTANGLE)) {
            caster.sendMessage(target.getMobName() + " is already trapped in an " + getName().replace(".", " ") + icon + ".");
            return false;
        }

        durationTicks = 5;
        
        // Apply WebEffect
        EntangleEffect web = new EntangleEffect(target, durationTicks);
        target.addEffect(web);
        target.addEffect(EffectType.ENTANGLE);

        target.sendMessage("Binding roots from " + getName().replace(".", " ") + icon + " wrap around you, preventing movement!");
        caster.sendMessage("You entangle " + target.getMobName() + " in a " + getName().replace(".", " ") + icon + "!");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " casts a " + getName().replace(".", " ") + icon + " on " + target.getMobName() + "!");
        }
        return true;
    }

	@Override
	public String getName() {
		return "entangle";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// false, must be cast on mob
		return false;
	}


	@Override
	public int getLevelRequired() {
		// 
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// 
		return false;
	}

	@Override
	public boolean isAoE() {
		// 
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// 
		return false;
	}

	@Override
	public boolean isDirectional() {
		// 
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.HUNTER, Profession.DRUID, Profession.SHAMAN); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
