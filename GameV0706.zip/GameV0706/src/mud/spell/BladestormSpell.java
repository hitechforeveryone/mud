package mud.spell;

import mud.core.*;
import mud.spell.effects.BladestormEffect;

import java.util.Set;

public class BladestormSpell implements Spell {

    private static final int MANA_COST = 40;
    private static final int DURATION_TICKS = 6;

    @Override
    public String getName() {
        return "bladestorm";
    }

    @Override
    public String getDescription() {
        return "Unleash a rain of whirling weapons that strikes all enemies each tick.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {

        // Must have a weapon equipped
        ObjectItem weapon = caster.getEquippedItem(EquipSlot.MAINHAND);
        if (weapon == null) {
            caster.sendMessage("You must wield a weapon to unleash a bladestorm.");
            return false;
        }

        int baseDamage =
                (int) (weapon.rollDamage() / 4.0 + caster.getStrength() / 2.0);

        int scaledDamage =
                (int) (baseDamage * caster.getRank().getMultiplier());

        new BladestormEffect(
                caster,
                weapon,
                scaledDamage,
                DURATION_TICKS
        );

        caster.sendMessage(
                "You unleash a furious rain of " +
                weapon.getWeaponType() + "s " +
                weapon.getDamageTypePretty() + "!"
        );

        caster.getCurrentRoom().broadcastExcept(
                caster.getMobName() +
                " unleashes a furious rain of " +
                weapon.getWeaponType() + "s " +
                weapon.getDamageTypePretty() + "!",
                caster,
                null
        );

        return true;
    }

    // ---------------- Spell Metadata ----------------

    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public int getManaCost() {
        return MANA_COST;
    }

    @Override
    public boolean isAoE() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true; // originates from caster
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

    @Override
    public boolean isDirectional() {
        return false;
    }

    @Override
    public boolean isAbility() {
        return true; // martial AoE, not a chant
    }

    @Override
    public boolean isNPCCastable() {
        return true;
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.WARRIOR, Profession.ROGUE);
    }

    // ---------------- Unused Cast Paths ----------------

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        return false;
    }
}
