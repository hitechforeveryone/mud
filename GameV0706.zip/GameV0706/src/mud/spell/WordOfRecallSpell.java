package mud.spell;

import mud.core.*;
import mud.scripting.ZoneScript;

import java.util.List;
import java.util.Random;
import java.util.Set;

public class WordOfRecallSpell implements Spell {

    private static final Random RANDOM = new Random();

    @Override
    public String getName() {
        return "word.of.recall";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Zone currentZone = caster.getCurrentRoom().getZone();
        if (currentZone == null) {
            caster.sendMessage("You are not in a zone and cannot recall.");
            return false;
        }

        ZoneScript script = currentZone.getScript();
        if (script == null || script.getRecallNodes().isEmpty()) {
            caster.sendMessage("No recall nodes are defined in this zone.");
            return false;
        }

        // Pick a random recall node
        List<ZoneScript.RecallNode> nodes = script.getRecallNodes();
        ZoneScript.RecallNode targetNode = nodes.get(RANDOM.nextInt(nodes.size()));

        Room targetRoom = currentZone.getRoom(targetNode.roomId);
        if (targetRoom == null) {
            caster.sendMessage("The recall node is invalid. Teleportation failed.");
            return false;
        }

        Room casterRoom = caster.getCurrentRoom();
        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A magical barrier prevents you from recalling from this room.");
            return false;
        }
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A magical barrier prevents you from recalling to that location.");
            return false;
        }

        // Deduct mana
        int manaCost = getManaCost();
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You do not have enough mana to cast Word of Recall.");
            return false;
        }
        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // Perform teleport
        casterRoom.removeMob(caster);
        targetRoom.addMob(caster);
        caster.setCurrentRoom(targetRoom);
        caster.setRoom(targetRoom);

        // Messaging
        caster.sendMessage("You speak the words of recall and vanish in a flash of light!");
        casterRoom.broadcastToRoom(caster.getMobName() + " vanishes in a flash of light!");
        targetRoom.broadcastExcept(caster.getMobName() + " suddenly appears!", caster);

        // Update view for player if applicable
        if (caster instanceof Player) {
            mud.commands.CommandProcessor.lookRoom((Player) caster, targetRoom);
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        return false; // not object-targeted
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false; // not directional
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MAGE, Profession.WARLOCK);
    }

    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return true; // only affects caster
    }

    @Override
    public boolean isDirectional() {
        return false;
    }

    @Override
    public boolean isAbility() {
        return false;
    }

    @Override
    public boolean isNPCCastable() {
        return false;
    }

    @Override
    public int getManaCost() {
        return 20;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

}
