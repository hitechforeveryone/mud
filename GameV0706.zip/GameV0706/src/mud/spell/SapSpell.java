package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.SapEffect;

public class SapSpell implements Spell {

    private final int duration = 4; // short CC

    @Override
    public String getName() {
        return "sap";
    }

    @Override
    public String getDescription() {
        return "Saps the target, leaving them disoriented and unable to focus for a short duration.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no one to sap.");
            return false;
        }

        if (target.hasEffect(EffectType.DISORIENT)) {
            caster.sendMessage(target.getMobName() + " is already disoriented.");
            return false;
        }

        SapEffect effect = new SapEffect(target, duration);
        target.addEffect(effect);

        // CC applied
        target.setTarget(null);
        target.setCurrentTarget(null);

        caster.sendMessage("You strike swiftly, sapping " + target.getMobName() + "!");
        target.sendMessage("A sudden blow leaves you disoriented!");

        if (caster.getRoom() != null) {
            caster.getRoom().broadcastExcept(
                caster.getMobName() + " saps " + target.getMobName() + "!",
                caster, target
            );
        }

        return true;
    }

    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public int getLevelRequired() { return 1; }

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.ROGUE, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
