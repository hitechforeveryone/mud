package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.BlindEffect;

public class BlindSpell implements Spell {

    private final MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();

    @Override
    public boolean cast(Mob caster, Mob target) {

        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        // Already blind?
        if (target.hasEffect(EffectType.BLIND)) {
            caster.sendMessage(target.getMobName() + " is already blinded.");
            return false;
        }

        int durationTicks = 6; // adjust as needed

        BlindEffect eff = new BlindEffect(target, durationTicks);
        target.addEffect(eff);
        target.addEffect(EffectType.BLIND);

        target.sendMessage("A wave of darkness " + icon + " washes over your eyes — you are BLINDED!");
        caster.sendMessage("You blind " + target.getMobName() + icon + "!");

        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(
                caster.getMobName() + " casts a " + getName() + icon + " on " + target.getMobName() + "!"
            );
        }

        return true;
    }

    @Override public String getName() { return "blind"; }
    @Override public String getDescription() { return "Blinds the target, preventing them from seeing."; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MAGE, Profession.PRIEST, Profession.BARD, Profession.WARLOCK); // multiple
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
