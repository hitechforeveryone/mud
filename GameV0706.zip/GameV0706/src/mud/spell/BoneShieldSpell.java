package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.BoneShieldEffect;

public class BoneShieldSpell implements Spell {
	
    private final MagicDamageType damageType = MagicDamageType.NECROMANCY;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
	
	
    @Override
    public String getName() {
        return "bone.shield";
    }

    @Override
    public String getDescription() {
        return "Creates several floating bones that may absorb incoming attacks.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Self-target only
        if (caster == null) return false;

        int min = 4;
        int max = 6;

        int count = min + (int)(Math.random() * ((max - min) + 1));

        BoneShieldEffect existing = caster.getEffect(BoneShieldEffect.class);
        if (existing != null) {
            caster.sendMessage("Your bone shield's bones swirl and reform around you." + icon);
 
            existing.addImages(count);
        } else {
            caster.addEffect(new BoneShieldEffect(caster, count, 20)); // 20 ticks
            caster.addEffect(EffectType.BONE_SHIELD);
        }
        
        target.addEffect(EffectType.BONE_SHIELD);
        
        caster.sendMessage("Multiple floating bones of surround you!" + icon);
        caster.getRoom().broadcastExcept(
            caster.getMobName() + " multiple floating bones suddenly surround " + caster.getMobName() + "!" + icon, caster
        );

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 6;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean isAoE() { return false; }

    @Override
    public boolean cast(Mob caster, Direction dir) { return false; }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.NECROMANCER); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
