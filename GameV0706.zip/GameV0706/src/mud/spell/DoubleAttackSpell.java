package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.DoubleAttackEffect;

public class DoubleAttackSpell implements Spell {

    @Override
    public String getName() {
        return "double_attack";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually.
        applyPassive(caster);
        return true;
    }

    /**
     * Apply passive effect if missing.
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("double_attack")) {
            mob.addEffect(new DoubleAttackEffect(mob));
        }
    }

    @Override
    public String getDescription() {
        return "Grants the ability to occasionally strike twice in a single attack.";
    }

    @Override
    public int getLevelRequired() {
        return 0; // Adjust as needed for balance
    }

    @Override
    public boolean isInstantCast() {
        return true; // Passive, always active once applied
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.WARRIOR, Profession.ROGUE, Profession.PALADIN); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end
