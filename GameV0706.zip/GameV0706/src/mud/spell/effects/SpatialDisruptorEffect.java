package mud.spell.effects;

import java.util.*;

import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;

public class SpatialDisruptorEffect implements Effect {

    private static final List<SpatialDisruptorEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Room room;
    private final int totalTicks;
    private int ticksPassed = -1;
    private boolean applied = false;

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    public SpatialDisruptorEffect(Room room, int totalTicks) {
        this.room = room;
        this.totalTicks = totalTicks;

        // Register effect
        ACTIVE_EFFECTS.add(this);
    }

    // Called once per global tick
    public static void tickAll() {
        Iterator<SpatialDisruptorEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            SpatialDisruptorEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        ticksPassed++;

        // FIRST tick → apply effect
        if (!applied) {
            applied = true;
            room.setFlag(RoomFlag.NOSUMMON);
            room.broadcastToRoom("The air distorts and crackles with unstable spatial energy " + icon + "!");
            return;
        }

        // MIDDLE ticks → maybe add atmospheric messages
        if (ticksPassed < totalTicks) {
            if (ticksPassed % 5 == 0) { // periodic message every 5 ticks
                room.broadcastToRoom("Spatial interference continues to ripple through the room " + icon + ".");
            }
        }

        // END tick → remove effect & announce resolution
        if (ticksPassed == totalTicks) {
            room.removeFlag(RoomFlag.NOSUMMON);
            room.broadcastToRoom("The spatial tension fades, restoring normal summoning conditions." + icon);
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    public Room getTargetRoom() {
        return room;
    }

    @Override
    public String getName() {
        return "SpatialDisruptor";
    }

    @Override
    public EffectType getType() {
        return EffectType.SILENCE;
    }

    @Override
    public int getDuration() {
        return totalTicks;
    }

    // Not relevant for room effects but required by the interface
    @Override public int getHpBonus() { return 0; }
    @Override public int getStrengthBonus() { return 0; }
    @Override public mud.core.Mob getTarget() { return null; }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}

} // end
