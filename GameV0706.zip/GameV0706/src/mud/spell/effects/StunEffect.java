package mud.spell.effects;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class StunEffect implements Effect{
    private static final CopyOnWriteArrayList<StunEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();

    private final Mob target;
    private final int totalTicks;
    private int ticksPassed = 0;
    private final String icon = "\u2728"; // ✨ for stun indicator

    public StunEffect(Mob target, int durationTicks) {
        this.target = target;
        this.totalTicks = durationTicks;
        ACTIVE_EFFECTS.add(this);
        this.target.addEffect(this);
        this.target.addEffect(EffectType.STUN);
        this.target.sendMessage("You are stunned and cannot act! " + icon);
        this.target.getCurrentRoom().broadcastExcept(target.getMobName() + " is stunned! " + icon, target, null);
    }

    public static void tickAll() {
        Iterator<StunEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            StunEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
            	ACTIVE_EFFECTS.remove(effect);
            	effect.target.removeEffect(EffectType.STUN);
                effect.target.removeEffect(effect.getName());
                effect.target.sendMessage("You recover from the stun. " + effect.icon);
                if (effect.target.getCurrentRoom() != null) {
                    effect.target.getCurrentRoom().broadcastExcept(effect.target.getMobName() + " recovers from the stun.", effect.target, null);
                }
            }
        }
    }

    public void tick() {
        ticksPassed++;
        // Nothing else per tick, stun is just a lockout
    }

    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    public String getName() {
        return "stun";
    }

	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return EffectType.STUN;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
} // end StunEffect
