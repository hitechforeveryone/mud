package mud.spell.effects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

public class SapEffect implements Effect {

    private static final List<SapEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private int remainingTicks;

    public SapEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Sap";
    }

    @Override
    public EffectType getType() {
        return EffectType.DISORIENT;  // SAP = disorient/stun-lite
    }

    @Override
    public void tick() {
        if (target == null || target.getRoom() == null) {
            remainingTicks = 0;
            expire();
            return;
        }

        // Prevents combat actions
        target.setTarget(null);
        target.setCurrentTarget(null);

        target.sendMessage("You are disoriented and struggling to regain your senses...");
        target.getRoom().broadcastExcept(
                target.getMobName() + " staggers, looking disoriented.",
                target);

        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }

    public static void tickAll() {
        Iterator<SapEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            SapEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
    private void expire() {
        target.removeEffect(EffectType.DISORIENT);
        target.sendMessage("You shake off the disorientation and regain awareness.");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() {
        return null;
    }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
