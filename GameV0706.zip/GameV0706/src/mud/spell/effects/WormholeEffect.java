
// WormholeEffect.java
package mud.spell.effects;

import mud.core.*;
import java.util.ArrayList;
import java.util.List;

public class WormholeEffect implements Effect {

    static MagicDamageType damageType = MagicDamageType.SUMMON;
    static String icon = damageType.getIcon();
    static String typeName = damageType.getPrettyName().toLowerCase();
	
    private static List<WormholeEffect> ACTIVE = new ArrayList<>();

    private Room fromRoom;
    private Room toRoom;
    private String id;
    public int duration;

    public WormholeEffect(Room fromRoom, Room toRoom, String id, int duration) {
        this.fromRoom = fromRoom;
        this.toRoom = toRoom;
        this.id = id;
        this.duration = duration;
        ACTIVE.add(this);
    }

    public Room getDestinationRoom() { return toRoom; }

    public String getWormholeId() { return id; }

    @Override
    public String getName() { return "wormhole"; }

    @Override
    public void onApply(Room room) {
        room.broadcastToRoom("Metal gears twist and spark as a wormhole stabilizes.");
    }

    public void onTick(Room room) {
        duration--;
        if (duration <= 0) expire(room);
    }

    public void expire(Room room) {
        room.broadcastToRoom("The mechanical wormhole grinds shut, gears screeching!" + icon);
        room.removeRoomEffect(this);
    }

    @Override
    public boolean isExpired() { return duration <= 0; }

    @Override
    public void tick() {}

    public static void tickAll() {
        for (World world : WorldManager.getAllWorlds()) {
            for (Zone zone : world.getZones()) {
                for (Room room : zone.getRooms().values()) {
                    List<Effect> effects = room.getEffects();
                    if (effects == null || effects.isEmpty()) continue;

                    List<Effect> remove = new ArrayList<>();

                    for (Effect e : effects) {
                        if (e instanceof WormholeEffect wh) {
                            wh.duration--;
                            if (wh.duration <= 0) remove.add(wh);
                        }
                    }

                    for (Effect e : remove) {
                        effects.remove(e);
                        room.broadcastToRoom("The wormhole collapses with a metallic shriek!" + icon);
                        room.removeRoomEffect(e);
                    }
                }
            }
        }
    }

    @Override public Mob getTarget() { return null; }
    @Override public EffectType getType() { return EffectType.PORTAL; }
    @Override public int getDuration() { return duration; }
    @Override public Direction getDirection() { return null; }

	public static MagicDamageType getDamageType() {
		return damageType;
	}

	public static void setDamageType(MagicDamageType damageType) {
		WormholeEffect.damageType = damageType;
	}

	public static String getIcon() {
		return icon;
	}

	public static void setIcon(String icon) {
		WormholeEffect.icon = icon;
	}

	public static String getTypeName() {
		return typeName;
	}

	public static void setTypeName(String typeName) {
		WormholeEffect.typeName = typeName;
	}

	public static List<WormholeEffect> getActive() {
		return ACTIVE;
	}

	public static void setActive(List<WormholeEffect> active) {
		ACTIVE = active;
	}

	public Room getFromRoom() {
		return fromRoom;
	}

	public void setFromRoom(Room fromRoom) {
		this.fromRoom = fromRoom;
	}

	public Room getToRoom() {
		return toRoom;
	}

	public void setToRoom(Room toRoom) {
		this.toRoom = toRoom;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
} // end
