package mud.spell.effects;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;
import mud.core.EffectType;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class SilenceEffect implements Effect{
    private static final CopyOnWriteArrayList<SilenceEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();

    MagicDamageType damageType = MagicDamageType.AIR;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    private final Mob target;
    private final int totalTicks;
    private int ticksPassed = 0;

    public SilenceEffect(Mob target, int durationTicks) {
        this.target = target;
        this.totalTicks = durationTicks;
        ACTIVE_EFFECTS.add(this);
        
        this.target.addEffect(this);
        this.target.addEffect(EffectType.SILENCE);
        
        this.target.sendMessage("You are silenced and cannot do that! " + icon);
        if (target.getCurrentRoom() != null) {
        	target.getCurrentRoom().broadcastExcept(target.getMobName() + " is silenced!", target, null);
        	}
    }

    public static void tickAll() {
        Iterator<SilenceEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            SilenceEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
            	ACTIVE_EFFECTS.remove(effect);
            	effect.target.removeEffect(EffectType.SILENCE);
                effect.target.removeEffect(effect.getName());
                effect.target.sendMessage("You recover the ability to speak. " + effect.icon);
                if (effect.target.getCurrentRoom() != null) {
                    effect.target.getCurrentRoom().broadcastExcept(effect.target.getMobName() + " recovers from the silence.", effect.target, null);
                }
            }
        }
    }

    public void tick() {
        ticksPassed++;
        // Nothing else per tick, stun is just a lockout
    }

    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    public String getName() {
        return "silence";
    }

	@Override
	public Mob getTarget() {
		return target;
	}

	@Override
	public EffectType getType() {
		return EffectType.SILENCE;
	}

	@Override
	public int getDuration() {
		return totalTicks - ticksPassed;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
} // end StunEffect
