package mud.spell.effects;

import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ForcefulHandEffect implements Effect {

    private static final Random RNG = new Random();
    private static final List<ForcefulHandEffect> ACTIVE = new ArrayList<>();

    private final Mob caster;
    private int remainingTicks;

    public ForcefulHandEffect(Mob caster, int durationTicks) {
        this.caster = caster;
        this.remainingTicks = durationTicks;
        ACTIVE.add(this);
    }

    @Override
    public String getName() {
        return "Forceful Hand";
    }

    @Override
    public EffectType getType() {
        return EffectType.FORCEFUL_HAND;
    }

    @Override
    public void tick() {
        if (caster == null || caster.getCurrentRoom() == null) {
            remainingTicks = 0;
            expire();
            return;
        }

        Mob target = caster.getCurrentTarget();
        if (target != null && target.getCurrentRoom() == caster.getCurrentRoom()) {

            // Chance to knock down
            if (RNG.nextInt(100) < 20) { // 20% chance each tick
                caster.getCurrentRoom().broadcast(
                    "A massive black spectral hand SLAMS " + target.getMobName() + " to the ground!", null
                );

                target.sendMessage("The Forceful Hand knocks you down!");
                StunEffect STUN = new StunEffect(target, 1);
                target.addEffect(STUN);
                target.addEffect(EffectType.STUN);
            }
        }

        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }

    private void expire() {
        if (caster != null) {
            caster.removeEffect(EffectType.FORCEFUL_HAND);
            caster.sendMessage("Your spectral Forceful Hand fades away.");
        }
        ACTIVE.remove(this);
    }

    public static void tickAll() {
        Iterator<ForcefulHandEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            ForcefulHandEffect e = it.next();
            e.tick();
            if (e.isExpired()) it.remove();
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return caster; // effect is attached to caster
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() { return null; }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
