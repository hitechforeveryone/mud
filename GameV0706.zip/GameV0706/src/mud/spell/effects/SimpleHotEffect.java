// mud/spell/effects/SimpleHotEffect.java
package mud.spell.effects;

import mud.core.Mob;

public class SimpleHotEffect extends HealOverTimeEffect {
    private int remainingTicks;
    private final int healPerTick;

    public SimpleHotEffect(Mob target, int healPerTick, int durationTicks) {
        super(target, durationTicks, durationTicks); // explicitly call superclass constructor
        this.healPerTick = healPerTick;
        this.remainingTicks = durationTicks;
    }

    @Override
    public void tick() {
        if (remainingTicks > 0) {
            target.heal(healPerTick);
            target.sendMessage("You are healed for " + healPerTick + " health.");
            remainingTicks--;
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public String getName() {
        return "simple_hot";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
}
