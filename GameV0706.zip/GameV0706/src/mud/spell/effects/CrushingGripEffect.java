package mud.spell.effects;

import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class CrushingGripEffect implements Effect {

    private static final Random RNG = new Random();
    private static final List<CrushingGripEffect> ACTIVE = new ArrayList<>();

    private final Mob caster;
    private int remainingTicks;

    public CrushingGripEffect(Mob caster, int durationTicks) {
        this.caster = caster;
        this.remainingTicks = durationTicks;
        ACTIVE.add(this);
    }

    @Override
    public String getName() {
        return "Crushing Grip";
    }

    @Override
    public EffectType getType() {
        return EffectType.CRUSHING_GRIP;
    }

    @Override
    public void tick() {
        if (caster == null || caster.getCurrentRoom() == null) {
            remainingTicks = 0;
            expire();
            return;
        }

        Mob target = caster.getCurrentTarget();
        if (target != null && target.getCurrentRoom() == caster.getCurrentRoom()) {

            // Deal damage (modify formula as you wish)
            int dmg = 5 + RNG.nextInt(11); // 5–15 crushing damage

            caster.getCurrentRoom().broadcast(
                "A massive spectral fist crushes " + target.getMobName() + " with bone-cracking force!",
                null
            );
            target.sendMessage("You are crushed by a spectral fist!");

            target.takeDamage(dmg,MagicDamageType.SHADOW);
        }

        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }

    private void expire() {
        if (caster != null) {
            caster.removeEffect(EffectType.CRUSHING_GRIP);
            caster.sendMessage("Your Crushing Grip dissipates into nothingness.");
        }
        ACTIVE.remove(this);
    }

    public static void tickAll() {
        Iterator<CrushingGripEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            CrushingGripEffect e = it.next();
            e.tick();
            if (e.isExpired()) it.remove();
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return caster;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() { return null; }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
