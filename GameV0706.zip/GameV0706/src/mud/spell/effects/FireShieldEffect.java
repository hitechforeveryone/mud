package mud.spell.effects;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Room;
import mud.core.Direction;
import mud.core.EffectType;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class FireShieldEffect implements Effect {
    private static final CopyOnWriteArrayList<FireShieldEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();

    private final MagicDamageType damageType = MagicDamageType.FIRE;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();

    private final Mob target;
    private final int totalTicks;
    private int ticksPassed = 0;

    public FireShieldEffect(Mob target, int durationTicks) {
        this.target = target;
        this.totalTicks = durationTicks;
        ACTIVE_EFFECTS.add(this);

        this.target.addEffect(this);
        this.target.addEffect(EffectType.FIRE_SHIELD);

        target.sendMessage("You are surrounded by a blazing fire shield! " + icon);
        if (target.getRoom() != null) {
            target.getRoom().broadcastExcept(target.getMobName() + " is surrounded by a blazing fire shield!", target, null);
        }
    }

    public static void tickAll() {
        Iterator<FireShieldEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            FireShieldEffect effect = it.next();
            effect.tick();

            if (effect.isExpired()) {
                ACTIVE_EFFECTS.remove(effect);
                effect.target.removeEffect(EffectType.FIRE_SHIELD);
                effect.target.removeEffect(effect.getName());
                effect.target.sendMessage("Your fire shield flickers and fades. " + effect.icon);
                if (effect.target.getRoom() != null) {
                    effect.target.getRoom().broadcastExcept(effect.target.getMobName() + "'s fire shield fades away.", effect.target, null);
                }
            }
        }
    }

    public static void onTargetHit(Mob attacker, Mob target, int damageTaken) {
        if (target.hasEffect(EffectType.FIRE_SHIELD)) {
            int reflected = (int)(damageTaken * 0.1); // 10%
            if (reflected > 0) {
                attacker.takeDamage(reflected);
                if (attacker instanceof Player p) {
                    p.sendMessage("You are burned by " + target.getMobName() + "'s Fire Shield for " + reflected + " damage!");
                }
                if (target instanceof Player t) {
                    t.sendMessage(attacker.getMobName() + " takes " + reflected + " damage from your Fire Shield!");
                }
                target.getCurrentRoom().broadcastToExcept(attacker, target,
                    attacker.getMobName() + " is burned by " + target.getMobName() + "'s Fire Shield for " + reflected + " damage!");
            }
        }
    }


    public void tick() {
        ticksPassed++;
        // Fire Shield is passive until it expires
    }

    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    public String getName() {
        return "fire shield";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public EffectType getType() {
        return EffectType.FIRE_SHIELD;
    }

    @Override
    public int getDuration() {
        return totalTicks - ticksPassed;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
// end
