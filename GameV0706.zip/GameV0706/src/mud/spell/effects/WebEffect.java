package mud.spell.effects;

import mud.core.*;

import java.util.*;


public class WebEffect implements Effect {
	
    private final MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
	
	private static final List<WebEffect> ACTIVE_EFFECTS = new ArrayList<>();
    private Mob target;
    private int remainingTicks;

    public WebEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Web";
    }


    public static void tickAll() {
        Iterator<WebEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            WebEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
 
    public void tick() {
        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }
    

    private void expire() {
        target.removeEffect(EffectType.WEB);
        target.sendMessage("The sticky " + getName() + icon + " around you dissolves.");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return EffectType.WEB;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
