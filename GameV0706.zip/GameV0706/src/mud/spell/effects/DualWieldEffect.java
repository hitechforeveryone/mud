package mud.spell.effects;

import mud.core.*;

public class DualWieldEffect implements Effect {

    private final Mob target;
    private final boolean permanent = true;
    MobAffectFlag DW = MobAffectFlag.DUALWIELD;

    public DualWieldEffect(Mob target) {
        this.target = target;
        this.target.setCanDualWield(true);  // Enable dual wield
        this.target.addAffect(DW);
    }

    @Override
    public void tick() {
        // Passive/permanent effects don’t need ticking logic
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent effect
    }

    @Override
    public String getName() {
        return "dual_wield";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
    
    public void onRemove() {
        target.setCanDualWield(false);
        target.removeAffect(DW);
    }

	@Override
	public int getHpBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStrengthBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
