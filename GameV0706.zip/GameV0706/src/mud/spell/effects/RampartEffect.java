package mud.spell.effects;


import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class RampartEffect implements Effect {


	private static final List<RampartEffect> ACTIVE_RAMPARTS = new CopyOnWriteArrayList<>();


	private final Room room;
	private Direction blockedDir;
	private int remainingTicks;


	public RampartEffect(Room room, Direction dir, int duration) {
		this.room = room;
		this.blockedDir = dir;
		this.remainingTicks = duration;
		ACTIVE_RAMPARTS.add(this);
	}


	// ---- GLOBAL TICKER ----
	public static void tickAll() {
		for (RampartEffect ef : ACTIVE_RAMPARTS) {
			ef.tick();
		}
	}


	// ---- INSTANCE TICK ----
	public void tick() {
		remainingTicks--;
		if (remainingTicks <= 0) {
			expire();
		}
	}


	public Direction getBlockedDir() {
		return blockedDir;
	}


	@Override
	public String getName() {
		return "Icewall (" + blockedDir.name().toLowerCase() + ")";
	}


	private void expire() {
		ACTIVE_RAMPARTS.remove(this);


		// remove effect from room
		room.removeExitEffect(blockedDir, this);
		room.broadcastToRoom("The earthen rampart to the " + blockedDir.name().toLowerCase() + " crumbles away.");
	}


	@Override
	public boolean isExpired() {
		return remainingTicks <= 0;
	}


	@Override
	public Mob getTarget() {
		return null; // Room-based effect
	}


	@Override
	public EffectType getType() {
		return EffectType.METALWALL;
	}


	@Override
	public int getDuration() {
		return remainingTicks;
	}


	public Direction getDirection() {
		return blockedDir;
	}


	public void setDirection(Direction dir) {
		this.blockedDir = dir;
	}


	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}


} // end