package mud.spell.effects;

import java.util.*;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;

public class LifeBloomEffect implements Effect {

    private static final List<LifeBloomEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private final int tickHeal;
    private final int finalHeal;
    private final int totalTicks;
    private int ticksPassed = -1;

    MagicDamageType damageType = MagicDamageType.NATURE;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    public LifeBloomEffect(Mob target, int tickHeal, int finalHeal, int totalTicks) {
        this.target = target;
        this.tickHeal = tickHeal;
        this.finalHeal = finalHeal;
        this.totalTicks = totalTicks;
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<LifeBloomEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            LifeBloomEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {

        ticksPassed++;

        if (ticksPassed < totalTicks) {
            this.target.heal(tickHeal);
            this.target.sendMessage("A gentle pulse of life restores " + tickHeal + "" + icon + " health.");
        }
        else if (ticksPassed == totalTicks) {
            this.target.heal(finalHeal);
            this.target.sendMessage("The bloom explodes with healing energy, restoring " + finalHeal + "" + icon + " health!");
            Room room = target.getCurrentRoom();
            if (room != null) {
                room.broadcastExcept(target.getMobName() + "'s Lifebloom bursts in a radiant flash of life" + icon + ".", target, null);
            }
        }
        
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public String getName() {
        return "LifeBloom";
    }

    @Override
    public int getHpBonus() {
        return 0;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public EffectType getType() {
        return EffectType.HOT;
    }

    @Override
    public int getDuration() {
        return totalTicks;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
} // end
