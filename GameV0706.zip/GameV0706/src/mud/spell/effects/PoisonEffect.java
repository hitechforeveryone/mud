package mud.spell.effects;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;
import mud.core.EffectType;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class PoisonEffect implements Effect {
    private static final CopyOnWriteArrayList<PoisonEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();

    private final MagicDamageType damageType = MagicDamageType.POISON;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();

    private final Mob target;
    private final int totalTicks;
    private int ticksPassed = 0;

    private final int hpDamagePerTick;

    public PoisonEffect(Mob target, int durationTicks, int hpDamagePerTick) {
        this.target = target;
        this.totalTicks = durationTicks;
        this.hpDamagePerTick = hpDamagePerTick;
        ACTIVE_EFFECTS.add(this);

        // Apply poison debuff
        this.target.addEffect(this);
        this.target.addEffect(EffectType.POISON);

        // Apply stat penalties (1% reduction)
  //      this.target.setStrength((int) (target.getStrength() * 0.99));
    //    this.target.setStamina((int) (target.getStamina() * 0.99));

        target.sendMessage("You have been poisoned! " + icon);
        if (target.getCurrentRoom() != null) {
            target.getCurrentRoom().broadcastExcept(target.getMobName() + " is poisoned!", target, null);
        }
        
        
    }

    public static void tickAll() {
        Iterator<PoisonEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            PoisonEffect effect = it.next();
            effect.tick();

            if (effect.isExpired()) {
                ACTIVE_EFFECTS.remove(effect);
                effect.target.removeEffect(EffectType.POISON);
                effect.target.removeEffect(effect.getName());

                // Restore stats
                effect.target.setStrength((int) (effect.target.getStrength() / 0.99));
                effect.target.setStamina((int) (effect.target.getStamina() / 0.99));

                effect.target.sendMessage("The poison fades from your body. " + effect.icon);
                if (effect.target.getCurrentRoom() != null) {
                    effect.target.getCurrentRoom().broadcastExcept(effect.target.getMobName() + " recovers from the poison.", effect.target, null);
                }
            }
        }
    }

    public void tick() {
        ticksPassed++;
        target.takeDamage(hpDamagePerTick, damageType);
        target.sendMessage("The poison burns through your veins, causing " + hpDamagePerTick + " damage! " + icon);
    }

    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    public String getName() {
        return "poison";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public EffectType getType() {
        return EffectType.POISON;
    }

    @Override
    public int getDuration() {
        return totalTicks - ticksPassed;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
// end
