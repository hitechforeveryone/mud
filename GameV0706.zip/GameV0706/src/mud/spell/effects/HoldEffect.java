package mud.spell.effects;

import mud.core.Mob;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;

public class HoldEffect implements Effect {
	
    private final MagicDamageType damageType = MagicDamageType.ARCANE;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
	
	private static final List<HoldEffect> ACTIVE_EFFECTS = new ArrayList<>();
    private Mob target;
    private int remainingTicks;

    public HoldEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "hold";
    }


    public static void tickAll() {
        Iterator<HoldEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            HoldEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
 
    public void tick() {
        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }
    

    private void expire() {
        target.removeEffect(EffectType.HOLD);
        target.sendMessage("You are no immobilized by " + getName() + icon + " .");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return EffectType.HOLD;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
