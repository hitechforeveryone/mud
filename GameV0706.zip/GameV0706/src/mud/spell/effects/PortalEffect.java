// PortalEffect.java
package mud.spell.effects;


import java.util.ArrayList;
import java.util.List;

import mud.core.*;


public class PortalEffect implements Effect {

	private static List<PortalEffect> ACTIVE_PORTALS = new ArrayList<>();
	private Room fromRoom;  
	private Room toRoom;
	private String portalId;
	private int duration;


	public PortalEffect(Room fromRoom, Room toRoom, String portalId, int duration) {
		this.fromRoom = fromRoom;
		this.toRoom = toRoom;
		this.portalId = portalId;
		this.duration = duration;
		ACTIVE_PORTALS.add(this);
	}


	public Room getDestinationRoom() {
		return toRoom;
	}


	public String getPortalId() {
		return portalId;
	}


	@Override
	public String getName() {
		return "portal";
	}


	public void onApply(Room room) {
		room.broadcastToRoom("A shimmering portal crackles with arcane power.");
	}


	public void onTick(Room room) {
		duration--;
		if (duration <= 0) {
			expire(room);
		}
		
		
	}


	public void expire(Room room) {
		room.broadcastToRoom("The shimmering portal flickers and collapses into nothingness.");
		room.removeRoomEffect(this);
	}


	@Override
	public boolean isExpired() {
		return duration <= 0;
	}


	public String getDescription() {
		return "A magical portal linking this room to another location.";
	}


	@Override
	public void tick() {
		// TODO Auto-generated method stub

	}
	public static void tickAll() {
	    for (World world : WorldManager.getAllWorlds()) {

	        for (Zone zone : world.getZones()) {

	            for (Room room : zone.getRooms().values()) {  // FIXED

	                List<Effect> effects = room.getEffects();
	                if (effects == null || effects.isEmpty()) continue;

	                List<Effect> toRemove = new ArrayList<>();

	                for (Effect e : effects) {

	                    if (e instanceof PortalEffect portal) {

	                        portal.duration--;

	                        if (portal.duration <= 0) {
	                            toRemove.add(portal);
	                        }
	                    }
	                }

	                // Remove expired portals
	                for (Effect e : toRemove) {
	                    effects.remove(e);
	                    room.broadcastToRoom("The shimmering portal collapses in on itself!");
	                    
	                    room.removeRoomEffect(e);
	                }
	            }
	        }
	    }
	}



	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public EffectType getType() {
		return EffectType.PORTAL;
	}


	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}


	public static List<PortalEffect> getActivePortals() {
		return ACTIVE_PORTALS;
	}


	public static void setActivePortals(List<PortalEffect> activePortals) {
		ACTIVE_PORTALS = activePortals;
	}


	public Room getFromRoom() {
		return fromRoom;
	}


	public void setFromRoom(Room fromRoom) {
		this.fromRoom = fromRoom;
	}


	public Room getToRoom() {
		return toRoom;
	}


	public void setToRoom(Room toRoom) {
		this.toRoom = toRoom;
	}


	public void setPortalId(String portalId) {
		this.portalId = portalId;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}
} // end PortalEffect