package mud.spell;

import mud.core.Mob;
import mud.core.MobRank;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.MagicDamageType;

public class CureCriticalSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.HOLY;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "cure.critical.wounds";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cure.");
            return false;
        }

        // 🔢 Calculate raw + scaled damage
        int heal = (int) (10 + (1.5 * caster.getIntellect()));
        MobRank rank = caster.getRank();
        double multiplier = rank != null ? rank.getMultiplier() : 1.0;
        caster.sendMessage(caster.getIntellect() + ":" + caster.getBaseIntellect());
        int healAmount = (int) Math.round(heal * multiplier);

        // Heal the target
        target.heal(healAmount);

        // Notify both caster and target
        caster.sendMessage("You cast " + getName() + icon + " and restore " + healAmount + " health to " + target.getMobName() + ".");

        if (target != caster) {
            target.sendMessage(caster.getMobName() + " cures you for " + healAmount + " health.");
        }

        caster.getCurrentRoom().broadcastExcept(
            caster.getMobName() + " casts " + getName() + icon + " at " + target.getMobName()
                + ", healing for " + healAmount + " health!",
            caster, target
        );

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.PALADIN); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
