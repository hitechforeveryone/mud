
package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.MagicDamageType;

public class UnholySmiteSpell implements Spell {
    private final MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "unholy.smite";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to " + getName() + icon + ".");
            return false;
        }

        boolean healCase = false;

        if (caster instanceof Player playerCaster) {
            if (target == caster) {
                healCase = true;
            } else if (playerCaster.getParty() != null && playerCaster.getParty().getMembers().contains(target)) {
                healCase = true;
            }
        }

        if (healCase) {
            // Heal case
            int healAmount = 20 + caster.getIntellect();
            target.heal(healAmount);

            caster.sendMessage("You cast " + getName() + icon + " and restore " + healAmount + " health to " + target.getMobName() + ".");
            if (target != caster) {
                target.sendMessage(caster.getMobName() + "'s " + getName() + icon + " heals you for " + healAmount + " health.");
            }
            caster.getCurrentRoom().broadcastExcept(
                caster.getMobName() + " casts " + getName() + icon + " on " + target.getMobName() + ", healing them.",
                caster, target
            );
        } else {
            // Damage case
            int damage = 20 + caster.getIntellect();
            target.takeDamage(damage, damageType);

            caster.sendMessage("You smite " + target.getMobName() + icon + ", dealing " + damage + " " + typeName + " damage.");
            target.sendMessage(caster.capitalize(caster.getMobName()) + " smites you" + icon + ", dealing " + damage + " " + typeName + " damage!");
            caster.getCurrentRoom().broadcastExcept(
            	caster.capitalize(caster.getMobName()) + " smites " + target.getMobName() + icon + ", dealing " + damage + " " + typeName + " damage.",
                caster, target
            );
            if (target.getTarget() == null) {
            	target.setTarget(caster);
            	caster.setTarget(target);
            }
            
        }
        
        return true;
    }

    @Override
    public String getDescription() {
        return "If cast on self or ally, heals them. If cast on an enemy, deals shadow damage.";
    }

    @Override
    public int getLevelRequired() {
        return 1;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.WARLOCK, Profession.NECROMANCER); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
} // end
