package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.spell.effects.DualWieldEffect;

public class DualWieldSpell implements Spell {

    @Override
    public String getName() {
        return "dualwield";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually.
    	applyPassive(target);
        return true;
    }

    /**
     * Apply passive effect if missing.
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("dual_wield")) {
            mob.addEffect(new DualWieldEffect(mob));
        }
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.WARRIOR, Profession.ROGUE, Profession.HUNTER, Profession.SHAMAN, Profession.MECHANIC); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
