package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.WebEffect;

public class WebSpell implements Spell {

	
    private final MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
    
    private int durationTicks;


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        // Check if target is already webbed
        if (target.hasEffect(EffectType.WEB)) {
            caster.sendMessage(target.getMobName() + " is already trapped in a " + getName() + icon + ".");
            return false;
        }

        durationTicks = 5;
        
        // Apply WebEffect
        WebEffect web = new WebEffect(target, durationTicks);
        target.addEffect(web);
        target.addEffect(EffectType.WEB);
        
        target.sendMessage("A sticky " + getName() + icon + " wraps around you, preventing movement!");
        caster.sendMessage("You ensnare " + target.getMobName() + " in a " + getName() + icon + "!");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " casts a " + getName() + icon + " on " + target.getMobName() + "!");
        }
        return true;
    }

	@Override
	public String getName() {
		return "web";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Ensare the target in webs, preventing movement.";
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// false, must be cast on mob
		return false;
	}

	@Override
	public int getLevelRequired() {
		// 
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// 
		return false;
	}

	@Override
	public boolean isAoE() {
		// 
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// 
		return false;
	}

	@Override
	public boolean isDirectional() {
		// 
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MECHANIC, Profession.MAGE, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
