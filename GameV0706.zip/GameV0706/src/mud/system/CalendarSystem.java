package mud.system;

import java.util.List;

import mud.config.Config;

import java.util.ArrayList;

public class CalendarSystem {
	
    private int daysPerWeek = 6;
    private int weeksPerMonth = 5;
    private int daysPerMonth = 30;
    private int monthsPerYear = 12;


    private List<String> dayNames;
    private List<String> monthNames;
    
    
    public CalendarSystem(int daysPerWeek, int weeksPerMonth, int monthsPerYear,
                          List<String> dayNames, List<String> monthNames) {
        this.daysPerWeek = daysPerWeek;
        this.weeksPerMonth = weeksPerMonth;
        this.monthsPerYear = monthsPerYear;
        this.dayNames = dayNames;
        this.monthNames = monthNames;
        // Default names
        setDayNames(List.of("Primeday", "Twosday", "Threesday", "Foursday", "Fiveday", "Sixthday"));
        setMonthNames(List.of(
            "Frostmere", "Snowwane", "Thawmarch", "Rainfell", "Bloomreach", "Sungold",
            "Emberbright", "Dustcall", "Harvestwane", "Coldfall", "Starwatch", "Yearsend"
        ));
        
        validate();
    }

    public CalendarSystem() {
        this.daysPerWeek = 6;
        this.weeksPerMonth = 5;
        this.monthsPerYear = 12;
        this.dayNames = new ArrayList<>();
        this.monthNames = new ArrayList<>();
    }

    public String getDayName(int dayIndex) {
        return dayNames.get(dayIndex % daysPerWeek);
    }

    public String getMonthName(int monthIndex) {
        return monthNames.get(monthIndex % monthsPerYear);
    }
    
    public int getMonthIndex(int totalDayIndex) {
        int daysPerMonth = daysPerWeek * weeksPerMonth;
        return (totalDayIndex / daysPerMonth) % monthsPerYear;
    }

    public int getDayOfWeekIndex(int totalDayIndex) {
        return totalDayIndex % daysPerWeek;
    }


    
    
    public void validate() {
        if (dayNames.size() != daysPerWeek)
            throw new IllegalArgumentException("Day names must match daysPerWeek");
        if (monthNames.size() != monthsPerYear)
            throw new IllegalArgumentException("Month names must match monthsPerYear");
    }

    public int getDaysPerWeek() {
        return daysPerWeek;
    }

    public int getWeeksPerMonth() {
        return weeksPerMonth;
    }

    public int getMonthsPerYear() {
        return monthsPerYear;
    }

    public int getDaysPerMonth() {
        return daysPerWeek * weeksPerMonth;
    }

    public int getDaysPerYear() {
        return getDaysPerMonth() * monthsPerYear;
    }

    public List<String> getDayNames() {
        return dayNames;
    }

    public List<String> getMonthNames() {
        return monthNames;
    }

    public String getDayOfWeekName(int totalDayIndex) {
        return dayNames.get(totalDayIndex % daysPerWeek);
    }

    public String getMonthNameByDay(int totalDayIndex) {
        int daysPerMonth = getDaysPerMonth(); // = 30
        int monthIndex = (totalDayIndex / daysPerMonth) % monthsPerYear;
        return monthNames.get(monthIndex);
    }

    public int getWeekOfMonth(int totalDayIndex) {
        int daysPerMonth = getDaysPerMonth(); // = 30
        int dayInMonth = totalDayIndex % daysPerMonth;
        return dayInMonth / daysPerWeek; // Week 0–4
    }

    public int getYear(int dayIndex) {
        int daysPerYear = getDaysPerYear(); // = 360
        return dayIndex / daysPerYear;
    }

    public void setDaysPerWeek(int daysPerWeek) {
        this.daysPerWeek = daysPerWeek;
    }

    public void setWeeksPerMonth(int weeksPerMonth) {
        this.weeksPerMonth = weeksPerMonth;
    }

    public void setMonthsPerYear(int monthsPerYear) {
        this.monthsPerYear = monthsPerYear;
    }

    public void setDayNames(List<String> dayNames) {
        this.dayNames = new ArrayList<>(dayNames);
    }

    public void setMonthNames(List<String> monthNames) {
        this.monthNames = new ArrayList<>(monthNames);
    }
    public int getDayOfYear(int month, int day) {
        return (month * daysPerMonth) + day;
    }

    public String getTimeOfDay(int tick) {
        int totalTicks = Config.ticksPerDay;

        int dawnStart = 0;
        int dayStart = totalTicks / 4;           // 25% into the day
        int duskStart = totalTicks / 2;          // 50%
        int nightStart = (totalTicks * 3) / 4;   // 75%

        if (tick >= dawnStart && tick < dayStart) return "Dawn";
        if (tick >= dayStart && tick < duskStart) return "Day";
        if (tick >= duskStart && tick < nightStart) return "Dusk";
        return "Night";
    }

    /**
     * Utility to get a formatted string like:
     * "[GameClock] New day: Primeday, Week 1 of Frostmere, Year 0"
     */
    public String formatDayInfo(int totalDayIndex) {
        String dayName = getDayOfWeekName(totalDayIndex);
        String monthName = getMonthNameByDay(totalDayIndex);
        int weekNumber = getWeekOfMonth(totalDayIndex) + 1; // Convert from 0-based to 1-based for display
        int year = getYear(totalDayIndex);
        return String.format("[GameClock] New day: %s, Week %d of %s, Year %d", dayName, weekNumber, monthName, year);
    }

	public void setDaysPerMonth(int daysPerMonth) {
		this.daysPerMonth = daysPerWeek * weeksPerMonth;
	}
    
} // end CalendarSystem
