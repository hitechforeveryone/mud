package mud.system;

import mud.core.*;

import java.util.Random;

public class WeatherSystem {

	private static final Random random = new Random();

	public static WeatherType generateWeather(Climate climate) {
		int roll = random.nextInt(100);

		return switch (climate) {
		case NONE -> roll < 10 ? WeatherType.VOID : WeatherType.NONE;
		case VOID -> roll < 50 ? WeatherType.CLEAR :
			roll < 75 ? WeatherType.CLOUDY :
				roll < 90 ? WeatherType.NONE :
					WeatherType.VOID;
		case DESERT -> roll < 70 ? WeatherType.CLEAR :
			roll < 85 ? WeatherType.WINDY :
				WeatherType.HEATWAVE;
		case TROPICAL -> roll < 50 ? WeatherType.CLEAR :
			roll < 75 ? WeatherType.RAIN :
				roll < 90 ? WeatherType.STORM :
					WeatherType.FOG;
		case ARCTIC -> roll < 40 ? WeatherType.CLEAR :
			roll < 60 ? WeatherType.SNOW :
				roll < 80 ? WeatherType.COLD_SNAP :
					WeatherType.FOG;
		case PLAINS -> roll < 50 ? WeatherType.CLEAR :
			roll < 70 ? WeatherType.CLOUDY :
				roll < 85 ? WeatherType.RAIN :
					WeatherType.STORM;
		case MOUNTAIN -> roll < 40 ? WeatherType.CLEAR :
			roll < 60 ? WeatherType.WINDY :
				roll < 80 ? WeatherType.FOG :
					WeatherType.SNOW;
		case TEMPERATE -> roll < 10 ? WeatherType.STORM :
			roll < 20 ? WeatherType.RAIN :
				roll < 30 ? WeatherType.CLOUDY :
					WeatherType.CLEAR;
		case BLIGHTED -> roll < 40 ? WeatherType.BLIGHT :
			roll < 60 ? WeatherType.STORM :
				roll < 90 ? WeatherType.RAIN :
					WeatherType.FOG;
		case HIGHLAND -> roll < 10 ? WeatherType.SNOW :
			roll < 20 ? WeatherType.COLD_SNAP :
				roll < 35 ? WeatherType.WINDY :
					WeatherType.CLEAR;
		case SWAMP -> roll < 5 ? WeatherType.BLIGHT :
			roll < 10 ? WeatherType.STORM :
				roll < 40 ? WeatherType.RAIN :
					roll < 60 ? WeatherType.CLOUDY :
						WeatherType.FOG;
		case COLD -> roll < 10 ? WeatherType.COLD_SNAP :
			roll < 30 ? WeatherType.COLD :
				roll < 55 ? WeatherType.SNOW :
					roll < 75 ? WeatherType.WINDY :
						WeatherType.CLEAR;
		case COASTAL -> roll < 5 ? WeatherType.FOG :
			roll < 15 ? WeatherType.STORM :
				roll < 25 ? WeatherType.WINDY :
					roll < 35 ? WeatherType.RAIN :
						roll < 60 ? WeatherType.CLOUDY :
							WeatherType.CLEAR;		

		default -> WeatherType.CLEAR;
		};
	}


	public static void updateWeather(World world) {
		if (world == null) return;

		for (Zone zone : world.getZones()) {
			Climate climate = zone.getClimate();
			WeatherType current = zone.getCurrentWeather();
			WeatherType next = generateWeather(climate);

			if (next != current) {
				zone.setCurrentWeather(next);

		//		System.out.printf("🌦️ Weather changed in Zone %d (%s): %s → %s%n", zone.getZoneId(), climate, current, next);

				// ✅ Broadcast to all outdoor rooms
				for (Room room : zone.getRooms().values()) {
					if (room.hasFlag(RoomFlag.OUTSIDE)) {
						for (Mob mob : room.getMobs()) {
							if (mob instanceof Player player) {
								player.sendMessage("☁️ The weather changes: " + next.getDescription());
							}
						}
					}
				}

				/*
				 * redundant if already sending to the player (above)
				 *
	            for (Room room : zone.getRooms().values()) {
	                if (room.hasFlag(RoomFlag.OUTSIDE)) {
	                    for (Mob mob : room.getMobs()) {
	                        if (mob instanceof Player player) {
	                            player.sendMessage("☁️ The weather changes: " + next.getDescription());
	                        }
	                    }
	                }
	            }
				 */


			}
		}
	}






}
