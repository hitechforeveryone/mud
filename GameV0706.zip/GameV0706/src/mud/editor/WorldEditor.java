package mud.editor;

import java.io.*;
import java.util.*;

import mud.config.Config;
import mud.core.*;

public class WorldEditor implements Editor {

    private final World world;
    private Moon newMoon;
    private final Player player;
    private final boolean isNewWorld;
    private boolean finished = false;
    private WorldEditorState state = WorldEditorState.MAIN_MENU;

    private Moon moonBeingEdited = null;
    
    private int moonIndexBeingEdited = -1;
    
    private static final int MAIN_MENU = 0;
    private static final int MOON_MENU = 1;
    private static final int AWAITING_NEW_MOON_NAME = 2;
    private static final int AWAITING_NEW_MOON_ORBIT = 3;
    private static final int AWAITING_DELETE_SELECTION = 4;
    private static final int AWAITING_MOON_SUBMENU = 5;

    private int moonTempOrbit = 0;
    private String moonTempName = null;
    private Moon editingMoon = null;


    public WorldEditor(World world, Player player, boolean isNewWorld) {
        this.world = world;
        this.player = player;
        this.isNewWorld = isNewWorld;
    }

    private void displayMainMenu() {
        player.sendMessage("\n--- Editing World: " + world.getWorldId() + " ---");
        player.sendMessage("1) Show World Info");
        player.sendMessage("2) Edit Name");
        player.sendMessage("3) Edit Owner");
        player.sendMessage("4) Edit Starting Location");
        player.sendMessage("5) Manage Moons");
        player.sendMessage("6) List Zones");
        player.sendMessage("7) Save World (csave)");
        player.sendMessage("8) Exit Editor");
        player.sendMessage("Choose option:");
    }

    @Override
    public void startEditing() {
    	  if (isNewWorld) {
    	        player.sendMessage("🌍 Creating default Zone 0 and Room 0 for new world...");

    	        // Create Zone 0
    	        Zone zone0 = new Zone(0);
    	        zone0.setName("Default Zone");
    	        zone0.setWorld(world);
    	        world.addZone(0, zone0);
    	        zone0.setParentWorld(world);

    	        // Create Room 0
    	        Room room0 = new Room(0);
    	        room0.setName("Starting Room");
    	        room0.setDescription("An empty, dull room.");
    	        room0.setShortDescription("An empty room.");
    	        room0.setZone(zone0);
    	        zone0.addRoom(0, room0);

    	        // Save the zone immediately
    	        if (WorldManager.saveZone(zone0)) {
    	            player.sendMessage("✅ Zone 0 and Room 0 created and saved.");
    	        } else {
    	            player.sendMessage("❌ Failed to save Zone 0.");
    	        }
    	    }
        state = WorldEditorState.MAIN_MENU;
        displayMainMenu();
    }

    @Override
    public void handleInput(String input) {
        switch (state) {
            case MAIN_MENU:
                handleMainMenuInput(input);
                break;
            case EDIT_NAME:
                handleEditNameInput(input);
                break;
            case EDIT_OWNER:
                handleEditOwnerInput(input);
                break;
            case MANAGE_MOONS_MENU:
                handleManageMoonsInput(input);
                break;
            case ADD_MOON:
                handleAddMoonInput(input);  // ← This connects it!
                break;
            case DELETE_MOON_SELECT:
                handleDeleteMoonInput(input);
                break;
            case ADD_MOON_NAME:
                handleAddMoonNameInput(input);
                break;
            case ADD_MOON_ORBIT:
                handleAddMoonOrbitInput(input);
                break;
            case EDIT_MOON_NAME:
                handleEditMoonNameInput(input);
                break;
            case EDIT_MOON_ORBIT:
                handleEditMoonOrbitInput(input);
                break;
            case EDIT_MOON_MENU:
                handleEditMoonMenuInput(input);
                break;
            case REMOVE_MOON_CONFIRMATION:
                handleRemoveMoonConfirmationInput(input);
                break;
            case MOON_MENU:
            	handleMoonMenuInput(input);
            	break;
            case AWAITING_NEW_MOON_NAME:
            	handleNewMoonName(input);
            	break;
            case AWAITING_NEW_MOON_ORBIT:
            	handleNewMoonOrbit(input);
            	break;
            case AWAITING_DELETE_SELECTION:
            	handleDeleteMoonInput(input);
            	break;
            case AWAITING_MOON_SUBMENU:
            	handleMoonSubmenu(input);
            	break;
            case SET_START_LOCATION: {
                String[] parts = input.trim().split("\\s+");
                if (parts.length != 2) {
                    player.sendMessage("Invalid input. Use: zoneId roomId");
                } else {
                    try {
                        int zoneId = Integer.parseInt(parts[0]);
                        int roomId = Integer.parseInt(parts[1]);
                        world.setStartingZoneId(zoneId);
                        world.setStartingRoomNumber(roomId);
                        player.sendMessage("Starting location updated.");
                    } catch (NumberFormatException e) {
                        player.sendMessage("Invalid zone or room ID.");
                    }
                }
                state = WorldEditorState.MAIN_MENU;
                displayMainMenu();
            }

            default:
                player.sendMessage("Unexpected input. Returning to main menu.");
                state = WorldEditorState.MAIN_MENU;
                displayMainMenu();
                break;
        }
    }

    private void handleMainMenuInput(String input) {
        switch (input) {
            case "1":
                showWorldInfo();
                displayMainMenu();
                break;
            case "2":
                player.sendMessage("Enter new world name (current: " + world.getName() + "):");
                state = WorldEditorState.EDIT_NAME;
                break;
            case "3":
                player.sendMessage("Enter new owner (current: " + world.getOwner() + "):");
                state = WorldEditorState.EDIT_OWNER;
            case "4" : {
            	player.sendMessage("Enter starting location (format: zoneId roomId):");
            	player.sendMessage("Current Location: Zone " + world.getStartingZoneId() + ", Room " + world.getStartingRoomNumber());
                state = WorldEditorState.SET_START_LOCATION;                
            	break; }
            case "5":
                displayManageMoonsMenu();
                state = WorldEditorState.MANAGE_MOONS_MENU;
                break;
            case "6":
                listZones();
                displayMainMenu();
                break;
            case "7":
                doSave();
                displayMainMenu();
                break;
            case "8":
                player.sendMessage("Exiting editor.");
                finished = true;
                break;
            default:
                player.sendMessage("Invalid option. Choose a number 1-8.");
                displayMainMenu();
        }
    }

    private void showWorldInfo() {
        player.sendMessage("\nWorld ID: " + world.getWorldId());
        player.sendMessage("Name: " + world.getName());
        player.sendMessage("Owner: " + world.getOwner());
    }

    private void displayManageMoonsMenu() {
        player.sendMessage("\nMoons:");
        List<Moon> moons = world.getMoons();
        if (moons.isEmpty()) {
            player.sendMessage("  (None)");
        } else {
            for (int i = 0; i < moons.size(); i++) {
                Moon moon = moons.get(i);
                player.sendMessage(String.format("%d) %s (Orbit: %d days)", i + 1, moon.getName(), moon.getOrbitDays()));
            }
        }

        // Adjust add/delete options based on how many moons exist
        player.sendMessage("\n" + (moons.size() + 1) + ") Add new moon");
        player.sendMessage((moons.size() + 2) + ") Delete a moon");
        player.sendMessage("0) Return to main menu");
    }




    private void handleManageMoonsInput(String input) {
    	
    	// TODO
        List<Moon> moons = world.getMoons();
        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input.");
            displayManageMoonsMenu();
            return;
        }

        moons = world.getMoons();
        
        if (choice == 0) {
            state = WorldEditorState.MAIN_MENU;
            displayMainMenu();
        } 
        
        if (choice == moons.size() + 1) {
            promptForNewMoon();  // 🎯 Add Moon flow
            return;
        }
        
        if (choice == moons.size() + 2) {
            promptToDeleteMoon(); // 🎯 Delete Moon flow
            return;
        }
        
        if (choice >= 1 && choice <= moons.size()) {
            editingMoon = moons.get(choice - 1);  // zero-based index
            showEditMoonSubmenu();
            return;
        }
        
        else {
            player.sendMessage("Invalid choice.");
            displayManageMoonsMenu();
        }
    }
    
    private void promptForNewMoon() {
        player.sendMessage("Enter new moon name (or 'cancel'):");
        state = WorldEditorState.ADD_MOON_NAME;
    }

    private void promptToDeleteMoon() {
        List<Moon> moons = world.getMoons();
        if (moons.isEmpty()) {
            player.sendMessage("There are no moons to delete.");
            return;
        }

        player.sendMessage("Which moon do you want to delete?");
        for (int i = 0; i < moons.size(); i++) {
            player.sendMessage((i + 1) + ") " + moons.get(i).getName());
        }
        state = WorldEditorState.AWAITING_DELETE_SELECTION;
    }

    
    private void handleEditMoonNameInput(String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage("Moon renaming cancelled.");
            state = WorldEditorState.MANAGE_MOONS_MENU;
            displayManageMoonsMenu();
            return;
        }

        if (!input.trim().isEmpty()) {
            moonBeingEdited.setName(input.trim());
        }

        player.sendMessage("Enter new orbit length (current: " + moonBeingEdited.getOrbitDays() + "):");
        state = WorldEditorState.EDIT_MOON_ORBIT;
    }


    private void handleAddMoonOrbitInput(String input) {
        try {
            int orbit = Integer.parseInt(input);
            newMoon.setOrbitDays(orbit);
            world.addMoon(newMoon);
            player.sendMessage("Moon '" + newMoon.getName() + "' added.");
            newMoon = null;
            state = WorldEditorState.MANAGE_MOONS_MENU;
            displayManageMoonsMenu();
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid number. Enter orbit length as integer:");
        }
    }


    /*
    private void handleEditMoonNameInput(String input) {
        if (!input.trim().isEmpty()) {
            moonBeingEdited.setName(input.trim());
        }
        player.sendMessage("Enter new orbit length (current: " + moonBeingEdited.getOrbitDays() + "):");
        state = WorldEditorState.EDIT_MOON_ORBIT;
    }
*/
    
    private void handleEditMoonOrbitInput(String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage("Moon editing cancelled.");
            moonBeingEdited = null;
            state = WorldEditorState.MANAGE_MOONS_MENU;
            displayManageMoonsMenu();
            return;
        }

        try {
            if (!input.trim().isEmpty()) {
                int orbit = Integer.parseInt(input.trim());
                if (orbit > 0) {
                    moonBeingEdited.setOrbitDays(orbit);
                    player.sendMessage("Moon updated.");
                } else {
                    player.sendMessage("Orbit days must be positive. Not changed.");
                }
            } else {
                player.sendMessage("Orbit not changed.");
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid number. Orbit not changed.");
        }

        moonBeingEdited = null;
        state = WorldEditorState.MANAGE_MOONS_MENU;
        displayManageMoonsMenu();
    }


    private void listZones() {
        List<Zone> zones = new ArrayList<>(world.getZones());
        if (zones.isEmpty()) {
            player.sendMessage("This world has no zones.");
        } else {
            for (Zone zone : zones) {
                player.sendMessage("Zone ID: " + zone.getZoneId() + " - " + zone.getName());
            }
        }
    }

    private void doSave() {
        boolean success = WorldManager.saveWorld(world);
        if (success) {
            player.sendMessage("World '" + world.getWorldId() + "' saved successfully.");
        } else {
            player.sendMessage("❌ Failed to save world.");
        }
    }

    private void handleEditNameInput(String input) {
        if (!input.trim().isEmpty()) {
            world.setName(input.trim());
            player.sendMessage("World name updated.");
        } else {
            player.sendMessage("Name not changed.");
        }
        state = WorldEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleEditOwnerInput(String input) {
        world.setOwner(input.trim());
        player.sendMessage("Owner updated.");
        state = WorldEditorState.MAIN_MENU;
        displayMainMenu();
    }

    public static boolean saveZone(Zone zone) {
        if (zone == null || zone.getWorld() == null) {
            System.err.println("❌ Cannot save zone: missing world or zone.");
            return false;
        }

        String filename = zone.getWorld().getWorldId() + "_" + zone.getZoneId() + ".zone";
        File file = new File(Config.ZONES_DIR, filename);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(zone);
            System.out.println("✅ Zone saved: " + filename);
            return true;
        } catch (IOException e) {
            System.err.println("❌ Failed to save zone: " + filename);
            e.printStackTrace();
            return false;
        }
    }
    
    private void handleEditMoonMenuInput(String input) {
        switch (input) {
            case "1":
                player.sendMessage("Enter new name (or leave blank to keep):");
                state = WorldEditorState.EDIT_MOON_NAME;
                break;
            case "2":
                player.sendMessage("Enter new orbit length (current: " + moonBeingEdited.getOrbitDays() + "):");
                state = WorldEditorState.EDIT_MOON_ORBIT;
                break;
            case "3":
                player.sendMessage("Are you sure you want to remove the moon '" + moonBeingEdited.getName() + "'? (yes/no)");
                state = WorldEditorState.REMOVE_MOON_CONFIRMATION;
                break;
            case "0":
            default:
                moonBeingEdited = null;
                state = WorldEditorState.MANAGE_MOONS_MENU;
                displayManageMoonsMenu();
                break;
        }
    }
    
    private void handleRemoveMoonConfirmationInput(String input) {
        if (input.equalsIgnoreCase("yes")) {
            world.getMoons().remove(moonBeingEdited);
            player.sendMessage("Moon '" + moonBeingEdited.getName() + "' removed.");
        } else {
            player.sendMessage("Moon removal canceled.");
        }
        moonBeingEdited = null;
        state = WorldEditorState.MANAGE_MOONS_MENU;
        displayManageMoonsMenu();
    }

    private void handleAddMoonNameInput(String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage("Add moon cancelled.");
            state = WorldEditorState.MANAGE_MOONS_MENU;
            displayManageMoonsMenu();
            return;
        }
        newMoon = new Moon();  // assign here
        newMoon.setName(input);
        player.sendMessage("Enter orbit length in days:");
        state = WorldEditorState.ADD_MOON_ORBIT;
    }

    /*
    private void handleDeleteMoonInput(String input) {
        try {
            int index = Integer.parseInt(input) - 1;
            List<Moon> moons = world.getMoons();
            if (index >= 0 && index < moons.size()) {
                Moon removed = moons.remove(index);
                player.sendMessage("Removed moon: " + removed.getName());
            } else {
                player.sendMessage("Invalid index.");
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Please enter a valid number.");
        }
        state = WorldEditorState.MANAGE_MOONS_MENU;
        displayManageMoonsMenu();
    }
*/
    private void handleMoonMenuInput(String input) {
        List<Moon> moons = world.getMoons();
        int maxIndex = moons.size();

        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            player.sendMessage("Please enter a number.");
            return;
        }

        if (choice == 0) {
            state = WorldEditorState.MAIN_MENU;
            displayMainMenu();
            return;
        }

        if (choice == maxIndex + 1) {
            state = WorldEditorState.AWAITING_NEW_MOON_NAME;
            player.sendMessage("Enter new moon name (or 'cancel'):");
            return;
        }

        if (choice == maxIndex + 2) {
            if (moons.isEmpty()) {
                player.sendMessage("No moons to delete.");
                showMoonMenu();
                return;
            }
            state = WorldEditorState.AWAITING_DELETE_SELECTION;
            player.sendMessage("Select a moon to delete:");
            for (int i = 0; i < moons.size(); i++) {
                player.sendMessage((i + 1) + ") " + moons.get(i).getName());
            }
            return;
        }

        if (choice >= 1 && choice <= maxIndex) {
            this.editingMoon = moons.get(choice - 1);
            state = WorldEditorState.AWAITING_MOON_SUBMENU;
            showEditMoonSubmenu();
            return;
        }

        player.sendMessage("Invalid option.");
    }
    
    
    private void handleNewMoonName(String input) {
        if (input.equalsIgnoreCase("cancel")) {
            state = WorldEditorState.MOON_MENU;
            showMoonMenu();
            return;
        }

        moonTempName = input;
        state = WorldEditorState.AWAITING_NEW_MOON_ORBIT;
        player.sendMessage("Enter orbit length in days (or 'cancel'):");
    }

    private void handleNewMoonOrbit(String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage("Moon creation cancelled.");
            state = WorldEditorState.MOON_MENU;
            showMoonMenu();
            return;
        }

        try {
            moonTempOrbit = Integer.parseInt(input);
            Moon newMoon = new Moon(moonTempName, moonTempOrbit);
            world.addMoon(newMoon);
            player.sendMessage("Moon added: " + moonTempName + " (Orbit: " + moonTempOrbit + ")");
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid orbit length.");
        }

        moonTempName = null;
        moonTempOrbit = 0;
        state = WorldEditorState.MOON_MENU;
        showMoonMenu();
    }
    
    private void handleDeleteMoonInput(String input) {
        try {
            int index = Integer.parseInt(input);
            List<Moon> moons = world.getMoons();
            if (index >= 1 && index <= moons.size()) {
                Moon removed = moons.remove(index - 1);
                this.editingMoon = null; // Clear any previous selection
                player.sendMessage("Moon '" + removed.getName() + "' deleted.");
            } else {
                player.sendMessage("Invalid moon number.");
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input.");
        }
        state = WorldEditorState.MOON_MENU;
        showMoonMenu();
    }
    
    private void showEditMoonSubmenu() {
        if (editingMoon == null) {
            player.sendMessage("⚠️ No moon selected. Returning to moon menu.");
            showMoonMenu();
            state = WorldEditorState.MOON_MENU;
            return;
        }

        player.sendMessage("Editing moon: " + editingMoon.getName() + " (Orbit Days: " + editingMoon.getOrbitDays() + ")");
        player.sendMessage("1) Rename Moon");
        player.sendMessage("2) Change Orbit");
        player.sendMessage("3) Remove Moon");
        player.sendMessage("0) Back");
    }

    private void handleMoonSubmenu(String input) {
    	if (editingMoon == null) {
    	    player.sendMessage("⚠️ No moon selected. Returning to moon menu.");
    	    showMoonMenu();
    	    return;
    	}
    	switch (input) {
        
            case "0" -> {
                editingMoon = null;
                state = WorldEditorState.MOON_MENU;
                showMoonMenu();
            }
            case "1" -> {
                player.sendMessage("Enter new name (or blank to keep):");
                state = WorldEditorState.AWAITING_NEW_MOON_NAME; // Custom constant like AWAITING_RENAME
            }
            case "2" -> {
                player.sendMessage("Enter new orbit length (current: " + editingMoon.getOrbitDays() + "):");
                state = WorldEditorState.AWAITING_NEW_MOON_ORBIT;
            }
            case "3" -> {


                world.getMoons().remove(editingMoon);
                player.sendMessage("Moon removed.");
                editingMoon = null;
                state =WorldEditorState.MOON_MENU;
                
                showMoonMenu();
            }
            default -> player.sendMessage("Invalid option.");
        }
    }
    private void showMoonMenu() {
        List<Moon> moons = world.getMoons();
        player.sendMessage("Moons:");
        for (int i = 0; i < moons.size(); i++) {
            Moon moon = moons.get(i);
            player.sendMessage((i + 1) + ") " + moon.getName() + " (Orbit Days: " + moon.getOrbitDays() + ")");
        }
        player.sendMessage((moons.size() + 1) + ") Add new moon");
        player.sendMessage((moons.size() + 2) + ") Delete a moon");
        player.sendMessage("0) Return to main menu");
    }

    private void handleAddMoonInput(String input) {
        String name = input.trim();

        if (name.equalsIgnoreCase("cancel") || name.isBlank()) {
            player.sendMessage("Moon creation cancelled.");
            state = WorldEditorState.MANAGE_MOONS_MENU;
            displayManageMoonsMenu();
            return;
        }

        if (!name.matches("[A-Za-z0-9_\\-]{1,20}")) {
            player.sendMessage("Invalid moon name. Use 1–20 letters, numbers, hyphens, or underscores.");
            player.sendMessage("Enter new moon name (or 'cancel'):");
            return;
        }

        Moon moon = new Moon(name);
        world.addMoon(moon);
        player.sendMessage("✅ Moon '" + name + "' added.");
        
        state = WorldEditorState.MANAGE_MOONS_MENU;
        displayManageMoonsMenu();
    }



    @Override
    public void stopEditing() {}

    @Override
    public void showMenu() {}

    @Override
    public boolean save() {
        return false;
    }

    @Override
    public String getEditorName() {
        return null;
    }

    @Override
    public void tick() {}

    @Override
    public boolean isFinished() {
        return finished;
    }
} // end WorldEditor
