package mud.editor;

import mud.core.*;
import mud.core.MobBehaviorFlag;
import mud.core.MobAffectFlag;
import mud.spell.effects.Effect;
import java.util.*;

public class MobEditor implements Editor {
    private Mob mob;
    private final Player player;
    private boolean finished = false;
    private MobEditorState state = MobEditorState.MAIN_MENU;

    public MobEditor(Mob mob, Player player) {
        this.mob = mob;
        this.player = player;
        System.out.println("DEBUG: MobEditor created for mob ID " + mob.getId());
    }

    @Override
    public void startEditing() {
        displayMainMenu();
        System.out.println("DEBUG: MobEditor started for mob " + mob.getMobName());
        player.sendMessage("Now editing mob: " + mob.getMobName());
    }

    public void displayMainMenu() {
        player.sendMessage("""
--- Mob Editor: %s ---
1) Show Mob Info
2) Edit Mob Name
3) Edit Short Description
4) Edit Extended Description
5) Edit Keywords
6) Edit Level
7) Edit Profession
8) Edit Race
9) Edit Subrace
10) Edit Mob Rank
11) Edit Stats
12) Toggle Behavior Flags
13) Toggle Affect Flags
14) Set Sentry Direction/Message
15) Set Reincarnate Count
16) Set Speeches
17) Save Mob
18) Exit Editor
Choose option:""".formatted(mob.getId()));
    }

    @Override
    public void handleInput(String input) {
        switch (state) {
            case MAIN_MENU -> handleMainMenu(input);
            case EDIT_BEHAVIOR_FLAGS -> handleToggleBehavior(input);
            case TOGGLE_AFFECT -> handleToggleAffect(input);
            case SET_SENTRY -> handleSentry(input);
            case SET_REINCARNATE -> handleReincarnate(input);
            case SET_SPEECHES -> handleSpeeches(input);
            case SET_PROFESSION -> handleSetProfession(input);
            case SET_RACE -> handleSetRace(input);
            case SET_SUBRACE -> handleSetSubrace(input);
            case SET_RANK -> handleSetRank(input);
            case SET_NAME -> {
                mob.setMobName(input);
                player.sendMessage("Name set.");
                state = MobEditorState.MAIN_MENU;
                displayMainMenu();
            }
            case SET_SHORT_DESC -> {
                mob.setShortDescription(input);
                player.sendMessage("Short description set.");
                state = MobEditorState.MAIN_MENU;
                displayMainMenu();
            }
            case SET_LONG_DESC -> {
                mob.setLongDescription(input);
                player.sendMessage("Extended description set.");
                state = MobEditorState.MAIN_MENU;
                displayMainMenu();
            }
            case SET_LEVEL -> handleSetLevel(input);
            case SET_STATS -> handleSetStats(input);
            case SET_KEYWORDS -> handleSetKeywords(input);
        }
    }

    private void handleMainMenu(String input) {
        switch (input) {
            case "1" -> {
                showMobInfo();
                displayMainMenu();
            }
            case "2" -> {
                state = MobEditorState.SET_NAME;
                player.sendMessage("Enter new name:");
            }
            case "3" -> {
                state = MobEditorState.SET_SHORT_DESC;
                player.sendMessage("Enter short description:");
            }
            case "4" -> {
                state = MobEditorState.SET_LONG_DESC;
                player.sendMessage("Enter extended description:");
            }
            case "5" -> {
                state = MobEditorState.SET_KEYWORDS;
                player.sendMessage("Enter keywords (space-separated):");
            }
            case "6" -> {
                state = MobEditorState.SET_LEVEL;
                player.sendMessage("Enter new mob level (1-100):");
            }
            case "7" -> {
                state = MobEditorState.SET_PROFESSION;
                player.sendMessage("Enter profession:");
            }
            case "8" -> {
                state = MobEditorState.SET_RACE;
                player.sendMessage("Enter race:");
            }
            case "9" -> {
                state = MobEditorState.SET_SUBRACE;
                player.sendMessage("Enter subrace:");
            }
            case "10" -> {
                state = MobEditorState.SET_RANK;
                player.sendMessage("Enter rank (e.g., COMMON, ELITE, etc.):");
            }
            case "11" -> {
                state = MobEditorState.SET_STATS;
                player.sendMessage("Enter stats as STR STA AGI INT:");
            }
            case "12" -> {
                state = MobEditorState.EDIT_BEHAVIOR_FLAGS;
                showBehaviorFlags();
            }
            case "13" -> {
                state = MobEditorState.TOGGLE_AFFECT;
                showAffectFlags();
            }
            case "14" -> {
                state = MobEditorState.SET_SENTRY;
                player.sendMessage("Enter sentry direction and message:");
            }
            case "15" -> {
                state = MobEditorState.SET_REINCARNATE;
                player.sendMessage("Enter reincarnate count:");
            }
            case "16" -> {
                state = MobEditorState.SET_SPEECHES;
                player.sendMessage("Enter up to 3 speeches (pike (|) separated ):");
            }
            case "17" -> {
                doSave();
                displayMainMenu();
            }
            case "18" -> {
                player.sendMessage("Exiting Mob Editor.");
                player.setEditor(null);
            }
            default -> displayMainMenu();
        }
    }

    private void handleSetKeywords(String input) {
        Set<String> keywords = new HashSet<>(Arrays.asList(input.trim().split("\\s+")));
        mob.setKeywords(keywords);
        player.sendMessage("Keywords set to: " + String.join(", ", keywords));
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void showBehaviorFlags() {
        player.sendMessage("Current Behavior Flags:");
        for (MobBehaviorFlag flag : MobBehaviorFlag.values()) {
            player.sendMessage(" - " + flag.name() + (mob.hasBehavior(flag) ? " [ON]" : " [off]"));
        }
        player.sendMessage("Enter flag to toggle (or 'back'):");
    }

    private void handleToggleBehavior(String input) {
        if (input.equalsIgnoreCase("back")) {
            state = MobEditorState.MAIN_MENU;
            displayMainMenu();
            return;
        }
        try {
            MobBehaviorFlag flag = MobBehaviorFlag.valueOf(input.toUpperCase());
            if (mob.hasBehavior(flag)) {
                mob.removeBehavior(flag);
                player.sendMessage("Removed behavior: " + flag.name());
            } else {
                mob.addBehavior(flag);
                player.sendMessage("Added behavior: " + flag.name());
            }
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid flag name.");
        }
        showBehaviorFlags();
    }

    private void showAffectFlags() {
        player.sendMessage("Current Affect Flags:");
        for (MobAffectFlag flag : MobAffectFlag.values()) {
            player.sendMessage(" - " + flag.name() + (mob.hasAffect(flag) ? " [ON]" : " [off]"));
        }
        player.sendMessage("Enter flag to toggle (or 'back'):");
    }

    private void handleToggleAffect(String input) {
        if (input.equalsIgnoreCase("back")) {
            state = MobEditorState.MAIN_MENU;
            displayMainMenu();
            return;
        }
        try {
            MobAffectFlag flag = MobAffectFlag.valueOf(input.toUpperCase());
            mob.toggleAffect(flag);
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid flag name.");
        }
        showAffectFlags();
    }

    private void handleSentry(String input) {
        String[] parts = input.split(" ", 2);
        if (parts.length == 2) {
            mob.setSentryDirection(parts[0].toUpperCase());
            mob.setSentryMessage(parts[1]);
            player.sendMessage("Sentry direction/message set.");
        } else {
            player.sendMessage("Invalid input.");
        }
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleReincarnate(String input) {
        try {
            int count = Integer.parseInt(input);
            mob.setReincarnateMax(count);
            mob.setReincarnateRemaining(count);
            player.sendMessage("Reincarnate count set.");
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid number.");
        }
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSpeeches(String input) {
        List<String> list = Arrays.stream(input.split("\\|"))
                .map(String::trim).filter(s -> !s.isEmpty()).toList();
        mob.setSpeeches(list);
        player.sendMessage("Speeches updated.");
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void showMobInfo() {
        player.sendMessage("\n--- Mob Info ---");
        player.sendMessage("Name: " + mob.getMobName());
        player.sendMessage("Short Desc: " + mob.getShortDescription());
        player.sendMessage("Long Desc:" + mob.getLongDescription());
        player.sendMessage("Extended Desc:" + mob.getExtendedDescription());
        player.sendMessage("Keywords: " + mob.getKeywords());
        player.sendMessage("Level: " + mob.getLevel());
        player.sendMessage("HP: " + mob.getCurrentHP() + "/" + mob.getMaxHP());
        player.sendMessage("MP: " + mob.getCurrentMP() + "/" + mob.getMaxMP());
        player.sendMessage("Stats: STR=" + mob.getStrength() + ", STA=" + mob.getStamina()
                + ", AGI=" + mob.getAgility() + ", INT=" + mob.getIntellect());
        player.sendMessage("Race: " + mob.getRace());

        player.sendMessage("Behavior Flags:");
        for (MobBehaviorFlag flag : MobBehaviorFlag.values()) {
            if (mob.hasBehavior(flag)) {
                player.sendMessage(" - " + flag.name());
            }
        }

        player.sendMessage("Affect Flags:");
        for (MobAffectFlag flag : MobAffectFlag.values()) {
            if (mob.hasAffect(flag)) {
                player.sendMessage(" - " + flag.name());
            }
        }

        if (mob.isTalker()) {
            player.sendMessage("Talker Speeches:");
            for (String speech : mob.getSpeeches()) {
                player.sendMessage(" - " + speech);
            }
        }

        if (mob.hasBehavior(MobBehaviorFlag.SENTRY)) {
            player.sendMessage("Sentry Blocks Direction: " + mob.getSentryDirection());
            player.sendMessage("Sentry Message: " + mob.getSentryMessage());
        }

        if (mob.hasBehavior(MobBehaviorFlag.REINCARNATE) && mob.getReincarnateRemaining() > 0) {
            player.sendMessage("Reincarnates Left: " + mob.getReincarnateRemaining());
        }

        if (!mob.getActiveEffects().isEmpty()) {
            List<String> effectNames = mob.getActiveEffects()
                    .stream()
                    .map(Effect::getName)
                    .toList();
            player.sendMessage("Active Effects: " + String.join(", ", effectNames));
        }
    }

    private void handleSetLevel(String input) {
        try {
            int level = Integer.parseInt(input);
            if (level < 1 || level > 100) {
                player.sendMessage("Level must be between 1 and 100.");
            } else {
                mob.setLevel(level);
                mob.scaleStatsByLevel();
                player.sendMessage("Mob level set to " + level + ".");
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid level input.");
        }
        mob.scaleStatsByLevel();
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetProfession(String input) {
        try {
            Profession prof = Profession.valueOf(input.toUpperCase());
            mob.setProfession(prof);
            player.sendMessage("Profession set to " + prof.name());
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid profession.");
        }
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetRace(String input) {
        mob.setRace(input.trim());
        mob.regenerateStatsFromRaceLevelAndRank();
        player.sendMessage("Race set to: " + mob.getRace());
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetSubrace(String input) {
        mob.setSubrace(input.trim());
        player.sendMessage("Subrace set to: " + mob.getSubrace());
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetRank(String input) {
        try {
            MobRank rank = MobRank.valueOf(input.toUpperCase());
            mob.setRank(rank);
            mob.regenerateStatsFromRaceLevelAndRank();
            player.sendMessage("Rank set to: " + rank.name());
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid rank.");
        }
        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetStats(String input) {
        String[] parts = input.split(" ");
        if (parts.length != 4) {
            player.sendMessage("Please enter 4 integers: STR STA AGI INT");
            return;
        }

        try {
            int str = Integer.parseInt(parts[0]);
            int sta = Integer.parseInt(parts[1]);
            int agi = Integer.parseInt(parts[2]);
            int intel = Integer.parseInt(parts[3]);

            mob.setStrength(str);
            mob.setStamina(sta);
            mob.setAgility(agi);
            mob.setIntellect(intel);
            
            player.sendMessage("Stats updated.");
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid stat input. Use four integers.");
        }

        state = MobEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void doSave() {
        WorldManager.saveMob(mob);
        player.sendMessage("Mob saved.");
    }

    @Override public void stopEditing() {finished = true;}
    @Override public void showMenu() { displayMainMenu(); }
    @Override public boolean save() { doSave(); return true; }
    @Override public String getEditorName() { return "MobEditor for mob " + mob.getId(); }
    @Override public void tick() {}
    @Override public boolean isFinished() { return finished; }
} // end