package mud.editor;

import mud.core.Direction;
import mud.core.Door;
import mud.core.Player;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.World;
import mud.core.WorldManager;
import mud.core.Zone;
import mud.core.ZoneExit;

import java.util.List;

public class RoomEditor implements Editor {

	private final Room room;
	private final Player player;
	private RoomEditorState state = RoomEditorState.MAIN_MENU;

	private String pendingDirectionInput = null;

	private String pendingZoneExitWorld;
	private int pendingZoneExitZoneId = -1;

	private boolean finished = false;

	public RoomEditor(Room room, Player player) {
		this.room = room;
		this.player = player;
		System.out.println("[DEBUG] RoomEditor created for room: " + room.getId());

	}

	@Override
	public void startEditing() {
		state = RoomEditorState.MAIN_MENU;
		displayMainMenu();
	}

	private void displayMainMenu() {
		player.sendMessage("\n--- Editing Room ID: " + room.getId() + " ---");
		player.sendMessage("1) Show Room Info");
		player.sendMessage("2) Edit Name");
		player.sendMessage("3) Edit Description");
		player.sendMessage("4) Edit Short Description");
		player.sendMessage("5) Manage Flags");
		player.sendMessage("6) Manage Exits");
		player.sendMessage("7) Manage Doors");
		player.sendMessage("8) Save Room");
		player.sendMessage("9) Exit Editor");
		player.sendMessage("Choose an option:");
	}

	@Override
	public void handleInput(String input) {
		switch (state) {
		case MAIN_MENU -> handleMainMenuInput(input);
		case EDIT_NAME -> handleEditNameInput(input);
		case EDIT_DESCRIPTION -> handleEditDescriptionInput(input);
		case EDIT_SHORT_DESCRIPTION -> handleEditShortDescriptionInput(input);
		case MANAGE_EXITS -> handleManageExitsInput(input);
		case SET_EXIT_TARGET -> handleSetExitTargetInput(input);
		case ZONE_EXIT_DIRECTION -> handleZoneExitDirectionInput(input);
		case ZONE_EXIT_TARGET_WORLD -> handleZoneExitTargetWorldInput(input);
		case ZONE_EXIT_TARGET_ZONE -> handleZoneExitTargetZoneInput(input);
		case ZONE_EXIT_TARGET_ROOM -> handleZoneExitTargetRoomInput(input);
		case MANAGE_DOORS -> handleManageDoorsInput(input);
		case EDIT_DOOR_MENU -> handleEditDoorMenu(input);
		case EDIT_DOOR_NAME -> handleEditDoorName(input);
		case EDIT_DOOR_DESCRIPTION -> handleEditDoorDescription(input);
		case EDIT_DOOR_KEYWORDS -> handleEditDoorKeywords(input);
		case EDIT_FLAGS -> handleEditFlagsInput(input);

		default -> {
			player.sendMessage("Unexpected input. Returning to main menu.");
			state = RoomEditorState.MAIN_MENU;
			displayMainMenu();
		}
		}
	}

	private void handleMainMenuInput(String input) {
		switch (input) {
		case "1" -> { showRoomInfo(); displayMainMenu(); }
		case "2" -> { player.sendMessage("Enter new room name:"); state = RoomEditorState.EDIT_NAME; }
		case "3" -> { player.sendMessage("Enter new room description:"); state = RoomEditorState.EDIT_DESCRIPTION; }
		case "4" -> { player.sendMessage("Enter new short description:"); state = RoomEditorState.EDIT_SHORT_DESCRIPTION; }
		case "5" -> { displayFlagMenu(); state = RoomEditorState.EDIT_FLAGS; }
		case "6" -> { displayExitMenu(); state = RoomEditorState.MANAGE_EXITS; }
		case "7" -> { displayDoorMenu(); state = RoomEditorState.MANAGE_DOORS; }
		case "8" -> { doSave(); displayMainMenu(); }
		case "9" -> stopEditing();
		default -> { player.sendMessage("Invalid option."); displayMainMenu(); }
		}
	}

	private void handleEditNameInput(String input) {
		if (!input.isBlank()) {
			room.setName(input.trim());
			player.sendMessage("✅ Room name updated.");
		} else {
			player.sendMessage("⚠️ Room name not changed (blank input).");
		}
		state = RoomEditorState.MAIN_MENU;
		displayMainMenu();
	}

	private void handleEditDescriptionInput(String input) {
		if (!input.isBlank()) {
			room.setDescription(input.trim());
			player.sendMessage("✅ Room description updated.");
		} else {
			player.sendMessage("⚠️ Description not changed (input was blank).");
		}
		state = RoomEditorState.MAIN_MENU;
		displayMainMenu();
	}

	private void handleEditShortDescriptionInput(String input) {
		if (!input.isBlank()) {
			room.setShortDescription(input.trim());
			player.sendMessage("✅ Short description updated.");
		} else {
			player.sendMessage("⚠️ Short description not changed (input was blank).");
		}
		state = RoomEditorState.MAIN_MENU;
		displayMainMenu(); // or showMenu(), depending on what you're using
	}

	private void handleManageExitsInput(String input) {
		input = input.trim().toLowerCase();

		if (input.equals("done")) {
			state = RoomEditorState.MAIN_MENU;
			displayMainMenu();
			return;
		}

		if (input.equals("z")) {
			player.sendMessage("Enter direction for the zone exit (e.g., north, up):");
			state = RoomEditorState.ZONE_EXIT_DIRECTION;
			return;
		}

		if (input.equals("d")) {
			player.sendMessage("Enter direction of the door to add/edit (e.g., east):");
			state = RoomEditorState.ADD_DOOR_DIRECTION;
			return;
		}

		if (input.startsWith("remove ")) {
			String dirStr = input.substring("remove ".length()).trim().toUpperCase();
			try {
				Direction dir = Direction.valueOf(dirStr);
				room.getExits().remove(dir);
				room.getZoneExits().remove(dir);
				room.getDoors().remove(dir);
				player.sendMessage("✅ Removed all exit/door data for direction " + dir.name().toLowerCase());
			} catch (IllegalArgumentException e) {
				player.sendMessage("❌ Invalid direction.");
			}
			displayExitMenu();
			return;
		}

		// Normal exit creation
		try {
			Direction dir = Direction.valueOf(input.toUpperCase());
			pendingDirectionInput = dir.name();
			player.sendMessage("Enter the ID of the target room for exit " + dir.name().toLowerCase() + " (or leave blank to auto-create):");
			state = RoomEditorState.SET_EXIT_TARGET;
		} catch (IllegalArgumentException e) {
			player.sendMessage("❌ Invalid input. Use a direction, 'remove <dir>', 'z', 'd', or 'done'.");
			displayExitMenu();
		}
	}




	private void displayDoorMenu() {
		player.sendMessage("\n--- Door Management ---");
		player.sendMessage("Current doors:");
		for (Direction dir : room.getDoors().keySet()) {
			Door door = room.getDoors().get(dir);
			player.sendMessage(" - " + dir.name().toLowerCase() + ": " + door.getDoorName());
		}
		player.sendMessage("\nType direction (e.g. north) to create/edit door, 'remove north' to delete, or 'done' to return:");
	}


	private void handleManageDoorsInput(String input) {
		input = input.trim();
		if (input.equalsIgnoreCase("done")) {
			state = RoomEditorState.MAIN_MENU;
			displayMainMenu();
			return;
		}

		String[] parts = input.split("\\s+");
		if (parts.length == 2 && parts[0].equalsIgnoreCase("remove")) {
			try {
				Direction dir = Direction.valueOf(parts[1].toUpperCase());
				if (room.getDoors().remove(dir) != null) {
					player.sendMessage("✅ Door removed in direction " + dir.name().toLowerCase());
				} else {
					player.sendMessage("⚠️ No door found in that direction.");
				}
			} catch (IllegalArgumentException e) {
				player.sendMessage("Invalid direction.");
			}
			displayDoorMenu();
			return;
		}

		try {
			Direction dir = Direction.valueOf(input.toUpperCase());
			pendingDirectionInput = dir.name();
			state = RoomEditorState.EDIT_DOOR_MENU;
			showEditDoorMenu(dir);
		} catch (IllegalArgumentException e) {
			player.sendMessage("Invalid direction.");
			displayDoorMenu();
		}
	}

	
	
	private void handleEditDoorName(String input) {
		Direction dir = Direction.valueOf(pendingDirectionInput);
		Door door = room.getDoor(dir);
		door.setDoorName(input.trim());
		door.setShortDescription(input.trim());
		player.sendMessage("Door name set.");
		state = RoomEditorState.EDIT_DOOR_MENU;
		showEditDoorMenu(dir);
	}

	private void handleEditDoorDescription(String input) {
		Direction dir = Direction.valueOf(pendingDirectionInput);
		Door door = room.getDoor(dir);
		door.setLongDescription(input.trim());
		player.sendMessage("Long description set.");
		state = RoomEditorState.EDIT_DOOR_MENU;
		showEditDoorMenu(dir);
	}

	private void handleEditDoorKeywords(String input) {
		Direction dir = Direction.valueOf(pendingDirectionInput);
		Door door = room.getDoor(dir);
		door.setKeywords(List.of(input.trim().split(",")));
		player.sendMessage("Keywords updated.");
		state = RoomEditorState.EDIT_DOOR_MENU;
		showEditDoorMenu(dir);
	}


	private void doSave() {
		Zone zone = room.getZone();
		if (zone != null) {
			boolean success = WorldManager.saveZone(zone);
			if (success) player.sendMessage("✅ Room and zone saved successfully.");
			else player.sendMessage("❌ Failed to save zone.");
		} else player.sendMessage("⚠️ Room is not associated with any zone. Cannot save.");
	}

	private void showRoomInfo() {
		player.sendMessage("\n--- Room Info ---");
		player.sendMessage("ID: " + room.getId());
		player.sendMessage("Name: " + room.getName());
		player.sendMessage("Short Description: " + room.getShortDescription());
		player.sendMessage("Full Description: " + room.getDescription());
		player.sendMessage("Tunnel Limit: " + room.getTunnelNum());

		// Flags
		StringBuilder flags = new StringBuilder();
		for (RoomFlag flag : RoomFlag.values()) {
			if (room.hasFlag(flag)) {
				flags.append(flag.name().toLowerCase()).append(" ");
			}
		}
		player.sendMessage("Flags: " + (flags.length() > 0 ? flags.toString().trim() : "None"));

		// Exits
		if (!room.getExits().isEmpty()) {
			player.sendMessage("Exits:");
			for (Direction dir : room.getExits().keySet()) {
				Room target = room.getExits().get(dir);
				player.sendMessage(" - " + dir.name().toLowerCase() + ": Room " + target.getId());
			}
		} else {
			player.sendMessage("Exits: None");
		}

		// ZoneExits
		if (!room.getZoneExits().isEmpty()) {
			player.sendMessage("Zone Transitions:");
			for (Direction dir : room.getZoneExits().keySet()) {
				ZoneExit zx = room.getZoneExits().get(dir);
				player.sendMessage(" - " + dir.name().toLowerCase() + " → " +
						zx.getTargetWorldId() + " / Zone " + zx.getTargetZoneId() +
						" / Room " + zx.getTargetRoomId());
			}
		}

		// Doors
		if (!room.getDoors().isEmpty()) {
			player.sendMessage("Doors:");
			for (Direction dir : room.getDoors().keySet()) {
				Door door = room.getDoors().get(dir);
				player.sendMessage(" - " + dir.name().toLowerCase() + ": " + door.getShortDescription() +
						" [open: " + door.isOpen() + ", locked: " + door.isLocked() + "]");
			}
		}
	}

	private void displayExitMenu() {
		player.sendMessage("\n--- Manage Exits & Doors ---");

		// Regular room-to-room exits
		if (!room.getExits().isEmpty()) {
			player.sendMessage("Standard Exits:");
			for (Direction dir : room.getExits().keySet()) {
				Room target = room.getExit(dir);
				if (target != null) {
					player.sendMessage(" - " + dir.name().toLowerCase() + " → Room " + target.getId());
				}
			}
		} else {
			player.sendMessage("Standard Exits: None");
		}

		// Cross-zone exits
		if (!room.getZoneExits().isEmpty()) {
			player.sendMessage("Zone Exits:");
			for (Direction dir : room.getZoneExits().keySet()) {
				ZoneExit zx = room.getZoneExits().get(dir);
				player.sendMessage(" - " + dir.name().toLowerCase() + " → " +
						zx.getTargetWorldId() + ":" + zx.getTargetZoneId() + ":" + zx.getTargetRoomId());
			}
		}

		// Doors
		if (!room.getDoors().isEmpty()) {
			player.sendMessage("Doors:");
			for (Direction dir : room.getDoors().keySet()) {
				Door door = room.getDoors().get(dir);
				player.sendMessage(" - " + dir.name().toLowerCase() + " → " + door.getShortDescription() +
						" [open: " + door.isOpen() + ", locked: " + door.isLocked() + "]");
			}
		}

		player.sendMessage("\nCommands:");
		player.sendMessage(" - Type a direction (e.g., `north`) to add/set an exit.");
		player.sendMessage(" - `remove <dir>` to delete an exit.");
		player.sendMessage(" - `door <dir>` to create/edit a door.");
		player.sendMessage(" - `delete door <dir>` to remove a door.");
		player.sendMessage(" - `z` to add a cross-zone exit.");
		player.sendMessage(" - `done` to return to the main menu.");
	}

	private void displayFlagMenu() {
		player.sendMessage("\n--- Room Flags ---");
		player.sendMessage("Current flags:");
		for (RoomFlag flag : RoomFlag.values()) {
			boolean enabled = room.hasFlag(flag);
			player.sendMessage(" - " + flag.name().toLowerCase() + (enabled ? " (enabled)" : " (disabled)"));
		}
		player.sendMessage("\nType a flag name to toggle it.");
		player.sendMessage("Type 'clear' to remove all flags.");
		player.sendMessage("Type 'done' to return to the main menu.");
	}


	private void handleSetExitTargetInput(String input) {
		try {
			int targetId = Integer.parseInt(input.trim());
			Zone zone = room.getZone();
			if (zone == null) {
				player.sendMessage("⚠️ This room is not in a zone. Cannot set exits.");
				state = RoomEditorState.MAIN_MENU;
				return;
			}

			Room target = zone.getRoom(targetId);
			if (target == null) {
				player.sendMessage("Room " + targetId + " not found. Creating...");
				target = new Room(targetId);
				target.setZone(zone);
				zone.addRoom(targetId, target);
				player.sendMessage("✅ Room " + targetId + " created in Zone " + zone.getZoneId());   
			}

			Direction dir = Direction.valueOf(pendingDirectionInput);
			room.setExit(dir, target);
			player.sendMessage("✅ Exit set: " + dir.name().toLowerCase() + " → Room " + targetId);

			// Optional reverse exit setup
			Direction reverse = dir.getOpposite();
			if (target.getExit(reverse) == null) {
				target.setExit(reverse, room);
				player.sendMessage("↔ Reverse exit also set: " + reverse.name().toLowerCase() + " → Room " + room.getId());
			}

		} catch (NumberFormatException e) {
			player.sendMessage("❌ Invalid room ID. Please enter a number.");
		} catch (IllegalArgumentException e) {
			player.sendMessage("❌ Invalid direction.");
		}

		pendingDirectionInput = null;
		state = RoomEditorState.MANAGE_EXITS;
		displayExitMenu();
	}

	private void handleZoneExitTargetWorldInput(String input) {
		if (input.trim().isEmpty()) {
			player.sendMessage("World ID cannot be empty. Please enter the target world ID:");
			return;
		}

		pendingZoneExitWorld = input.trim();
		player.sendMessage("Enter target zone ID:");
		state = RoomEditorState.ZONE_EXIT_TARGET_ZONE;
	}

	private void handleZoneExitDirectionInput(String input) {
		try {
			pendingDirectionInput = input.trim().toUpperCase();
			Direction.valueOf(pendingDirectionInput); // Validates the direction
			player.sendMessage("Enter target world ID:");
			state = RoomEditorState.ZONE_EXIT_TARGET_WORLD;
		} catch (IllegalArgumentException e) {
			player.sendMessage("❌ Invalid direction. Try again:");
		}
	}

	private void handleZoneExitTargetZoneInput(String input) {
		try {
			pendingZoneExitZoneId = Integer.parseInt(input.trim());
			player.sendMessage("Enter target room ID:");
			state = RoomEditorState.ZONE_EXIT_TARGET_ROOM;
		} catch (NumberFormatException e) {
			player.sendMessage("❌ Invalid zone ID. Please enter a number:");
		}
	}

	// Suggested fix to improve cross-zone exit handling in RoomEditor

	// Enhanced zone exit logic inside RoomEditor
	private void handleZoneExitTargetRoomInput(String input) {
	    try {
	        int targetRoomId = Integer.parseInt(input.trim());
	        Direction dir = Direction.valueOf(pendingDirectionInput);
	        ZoneExit ze = new ZoneExit(pendingZoneExitWorld, pendingZoneExitZoneId, targetRoomId);
	        room.setZoneExit(dir, ze);

	        // Try to locate and load the target world, zone, and room
	        World targetWorld = WorldManager.getWorldByName(pendingZoneExitWorld);
	        if (targetWorld == null) {
	            player.sendMessage("❌ World not found: " + pendingZoneExitWorld);
	        } else {
	            Zone targetZone = targetWorld.getZone(pendingZoneExitZoneId);
	            if (targetZone == null) {
	                // Attempt to load the zone
	                targetZone = WorldManager.loadZone(targetWorld.getWorldId(), pendingZoneExitZoneId);
	                if (targetZone == null) {
	                    player.sendMessage("⚠️ Target zone could not be loaded.");
	                }
	            }

	            if (targetZone != null) {
	                Room targetRoom = targetZone.getRoom(targetRoomId);
	                if (targetRoom == null) {
	                    // Attempt to load room via Zone if lazy loading is supported
	                    targetRoom = WorldManager.getRoom(pendingZoneExitWorld, pendingZoneExitZoneId, targetRoomId);
	                }

	                if (targetRoom != null) {
	                    room.setExit(dir, targetRoom);

	                    // Optional reverse exit
	                    Direction reverse = dir.getOpposite();
	                    if (targetRoom.getExit(reverse) == null) {
	                        targetRoom.setExit(reverse, room);
	                    }

	                    player.sendMessage("✅ In-memory exit also created.");
	                } else {
	                    player.sendMessage("⚠️ ZoneExit set, but target room could not be loaded into memory.");
	                }
	            }
	        }

	        player.sendMessage("✅ ZoneExit added in direction " + dir.name().toLowerCase() +
	                " → " + pendingZoneExitWorld + ":" + pendingZoneExitZoneId + ":" + targetRoomId);

	        // Cleanup
	        pendingDirectionInput = null;
	        pendingZoneExitWorld = null;
	        pendingZoneExitZoneId = -1;

	        state = RoomEditorState.MANAGE_EXITS;
	        displayExitMenu();

	    } catch (Exception e) {
	        player.sendMessage("❌ Error: " + e.getMessage());
	    }
	} // end





	private void handleEditFlagsInput(String input) {
		input = input.trim().toUpperCase();

		if (input.equals("DONE")) {
			state = RoomEditorState.MAIN_MENU;
			displayMainMenu();
			return;
		}

		if (input.equals("CLEAR")) {
			room.clearFlags(); // or room.getFlags().clear(); if no helper method
			player.sendMessage("✅ All flags cleared.");
			displayFlagMenu();
			return;
		}

		try {
			RoomFlag flag = RoomFlag.valueOf(input);
			if (room.hasFlag(flag)) {
				room.removeFlag(flag);
				player.sendMessage("❌ " + flag.name().toLowerCase() + " disabled.");
			} else {
				room.addFlag(flag);
				player.sendMessage("✅ " + flag.name().toLowerCase() + " enabled.");
			}
		} catch (IllegalArgumentException e) {
			player.sendMessage("⚠️ Unknown flag: " + input.toLowerCase());
		}

		displayFlagMenu();
	}






	private void showEditDoorMenu(Direction dir) {
		Door door = room.getDoor(dir);
		if (door == null) {
		door = new Door();
		room.setDoor(dir, door);
		player.sendMessage("🚪 New door created for " + dir.name().toLowerCase());
		}
		player.sendMessage("\nEditing door: " + dir.name().toLowerCase());
		player.sendMessage("1) Set name");
		player.sendMessage("2) Set long description");
		player.sendMessage("3) Edit keywords");
		player.sendMessage("4) Toggle open/closed");
		player.sendMessage("5) Toggle locked/unlocked");
		player.sendMessage("6) Toggle lockable");
		player.sendMessage("7) Toggle hidden/visible"); // new option
		player.sendMessage("8) Set door key object ID"); // new option
		player.sendMessage("9) Return to door menu");
		player.sendMessage("Choose an option:");
		}


		private void handleEditDoorMenu(String input) {
		Direction dir = Direction.valueOf(pendingDirectionInput);
		Door door = room.getDoor(dir);
		switch (input) {
		case "1" -> { player.sendMessage("Enter new door name:"); state = RoomEditorState.EDIT_DOOR_NAME; }
		case "2" -> { player.sendMessage("Enter new long description:"); state = RoomEditorState.EDIT_DOOR_DESCRIPTION; }
		case "3" -> { player.sendMessage("Enter comma-separated keywords:"); state = RoomEditorState.EDIT_DOOR_KEYWORDS; }
		case "4" -> { door.setOpen(!door.isOpen()); player.sendMessage("Door is now " + (door.isOpen() ? "open" : "closed") + "."); showEditDoorMenu(dir); }
		case "5" -> { door.setLocked(!door.isLocked()); player.sendMessage("Door is now " + (door.isLocked() ? "locked" : "unlocked") + "."); showEditDoorMenu(dir); }
		case "6" -> { door.setLockable(!door.isLockable()); player.sendMessage("Door is now " + (door.isLockable() ? "lockable" : "not lockable") + "."); showEditDoorMenu(dir); }
		case "7" -> { door.setHidden(!door.isHidden()); player.sendMessage("Door is now " + (door.isHidden() ? "hidden" : "visible") + "."); showEditDoorMenu(dir); } // toggle hidden
		case "8" -> { player.sendMessage("Enter door key object ID (integer):"); state = RoomEditorState.EDIT_DOOR_KEY_ID; } // set key ID
		case "9" -> { state = RoomEditorState.MANAGE_DOORS; displayDoorMenu(); }
		default -> { player.sendMessage("Invalid choice."); showEditDoorMenu(dir); }
		}
		}


		// New input handlers
		private void handleEditDoorKeyId(String input) {
		Direction dir = Direction.valueOf(pendingDirectionInput);
		Door door = room.getDoor(dir);
		try {
		int keyId = Integer.parseInt(input.trim());
		door.setDoorKeyId(keyId);
		player.sendMessage("Door key object ID set to " + keyId);
		} catch (NumberFormatException e) {
		player.sendMessage("Invalid input. Please enter an integer.");
		}
		state = RoomEditorState.EDIT_DOOR_MENU;
		showEditDoorMenu(dir);
		}
	// ... all your existing methods remain unchanged ...

	@Override public boolean isFinished() { return finished; }
	@Override public void stopEditing() { finished = true; player.sendMessage("Stopped editing room."); }
	@Override public void showMenu() { displayMainMenu(); }
	@Override public boolean save() { 
		return true;
	}
	@Override public String getEditorName() { return "RoomEditor for room " + room.getId(); }
	@Override public void tick() {}
} // end RoomEditor
