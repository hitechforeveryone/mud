package mud.commands;

import mud.core.Player;
import mud.core.WorldManager;

public class GrapevineCommandHandler {

    public static void handleGrapevine(Player sender, String message) {
        if (message == null || message.isBlank()) {
            sender.sendMessage("Usage: % <message>, grapevine <message>, or grape <message>");
            return;
        }

        String formatted = "📣 \u001B[35m[Grapevine] " + sender.getName() + ": " + message + "\u001B[0m";

        for (Player p : WorldManager.getAllPlayers()) {
            p.sendMessage(formatted);
        }

        System.out.println("[Grapevine] " + sender.getName() + ": " + message);
    }
}
