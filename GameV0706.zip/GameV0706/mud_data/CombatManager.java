package mud.combat;

import mud.core.*;
import mud.spell.effects.*;

import java.util.List;
import java.util.Random;

public class CombatManager {
    private static final Random random = new Random();

    public static String performAttack(Mob attacker, Mob target) {
        if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
            return "Invalid combatants.";
        }

        Room curRoom = attacker.getRoom();
        attacker.setCurrentRoom(curRoom);
        target.setCurrentRoom(curRoom);

        // Prevent movement while in combat
        attacker.setInCombat(true);
        target.setInCombat(true);

        StringBuilder result = new StringBuilder();

        // Primary attack (main hand weapon)
        ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
        result.append(performSingleAttack(attacker, target, mainHand, false));

        // Double Attack chance based on level if effect is active
        if (attacker.hasEffect("double_attack")) {
            double doubleAttackChance = Math.min(0.05 * attacker.getLevel(), 0.5); // 5% per level, max 50%
            if (Math.random() < doubleAttackChance) {
                if (mainHand != null && mainHand.isWeapon()) {
                    result.append("\n").append(performSingleAttack(attacker, target, mainHand, true));
                }
            }
        }

        // Offhand attack chance based on level if dual wield effect is active
        if (attacker.hasEffect("dual_wield")) {
            double dualWieldChance = Math.min(0.03 * attacker.getLevel(), 0.4); // 3% per level, max 40%
            if (Math.random() < dualWieldChance) {
                ObjectItem offHand = attacker.getEquipment().get(EquipSlot.OFFHAND);
                if (offHand != null && offHand.isWeapon()) {
                    result.append("\n").append(performSingleAttack(attacker, target, offHand, true));
                }
            }
        }

        if (target.getTarget() == null) {
            target.setTarget(attacker);
        }

        // after attack messages
        // For attacker
        if (attacker instanceof Player playerAttacker) {
            String attackerView = String.format("You:HP:%d/%d MP:%d/%d  %s:HP:%d/%d MP:%d/%d",
                    attacker.getCurrentHP(), attacker.getMaxHP(), attacker.getCurrentMP(), attacker.getMaxMP(),
                    target.getMobName(), target.getCurrentHP(), target.getMaxHP(), target.getCurrentMP(), target.getMaxMP());
            playerAttacker.sendMessage(attackerView);
        }

        // For target
        if (target instanceof Player playerTarget && playerTarget != attacker) {
            String targetView = String.format("%s:HP:%d/%d MP:%d/%d  You:HP:%d/%d MP:%d/%d",
                    attacker.getMobName(), attacker.getCurrentHP(), attacker.getMaxHP(), attacker.getCurrentMP(), attacker.getMaxMP(),
                    target.getCurrentHP(), target.getMaxHP(), target.getCurrentMP(), target.getMaxMP());
            playerTarget.sendMessage(targetView);
        }

        return result.toString().trim();
    }

    public static String getCombatStatus(Mob a, Mob b) {
        return a.getMobName() + ":HP: " + a.getCurrentHP() + "/" + a.getMaxHP() +
                " MP: " + a.getCurrentMP() + "/" + a.getMaxMP() + "  " +
                b.getMobName() + ":HP: " + b.getCurrentHP() + "/" + b.getMaxHP() +
                " MP: " + b.getCurrentMP() + "/" + b.getMaxMP();
    }

    private static String performSingleAttack(Mob attacker, Mob target, ObjectItem weapon, boolean isOffhand) {
        String attackerMsg = "";

        double vorpalDamage = 1.0;
        if (weapon != null && weapon.isVorpal()) {
            vorpalDamage = 1.25;
        }

        int intDamage = 0;
        if (weapon != null && weapon.isIntelligent()) {
            intDamage = weapon.getFlatDamage();
        }

        if (attacker.getTarget() == null || attacker.getTarget().isDead()) {
            attacker.setTarget(target);
        }
        int baseDamage = rollWeaponDamage(weapon, attacker);
        int bonusDamage = attacker.getStat("Strength") / 2;
        double scaledDamage = ((baseDamage * vorpalDamage) + intDamage + bonusDamage) * attacker.getRank().getMultiplier();
        int totalDamage = (int) scaledDamage;

        // Damage type
        WeaponDamageType dmgType = (weapon != null && weapon.getDamageType() != null)
                ? weapon.getDamageType()
                : WeaponDamageType.HIT;

        String icon = dmgType.getIcon();
        String verb = dmgType.getPrettyName().toLowerCase();
        String handLabel = isOffhand ? " (offhand)" : "";

        // Calculate total defense bonus safely
        int TotalDefenseBonus = 0;
        for (ObjectItem obj : target.getEquipment().values()) {
            if (obj != null && obj.getArmorType() != null) {
                TotalDefenseBonus += obj.getArmorType().getDefenseBonus();
            }
        }
        if (TotalDefenseBonus >= 100) {
            TotalDefenseBonus = 99;
        }

        // ===================== MIRROR IMAGE HOOK ======================
        MirrorImageEffect mie = target.getEffect(MirrorImageEffect.class);
        if (mie != null && mie.getImages() > 0) {
            if (mie.onIncomingAttack(attacker, target)) {
                // Messaging
                attacker.sendMessage("Your attack shatters one of " + target.getMobName() + "'s mirror images!");
                target.sendMessage(attacker.getMobName() + " shatters one of your mirror images!");

                if (target.getRoom() != null) {
                    target.getRoom().broadcastToExcept(attacker, target,
                            attacker.getMobName() + " shatters one of " + target.getMobName() + "'s mirror images!");
                }

                // Attack negated, do not apply vampiric healing or damage
                return "Your attack missed as it struck a mirror image!";
            }
        }
        // ===============================================================

        // ===================== SHADOW CLONE HOOK ======================
        ShadowCloneEffect sce = target.getEffect(ShadowCloneEffect.class);
        if (sce != null && sce.getImages() > 0) {
            if (sce.onIncomingAttack(attacker, target)) {
                attacker.sendMessage("Your attack shatters one of " + target.getMobName() + "'s shadow clones!");
                target.sendMessage(attacker.getMobName() + " shatters one of your shadow clones!");

                if (target.getRoom() != null) {
                    target.getRoom().broadcastToExcept(attacker, target,
                            attacker.getMobName() + " shatters one of " + target.getMobName() + "'s shadow clones!");
                }

                return "Your attack missed as it struck a shadow clone!";
            }
        }
        // ===============================================================

        // ===================== BONE SHIELD HOOK ======================
        BoneShieldEffect bse = target.getEffect(BoneShieldEffect.class);
        if (bse != null && bse.getImages() > 0) {
            if (bse.onIncomingAttack(attacker, target)) {
                attacker.sendMessage("Your attack shatters one of " + target.getMobName() + "'s bone shields!");
                target.sendMessage(attacker.getMobName() + " shatters one of your bone shields!");

                if (target.getRoom() != null) {
                    target.getRoom().broadcastToExcept(attacker, target,
                            attacker.getMobName() + " shatters one of " + target.getMobName() + "'s bone shields!");
                }

                return "Your attack missed as it struck a bone shield!";
            }
        }
        // ===============================================================

        // Apply damage (use double arithmetic for correct percentage reduction)
        double reduction = (1.0 - (TotalDefenseBonus / 100.0));
        int damageTaken = (int) Math.max(1, Math.round(totalDamage * reduction));

        target.takeDamage(damageTaken);

        // Vampiric healing happens only after successful damage
        double vampPercent = weapon != null ? weapon.getVampiricPercent() : 0.0;
        int vampHeal = (int) (damageTaken * vampPercent);
        if (vampHeal > 0) {
            attacker.heal(vampHeal);
        }

        // Messaging
        attackerMsg = "You " + verb + handLabel + " " + target.getMobName() + " for " + damageTaken + " damage! " + icon;
        String targetMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " you for " + damageTaken + " damage! " + icon;
        String roomMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " " + target.getMobName() + "! " + icon;
        String vorpalMsg = "";
        if (weapon != null && weapon.isVorpal()) {
            vorpalMsg = attacker.getMobName() + "'s " + weapon.getName() + " cuts " + target.getMobName() + " deeply.";
        }

        MagicDamageType intDamType = weapon.getIntDamType();
        
     	String intAttMsg = "Your " + weapon.getName() + " causes " + weapon.getFlatDamage()+ " extra " + intDamType.name()+intDamType.getIcon() + " damage to " + target.getMobName() + ".";
        String intTarMsg = "You recieve " + weapon.getFlatDamage() + " extra " + intDamType.name()+intDamType.getIcon() + " from " + attacker.getMobName() + "s " + weapon.getName();
     	String intRoomMsg = attacker.getMobName() + "s " + weapon.getName()  + " causes " + weapon.getFlatDamage()+ " extra " + intDamType.name()+intDamType.getIcon() + " damage to " + target.getMobName() + ".";
     	
        if (weapon != null && weapon.isIntelligent()) {
        	attacker.sendMessage(intAttMsg);
        	target.sendMessage(intTarMsg);
        	attacker.getCurrentRoom().broadcastExcept(intRoomMsg, attacker, target);
        	
        }
        
        
        
        if (attacker instanceof Player) {
            attacker.sendMessage(attackerMsg);
        }
        if (target instanceof Player) {
            target.sendMessage(targetMsg);
        } else {
            System.out.println("[Mob] " + targetMsg);
        }
        if (weapon != null && weapon.isVorpal()) {
            attacker.getRoom().broadcastToExcept(attacker, target, vorpalMsg);
        }

        FireShieldEffect.onTargetHit(attacker, target, damageTaken);
        attacker.getRoom().broadcastToExcept(attacker, target, roomMsg);

        if (target.getCurrentHP() <= 0) {
            deathStuff(attacker, target);
        }

        return attackerMsg;
    }

    public static void playerDeathStuff(Player target) {
        String deathMsg = target.getMobName() + " has been slain!";

        // clear targets and combat status
        target.setInCombat(false);
        target.setCurrentTarget(null);
        target.setTarget(null);

        // remove status effects
        // TODO
        target.removeEffect(EffectType.POISON);
        target.removeEffect(EffectType.BLEED);
        target.removeEffect(EffectType.STUN);
        target.removeEffect(EffectType.BURN);
        target.removeEffect(EffectType.FROSTBITE);
        target.removeEffect(EffectType.CURSE);
        target.removeEffect(EffectType.BLESSING);
        target.removeEffect(EffectType.REGENERATION);
        target.removeEffect(EffectType.SHIELD);
        target.removeEffect(EffectType.SILENCE);
        target.removeEffect(EffectType.ROOT);
        target.removeEffect(EffectType.CONFUSE);
        target.removeEffect(EffectType.INVISIBILITY);
        target.removeEffect(EffectType.SANCTUARY);
        target.removeEffect(EffectType.DETECT_INVISIBLE);
        target.removeEffect(EffectType.FEAR);
        target.removeEffect(EffectType.CHARM);
        target.removeEffect(EffectType.FIRE_SHIELD);
        target.removeEffect(EffectType.TAME);

        target.isDead = false;
        // set player hp to 1
        if (target instanceof Player playerAttacker) {
            playerAttacker.sendMessage(deathMsg);
            playerAttacker.setCurrentHP(1);
        }

        if (target instanceof Player playerTarget) {
            playerTarget.sendMessage("You have been slain!");
            target.setCurrentHP(1);
        }

        // remove player from room
        target.getCurrentRoom().removeMob(target);
        // send player to login screen
        target.setPendingLogout(true);
    }

    public static void deathStuff(Mob attacker, Mob target) {

        if (attacker == null || target == null) return;
        if (!target.isDead()) return;

        Room room = target.getRoom();
        if (room == null) return;

        // Stop combat immediately
        attacker.setInCombat(false);
        target.setInCombat(false);

        attacker.setTarget(null);
        attacker.setCurrentTarget(null);
        target.setTarget(null);
        target.setCurrentTarget(null);

        MobAffectFlag NOKILL = MobAffectFlag.NOKILL;
        MobAffectFlag REINCARNATE = MobAffectFlag.REINCARNATE;

        // --- REINCARNATE ---
        if (target.hasAffect(REINCARNATE)) {

            int remaining = target.getReincarnateRemaining();
            if (remaining > 0) {

                remaining--;
                target.setReincarnateRemaining(remaining);

                target.setCurrentHP(Math.max(1, target.getMaxHP() / 2));
                target.isDead = false;

                room.broadcastToRoom(
                    target.getMobName() + " rises again! (" + remaining + " reincarnations left)"
                );

                if (remaining == 0)
                    target.removeAffect(REINCARNATE);

                return; // Skip death
            }
        }

        // --- NOKILL ---
        if (target.hasAffect(NOKILL)) {
            target.setCurrentHP(1);
            target.isDead = false;

            if (attacker instanceof Player) {
                attacker.sendMessage("You cannot kill " + target.getMobName() + ".");
            }

            attacker.setTarget(null);
            attacker.setCurrentTarget(null);
            target.setTarget(null);
            target.setCurrentTarget(null);
            return;
        }

        // --- PLAYER DEATH ---
        if (target instanceof Player player) {
            playerDeathStuff(player);
        }

        // Broadcast death
        room.broadcastToRoom(target.getMobName() + " has been slain!");

        // XP reward (players only)
        if (attacker instanceof Player p) {
            p.gainExpShared(target.getExpValue());
            if (p.getExp() >= Leveling.getExpToLevel(p.getLevel())) {
                p.levelUp(p.getLevel() + 1);
                p.applyLevelScaling(p.getLevel());
            }
        }

        // Remove all aggro on this target
        for (Mob m : WorldManager.getAllMobs()) {
            if (m.getTarget() == target)
                m.setTarget(null);
        }

        // Loot drop
        List<ObjectItem> loot = target.dropAllLoot();
        for (ObjectItem item : loot) {
            room.addObject(item);
        }

        // Create corpse
        ObjectItem corpse = new ObjectItem("corpse of " + target.getMobName());
        corpse.setShortDescription("a corpse of " + target.getMobName());
        corpse.setType(ObjectType.TRASH);
        corpse.setContents(loot);
        room.addObject(corpse);

        // Remove mob from world
        room.removeMob(target);
        target.setCurrentRoom(null);

     // attacker has Berserk effect if (attacker.hasEffect(EffectType.BERSERK)) { // // attack random mob
        Mob nextPTar = attacker.getCurrentRoom().getPlayers().getFirst();
        Mob nextMTar = attacker.getCurrentRoom().getMobs().getFirst();
        if (!(nextPTar == null)) { 
        	attacker.setTarget(nextPTar);
        attacker.setCurrentTarget(nextPTar);
        attacker.getCurrentRoom().broadcastToRoom(attacker.getMobName() + " snarls and turns to fight " + nextPTar.getMobName() + "!");
        }
        else 
        { 
        	attacker.setTarget(nextMTar);
        	attacker.setCurrentTarget(nextMTar); 
        	attacker.getCurrentRoom().broadcastToRoom(attacker.getMobName() + " snarls and turns to fight " + nextMTar.getMobName() + "!");
        	}
    }


    private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
        if (weapon == null || weapon.getDamageDice() == null) {
            int level = attacker.getLevel();
            if (level >= 75) return rollDice(4, 6);
            if (level >= 50) return rollDice(3, 6);
            if (level >= 20) return rollDice(2, 6);
            if (level >= 10) return rollDice(1, 8);
            return rollDice(1, 6);
        }

        String[] parts = weapon.getDamageDice().split("d");
        int num = Integer.parseInt(parts[0]);
        int sides = Integer.parseInt(parts[1]);

        return rollDice(num, sides) + weapon.getDamageBonus();
    }

    private static int rollDice(int num, int sides) {
        int total = 0;
        for (int i = 0; i < num; i++) {
            total += random.nextInt(sides) + 1;
        }
        return total;
    }

    // --- Leveling system ---
    public static class Leveling {
        private static final int BASE_EXP = 5000;
        private static final double GROWTH_RATE = 1.25;

        public static int getExpToLevel(int level) {
            if (level <= 1) {
                return BASE_EXP;
            }
            return (int) (BASE_EXP * Math.pow(GROWTH_RATE, level - 1));
        }
    }
} // end combatManager
