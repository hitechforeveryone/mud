package mud.commands;

import java.io.File;
import java.util.List;

import mud.config.ChangeLog;
import mud.config.ChangeLogManager;
import mud.config.ChangeLogManager.ChangeLogEntry;
import mud.core.Player;

public class ChangeLogCommandHandler {

    private static final ChangeLogManager manager = new ChangeLogManager();

    private static File getFile() {
        return ChangeLog.getFile();
    }

    private static void load() {
        try {
            manager.load(getFile());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void save() {
        try {
            manager.save(getFile());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void handleChangeLog(Player player, String[] tokens) {

        load();

        if (tokens.length == 1) {
            // LIST
            List<String> versions = manager.listVersions();

            if (versions.isEmpty()) {
                player.sendMessage("No changelog entries found.");
                return;
            }

            player.sendMessage("📜 ChangeLog Versions:");
            for (String v : versions) {
                player.sendMessage(" - " + v);
            }
            return;
        }

        String sub = tokens[1].toLowerCase();

        switch (sub) {

        // -----------------------
        // VIEW VERSION
        // -----------------------
        case "view": {
            if (tokens.length < 3) {
                player.sendMessage("Usage: changelog view <version>");
                return;
            }

            String version = tokens[2];
            ChangeLogEntry entry = manager.getVersion(version);

            if (entry == null) {
                player.sendMessage("Version not found.");
                return;
            }

            player.sendMessage("📜 " + entry.getVersion() +
                (entry.getDate() != null ? " (" + entry.getDate() + ")" : ""));

            int i = 1;
            for (String change : entry.getChanges()) {
                player.sendMessage(" " + (i++) + ". " + change);
            }

            return;
        }

        // -----------------------
        // ADD VERSION
        // -----------------------
        case "addver": {
            if (tokens.length < 3) {
                player.sendMessage("Usage: changelog addver <version> [date]");
                return;
            }

            String version = tokens[2];
            String date = (tokens.length >= 4) ? tokens[3] : null;

            manager.addVersion(version, date);
            save();

            player.sendMessage("Version added: " + version);
            return;
        }

        // -----------------------
        // ADD ENTRY
        // -----------------------
        case "add": {
            if (tokens.length < 4) {
                player.sendMessage("Usage: changelog add <version> <text>");
                return;
            }

            String version = tokens[2];
            String text = String.join(" ", java.util.Arrays.copyOfRange(tokens, 3, tokens.length));

            manager.addEntry(version, text);
            save();

            player.sendMessage("Entry added to " + version);
            return;
        }

        // -----------------------
        // EDIT ENTRY
        // -----------------------
        case "edit": {
            if (tokens.length < 5) {
                player.sendMessage("Usage: changelog edit <version> <index> <text>");
                return;
            }

            String version = tokens[2];

            int index;
            try {
                index = Integer.parseInt(tokens[3]) - 1;
            } catch (NumberFormatException e) {
                player.sendMessage("Index must be a number.");
                return;
            }

            String text = String.join(" ", java.util.Arrays.copyOfRange(tokens, 4, tokens.length));

            manager.editEntry(version, index, text);
            save();

            player.sendMessage("Entry updated.");
            return;
        }

        default:
            player.sendMessage("Unknown subcommand.");
        }
    }
}