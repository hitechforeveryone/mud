package mud.commands;

import mud.core.Mob;
import mud.core.enums.Language;

import java.util.*;

public class LanguageHandler {

    private static final Random RANDOM = new Random();

    // Each language has consonants and vowels, optionally syllable motifs and accent maps
    private static final Map<Language, LanguagePattern> LANGUAGE_PATTERNS = new HashMap<>();
    static {
        // Accents
        Map<Character, char[]> elvishAccents = new HashMap<>();
        elvishAccents.put('a', new char[]{'á','â','ä'});
        elvishAccents.put('e', new char[]{'é','ë'});
        elvishAccents.put('i', new char[]{'í'});
        elvishAccents.put('o', new char[]{'ó','ö'});
        elvishAccents.put('u', new char[]{'ú'});

        Map<Character, char[]> dwarfAccents = new HashMap<>();
        dwarfAccents.put('a', new char[]{'ä'});
        dwarfAccents.put('o', new char[]{'ö'});
        dwarfAccents.put('u', new char[]{'ü'});

        Map<Character, char[]> dragonAccents = new HashMap<>();
        dragonAccents.put('a', new char[]{'à','á'});
        dragonAccents.put('e', new char[]{'è','é'});
        dragonAccents.put('s', new char[]{'š'});
        dragonAccents.put('z', new char[]{'ž'});

        Map<Character, char[]> demonAccents = new HashMap<>();
        demonAccents.put('a', new char[]{'â','ã'});
        demonAccents.put('o', new char[]{'ô','õ'});
        demonAccents.put('u', new char[]{'û'});

        LANGUAGE_PATTERNS.put(Language.COMMON, new LanguagePattern("bcdfghjklmnpqrstvwxyz","aeiou"));
        LANGUAGE_PATTERNS.put(Language.ELVISH,
                new LanguagePattern("lmrnsht","aeiouy",
                        new String[]{"el","ia","th"},
                        elvishAccents,
                        0.3 // 30% chance of accent
                ));
        LANGUAGE_PATTERNS.put(Language.DWARVISH,
                new LanguagePattern("bgrdk","auo",
                        new String[]{"og","um","ar"},
                        dwarfAccents,
                        0.4
                ));
        LANGUAGE_PATTERNS.put(Language.ORCISH, new LanguagePattern("grkzn","ao","ug","mog","rak"));
        LANGUAGE_PATTERNS.put(Language.GNOMISH, new LanguagePattern("flznqt","aeiou","fi","lo","zi"));
        LANGUAGE_PATTERNS.put(Language.TROLLISH, new LanguagePattern("thgrk","uo","th","ug","ok"));
        LANGUAGE_PATTERNS.put(Language.KOTIAN, new LanguagePattern("ktnrs","aeiou","ko","ta","ni"));
        LANGUAGE_PATTERNS.put(Language.BEASTTONGUE, new LanguagePattern("rwgkshn","ao","rr","ww","kk"));
        LANGUAGE_PATTERNS.put(Language.DRAGONESE,
                new LanguagePattern("drskgh","aeiou",
                        new String[]{"dr","th","ra"},
                        dragonAccents,
                        0.35
                ));
        LANGUAGE_PATTERNS.put(Language.ARCANO, new LanguagePattern("lrnvx","aeiou","al","or","ix"));
        LANGUAGE_PATTERNS.put(Language.DEMONIC,
                new LanguagePattern("zrkthg","auo",
                        new String[]{"za","ra","ka"},
                        demonAccents,
                        0.5
                ));
        LANGUAGE_PATTERNS.put(Language.GIANTSPEAK, new LanguagePattern("thrg","ao","th","or","gar"));
        // Morse-like short patterns
        LANGUAGE_PATTERNS.put(Language.MORSECODE, new LanguagePattern(".-","-","..")); 
        LANGUAGE_PATTERNS.put(Language.ENTISH, new LanguagePattern("lnrsgt","aoe","loo","na","ree"));
        LANGUAGE_PATTERNS.put(Language.ELEMENTAL, new LanguagePattern("fwtzr","aeiou","fi","wa","tu"));
        LANGUAGE_PATTERNS.put(Language.MERTONGUE, new LanguagePattern("mn","aeiou","mi","ma","mo"));
    }

    // Process a message for a listener, considering proficiency & familiarity
    public static String processMessage(String message, Language lang, Mob listener) {
        int prof = listener.getLanguageProficiency(lang);
        if (prof >= 95) return message;
        if (prof <= 0) return "something incomprehensible";
        return garble(message, lang, listener, prof);
    }

    private static String garble(String message, Language lang, Mob listener, int proficiency) {
        StringBuilder result = new StringBuilder();
        String[] words = message.split(" ");

        for (String word : words) {
            // Track exposure for recognizable words
            listener.rememberWord(lang, word);

            int familiarity = listener.getWordFamiliarity(lang, word);
            double recognizeChance = familiarity * 0.05; // 5% per exposure

            if (RANDOM.nextDouble() < recognizeChance || RANDOM.nextDouble() < (proficiency / 100.0)) {
                result.append(word); // recognizable
            } else {
                result.append(scrambleWord(word, lang, proficiency));
            }
            result.append(" ");
        }

        return result.toString().trim();
    }

    private static String scrambleWord(String word, Language lang, int proficiency) {

        LanguagePattern pattern = LANGUAGE_PATTERNS.getOrDefault(
                lang,
                new LanguagePattern("bcdfghjklmnpqrstvwxyz","aeiou")
        );

        StringBuilder sb = new StringBuilder();
        boolean useSyllables = pattern.syllables != null && pattern.syllables.length > 0;

        for (int i = 0; i < word.length(); i++) {
            char original = word.charAt(i);

            // Preserve punctuation
            if (!Character.isLetter(original)) {
                sb.append(original);
                continue;
            }

            // Chance to preserve original letter based on proficiency
            double preserveChance = proficiency / 100.0 * 0.5; // up to 50% preserve
            if (RANDOM.nextDouble() < preserveChance) {
                sb.append(original);
                continue;
            }

            // Replacement with syllable or consonant/vowel
            if (useSyllables && RANDOM.nextDouble() < 0.4) {
                String syll = pattern.syllables[RANDOM.nextInt(pattern.syllables.length)];
                sb.append(syll.charAt(RANDOM.nextInt(syll.length())));
            } else {
                sb.append(RANDOM.nextBoolean()
                        ? pattern.randomConsonant()
                        : pattern.randomVowel());
            }
        }

        return sb.toString();
    }

    // Handle passive exposure to languages
    public static void handleExposure(Mob listener, Mob speaker, Language lang, String originalMessage) {
        if (listener.getActiveLanguage() == lang) return;

        int prof = listener.getLanguageProficiency(lang);
        int speakerProf = speaker.getLanguageProficiency(lang);

        if (!listener.knowsLanguage(lang)) {
            if (Math.random() < 0.02) { // 2% chance
                listener.addLanguage(lang, 1);
                listener.sendMessage("You begin to pick up a few words of " + lang.name().toLowerCase() + ".");
            }
            return;
        }

        if (prof >= speakerProf) return; // cap at speaker's proficiency

        double learnChance = 0.10 * (1.0 - (prof / 100.0));
        if (Math.random() > learnChance) return;

        int gain = 1;
        int newProf = Math.min(prof + gain, speakerProf); // cap here
        listener.getLanguageProficiency().put(lang, newProf);

        if (newProf == 20 || newProf == 50 || newProf == 80) {
            listener.sendMessage("You are starting to understand more of " + lang.name().toLowerCase() + ".");
        }
    }

    // --- HELPER CLASS ---
    private static class LanguagePattern {
        String consonants;
        String vowels;
        String[] syllables;
        Map<Character, char[]> accents;
        double accentChance;

        LanguagePattern(String consonants, String vowels) {
            this(consonants, vowels, null, new HashMap<>(), 0.0);
        }

        LanguagePattern(String consonants, String vowels, String... syllables) {
            this(consonants, vowels, syllables, new HashMap<>(), 0.0);
        }

        LanguagePattern(String consonants, String vowels, String[] syllables,
                        Map<Character, char[]> accents, double accentChance) {
            this.consonants = consonants;
            this.vowels = vowels;
            this.syllables = syllables;
            this.accents = accents;
            this.accentChance = accentChance;
        }

        char randomConsonant() {
            return applyAccent(consonants.charAt(RANDOM.nextInt(consonants.length())));
        }

        char randomVowel() {
            return applyAccent(vowels.charAt(RANDOM.nextInt(vowels.length())));
        }

        private char applyAccent(char c) {
            if (accents.containsKey(c) && RANDOM.nextDouble() < accentChance) {
                char[] options = accents.get(c);
                return options[RANDOM.nextInt(options.length)];
            }
            return c;
        }
    }
}