package mud.config;

import java.io.File;

public class Config {

	public static final String gameDevTeam = "Jan Ouellette";
	public static final String engineDevTeam = "Jan Ouellette";
	public static final String gameDedication = "   Dedicated to builders, adventurers, storytellers, and late-night coders. \n\n Jon Prue, a true friend and inspiration. The man who introduced me to the Empire and Imperium DIKU-MUDs.  I started writing this game as we could not easily play together when he was in China.  Sadly he passed away before I was able to get a demo out to him.  He was a very well travelled man and expierenced many things in his life. He suffered silently to alcohol addiction, but if he had just reached out to us, we would have given him all the love and attention he needed.  You will be missed my friend. \n  Troy Phister, another true friend.  He was a constant presence on Empire and then later on Imperium.  He was an avid explorer of both the world and Empire/Imperium, and sadly passed away too early to see the development of this game.  Troy drove many of our groups to explore new areas of Imperium, and he was always willing to join your party for an adventure or just purely to hang out.";
	
	public static final String gameName = "Tithrius";
	public static final String gameVersion = "v0.7.0.20";
	
	public static final String gameHistory = "Empire Mud refers to the MUD (Multi-User Dungeon) called Empire, which was built on the classic DikuMUD engine, a popular, hack-and-slash fantasy text-based game framework from the early 90s. Empire was known for its large world, emphasis on role-playing (RP), complex custom features like unique magic/skill systems, and player-run empire building, setting it apart from standard Diku MUDs.  \n\n  Imperium began as a schism or coup'd'eta against the management running Empire.  Imperium shared the same basic topography as Empire, and many players secretly played on both, either openly or coverly. Imperium has had an active player and Imm base until shortly after COVID.  Imperium has gone through a few code updates and new zone developmentsm it is currently available to play on at imperium.genesismuds.com:40000, though current support is unknown. \n Empire and Imperium ran on C-based DIKU engines. \n  I initially played on both Empire and Imperium from '98-02 before moving on to other games, I later came back to Imperium in 2018 for nostalgia and by 2023 an Imm and zone developer.  However by late '25, it appears the player base of Imperium has dwindled away.  When I started my new job in 2021, I was unable to easily access Imperium from work, so I started developing this project to kill time while at work.  \n\n  Tithrius is being developed as a brand project inspired by the expierences of playing on Empire and zone developing on Imperium.  As this is a fresh project, it is not using any of the old C-based DIKU engine, but a fresh engine written in JAVA (also causing me to relearn JAVA in the process).  The engine code base is very small, modular and still allows for world growth.  Potentially it could be run off a laptop or smartphone or a Raspberry Pi microboard.  As this is a brand new engine it is bound to have growth spurts and bugs. \n  I am not expecting a lot from this game, text based games and MUDs are not very common gaming platforms anymore, everyone is after either cartoonish or lifelike graphics.  This is a project and labor of love." ;
	
	public static final String specialThanks = "Greg Milford for the history, encouragement and code dev talks, Hanno Bulhof and Sten Olsson for the history talks on Empire/Imperium.";
	
	
	// v0.7.0.20 - Sentry Behavior stuff for mobBehaviorFlag.SENTRY
	// v0.7.0.19 - seasons and weather system update
	// v0.7.0.18 - mob editor updates for shopkeeper
	// v0.7.0.17 - Zone Script Triggers
	// v0.7.0.16 - TreasureValue - coins + gems
	// v0.7.0.15 - Spell/Effects standardization
	// v0.7.0.14 - RoomEditor updates
	// v0.7.0.13 - ZoneExit work
	// v0.7.0.12
	// v0.7.0.11 - Jan 2, 2026
	// v0.7.0.10 logs, bugs, ideas, quaff, use, recite - Jan 1, 2026
	// v0.7.0.9a player backers, save world state (tick) - Dec 31, 2025
	// v0.7.0.9 world/zone map system
	// v0.7.0.8 combat system rewrite
	// v0.7.0.7 Shops/Banks, leveling
	// v0.7.0.6 Zone Scripts! - Recall Nodes, Mobs, Objects, Doors
	// v0.7.0.5 object editor
	// v0.7.0.4 redesign of spell registry
	// v0.7.0.3 basic mobAI implemented, work on zone scripts
	// v0.7.0.2 Zone exits work
	// v0.7.0.1 redesign of base structure on game, modularized game systems
	// v0.7.0.0 created a Server and Client login system for game - 2025
	// v0.6.0.0 player objects gone, players are now Mobs 2024
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux now
	// game v0.5.0 introduces zone objects and zoneScript objects (not working) - 2024

	
	
    // Base directory for all MUD data files
    public static final String DATA_DIR = "mud_data";

    // Subdirectories for different data types
    public static final String PLAYERS_DIR = DATA_DIR + File.separator + "players";
    public static final String BACKUP_FOLDER = PLAYERS_DIR + "/backup";
    public static final String WORLDS_DIR = DATA_DIR + File.separator + "worlds";
    public static final String ZONES_DIR = DATA_DIR + File.separator + "zones";
    public static final String SCRIPT_DIR = DATA_DIR + File.separator + "zones";
    public static final String MOBS_DIR = DATA_DIR + File.separator + "mobs";
    public static final String OBJECTS_DIR = DATA_DIR + File.separator + "objects";
    public static final String LOGS_DIR = DATA_DIR + File.separator + "logs";
    public static final String HELPS_DIR = DATA_DIR + File.separator + "helps";
    public static final String MAPS_DIR = DATA_DIR + File.separator + "maps";

    // Game settings
    public static final int SERVER_PORT = 4000;
    public static final int CLIENT_TIMEOUT_MILLIS = 10 * 60 * 1000; // 10 minutes
    
    public static final String DEFAULT_WORLD_ID = "1";
    public static final int DEFAULT_LOGIN_ZONE = 0;
    public static final int DEFAULT_LOGIN_ROOM = 0;
    
    // UNIVERSAL DAY LENGTH
    public static final int tickIntervalMillis = 5000; // .5 seconds per tick
    public final static int ticksPerDay = 60; // 60 ticks = 1 game day
    public final static int sunriseTick = 10; // example: tick 15
    public final static int sunsetTick = 50;  // example: tick 45

    // Ensures the directory structure exists on startup
    public static void createDirectories() {
        new File(PLAYERS_DIR).mkdirs();
        new File(BACKUP_FOLDER).mkdirs();
        new File(WORLDS_DIR).mkdirs();
        new File(ZONES_DIR).mkdirs();
        new File(MOBS_DIR).mkdirs();
        new File(OBJECTS_DIR).mkdirs();
        new File(LOGS_DIR).mkdirs();
        new File(HELPS_DIR).mkdirs();
        new File(MAPS_DIR).mkdirs();
               
    }

    // You can add more config values or helper methods here...

    private Config() {
        // Prevent instantiation
    }
}
