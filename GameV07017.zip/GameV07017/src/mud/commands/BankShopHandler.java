package mud.commands;

import java.util.*;

import mud.Shop.*;
import mud.core.*;
import mud.core.enums.MobBehaviorFlag;
import mud.core.enums.ObjectType;

public class BankShopHandler {


	// BANK STUFF
	// Helper to format copper into "Xp Yg Zs Wc"


	private static String formatCoins(int totalCopper) {
		int platinum = totalCopper / 1000000;
		totalCopper %= 1000000;
		int gold = totalCopper / 10000;
		totalCopper %= 10000;
		int silver = totalCopper / 100;
		int copper = totalCopper % 100;

		List<String> parts = new ArrayList<>();
		if (platinum > 0) parts.add(platinum + "p");
		if (gold > 0) parts.add(gold + "g");
		if (silver > 0) parts.add(silver + "s");
		if (copper > 0 || parts.isEmpty()) parts.add(copper + "c");

		return String.join(" ", parts);
	}

	public static String handleDepositCoins(Player player, String input) {
		if (input == null || input.trim().isEmpty()) {
			return "Usage: deposit <amount> (e.g., 1p 5g 20s 30c, 3g 50c, 15s, 200)\r\n"
					+ "Specify coins in platinum (p), gold (g), silver (s), copper (c). Omitted types are treated as zero.\r\n"
					+ "No suffix defaults to copper.";
		}

		try {
			int totalCopper = 0;

			// parse input like "1g 15s 30c"
			String[] tokens = input.toLowerCase().split("\\s+");
			for (String token : tokens) {
				if (token.endsWith("p")) totalCopper += Integer.parseInt(token.replace("p","")) * 10000 * 100;
				else if (token.endsWith("g")) totalCopper += Integer.parseInt(token.replace("g","")) * 10000;
				else if (token.endsWith("s")) totalCopper += Integer.parseInt(token.replace("s","")) * 100;
				else if (token.endsWith("c")) totalCopper += Integer.parseInt(token.replace("c",""));
				else totalCopper += Integer.parseInt(token); // default copper
			}

			if (totalCopper <= 0) return "You must deposit a positive amount.";

			BankManager.Vault vault = BankManager.playerVaults.get(player.getId());
			if (vault == null) return "You do not own a vault. Use 'vaultbuy' to purchase one.";

			if (player.getTotalCopper() >= totalCopper) {
				player.addCopper(-totalCopper);
				vault.addCopper(totalCopper);
				return "Deposited " + formatCoins(totalCopper) + " into your vault.";
			} else {
				return "You do not have enough coins to deposit that amount.";
			}
		} catch (NumberFormatException e) {
			return "Invalid number format. Usage: deposit <amount> (e.g., 1g 15s 30c)";
		}
	}



	public static String handleWithdrawCoins(Player player, String input) {
		if (input == null || input.trim().isEmpty()) {
			return "Usage: withdraw <amount> (e.g., 1p 5g 20s 30c, 3g 50c, 15s, 200)\r\n"
					+ "Specify coins in platinum (p), gold (g), silver (s), copper (c). Omitted types are treated as zero.\r\n"
					+ "No suffix defaults to copper.\r\n"
					+ "";
		}

		try {
			int totalCopper = 0;

			String[] tokens = input.toLowerCase().split("\\s+");
			for (String token : tokens) {
				if (token.endsWith("p")) totalCopper += Integer.parseInt(token.replace("p","")) * 10000 * 100;
				else if (token.endsWith("g")) totalCopper += Integer.parseInt(token.replace("g","")) * 10000;
				else if (token.endsWith("s")) totalCopper += Integer.parseInt(token.replace("s","")) * 100;
				else if (token.endsWith("c")) totalCopper += Integer.parseInt(token.replace("c",""));
				else totalCopper += Integer.parseInt(token);
			}

			if (totalCopper <= 0) return "You must withdraw a positive amount.";

			BankManager.Vault vault = BankManager.playerVaults.get(player.getId());
			if (vault == null) return "You do not own a vault. Use 'vaultbuy' to purchase one.";

			if (vault.getCopper() >= totalCopper) {
				vault.addCopper(-totalCopper);
				player.addCopper(totalCopper);
				return "Withdrew " + formatCoins(totalCopper) + " from your vault.";
			} else {
				return "Not enough funds in your vault to withdraw that amount.";
			}
		} catch (NumberFormatException e) {
			return "Invalid number format. Usage: withdraw <amount> (e.g., 1g 15s 30c)";
		}
	}



	public static String handleDepositItem(Player player, String inputName) {
		BankManager.Vault vault = BankManager.playerVaults.get(player.getId());
		if (vault == null) return "You do not own a vault.";

		if (player.getInventory() == null || player.getInventory().isEmpty()) {
			return "You don't have any items to deposit.";
		}

		ObjectItem toDeposit = null;
		String lowerInput = inputName.toLowerCase();

		for (ObjectItem item : player.getInventory()) {
			if (item != null && item.matchesKeyword(lowerInput)) {
				toDeposit = item;
				break;
			}
		}

		if (toDeposit == null) return "You don't have an item matching '" + inputName + "'.";
		if (vault.getItems().size() >= 100) return "Vault is full.";

		vault.getItems().add(toDeposit);
		player.removeItem(toDeposit);
		return "Deposited " + toDeposit.getName() + " into your vault.";
	}


	public static String handleWithdrawItem(Player player, String inputName) {
		BankManager.Vault vault = BankManager.playerVaults.get(player.getId());
		if (vault == null) return "You do not own a vault.";

		if (vault.getItems() == null || vault.getItems().isEmpty()) {
			return "Your vault is empty.";
		}

		ObjectItem toWithdraw = null;
		String lowerInput = inputName.toLowerCase();

		for (ObjectItem item : vault.getItems()) {
			if (item != null && item.matchesKeyword(lowerInput)) {
				toWithdraw = item;
				break;
			}
		}

		if (toWithdraw == null) return "No item in your vault matches '" + inputName + "'.";

		vault.getItems().remove(toWithdraw);
		player.addItem(toWithdraw);
		return "Withdrew " + toWithdraw.getName() + " from your vault.";
	}


	public static String handleListVault(Player player) {
		BankManager.Vault vault = BankManager.playerVaults.get(player.getId());
		if (vault == null) return "You do not own a vault.";

		// reuse BankManager method
		return BankManager.listVaultContents(player);
	}

	public static String handlePurchaseVault(Player player) {
		if (player.ownsVault) return "You already own a vault.";

		int cost = 5000; // copper
		if (player.getTotalCopper() >= cost) {
			player.addCopper(-cost);
			BankManager.playerVaults.put(player.getId(), new BankManager.Vault());
			player.ownsVault = true;
			return "Vault purchased! You can now deposit coins and items.";
		} else {
			return "Not enough funds to purchase a vault.";
		}
	}

	// ---------------------
	// Normalize all coin denominations and report via player message
	// ---------------------
	public static void handleExchange(Player player) {
		if (player == null) return;

		// Total copper in player's inventory
		int totalCopper = player.getCopper() 
				+ player.getSilver() * 100 
				+ player.getGold() * 10000 
				+ player.getPlatinum() * 1000000;

		// Calculate normalized denominations
		int platinum = totalCopper / 1000000;
		totalCopper %= 1000000;

		int gold = totalCopper / 10000;
		totalCopper %= 10000;

		int silver = totalCopper / 100;
		int copper = totalCopper % 100;

		// Track changes
		int diffPlatinum = platinum - player.getPlatinum();
		int diffGold = gold - player.getGold();
		int diffSilver = silver - player.getSilver();
		int diffCopper = copper - player.getCopper();

		// Apply normalized coins
		player.setPlatinum(platinum);
		player.setGold(gold);
		player.setSilver(silver);
		player.setCopper(copper);

		// Build exchange report
		StringBuilder report = new StringBuilder("Coin exchange completed:\n");
		if (diffPlatinum != 0) report.append("- Platinum: ").append(diffPlatinum > 0 ? "+" : "").append(diffPlatinum).append("\n");
		if (diffGold != 0) report.append("- Gold: ").append(diffGold > 0 ? "+" : "").append(diffGold).append("\n");
		if (diffSilver != 0) report.append("- Silver: ").append(diffSilver > 0 ? "+" : "").append(diffSilver).append("\n");
		if (diffCopper != 0) report.append("- Copper: ").append(diffCopper > 0 ? "+" : "").append(diffCopper).append("\n");

		if (diffPlatinum == 0 && diffGold == 0 && diffSilver == 0 && diffCopper == 0) {
			report.append("- No change; coins were already normalized.\n");
		}

		// Send message to player
		player.sendMessage(report.toString());
	}

	
	
	
	public static String handleBuy(Player player, String[] tokens) {

		String itemName = tokens[1];

		Mob shop = player.getCurrentRoom().getShopkeeper();
		if (shop == null || !shop.hasBehavior(MobBehaviorFlag.SHOPKEEPER)) {
			return "There is no shopkeeper here.";
		}

		ShopProfile profile = shop.getShopProfile();
		if (profile == null) {
			return shop.getMobName() + " looks confused and cannot trade.";
		}

		ObjectItem template = shop.findShopItem(itemName);
		if (template == null) {
			return shop.getMobName() + " says, 'I don't sell that.'";
		}

		int baseValue = template.getValue();
		int price = Math.max(1, (int) Math.round(baseValue * profile.getBuyModifier()));

		if (!player.canAfford(price)) {
			return "You cannot afford that.";
		}

		ObjectItem item = template.copy(); // IMPORTANT: copy, never reuse

		player.subtractCopper(price);
		player.addItem(item);

		shop.addCopper(price);

		return "You buy " + item.getShortDescription() +
				" for " + price + " copper.";
	}
	// end
	public static String handleSell(Player player, String[] tokens) {

		String itemName = tokens[1];

		Mob shop = player.getCurrentRoom().getShopkeeper();
		if (shop == null || !shop.hasBehavior(MobBehaviorFlag.SHOPKEEPER)) {
			return "There is no shopkeeper here.";
		}

		ShopProfile profile = shop.getShopProfile();
		if (profile == null) {
			return shop.getMobName() + " cannot trade right now.";
		}

		ObjectItem item = player.findItemByName(itemName);
		if (item == null) {
			return "You aren't carrying that.";
		}

		ObjectType type = item.getObjectType();
		if (!profile.getBuys().contains(type)) {
			return shop.getMobName() + " says, 'I have no interest in that.'";
		}

		int baseValue = item.getValue();
		int price = Math.max(1, (int) Math.round(baseValue * profile.getSellModifier()));

		if (shop.getTotalCopper() < price) {
			return shop.getMobName() + " says, 'I can't afford that right now.'";
		}

		player.removeItem(item);
		player.addCopper(price);

		shop.subtractCopper(price);

		return "You sell " + item.getShortDescription() +
				" for " + price + " copper.";
	}
	// end


}
