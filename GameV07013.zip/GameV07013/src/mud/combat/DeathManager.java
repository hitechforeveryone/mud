package mud.combat;

import java.util.List;

import mud.config.Config;
import mud.core.*;

public class DeathManager {

	public static void handleDeath(Mob attacker, Mob target) {
		if (attacker == null || target == null) return;
		if (target.getCurrentHP() > 0) return;

		Room room = target.getRoom();
		if (room == null) return;

		// Stop combat
		clearCombat(attacker, target);

		target.setDead(true);

		// Reincarnation
		if (target.hasAffect(MobAffectFlag.REINCARNATE)) {
			int remaining = target.getReincarnateRemaining();
			if (remaining > 0) {
				target.setReincarnateRemaining(remaining - 1);
				target.setCurrentHP(Math.max(1, target.getMaxHP() / 2));
				target.setDead(false);
				room.broadcastToRoom(
						target.getMobName() + " rises again! (" + (remaining - 1) + " reincarnations left)"
						);
				if (remaining - 1 <= 0) target.removeAffect(MobAffectFlag.REINCARNATE);
				return;
			}
		}

		// No-kill effect
		if (target.hasAffect(MobAffectFlag.NOKILL)) {
			target.setCurrentHP(1);
			target.setDead(false);
			if (attacker instanceof Player player)
				player.sendMessage("You cannot kill " + target.getMobName() + ".");
			clearCombat(attacker, target);
			return;
		}

		// Player death
		if (target instanceof Player player) {
			playerDeathStuff(player);
			return;
		}

		// NPC death
		broadcastDeath(attacker, target);

		// XP reward
		if (attacker instanceof Player p) {
			p.gainExpShared(target.getExpReward());
		}

		spawnCorpse(target, room);

		if (target instanceof Player) {
			String cause = String.format("Killed by %s (Lv %d)", attacker.getMobName(), attacker.getLevel());
			MudLogger.logDeath((Player) target, cause);
		}

		// --- BERSERK RETARGET ---
		if (attacker.hasEffect(EffectType.BERSERK)) {
			Mob next = room.findRandomHostile(attacker);
			if (next != null) {
				attacker.setTarget(next);
				attacker.setCurrentTarget(next);
				attacker.setInCombat(true);
				room.broadcastToRoom(
						attacker.getMobName() + " snarls and turns to fight " + next.getMobName() + "!"
						);
			}
		}

	}

	private static void spawnCorpse(Mob target, Room room) {
		// Loot → corpse
		List<ObjectItem> loot = target.dropAllLoot(); // inventory + equipment
		
		ObjectItem corpse = new ObjectItem("corpse of " + target.getMobName());
		corpse.setShortDescription("a corpse of " + target.getShortDescription());

		corpse.setType(ObjectType.CONTAINER);
		corpse.setSize(1000);
		String corpseKeys = "corpse, " + target.getMobName();
		corpse.setKeywords(corpseKeys);

		// fill corpse with loot
		if (!loot.isEmpty()) {
			for (ObjectItem o : loot) {
				corpse.addContents(o);
			}
		}
		corpse.setCorpse(true);
		corpse.setDecayTicks(3 * Config.ticksPerDay); // assuming 1 day = X ticks

		room.addObject(corpse);

		// Remove from world
		room.removeMob(target);
		target.setCurrentRoom(null);

	}

	public static void broadcastDeath(Mob attacker, Mob target) {
		Room room = target.getRoom();
		if (room != null) {
			room.broadcastToRoom(target.getMobName() + " has been slain!");
		}
	}

	public static void clearCombat(Mob attacker, Mob target) {
		// Clear the direct combatants
		if (attacker != null) {
			attacker.setInCombat(false);
			attacker.setTarget(null);
			attacker.setCurrentTarget(null);
		}
		if (target != null) {
			target.setInCombat(false);
			target.setTarget(null);
			target.setCurrentTarget(null);
		}

		// Clear aggro on attacker
		if (attacker != null) {
			for (Mob m : WorldManager.getAllMobs()) {
				if (m.getTarget() == attacker || m.getCurrentTarget() == attacker) {
					m.setInCombat(false);
					m.setTarget(null);
					m.setCurrentTarget(null);
				}

			}
		}

		// Clear aggro on target
		if (target != null) {
			for (Mob m : WorldManager.getAllMobs()) {
				if (m.getTarget() == target || m.getCurrentTarget() == target) {
					m.setInCombat(false);
					m.setTarget(null);
					m.setCurrentTarget(null);
				}
			}
		}
	}




	public static void playerDeathStuff(Player target) {

		target.setDead(true);
		target.setCurrentHP(0);

		target.removeAllCombatEffects(); // you should add this helper

		target.sendMessage("You have been slain!");

		Room room = target.getRoom();
		if (room != null)
			room.removeMob(target);

		target.setCurrentHP(1);
		target.setPendingLogout(true);

	}
}
