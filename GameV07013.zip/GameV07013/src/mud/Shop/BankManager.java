package mud.Shop;

import mud.core.*;

import java.util.*;

public class BankManager {

	private static final int VAULT_COST = 5000; // in copper
	private static final int VAULT_MAX_ITEMS = 100;

	// Stores player vaults separately from inventory
	public static  Map<Integer, Vault> playerVaults = new HashMap<>();

	// ---------------------
	// Normalize player coins
	// ---------------------
	public void normalizeCoins(Player player) {
		int totalCopper = player.getCopper();
		int platinum = totalCopper / 10000;
		totalCopper %= 10000;
		int gold = totalCopper / 100;
		totalCopper %= 100;

		player.setPlatinum(platinum);
		player.setGold(gold);
		player.setCopper(totalCopper);
	}

	// ---------------------
	// Deposit coins
	// ---------------------
	public void depositCoins(Player player, int copper) {
		player.addCopper(copper);
		normalizeCoins(player);
	}

	// ---------------------
	// Withdraw coins
	// ---------------------
	public boolean withdrawCoins(Player player, int copper) {
		if (player.getTotalCopper() < copper) return false;
		player.addCopper(-copper);
		normalizeCoins(player);
		return true;
	}

	// ---------------------
	// Purchase a vault
	// ---------------------
	public boolean purchaseVault(Player player) {
	    if (playerVaults.containsKey(player.getId()) || player.ownsVault) return false;
	    if (withdrawCoins(player, VAULT_COST)) {
	        playerVaults.put(player.getId(), new Vault());
	        player.ownsVault = true; // mark player as owning a vault
	        return true;
	    }
	    return false;
	}


	// ---------------------
	// Deposit to vault (coins)
	// ---------------------
	public boolean depositToVaultCoins(Player player, int copper) {
		Vault vault = playerVaults.get(player.getId());
		if (vault == null) return false;
		if (withdrawCoins(player, copper)) {
			vault.addCopper(copper);
			return true;
		}
		return false;
	}

	// ---------------------
	// Withdraw from vault (coins)
	// ---------------------
	public boolean withdrawFromVaultCoins(Player player, int copper) {
		Vault vault = playerVaults.get(player.getId());
		if (vault == null || vault.getCopper() < copper) return false;
		vault.addCopper(-copper);
		depositCoins(player, copper);
		return true;
	}

	// ---------------------
	// Deposit item into vault
	// ---------------------
	public boolean depositItemToVault(Player player, ObjectItem item) {
		Vault vault = playerVaults.get(player.getId());
		if (vault == null) return false;
		if (vault.getItems().size() >= VAULT_MAX_ITEMS) return false; // vault full
		vault.getItems().add(item);
		return true;
	}

	// ---------------------
	// Withdraw item from vault
	// ---------------------
	public boolean withdrawItemFromVault(Player player, ObjectItem item) {
		Vault vault = playerVaults.get(player.getId());
		if (vault == null) return false;
		return vault.getItems().remove(item);
	}

	// ---------------------
	// Withdraw item by name (first match)
	// ---------------------
	public ObjectItem withdrawItemByName(Player player, String name) {
		Vault vault = playerVaults.get(player.getId());
		if (vault == null) return null;

		for (ObjectItem item : vault.getItems()) {
			if (item.getName().equalsIgnoreCase(name)) {
				vault.getItems().remove(item);
				return item;
			}
		}
		return null; // not found
	}

	// ---------------------
	// List vault contents with counts (sorted alphabetically, coins normalized with Silver)
	// ---------------------
	public static String listVaultContents(Player player) {
	    Vault vault = playerVaults.get(player.getId());
	    
	    if (vault == null) return "You do not have a vault.";

	    int totalCopper = vault.getCopper();

	    int platinum = totalCopper / 1000000;
	    totalCopper %= 1000000;

	    int gold = totalCopper / 10000;
	    totalCopper %= 10000;

	    int silver = totalCopper / 100;
	    int copper = totalCopper % 100;

	    // TreeMap sorts items alphabetically
	    Map<String, Integer> itemCounts = new TreeMap<>();
	    for (ObjectItem item : vault.getItems()) {
	        String key = item.getName();
	        itemCounts.put(key, itemCounts.getOrDefault(key, 0) + 1);
	    }

	    StringBuilder sb = new StringBuilder();
	    sb.append("Vault Contents:\n");

	    // Build coin string dynamically, skipping zeros
	    List<String> coinParts = new ArrayList<>();
	    if (platinum > 0) coinParts.add(platinum + "p");
	    if (gold > 0) coinParts.add(gold + "g");
	    if (silver > 0) coinParts.add(silver + "s");
	    if (copper > 0 || coinParts.isEmpty()) coinParts.add(copper + "c"); // always show at least copper

	    sb.append("- Coins: ").append(String.join(" ", coinParts)).append("\n");

	    if (itemCounts.isEmpty()) {
	        sb.append("- No items stored.\n");
	    } else {
	        for (Map.Entry<String, Integer> entry : itemCounts.entrySet()) {
	            sb.append("- ").append(entry.getKey()).append("\n");
	        }
	    }

	    return sb.toString();
	}




	// ---------------------
	// Get vault object
	public static Vault getVault(Player player) {
	    return playerVaults.get(player.getId());
	}



	// ---------------------
	// Vault class
	// ---------------------
	public static class Vault {
		private int vaultcopper = 0;
		private List<ObjectItem> vaultitems = new ArrayList<>();

		public int getCopper() {
			return vaultcopper;
		}

		public void addCopper(int amount) {
			this.vaultcopper += amount;
		}

		public List<ObjectItem> getItems() {
			return vaultitems;
		}
		
		public void setCopper(int amount) {
		    this.vaultcopper = amount;
		}

	}
}
