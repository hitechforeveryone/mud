package mud.scripting;

import mud.core.*;

public class ZoneUtils {

	public static void forceBroadcastToRoom(Room room, String message) {
	    String worldId = room.getZone().getWorld().getWorldId();
	    int zoneId  = room.getZone().getZoneId();
	    int roomId  = room.getId();

	    for (Player p : WorldManager.getAllPlayers()) {
	        Room pr = p.getCurrentRoom();
	        if (pr == null) continue;

	        if (pr.getZone().getWorld().getWorldId() == worldId &&
	            pr.getZone().getZoneId() == zoneId &&
	            pr.getId() == roomId) {

	            p.sendMessage(message);
	        }
	    }
	}


	
	

    
}
