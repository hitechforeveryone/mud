package mud.core;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import mud.commands.*;
import mud.spell.*;

public class MobAI {

	
	public static void tickMobBehavior() {
		for (Mob mob : WorldManager.getAllMobs()) {
			Room room = mob.getCurrentRoom();
	        Room current = mob.getCurrentRoom();
			if (room == null) continue; // skip if mob has no room
			
	        Map<Direction, Room> exits = current.getExits();
	        if (exits == null || exits.isEmpty()) {
	            return; // No exits, cannot flee
	        }
	     // Collect functional exits
	        List<Direction> validDirs = new ArrayList<>();
	        for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	            Direction dir = entry.getKey();
	            Room dest = entry.getValue();
	            if (dest == null) continue;

	            Door door = current.getDoor(dir);
	            if (door != null) {
	                if (!door.isOpen() || door.isLocked()) continue;
	            }

	            if (MovementHandler.isMovementBlocked(mob, mob.getCurrentRoom(), dir)) continue;

	            validDirs.add(dir);
	        }

	        // 🚨 MUST CHECK HERE
	        if (validDirs.isEmpty()) {
	            continue; // NOT return
	        }

	        // Safe now
	        Direction fleeDir = validDirs.get(ThreadLocalRandom.current().nextInt(validDirs.size()));
	        Room escapeRoom = exits.get(fleeDir);


	        
			
			// --- WIMPY ----
			// Clean & Correct WIMPY Flee Logic

			if (mob.hasBehavior(MobBehaviorFlag.WIMPY) && mob.getInCombat()) {
			    // Trigger flee when HP <= 20%
			    if (mob.getCurrentHP() <= mob.getMaxHP() / 5) {
		
			        if (validDirs.isEmpty()) {
			            return; // No usable exits
			        }

			        // Move mob
			        current.removeMob(mob);
			        escapeRoom.addMob(mob);
			        mob.setCurrentRoom(escapeRoom);
			       // mob.setRoom(escapeRoom);

			        // Drop combat
			        if (mob.getCurrentTarget() != null) {
			            mob.getCurrentTarget().setTarget(null);
			        }
			        mob.setTarget(null);
			        mob.setInCombat(false);

			        // Output messaging
			        current.broadcast(mob.getMobName() + " flees to the " + fleeDir.name() + "!", mob);
			        escapeRoom.broadcast(mob.getMobName() + " rushes in, fleeing in terror!", mob);

			//        System.out.println("DEBUG: " + mob.getMobName() + " fled " + fleeDir.name() + " to room " + escapeRoom.getId());
			    }
			}
						

			// --- CITYGUARD ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.CITYGUARD) && !mob.getInCombat()) {
				// check mobs and players in room
				List<Mob> potentialVictims = new ArrayList<>();
				potentialVictims.addAll(room.getMobs());
				potentialVictims.addAll(room.getPlayers());

				for (Mob victim : potentialVictims) {
					if (victim == mob) continue; // skip self
					if (!victim.getInCombat() || victim.getTarget() == null) continue;

					Mob aggressor = victim.getTarget();
					if (aggressor == mob) continue; // don’t rescue from self
					if (aggressor.getTarget() != victim) continue; // only intervene if aggressor is still fighting victim

					room.broadcast(mob.getMobName() + " intervenes to protect " + victim.getMobName() + "!", mob);
			//		System.out.println(mob.getMobName() + " rescued " + victim.getMobName() + " from " + aggressor.getMobName());

					// Guard takes over combat
					mob.setTarget(aggressor);
					mob.setInCombat(true);

					aggressor.setTarget(mob);
					aggressor.setInCombat(true);

					victim.setTarget(null);
					victim.setInCombat(false);

					break; // only rescue once per tick
				}
			}

			// --- ASSISTER ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.ASSISTER) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					if (player.getInCombat() && player.getTarget() != null) {
						room.broadcast(mob.getMobName() + " rushes to aid its ally against " + player.getMobName() + "!", mob);
						mob.setTarget(player);
						mob.setInCombat(true);
						break;
					}
				}
			}


			// --- AGGRESSIVE ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.AGGRESSIVE) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {

					if (player == null) continue; // safety
					// Optional: skip dead/disconnected players here

					room.broadcast(mob.getMobName() + " snarls and attacks " + player.getMobName() + "!", mob);
			//		System.out.println(mob.getMobName() + " attacked " + player.getMobName());

					// Mob engages combat
					mob.setTarget(player);
					mob.setInCombat(true);

					// Player is now in combat with mob
					player.setTarget(mob);
					player.setInCombat(true);

					break; // only attack one player per tick
				}
			}


			// --- JANITOR ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.JANITOR)) {
				for (ObjectItem obj : new ArrayList<>(room.getObjects())) { // avoid CME
					if (obj.getObjectType() == ObjectType.TRASH || obj.getObjectType() == ObjectType.CONTAINER) {
						mob.addItem(obj);
						room.removeObject(obj);
						room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);
					}
				}
			}


			// --- HUNTER ---
			if (mob.hasBehavior(MobBehaviorFlag.HUNTER)) {

			    // If already chasing someone, make sure they're valid
			    Mob chaseTarget = mob.getChaseTarget();
			    if (chaseTarget != null) {

			        // Target must be alive, have a room, and remain in same zone
			        Room tRoom = chaseTarget.getCurrentRoom();
			        Room mRoom = mob.getCurrentRoom();

			        if (tRoom == null || mRoom == null || tRoom.getZone() != mRoom.getZone()) {
			            mob.setChaseTarget(null); // drop chase
			        } 
			        else if (tRoom == mRoom) {
			            // Already caught up — attack!
			            mRoom.broadcast(mob.getMobName() + " lunges at " + chaseTarget.getMobName() + "!", mob);
			            mob.setTarget(chaseTarget);
			            mob.setInCombat(true);
			            chaseTarget.setTarget(mob);
			            chaseTarget.setInCombat(true);
			            continue;
			        } 
			        else {
			            // Move one step toward target
			            Direction chaseDir = getBestChaseDirection(mob, chaseTarget);
			            if (chaseDir != null) {
			                Room next = mRoom.getExit(chaseDir);
			                if (next != null && !next.hasFlag(RoomFlag.NOMOB)) {

			                    // Handle doors
			                    Door door = mRoom.getDoor(chaseDir);
			                    if (door != null && door.isClosed()) {
			                        // Hunters can open but not pass locked doors
			                        if (!door.isLocked()) {
			                            door.setOpen(true);
			                            mRoom.broadcast(mob.getMobName() + " opens the " + door.getDoorName() + ".", mob);
			                        } else {
			                            // Door is locked → abort chase this tick
			                            continue;
			                        }
			                    }

			                    // Move mob
			                    mRoom.removeMob(mob);
			                    next.addMob(mob);
			                    mob.setCurrentRoom(next);
			                    next.broadcast(mob.getMobName() + " arrives, hunting someone.", mob);
			                }
			            }
			            continue; // hunter only does one thing per tick
			        }
			    }

			    // Not currently chasing — look for players in room
			    room = mob.getCurrentRoom();
			    if (room != null) {
			        for (Mob player : room.getPlayers()) {
			            mob.setChaseTarget(player);
			            room.broadcast(mob.getMobName() + " fixes its gaze on " + player.getMobName() + "!", mob);
			            break;
			        }
			    }
			}


			// --- HEALER ----
			if (mob.hasBehavior(MobBehaviorFlag.HEALER)) {
				room = mob.getCurrentRoom();
			    if (room != null) {
			        // 1-in-10 chance
			        if (new Random().nextInt(10) == 0) {
			            // Find first healable target in room
			            Mob target = null; // can be Mob or Player

			            // Check mobs first
			            for (Mob m : room.getMobs()) {
			                if (m != mob && m.getCurrentHP() < m.getMaxHP()) {
			                    target = m;
			                    break;
			                }
			            }

			            // If none, check players
			            if (target == null) {
			                for (Player p : room.getPlayers()) {
			                    if (p.getCurrentHP() < p.getMaxHP()) {
			                        target = p;
			                        break;
			                    }
			                }
			            }

			            // If we have someone to heal, do it
			            if (target != null) {

			                SpellManager.castSpell("heal", mob, target);

			                room.broadcast(
			                    mob.getMobName() + " casts a healing spell on " + target.getMobName() + ".",
			                    mob
			                );
			            }
			        }
			    }
			}


			// --- PICKPOCKET ----
			if (mob.hasBehavior(MobBehaviorFlag.PICKPOCKET)) {
			    
			    Room r = mob.getCurrentRoom();
			    if (r == null) return;
		    
			    boolean concealed = false;
			   
			    if (mob.hasAffect(MobAffectFlag.INVISIBLE) || mob.hasAffect(MobAffectFlag.HIDE) ) {
			        concealed = true;
			    } 

			    // 1-in-10 chance per tick
			    if (!concealed || new Random().nextInt(10) != 0) {
			        // Still check other AI behaviors
			    } else {
			        // Attempt a theft
			        for (Mob victim : r.getPlayers()) {
			            if (victim == null) continue;
			            if (victim == mob) continue;
			            if (victim.getCurrentHP() <= 0) continue;

			            int steal = 0;
			            String coin = null;

			            if (victim.getCopper() > 0) {
			                steal = 1;
			                coin = "copper";
			            } else if (victim.getSilver() > 0) {
			                steal = 1;
			                coin = "silver";
			            } else if (victim.getGold() > 0) {
			                steal = 1;
			                coin = "gold";
			            } else if (victim.getPlatinum() > 0) {
			                steal = 1;
			                coin = "platinum";
			            }

			            if (coin == null) break; // nothing to steal

			            // Transfer coins
			            switch (coin) {
			                case "copper":
			                    victim.setCopper(victim.getCopper() - steal);
			                    mob.setCopper(mob.getCopper() + steal);
			                    break;
			                case "silver":
			                    victim.setSilver(victim.getSilver() - steal);
			                    mob.setSilver(mob.getSilver() + steal);
			                    break;
			                case "gold":
			                    victim.setGold(victim.getGold() - steal);
			                    mob.setGold(mob.getGold() + steal);
			                    break;
			                case "platinum":
			                    victim.setPlatinum(victim.getPlatinum() - steal);
			                    mob.setPlatinum(mob.getPlatinum() + steal);
			                    break;
			            }

			            // Notify the mob
			            mob.sendMessage("You steal " + steal + " " + coin + " coin from " + victim.getMobName() + ".");

			            // Chance the victim notices
			            if (new Random().nextInt(10) == 0) {
			                victim.sendMessage("You feel someone brush against your coin pouch!");
			                r.broadcastToExcept(victim, mob, mob.getMobName() + " has been caught trying to pickpocket " + victim.getMobName() + "!");

			                // Engage combat
			                victim.setTarget(mob);
			                victim.setInCombat(true);

			                mob.setTarget(victim);
			                mob.setInCombat(true);
			            }

			            break; // only pick one victim per tick
			        }
			    }
			}




			// --- USE_SPELLS ---
			if (mob.hasBehavior(MobBehaviorFlag.USE_SPELLS)) {

			    if (CombatSpellHandler.isCastingBlocked(mob, mob.getCurrentRoom())) continue;
			    if (!mob.getInCombat()) continue;

			    Mob target = mob.getCurrentTarget();
			    if (target == null || target.isDead()) continue;

			    Profession prof = mob.getProfession();
			    if (prof == null) continue;

			    Collection<Spell> spells = SpellRegister.getInstance().getSpellsForProfession(prof);
			    if (spells == null || spells.isEmpty()) continue;

			    // --- Internal cooldown check ---


			    // --- Random throttle (~25% chance per tick) ---
			   // if (new Random().nextInt(4) != 0) continue;

	

			    List<Spell> spellList = new ArrayList<>(spells);
			    Collections.shuffle(spellList);

			    for (Spell spell : spellList) {
			        if (!spell.isNPCCastable()) continue;
			        if (spell.getLevelRequired() > mob.getLevel()) continue;
			        if (spell.getManaCost() > mob.getCurrentMP()) continue;

			        boolean success = false;

			        if (spell.isSelfTarget()) {
			            success = spell.cast(mob, mob, mob.getLevel());
			        } else if (!spell.isDirectional() && !spell.isAoE()) {
			            if (target != null && !target.isDead()) {
			                success = spell.cast(mob, target, mob.getLevel());
			            }
			        }

			        if (success) {
			            mob.setCurrentMP(mob.getCurrentMP() - spell.getManaCost());
			            mob.getCurrentRoom().broadcast(mob.getMobName() + " casts " + spell.getName() + "!", mob);
			
			            break; // stop after one successful cast
			        }
			    }

			}
			// --- end USE_SPELLS ---





			// --- SCAVENGER ----
			// Picks up loose objects and attempts to wear usable gear
			if (mob.hasBehavior(MobBehaviorFlag.SCAVENGER)) {

			    // Copy list to avoid ConcurrentModificationException
			    List<ObjectItem> roomItems = new ArrayList<>(room.getObjects());

			    for (ObjectItem obj : roomItems) {

			        // Skip if object is not pickable
			        if (obj.hasEffect(ItemEffect.NOTAKE)) continue;

			        // Optional: skip coins or junk types if desired
			         if (obj.getType() == ObjectType.COIN) continue;



			        mob.addItem(obj);
			        room.removeObject(obj);

			        room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);

			        // ---- Attempt to Wear ----
			        if (obj.getEquipSlot() != null && !obj.getEquipSlot().isEmpty()) {

			            // Try each slot the item could fit
			            for (EquipSlot slot : obj.getEquipSlot()) {

			                ObjectItem currentlyWorn = mob.getEquipment().get(slot);

			                // If slot empty, auto-equip
			                if (currentlyWorn == null) {
			                    mob.equip(slot, obj);
			                    room.broadcast(mob.getMobName() + " wears " + obj.getName() + ".", mob);
			                    break;
			                }

			                // If filled, compare usefulness (simple compare by value or a stat)
			                if (obj.getValue() > currentlyWorn.getValue()) {
			                    mob.unequip(slot);
			                    mob.equip(slot, obj);
			                    room.broadcast(
			                        mob.getMobName() + " switches to " + obj.getName() + ".", 
			                        mob
			                    );
			                    break;
			                }
			            }
			        }
			    }
			}


			// --- other behaviors from MobBehaviorFlag go here ---

		}
	} // end tickMobBehavior()

	private static Direction getBestChaseDirection(Mob hunter, Mob target) {
	    Room start = hunter.getCurrentRoom();
	    Room goal = target.getCurrentRoom();
	    if (start == null || goal == null) return null;

	    int goalId = goal.getId();

	    Direction bestDir = null;
	    int bestDist = Integer.MAX_VALUE;

	    for (Map.Entry<Direction, Room> entry : start.getExits().entrySet()) {
	        Room r = entry.getValue();
	        if (r == null) continue;
	        if (r.getZone() != start.getZone()) continue;

	        int dist = Math.abs(r.getId() - goalId);
	        if (dist < bestDist) {
	            bestDist = dist;
	            bestDir = entry.getKey();
	        }
	    }

	    return bestDir;
	}



	public static void tickMobMovement() {
		for (World world : WorldManager.getAllWorlds()) {
			tickMobMovement(world);
		}
	}

	
	public static void tickMobMovement(World world) {
	    Map<Mob, Room> moves = new HashMap<>();
	    Random random = new Random();

	    // --- Determine possible moves for each mob ---
	    for (Room room : world.getRooms()) {
	        List<Mob> mobsCopy = new ArrayList<>(room.getMobs());

	        for (Mob mob : mobsCopy) {
	            if (mob == null) continue;

	            // 🚫 Do not wander if stationary or in combat
	            if (mob.hasBehavior(MobBehaviorFlag.STATIONARY) || mob.getInCombat()) continue;

	            Room currentRoom = mob.getCurrentRoom();
	            if (currentRoom == null) continue;

	            Zone currentZone = currentRoom.getZone();
	            if (currentZone == null) continue;

	            Map<Direction, Room> exits = currentRoom.getExits();
	            if (exits == null || exits.isEmpty()) continue;

	            List<Direction> validDirs = new ArrayList<>();

	            // Collect valid directions
	            for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                Direction dir = entry.getKey();
	                Room dest = entry.getValue();

	                if (dest == null) continue;
	                if (dest.getZone() != currentZone) continue; // Restrict to current zone
	                if (dest.hasFlag(RoomFlag.NOMOB)) continue;
	                if (MovementHandler.isMovementBlocked(mob, currentRoom, dir)) continue; // Check block

	                Door door = currentRoom.getDoor(dir);
	                if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;
	                if (dest == mob.getLastRoom()) continue; // Avoid last room

	                validDirs.add(dir);
	            }

	            // Loosen restriction if no valid directions
	            if (validDirs.isEmpty()) {
	                for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	                    Direction dir = entry.getKey();
	                    Room dest = entry.getValue();

	                    if (dest == null) continue;
	                    if (dest.getZone() != currentZone) continue;
	                    if (dest.hasFlag(RoomFlag.NOMOB)) continue;
	                    if (MovementHandler.isMovementBlocked(mob, currentRoom, dir)) continue;

	                    Door door = currentRoom.getDoor(dir);
	                    if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

	                    validDirs.add(dir);
	                }
	            }

	            // Choose a random valid direction
	            if (!validDirs.isEmpty()) {
	                Direction chosen = validDirs.get(random.nextInt(validDirs.size()));
	                Room dest = currentRoom.getExit(chosen);
	                if (dest != null && !dest.hasFlag(RoomFlag.NOMOB)) {
	                    moves.put(mob, dest);
	                }
	            }
	        }
	    }

	    // --- Apply moves ---
	    for (Map.Entry<Mob, Room> entry : moves.entrySet()) {
	        Mob mob = entry.getKey();
	        Room dest = entry.getValue();
	        Room currentRoom = mob.getCurrentRoom();

	        boolean hasBoat = mob.getInventory().stream().anyMatch(o -> o.getType() == ObjectType.BOAT);
	        boolean isVisible = mob.isVisible();
	        boolean isSneaky = mob.hasAffect(MobAffectFlag.SNEAK) || mob.hasAffect(MobAffectFlag.INVISIBLE);

	        // Water check
	        if (dest.hasFlag(RoomFlag.ON_WATER) && (!mob.hasEffect(EffectType.WATER_WALK) && !hasBoat)) {
	            continue;
	        }

	        // Tunnel restriction
	        if (dest.hasFlag(RoomFlag.TUNNEL) && dest.getPlayers().size() >= dest.getTunnelNum()) {
	            continue;
	        }

	        // Determine movement direction for broadcast
	        Direction chosenDir = null;
	        Direction reverseDir = null;
	        if (currentRoom != null) {
	            for (Map.Entry<Direction, Room> e : currentRoom.getExits().entrySet()) {
	                if (e.getValue() == dest) {
	                    chosenDir = e.getKey();
	                    reverseDir = chosenDir.getOpposite();
	                    break;
	                }
	            }
	        }

	        // Broadcast departure
	        if (currentRoom != null) {
	            currentRoom.removeMob(mob);
	            if (!isSneaky && isVisible && chosenDir != null && reverseDir != null) {
	                currentRoom.broadcastToRoom(mob.getMobName() + " leaves " + chosenDir + ".");
	                dest.broadcastToRoom(mob.getMobName() + " enters from the " + reverseDir + ".");
	            }
	        }

	        // Move mob
	        mob.setCurrentRoom(dest);
	        dest.addMob(mob);
	        mob.setLastRoom(currentRoom);


	        // Handle fall
	        MovementHandler.handleFall(mob, dest);
	    }
	}



	

}
