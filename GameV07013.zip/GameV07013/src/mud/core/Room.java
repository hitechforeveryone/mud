package mud.core;

import java.io.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import mud.core.WorldManager.PendingExit;
import mud.spell.effects.*;

import java.util.stream.Collectors;


public class Room  {


	private int id;
	private Zone zone;

	private String name = "New Room";
	private String description = "An empty, dull room.";
	private List<Mob> mobs = new ArrayList<>();
	private List<ObjectItem> objects = new ArrayList<>();


	private int roomFlags = 0;   // bitflags to store your new flags, replaces isDark
	private final Set<RoomFlag> flags = EnumSet.noneOf(RoomFlag.class);

	private int tunnelNum = 0;   // for TUNNEL flag max mobs/players allowed

	private Map<Direction, Room> exits = new HashMap<>();



	public Room() {
		// Initialize with defaults
		this.id = 0;
		this.name = "Unnamed Room";
		this.description = "This room is empty.";
		this.zone = null; // Set later
		// Add any other default init as needed
		this.zoneExits = new HashMap<>();
		this.effects = new ArrayList<>();
	}

	public Room(int id) {
		this.id = id;
		// Initialize other fields if necessary
	}

	public Room(String description) {
		this.description = description;
	}


	public void addMob(Mob mob) {
	    if (mob == null) return;
	    if (!mobs.contains(mob)) {
	        mobs.add(mob);
	    }
	}



	public synchronized void removeMob(Mob mob) {
		mobs.remove(mob);
	}

	public List<Mob> getMobs() {
		// System.out.println("Room contains mobs: " + mobs.stream().map(Mob::getId).toList());
		return mobs;
	}

	public Map<Direction, Room> getExits() {
		return exits;
	}
	// Add or set exit in a direction
	public void setExits(Map<Direction, Room> exits) {
		this.exits = exits;
	}
	public void setExit(Direction dir, Room room) {
		exits.put(dir, room);
	}
	public Room getExit(Direction dir) {
		return exits.get(dir);
	}
	public void removeExit(Direction dir) {
		if (exits != null) {
			exits.remove(dir);
		}
	} // end removeExit

	
	private transient Map<Direction, Door> doors = new HashMap<>();
	public void setDoor(Direction dir, Door door) {
		doors.put(dir, door);
	}
	public Door getDoor(Direction dir) {
		return doors.get(dir);
	}
	@SuppressWarnings("unlikely-arg-type")
	public Door getDoor(String direction) {
		return doors.get(direction.toLowerCase());
	}
	public void setDoors(Map<Direction, Door> doors) {
		this.doors = doors;
	}
	public List<Door> getMatchingDoors(String keyword) {
		List<Door> matches = new ArrayList<>();
		for (Direction dir : Direction.values()) {
			Door door = getDoor(dir);
			if (door != null && door.hasKeyword(keyword)) {
				matches.add(door);
			}
		}
		return matches;
	}
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		if (doors == null) {
			doors = new HashMap<>();
		}
	}
	public Map<Direction, Door> getDoors() {
		if (doors == null) {
			doors = new HashMap<>();
		}
		return doors;
	}
	



	public Mob findMobByName(String name) {
		for (Mob mob : mobs) {
			if (mob.getMobName().equalsIgnoreCase(name)) {
				return mob;
			}
		}
		return null;
	}
	public ObjectItem findObjectByName(String name) {
		for (ObjectItem obj : objects) {
			if (obj.getName().equalsIgnoreCase(name)) {
				return obj;
			}
		}
		return null;
	}
	public void addObject(ObjectItem obj) {
		objects.add(obj);
	}

	public void removeObject(ObjectItem obj) {
		objects.remove(obj);
	}

	public List<ObjectItem> getObjects() {
		return objects;
	}

	public List<ObjectItem> findObjectsByKeyword(String keyword) {
		List<ObjectItem> matches = new ArrayList<>();
		String lowerKeyword = keyword.toLowerCase();

		for (ObjectItem obj : this.objects) {  // or this.objects depending on your field name
			if (obj.getName() != null && obj.getName().toLowerCase().contains(lowerKeyword)) {
				matches.add(obj);
			}
		}

		return matches;
	}

	public List<Mob> findMobsByKeyword(String keyword) {
		List<Mob> matches = new ArrayList<>();
		for (Mob mob : mobs) {
			if (mob.hasKeyword(keyword)) {
				matches.add(mob);
			}
		}
		return matches;
	}

	// In Room.java
	public Mob findMobByKeyword(String keyword) {
	    for (Mob mob : mobs) {  // assuming 'mobs' is the list of mobs in the room
	        if (mob.matchesKeyword(keyword)) {
	            return mob;
	        }
	    }
	    return null;
	}



	public Room(String shortDescription, String fullDescription) {
		this.description = fullDescription;
	}
	public Room(int id, String name) {
		this.id = id;
		this.name = name;
	}





	public int getId() {
		return id;
	}

	public String getName() {
		return name != null ? name : "Unnamed Room";
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}






	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setShortDescription(String shortDescription) {
	}

	public void setMobs(List<Mob> mobs) {
		this.mobs = mobs;
	}

	public void setObjects(List<ObjectItem> objects) {
		this.objects = objects;
	}
	public String getShortDescription() {
		return name + ": " + description.split("\\.")[0] + ".";  // First sentence
	}
	private Map<Direction, ZoneExit> zoneExits = new HashMap<>();

	public void setZoneExit(Direction dir, ZoneExit ze) {
		if (zoneExits == null) {
			zoneExits = new HashMap<>();
		}
		zoneExits.put(dir, ze);
		System.out.println("[DEBUG] ZoneExit set for direction " + dir + ": " + ze.getWorldId());
	}


	public ZoneExit getZoneExit(Direction dir) {
		return zoneExits.get(dir);
	}

	public Map<Direction, ZoneExit> getZoneExits() {
		return Collections.unmodifiableMap(zoneExits);
	}

	public void setZoneExits(Map<Direction, ZoneExit> zoneExits) {
		this.zoneExits = zoneExits;
	}



	private List<PendingExit> pendingExits = new ArrayList<>();

	public void addPendingExit(Direction dir, int targetRoomId) {
	    pendingExits.add(new PendingExit(this, dir, targetRoomId));
	}

	public List<PendingExit> getPendingExits() {
	    return pendingExits;
	}

	




    public boolean hasExit(Direction dir) {
        return exits.containsKey(dir);
    }

    public boolean hasZoneExit(Direction dir) {
        return zoneExits.containsKey(dir);
    }
	
	
	
	public void broadcastExcept(String message, Mob... excluded) {
		Set<Mob> exclusions = new HashSet<>(Arrays.asList(excluded));
		for (Mob mob : getMobs()) {
			if (!exclusions.contains(mob)) {
				mob.sendMessage(message);
			}
		}
	}
	
	public void broadcastToExcept(Mob excluded1, Mob excluded2, String message) {
		for (Mob mob : mobs) {
			if (mob != excluded1 && mob != excluded2) {
				mob.sendMessage(message);
			}
		}

	} // end broadcastToExcept	

	public void broadcastToRoom(String message) {
	    // NPCs
	    for (Mob mob : mobs) {
	        if (mob != null) {
	            mob.sendMessage(message);
	        }
	    }

	    // Players
	    for (Player player : getPlayers()) {
	        if (player != null) {
	            player.sendMessage(message);
	        }
	    }
	}
 // end broadcastToRoom


	public void broadcastToExcept2(Mob excluded1, Mob excluded2, String message) {
		for (Mob mob : mobs) {
			if (mob != excluded1 && mob != excluded2) {
				mob.sendMessage(message);
			}
		}
	}

	public void broadcast(String message, Mob sender) { 
	    for (Mob mob : mobs) {
	        if (mob != sender) {
	            mob.sendMessage(message); // all mobs can receive messages
	        }
	    }
	}
	public void broadcastToRoomPlayers(String message) {
	    for (Player p : getPlayers()) {
	        p.sendMessage(message);
	    }
	}



	public Zone getZone() {
		return zone;
	}

	public void setZone(Zone zone) {
		this.zone = zone;
	}

	public Mob getMobByName(String... nameParts) {
		String target = String.join(" ", nameParts).toLowerCase();

		for (Mob mob : getMobs()) {
			for (String keyword : mob.getKeywords()) {
				if (target.equalsIgnoreCase(keyword)) {
					return mob;
				}
			}

			if (mob.getShortDescription().toLowerCase().contains(target) ||
					mob.getMobName().toLowerCase().contains(target)) {
				return mob;
			}
		}
		return null;
	}
	public Map<Direction, String> getAllExits() {
		Map<Direction, String> all = new HashMap<>();

		// normal exits (in-zone)
		for (Map.Entry<Direction, Room> e : exits.entrySet()) {
			Room r = e.getValue();
			all.put(e.getKey(), "Room " + r.getId()); // or r.getRoomId() depending on your Room class
		}

		// zone exits (cross-zone)
		for (Map.Entry<Direction, ZoneExit> e : zoneExits.entrySet()) {
			ZoneExit ze = e.getValue();
			all.put(e.getKey(), "World " + ze.getTargetWorldId() +
					" Zone " + ze.getTargetZoneId() +
					" Room " + ze.getTargetRoomId());
		}

		return all;
	}




	public List<Mob> getMatchingMobs(String keyword, Mob exclude) {
		return mobs.stream()
				.filter(mob -> !mob.equals(exclude) && mob.hasKeyword(keyword))
				.toList();
	}

	public List<ObjectItem> getMatchingObjects(String keyword) {
		return objects.stream()
				.filter(obj -> obj.hasKeyword(keyword))
				.toList();
	}

	public void clearFlag(RoomFlag flag) {
		roomFlags &= ~flag.getBit();
	}

	public void toggleFlag(RoomFlag flag) {
		roomFlags ^= flag.getBit();
	}
	public int getTunnelNum() {
		return tunnelNum;
	}

	public void setTunnelNum(int tunnelNum) {
		this.tunnelNum = tunnelNum;
	}
	public boolean isOutside() {
		return hasFlag(RoomFlag.OUTSIDE);
	}

	public void setOutside(boolean value) {
		if (value) setFlag(RoomFlag.OUTSIDE);
		else clearFlag(RoomFlag.OUTSIDE);
	}

	public void clearMobs() {
		mobs.clear();
	}

	public void clearObjects() {
		objects.clear(); // Assumes your Room class has a List<ObjectItem> named 'objects'
	}

	// Similarly for other important flags like FALL, NOMOB, etc.

	public String getFlagsString() {
		StringBuilder sb = new StringBuilder();
		for (RoomFlag flag : RoomFlag.values()) {
			if (hasFlag(flag)) {
				if (sb.length() > 0) sb.append(", ");
				sb.append(flag.name());
			}
		}
		return sb.length() > 0 ? sb.toString() : "None";
	}

	public boolean setFlagByName(String name) {
		try {
			RoomFlag flag = RoomFlag.valueOf(name.toUpperCase());
			setFlag(flag);
			return true;
		} catch (IllegalArgumentException e) {
			return false;
		}
	}

	public int getRoomFlags() {
		return roomFlags;
	}

	public void setRoomFlags(int roomFlags) {
		this.roomFlags = roomFlags;
	}




	public void addFlag(RoomFlag flag) {
		flags.add(flag);
	}

	public void removeFlag(RoomFlag flag) {
		flags.remove(flag);
	}

	public boolean hasFlag(RoomFlag flag) {
		return flags.contains(flag);
	}

	public List<Player> getPlayers() {
	    return mobs.stream()
	               .filter(m -> m instanceof Player)
	               .map(m -> (Player)m)
	               .filter(p -> p.getCurrentRoom() == this) // optional safety
	               .collect(Collectors.toList());
	}


	public boolean hasPlayers() {
		for (Mob mob : mobs) {
			if (mob instanceof Player) return true;
		}
		return false;
	}

	public boolean hasMobs() {
		for (Mob mob : mobs) {
			if (mob instanceof Mob) return true;
		}
		return false;
	}

	public Set<RoomFlag> getFlags() {
		return Collections.unmodifiableSet(flags);
	}

	public void setFlag(RoomFlag flag) {
		flags.add(flag);
	}

	public void clearFlags() {
		flags.clear();
	}


	private List<Effect> effects = new ArrayList<>();



	public String returnStatBlock() {
		StringBuilder sb = new StringBuilder();

		sb.append("🏠 Room ID: ").append(getId()).append("\n");
		sb.append("Name: ").append(getName()).append("\n");
		sb.append("Short Description: ").append(getShortDescription()).append("\n");
		sb.append("Long Description: ").append(getDescription()).append("\n");

		sb.append("Room Flags: ");
		if (getFlags() != null && !getFlags().isEmpty()) {
			sb.append(getFlags().stream()
					.map(Enum::name) // or .toString() if not enum
					.collect(Collectors.joining(", ")));

		} else {
			sb.append("None");
		}
		sb.append("\n");

		sb.append("Tunnel Limit: ").append(getTunnelNum()).append("\n");

		// this works
		sb.append("Exits:\n");
		for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
			Direction dir = entry.getKey();
			Room dest = entry.getValue();
			sb.append("  ").append(dir.name()).append(" -> Room ")
			.append(dest.getId()).append(": ").append(dest.getName());

			// Check if there's a door for this direction
			Door door = doors.get(dir);
			if (door != null) {
				sb.append(" [Door: ")
				.append(door.getDoorName()); // or description if you prefer
				if (door.isLockable()) sb.append(", lockable").append(" Door Key: ").append(door.getDoorKeyId());
				if (door.isLocked()) sb.append(", locked");
				if (door.isClosed()) sb.append(", closed");
				if (door.isHidden()) sb.append(", hidden");
				sb.append(" Keywords: " + door.getKeywords());
				sb.append("]");
			}

			sb.append("\n");
		}
		Map<Direction, ZoneExit> zoneExits = getZoneExits();
		if (zoneExits != null && !zoneExits.isEmpty()) {
			for (Map.Entry<Direction, ZoneExit> entry : zoneExits.entrySet()) {
				ZoneExit ze = entry.getValue();
				sb.append("  ").append(entry.getKey().name())
				.append(" => ZoneExit to ")
				.append("World ").append(ze.getTargetWorldId())
				.append(" Zone ").append(ze.getTargetZoneId())
				.append(" Room ").append(ze.getTargetRoomId()).append("\n");
			}
		} else {
			sb.append("ZoneExits: None or not loaded\n");
		}

		System.out.println("[DEBUG] ZoneExits map: " + getZoneExits());

		sb.append("Room Effects:\n");


		return sb.toString();
	}

	public boolean hasEffectOnExit(Direction dir, Class<? extends Effect> clazz) {
		if (effects == null) return false;
		for (Effect e : effects) {
			if (clazz.isInstance(e) && e.getDirection() == dir) {
				return true;
			}
		}
		return false;
	}

	public boolean hasEffect(Class<? extends Effect> clazz) {
		if (effects == null) return false;
		for (Effect e : effects) {
			if (clazz.isInstance(e)) {
				return true;
			}
		}
		return false;		
	}

	// TODO
	// add/remove barrier effects
	public void removeExitEffect(Direction blockedDir, IcewallEffect icewallEffect) {
		effects.removeIf(e -> e == icewallEffect || (e instanceof IcewallEffect ice && ice.getDirection() == blockedDir));
	}	
	public void removeExitEffect(Direction blockedDir, FortifyEffect fortifyEffect) {
		effects.removeIf(e -> e == fortifyEffect || (e instanceof FortifyEffect fort && fort.getDirection() == blockedDir));
	}	
	public void removeExitEffect(Direction blockedDir, RampartEffect rampartEffect) {
		effects.removeIf(e -> e == rampartEffect || (e instanceof RampartEffect ramp && ramp.getDirection() == blockedDir));
	}
	public void removeExitEffect(Direction blockedDir, FlameBarrierEffect fbEffect) {
		effects.removeIf(e -> e == fbEffect || (e instanceof FlameBarrierEffect fb && fb.getDirection() == blockedDir));
	}
	public void addExitEffect(Direction dir, FortifyEffect fort) {
		if (effects == null) effects = new ArrayList<>();
		fort.setDirection(dir);
		effects.add(fort);	
	}
	public void addExitEffect(Direction dir, RampartEffect ramp) {
		if (effects == null) effects = new ArrayList<>();
		ramp.setDirection(dir);
		effects.add(ramp);	
	}	
	public void addExitEffect(Direction dir, IcewallEffect wall) {
		if (effects == null) effects = new ArrayList<>();
		wall.setDirection(dir);
		effects.add(wall);
	}
	public void addExitEffect(Direction dir, FlameBarrierEffect wall) {
		if (effects == null) effects = new ArrayList<>();
		wall.setDirection(dir);
		effects.add(wall);
	}

	public List<Effect> getEffects() {
		return effects;
	}

	public void addRoomEffect(Effect effect) {
		if (effects == null)
			effects = new ArrayList<>();
		effects.add(effect);
		effect.onApply(this);
	}

	public void removeRoomEffect(Effect effect) {
		if (effects == null) return;
		effects.remove(effect);
	}
	public Mob getShopkeeper() {
		for (Mob mob : mobs) {
			if (mob.isShopKeeper()==true) {
				return mob;
			}
		}
		return null;
	}
	public Mob getBanker() {
		for (Mob mob : mobs) {
			if (mob.isBanker()==true) {
				return mob;
			}
		}
		return null;
	}

	public ObjectItem getObject(int objectId) {
		for (ObjectItem obj : objects) {
			if (obj.getObjID() == objectId) {
				return obj;
			}
		}
		return null; // Not found
	}

	public Mob findRandomHostile(Mob attacker) {
		List<Mob> candidates = new ArrayList<>();

		// Players
		for (Player p : getPlayers()) {
			if (p != attacker && !p.isDead()) {
				candidates.add(p);
			}
		}

		// NPCs
		for (Mob m : getMobs()) {
			if (m != attacker && !m.isDead()) {
				candidates.add(m);
			}
		}

		if (candidates.isEmpty()) return null;

		return candidates.get(
				new Random().nextInt(candidates.size())
				);
	}
	// end findRandomHostile



	public String getFullDescription() {
	    StringBuilder sb = new StringBuilder();

	    String coreDesc = description; // start with base description

	    
	    // Apply weather masking if outside
	    if (isOutside() && getZone() != null && getZone().getCurrentWeather() != null) {
	        String weatherType = getZone().getCurrentWeather().toString();

	        switch (weatherType) {
	            case "FOG", "MIST" -> {
	                // Mask distant features
	                coreDesc = maskDescription(coreDesc, 0.5); // show 50% of text
	            }
	            case "BLIGHT" -> {
	                // Replace description with "blighted" flavor
	                coreDesc = maskDescription(coreDesc, 0.5); // show 50% of text
	            }
	            case "SNOW" -> {
	                // Partial masking, maybe hide details beyond snowdrifts
	                coreDesc = maskDescription(coreDesc, 0.7); // show 70%
	            }
	            case "STORM" -> {
	                // Storm may obscure long distance views
	                coreDesc = maskDescription(coreDesc, 0.6);
	            }
	            case "RAIN" -> {
	                // Storm may obscure long distance views
	                coreDesc = maskDescription(coreDesc, 0.8); // show 80%
	            }
	        }
	    }

	    sb.append(coreDesc);


	    // Weather feedback (only for outside)
	    if (isOutside() && getZone() != null && getZone().getCurrentWeather() != null) {
	        String weatherType = getZone().getCurrentWeather().toString();
	        switch (weatherType) {
	            case "RAIN" -> sb.append("\nRain falls from the sky, soaking everything.");
	            case "STORM" -> sb.append("\nA fierce storm rages, lightning flashing across the sky.");
	            case "SNOW" -> sb.append("\nSnowflakes drift gently down, covering the ground in white.");
	            case "FOG" -> sb.append("\nA thick fog blankets the area, obscuring your vision.");
	            case "BLIGHT" -> sb.append("\nA foul, acrid wind blows, carrying the stench of decay and poisoned earth.");
	            case "HEATWAVE" -> sb.append("\nThe air shimmers with intense heat, making movement sluggish.");
	            case "WINDY" -> sb.append("\nStrong winds whip through the area, rattling loose objects.");
	            case "MIST" -> sb.append("\nA light mist hangs in the air, dampening the surroundings.");
	            default -> sb.append("\nThe weather is calm and uneventful.");
	        }
	    }

	    // Lighting feedback
	    switch (getLightLevel()) {
	        case 0 -> {
	            if ((isOutside() && isDark()) || hasFlag(RoomFlag.DARK))
	                sb.append("\nIt is pitch dark here.");
	        }
	        case 1 -> {
	            if (isOutside())
	                sb.append("\nDim moonlight casts faint shadows.");
	        }
	        case 2 -> {
	            if (isOutside())
	                sb.append("\nDaylight fills the area.");
	        }
	        case 3 -> sb.append("\nThe area glows with an unnatural light.");
	    }
	    
	    return sb.toString();
	} // end getFullDescription
	

	// Utility to mask part of a description based on percentage (randomized)
	private String maskDescription(String desc, double visibleFraction) {
	    if (visibleFraction >= 1.0 || desc == null || desc.isBlank()) {
	        return desc;
	    }

	    String[] words = desc.split("\\s+");
	    int totalWords = words.length;

	    int visibleWords = Math.max(6, (int) (totalWords * visibleFraction));
	    visibleWords = Math.min(visibleWords, totalWords);

	    boolean[] keep = new boolean[totalWords];
	    Random rand = ThreadLocalRandom.current();

	    int kept = 0;
	    while (kept < visibleWords) {
	        int i = rand.nextInt(totalWords);
	        if (!keep[i]) {
	            keep[i] = true;
	            kept++;
	        }
	    }

	    StringBuilder sb = new StringBuilder();
	    boolean obscured = false;

	    for (int i = 0; i < totalWords; i++) {
	        if (keep[i]) {
	            sb.append(words[i]).append(" ");
	            obscured = false;
	        } else if (!obscured) {
	            sb.append("... ");
	            obscured = true;
	        }
	    }

	    return sb.toString().trim();
	}



	
	public int getBaseLightLevel() {
		return lightLevel;
	}


	private int lightLevel = 0; // authoritative
	@SuppressWarnings("unused")
	private int baseLightLevel = 0;     // daylight, moonlight, etc.
	private int overrideLightLevel = -1; // temporary spell override (-1 = none)
	private boolean isNight;
	
	public void setNightTime(boolean isNight) {
	    this.isNight = isNight;
	}

	public boolean isNightTime() {
	    return isNight;
	}

	
	public void setDark(boolean value) {
		if (value) setFlag(RoomFlag.DARK);
		else clearFlag(RoomFlag.DARK);
	}

	public boolean isLit() {
		return getLightLevel() > 0;
	}

	public boolean isDark() {
		return getLightLevel() == 0;
	}

	public int getLightLevel() {
		return overrideLightLevel >= 0 ? overrideLightLevel : lightLevel;
	}

	public void setLightLevel(int level) {
		this.lightLevel = Math.max(0, Math.min(level, 3));
	}

	public void setLightOverride(int level) {
		this.overrideLightLevel = Math.max(0, Math.min(level, 3));
	}

	public void clearLightOverride() {
		this.overrideLightLevel = -1;
	}

	// For day/night, moons, eclipses, etc.
	public void setBaseLightLevel(int level) {
		this.baseLightLevel = Math.min(3, Math.max(0, level));
	}

	// For temporary magical effects like Dancing Lights or Haze
	public void setOverrideLightLevel(int level) {
		this.overrideLightLevel = Math.min(3, Math.max(0, level));
	}

	// Clear any temporary magical lighting
	public void clearOverrideLightLevel() {
		this.overrideLightLevel = -1;
	}

	public void recalculateLighting() {
		int newBaseLevel = 0; // default dark

		// Check for permanent light sources in the room
		boolean hasLightSource = getObjects().stream()
				.anyMatch(obj -> obj.getType() == ObjectType.LIGHTSOURCE);
		if (hasLightSource) {
			newBaseLevel = 3; // magical light from object
		}

		// Check world/day status
		World world = getZone() != null ? getZone().getParentWorld() : null;
		boolean isDay = world != null && world.isDay();
		if (isDay) {
			newBaseLevel = Math.max(newBaseLevel, 2); // daylight
		}

		// Moonlight if night and outside
		boolean isOutside = hasFlag(RoomFlag.OUTSIDE);
		if (!isDay && isOutside && world != null) {
			boolean hasFullMoon = world.getMoons().stream()
					.anyMatch(m -> m.getPhase() == MoonPhase.FULL_MOON);
			boolean hasEclipse = world.getMoons().stream()
					.anyMatch(Moon::isEclipseDay);

			if (hasFullMoon && !hasEclipse) newBaseLevel = Math.max(newBaseLevel, 1);
			if (hasEclipse) newBaseLevel = Math.max(newBaseLevel, 0); // partial eclipses dim naturally
		}

		// Set the ambient/base light level
		setBaseLightLevel(newBaseLevel);

	}

	private int mapX;
	private int mapY;

	public int getMapX() { return mapX; }
	public int getMapY() { return mapY; }

	public void setMapX(int x) { this.mapX = x; }
	public void setMapY(int y) { this.mapY = y; }
	// end



} // end Room