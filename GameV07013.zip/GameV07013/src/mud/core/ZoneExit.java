package mud.core;

import mud.config.Config;
import mud.scripting.*;

public class ZoneExit{


    private String targetWorldId;
    private int targetZoneId;
    private int targetRoomId;
    private Direction direction;
    
    private long activeFromTick = -1;
    private long activeToTick   = -1;
    private String message = null;          // optional emote or SAY message
    private ZoneAction actionType = null;   // SAY or EMOTE
    
    private boolean lastActiveState = true; // default to true

    private String messageOnAppear;   // shown when exit becomes active
    private String messageOnDisappear; // shown when exit becomes inactive
    
    public boolean isActive(long currentTick) {

        // No window defined → always active
        if (activeFromTick < 0 && activeToTick < 0)
            return true;

        int tickOfDay = (int)(currentTick % Config.ticksPerDay);

        if (activeFromTick >= 0 && tickOfDay < activeFromTick)
            return false;

        if (activeToTick >= 0 && tickOfDay > activeToTick)
            return false;

        return true;
    }


    public ZoneExit(String targetWorldId, int targetZoneId, int targetRoomId) {
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
        
    }
    
    public ZoneExit(String targetWorldId, int targetZoneId, int targetRoomId, Direction direction) {
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
        this.direction = direction;
    }
    
    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }
    public String getTargetWorldId() {
        return targetWorldId;
    }

    public int getTargetZoneId() {
        return targetZoneId;
    }

    public int getTargetRoomId() {
        return targetRoomId;
    }

    public void setTargetWorldId(String id) {
        this.targetWorldId = id;
    }

    public void setTargetZoneId(int id) {
        this.targetZoneId = id;
    }

    public void setTargetRoomId(int id) {
        this.targetRoomId = id;
    }
    public int getZoneId() {
        return targetZoneId;
    }
    public String getWorldId() {
        return targetWorldId;
    }

    public int getRoomId() {
        return targetRoomId;
    }

	public long getActiveFromTick() {
		return activeFromTick;
	}

	public void setActiveFromTick(long activeFromTick) {
		this.activeFromTick = activeFromTick;
	}

	public long getActiveToTick() {
		return activeToTick;
	}

	public void setActiveToTick(long activeToTick) {
		this.activeToTick = activeToTick;
	}
	

	
    // getters/setters for message & actionType
    public void setMessage(String msg, ZoneAction type) {
        this.message = msg;
        this.actionType = type;
    }
    public String getMessage() { return message; }
    public ZoneAction getActionType() { return actionType; }
    
    public boolean getLastActiveState() { return lastActiveState; }
    
    public void setLastActiveState(boolean state) { this.lastActiveState = state; }

    public String getMessageOnAppear() { return messageOnAppear; }
    public void setMessageOnAppear(String msg) { this.messageOnAppear = msg; }

    public String getMessageOnDisappear() { return messageOnDisappear; }
    public void setMessageOnDisappear(String msg) { this.messageOnDisappear = msg; }

}
