package mud.editor;

import mud.core.*;
import mud.system.PlayerLoader;

import java.util.*;

public class PlayerEditor implements Editor {
    private final Player target;
    private final Player player;
    private boolean finished = false;
    private PlayerEditorState state = PlayerEditorState.MAIN_MENU;
    
    public PlayerEditor(Player target, Player player) {
        this.target = target;
        this.player = player;
        System.out.println("DEBUG: PlayerEditor created for player " + target.getName());
    }

    @Override
    public void startEditing() {
        displayMainMenu();
        player.sendMessage("Now editing player: " + target.getName());
    }

    private void displayMainMenu() {
        player.sendMessage("""
    --- Player Editor ---
     1) Show Player Info
     2) Edit Name
     3) Edit Title
     4) Edit Level
     5) Edit Experience
     6) Edit Stats
     7) Edit Password
     8) Edit Privilege Level
     9) Set World/Zone/Room
    10) Edit Race
    11) Edit Subrace
    12) Set Rank
    13) Set Profession
    14) Edit Short Description
    15) Edit Long Description
    16) Edit Extended Description
    17) Edit Keywords
    18) Save Player
    19) Exit Editor
    Choose option:""");
    }


    @SuppressWarnings("incomplete-switch")
	@Override
    public void handleInput(String input) {
        switch (state) {
            case MAIN_MENU -> handleMainMenu(input);
            case SET_NAME -> { target.setName(input); player.sendMessage("Name set."); state = PlayerEditorState.MAIN_MENU; displayMainMenu(); }
            case SET_TITLE -> { target.setPlayerTitle(input); player.sendMessage("Title set."); state = PlayerEditorState.MAIN_MENU; displayMainMenu(); }
            case SET_SHORT_DESC -> { target.setShortDescription(input); player.sendMessage("Short description set."); state = PlayerEditorState.MAIN_MENU; displayMainMenu(); }
            case SET_LONG_DESC -> { target.setLongDescription(input); player.sendMessage("Extended description set."); state = PlayerEditorState.MAIN_MENU; displayMainMenu(); }
            case SET_EXT_DESC -> {
                if (input.trim().equals("~")) {
                    target.setExtendedDescription(multilineBuffer.toString().trim());
                    player.sendMessage("Extended description set.");
                    multilineBuffer.setLength(0); // clear
                    state = PlayerEditorState.MAIN_MENU;
                    displayMainMenu();
                } else {
                    multilineBuffer.append(input).append("\n");
                }
            }
            case SET_KEYWORDS -> handleSetKeywords(input);
            case SET_LEVEL -> handleSetLevel(input);
            case SET_PROFESSION -> handleSetProfession(input);
            case SET_RACE -> handleSetRace(input);
           
            case SET_SUBRACE -> handleSetSubrace(input);
            case SET_STATS -> handleSetStats(input);
            case SET_RANK -> handleSetRank(input);
        }
    }

    private void handleMainMenu(String input) {
        switch (input) {
            case "1" -> { showPlayerInfo(); displayMainMenu(); }
            case "2" -> { state = PlayerEditorState.SET_NAME; player.sendMessage("Enter new name:"); }
            case "3" -> { state = PlayerEditorState.SET_TITLE; player.sendMessage("Enter new title:"); }
            case "4" -> { state = PlayerEditorState.SET_LEVEL; player.sendMessage("Enter new level:"); }
            case "5" -> { state = PlayerEditorState.SET_EXP; player.sendMessage("Enter new experience:"); }
            case "6" -> { state = PlayerEditorState.SET_STATS; player.sendMessage("Enter stats as STR STA AGI INT: (W X Y Z)"); }
            case "7" -> { state = PlayerEditorState.SET_PASSWORD; player.sendMessage("Enter new password:"); }
            case "8" -> { state = PlayerEditorState.SET_PRIVILEGE; player.sendMessage("Enter new privilege level:"); }
            case "9" -> { state = PlayerEditorState.SET_LOCATION; player.sendMessage("Enter worldId zoneId roomId:"); }
            case "10" -> { state = PlayerEditorState.SET_RACE; player.sendMessage("Enter new race: (none, aquatic, beast, critter, dragonkin, elemental, flying, humanoid, giant, magic, mechanicalm, plant, undead)"); }
            case "11" -> { state = PlayerEditorState.SET_SUBRACE; player.sendMessage("Enter new subrace: (enter your own)"); }
            case "12" -> { state = PlayerEditorState.SET_RANK; player.sendMessage("Enter new rank (common, elite, chieftain, high_lord, great_lord, grand_lord, mythid, archaic_species, god_rank)"); }
            case "13" -> { state = PlayerEditorState.SET_PROFESSION; player.sendMessage("Enter new profession (none, warrior, rogue, monk, priest, paladin, hunter, druid, shaman, bard, mage, warlock, necromancer, mechanic"); }
            case "14" -> { state = PlayerEditorState.SET_SHORT_DESC; player.sendMessage("Enter new short description:"); }
            case "15" -> { state = PlayerEditorState.SET_LONG_DESC; player.sendMessage("Enter new long description:"); }
            case "16" -> {
                state = PlayerEditorState.SET_EXT_DESC;
                player.sendMessage("Enter extended description. Type `~` on a new line when done:");
                multilineBuffer = new StringBuilder();
            }
            case "17" -> { state = PlayerEditorState.SET_KEYWORDS; player.sendMessage("Enter keywords separated by space:"); }
            case "18" -> { save(); displayMainMenu(); }
            case "19" -> { player.sendMessage("Exiting Player Editor."); player.setEditor(null); }

            default -> displayMainMenu();
        }
    }
    private StringBuilder multilineBuffer = new StringBuilder();

    
    private void showPlayerInfo() {
        player.sendMessage("\n--- Player Info ---");
        player.sendMessage("Name: " + target.getName());
        player.sendMessage("Title: " + target.getPlayerTitle());
        player.sendMessage("Short Desc: " + target.getShortDescription());
        player.sendMessage("Long Desc: " + target.getLongDescription());
        player.sendMessage("Extended Desc: " + target.getExtendedDescription());
        
        player.sendMessage("Keywords: " + target.getKeywords());
        player.sendMessage("Level: " + target.getLevel());
        player.sendMessage("HP: " + target.getCurrentHP() + "/" + target.getMaxHP());
        player.sendMessage("MP: " + target.getCurrentMP() + "/" + target.getMaxMP());
        player.sendMessage("Stats: STR=" + target.getStrength() + ", STA=" + target.getStamina()
                + ", AGI=" + target.getAgility() + ", INT=" + target.getIntellect());
        player.sendMessage("Race: " + target.getRace() + " Subrace: " + target.getSubrace());
        player.sendMessage("Rank: " + target.getMobType());
    }

    private void handleSetKeywords(String input) {
        Set<String> keywords = new HashSet<>(Arrays.asList(input.trim().split("\\s+")));
        target.setKeywords(keywords);
        player.sendMessage("Keywords set to: " + String.join(", ", keywords));
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetLevel(String input) {
        try {
            int level = Integer.parseInt(input);
            if (level < 1 || level > 100) {
                player.sendMessage("Level must be between 1 and 100.");
            } else {
                target.setLevel(level);
                target.recalculateStats();
                player.sendMessage("Level set to " + level);
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid number.");
        }
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetProfession(String input) {
        try {
            Profession prof = Profession.valueOf(input.toUpperCase());
            target.setProfession(prof);
            player.sendMessage("Profession set to " + prof.name());
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid profession.");
        }
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetRace(String input) {
        target.setRace(input.trim());
        target.recalculateStats();
        player.sendMessage("Race set to: " + target.getRace());
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }
    
    private void handleSetRank(String input) {
        try {
            MobRank rank = MobRank.valueOf(input.trim().toUpperCase());
            target.setRank(rank);
            target.setMobType(rank.name()); 
            target.recalculateStats();
            player.sendMessage("Rank set to: " + rank);
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid rank.");
        }
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetSubrace(String input) {
    	// TODO update this to only allow subraces from enum
        target.setSubrace(input.trim());
        player.sendMessage("Subrace set to: " + target.getSubrace());
        target.recalculateStats();
        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void handleSetStats(String input) {
        String[] parts = input.split(" ");
        if (parts.length != 5) {
            player.sendMessage("Please enter 4 integers: STR STA AGI INT CHA");
            return;
        }

        try {
            int str = Integer.parseInt(parts[0]);
            int sta = Integer.parseInt(parts[1]);
            int agi = Integer.parseInt(parts[2]);
            int intel = Integer.parseInt(parts[3]);
            int cha = Integer.parseInt(parts[4]);

            target.setStrength(str);
            target.setStamina(sta);
            target.setAgility(agi);
            target.setIntellect(intel);
            target.setCharisma(cha);
            
            player.sendMessage("Stats updated.");
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid stat input. Use four integers.");
        }

        state = PlayerEditorState.MAIN_MENU;
        displayMainMenu();
    }

    @Override public void stopEditing() { finished = true; }
    @Override public void showMenu() { displayMainMenu(); }
 // Inside your PlayerEditor class

    @Override
    public boolean save() {
        boolean success = PlayerLoader.save(this.target);
        if (success) {
            this.player.sendMessage("Player saved successfully.");
        } else {
            this.player.sendMessage("Failed to save player.");
        }
        return success;
    }

    @Override public String getEditorName() { return "PlayerEditor for player " + target.getName(); }
    @Override public void tick() {}
    @Override public boolean isFinished() { return finished; }

    public enum PlayerEditorState {
        MAIN_MENU,
        SET_NAME,
        SET_TITLE,
        SET_SHORT_DESC,
        SET_LONG_DESC,
        SET_KEYWORDS,
        SET_LEVEL,
        SET_PROFESSION,
        SET_RACE,
        SET_SUBRACE,
        SET_RANK,
        SET_STATS, SET_PASSWORD, SET_PRIVILEGE, SET_LOCATION, SET_EXP, SET_EXT_DESC
    }
}
