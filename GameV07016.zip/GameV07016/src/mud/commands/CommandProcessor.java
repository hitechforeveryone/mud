package mud.commands;

import java.util.*;

import mud.core.*;
import mud.Shop.*;
import mud.editor.*;
import mud.server.BackupHandler;
import mud.system.*;

public class CommandProcessor {

	static WorldManager worldManager;

	@SuppressWarnings("static-access")
	public CommandProcessor(WorldManager worldManager) {
		this.worldManager = worldManager;
	}

	public static String processCommand(String input, Player player) throws Exception {
		// Quick check for common shorthand commands before tokenization
		if (input.startsWith("'")) { // ' = say
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Say what?";
			return CommunicationHandler.handleSay(player, message);
		}
		if (input.startsWith("\"")) { // " = shout or yell
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Shout what?";
			CommunicationHandler.handleShout(player, message);
			return null;
		}
		if (input.startsWith("%") || input.startsWith("%%")) { // % or %% = grape
			String message = input.replaceFirst("^%+", "").trim();
			if (message.isEmpty()) return "Usage: grapevine <message>";
			CommunicationHandler.handleGrapevine(player, message);
			return null;
		}
		if (input.startsWith(":")) { // : = emote
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Emote what?";
			CommunicationHandler.handleEmote(player, message);
			return null;
		}

		// if player is in multiline editor
		if (player.isAwaitingMultiline()) {
			if (input.trim().equalsIgnoreCase("END")) {
				player.setAwaitingMultiline(false);

				if (player.getMultilineEditor() instanceof HelpEditorFieldEditor subEditor) {
					subEditor.applyMultilineInput(player, player.getMultilineBuffer().toString().trim());
				}
				player.cancelMultilineInput();
			} else {
				player.appendMultilineInput(input);
			}
			return null; // important: do not process normal commands while in multiline
		}

		if (input == null || input.trim().isEmpty()) {
			return "You must enter a command.";
		}

		String[] tokens = input.trim().split("\\s+");
		String cmd = tokens[0].toLowerCase();

		// implicit list of admin commands for admin players
		Set<String> adminCommands = Set.of("pkick", "psummon", "goto", "setlevel", "imm", "gimm", "load", "unload", "purge", "list", "create", "edit", "csave", "ichat", "gchat", "where", "setmoblevel","backup","listbackups","restorebackup","viewlog");

		if (adminCommands.contains(cmd) && !player.isAdmin()) {
			return "You do not have permission to use that command.";
		}

		// Directional movement shortcut
		if (MovementHandler.isDirection(cmd)) {
			return MovementHandler.handleMovement(player, cmd);
		}

		switch (cmd) {
		// Admin Commands // TODO
		case "about": { return AdminCommandHandler.handleAbout(player);  } // Reserved for future restart command
		case "/restartgame":{ AdminCommandHandler.handleRestart(player); return null; } // restart server command
		case "/shutdown": { AdminCommandHandler.handleShutdown(player); return null; } //server shutdown
		case "pkick":    return AdminCommandHandler.handleKick(player, tokens); // kick player from server
		case "psummon":  return AdminCommandHandler.handleSummon(player, tokens); // global summons of player
		case "goto":     return AdminCommandHandler.handleGoto(player, tokens); // goto player room from coords wId zId rId
		case "setlevel": return AdminCommandHandler.handleSetLevel(player, tokens); // set a player lvl
		case "setmoblevel": { // set a mobs level and auto-recalc stats
			return AdminCommandHandler.handleSetMobLevel(player, tokens);
		}
		case "stat": StatCommandHandler.handleStat(player,tokens); return null; // currently open to all
		case "load": return AdminCommandHandler.handleLoad(player,Arrays.copyOfRange(tokens, 1, tokens.length));
		case "unload":{	return AdminCommandHandler.handleUnload(player,tokens); // unload zone 
		}
		case "purge": return AdminCommandHandler.handlePurge(player, tokens); // remove/purge mob/mobs from room
		case "list": {
			AdminCommandHandler.handleList(player, tokens); return null;
		}
		case "create": {
			String result = AdminCommandHandler.handleCreate(player, tokens);
			return (result == null) ? "Failed to create object. Check your input." : result;
		}
		case "csave": {
			return AdminCommandHandler.handleCSave(player, tokens);		}
		case "edit": {
			if (player.getEditor() != null) {
				System.out.println("[DEBUG] Passing input to editor: " + player.getEditor().getEditorName());
				player.getEditor().handleInput(input);	return null;
			}
			AdminCommandHandler.handleEdit(player, tokens);	return null;
		}
		case "imm":
		case "ichat":
		case "gchat":
		case "gimm": {
			CommunicationHandler.handlePrivilegedChat(player, tokens);
			return null;
		}
		case "where":{
			return AdminCommandHandler.handleWhere(player, tokens);
		}

		// Backups
		// system automatically backs-up player at rent/camp but these are manual commands
		case "backup": {
			// backup [playerName]
			if (tokens.length < 2 || tokens[1] == null || tokens[1].isBlank()) {
				BackupHandler.handleBackup(player, null); // backup ALL players
			} else {
				BackupHandler.handleBackup(player, tokens[1]); // backup one player
			}
			return null;
		}
		case "listbackups": {
			if (tokens.length < 2 || tokens[1] == null || tokens[1].isBlank()) {
				player.sendMessage("Usage: listbackups <playerName>");
			} else {
				List<java.io.File> backups = PlayerLoader.listBackups(tokens[1]);
				if (backups.isEmpty()) {
					player.sendMessage("📦 No backups found for player: " + tokens[1]);
				} else {
					player.sendMessage("📦 Backups for " + tokens[1] + ":");
					for (java.io.File f : backups) {
						player.sendMessage(" - " + f.getName());
					}
				}
			}
			return null;
		}
		case "restorebackup": {
			if (tokens.length < 2 || tokens[1] == null || tokens[1].isBlank()) {
				player.sendMessage("Usage: restorebackup <playerName>");
			}

			if (tokens.length >= 3 && tokens[2] != null && !tokens[2].isBlank()) {
				// Restore a specific backup file
				BackupHandler.restoreBackup(player, tokens[1], tokens[2]);
			} else {
				// Restore latest backup for the player
				BackupHandler.restoreLatestBackup(player, tokens[1]);
			}
			return null;
		}
		case "/report":
		case "report":
			return MudLogger.handleReportCommand(player, tokens);
		case "viewlog":
			return MudLogger.handleViewLogCommand(player, tokens);


			// TESTING  SECTION //

		case "assemble":
			handleAssemble(player, tokens[0]);
			return null;

			// END TESTING SECTION //




			// Game Exits	
		case "quit": { GameExitHandler.handleQuit(player); return null;
		} // signal to ClientHandler
		case "rent": { GameExitHandler.handleRent(player);	return null;
		}
		case "camp": { GameExitHandler.handleCamp(player);	return null;
		}




		// world info
		case "moons":
		case "time": { WorldInfoHandler.handleTime(player);	return null;
		}
		case "date": { WorldInfoHandler.handleDate(player);	return null;
		}
		case "weather": { WorldInfoHandler.handleWeather(player); return null;
		}
		case "calendar": { WorldInfoHandler.handleCalendar(player);	return null;
		}



		// Maps
		case "maps":
		case "map": {
			MapCommand.handleMap(player, tokens);
			return null;
		}



		// Movement
		case "go": {
			if (tokens.length < 2) return "Move where?";
			return MovementHandler.handleMovement(player, tokens[1].toLowerCase());
		}
		case "follow":{
			return InteractionHandler.handleFollowCommand(player, tokens);
		}




			// communication
		case "emote": {
			if (tokens.length < 2) return "Emote what?";
			CommunicationHandler.handleEmote(player, input.substring(input.indexOf(' ') + 1));
			return null;
		}
		case "frown": { CommunicationHandler.handleEmote(player, "frowns intently."); return null;
		} 
		case "grin": { CommunicationHandler.handleEmote(player, "grins evily."); return null;
		} 
		case "sigh": { CommunicationHandler.handleEmote(player, "sighs gently."); return null;
		} 
		case "dance": { CommunicationHandler.handleEmote(player, "dances wildly about the room."); return null;
		} 
		case "ponder": { CommunicationHandler.handleEmote(player, "ponders deeply."); return null;
		}

		case "grape":
		case "grapevine": {
			if (tokens.length < 2) {
				return "Usage: grapevine <message>";
			}
			CommunicationHandler.handleGrapevine(player, input.substring(input.indexOf(' '))); return null;	}
		case "say": {
			if (tokens.length < 2) return "Say what?";
			return CommunicationHandler.handleSay(player, input.substring(input.indexOf(' ')));
		}
		case "yell":
		case "shout": {
			if (tokens.length < 2) {
				return "Shout what?";
			}
			CommunicationHandler.handleShout(player, input.substring(input.indexOf(' ')));
			return null;
		}
		case "tell": {
			CommunicationHandler.handleTell(player, tokens);
			return null;
		}
		case "reply": {
			CommunicationHandler.handleReply(player, tokens);
			return null;
		}
		case "whisper": {
			CommunicationHandler.handleWhisper(player, tokens);
			return null;
		}




		// --- Help ---
		case "help":
			return HelpHandler.handleHelp(player,tokens); // TODO: help system, add more helps
		case "hedit":
			if (tokens.length < 2) {
				player.sendMessage("Usage: hedit <keyword>");
				return null;
			}
			String keyword = tokens[1].toLowerCase();
			HelpEntry existing = HelpManager.getHelpEntry(keyword);
			if (existing != null) {
				player.setEditor(new HelpEditor(existing,player));
			} else {
				player.setEditor(new HelpEditor(keyword,player));
				player.sendMessage("Creating new help entry for: " + keyword);
			}
			return null;
		case "hindex":
			return HelpHandler.handleHindex(player,tokens); 




			// --- Party Stuff ---	
		case "party": {
			return PartyHandler.handleParty(player, tokens);
		}
		case "pchat":
		case "partychat": { 
			CommunicationHandler.handlePartyChat(player, tokens);
			return null;
		}




		// --- Combat Stuff ---
		case "consider": {
			Mob target = player.getCurrentRoom().findMobByKeyword(tokens[1]);
			if (target == null) return "There is no such creature here.";
			return LookHandler.handleConsider(player, target);
		}
		case "target": { 
			if (tokens.length < 2) return "target whom?";
			return CombatSpellHandler.handleTarget(player, tokens[1].toLowerCase());
		}
		case "kill":
		case "attack": {
			if (tokens.length < 2) return "Attack whom?";
			return CombatSpellHandler.handleAttack(player, tokens[1].toLowerCase());
		}
		case "assist": {
			Mob target = player.getCurrentRoom().findMobByName(tokens[1]);
			if (target == null) return "There is no target here.";
			return CombatSpellHandler.handleAssist(target);
		}

		//spells 
		case "cast": {
			if (tokens.length < 2) {
				return "Cast what?";
			}

			String spellName = tokens[1];

			String targetName = (tokens.length > 2)
					? String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length))
							: null;

			return CombatSpellHandler.handleCast(player, spellName, targetName);
		}

		case "spell":
		case "spells": {
			return CombatSpellHandler.handleSpell(player);
		}
		// portal/wormhole interaction
		case "enter": {
			CombatSpellHandler.handleEnter(player,tokens.toString());
			return null;
		}
		case "seal": {
			CombatSpellHandler.handleSeal(player,tokens.toString());
			return null;
		}


		//abilities // no "cast" command needed
		case "backstab": {
			// TODO
			return null;
		}
		case "detect.trap": {
			// TODO
			return null;
		}
		case "disable.trap": {
			// TODO
			return null;
		}
		case "disabling.blow": {
			// TODO
			return null;
		}
		case "disarm": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "double.attack": {
			// passive
			return null;
		}
		case "dual.wield": {
			// passive
			return null;
		}
		case "evicerate": {
			// TODO
			return null;
		}
		case "flee": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null; 	
		}
		case "gouge": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "headbutt": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "kick": {
			if (tokens.length < 2) return "Kick who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "pick.lock": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "pickpocket": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "punch": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "rend": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "rescue": {
			if (tokens.length < 2) return "Rescue who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "retreat": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null; 	
		}
		case "second.hit": {
			// passive
			return null;
		}
		case "track": {
			if (tokens.length < 2) return "Track who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}

		// familiar management
		case "order": {
			if (tokens.length < 3) return "Usage: order <target> <command>";    
			String targetName = tokens[1];
			String commandToRun = String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length));	    
			return InteractionHandler.handleOrder(player, targetName, commandToRun);
		}



		// Info
		case "look": { LookHandler.handleLook(player, tokens); return null;
		}
		case "who": { LookHandler.handleWho(player); 
		return null;
		}
		case "score" : return LookHandler.handleScore(player);
		case "inventory":
		case "inv": return LookHandler.handleInventory(player);
		case "examine":	return LookHandler.handleExamine(player,tokens); // TODO: update show extended object/mob info
		case "title": {
			if (tokens.length < 2) return "Set your title to what?";  // set player's title
			return AdminCommandHandler.handleTitle(player, tokens[1].trim());
		}



		// obj management
		case "take":
		case "get": {
			if (tokens.length < 2) return "Get what?";
			InteractionHandler.handleGet(player, tokens);
			return null;
		}
		case "drop": {
		    if (tokens.length < 2) return "Drop what?";

		    String itemName = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length)).toLowerCase();

		    // Detect if it's a coin drop:
		    // starts with "coin", "coins", or begins with a number+letter (1p, 5g, etc)
		    if (itemName.startsWith("coin") || itemName.startsWith("coins") ||
		        itemName.matches("^(\\d+[pgsc]\\s*)+.*$")) {
		        return InteractionHandler.handleDropCoins(player, itemName);
		    } else {
		        return InteractionHandler.handleDrop(player, itemName);
		    }
		}



		case "wear":
		case "equip": {
			if (tokens.length < 2) return "Equip what?";
			return InteractionHandler.handleEquip(player, tokens);
		}
		case "grab": {
			InteractionHandler.handleGrab(player, tokens);
		}
		case "light": {
			if (tokens.length < 2) return "Light what?";
			return InteractionHandler.handleLight(player, tokens);
		}
		case "unequip": {
			if (tokens.length < 2) return "Unequip what?";
			return InteractionHandler.handleUnequip(player, tokens[1].toLowerCase());
		}
		case "use": { // wand/staff
			if (tokens.length < 2) return "Use what?";
			return InteractionHandler.handleUseItem(player, tokens);
		}
		case "eat":{ // drink
			if (tokens.length < 2) return "Eat what?";
			return InteractionHandler.handleEat(player, tokens[1].toLowerCase());			
		}
		case "drink":{ // drink
			if (tokens.length < 2) return "Drink what?";
			return InteractionHandler.handleDrink(player, tokens[1].toLowerCase());			
		}
		case "quaff": { // potion
			if (tokens.length < 2) return "Quaff what?";
			return InteractionHandler.handleQuaff(player, tokens[1].toLowerCase());			
		}
		case "recite": { //scroll
			if (tokens.length < 2) return "Recite what?";
			return InteractionHandler.handleRecite(player, tokens);			
		}
		case "open": {
			InteractionHandler.handleOpen(player, tokens);
			return null;
		}
		case "close": {
			InteractionHandler.handleClose(player, tokens);
			return null;
		}
		case "lock": {
			InteractionHandler.handleLock(player, tokens);
			return null;
		}
		case "unlock": {
			InteractionHandler.handleUnlock(player, tokens);
			return null;
		}
		case "equipment": {
			InteractionHandler.handleEquipment(player);
			return null;
		}




		// --- Bank & Shop stuff ---
		case "money":
		case "coins": return  player.getMoneyString();
		case "exchange":  { 
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			BankShopHandler.handleExchange(player);
			return null;
		}
		case "deposit": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Deposit what amount?";
			return BankShopHandler.handleDepositCoins(player, tokens[1]);
		}
		case "withdraw": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Withdraw what amount?";
			return BankShopHandler.handleWithdrawCoins(player, tokens[1]);
		}
		case "vaultdeposit": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Deposit which item?";
			return BankShopHandler.handleDepositItem(player, tokens[1]);
		}
		case "vaultwithdraw": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Withdraw which item?";
			return BankShopHandler.handleWithdrawItem(player, tokens[1]);
		}
		case "vaultlist": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			return BankShopHandler.handleListVault(player);
		}
		case "vaultbuy": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			return BankShopHandler.handlePurchaseVault(player);
		}
		// shop stuff // seems to work
		case "shoplist": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return ShopManager.listShop(player, shopkeeper);
		}
		case "buy": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return BankShopHandler.handleBuy(player,tokens);
		}
		case "sell": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return BankShopHandler.handleSell(player,tokens);
		}





		// --- End of Commands ---

		default:
			return "Unknown command: " + cmd;
		}
	} // end processCommand






	public static void handleAssemble(Player player, String argument) {
		Room room = player.getCurrentRoom();
		if (room == null) return;

		ObjectItem root = null;

		// -------------------------------------------------
		// Step 1: Find root part
		// -------------------------------------------------
		if (argument != null && !argument.isEmpty()) {
			ObjectItem target = room.findObjectByName(argument);

			if (target == null) {
				player.sendMessage("You don't see that here.");
				return;
			}

			if (target.getType() != ObjectType.PART) {
				player.sendMessage("That cannot be assembled.");
				return;
			}

			if (target.getObjID() != target.getAssemblyRoot()) {
				player.sendMessage("That is not the base of an assembly.");
				return;
			}

			root = target;
		} else {
			// no argument: infer root
			for (ObjectItem item : room.getObjects()) {
				if (item.getType() == ObjectType.PART &&
						item.getObjID() == item.getAssemblyRoot()) {

					if (root != null) {
						player.sendMessage("Be more specific about what you want to assemble.");
						return;
					}
					root = item;
				}
			}

			if (root == null) {
				player.sendMessage("There is nothing here you can assemble.");
				return;
			}
		}

		// -------------------------------------------------
		// Step 2: Determine assembly group
		// -------------------------------------------------
		int resultId = root.getAssemblesInto();

		// -------------------------------------------------
		// Step 3: Count required parts globally (Option A)
		// -------------------------------------------------
		List<ObjectItem> found = new ArrayList<>();
		for (ObjectItem item : room.getObjects()) {
			if (item.getType() == ObjectType.PART &&
					item.getAssemblesInto() == root.getAssemblesInto()) {
				found.add(item);
			}
		}

		if (found.size() < 2) {
			player.sendMessage("All required parts are not present.");
			return;
		}


		// -------------------------------------------------
		// Step 4: Collect matching parts in room
		// -------------------------------------------------


		for (ObjectItem item : room.getObjects()) {
			if (item.getType() == ObjectType.PART &&
					item.getAssemblesInto() == resultId) {
				found.add(item);
			}
		}


		// -------------------------------------------------
		// Step 5: Consume parts
		// -------------------------------------------------
		for (ObjectItem part : found) {
			room.removeObject(part);
		}

		// -------------------------------------------------
		// Step 6: Create result
		// -------------------------------------------------
		// Step 5: create the result object
		ObjectItem result = ObjectManager.createObjById(root.getAssemblesInto());
		if (result != null) {
			room.addObject(result);
			player.sendMessage("You assemble the parts into " + result.getName() + ".");
		} else {
			player.sendMessage("Something went wrong creating the assembled object.");
		}
	}




	// match keyword across mob/player/obj
	static boolean matchesKeyword(HasKeywords entity, String keyword) {
		if (keyword == null) return false;
		for (String key : entity.getKeywords()) {
			if (key != null && key.equalsIgnoreCase(keyword)) {
				return true;
			}
		}
		return false;
	}






	// end handleAbout




} // end CommandProcessor
