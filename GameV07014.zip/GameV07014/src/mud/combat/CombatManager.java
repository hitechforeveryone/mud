package mud.combat;

import java.util.*;

import mud.core.*;
import mud.spell.effects.*;

public final class CombatManager {

	private CombatManager() {}

	public static class CombatMessages {
		public String attackerMsg;
		public String targetMsg;
		public String roomMsg;

		public CombatMessages(String attackerMsg, String targetMsg, String roomMsg) {
			this.attackerMsg = attackerMsg;
			this.targetMsg = targetMsg;
			this.roomMsg = roomMsg;
		}
	}

	// --------------------------------------------------
	// Public entry point — ONE attack, nothing more
	// --------------------------------------------------
	public static String performAttack(Mob attacker, Mob target) { 
		if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
			return "Invalid combatants.";
		}

		attacker.setInCombat(true);
		target.setInCombat(true);

		List<String> allMessages = new ArrayList<>();

		ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
		ObjectItem offHand  = attacker.getEquipment().get(EquipSlot.OFFHAND);


		//		if (!handleCombatRoundInterupt(attacker)) { 
		//			System.out.println("Mob combat round not interrupted");
		//		}

		// MAIN ATTACK
		allMessages.add(performSingleAttack(attacker, target, mainHand, false));

		// SECONDHIT
		if ((attacker.hasAffect(MobAffectFlag.SECONDHIT) || attacker.hasEffect("second_hit")) && mainHand == null) {
			double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
			if (Math.random() < chance) {
				allMessages.add(performSingleAttack(attacker, target, null, true));
			}
		}

		// DOUBLEATTACK
		if ((attacker.hasAffect(MobAffectFlag.DOUBLEATTACK) || attacker.hasEffect("double_attack")) && mainHand != null && mainHand.isWeapon()) {
			double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
			if (Math.random() < chance) {
				allMessages.add(performSingleAttack(attacker, target, mainHand, true));
			}
		}

		// OFFHANDHIT
		if ((attacker.hasAffect(MobAffectFlag.OFFHANDHIT) || attacker.hasEffect("offhand_hit")) && offHand == null) {
			double chance = Math.min(0.05 * attacker.getLevel(), 0.5);
			if (Math.random() < chance) {
				allMessages.add(performSingleAttack(attacker, target, null, true));
			}
		}

		// DUALWIELD
		if ((attacker.hasAffect(MobAffectFlag.DUALWIELD) || attacker.hasEffect("dual_wield")) && offHand != null && offHand.isWeapon()) {
			double chance = Math.min(0.03 * attacker.getLevel(), 0.4);
			if (Math.random() < chance) {
				allMessages.add(performSingleAttack(attacker, target, offHand, true));
			}
		}

		// Handle counter-attack
		if (!target.isDead() && target.getTarget() == null) {
			target.setTarget(attacker);
			// Optionally, you could immediately perform a reactive attack:
			// allMessages.add(performSingleAttack(target, attacker, target.getEquipment().get(EquipSlot.MAINHAND), false));
		}



		// Check for death AFTER all attacks
		if (target.isDead() || target.getCurrentHP() <= 0) {
			DeathManager.clearCombat(attacker, target);
		}



		// Return combined messages for logging/testing
		return String.join("\n", allMessages);

	}

	// -----------------------
	// PERFORM SINGLE ATTACK REFACTORED
	// -----------------------
	public static String performSingleAttack(Mob attacker, Mob target, ObjectItem weapon, boolean isOffhand) {

		double vorpalDamage = (weapon != null && weapon.isVorpal()) ? 1.25 : 1.0;
		int intDamage = (weapon != null && weapon.isIntelligent()) ? weapon.getFlatDamage() : 0;

		WeaponDamageType dmgType = (weapon != null && weapon.getDamageType() != null) ? weapon.getDamageType() : WeaponDamageType.HIT;
		String icon = dmgType.getIcon();
		String verb = dmgType.getPrettyName().toLowerCase();
		String handLabel = isOffhand ? " (offhand)" : "";
		if (weapon != null) {
			if (weapon.getObjectType()==ObjectType.WEAPON) {
				weapon.isWeapon();
			}
		}

		int baseDamage = rollWeaponDamage(weapon, attacker);
		int bonusDamage = attacker.getStrength() / 2;
		double scaledDamage = ((baseDamage * vorpalDamage) + intDamage + bonusDamage) * attacker.getRank().getMultiplier();
		int totalDamage = (int) scaledDamage;

		int totalDefenseBonus = target.getEquipment().values().stream()
				.filter(obj -> obj != null && obj.getArmorType() != null)
				.mapToInt(obj -> obj.getArmorType().getDefenseBonus())
				.sum();
		totalDefenseBonus = Math.min(totalDefenseBonus, 99);

		if (handleDefensiveIllusions(attacker, target)) {
			return "Your attack missed!"; // simplified legacy-friendly
		}

		double reduction = (1.0 - (totalDefenseBonus / 100.0));
		int damageTaken = (int) Math.max(1, Math.round(totalDamage * reduction));
		target.takeDamage(damageTaken);

		// if vampiric
		if (weapon != null && weapon.getVampiricPercent() > 0) {
			int vampHeal = (int) (damageTaken * weapon.getVampiricPercent());
			if (vampHeal > 0) attacker.heal(vampHeal);
		}

		// Apply poison if present
		if (weapon != null && weapon.isPoisoned()) {
			int duration = 3;
			int damagePerTick = 5;
			PoisonEffect poison = new PoisonEffect(target, duration, damagePerTick);
			target.addEffect(poison);
			target.addEffect(EffectType.POISON);
		}

		FireShieldEffect.onTargetHit(attacker, target, damageTaken);

		if (target.getCurrentHP() <= 0) {
			DeathManager.handleDeath(attacker, target);
		}

		// Return a single string for legacy code
		String finalVerb = conjugateVerb(verb, attacker);

		return String.format("%s %s%s %s for %d damage! %s",
				attacker.getMobName(), finalVerb, handLabel, target.getMobName(), damageTaken, icon);

	}


	private static String conjugateVerb(String verb, Mob attacker) {
		if (attacker instanceof Player) {
			return verb; // player sees: "You hit X"
		}
		// simple English 3rd-person singular
		if (verb.endsWith("s") || verb.endsWith("x") || verb.endsWith("z") || verb.endsWith("ch") || verb.endsWith("sh")) {
			return verb + "es";
		}
		if (verb.endsWith("y") && verb.length() > 1 && !isVowel(verb.charAt(verb.length()-2))) {
			return verb.substring(0, verb.length()-1) + "ies";
		}
		return verb + "s";
	}

	private static boolean isVowel(char c) {
		return "aeiou".indexOf(Character.toLowerCase(c)) != -1;
	}


	// --------------------------------------------------
	// Helpers (PURE)
	// --------------------------------------------------

	private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
		return weapon != null ? weapon.rollDamage() : 1;
	}

	private static boolean handleDefensiveIllusions(Mob attacker, Mob target) {
		// Before attacking target
		MirrorImageEffect mie = target.getEffect(MirrorImageEffect.class);
		if (mie != null && mie.getImages() > 0) {
			if (mie.onIncomingAttack(attacker, target)) {
				attacker.sendMessage("Your attack strikes a mirror image!");
				//target.sendMessage("An incoming attack shatters one of your mirror images!");
				if (target.getCurrentRoom() != null)
					target.getCurrentRoom().broadcastToExcept(attacker, target,
							attacker.getMobName() + "'s attack strikes a mirror image!");
				return true;
			}
		}

		ShadowCloneEffect sce = target.getEffect(ShadowCloneEffect.class);
		if (sce != null && sce.getImages() > 0) {
			if (sce.onIncomingAttack(attacker, target)) {
				attacker.sendMessage("Your attack is intercepted by a shadow clone!");
				target.sendMessage("A shadow clone absorbs the blow!");
				if (target.getCurrentRoom() != null)
					target.getCurrentRoom().broadcastToExcept(attacker, target,
							attacker.getMobName() + "'s attack strikes a shadow clone!");
				return true;
			}
		}

		BoneShieldEffect bse = target.getEffect(BoneShieldEffect.class);
		if (bse != null && bse.getImages() > 0) {
			if (bse.onIncomingAttack(attacker, target)) {
				attacker.sendMessage("Your attack is absorbed by a bone shield!");
				target.sendMessage("Your bone shield cracks under the blow!");
				if (target.getCurrentRoom() != null)
					target.getCurrentRoom().broadcastToExcept(attacker, target,
							attacker.getMobName() + "'s attack strikes a bone shield!");
				return true;
			}

		}

		// more defensives/illusions go here, Block/Deflect?





		return false;
	}

	public static String getCombatStatus(Mob a, Mob b) {
		StringBuilder sb = new StringBuilder();

		sb.append(a.getMobName())
		.append(": HP ")
		.append(a.getCurrentHP()).append("/").append(a.getMaxHP())
		.append(" MP ").append(a.getCurrentMP()).append("/").append(a.getMaxMP())
		.append(" ")
		.append(CombatFormatter.formatBuffs(a))
		.append(CombatFormatter.formatDebuffs(a))
		.append("\n");

		sb.append(b.getMobName())
		.append(": HP ")
		.append(b.getCurrentHP()).append("/").append(b.getMaxHP())
		.append(" MP ").append(b.getCurrentMP()).append("/").append(b.getMaxMP())
		.append(" ")
		.append(CombatFormatter.formatBuffs(b))
		.append(CombatFormatter.formatDebuffs(b));

		return sb.toString();
	}

	static boolean handleCombatRoundInterupt(Mob attacker) {
		// check if stun/fear/etc and return "" (nothing) instead of continuing with combat
		// TODO
		for (EffectType e: attacker.getActEffects()) {
			if (e==EffectType.STUN) {
				attacker.sendMessage("You can't do that while stunned.");
				return true;
			}
			if (e==EffectType.FEAR) {
				attacker.sendMessage("You can't do that while feared.");
				return true;
			}
			if (e==EffectType.CONFUSE) {
				attacker.sendMessage("You can't do that while confused.");
				return true;
			}
			if (e==EffectType.DISORIENT) {
				attacker.sendMessage("You can't do that while disoriented.");
				return true;
			}

		}

		return false;	

	}


} // end combatmanager
