package mud.config;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class ChangeLogManager {

    public static class ChangeLogEntry {
        private String version;
        private String date; // optional
        private List<String> changes;

        public ChangeLogEntry(String version, String date) {
            this.version = version;
            this.date = date;
            this.changes = new ArrayList<>();
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public List<String> getChanges() {
            return changes;
        }

        public void setChanges(List<String> changes) {
            this.changes = changes;
        }
    }

    private List<ChangeLogEntry> entries = new ArrayList<>();

    public List<ChangeLogEntry> getEntries() {
        return entries;
    }

    // =========================
    // LOAD
    // =========================
    public void load(File file) throws IOException {
        entries.clear();

        if (!file.exists()) return;

        List<String> lines = Files.readAllLines(file.toPath());

        ChangeLogEntry current = null;

        for (String raw : lines) {
            String line = raw.trim();

            if (line.isEmpty()) continue;

            if (line.startsWith("#VERSION:")) {
                if (current != null) {
                    entries.add(current);
                }

                String version = line.replace("#VERSION:", "").trim();
                current = new ChangeLogEntry(version, null);
            }
            else if (line.startsWith("#DATE:")) {
                if (current != null) {
                    String date = line.replace("#DATE:", "").trim();
                    current.setDate(date.isEmpty() ? null : date);
                }
            }
            else if (line.startsWith("-")) {
                if (current != null) {
                    current.getChanges().add(line.substring(1).trim());
                }
            }
        }

        if (current != null) {
            entries.add(current);
        }
    } // end

    // =========================
    // SAVE
    // =========================
    public void save(File file) throws IOException {
        List<String> lines = new ArrayList<>();

        for (ChangeLogEntry entry : entries) {
            lines.add("#VERSION: " + entry.getVersion());

            if (entry.getDate() != null && !entry.getDate().isEmpty()) {
                lines.add("#DATE: " + entry.getDate());
            }

            for (String change : entry.getChanges()) {
                lines.add("- " + change);
            }

            lines.add(""); // spacing between versions
        }

        Files.write(file.toPath(), lines);
    } // end

    // =========================
    // LIST VERSIONS
    // =========================
    public List<String> listVersions() {
        List<String> result = new ArrayList<>();

        for (ChangeLogEntry entry : entries) {
            if (entry.getDate() != null && !entry.getDate().isEmpty()) {
                result.add(entry.getVersion() + " (" + entry.getDate() + ")");
            } else {
                result.add(entry.getVersion());
            }
        }

        return result;
    } // end

    // =========================
    // GET VERSION
    // =========================
    public ChangeLogEntry getVersion(String version) {
        for (ChangeLogEntry entry : entries) {
            if (entry.getVersion().equalsIgnoreCase(version)) {
                return entry;
            }
        }
        return null;
    } // end

    // =========================
    // ADD VERSION
    // =========================
    public void addVersion(String version, String date) {
        ChangeLogEntry entry = new ChangeLogEntry(version, date);
        entries.add(0, entry); // newest at top
    } // end

    // =========================
    // ADD ENTRY TO VERSION
    // =========================
    public void addEntry(String version, String text) {
        ChangeLogEntry entry = getVersion(version);
        if (entry != null) {
            entry.getChanges().add(text);
        }
    } // end

    // =========================
    // EDIT ENTRY BY INDEX
    // =========================
    public void editEntry(String version, int index, String newText) {
        ChangeLogEntry entry = getVersion(version);

        if (entry == null) return;

        if (index >= 0 && index < entry.getChanges().size()) {
            entry.getChanges().set(index, newText);
        }
    } // end
}