package mud.scripting;

import mud.config.Config;
import mud.core.EquipSlot;
import mud.core.Zone;

import java.io.*;

public final class ZoneScriptTextParser {

    private enum Section {
        NONE,
        ROOMS,
        RECALL_NODES
    }

    private enum SubSection {
        NONE,
        MOBS,
        OBJECTS,
        DOORS,
        TRIGGERS
    }

    private enum SubSubSection {
        NONE,
        EQUIPMENT,
        INVENTORY,
        CONTAINS
    }

    private ZoneScriptTextParser() {}

    public static BasicZoneScript read(Zone zone) throws IOException {
        File file = resolveScriptFile(zone);
        if (file == null || !file.exists()) return null;

        BasicZoneScript script = new BasicZoneScript(zone, zone.getZoneId());
        parseFile(file, script);
        return script;
    }

    private static File resolveScriptFile(Zone zone) {
        String worldPrefix = zone.getWorld() != null
                ? zone.getWorld().getWorldId() + "_"
                : "";
        String fileName = worldPrefix + zone.getZoneId() + ".Script.txt";
        File f = new File(Config.SCRIPT_DIR, fileName);
        return f.exists() ? f : null;
    }

    static void parseFile(File file, BasicZoneScript script) throws IOException {

        Section section = Section.NONE;
        SubSection subSection = SubSection.NONE;
        SubSubSection subSubSection = SubSubSection.NONE;

        ZoneScript.Room currentRoom = null;
        ZoneScript.Mob currentMob = null;
        ZoneScript.ZoneObject currentObject = null;
        ZoneScript.Trigger currentTrigger = null;
        ZoneScript.EquipmentEntry currentEquip = null;
 
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("//")) continue;

                /* =======================
                 * TOP LEVEL
                 * ======================= */
                if (line.startsWith("RecallNodes:")) {
                    section = Section.RECALL_NODES;
                    continue;
                }

                if (line.startsWith("Rooms:")) {
                    section = Section.ROOMS;
                    continue;
                }


                /* =======================
                 * RECALL NODES
                 * ======================= */
                if (section == Section.RECALL_NODES) {

                    // Stop recall parsing when Rooms begins
                    if (line.startsWith("Rooms:")) {
                        section = Section.ROOMS;
                        continue;
                    }

                    for (String part : line.split(",")) {
                        String p = part.trim();
                        if (p.isEmpty()) continue;

                        try {
                            script.addRecallNode(Integer.parseInt(p));
                        } catch (NumberFormatException e) {
                            System.err.println("Invalid recall node: " + p);
                        }
                    }
                    continue;
                }


                /* =======================
                 * ROOMS
                 * ======================= */
                if (section != Section.ROOMS) continue;

                if (line.startsWith("- RoomID:")) {
                    int roomId = Integer.parseInt(line.substring(9).trim());
                    currentRoom = script.createRoom(roomId);

                    subSection = SubSection.NONE;
                    subSubSection = SubSubSection.NONE;
                    currentMob = null;
                    currentObject = null;
                    currentTrigger = null;
                    continue;
                }

                if (line.equals("Mobs:"))    { subSection = SubSection.MOBS; continue; }
                if (line.equals("Objects:")) { subSection = SubSection.OBJECTS; continue; }
                if (line.equals("Doors:"))   { subSection = SubSection.DOORS; continue; }
                if (line.equals("Triggers:")){ subSection = SubSection.TRIGGERS; continue; }

                /* =======================
                 * MOBS
                 * ======================= */
                if (subSection == SubSection.MOBS) {

                    // Start Equipment or Inventory sub-section
                    if (line.equals("Equipment:")) {
                        subSubSection = SubSubSection.EQUIPMENT;
                        continue;
                    }
                    if (line.equals("Inventory:")) {
                        subSubSection = SubSubSection.INVENTORY;
                        continue;
                    }

                    // ---- Parse MobID ----
                    if (line.startsWith("MobID:")) {
                        currentMob = new ZoneScript.Mob();
                        currentMob.mobId = Integer.parseInt(line.substring(6).trim());
                        currentRoom.mobs.add(currentMob);
                        subSubSection = SubSubSection.NONE; 
                        continue;
                    }

                    // ---- Parse Percent ----
                    if (line.startsWith("Percent:")) {
                        currentMob.percent = Integer.parseInt(line.substring(8).trim());
                        continue;
                    }

                    // ---- Parse Equipment entries ----
                    if (subSubSection == SubSubSection.EQUIPMENT) {
                        if (line.startsWith("ObjectID:")) {
                            currentEquip = new ZoneScript.EquipmentEntry();
                            currentEquip.objectId = Integer.parseInt(line.substring(9).trim());
                            currentMob.equipment.add(currentEquip);
                            continue;
                        }
                        if (line.startsWith("Slot:") && currentEquip != null) {
                            try {
                                currentEquip.slot = EquipSlot.valueOf(line.substring(5).trim().toUpperCase());
                            } catch (IllegalArgumentException e) {
                                System.err.println("[ZoneScript] Invalid EquipSlot: " + line.substring(5).trim());
                                currentEquip.slot = null;
                            }
                            continue;
                        }
                        if (line.startsWith("Percent:") && currentEquip != null) {
                            currentEquip.percent = Integer.parseInt(line.substring(8).trim());
                            continue;
                        }
                    }

                    // ---- Parse Inventory entries ----
                    if (subSubSection == SubSubSection.INVENTORY) {
                        if (line.startsWith("ObjectID:")) {
                            ZoneScript.ZoneObject obj = new ZoneScript.ZoneObject();
                            obj.objectId = Integer.parseInt(line.substring(9).trim());
                            currentMob.inventory.add(obj);
                            continue;
                        }
                        if (line.startsWith("Percent:") && !currentMob.inventory.isEmpty()) {
                            currentMob.inventory.get(currentMob.inventory.size()-1).percent =
                                Integer.parseInt(line.substring(8).trim());
                            continue;
                        }
                    }
                }



                /* =======================
                 * OBJECTS
                 * ======================= */
                if (subSection == SubSection.OBJECTS && currentRoom != null) {

                    if (line.startsWith("ObjectID:")) {
                        currentObject = new ZoneScript.ZoneObject();
                        currentObject.objectId = Integer.parseInt(line.substring(9).trim());
                        currentRoom.objects.add(currentObject);
                        continue;
                    }

                    if (line.startsWith("Percent:") && currentObject != null) {
                        currentObject.percent = Integer.parseInt(line.substring(8).trim());
                        continue;
                    }

                    if (line.equals("Contains:")) { subSubSection = SubSubSection.CONTAINS; continue; }

                    if (subSubSection == SubSubSection.CONTAINS && line.startsWith("ObjectID:")) {
                        ZoneScript.ZoneObject inner = new ZoneScript.ZoneObject();
                        inner.objectId = Integer.parseInt(line.substring(9).trim());
                        currentObject.contains.add(inner);
                    }
                }

                /* =======================
                 * DOORS
                 * ======================= */
                if (subSection == SubSection.DOORS && currentRoom != null) {

                    if (line.startsWith("Direction:")) {
                        ZoneScript.Door door = new ZoneScript.Door();
                        door.direction = line.substring(10).trim();
                        currentRoom.doors.add(door);
                        continue;
                    }

                    ZoneScript.Door door = currentRoom.doors.get(currentRoom.doors.size() - 1);
                    if (line.startsWith("Open:"))   door.open = Boolean.parseBoolean(line.substring(5).trim());
                    if (line.startsWith("Locked:")) door.locked = Boolean.parseBoolean(line.substring(7).trim());
                    if (line.startsWith("Remote:")) door.remote = Boolean.parseBoolean(line.substring(7).trim());
                }

                /* =======================
                 * TRIGGERS
                 * ======================= */
                if (subSection == SubSection.TRIGGERS && currentRoom != null) {

                    if (line.startsWith("- ")) {
                        currentTrigger = new ZoneScript.Trigger();
                        currentTrigger.type = ZoneScript.TriggerType.valueOf(
                                line.substring(2, line.length() - 1).toUpperCase()
                        );
                        currentRoom.triggers.add(currentTrigger);
                        continue;
                    }

                    if (currentTrigger == null) continue;

                    if (line.startsWith("Chance:"))     currentTrigger.chance = Integer.parseInt(line.substring(7).trim());
                    else if (line.startsWith("Action:")) currentTrigger.actionDetail = line.substring(7).trim();
                    else if (line.startsWith("Spell:"))  currentTrigger.spell = line.substring(6).trim();
                    else if (line.startsWith("TextMatch:")) currentTrigger.textMatch = line.substring(10).trim();
                    else if (line.startsWith("ObjectType:")) currentTrigger.objectType = line.substring(11).trim();
                    else if (line.startsWith("Player:")) currentTrigger.player = Boolean.parseBoolean(line.substring(7).trim());
                }
            }
        }
    }
}
