package mud.scripting;

import mud.core.Zone;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Concrete, data-driven implementation of ZoneScript.
 * This class is intentionally dumb: it stores parsed data and exposes it.
 */
public class BasicZoneScript implements ZoneScript {

    protected final Zone zone;
    private final int zoneId;

    private final Map<Integer, List<MobSpawn>> roomMobs = new HashMap<>();
    private final Map<Integer, List<ObjectSpawn>> roomObjects = new HashMap<>();
    private final Set<Integer> recallNodes = new HashSet<>();
    public final Map<Integer, Map<String, Set<DoorState>>> doorStates = new HashMap<>();
    private final List<Room> rooms = new ArrayList<>();


    public BasicZoneScript(Zone zone, int zoneId) {
        this.zone = zone;
        this.zoneId = zoneId;
    }

    @Override
    public int getZoneId() {
        return zoneId;
    }

    @Override
    public List<Room> getRooms() {
        return rooms;
    }

    @Override
    public List<RecallNode> getRecallNodes() {
        List<RecallNode> list = new ArrayList<>();
        for (int roomId : recallNodes) {
            RecallNode node = new RecallNode();
            node.roomId = roomId;
            list.add(node);
        }
        return list;
    }

    @Override
    public void apply(Zone zone) {
        // runtime executor handles behavior
    	// TODO
    	
    	applyMobs(zone);
    	applyObjects(zone); // this one works
    	applyDoors(zone); // this one works
    }

    /* =========================
     * Parser helpers
     * ========================= */

    public Room createRoom(int roomId) {
        Room room = new Room();
        room.roomId = roomId;
        rooms.add(room);
        return room;
    }

    public void addRecallNode(int roomId) {
        recallNodes.add(roomId);
    }
    

    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("ZoneScript: ").append(zoneId).append("\n");
        sb.append("WorldID:").append(zone.getParentWorld().getWorldId()).append("\n");
        sb.append("ZoneID:").append(zone.getZoneId()).append("\n\n");

        // -------------------
        // Recall Nodes
        // -------------------
        if (!recallNodes.isEmpty()) {
            sb.append("  RecallNodes:\n");
            List<Integer> sorted = new ArrayList<>(recallNodes);
            Collections.sort(sorted);
            sb.append("  ").append(sorted.stream().map(String::valueOf).collect(Collectors.joining(","))).append("\n\n");
        }

        // -------------------
        // Rooms
        // -------------------
        sb.append("Rooms:\n");
        List<Integer> roomIds = new ArrayList<>(getRoomIds());
        Collections.sort(roomIds);

        for (int roomId : roomIds) {
            sb.append("  - RoomID: ").append(roomId).append("\n");

            // ----- Mobs -----
            List<MobSpawn> mobs = roomMobs.getOrDefault(roomId, List.of());
            if (!mobs.isEmpty()) {
                sb.append("    Mobs:\n");
                for (MobSpawn mob : mobs) {
                    sb.append("      MobID: ").append(mob.mobId).append("\n");
                    sb.append("      Percent: ").append((int)(mob.chance * 100)).append("\n");

                    // Equipment & Inventory placeholders (empty lists if not yet tracked)
                    if (mob instanceof MobSpawnWithInventory mswi) {
                    	if (!mswi.equipment.isEmpty()) {
                    	    sb.append("      Equipment:\n");
                    	    for (EquipmentEntry eq : mswi.equipment) {
                    	        sb.append("        ObjectID: ").append(eq.objectId).append("\n");
                    	        sb.append("        Slot: ").append(eq.slot).append("\n");
                    	        sb.append("        Percent: ").append(eq.percent).append("\n");
                    	    }
                    	}

                        if (!mswi.inventory.isEmpty()) {
                            sb.append("      Inventory:\n");
                            for (ZoneObject item : mswi.inventory) {
                            	 sb.append("        ObjectID: ").append(item.objectId).append("\n");
                            	 sb.append("        Percent: ").append(item.percent).append("\n");
                            }
                        }
                    }
                }
            }

            // ----- Objects -----
            List<ObjectSpawn> objects = roomObjects.getOrDefault(roomId, List.of());
            if (!objects.isEmpty()) {
                sb.append("    Objects:\n");
                for (ObjectSpawn obj : objects) {
                    sb.append("      ObjectID: ").append(obj.objectId).append("\n");
                    sb.append("      Percent: ").append((int)(obj.chance * 100)).append("\n");
                    if (!obj.contains.isEmpty()) {
                        sb.append("      Contains:\n");
                        for (ZoneObject inner : obj.contains)
                            sb.append("        ObjectID: ").append(inner.objectId).append("\n");
                    }
                }
            }

            // ----- Doors -----
            Map<String, Set<DoorState>> doorsMap = doorStates.getOrDefault(roomId, Map.of());

            if (!doorsMap.isEmpty()) {
                sb.append("    Doors:\n");
                for (var entry : doorsMap.entrySet()) {
                    sb.append("      Direction: ").append(entry.getKey()).append("\n");
                    sb.append("      State: ").append(entry.getValue()).append("\n");
                }
            }

            sb.append("\n");
        }

        return sb.toString();
    }


    private Set<Integer> getRoomIds() {
        Set<Integer> ids = new HashSet<>();
        ids.addAll(roomMobs.keySet());
        ids.addAll(roomObjects.keySet());
        ids.addAll(doorStates.keySet());
        return ids;
    }

    // Inner classes for spawn tracking
    public static class MobSpawn {
        public int mobId;
        public double chance;
        public List<ZoneObject> equipment = new ArrayList<>();
        public List<ZoneObject> inventory = new ArrayList<>();

        public MobSpawn(int mobId, double chance) {
            this.mobId = mobId;
            this.chance = chance;
        }
    }


    public static class ObjectSpawn {
        public int objectId;
        public double chance;
        public List<ZoneObject> contains = new ArrayList<>(); // nested objects

        public ObjectSpawn(int objectId, double chance) {
            this.objectId = objectId;
            this.chance = chance;
        }
    }

    
    public static class MobSpawnWithInventory extends MobSpawn {
    	public List<EquipmentEntry> equipment;
    	public List<ZoneObject> inventory;

        public MobSpawnWithInventory(int mobId, double chance) { super(mobId, chance); }
    }

    
    
}// end
