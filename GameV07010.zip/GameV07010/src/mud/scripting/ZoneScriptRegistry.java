package mud.scripting;

import mud.core.World;
import mud.core.Zone;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public final class ZoneScriptRegistry {

    private static final Map<String, ZoneScript> SCRIPTS = new HashMap<>();


    private ZoneScriptRegistry() {}

    /* ======================================================
     * CREATE / LOAD
     * ====================================================== */
    public static ZoneScript createForZone(Zone zone) {
        String key = makeKey(zone);

        if (SCRIPTS.containsKey(key)) {
            ZoneScript existing = SCRIPTS.get(key);
            zone.setScript(existing);   // always attach
            return existing;
        }

        ZoneScript script = null;

        try {
            script = ZoneScriptTextParser.read(zone);
            if (script != null) {
                System.out.println("✅ Loaded ZoneScript (.txt) for zone "
                    + zone.getWorld().getWorldId() + ":" + zone.getZoneId());
            }
        } catch (IOException e) {
            System.err.println("❌ Failed to load ZoneScript (.txt) for zone "
                + zone.getZoneId() + ": " + e.getMessage());
        }

        if (script == null) {
            script = new BasicZoneScript(zone, zone.getZoneId());
        }

        zone.setScript(script);
        SCRIPTS.put(key, script);

        return script;
    }


    /* ======================================================
     * ACCESS
     * ====================================================== */

    public static ZoneScript get(Zone zone) {
        return SCRIPTS.get(makeKey(zone));
    }

    public static boolean has(Zone zone) {
        return SCRIPTS.containsKey(makeKey(zone));
    }

    /* ======================================================
     * LIFECYCLE
     * ====================================================== */

    public static void clear() {
        SCRIPTS.clear();
    }

    public static void unload(String key, ZoneScript script) {
        SCRIPTS.remove(key, script);
    }

    public static void registerDefaults(World world) {
        for (Zone zone : world.getZones()) {
            createForZone(zone);
        }
    }
    private static String makeKey(Zone zone) {
        return zone.getWorld().getWorldId() + ":" + zone.getZoneId();
    }

   
} // end
