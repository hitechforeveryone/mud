package mud.scripting;


public enum ZoneAction {

    // Messaging / Emotes
    SAY("Sends a message to the room"),
    EMOTE("Sends a descriptive emote to the room"),
    TELL("Sends a message to a specific player"),
    SHOUT("Broadcasts a message to all nearby rooms"),

    // Mob / NPC Control
    SPAWN("Spawns a mob in the room"),
    DESPAWN("Removes a specific mob from the room"),
    MOVE("Moves a mob in a specified direction"),
    ATTACK("Forces a mob to attack a target"),
    CAST("Casts a spell by a mob or environment"),

    // Object / Inventory Manipulation
    GIVE("Gives an object to a mob"),
    REMOVE("Removes an object from a mob"),
    UNLOCK_EXIT("Unlocks a door in a room"),
    LOCK_EXIT("Locks a door in a room"),
    OPEN_EXIT("Opens a door in a room"),
    CLOSE_EXIT("Closes a door in a room"),
    DESTROY_OBJECT("Removes an object from the room"),

    // Player Interaction / Effects
    HEAL("Heals a player"),
    DAMAGE("Deals damage to a player"),
    STATUS("Applies a status effect to a player"),
    TELEPORT("Teleports a player to a room"),

    // Environmental / Zone Control
    WEATHER("Changes the zone's weather temporarily"),
    LIGHT("Adjusts the lighting in the room"),
    PLAY_SOUND("Plays a sound in the room"), // sound not implemented yet
    TRIGGER("Manually activates another trigger in the room"),

    // Conditional / Logic Actions
    IF_PLAYER_HAS("Conditional: execute if player has object"),
    IF_MOB_ALIVE("Conditional: execute if mob is alive"),
    ELSE("Executes if previous condition fails"),
    WAIT("Delays next action by a number of ticks");

    private final String description;

    ZoneAction(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}