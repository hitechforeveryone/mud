package mud.Shop;

import mud.core.ObjectItem;
import mud.core.ObjectType;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

public class ShopProfile {

    private double buyModifier = 0.5;
    private double sellModifier = 1.5;
    private int maxCopper = -1; // -1 = unlimited


    private Set<ObjectType> buys = EnumSet.allOf(ObjectType.class);
    private Set<ObjectType> sells = EnumSet.allOf(ObjectType.class);

    public double getBuyModifier() {
        return buyModifier;
    }

    public void setBuyModifier(double buyModifier) {
        this.buyModifier = buyModifier;
    }

    public double getSellModifier() {
        return sellModifier;
    }

    public void setSellModifier(double sellModifier) {
        this.sellModifier = sellModifier;
    }

    // --------------------
    // Item Rules
    // --------------------
    public boolean buys(ObjectItem item) {
        return buys.contains(item.getType());
    }

    public boolean sells(ObjectItem item) {
        return sells.contains(item.getType());
    }

    public void setBuys(Set<ObjectType> buys) {
        this.buys = buys;
    }

    public void setSells(Set<ObjectType> sells) {
        this.sells = sells;
    }
    public int getMaxCopper() {
        return maxCopper;
    }

    public void setMaxCopper(int maxCopper) {
        this.maxCopper = maxCopper;
    }
    public String[] getBuysAsStrings() {
        return buys.stream().map(Enum::name).toArray(String[]::new);
    }

    public String[] getSellsAsStrings() {
        return sells.stream().map(Enum::name).toArray(String[]::new);
    }
    public Set<ObjectType> getBuys() {
        return buys == null ? Set.of() : buys;
    }
    // end
    public Set<ObjectType> getSells() {
        return sells == null ? Set.of() : sells;
    }
    // end


    public ShopProfile copy() {
        ShopProfile copy = new ShopProfile();
        copy.setBuyModifier(this.buyModifier);
        copy.setSellModifier(this.sellModifier);
        copy.setMaxCopper(this.maxCopper);
        copy.setBuys(new HashSet<>(this.buys));
        copy.setSells(new HashSet<>(this.sells));
        return copy;
    }

}
// end
