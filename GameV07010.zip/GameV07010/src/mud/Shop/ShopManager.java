package mud.Shop;

import mud.core.Mob;
import mud.core.ObjectItem;

public class ShopManager {

    // --------------------
    // Validation
    // --------------------
    public static boolean canBuy(Mob shopkeeper, ObjectItem item) {
        if (shopkeeper == null || item == null) return false;
        if (!shopkeeper.isShopKeeper()) return false;
        if (shopkeeper.getShopProfile() == null) return false;

        return shopkeeper.getShopProfile().buys(item);
    }

    public static boolean canSell(Mob shopkeeper, ObjectItem item) {
        if (shopkeeper == null || item == null) return false;
        if (!shopkeeper.isShopKeeper()) return false;
        if (shopkeeper.getShopProfile() == null) return false;

        return shopkeeper.getShopProfile().sells(item);
    }

    // --------------------
    // Pricing
    // --------------------
    public static int getBuyPrice(Mob shopkeeper, ObjectItem item) {
        double mod = shopkeeper.getShopProfile().getBuyModifier();
        return Math.max(1, (int)(item.getTotalValueInCopper() * mod));
    }

    public static int getSellPrice(Mob shopkeeper, ObjectItem item) {
        double mod = shopkeeper.getShopProfile().getSellModifier();
        return Math.max(1, (int)(item.getTotalValueInCopper() * mod));
    }

    // --------------------
    // Transactions
    // --------------------
    public static boolean buyFromPlayer(Mob player, Mob shopkeeper, ObjectItem item) {
        if (!canBuy(shopkeeper, item)) return false;
        if (!player.getInventory().contains(item)) return false;

        int price = getBuyPrice(shopkeeper, item);

        // Shopkeeper copper limit
        int max = shopkeeper.getShopProfile().getMaxCopper();
        if (max != -1 && shopkeeper.getTotalCopper() + price > max) {
            return false;
        }

        // Transfer item
        player.getInventory().remove(item);
        shopkeeper.addShopItem(item);

        // Transfer money
        player.addCopper(price);
        shopkeeper.subtractCopper(price);

        return true;
    }

    public static boolean sellToPlayer(Mob player, Mob shopkeeper, ObjectItem item) {
        if (!canSell(shopkeeper, item)) return false;
        if (!shopkeeper.getShopInventory().contains(item)) return false;

        int price = getSellPrice(shopkeeper, item);
        if (player.getTotalCopper() < price) return false;

        // Transfer item
        shopkeeper.getShopInventory().remove(item);
        player.getInventory().add(item);

        // Transfer money
        player.subtractCopper(price);
        shopkeeper.addCopper(price);

        return true;
    }
    
    private static String formatCoins(int copper) {
        int gold = copper / 10000;
        copper %= 10000;
        int silver = copper / 100;
        copper %= 100;

        StringBuilder sb = new StringBuilder();
        if (gold > 0) sb.append(gold).append(" gold");
        if (silver > 0) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(silver).append(" silver");
        }
        if (gold == 0 && silver == 0) {
            sb.append(copper).append(" copper");
        }
        return sb.toString();
    }
    // end

    
    public static String listShop(Mob player, Mob shopkeeper) {

        if (shopkeeper == null || !shopkeeper.isShopKeeper()) {
            return "They are not running a shop.";
        }

        if (shopkeeper.getShopProfile() == null) {
           return "No shop profile set.";
        }
        
        var stock = shopkeeper.getShopInventory();
        if (stock == null || stock.isEmpty()) {
            return "The shop is currently out of stock.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("The shopkeeper offers the following goods:\n\n");

        int index = 1;

        for (ObjectItem item : stock) {
            // TEMPORARY BYPASS: skip shopProfile filter
             if (shopkeeper.getShopProfile() != null && !shopkeeper.getShopProfile().sells(item)) continue;

            int price = getSellPrice(shopkeeper, item);

            sb.append(String.format(
                " [%2d] %-25s %s\n",
                index++,
                item.getShortDescription(),
                formatCoins(price)
            ));
        }

        if (index == 1) {
            return "The shop has nothing suitable for sale.";
        }

        return sb.toString();
    }
    // end

    
    
    
    
}
// end
