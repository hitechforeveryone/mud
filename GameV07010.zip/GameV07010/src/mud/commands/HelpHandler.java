package mud.commands;

import java.util.Arrays;
import java.util.List;

import mud.core.HelpEntry;
import mud.core.HelpManager;
import mud.core.Player;

public class HelpHandler {

	static String handleHelp(Player player, String[] args) {
		if (args.length < 2) {
			return "Usage: help <topic>";
		}

		String query = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		HelpEntry entry = HelpManager.getHelpEntry(query);

		if (entry == null) {
			return "No help found for: " + query;
		}

		return "**" + entry.getTitle() + "**\n" + entry.getBody();
	}

	static String handleHindex(Player player, String[] args) {
		List<HelpEntry> entries = HelpManager.getAllEntries();

		if (entries.isEmpty()) {
			return "No help files available.";
		}

		String prefix = null;
		if (args.length > 1) {
			prefix = args[1].toLowerCase();
		}

		StringBuilder sb = new StringBuilder();
		sb.append("Available Help Topics:\n");

		for (HelpEntry entry : entries) {
			String key = entry.getKeyword();

			// Prefix filter if requested
			if (prefix != null && !key.toLowerCase().startsWith(prefix)) {
				continue;
			}

			sb.append("  - ").append(key);

			if (entry.getTitle() != null && 
					!entry.getTitle().equalsIgnoreCase(key)) {
				sb.append(" (").append(entry.getTitle()).append(")");
			}

			sb.append("\n");
		}

		return sb.toString();
	}
	// end
	
}
