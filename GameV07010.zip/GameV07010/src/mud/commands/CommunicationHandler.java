package mud.commands;

import java.util.*;

import mud.core.*;

public class CommunicationHandler {
	

	public static void handlePrivilegedChat(Player sender, String[] tokens) {
	    if (tokens.length < 2) {
	        sender.sendMessage("Usage: " + tokens[0] + " <message>");
	        return;
	    }

	    String command = tokens[0].toLowerCase();
	    int requiredLevel;
	    String tag;
	    String colorCode;

	    switch (command) {
	        case "imm":
	            requiredLevel = 1;
	            tag = "IMM";
	            colorCode = "\u001B[31;1m"; // red bold
	            break;
	        case "gimm":
	            requiredLevel = 2;
	            tag = "GIMM";
	            colorCode = "\u001B[35;1m"; // magenta bold
	            break;
	        default:
	            sender.sendMessage("Unknown privileged chat command: " + command);
	            return;
	    }

	    if (sender.getPrivilegeLevel() < requiredLevel) {
	        sender.sendMessage("You do not have permission to use " + tag + " chat.");
	        return;
	    }

	    String message = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length));
	    String formatted = colorCode + "[" + tag + "] " + sender.getName() + ": " + message + "\u001B[0m";

	    for (Player p : WorldManager.getAllPlayers()) {
	        // GIMM players (level 2+) see both IMM and GIMM messages
	        if (p.getPrivilegeLevel() >= 2 || (command.equals("imm") && p.getPrivilegeLevel() >= 1)) {
	            p.sendMessage(formatted);
	        }
	    }

	    System.out.println("[" + tag + "] " + sender.getName() + ": " + message);
	} // end handlePrivilegedChat

	public static void handlePartyChat(Player sender, String[] tokens) {
	    if (tokens.length < 2) {
	        sender.sendMessage("Usage: partychat <message>");
	        return;
	    }

	    Party party = sender.getParty();
	    if (party == null) {
	        sender.sendMessage("You're not in a party.");
	        return;
	    }

	    String message = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length));
	    String formatted = "\u001B[36;1m[Party] " + sender.getName() + ": " + message + "\u001B[0m"; // cyan bold

	    for (Player member : party.getMembers()) {
	        if (member != null) {
	            member.sendMessage(formatted);
	        }
	    }

	    System.out.println("[Party] " + sender.getName() + ": " + message);
	} // end handlePartyChat

	
	public static void handleEmote(Player player, String message) {
		// emotes are physica, they ignore silences
		if (message == null || message.trim().isEmpty()) {
			player.sendMessage("Emote what?");
			return;
		}

		String emoteMessage = player.getName() + " " + message.trim();
		Room room = player.getCurrentRoom();

		for (Player p : room.getPlayers()) {
			p.sendMessage(emoteMessage);
		}
	} // end handleEmote

	public static void handleGrapevine(Player sender, String message) {
		if (message == null || message.isBlank()) {
			sender.sendMessage("Usage: % <message>, grapevine <message>, or grape <message>");
			return;
		}
		String formatted = "📣 \u001B[35m[Grapevine] " + sender.getName() + ": " + message + "\u001B[0m";
		for (Player p : WorldManager.getAllPlayers()) {
			p.sendMessage(formatted);
		}
		System.out.println("[Grapevine] " + sender.getName() + ": " + message);
	} // end handleGrapevine

	public static void handleReply(Player player, String[] tokens) {
		if (tokens.length < 2) {
			player.sendMessage("Usage: reply <message>");
			return;
		}

		if (player.hasEffect(EffectType.SILENCE)) {
			player.sendMessage("You try to speak, but no sound escapes your lips...");
			return;
		}

		if (player.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
			player.sendMessage("This place is too quiet to send messages.");
			return;
		}

		Player target = player.getLastTellSender();
		if (target == null) {
			player.sendMessage("You have no one to reply to.");
			return;
		}

		String message = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length));
		player.sendMessage("You tell " + target.getName() + ": " + message);
		target.sendMessage(player.getName() + " tells you: " + message);
		target.setLastTellSender(player);  // Update back-and-forth reply support
	} // end handleReply

	public static String handleSay(Player player, String message) {
		Room room = player.getCurrentRoom();
		if (player.hasEffect(EffectType.SILENCE)) {
			player.sendMessage("You try to speak, but no sound escapes your lips...");
		}
		room.broadcast(player.getName() + " says: " + message, player);
		return "You say: " + message;
	} // end handleSay

	public static void handleShout(Player sender, String message) {
		if (message == null || message.isBlank()) {
			sender.sendMessage("Usage: shout <message>");
			return;
		}

		Room currentRoom = sender.getCurrentRoom();

		if (currentRoom.hasFlag(RoomFlag.QUIET)) {
			sender.sendMessage("You cannot shout in this quiet room.");
			return;
		}
		if (sender.hasEffect(EffectType.SILENCE)) {
			sender.sendMessage("You try to shout, but no sound escapes your lips...");
			return;
		}

		Set<Room> targets = new HashSet<>();
		targets.add(currentRoom);

		// Add adjacent rooms
		for (Room adjacent : currentRoom.getExits().values()) {
			if (adjacent != null && !adjacent.hasFlag(RoomFlag.QUIET)) {
				targets.add(adjacent);
			}
		}

		String formatted = "\u001B[33;1m[Shout] " + sender.getName() + " shouts: " + message + "\u001B[0m";

		for (Room room : targets) {
			for (Player p : room.getPlayers()) {
				if (p != sender) {
					p.sendMessage(formatted);
				}
			}
		}

		sender.sendMessage("\u001B[33;1mYou shout: " + message + "\u001B[0m");
	} // end handleShout

	public static void handleTell(Player sender, String[] tokens) {
		if (tokens.length < 3) {
			sender.sendMessage("Usage: tell <player> <message>");
			return;
		}

		if (sender.hasEffect(EffectType.SILENCE)) {
			sender.sendMessage("You try to speak, but no sound escapes your lips...");
			return;
		}

		if (sender.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
			sender.sendMessage("This place is too quiet to send messages.");
			return;
		}

		String targetName = tokens[1];
		Player recipient = WorldManager.getPlayerByName(targetName);

		if (recipient == null) {
			sender.sendMessage("No player named '" + targetName + "' is currently online.");
			return;
		}

		String message = String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length));
		sender.sendMessage("You tell " + recipient.getName() + ": " + message);
		recipient.sendMessage(sender.getName() + " tells you: " + message);
		recipient.setLastTellSender(sender);

	} // end handleTell

	public static void handleWhisper(Player sender, String[] tokens) {
		if (tokens.length < 3) {
			sender.sendMessage("Usage: whisper <player> <message>");
			return;
		}

		if (sender.hasEffect(EffectType.SILENCE)) {
			sender.sendMessage("You try to whisper, but no sound escapes your lips...");
			return;
		}

		if (sender.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
			sender.sendMessage("This room is eerily quiet. You cannot whisper here.");
			return;
		}

		String targetName = tokens[1];
		Player target = (Player) sender.getCurrentRoom().getMobByName(targetName);

		if (target == null) {
			sender.sendMessage("No player named '" + targetName + "' is here.");
			return;
		}

		String message = String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length));

		// Notify both
		sender.sendMessage("You whisper to " + target.getName() + ": " + message);
		target.sendMessage(sender.getName() + " whispers to you: " + message);
		
	} // end handleWhisper


} // end CommunicationHandler
