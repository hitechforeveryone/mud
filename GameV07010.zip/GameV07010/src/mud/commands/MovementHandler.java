package mud.commands;

import mud.core.*;
import mud.spell.effects.*;

public class MovementHandler {


	static boolean isDirection(String word) {
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(word)) return true;
		}
		return false;
	}


	static String handleMovement(Player player, String direction) {

	    if (player.isAttacking()) {
	        return "You are in combat.";
	    }

	    Direction dirEnum = Direction.fromString(direction);
	    if (dirEnum == null) return "Invalid direction.";

	    Room current = player.getCurrentRoom();
	    if (current == null) return "You are nowhere.";

	    // Boat check
	    boolean hasBoat = player.getInventory().stream()
	            .anyMatch(o -> o.getType() == ObjectType.BOAT);

	    String restriction = checkMovementRestrictions(player, dirEnum);
	    if (restriction != null) return restriction;

	    Door door = current.getDoor(dirEnum);
	    if (door != null) {
	        if (!door.isOpen()) return "🛋 The " + door.getDoorName() + " is closed.";
	        if (door.isLocked()) return "🔒 The " + door.getDoorName() + " is locked.";
	    }

	    // --- Cross-Zone Exit ---
	    ZoneExit cross = current.getZoneExit(dirEnum);
	    if (cross != null) {

	        Zone nextZone = WorldManager.loadZone(
	                cross.getWorldId(),
	                cross.getTargetZoneId()
	        );

	        if (nextZone == null) return "⚠️ The path seems blocked (target zone missing).";

	        nextZone.setParentWorld(
	                WorldManager.loadWorld(cross.getTargetWorldId())
	        );

	        Room nextRoom = nextZone.getRoom(cross.getTargetRoomId());
	        if (nextRoom == null) return "⚠️ The path seems blocked (target room not loaded).";

	        current.setExit(dirEnum, nextRoom);
	        nextRoom.setExit(dirEnum.getOpposite(), current);
	    }

	    Room next = current.getExit(dirEnum);
	    if (next == null) return "You can't go that way.";

	    // Water
	    if (next.hasFlag(RoomFlag.ON_WATER)
	            && (!player.hasEffect(EffectType.WATER_WALK) || !hasBoat)) {
	        return "You require a boat to go that way.";
	    }

	    // Tunnel
	    if (next.hasFlag(RoomFlag.TUNNEL)
	            && next.getPlayers().size() >= next.getTunnelNum()) {
	        return "That tunnel is too narrow for another person.";
	    }

	    // 🔥 ONE CALL DOES EVERYTHING 🔥
	    boolean moved = moveMob(player, dirEnum);
	    if (!moved) return "You cannot go that way.";

	    return null;
	}
	// end


	// --- FALL HANDLING ---
	public static void handleFall(Mob mob, Room room) {
	    if (!room.hasFlag(RoomFlag.FALL)) return;

	    boolean levEquipped = mob.getEquipment().values().stream()
	            .anyMatch(o -> o.hasEffect(ItemEffect.LEVITATE));

	    boolean levitating = mob.hasEffect(EffectType.LEVITATE) || levEquipped;

	    if (levitating) {
	        // Optional: message only if mob is a Player
	        if (mob instanceof Player player) {
	            player.sendMessage("You hover safely over the drop.");
	        }
	        return;
	    }

	    Room down = room.getExit(Direction.DOWN);
	    if (down == null) {
	        if (mob instanceof Player player) {
	            player.sendMessage("You slip… but nowhere to fall!");
	        }
	        return;
	    }

	    // Perform fall
	    room.removeMob(mob);
	    down.addMob(mob);
	    mob.setCurrentRoom(down);

	    if (mob instanceof Player player) {
	        player.sendMessage("You fall!\n");
	        LookHandler.handleLook(player, new String[]{"look"});
	    }

	    // Optional: broadcast to others in the room if not a player
	    if (!(mob instanceof Player)) {
	        room.broadcast(mob.getMobName() + " falls downward.", mob);
	        down.broadcast(mob.getMobName() + " crashes in from above.", mob);
	    }

	    // Recursively handle multiple FALL rooms
	    handleFall(mob, down);
	}


	
	public static boolean moveMob(Mob mob, Direction dir) {
	    Room fromRoom = mob.getCurrentRoom();
	    if (fromRoom == null) return false;

	    Room toRoom = fromRoom.getExit(dir);
	    if (toRoom == null) return false;

	    if (MovementHandler.isMovementBlocked(mob, fromRoom, dir)) {
	        if (mob instanceof Player) {
	            mob.sendMessage("You cannot go that way.");
	        }
	        return false;
	    }

	    boolean visible =
	            mob.isVisible()
	            && !mob.hasAffect(MobAffectFlag.SNEAK)
	            && !mob.hasAffect(MobAffectFlag.INVISIBLE);

	    Direction reverse = dir.getOpposite();

	    // Departure
	    if (visible) {
	        fromRoom.broadcastToExcept(mob,mob,mob.getMobName() + " leaves " + dir.toString().toLowerCase() + ".");
	    }

	    // Move
	    fromRoom.removeMob(mob);
	    toRoom.addMob(mob);
	    mob.setCurrentRoom(toRoom);

	    // Arrival
	    if (visible) {
	        toRoom.broadcastToExcept(mob,mob,mob.getMobName() + " enters from the " + reverse.toString().toLowerCase() + ".");
	    }

	    // 🔥 FOLLOW CHAIN 🔥
	    InteractionHandler.handleFollow(mob, fromRoom, toRoom, dir);

	    // Player extras
	    if (mob instanceof Player player) {
	        player.setCurrentZone(toRoom.getZone());
	        player.setCurrentWorld(toRoom.getZone().getParentWorld());
	        player.sendMessage("You move " + dir.toString().toLowerCase() + ".");
	        LookHandler.handleLook(player, new String[]{"look"});
	        handleFall(player, toRoom);
	    }

	    return true;
	}
	// end




	    // --- Core check: is movement blocked? (no messaging) ---
	    public static boolean isMovementBlocked(Mob mob, Room room, Direction dir) {
	        // Room-level exit-blocking effects
	        if (room.hasEffectOnExit(dir, IcewallEffect.class)) return true;
	        if (room.hasEffectOnExit(dir, FlameBarrierEffect.class)) return true;
	        if (room.hasEffectOnExit(dir, FortifyEffect.class)) return true;
	        if (room.hasEffectOnExit(dir, RampartEffect.class)) return true;

	        // MOB-level "rooting" effects
	        if (mob.hasEffect(EffectType.HOLD)) return true;
	        if (mob.hasEffect(EffectType.STUN)) return true;
	        if (mob.hasEffect(EffectType.WEB)) return true;
	        if (mob.hasEffect(EffectType.ROOT)) return true;
	        if (mob.hasEffect(EffectType.ENTANGLE)) return true;
	        if (mob.hasEffect(EffectType.FROSTBITE)) return true;

	        return false;
	    }

	    // --- Player-facing check: returns message if blocked ---
	    public static String checkMovementRestrictions(Mob player, Direction dir) {
	        Room room = player.getCurrentRoom();
	        if (room == null) return "⚠️ You are not in a valid room.";

	        // Room-level exit-blocking effects
	        if (room.hasEffectOnExit(dir, IcewallEffect.class))
	            return "A massive wall of ice blocks the " + dir.toString().toLowerCase() + " exit!";
	        if (room.hasEffectOnExit(dir, RampartEffect.class))
	            return "A rampart of stone bars the " + dir.toString().toLowerCase() + " exit!";
	        if (room.hasEffectOnExit(dir, FortifyEffect.class))
	            return "A steel fortification blocks the " + dir.toString().toLowerCase() + " exit!";
	        if (room.hasEffectOnExit(dir, FlameBarrierEffect.class))
	            return "A barrier of flames blocks the " + dir.toString().toLowerCase() + " exit!";

	        // MOB-level effects
	        if (player.hasEffect(EffectType.STUN)) return "💪 You are stunned and cannot move!";
	        if (player.hasEffect(EffectType.ROOT)) return "🌍 Your legs are rooted to the ground!";
	        if (player.hasEffect(EffectType.ENTANGLE)) return "🌿 You are entangled and cannot move!";
	        if (player.hasEffect(EffectType.WEB)) return "🕷️ Sticky webs bind your legs—you can’t move!";
	        if (player.hasEffect(EffectType.FROSTBITE)) return "❄️ Your feet are frozen to the ground!";
	        if (player.hasEffect(EffectType.HOLD)) return "💫 You are held immobile!";

	        return null; // no restriction found
	    }
	


	
}
