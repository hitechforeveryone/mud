package mud.commands;

import mud.core.Party;
import mud.core.Player;
import mud.core.WorldManager;

public class PartyHandler {

	public static String handleParty(Player player, String[] args) {
		// The first arg should be the subcommand, not the literal "party"
		if (args.length == 0) {
			Party party = player.getParty();
			if (party == null) return "You're not in a party.";
			StringBuilder sb = new StringBuilder("Your party members:\n");
			for (Player member : party.getMembers()) {
				if (party.getLeader().equals(member)) {
					sb.append(" * ").append(member.getDisplayName()).append(" (Leader)\n");
				} else {
					sb.append(" - ").append(member.getDisplayName()).append("\n");
				}
			}
			return sb.toString();
		}

		// FIX: skip the literal "party" command name if present
		int subIndex = 0;
		if (args[0].equalsIgnoreCase("party")) {
			if (args.length == 1) {
				// just "party" => show members
				return handleParty(player, new String[]{});
			}
			subIndex = 1; // shift index to get real subcommand
		}

		String sub = args[subIndex].toLowerCase();

		switch (sub) {
		case "invite" -> {
			if (args.length <= subIndex + 1) return "Usage: party invite <player>";

			if (player.getParty() != null && !player.getParty().isLeader(player)) {
				return "Only the party leader can invite.";
			}

			String targetName = args[subIndex + 1];
			Player target = WorldManager.getPlayer(targetName);
			if (target == null) return "That player is not online.";

			if (target.getParty() != null) return target.getName() + " is already in a party.";

			if (player.getParty() == null) {
				Party newParty = new Party(player);
				player.setParty(newParty);
			}

			player.getParty().addMember(target);
			player.sendMessage("You invite " + target.getName() + " to your party.");
			target.sendMessage(player.getName() + " has invited you to join their party.");
			return null;
		}

		case "kick" -> {
			if (args.length <= subIndex + 1) return "Usage: party kick <player>";

			if (player.getParty() == null || !player.getParty().isLeader(player)) {
				return "Only the party leader can kick members.";
			}

			String targetName = args[subIndex + 1];
			Player target = WorldManager.getPlayer(targetName);
			if (target == null || !player.getParty().isMember(target)) {
				return "That player is not in your party.";
			}

			player.getParty().removeMember(target);
			player.sendMessage("You kicked " + target.getName() + " from the party.");
			target.sendMessage("You have been kicked from the party.");
			return null;
		}

		case "leave" -> {
			if (player.getParty() == null) return "You're not in a party.";
			player.getParty().removeMember(player);
			player.sendMessage("You leave the party.");
			return null;
		}

		case "list" -> {
			if (player.getParty() == null) return "You're not in a party.";
			player.sendMessage("" + player.getParty().listMembers());
			return null;
		}

		default -> {
			return "Unknown party command. Try: party, party invite <name>, party kick <name>, party leave";
		}
		}
	} // end handleParty


}
