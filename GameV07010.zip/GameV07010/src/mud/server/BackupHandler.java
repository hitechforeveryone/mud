package mud.server;

import mud.config.Config;
import mud.core.Player;
import mud.system.PlayerLoader;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class BackupHandler {

	private static final int MAX_BACKUPS_PER_PLAYER = 10;
	
	
    /**
     * Handle backup request from a player/admin.
     * If playerName is null or empty, backs up all players.
     */
    public static void handleBackup(Player requester, String playerName) {
        System.out.println("💾 Backup initiated by: " + (requester != null ? requester.getName() : "SYSTEM"));

        if (playerName == null || playerName.isBlank()) {
            // Backup all players
            backupAllPlayers();
            if (requester != null) {
                requester.sendMessage("✅ All players backed up successfully.");
            }
        } else {
            // Backup a single player
            Player target = PlayerLoader.load(playerName);
            enforceBackupLimit(playerName);
            
            if (target == null) {
                if (requester != null) requester.sendMessage("❌ Player not found: " + playerName);
                return;
            }
            PlayerLoader.createNamedBackup(playerName, "_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()));
        }
    }

    /**
     * Backup all players using PlayerLoader logic
     */
	public static void backupAllPlayers() {
	    File playerDir = new File(Config.PLAYERS_DIR);
	    File backupDir = new File(Config.BACKUP_FOLDER);

	    if (!playerDir.exists() || !playerDir.isDirectory()) {
	        System.err.println("❌ Player directory not found: " + playerDir.getAbsolutePath());
	        return;
	    }

	    backupDir.mkdirs();

	    String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    File[] playerFiles = playerDir.listFiles((dir, name) ->
	        name.endsWith(".player.txt") && !name.startsWith("._") // skip macOS metadata files
	    );

	    if (playerFiles == null || playerFiles.length == 0) {
	        System.out.println("📦 No player files found to back up.");
	        return;
	    }

	    int backedUpCount = 0;

	    for (File original : playerFiles) {
	        String baseName = original.getName().replace(".player.txt", "");
	        File backup = new File(backupDir, baseName + "_" + timestamp + ".player.txt");

	        try (InputStream in = new FileInputStream(original);
	             OutputStream out = new FileOutputStream(backup)) {

	            byte[] buffer = new byte[4096];
	            int len;
	            while ((len = in.read(buffer)) > 0) {
	                out.write(buffer, 0, len);
	            }

	            backedUpCount++;
	            System.out.println("📦 Backed up player: " + original.getName());

	        } catch (IOException e) {
	            System.err.println("❌ Failed to back up player file: " + original.getName());
	            e.printStackTrace();
	        }
	    }

	    System.out.println("✅ Backed up " + backedUpCount + " player(s).");
	}
	// end

    
    
    public static void listBackups(Player requester, String playerName) {
        if (playerName == null || playerName.isBlank()) {
            if (requester != null) requester.sendMessage("❌ Player name required to list backups.");
            return;
        }

        List<File> backups = PlayerLoader.listBackups(playerName);
        if (backups.isEmpty()) {
            if (requester != null) requester.sendMessage("📦 No backups found for player: " + playerName);
            System.out.println("📦 No backups found for player: " + playerName);
            return;
        }

        if (requester != null) requester.sendMessage("📦 Backups for '" + playerName + "':");
        System.out.println("📦 Backups for '" + playerName + "':");
        for (File f : backups) {
            if (requester != null) requester.sendMessage(" - " + f.getName());
            System.out.println(" - " + f.getName());
        }
    }

    /**
     * Restore a specific backup file for a player.
     * @param requester Optional Player requesting restore (for messaging)
     * @param backupFileName Full backup file name to restore (must exist in BACKUP_FOLDER)
     */
    public static void restoreBackup(Player requester, String playerName, String backupFileName) {
        if (!backupFileName.startsWith(playerName + "_")) {
            requester.sendMessage("❌ Backup does not belong to player: " + playerName);
            return;
        }
        
        if (backupFileName == null || backupFileName.isBlank()) {
            if (requester != null) requester.sendMessage("❌ Backup file name required.");
            return;
            
        }
        boolean success = PlayerLoader.restoreBackup(backupFileName);
        if (success) {
            if (requester != null) requester.sendMessage("✅ Backup restored: " + backupFileName);
            System.out.println("📦 Backup restored: " + backupFileName);
        } else {
            if (requester != null) requester.sendMessage("❌ Failed to restore backup: " + backupFileName);
            System.err.println("❌ Failed to restore backup: " + backupFileName);
        }
       
    }
    
    
    /**
     * Restore the latest backup for a given player automatically.
     * @param requester Optional player/admin requesting the restore (for messaging)
     * @param playerName Name of the player whose latest backup should be restored
     */
    public static void restoreLatestBackup(Player requester, String playerName) {
        if (playerName == null || playerName.isBlank()) {
            if (requester != null) requester.sendMessage("❌ Player name required to restore latest backup.");
            return;
        }

        List<File> backups = PlayerLoader.listBackups(playerName);
        if (backups.isEmpty()) {
            if (requester != null) requester.sendMessage("📦 No backups found for player: " + playerName);
            System.out.println("📦 No backups found for player: " + playerName);
            return;
        }

        // The listBackups method already sorts newest first
        File latestBackup = backups.get(0);

        boolean success = PlayerLoader.restoreBackup(latestBackup.getName());
        if (success) {
            if (requester != null) requester.sendMessage("✅ Latest backup restored for player: " + playerName);
            System.out.println("📦 Latest backup restored for player: " + playerName + " -> " + latestBackup.getName());
        } else {
            if (requester != null) requester.sendMessage("❌ Failed to restore latest backup for player: " + playerName);
            System.err.println("❌ Failed to restore latest backup for player: " + playerName);
        }
    }
    
    
	private static void enforceBackupLimit(String playerName) {
        List<File> backups = PlayerLoader.listBackups(playerName);
        if (backups.size() <= MAX_BACKUPS_PER_PLAYER) return; // under limit

        // oldest backups are at the end of the list, remove them
        for (int i = MAX_BACKUPS_PER_PLAYER; i < backups.size(); i++) {
            File oldBackup = backups.get(i);
            if (oldBackup.delete()) {
                System.out.println("🗑️ Deleted old backup: " + oldBackup.getName());
            } else {
                System.err.println("❌ Failed to delete old backup: " + oldBackup.getName());
            }
        }
    }
    
}
// end
