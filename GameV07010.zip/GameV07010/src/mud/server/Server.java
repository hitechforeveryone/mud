package mud.server;
// RUN THIS FIRST
import mud.config.Config;
import mud.core.*;
import mud.map.*;
import mud.spell.*;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static final int PORT = Config.SERVER_PORT;

    public static void main(String[] args) {
       
    	
    	
    	
    	System.out.println("🌍 Loading all worlds...");
    	WorldManager.loadAll();  // Implement this if not done yet
    	System.out.println("✅ Worlds loaded: " + WorldManager.getAllWorlds().toString());

    	// Fallback: Create a default world if none exist
    	if (WorldManager.getAllWorlds().isEmpty()) {
    	    System.out.println("⚠️ No worlds found. Creating default world...");
    	    World defaultWorld = WorldManager.createTithriusWorld();
    	    WorldManager.registerWorld(defaultWorld);
    	}
/*
    	// Step 1: Create directories if needed
       // Config.createDirectories();
	
        // loads world 0
    	// need to update to load all worlds in the folder
        World world = WorldManager.loadWorld(Config.DEFAULT_WORLD_ID);
        if (world == null) {
            System.out.println("World not found. Creating...");
            world = WorldManager.createTithriusWorld();
            WorldManager.registerWorld(world);

        }
         else {
            System.out.println("Worlds already loaded.");
        }
       */
        // Step 3: Start global game clocks
        System.out.println("Starting global clock...");
        WorldManager.getGlobalClock().start();
        System.out.println("Global clock started.");
        
        
        SpellManager.listSpells();
        HelpManager.loadAllFromDisk();

        MapManager.loadAll(Config.MAPS_DIR);
        ZoneMapManager.loadAll(Config.MAPS_DIR);
        WorldMapManager.loadAll(Config.MAPS_DIR);
        
        // Step 4: Start server
        System.out.println("Starting server on port " + PORT + "...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("✅ Server is now listening for clients.");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("🔗 New client connected from " + clientSocket.getInetAddress());
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("❌ Failed to start server:");
            e.printStackTrace();
        }
    }
}
