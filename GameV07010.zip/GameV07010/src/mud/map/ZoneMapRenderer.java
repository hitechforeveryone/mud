package mud.map;

import mud.core.*;
import java.util.*;

public class ZoneMapRenderer {

    private static final String BLUE = Ansi.BLUE;
    private static final String RESET = Ansi.RESET;

    public static String renderFor(Mob player) {
        if (player.getRoom() == null || player.getRoom().getZone() == null)
            return "You are nowhere.";

        Zone zone = player.getRoom().getZone();
        ZoneMap map = ZoneMapManager.get(Integer.parseInt(zone.getWorld().getWorldId()), zone.getZoneId());

        if (map == null)
            return "No map exists for this zone.";

        int playerRoomId = player.getCurrentRoom().getId();
        List<String> lines = map.getLines();
        StringBuilder sb = new StringBuilder();

        sb.append("== ").append(zone.getName()).append(" ==\n");

        String cell = String.format("%3d", playerRoomId);
        String playerMarker = BLUE + " @ " + RESET;

        for (String line : lines) {
            // Use literal replacement; spacing ensures alignment
            String newLine = line.replace(cell, playerMarker);
            sb.append(newLine).append("\n");
        }


        return sb.toString();
    }

}
