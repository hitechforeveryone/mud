package mud.map;

import java.nio.file.*;
import java.util.*;

public class WorldMapLoader {

    public static WorldMap load(Path path) throws Exception {
        String file = path.getFileName().toString(); // 1.world.map.txt
        String base = file.replace(".world.map.txt", "");

        int worldId = Integer.parseInt(base);

        List<String> lines = Files.readAllLines(path);
        return new WorldMap(worldId, lines);
    }
}
// end
