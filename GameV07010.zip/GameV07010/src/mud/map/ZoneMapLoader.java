package mud.map;

import java.nio.file.*;
import java.util.*;

public class ZoneMapLoader {

    public static ZoneMap load(Path path) throws Exception {
        String file = path.getFileName().toString(); // 1_3.map.txt
        String base = file.replace(".map.txt", "");
        String[] parts = base.split("_");

        int worldId = Integer.parseInt(parts[0]);
        int zoneId = Integer.parseInt(parts[1]);

        List<String> lines = Files.readAllLines(path);
        return new ZoneMap(worldId, zoneId, lines);
    }
}
// end
