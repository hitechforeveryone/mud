package mud.map;

import java.util.*;

public class ZoneMap {

    private final int worldId;
    private final int zoneId;
    private final List<String> lines;

    public ZoneMap(int worldId, int zoneId, List<String> lines) {
        this.worldId = worldId;
        this.zoneId = zoneId;
        this.lines = lines;
    }

    public int getWorldId() {
        return worldId;
    }

    public int getZoneId() {
        return zoneId;
    }

    public List<String> getLines() {
        return lines;
    }
}
// end
