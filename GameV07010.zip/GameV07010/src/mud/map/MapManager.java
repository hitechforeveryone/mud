package mud.map;

import java.nio.file.*;
import java.util.*;

public class MapManager {

    private static final Map<String, AsciiMap> maps = new HashMap<>();

    public static void loadAll(String dir) {
        try {
            Files.list(Paths.get(dir))
                .filter(p -> p.toString().endsWith(".map.txt"))
                .forEach(p -> {
                    try {
                        AsciiMap map = AsciiMap.load(p);
                        maps.put(map.getName().toLowerCase(), map);
                    } catch (Exception e) {
                        System.err.println("Failed to load map: " + p);
                    }
                });
        } catch (Exception e) {
            System.err.println("Map directory missing: " + dir);
        }
    }

    public static AsciiMap get(String name) {
        return maps.get(name.toLowerCase());
    }

    public static Collection<AsciiMap> all() {
        return maps.values();
    }
}
// end
