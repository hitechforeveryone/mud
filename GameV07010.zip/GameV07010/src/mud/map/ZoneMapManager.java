package mud.map;

import java.nio.file.*;
import java.util.*;

import mud.config.Config;

public class ZoneMapManager {

    private static final Map<String, ZoneMap> maps = new HashMap<>();

    private static String key(int worldId, int zoneId) {
        return worldId + ":" + zoneId;
    }

    public static void loadAll(String dir) {
        try {
            Files.list(Paths.get(dir))
                .filter(p -> p.toString().endsWith(".map.txt"))
                .forEach(p -> {
                    try {
                        ZoneMap map = ZoneMapLoader.load(p);
                        maps.put(key(map.getWorldId(), map.getZoneId()), map);
                    } catch (Exception e) {
                        System.err.println("Invalid zone map: " + p);
                    }
                });
        } catch (Exception e) {
            System.err.println("Zone map directory missing: " + dir);
        }
    }

    public static ZoneMap get(int worldId, int zoneId) {
        return maps.get(key(worldId, zoneId));
    }
    
    public static Collection<ZoneMap> all() {
        return maps.values();
    }

    public static void reload() {
        maps.clear();
        loadAll(Config.MAPS_DIR);
    }
    // end

    
    
}
// end
