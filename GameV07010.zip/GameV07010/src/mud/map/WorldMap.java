package mud.map;

import java.util.*;

public class WorldMap {

    private final int worldId;
    private final List<String> lines;

    public WorldMap(int worldId, List<String> lines) {
        this.worldId = worldId;
        this.lines = lines;
    }

    public int getWorldId() {
        return worldId;
    }

    public List<String> getLines() {
        return lines;
    }
}
// end
