package mud.map;

public class MapRenderer {

    public static String render(AsciiMap map) {
        StringBuilder sb = new StringBuilder();

        sb.append("== ").append(map.getName()).append(" ==\n");

        for (String line : map.getLines()) {
            sb.append(line).append("\n");
        }

        return sb.toString();
    }
}
// end
