package mud.map;

import java.nio.file.*;
import java.util.*;

public class AsciiMap {

    private final String name;
    private final List<String> lines;

    public AsciiMap(String name, List<String> lines) {
        this.name = name;
        this.lines = lines;
    }

    public String getName() {
        return name;
    }

    public List<String> getLines() {
        return lines;
    }

    public static AsciiMap load(Path path) throws Exception {
        List<String> lines = Files.readAllLines(path);
        String name = path.getFileName().toString();
        return new AsciiMap(name, lines);
    }
}
// end
