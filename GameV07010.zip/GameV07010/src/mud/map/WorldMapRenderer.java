package mud.map;

public class WorldMapRenderer {

    public static String render(WorldMap map) {
        StringBuilder sb = new StringBuilder();
        sb.append("== World ").append(map.getWorldId()).append(" ==\n");

        for (String line : map.getLines()) {
            sb.append(line).append("\n");
        }

        return sb.toString();
    }
}
// end
