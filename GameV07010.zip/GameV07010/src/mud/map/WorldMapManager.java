package mud.map;

import java.nio.file.*;
import java.util.*;

public class WorldMapManager {

    private static final Map<Integer, WorldMap> maps = new HashMap<>();

    public static void loadAll(String dir) {
        try {
            Files.list(Paths.get(dir))
                .filter(p -> p.toString().endsWith(".world.map.txt"))
                .forEach(p -> {
                    try {
                        WorldMap map = WorldMapLoader.load(p);
                        maps.put(map.getWorldId(), map);
                    } catch (Exception e) {
                        System.err.println("Invalid world map: " + p);
                    }
                });
        } catch (Exception e) {
            System.err.println("World map directory missing: " + dir);
        }
    }

    public static WorldMap get(int worldId) {
        return maps.get(worldId);
    }

    public static Collection<WorldMap> all() {
        return maps.values();
    }

    public static void reload(String dir) {
        maps.clear();
        loadAll(dir);
    }
}
// end
