package mud.combat;

import mud.core.*;
import mud.spell.effects.*;

public class CombatFormatter {

	public static String formatBuffs(Mob mob) {
		StringBuilder sb = new StringBuilder();
		sb.append("Buffs[");

		boolean hasBuffs = false;

		// --- FIRE SHIELD ---
		if (mob.getEffect(FireShieldEffect.class) != null) {
			hasBuffs = true;
			sb.append(Ansi.RED).append("F").append(Ansi.RESET);
		}

		// --- MIRROR IMAGE ---
		MirrorImageEffect mi = mob.getEffect(MirrorImageEffect.class);
		if (mi != null) {
			hasBuffs = true;
			for (int i = 0; i < mi.getImages(); i++) {
				sb.append(Ansi.GREY).append("i").append(Ansi.RESET);
			}
		}

		// --- SHADOW CLONE ---
		ShadowCloneEffect sc = mob.getEffect(ShadowCloneEffect.class);
		if (sc != null) {
			hasBuffs = true;
			for (int i = 0; i < sc.getImages(); i++) {
				sb.append(Ansi.GREY).append("i").append(Ansi.RESET);
			}
		}

		// --- BONE SHIELD ---
		BoneShieldEffect bs = mob.getEffect(BoneShieldEffect.class);
		if (bs != null) {
			hasBuffs = true;
			for (int i = 0; i < bs.getImages(); i++) {
				sb.append(Ansi.GREY).append("i").append(Ansi.RESET);
			}
		}

		
		// --- Crushing Grip ---
		if (mob.getEffect(CrushingGripEffect.class) != null) {
			hasBuffs = true;
			sb.append(Ansi.GREY).append("C").append(Ansi.RESET);
		}
		// --- Forceful Hand ---
		if (mob.getEffect(ForcefulHandEffect.class) != null) {
			hasBuffs = true;
			sb.append(Ansi.GREY).append("F").append(Ansi.RESET);
		}
		
		// --- Strength ---
		if (mob.getEffect(StrengthEffect.class) != null) {
			hasBuffs = true;
			sb.append(Ansi.GREY).append("+").append(Ansi.RESET);
		}
		
		
		// TODO: Sanctuary, Globe, Stoneskin, etc.
		
		

		if (!hasBuffs) {
			sb.append("none");
		}

		sb.append("]");
		return sb.toString();
	}
	// end formatBuffs



	public static String formatDebuffs(Mob mob) {
		StringBuilder sb = new StringBuilder();
		sb.append(" Debuffs[");
		boolean hasdeBuffs = false;

		// Mental Impairment
		// --- Blind ---
		if (mob.getEffect(BlindEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("B").append(Ansi.RESET);
		}
		// --- Charm ---
		if (mob.getEffect(CharmPersonEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("C").append(Ansi.RESET);
		}
		// --- Confusion ---
		if (mob.getEffect(ConfusionEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("c").append(Ansi.RESET);
		}
		// --- Fear ---
		if (mob.getEffect(FearEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("f").append(Ansi.RESET);
		}
		// --- SAP ---
		if (mob.getEffect(SilenceEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.RED).append("s").append(Ansi.RESET);
		}
		// --- SILENCE ---
		if (mob.getEffect(SilenceEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("S").append(Ansi.RESET);
		}
		// --- STUN ---
		if (mob.getEffect(StunEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.WHITE).append("s").append(Ansi.RESET);
		}	    
		// --- SLEEP ---
		// TODO
		//	    if (mob.getEffect(SleepEffect.class) != null) {
		//	        hasdeBuffs = true;
		//	        sb.append(Ansi.WHITE).append("S").append(Ansi.RESET);
		//	    }

		// Movement Impairment
		// --- Entangle ---
		if (mob.getEffect(EntangleEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREEN).append("E").append(Ansi.RESET);
		}
		// --- Frostbite ---
		if (mob.getEffect(FrostbiteEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.BLUE).append("F").append(Ansi.RESET);
		}
		// --- Hold ---
		if (mob.getEffect(HoldEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("H").append(Ansi.RESET);
		}
		// --- Root ---
		if (mob.getEffect(RootEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.CYAN).append("R").append(Ansi.RESET);
		}
		// --- Web ---
		if (mob.getEffect(WebEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("W").append(Ansi.RESET);
		}



		// Other Debuffs
		// --- Berserk ---
		if (mob.getEffect(BerserkEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.ORANGE).append("b").append(Ansi.RESET);
		}
		// --- Bleed ---
		if (mob.getEffect(BleedEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.RED).append("B").append(Ansi.RESET);
		}	    
		// --- Poison ---
		if (mob.getEffect(PoisonEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREEN).append("P").append(Ansi.RESET);
		}
		// --- Weakness ---
		if (mob.getEffect(WeaknessEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("-").append(Ansi.RESET);
		}
		
		
		
		
		// TODO
		// burn etc





		if (!hasdeBuffs) {
			sb.append("none");
		}

		sb.append("]");
		return sb.toString();
	}


}// end
