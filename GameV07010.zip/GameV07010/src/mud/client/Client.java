package mud.client;
// RUN THIS SECOND
import java.io.*;
import java.net.Socket;

//import mud.server.AdminCreator;
import mud.config.Config;

public class Client {
    public static final int PORT = Config.SERVER_PORT;

    public static void main(String[] args) {
    	
    	// creates an Admin character if none exists
    	// AdminCreator.createAdmin(); // Only needs to run once
    	
        try (Socket socket = new Socket("localhost", PORT)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

            // Thread to read messages from the server and print them
            Thread serverReader = new Thread(() -> {
                String fromServer;
                try {
                    while ((fromServer = in.readLine()) != null) {
                        System.out.println(fromServer);
                    }
                } catch (IOException e) {
                    System.out.println("Disconnected from server.");
                    System.exit(0); // closes the server out
                }
            });

            // Thread to read user input and send to the server
            Thread userReader = new Thread(() -> {
                String fromUser;
                try {
                    while ((fromUser = userInput.readLine()) != null) {
                        out.println(fromUser);
                    }
                } catch (IOException e) {
                    System.out.println("Error reading input.");
                }
            });

            serverReader.start();
            userReader.start();

            serverReader.join();
            userReader.join();

        } catch (IOException | InterruptedException e) {
            System.out.println("Could not connect to server.");
            e.printStackTrace();
        }
    }

} // end Client
