package mud.editor;

import mud.core.*;
import mud.core.Climate;
import mud.core.ZoneResetType;

public class ZoneEditor implements Editor {
    private final Zone zone;
    private final Player player;
    private ZoneEditorState state = ZoneEditorState.MAIN_MENU;

    private boolean finished = false;

    public ZoneEditor(Zone zone, Player player) {
        this.zone = zone;
        this.player = player;
    }

    @Override
    public void startEditing() {
        state = ZoneEditorState.MAIN_MENU;
        displayMainMenu();
    }

    private void displayMainMenu() {
    	player.sendMessage("1) Show Zone Info");
    	player.sendMessage("2) Edit Name");
    	player.sendMessage("3) Edit Climate");
    	player.sendMessage("4) Edit Reset Type");
    	player.sendMessage("5) Edit Reset Timer");
    	player.sendMessage("6) Edit Owner");
    	player.sendMessage("7) Save Zone");
    	player.sendMessage("8) Exit Editor");

    }

    @SuppressWarnings("incomplete-switch")
	@Override
    public void handleInput(String input) {
        switch (state) {
            case MAIN_MENU:
                handleMainMenuInput(input);
                break;
            case EDIT_NAME:
                zone.setName(input.trim());
                player.sendMessage("Zone name updated.");
                state = ZoneEditorState.MAIN_MENU;
                displayMainMenu();
                break;
            case EDIT_CLIMATE:
                try {
                    int index = Integer.parseInt(input.trim());
                    Climate[] climates = Climate.values();
                    if (index >= 1 && index <= climates.length) {
                        zone.setClimate(climates[index - 1]);
                        player.sendMessage("Climate set to: " + climates[index - 1]);
                    } else {
                        player.sendMessage("Invalid climate index.");
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("Invalid input.");
                }
                state = ZoneEditorState.MAIN_MENU;
                displayMainMenu();
                break;
            case SET_RESET_TYPE:
                try {
                    int index = Integer.parseInt(input.trim());
                    ZoneResetType[] types = ZoneResetType.values();
                    if (index >= 0 && index < types.length) {
                        zone.setResetType(types[index]);
                        player.sendMessage("Reset type set to: " + types[index]);
                    } else {
                        player.sendMessage("Invalid reset type.");
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("Invalid input.");
                }
                state = ZoneEditorState.MAIN_MENU;
                displayMainMenu();
                break;

            case EDIT_RESET_TIMER:
                try {
                    int days = Integer.parseInt(input.trim());
                    if (days >= 0) {
                        zone.setResetTimer(days);
                        player.sendMessage("Reset timer set to " + days + " days.");
                    } else {
                        player.sendMessage("Timer must be non-negative.");
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("Invalid input.");
                }
                state = ZoneEditorState.MAIN_MENU;
                displayMainMenu();
                break;


            case EDIT_OWNER:
                zone.setOwner(input.trim());
                player.sendMessage("Owner updated.");
                state = ZoneEditorState.MAIN_MENU;
                displayMainMenu();
                break;

                
                
                
                
        }
        
    }

    private void handleMainMenuInput(String input) {
        switch (input) {
            case "1":
                displayZoneInfo();
                displayMainMenu();
                break;
            case "2":
                player.sendMessage("Enter new name for zone (current: " + zone.getName() + "):");
                state = ZoneEditorState.EDIT_NAME;
                break;
            case "3":
                displayClimateOptions();
                state = ZoneEditorState.EDIT_CLIMATE;
                break;
            case "4":
                displayResetTypeOptions();
                state = ZoneEditorState.EDIT_RESET_TYPE;
                break;
            case "5":
                player.sendMessage("Enter reset timer in game days (current: " + zone.getResetTimer() + "):");
                state = ZoneEditorState.EDIT_RESET_TIMER;
                break;
            case "6":
                player.sendMessage("Enter new owner name (current: " + zone.getOwner() + "):");
                state = ZoneEditorState.EDIT_OWNER;
                break;
            case "7":
                doSave();
                displayMainMenu();
                break;
            case "8":
                player.sendMessage("Exiting zone editor.");
                finished = true;
                break;

            default:
                player.sendMessage("Invalid option.");
                displayMainMenu();
                break;
        }
    }


    private void displayClimateOptions() {
        player.sendMessage("Available Climates:");
        Climate[] climates = Climate.values();
        for (int i = 0; i < climates.length; i++) {
            player.sendMessage((i + 1) + ") " + climates[i]);
        }
        player.sendMessage("Enter the number of the climate:");
    }

    private void displayResetTypeOptions() {
        player.sendMessage("Reset Types:");
        ZoneResetType[] types = ZoneResetType.values();
        for (int i = 0; i < types.length; i++) {
            player.sendMessage(i + ") " + types[i]);
        }
        player.sendMessage("Enter the number of the reset type:");
    }
    private void displayZoneInfo() {
        player.sendMessage("\n--- Zone Info ---");
        player.sendMessage("ID: " + zone.getZoneId());
        player.sendMessage("Name: " + zone.getName());
        player.sendMessage("Owner: " + zone.getOwner());
        player.sendMessage("Climate: " + zone.getClimate());
        player.sendMessage("Reset Type: " + zone.getResetType());
        player.sendMessage("Reset Timer: " + zone.getResetTimer() + " game days");
        player.sendMessage("Rooms: " + zone.getRooms().size());
    }
    
    private void doSave() {
        boolean success = WorldManager.saveZone(zone);
        if (success) {
            player.sendMessage("Zone '" + zone.getZoneId() + "' saved successfully.");
        } else {
            player.sendMessage("❌ Failed to save zone.");
        }
    }


    @Override
    public boolean save() {
        return WorldManager.saveZone(zone);
    }

    @Override public void stopEditing() {}
    @Override public void showMenu() { displayMainMenu(); }
    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override public void tick() {}
    @Override public String getEditorName() { return "ZoneEditor for Zone " + zone.getZoneId(); }
}
