package mud.editor;

import java.util.List;

import mud.core.Player;

public class HelpBodyLineEditor implements Editor {
    private final HelpEditor parent;
    private final int lineIndex;
    private Player player;

    public HelpBodyLineEditor(HelpEditor parent, int lineIndex, Player player) {
        this.parent = parent;
        this.lineIndex = lineIndex;
        this.player = player;
    }

    @Override
    public void startEditing() {
        List<String> lines = parent.getBodyLines();
        if (lineIndex < 0 || lineIndex >= lines.size()) {
            player.sendMessage("Invalid line number.");
            player.setEditor(parent);
            parent.startEditing();
            return;
        }

        player.sendMessage("Current line (" + (lineIndex + 1) + "): " + lines.get(lineIndex));
        player.sendMessage("Enter new text (or leave blank to delete this line):");
    }

    @Override
    public void handleInput(String input) {
        List<String> lines = parent.getBodyLines();

        if (input.trim().isEmpty()) {
            // Delete the line if input is empty
            lines.remove(lineIndex);
            player.sendMessage("Line " + (lineIndex + 1) + " deleted.");
        } else {
            // Update the line
            lines.set(lineIndex, input);
            player.sendMessage("Line " + (lineIndex + 1) + " updated.");
        }

        parent.setBodyLines(lines);
        player.setEditor(parent);
        parent.startEditing();
    }

    @Override
    public void stopEditing() {
        // Nothing needed here for now
    }

    @Override
    public boolean save() {
        // No separate save needed here
        return false;
    }

    @Override
    public String getEditorName() {
        return "HelpBodyLineEditor";
    }

    @Override
    public void tick() {
        // Not used
    }

    @Override
    public boolean isFinished() {
        return false;
    }

    @Override
    public void showMenu() {
        // No menu needed in this editor
    }
}
