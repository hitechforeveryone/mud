package mud.editor;

import java.util.*;
import java.util.stream.Collectors;
import java.io.*;


import mud.core.*;
import mud.config.Config;

public class ObjectEditor implements Editor {

	private final ObjectItem object;
	private final Player player;
	private boolean finished = false;
	private ObjectEditorState state = ObjectEditorState.MAIN_MENU;
	public ObjectEditor(ObjectItem object, Player player) {
		this.object = object;
		this.player = player;
		System.out.println("DEBUG: ObjectEditor created for obj ID " + object.getObjID());

	}

	@Override
	public void startEditing() {
		displayMainMenu();
		System.out.println("DEBUG: ObjectEditor started for obj " + object.getName());
		player.sendMessage("Now editing obj: " + object.getName());
	}

	public void displayMainMenu() {
		player.sendMessage("""
				--- Object Editor: %s ---
				1) Show Obj Info
				2) Edit Obj Name
				3) Edit Short Description
				4) Edit Long Description
				5) Edit Extended Description
				6) Edit Keywords
				7) Edit EquipSlot
				8) Edit Durability
				9) Edit ItemType
				10) Toggle ItemEffects
				11) Edit Obj Value (coins)
				12) Edit Stats
				13) Edit ItemType Specific Values
				14) Toggle Behavior Flags
				15) Set Sapient Speeches
				16) Set Intelligent Values
				17) Set Vampiric Values
				18) Set Stackable
				19) Save Object
				20) Exit Editor
				Choose option:""".formatted(object.getObjID()));
	}



	@Override
	public void handleInput(String input) {
		switch (state) {
		case MAIN_MENU -> handleMainMenu(input);
		case Set_Name -> {
			handleSetObjectName(input);		
		}
		case SET_SHORT_DESC -> {
			object.setShortDescription(input);
			state = ObjectEditorState.MAIN_MENU;
			displayMainMenu();
		}
		case SET_LONG_DESC -> {
			object.setLongDescription(input);
			player.sendMessage("Long description set.");
			state = ObjectEditorState.MAIN_MENU;
			displayMainMenu();
		}
		case SET_EXT_DESC -> {
			object.setExtDescription(input);
			player.sendMessage("Extended description set.");
			state = ObjectEditorState.MAIN_MENU;
			displayMainMenu();
		}
		case SET_KEYWORDS -> {
			handleSetKeywords(input);

		}
		case SET_EQUIPSLOT -> {
			handleSetEquipSlot(input);

		}
		case SET_DURABILITY -> {
			handleSetDurability(input);

		}
		case SET_ITEMTYPE -> {
			handleSetItemType(input);
		}
		case TOGGLE_ITEMEFFECTS -> {
			handleToggleItemEffects(input);
		}
		case EDIT_BEHAVIOR_FLAGS -> {

			handleSetBehaviorFlags(input);
		}
		case SET_OBJVAL -> handleSetObjVal(input);
		case SET_STATS -> handleSetStats(input);
		case ITEM_SPEC_VALS -> {
		    player.sendMessage("Enter special values for this item type (or 'show'):");
		    showObjectInfo();

		    // DO NOT CALL handleSetItemSpecVal YET
		}

		case SET_SPEECHES -> handleSpeeches(input);
		case SET_INTELLIGENT -> handleIntelligent(input);
		case SET_VAMPIRIC -> {
			player.sendMessage("Current Vampiric Percentage: " + object.getVampiricPercent()); 
			handleVampiric(input);
		}
		case SET_STACKABLE -> handleStackable(input);




		}
	}
	
	
	
	private void handleMainMenu(String input) {
		switch (input) {
		case "1" -> {
			showObjectInfo();
			displayMainMenu();
		}
		case "2" -> {
			state = ObjectEditorState.Set_Name;
			player.sendMessage("Enter new name:");
		}
		case "3" -> {
			state = ObjectEditorState.SET_SHORT_DESC;
			player.sendMessage("Enter short description:");
		}
		case "4" -> {
			state = ObjectEditorState.SET_LONG_DESC;
			player.sendMessage("Enter long description:");
		}
		case "5" -> {
			state = ObjectEditorState.SET_EXT_DESC;
			player.sendMessage("Enter extended description:");
		}
		case "6" -> {
			state = ObjectEditorState.SET_KEYWORDS;
			player.sendMessage("Enter keywords (space-separated):");
		}
		case "7" -> {
			state = ObjectEditorState.SET_EQUIPSLOT;

			String slots = Arrays.stream(EquipSlot.values())
					.map(Enum::name)
					.collect(Collectors.joining(", "));

			player.sendMessage("Choose from the following equip slots: " + slots);
			player.sendMessage("Enter new equip slot:");
		}

		case "8" -> {
			state = ObjectEditorState.SET_DURABILITY;
			player.sendMessage("Enter durability:");
		}
		case "9" -> {
			state = ObjectEditorState.SET_ITEMTYPE;

			String types = Arrays.stream(ObjectType.values())
					.map(Enum::name)
					.collect(Collectors.joining(", "));

			player.sendMessage("Choose from the following objectitem types: " + types);
			player.sendMessage("Enter objectitem type:");
		}
		case "10" -> {
			state = ObjectEditorState.TOGGLE_ITEMEFFECTS;
			showAllItemEffects();
			showItemEffects(object); // Show currently active effects also
		}
		case "11" -> {
			state = ObjectEditorState.SET_OBJVAL;
			player.sendMessage("Enter object value:");
		}
		case "12" -> {
			state = ObjectEditorState.SET_STATS;
			player.sendMessage("Enter bonus stats as STR STA AGI INT HP MP:");
		}

		case "13" -> {
			state = ObjectEditorState.ITEM_SPEC_VALS;
			
		}
		case "14" -> {
			state = ObjectEditorState.EDIT_BEHAVIOR_FLAGS;
			showBehaviorFlags();
		}
		case "15" -> {
			state = ObjectEditorState.SET_SPEECHES;
			player.sendMessage("Enter up to 3 speeches (pike (|) separated):");
		}

		case "16" -> { 

			state = ObjectEditorState.SET_INTELLIGENT;
			player.sendMessage("");
		}

		case "17" ->  { 

			state = ObjectEditorState.SET_VAMPIRIC;
			showVampiric();
		}
		case "18" ->  { 

			state = ObjectEditorState.SET_STACKABLE;
			showStackable();
		}

		case "19" -> {
			save();
			displayMainMenu();
		}
		case "20" -> {
			player.sendMessage("Exiting Object Editor.");
			player.setEditor(null);
		}

		default -> displayMainMenu();
		}
	}
	
	
	@SuppressWarnings("unused")
	private void handleSetItemSpecVal(String input) {

		
	    input = (input == null ? "" : input.trim());

	    // ---------------------------
	    // SHOW CURRENT VALUES
	    // ---------------------------
	    if (input.equalsIgnoreCase("show")) {
	        player.sendMessage("Current Spec Values:");

	        switch (object.getObjectType()) {

	            case WEAPON:
	                player.sendMessage("  DamageMin: " + object.getDiceCount());
	                player.sendMessage("  DamageMax: " + object.getDiceSides());
	                player.sendMessage("  DamageType: " + object.getDamageType());
	                break;

	            case ARMOR:
	                player.sendMessage("  ArmorType: " + object.getArmorType());
	                break;

	            case CONTAINER:
	                player.sendMessage("  MaxSize: " + object.getSize());
	                break;

	            case DRINK:
	                player.sendMessage("  MpRestore: " + object.getMpRestore());
	                break;

	            case FOOD:
	                player.sendMessage("  HpRestore: " + object.getHpRestore());
	                break;

	            case LIGHTSOURCE:
	                player.sendMessage("  Duration: " + object.getDuration());
	                break;

	            case POTION:
	            case SCROLL:
	            case STAFF:
	            case WAND:
	                List<String> sp = object.getSpells();
	                player.sendMessage("  Spells: " + 
	                    (sp == null || sp.isEmpty() ? "None" : String.join(", ", sp)));

	                if (object.getObjectType() == ObjectType.WAND || 
	                    object.getObjectType() == ObjectType.STAFF) {
	                    player.sendMessage("  Charges: " + object.getCharges());
	                }
	                break;

	            case COIN:
	                player.sendMessage("  Platinum: " + object.getPlatinum());
	                player.sendMessage("  Gold: " + object.getGold());
	                player.sendMessage("  Silver: " + object.getSilver());
	                player.sendMessage("  Copper: " + object.getCopper());
	                break;

	            default:
	                player.sendMessage("This object type has no special values.");
	                break;
	        }

	        state = ObjectEditorState.MAIN_MENU;
	        displayMainMenu();
	        return;
	    }

	    // ---------------------------
	    // PARSE INPUT
	    // ---------------------------
	    String[] parts = input.split("\\s+");
	    if (parts.length == 0) {
	        player.sendMessage("Enter SET values or 'show'.");
	        return;
	    }

	    try {

	        switch (object.getObjectType()) {

	            // ------------------------------------------
	            // WEAPON: dMin dMax damageType
	            // ------------------------------------------
	            case WEAPON: {
	                if (parts.length < 3) {
	                    player.sendMessage("Usage: <dCount> <dSides> <damageType>");
	                    break;
	                }

	                int dMin = Integer.parseInt(parts[0]);
	                int dMax = Integer.parseInt(parts[1]);
	                WeaponDamageType dmgType = WeaponDamageType.valueOf(parts[2].toUpperCase());

	                object.setDiceCount(dMin);
	                object.setDiceSides(dMax);
	                object.setDamageType(dmgType);

	                player.sendMessage("Weapon spec values updated.");
	                break;
	            }

	            // ------------------------------------------
	            // ARMOR: armorType
	            // ------------------------------------------
	            case ARMOR: {
	                if (parts.length < 1) {
	                    player.sendMessage("Usage: <armorType>");
	                    break;
	                }

	                object.setArmorType(ArmorType.fromString(parts[0]));
	                player.sendMessage("Armor type set.");
	                break;
	            }

	            // ------------------------------------------
	            // CONTAINER: size
	            // ------------------------------------------
	            case CONTAINER: {
	                int w = Integer.parseInt(parts[0]);
	                object.setSize(w);
	                player.sendMessage("Container size updated.");
	                break;
	            }

	            // ------------------------------------------
	            // DRINK: mpRestore
	            // ------------------------------------------
	            case DRINK: {
	                int mp = Integer.parseInt(parts[0]);
	                object.setMpRestore(mp);
	                player.sendMessage("Drink MP Restore updated.");
	                break;
	            }

	            // ------------------------------------------
	            // FOOD: hpRestore
	            // ------------------------------------------
	            case FOOD: {
	                int n = Integer.parseInt(parts[0]);
	                object.setHpRestore(n);
	                player.sendMessage("Food HP Restore set.");
	                break;
	            }

	            // ------------------------------------------
	            // LIGHTSOURCE: duration hours
	            // ------------------------------------------
	            case LIGHTSOURCE: {
	                int hours = Integer.parseInt(parts[0]);
	                object.setDuration(hours);
	                player.sendMessage("Light duration set.");
	                break;
	            }

	            // ------------------------------------------
	            // POTION: spell1 spell2 spell3 ...
	            // ------------------------------------------
	            case POTION: {
	                List<String> spells = Arrays.asList(parts);
	                object.setSpells(new ArrayList<>(spells));

	                player.sendMessage("Potion spells updated (" + spells.size() + ").");
	                break;
	            }

	            // ------------------------------------------
	            // SCROLL: up to 3 spells
	            // ------------------------------------------
	            case SCROLL: {
	                if (parts.length > 3) {
	                    player.sendMessage("Scroll may only contain up to 3 spells.");
	                    break;
	                }

	                List<String> spells = Arrays.asList(parts);
	                object.setSpells(new ArrayList<>(spells));

	                player.sendMessage("Scroll spells updated (" + spells.size() + ").");
	                break;
	            }

	            // ------------------------------------------
	            // STAFF / WAND: spell charges
	            // ------------------------------------------
	            case STAFF:
	            case WAND: {
	                if (parts.length < 2) {
	                    player.sendMessage("Usage: <spell> <charges>");
	                    break;
	                }

	                String spell = parts[0];
	                int charges = Integer.parseInt(parts[1]);

	                List<String> list = new ArrayList<>();
	                list.add(spell);
	                object.setSpells(list);

	                object.setCharges(charges);

	                player.sendMessage("Magic device updated.");
	                break;
	            }

	            // ------------------------------------------
	            // COIN: platinum gold silver copper
	            // ------------------------------------------
	            case COIN: {
	                if (parts.length < 4) {
	                    player.sendMessage("Usage: <platinum> <gold> <silver> <copper>");
	                    break;
	                }

	                object.setPlatinum(Integer.parseInt(parts[0]));
	                object.setGold(Integer.parseInt(parts[1]));
	                object.setSilver(Integer.parseInt(parts[2]));
	                object.setCopper(Integer.parseInt(parts[3]));

	                player.sendMessage("Coin values updated.");
	                break;
	            }

	            // ------------------------------------------
	            default:
	                player.sendMessage("This object type has no special values.");
	        }

	    } 
	    catch (Exception ex) {
	        player.sendMessage("Invalid input. Expected integers or valid enum names.");
	    }

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	

	private void handleSetObjectName(String input) {

		object.setName(input);
		player.sendMessage("Object name changed to: " + object.getName() + ".");

		state = ObjectEditorState.MAIN_MENU;
		displayMainMenu();
	}

	private void handleStackable(String input) {

		if (input == null || input.trim().isEmpty()) {
			showStackable();
			player.sendMessage("Enter a max stack size, or type 'off' to disable stackable:");
			return;
		}

		input = input.trim().toLowerCase();

		if (input.equals("off") || input.equals("no") || input.equals("1")) {
			object.setStackable(false);
			object.setMaxStackSize(1);
			object.setStackCount(1);
			player.sendMessage("Object is no longer stackable.");
		} else {
			try {
				int max = Integer.parseInt(input);
				if (max < 2) {
					player.sendMessage("Max stack must be 2 or higher.");
				} else {
					object.setStackable(true);
					object.setMaxStackSize(max);
					if (object.getStackCount() > max) {
						object.setStackCount(max);
					}
					player.sendMessage("Stackable enabled. Max stack size set to " + max + ".");
				}
			} catch (NumberFormatException e) {
				player.sendMessage("Invalid value. Enter a number or 'off'.");
			}
		}

		state = ObjectEditorState.MAIN_MENU;
		displayMainMenu();
	}


	private void handleVampiric(String input) {
		input = input.trim();


		if (input.isEmpty()) {
			showVampiric();
			player.sendMessage("Enter vampiric percent (0.0 - 1.0). Example: 0.25 = 25%.");
			return;
		}


		try {
			double newVamp = Double.parseDouble(input);
			if (newVamp < 0 || newVamp > 1) {
				player.sendMessage("Value must be between 0 and 1.");
				return;
			}


			object.setVampiric(newVamp > 0);
			object.setVampiricPercent(newVamp);


			player.sendMessage("Vampiric updated.");
			showVampiric();
		} catch (NumberFormatException e) {
			player.sendMessage("Invalid number. Use a decimal like 0.15.");
		}


		state = ObjectEditorState.MAIN_MENU;
		displayMainMenu();
	}

	private void handleIntelligent(String input) {
	    input = input.trim().toLowerCase();

	    showIntelligent();
	    
	    if (input.isEmpty()) {
	        player.sendMessage("Toggle intelligent ON/OFF, or set flat damage or damage type.");
	        player.sendMessage("Commands:");
	        player.sendMessage(" on — make object intelligent");
	        player.sendMessage(" off — remove intelligence");
	        player.sendMessage(" flat <number> — set flat damage");
	        player.sendMessage(" type <damageType> — set damage type (e.g., FIRE, ICE, SUMMON)");
	        player.sendMessage(" show — show current intelligent settings");
	        return;
	    }

	    if (input.equals("on")) {
	        object.setIntelligent(true);
	        player.sendMessage("Object is now intelligent.");

	    } else if (input.equals("off")) {
	        object.setIntelligent(false);
	        player.sendMessage("Object intelligence removed.");

	    } else if (input.startsWith("flat")) {
	        String[] parts = input.split(" ");
	        if (parts.length < 2) {
	            player.sendMessage("Usage: flat <number>");
	        } else {
	            try {
	                int dmg = Integer.parseInt(parts[1]);
	                object.setFlatDamage(dmg);
	                player.sendMessage("Flat damage set to " + dmg + ".");
	            } catch (NumberFormatException e) {
	                player.sendMessage("Invalid number for flat damage.");
	            }
	        }

	    } else if (input.startsWith("type")) {
	        String[] parts = input.split(" ");
	        if (parts.length < 2) {
	            player.sendMessage("Usage: type <damageType>");
	        } else {
	            try {
	                MagicDamageType dmgType = MagicDamageType.valueOf(parts[1].toUpperCase());
	                object.setIntDamType(dmgType);
	                player.sendMessage("Intelligent damage type set to " + dmgType + ".");
	            } catch (IllegalArgumentException e) {
	                player.sendMessage("Invalid damage type. Valid types: " + Arrays.toString(MagicDamageType.values()));
	            }
	        }

	    } else if (input.equals("show")) {
	        showIntelligent();

	    } else {
	        player.sendMessage("Unknown intelligent command.");
	    }

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	private void showIntelligent() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("Intelligent Settings:\n");
	    sb.append(" Enabled: ").append(object.isIntelligent()).append("\n");
	    sb.append(" Flat Damage: ").append(object.getFlatDamage()).append("\n");
	    sb.append(" Magic Damage Type: ").append(object.getIntDamType()).append("\n");
	    player.sendMessage(sb.toString());
	   // return sb.toString();
	}


	private void showObjectInfo() {
		player.sendMessage("\n--- Object Info ---");
		player.sendMessage("ObjID: " + object.getObjID());
		player.sendMessage("Name: " + object.getName());
		player.sendMessage("Short Desc: " + object.getShortDescription());
		player.sendMessage("Long Desc:" + object.getLongDescription());
		player.sendMessage("Extended Desc:" + object.getExtDescription());
		player.sendMessage("Keywords: " + object.getKeywords());
		player.sendMessage("EquipSlot: " + object.getEquipSlot());
		player.sendMessage("Durability: " + object.getDurability());
		player.sendMessage("ItemType: " + object.getType());
		player.sendMessage("ItemEffects: " + object.getEffects());
		player.sendMessage("Behaviors: Sapient: " + object.isSapient() + "  Intelligent: " + object.isIntelligent() + "  Vampiric: " + object.isVampiric() +  "  Vorpal: " + object.isVorpal() + "  Stackable: " + object.isStackable());
		player.sendMessage("Object Value: " + object.getValuePlatinum() + ", " + object.getValueGold()+ ", " + object.getValueSilver() + ", " + object.getValueCopper() +  " coins.");
		player.sendMessage("Bonus Stats: STR=" + object.getStrengthBonus() + ", STA=" + object.getStaminaBonus()
		+ ", AGI=" + object.getAgilityBonus() + ", INT=" + object.getIntellectBonus() + ", HP Bonus=" +  object.getHpBonus() + ", MP Bonus=" + object.getMpBonus());


		player.sendMessage("ItemType Specific Vals for Type: " + object.getType().name());
		{
			// TODO
			ObjectType otype = object.getType();
			switch (otype) {

			case NONE: {
				// none ?
				player.sendMessage("None");
				break;
			}
			case WEAPON: {
				player.sendMessage("Weapon Type: " +
						(object.getWeaponType() != null ? object.getWeaponType().name() : "None"));

				player.sendMessage("Damage Type: " + object.getDamageType().name());
				player.sendMessage("Dice Number (x): " + object.getDiceCount());
				player.sendMessage("Dice Sides (y): " + object.getDiceSides());
				player.sendMessage("Bonus Damage: " + object.getDamageBonus());
				player.sendMessage("Weapon Damage: "+ object.getDamageDiceString() + "+" + object.getDamageBonus());
				break;
			}
			case ARMOR: {
				player.sendMessage("Armor Type: " + object.getArmorType().name());
				player.sendMessage("Defense Bonus: " + object.getDefenseBonus());
				break;
			}
			case LIGHTSOURCE: {
				player.sendMessage("Duration: " + object.getDuration());
				break;
			}
			case FOOD: {
				player.sendMessage("HP Restore: " + object.getHpRestore());
				break;
			}
			case DRINK: {
				player.sendMessage("MP Restore: " + object.getMpRestore());
				break;
			}
			case POTION: {
				// Charges/spells
				player.sendMessage("Spells: " + (object.getSpells() == null ? 0 : object.getSpells().size()));
				player.sendMessage("spellLevel: " + object.getSpellLvl());
				break;
			}
			case SCROLL: {
				player.sendMessage("Spells: " + (object.getSpells() == null ? 0 : object.getSpells().size()));
				player.sendMessage("spellLevel: " + object.getSpellLvl());
				break;
			}
			case WAND: {
				player.sendMessage("Max Charges: " + object.getMaxCharges());
				player.sendMessage("Spells: " + (object.getSpells() == null ? 0 : object.getSpells().size()));
				player.sendMessage("Spell Level: " + object.getSpellLvl());
				break;
			}
			case STAFF: {
				player.sendMessage("MaxCharges: " + object.getMaxCharges());
				player.sendMessage("Spells: " + (object.getSpells() == null ? 0 : object.getSpells().size()));
				player.sendMessage("spellLevel: " + object.getSpellLvl());
				break;
			}
			case TREASURE: {
				player.sendMessage("None");
				break;
			}
			case COIN: {
				player.sendMessage("Platinium coins: " + object.getPlatinumValue());
				player.sendMessage("Gold coins: " + object.getGoldValue());
				player.sendMessage("Silver coins: " + object.getSilverValue());
				player.sendMessage("Copper coins: " + object.getCopperValue());
				break;
			}
			case TRASH: {
				player.sendMessage("None");
				break;
			}
			case CONTAINER: {
				player.sendMessage("Lockable: " + object.isLockable());
				player.sendMessage("Locked: " + object.isLocked());
				player.sendMessage("Key: " + object.getKeyNum());
				player.sendMessage("Closed: " + object.isClosed());
				player.sendMessage("Container Size: " + object.getContents().size());
				break;
			}
			case SIGN: {
				// none?
				player.sendMessage("None");
				break;
			}
			case BOOK: { 
				// none?
				player.sendMessage("None");
				break;
			}
			case PART: {
				// TODO not yet developed
				// masterObject
				// firstPart
				break;
			}
			case KEY: {
				player.sendMessage("Key Uses: " + object.getKeyUses());
				break;
			}
			case BOAT: {
				player.sendMessage("None");
				break;
			}
			case CONTROLLER: {
				// TODO, todo not yet developed
				// roomID
				// exit dir
				// controller type
				break;
			}
			case TRAP: {
				// TODO, not yet developed
				// trapType // fire, acid, ice, electricity, sleep, poison, death... (allow multiple)
				// trapLevel
				break;
			}



			default: {
				//	none?
				player.sendMessage("None");
				break;
			}		
			}
		}

		player.sendMessage("Affects: Blessed: " + object.isBlessed() + "  Cursed: " + object.isCursed() + "  Magic:" + object.isMagic() + "  Humming: " + object.isHumming() + "  Poisoned: " + object.isPoisoned() + "  Burning: " + object.isBurning());

		if (object.isSapient()) {
			player.sendMessage("Sapient Speeches:");
			for (String speech :object.getSapientSpeeches()) {
				player.sendMessage(" - " + speech);
			}
		}

		if (object.isIntelligent()) {
			player.sendMessage(null);
		}

		if (object.getEffects().isEmpty()) {
			player.sendMessage("ItemEffects: None");
		} else {
			String effectNames = object.getEffects().stream()
					.map(ItemEffect::getDisplayName)
					.collect(Collectors.joining(", "));
			player.sendMessage("ItemEffects: " + effectNames);
		}


	} // end showObjectInfo

	

	private void handleSetObjVal(String input) {

	    if (input == null || input.trim().isEmpty()) {
	        player.sendMessage("Usage: show | PLAT GOLD SILVER COPPER | <valueName> <amount>");
	        return;
	    }

	    input = input.trim();

	    // SHOW CURRENT COIN VALUES
	    if (input.equalsIgnoreCase("show")) {
	        player.sendMessage(showObjValue());
	        return;
	    }

	    // Normalize separators
	    input = input.replace(",", " ");
	    String[] parts = input.split("\\s+");

	    // SINGLE VALUE ADJUST (gold +1)
	    if (parts.length == 2) {

	        String which = parts[0].toLowerCase();
	        int amount;

	        try {
	            amount = Integer.parseInt(parts[1]);
	        } catch (NumberFormatException e) {
	            player.sendMessage("Invalid number: " + parts[1]);
	            return;
	        }

	        switch (which) {
	            case "plat", "platinum" -> object.setValuePlatinum(object.getValuePlatinum() + amount);
	            case "gold"             -> object.setValueGold(object.getValueGold() + amount);
	            case "silver"           -> object.setValueSilver(object.getValueSilver() + amount);
	            case "copper"           -> object.setValueCopper(object.getValueCopper() + amount);
	            default -> {
	                player.sendMessage("Unknown coin type: " + which);
	                return;
	            }
	        }

	        player.sendMessage("Updated " + which.toUpperCase() + " by " + amount + ".");
	        state = ObjectEditorState.MAIN_MENU;
	        displayMainMenu();
	        return;
	    }

	    // MULTI-VALUE PLAT GOLD SILVER COPPER
	    if (parts.length >= 1 && parts.length <= 4) {

	        int plat = 0, gold = 0, silver = 0, copper = 0;

	        try {
	            plat   = Integer.parseInt(parts[0]);
	            if (parts.length > 1) gold   = Integer.parseInt(parts[1]);
	            if (parts.length > 2) silver = Integer.parseInt(parts[2]);
	            if (parts.length > 3) copper = Integer.parseInt(parts[3]);
	        } catch (NumberFormatException e) {
	            player.sendMessage("Invalid coin list. Use: PLAT GOLD SILVER COPPER");
	            return;
	        }

	        object.setValuePlatinum(plat);
	        object.setValueGold(gold);
	        object.setValueSilver(silver);
	        object.setValueCopper(copper);

	        player.sendMessage("Coin values updated.\n" + showObjValue());

	        state = ObjectEditorState.MAIN_MENU;
	        displayMainMenu();
	        return;
	    }

	    // INVALID FORMAT
	    player.sendMessage("Invalid format. Use: show | PLAT GOLD SILVER COPPER | <type> <value>");
	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}
	
	private String showObjValue() {
	    return "Current Coin Values:\n"
	            + " Platinum: " + object.getValuePlatinum() + "\n"
	            + " Gold:     " + object.getValueGold() + "\n"
	            + " Silver:   " + object.getValueSilver() + "\n"
	            + " Copper:   " + object.getValueCopper() + "\n";
	}


	private void handleSetBehaviorFlags(String input) {

	    if (input == null || input.trim().isEmpty()) {
	        player.sendMessage("No flags provided.");
	        state = ObjectEditorState.MAIN_MENU;
	        displayMainMenu();
	        return; // FIXED
	    }

	    String[] parts = input.trim().split("\\s+");
	    List<String> updatedFlags = new ArrayList<>();
	    List<String> invalidFlags = new ArrayList<>();

	    for (String raw : parts) {
	        boolean isRemove = raw.startsWith("!");
	        String flag = isRemove ? raw.substring(1).trim().toLowerCase() : raw.trim().toLowerCase();

	        switch (flag) {
	            case "sapient" -> {
	                object.setSapient(!isRemove);
	                updatedFlags.add((isRemove ? "Removed " : "Set ") + "Sapient");
	            }
	            case "intelligent" -> {
	                object.setIntelligent(!isRemove);
	                updatedFlags.add((isRemove ? "Removed " : "Set ") + "Intelligent");
	            }
	            case "vampiric" -> {
	                object.setVampiric(!isRemove);
	                updatedFlags.add((isRemove ? "Removed " : "Set ") + "Vampiric");
	            }
	            case "vorpal" -> {
	                object.setVorpal(!isRemove);
	                updatedFlags.add((isRemove ? "Removed " : "Set ") + "Vorpal");
	            }
	            case "stackable" -> {
	                object.setStackable(!isRemove);
	                updatedFlags.add((isRemove ? "Removed " : "Set ") + "Stackable");
	            }
	            default -> invalidFlags.add("Invalid flag: " + raw);
	        }
	    }

	    if (!updatedFlags.isEmpty()) player.sendMessage(String.join(", ", updatedFlags));
	    if (!invalidFlags.isEmpty()) player.sendMessage(String.join("\n", invalidFlags));

	    player.sendMessage("Current Behavior Flags: "
	            + "Sapient=" + object.isSapient()
	            + ", Intelligent=" + object.isIntelligent()
	            + ", Vampiric=" + object.isVampiric()
	            + ", Vorpal=" + object.isVorpal()
	            + ", Stackable=" + object.isStackable());

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}



	private void handleToggleItemEffects(String arg) {

	    // Always show options first
	    showAllItemEffects();
	    showItemEffects(object);

	    if (arg == null || arg.trim().isEmpty()) {
	        player.sendMessage("Toggle which effect? (type a name, number, or !effect)");
	        return;
	    }

	    String input = arg.trim();
	    boolean forceRemove = false;

	    if (input.startsWith("!")) {
	        forceRemove = true;
	        input = input.substring(1).trim();
	    }

	    ItemEffect matched = null;

	    // NUMERIC
	    if (input.matches("\\d+")) {
	        int index = Integer.parseInt(input);
	        ItemEffect[] values = ItemEffect.values();
	        if (index >= 1 && index <= values.length) {
	            matched = values[index - 1];
	        } else {
	            player.sendMessage("Invalid effect number: " + input);
	            return;
	        }
	    } else {

	        try {
	            matched = ItemEffect.valueOf(input.toUpperCase());
	        } catch (IllegalArgumentException ignored) {}

	        if (matched == null) {
	            String u = input.toUpperCase();
	            for (ItemEffect e : ItemEffect.values()) {
	                if (e.name().startsWith(u)) {
	                    matched = e;
	                    break;
	                }
	            }
	        }
	    }

	    if (matched == null) {
	        player.sendMessage("No such ItemEffect: " + arg);
	        return;
	    }

	    // FORCE REMOVE (!effect)
	    if (forceRemove) {
	        if (object.getEffects().remove(matched)) {
	            player.sendMessage("Removed effect: " + matched.name());
	        } else {
	            player.sendMessage("Effect was not present: " + matched.name());
	        }
	        showItemEffects(object);
	        state = ObjectEditorState.MAIN_MENU;
	        displayMainMenu();
	        return;
	    }

	    // NORMAL TOGGLE
	    if (object.getEffects().contains(matched)) {
	        object.getEffects().remove(matched);
	        player.sendMessage("Removed effect: " + matched.name());
	    } else {
	        object.getEffects().add(matched);
	        player.sendMessage("Added effect: " + matched.name());
	    }

	    showItemEffects(object);
	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}


	private void handleSetItemType(String input) {
	    try {
	        ObjectType type = ObjectType.valueOf(input.toUpperCase());
	        object.setType(type);
	        player.sendMessage("Object type set to " + type.name());
	    } catch (Exception e) {
	        player.sendMessage("Invalid object type.");
	    }
	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	private void handleSetDurability(String input) {

	    try {
	        int dura = Integer.parseInt(input);
	        object.setDurability(dura);
	        object.setMaxDurability(dura);
	        player.sendMessage("Durability set to: " + object.getMaxDurability());
	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid durability value.");
	    }

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	private void handleSetEquipSlot(String input) {

	    List<EquipSlot> current = object.getEquipSlot();
	    if (current == null) {
	        current = new ArrayList<>();
	        object.setEquipSlot(current);
	    }

	    String[] parts = input.split(",");

	    List<String> added = new ArrayList<>();
	    List<String> removed = new ArrayList<>();
	    List<String> invalid = new ArrayList<>();

	    for (String raw : parts) {

	        String part = raw.trim();
	        if (part.isEmpty()) continue;

	        boolean isRemove = part.startsWith("!");
	        String slotName = isRemove ? part.substring(1).trim()
	                                   : part;

	        if (slotName.isEmpty()) {
	            invalid.add("Invalid slot: " + part);
	            continue;
	        }

	        EquipSlot slot;
	        try {
	            slot = EquipSlot.valueOf(slotName.toUpperCase());
	        } catch (Exception e) {
	            invalid.add("Invalid slot: " + part);
	            continue;
	        }

	        if (isRemove) {
	            if (current.remove(slot)) {
	                removed.add(slot.name());
	            } else {
	                invalid.add("Cannot remove (not present): " + slot.name());
	            }
	        } else {
	            if (!current.contains(slot)) {
	                current.add(slot);
	                added.add(slot.name());
	            }
	        }
	    }

	    if (!added.isEmpty())
	        player.sendMessage("Added slots: " + String.join(", ", added));

	    if (!removed.isEmpty())
	        player.sendMessage("Removed slots: " + String.join(", ", removed));

	    if (!invalid.isEmpty())
	        player.sendMessage(String.join("\n", invalid));

	    player.sendMessage("Current Equip Slots: " +
	            current.stream().map(Enum::name).collect(Collectors.joining(", ")));

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}


	private void handleSpeeches(String input) {
	    List<String> list = Arrays.stream(input.split("\\|"))
	            .map(String::trim).filter(s -> !s.isEmpty()).toList();
	    object.setSapientSpeeches(list);
	    player.sendMessage("Speeches updated.");

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	private void handleSetKeywords(String input) {
	    if (input == null || input.trim().isEmpty()) {
	        object.setKeywords();
	        player.sendMessage("Keywords cleared.");
	    } else {
	        String[] keywords = Arrays.stream(input.trim().split("\\s+"))
	                .map(String::trim)
	                .filter(s -> !s.isEmpty())
	                .toArray(String[]::new);

	        object.setKeywords(keywords);
	        player.sendMessage("Keywords set to: " + String.join(", ", keywords));
	    }

	    state = ObjectEditorState.MAIN_MENU;
	    displayMainMenu();
	}

	private void handleSetStats(String input) {

		if (input == null || input.trim().isEmpty()) {
			player.sendMessage("Usage: show | STR STA AGI INT CHA HP MP | <stat> <value>");
			return;
		}

		input = input.trim();

		// ----------------------------
		// SHOW CURRENT STATS
		// ----------------------------
		if (input.equalsIgnoreCase("show")) {
			player.sendMessage(showStats());
			return;
		}

		String[] parts = input.split("\\s+");

		// -------------------------------------------------------
		// SINGLE-STAT ADJUST FORMAT (e.g., "str +1", "hp -5")
		// -------------------------------------------------------
		if (parts.length == 2) {
			String stat = parts[0].toLowerCase();
			int amount;

			try {
				amount = Integer.parseInt(parts[1]);
			} catch (NumberFormatException e) {
				player.sendMessage("Invalid value: " + parts[1]);
				return;
			}

			switch (stat) {
			case "str":
				object.setStrengthBonus(object.getStrengthBonus() + amount);
				break;
			case "sta":
				object.setStaminaBonus(object.getStaminaBonus() + amount);
				break;
			case "agi":
				object.setAgilityBonus(object.getAgilityBonus() + amount);
				break;
			case "int":
				object.setIntellectBonus(object.getIntellectBonus() + amount);
				break;
			case "cha":
				object.setCharismaBonus(object.getCharismaBonus() + amount);
				break;
			case "hp":
				object.setHpBonus(object.getHpBonus() + amount);
				break;
			case "mp":
				object.setMpBonus(object.getMpBonus() + amount);
				break;
			default:
				player.sendMessage("Unknown stat: " + stat);
				return;
			}

			player.sendMessage("Updated " + stat.toUpperCase() + " by " + amount + ".");
			state = ObjectEditorState.MAIN_MENU;
			displayMainMenu();
			return;
		}

		// -------------------------------------------------------
		// BULK FORMAT: STR STA AGI INT CHA HP MP
		// -------------------------------------------------------
		if (parts.length == 7) {
			try {
				int str  = Integer.parseInt(parts[0]);
				int sta  = Integer.parseInt(parts[1]);
				int agi  = Integer.parseInt(parts[2]);
				int intl = Integer.parseInt(parts[3]);
				int cha = Integer.parseInt(parts[4]);
				int hpb  = Integer.parseInt(parts[5]);
				int mpb  = Integer.parseInt(parts[6]);


				object.setStrengthBonus(str);
				object.setStaminaBonus(sta);
				object.setAgilityBonus(agi);
				object.setIntellectBonus(intl);
				object.setCharismaBonus(cha);
				object.setHpBonus(hpb);
				object.setMpBonus(mpb);

				player.sendMessage("Stats updated (bulk set).");
				showStats();
			} catch (NumberFormatException e) {
				player.sendMessage("Invalid input. Use six integers: STR STA AGI INT HP MP");
				return;
			}

			state = ObjectEditorState.MAIN_MENU;
			displayMainMenu();
			return;
		}

		// -------------------------------------------------------
		// INVALID FORMAT
		// -------------------------------------------------------
		player.sendMessage("Invalid format. Use: show | STR STA AGI INT HP MP | <stat> <value>");
		state = ObjectEditorState.MAIN_MENU;
		displayMainMenu();
	}


	
	
	
	
	
	private void showItemEffects(ObjectItem object) {
		EnumSet<ItemEffect> effectsSet = object.getEffects();
		if (effectsSet == null || effectsSet.isEmpty()) {
			player.sendMessage("ItemEffects: (none)");
			return;
		}

		StringBuilder sb = new StringBuilder();
		for (ItemEffect e : effectsSet) {
			if (e != null) {
				sb.append(e.name()).append(" ");
			}
		}
		player.sendMessage("ItemEffects: " + sb.toString().trim());
	}


	private void showAllItemEffects() {
		StringBuilder sb = new StringBuilder();
		sb.append("Available ItemEffects:\n");

		int i = 1;
		for (ItemEffect e : ItemEffect.values()) {
			sb.append("  ").append(i++).append(") ").append(e.name()).append("\n");
		}

		player.sendMessage(sb.toString());
	}


	private void showStackable() {
		boolean isStackable = object.isStackable();

		player.sendMessage("Stackable: " + (isStackable ? "Yes" : "No"));

		// If your object supports stack counts:
		try {
			player.sendMessage("Current Stack Count: " + object.getStackCount());
			player.sendMessage("Max Stack Size: " + object.getMaxStackSize());

			player.sendMessage("Please enter new Max Stack Size (Enter 'no' or '1' for Not Stackable)");
		} catch (Exception e) {
			// Silently ignore if those fields do not exist
		}
	}


	private void showVampiric() {
		player.sendMessage("Please enter a new Vampiric Percent (setting to 0.0 will disable Vampiric item)");

		player.sendMessage("Vampiric: " + object.isVampiric());
		player.sendMessage("Vampiric Percent: " + object.getVampiricPercent());
	}




	private void showBehaviorFlags() {
		player.sendMessage("Please provide new behavior flags: <flag1> <flag2> !<flag>.");
		player.sendMessage("Using the '!' will remove (mark as false) the flag.");
		player.sendMessage("Current Behavior Flags: " +
				"Sapient=" + object.isSapient() +
				", Intelligent=" + object.isIntelligent() +
				", Vampiric=" + object.isVampiric() +
				", Vorpal=" + object.isVorpal() +
				", Stackable=" + object.isStackable());
	}
	
	// -----------------------------------------------------------
	// Helper: Show full stat block
	// -----------------------------------------------------------
	private String showStats() {
		StringBuilder sb = new StringBuilder();
		sb.append("Current Stat Bonuses:\n");
		sb.append(" STR: ").append(object.getStrengthBonus()).append("\n");
		sb.append(" STA: ").append(object.getStaminaBonus()).append("\n");
		sb.append(" AGI: ").append(object.getAgilityBonus()).append("\n");
		sb.append(" INT: ").append(object.getIntellectBonus()).append("\n");
		sb.append(" CHA: ").append(object.getCharismaBonus()).append("\n");
		sb.append(" HP Bonus: ").append(object.getHpBonus()).append("\n");
		sb.append(" MP Bonus: ").append(object.getMpBonus()).append("\n");
		player.sendMessage(sb.toString());
		return sb.toString();
	}


	@Override
	public boolean save() {
		try {
			File objectFile = new File(Config.OBJECTS_DIR, object.getObjID() + ".Object.txt");

			try (FileWriter writer = new FileWriter(objectFile)) {

				// Header
				writer.write("Object:" + System.lineSeparator());
				writer.write("  ObjectID: " + object.getObjID() + System.lineSeparator());
				writer.write("  Name: " + (object.getName() == null ? "" : object.getName()) + System.lineSeparator());
				writer.write("  Short Description: " + (object.getShortDescription() == null ? "" : object.getShortDescription()) + System.lineSeparator());
				writer.write("  Long Description: " + (object.getLongDescription() == null ? "" : object.getLongDescription()) + System.lineSeparator());
				writer.write("  Extended Description: " + (object.getExtDescription() == null ? "" : object.getExtDescription()) + System.lineSeparator());

				// Keywords (space-separated)
				String keywords = String.join(" ", object.getKeywords());
				writer.write("  Keywords: " + keywords + System.lineSeparator());

				// Equip slots (space-separated)
				List<EquipSlot> equipSlotsList = object.getEquipSlot();
				String equipSlots = "";

				if (equipSlotsList != null && !equipSlotsList.isEmpty()) {
					// Join all slot names with spaces
					equipSlots = equipSlotsList.stream()
							.map(Enum::name)   // or .getDisplayName() if you prefer
							.collect(Collectors.joining(" "));
				}

				writer.write("  EquipSlots: " + equipSlots + System.lineSeparator());


				// Durability
				writer.write("  Durability: " + object.getDurability() + " / " + object.getMaxDurability() + System.lineSeparator());

				// Value (platinum, gold, silver, copper)
				writer.write("  Value: " + object.getValuePlatinum() + ", " + object.getValueGold() + ", " + object.getValueSilver() + ", " + object.getValueCopper() + System.lineSeparator());

				// Item effects
				String effects = "";
				try {
					effects = object.getEffects().stream().map(Enum::name).reduce((a, b) -> a + ", " + b).orElse("");
				} catch (Exception e) {
				}
				writer.write("  ItemEffects: " + effects + System.lineSeparator());
				writer.write(System.lineSeparator());

				// ItemType block
				writer.write("  ItemType: " + (object.getObjectType() == null ? "NONE" : object.getObjectType().name()) + System.lineSeparator());

				// Weapon specific
				writer.write("    WeaponType: " + (object.getWeaponType() == null ? "" : object.getWeaponType().name()) + System.lineSeparator());
				writer.write("    WeaponDamageType: " + (object.getDamageType() == null ? "" : object.getDamageType().name()) + System.lineSeparator());
				writer.write("      diceCount: " + object.getDiceCount() + System.lineSeparator());
				writer.write("      diceSides: " + object.getDiceSides() + System.lineSeparator());
				writer.write("      damageBonus: " + object.getDamageBonus() + System.lineSeparator());

				// Armor specific
				writer.write("    ArmorType: " + (object.getArmorType() == null ? "" : object.getArmorType().name()) + System.lineSeparator());

				// Stats
				writer.write("    Stats: " + System.lineSeparator());
				writer.write("      StrengthBonus: " + object.getStrengthBonus() + System.lineSeparator());
				writer.write("      StaminaBonus: " + object.getStaminaBonus() + System.lineSeparator());
				writer.write("      IntellectBonus: " + object.getIntellectBonus() + System.lineSeparator());
				writer.write("      AgilityBonus: " + object.getAgilityBonus() + System.lineSeparator());
				writer.write("      CharismaBonus: " + object.getCharismaBonus() + System.lineSeparator());
				writer.write("      hitrollBonus: " + object.getHitrollBonus() + System.lineSeparator());
				writer.write("      damrollBonus: " + object.getDamrollBonus() + System.lineSeparator());
				writer.write("      hpBonus: " + object.getHpBonus() + System.lineSeparator());
				writer.write("      mpBonus: " + object.getMpBonus() + System.lineSeparator());

				// Weapon flags
				writer.write("    Vorpal: " + object.isVorpal() + System.lineSeparator());
				writer.write("    Poisoned: " + object.isPoisoned() + System.lineSeparator());
				writer.write("    Intelligent: " + object.isIntelligent() + System.lineSeparator());
				// fields not present in ObjectItem: TargetMsg, AttackerMsg, RoomMsg -> leave 

				writer.write("      flatDamage: " + object.getFlatDamage() + System.lineSeparator());
				writer.write("      IntDamType: " + object.getIntDamType() + System.lineSeparator());

				writer.write("    Vampiric: " + object.isVampiric() + System.lineSeparator());
				writer.write("      vampiricPercent: " + object.getVampiricPercent() + System.lineSeparator());

				// Sapient
				writer.write("    Sapient: " + object.isSapient() + System.lineSeparator());
				String speeches = String.join("|", object.getSapientSpeeches());
				writer.write("      sapientSpeeches: " + speeches + System.lineSeparator());

				// Stackable
				writer.write("    Stackable: " + object.isStackable() + System.lineSeparator());
				writer.write("      StackCount: " + object.getStackCount() + System.lineSeparator());
				writer.write("      StackSize: " + object.getStackSize() + System.lineSeparator());
				writer.write("      maxStackSize: " + object.getMaxStackSize() + System.lineSeparator());

				// Container
				writer.write("    Container: " + object.isContainer() + System.lineSeparator());
				writer.write("      size: " + (object.getContents() == null ? 0 : object.getContents().size()) + System.lineSeparator());
				writer.write("      lockable: " + object.isLockable() + System.lineSeparator());
				writer.write("      locked: " + object.isLocked() + System.lineSeparator());
				writer.write("      closed: " + object.isClosed() + System.lineSeparator());

				// Charges/spells
				writer.write("    Charges: " + object.getCharges() + System.lineSeparator());
				writer.write("    MaxCharges: " + object.getMaxCharges() + System.lineSeparator());
				writer.write("    Spells: " + (object.getSpells() == null ? 0 : object.getSpells().toString()) + System.lineSeparator());
				writer.write("    spellLevel: " + object.getSpellLvl() + System.lineSeparator());

				// Consumables
				writer.write("    HPRestore: " + object.getHpRestore() + System.lineSeparator());
				writer.write("    MPRestore: " + object.getMpRestore() + System.lineSeparator());

				// Light duration (not modeled on ObjectItem)
				writer.write("    Duration: " + object.getDuration() + System.lineSeparator());

				// parts
				writer.write("    AssemblesInto: " + object.getAssemblesInto() + System.lineSeparator());
				writer.write("    AssemblyRoot: " + object.getAssemblyRoot() + System.lineSeparator());
				
				
				// TODO expand for more objectitem fields

				writer.write(System.lineSeparator());

				// Optionally write contained objects' IDs for reference
				if (object.getContents() != null && !object.getContents().isEmpty()) {
					writer.write("  Contents:" + System.lineSeparator());
					for (ObjectItem child : object.getContents()) {
						writer.write("    - ObjectID: " + child.getObjID() + " Name: " + (child.getName() == null ? "" : child.getName()) + System.lineSeparator());
					}
				}

			}
			WorldManager.registerObj(object);
			System.out.println("✅ Object saved: " + objectFile.getName());
			return true;
		} catch (IOException e) {
			System.err.println("❌ Failed to save ObjectItem: " + object.getObjID());
			e.printStackTrace();
			return false;
		}
	}
	// end ObjectEditor.save() // follows template format

	
	

	@Override public void showMenu() { displayMainMenu(); }
	//   @Override public boolean save() { doSave(); return true; }
	@Override public String getEditorName() { return "ObjectEditor for obj " + object.getObjID(); }
	@Override public void tick() {}
	@Override public boolean isFinished() { return finished; }
	@Override public void stopEditing() {finished = true;}

} // end ObjectEditor

