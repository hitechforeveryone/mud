package mud.editor;

import java.util.*;

import mud.core.*;

public class HelpEditor implements Editor {
    private HelpEntry entry;
    private Player player;
    
    public HelpEditor(String keyword, Player player) {
        this.entry = new HelpEntry(keyword, "", "");
        this.player = player;
    }

    public HelpEditor(HelpEntry entry, Player player) {
        this.entry = entry;
        this.player = player;
    }

    public String showMenu(Player player) {
        return String.format("""
            \u001B[1mHelp Editor - %s\u001B[0m
            1) Title: %s
            2) Body: %s
            3) Aliases: %s
            4) Save and Exit
            5) Cancel
            Enter choice:
            """,
            entry.getKeyword(),
            entry.getTitle().isEmpty() ? "(none)" : entry.getTitle(),
            summarize(entry.getBody()),
            entry.getAliases().isEmpty() ? "(none)" : String.join(", ", entry.getAliases())
        );
    }


    public void handleInput(Player player, String input) {
        switch (input.trim()) {
            case "1" -> player.setEditor(new HelpEditorFieldEditor(this, 1, player));
            case "2" -> player.setEditor(new HelpEditorFieldEditor(this, 2, player));
            case "3" -> player.setEditor(new HelpEditorFieldEditor(this, 3, player));
            case "4" -> {
                HelpManager.addHelpEntry(entry);
                HelpManager.saveAllToDisk();
                if (save()) {
                    player.sendMessage("Help entry saved.");
                } else {
                    player.sendMessage("Failed to save help entry.");
                }
                player.setEditor(null);
            }
            case "5" -> {
                player.sendMessage("Help editing canceled.");
                player.setEditor(null);
            }
            default -> player.sendMessage("Invalid choice. Enter 1-5.");
        }
    }

    public void onCancel(Player player) {
        player.sendMessage("Help editing canceled.");
    }

    private String summarize(String text) {
        return text.length() <= 40 ? text : text.substring(0, 37) + "...";
    }

    // Allow field editing in a simple sub-editor
    public void setField(int fieldNumber, String value) {
        switch (fieldNumber) {
            case 1 -> entry = new HelpEntry(entry.getKeyword(), value, entry.getBody());
            case 2 -> entry = new HelpEntry(entry.getKeyword(), entry.getTitle(), value);
            case 3 -> {
                entry.getAliases().clear();
                for (String alias : value.split(",")) {
                    entry.addAlias(alias.trim());
                }
            }
        }
    }

    public HelpEntry getEntry() {
        return entry;
    }

	@Override
	public void startEditing() {
	    player.sendMessage(showMenu(player));
		
	}

	@Override
	public void stopEditing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleInput(String input) {
	    switch (input.trim()) {
	        case "1" -> player.setEditor(new HelpEditorFieldEditor(this, 1, player));
	        case "2" -> player.setEditor(new HelpEditorFieldEditor(this, 2, player));
	        case "3" -> player.setEditor(new HelpEditorFieldEditor(this, 3, player));
	        case "4" -> {
	            HelpManager.addHelpEntry(entry);
	            HelpManager.saveAllToDisk();
	            player.sendMessage("Help entry saved.");
	            player.setEditor(null);
	        }
	        case "5" -> {
	            player.sendMessage("Help editing canceled.");
	            player.setEditor(null);
	        }
	        default -> player.sendMessage("Invalid choice. Enter 1-5.");
	    }
	}


	@Override
	public boolean save() {
	    HelpManager.addHelpEntry(entry); // In case it's new
	    HelpManager.saveEntryToDisk(entry);
	    return true;
	}


	@Override
	public String getEditorName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void showMenu() {
	    player.sendMessage(String.format("""
	        \u001B[1mHelp Editor - %s\u001B[0m
	        1) Title: %s
	        2) Body: %s
	        3) Aliases: %s
	        4) Save and Exit
	        5) Cancel
	        Enter choice:
	        """,
	        entry.getKeyword(),
	        entry.getTitle().isEmpty() ? "(none)" : entry.getTitle(),
	        summarize(entry.getBody()),
	        entry.getAliases().isEmpty() ? "(none)" : String.join(", ", entry.getAliases())
	    ));
	}

	public List<String> getBodyLines() {
	    String body = entry.getBody();
	    if (body.isEmpty()) return new ArrayList<>();
	    return new ArrayList<>(Arrays.asList(body.split("\n")));
	}


	public void setBodyLines(List<String> lines) {
	    entry = new HelpEntry(entry.getKeyword(), entry.getTitle(), String.join("\n", lines));
	}

	
} // end HelpEditor
