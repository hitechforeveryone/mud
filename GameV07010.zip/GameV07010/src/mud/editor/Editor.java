package mud.editor;

public interface Editor {
	
    void startEditing();
    void stopEditing();
    
    void handleInput(String input);
    void showMenu();
    boolean save();  // Returns true if save was successful
    String getEditorName(); // For messaging/logging
    void tick(); // optional
    boolean isFinished(); // <-- must be defined here
}
