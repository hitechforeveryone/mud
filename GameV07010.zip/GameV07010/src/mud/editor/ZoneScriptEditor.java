package mud.editor;

import mud.config.Config;
import mud.core.*;
import mud.scripting.*;


import java.io.*;
import java.util.*;

public class ZoneScriptEditor implements Editor {

	private final int zoneId;
	private final Player player;
	private final BasicZoneScript zoneScript;
	private boolean finished = false;
	private ZoneScriptEditorState state = ZoneScriptEditorState.MAIN_MENU;

	private int editingRoomId = -1;
	private String editingDoorDirection = null;

	private int pendingMobId = -1;
	private int pendingObjectId = -1;
	private int pendingContainerObjectId = -1;
	@SuppressWarnings("unused")
	private double pendingChance = 0.0;
	private EquipSlot pendingEquipSlot = null;


	public ZoneScriptEditor(Player player, ZoneScript script) {
		this.player = player;
		this.zoneScript = (BasicZoneScript) script;
		this.zoneId = player.getCurrentZone().getZoneId();
	}

	@Override
	public void startEditing() {
		finished = false;
		state = ZoneScriptEditorState.MAIN_MENU;
		showMenu();
	}

	@Override
	public void stopEditing() { finished = true; }

	@Override
	public boolean isFinished() { return finished; }

	@Override
	public void tick() { }

	@Override
	public String getEditorName() { return "ZoneScriptEditor for Zone " + zoneId; }

	@Override
	public void showMenu() {
		player.sendMessage("\n--- Zone Script Editor ---");
		player.sendMessage("1) Edit Room Scripts");
		player.sendMessage("2) Show Script");
		player.sendMessage("3) Set Recall Nodes");
		player.sendMessage("4) Save Script and Exit Editor");
		player.sendMessage("5) Exit Without Saving");
		player.sendMessage("Type a command or option number:");
	}

	@Override
	public void handleInput(String input) {
		if (input == null || input.isBlank()) { player.sendMessage("Enter a command or 'menu'."); return; }
		input = input.trim();
		if (input.equalsIgnoreCase("menu")) { showMenu(); return; }
		if (input.equalsIgnoreCase("show")) { showScript(); return; }
		if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("done") || input.equalsIgnoreCase("quit")) { finished = true; player.sendMessage("Exiting editor."); return; }

		switch (state) {
		case MAIN_MENU -> handleMainMenu(input);
		case AWAITING_ROOM_ID -> handleRoomIdInput(input);
		case EDITING_ROOM_SCRIPT -> handleRoomScriptMenuInput(input);
		case AWAITING_ADD_MOB_ID -> handleMobIdInput(input);
		case AWAITING_MOB_LOAD_CHANCE -> handleMobLoadChance(input);
		case AWAITING_ADD_OBJECT_ID -> handleObjectIdInput(input);
		case AWAITING_OBJECT_LOAD_CHANCE -> handleObjectLoadChance(input);
		case AWAITING_DOOR_DIRECTION -> handleDoorDirection(input);
		case AWAITING_DOOR_STATE -> handleDoorState(input);
		case AWAITING_CONTAINER_OBJECT_ID -> handleContainerObjectId(input);
		case AWAITING_INNER_OBJECT_ID -> handleInnerObjectId(input);
		case AWAITING_RECALL_NODES -> handleRecallNodesInput(input);
		case AWAITING_SELECT_MOB_FOR_EQUIP -> handleSelectMobForEquip(input);
		case AWAITING_ADD_EQUIP_OBJECT_ID -> handleAddEquipObjectId(input);
		case AWAITING_ADD_INVENTORY_OBJECT_ID -> handleAddInventoryObjectId(input);
		case AWAITING_CHOOSE_EQUIP_OR_INVENTORY -> handleAddMobEquipOrInventory(input);
		case AWAITING_EQUIP_SLOT -> handleEquipSlot(input);
		
		}
	}




	private void handleMainMenu(String input) {
		switch (input) {
		case "1" -> { player.sendMessage("Enter room ID to edit:"); state = ZoneScriptEditorState.AWAITING_ROOM_ID; }
		case "2" -> showScript();
		case "3" -> { player.sendMessage("Enter comma-separated Room IDs for recall nodes:"); state = ZoneScriptEditorState.AWAITING_RECALL_NODES; }
		case "4" -> { saveZoneScript(); finished = true; }
		case "5" -> { player.sendMessage("Exiting without saving."); finished = true; }
		default -> player.sendMessage("Invalid option.");
		}
	}

	private void handleRoomIdInput(String input) {
		try {
			int roomId = Integer.parseInt(input);
			Room room = player.getCurrentWorld().getRoom(zoneId, roomId);
			if (room == null) { player.sendMessage("Room not found."); return; }
			editingRoomId = roomId;
			state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
			showRoomScriptMenu(roomId);
		} catch (NumberFormatException e) { player.sendMessage("Invalid room ID."); }
	}

	private void showRoomScriptMenu(int roomId) {
	    player.sendMessage("\n--- Editing Room " + roomId + " ---");
	    player.sendMessage("1) Add Mob");
	    player.sendMessage("2) Add Object");
	    player.sendMessage("3) Add Object Inside Object");
	    player.sendMessage("4) Set Door State");
	    player.sendMessage("5) Edit Mob Equipment/Inventory");  // NEW
	    player.sendMessage("6) Back to Main Menu");
	}


	private void handleRoomScriptMenuInput(String input) {
		switch (input) {
		case "1" -> { player.sendMessage("Enter Mob ID to add:"); state = ZoneScriptEditorState.AWAITING_ADD_MOB_ID; }
		case "2" -> { player.sendMessage("Enter Object ID to add:"); state = ZoneScriptEditorState.AWAITING_ADD_OBJECT_ID; }
		case "3" -> { player.sendMessage("Enter container Object ID:"); state = ZoneScriptEditorState.AWAITING_CONTAINER_OBJECT_ID; }
		case "4" -> { player.sendMessage("Enter Door Direction:"); state = ZoneScriptEditorState.AWAITING_DOOR_DIRECTION; }
		case "5" -> {             BasicZoneScript.Room room = zoneScript.getRooms().stream()
                .filter(r -> r.roomId == editingRoomId)
                .findFirst().orElse(null);

        if (room == null || room.mobs.isEmpty()) {
            player.sendMessage("No mobs in this room to edit.");
            state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
            showRoomScriptMenu(editingRoomId);
            return;
        }

        player.sendMessage("Select Mob by number:");
        for (int i = 0; i < room.mobs.size(); i++) {
            BasicZoneScript.Mob m = room.mobs.get(i);
            player.sendMessage((i+1) + ") MobID: " + m.mobId);
        }
        state = ZoneScriptEditorState.AWAITING_SELECT_MOB_FOR_EQUIP;
    }
    case "6" -> { state = ZoneScriptEditorState.MAIN_MENU; showMenu(); }
    default -> player.sendMessage("Invalid option.");

		}
	}

	private void handleRecallNodesInput(String input) {
		String[] parts = input.split(",");
		for (String part : parts) {
			try {
				int roomId = Integer.parseInt(part.trim());
				zoneScript.addRecallNode(roomId);
				player.sendMessage("Added room " + roomId + " as recall node.");
			} catch (NumberFormatException e) {
				player.sendMessage("Invalid room ID: " + part);
			}
		}
		state = ZoneScriptEditorState.MAIN_MENU;
		showMenu();
	}

	private void saveZoneScript() {
		Zone zone = player.getZone();
		if (zone == null) { player.sendMessage("Cannot save: Zone is null."); return; }
		File file = new File(Config.SCRIPT_DIR, zone.getWorld().getWorldId() + "_" + zone.getZoneId() + ".Script.txt");
		try (FileWriter writer = new FileWriter(file)) {
			writer.write(zoneScript.serialize());
			player.sendMessage("ZoneScript saved to " + file.getAbsolutePath());
		} catch (IOException e) {
			player.sendMessage("Failed to save ZoneScript: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void showScript() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("ZoneScript for Zone ").append(zoneScript.getZoneId()).append("\n\n");

	    // Recall nodes
	    List<BasicZoneScript.RecallNode> recalls = zoneScript.getRecallNodes();
	    if (!recalls.isEmpty()) {
	        sb.append("Recall Nodes:\n");
	        for (BasicZoneScript.RecallNode r : recalls) {
	            sb.append("  RoomID: ").append(r.roomId).append("\n");
	        }
	        sb.append("\n");
	    }

	    // Rooms
	    List<BasicZoneScript.Room> rooms = zoneScript.getRooms();
	    if (rooms.isEmpty()) {
	        sb.append("No rooms defined in this script.\n");
	        player.sendMessage(sb.toString());
	        return;
	    }

	    for (BasicZoneScript.Room room : rooms) {
	        sb.append("--- Room ").append(room.roomId).append(" ---\n");

	        // Mobs
	        if (!room.mobs.isEmpty()) {
	            sb.append("  Mobs:\n");
	            for (BasicZoneScript.Mob mob : room.mobs) {
	                sb.append("    MobID: ").append(mob.mobId)
	                  .append(" | Percent: ").append(mob.percent).append("\n");
	                if (!mob.equipment.isEmpty()) {
	                    sb.append("      Equipment:\n");
	                    for (BasicZoneScript.ZoneObject eq : mob.equipment)
	                        sb.append("        ObjectID: ").append(eq.objectId).append("\n");
	                }
	                if (!mob.inventory.isEmpty()) {
	                    sb.append("      Inventory:\n");
	                    for (BasicZoneScript.ZoneObject item : mob.inventory)
	                        sb.append("        ObjectID: ").append(item.objectId).append("\n");
	                }
	            }
	        }

	        // Objects
	        if (!room.objects.isEmpty()) {
	            sb.append("  Objects:\n");
	            for (BasicZoneScript.ZoneObject obj : room.objects) {
	                sb.append("    ObjectID: ").append(obj.objectId)
	                  .append(" | Percent: ").append(obj.percent).append("\n");
	                if (!obj.contains.isEmpty()) {
	                    sb.append("      Contains:\n");
	                    for (BasicZoneScript.ZoneObject inner : obj.contains)
	                        sb.append("        ObjectID: ").append(inner.objectId).append("\n");
	                }
	            }
	        }

	        // Doors
	        if (!room.doors.isEmpty()) {
	            sb.append("  Doors:\n");
	            for (BasicZoneScript.Door door : room.doors) {
	                sb.append("    Direction: ").append(door.direction)
	                  .append(" | Open: ").append(door.open)
	                  .append(" | Locked: ").append(door.locked)
	                  .append(" | Remote: ").append(door.remote)
	                  .append("\n");
	            }
	        }

	        // Triggers
	        if (!room.triggers.isEmpty()) {
	            sb.append("  Triggers:\n");
	            for (BasicZoneScript.Trigger t : room.triggers) {
	                sb.append("    - ").append(t.type).append("\n");
	                sb.append("      Chance: ").append(t.chance).append("\n");
	                if (t.actionType != null) sb.append("      ActionType: ").append(t.actionType).append("\n");
	                if (t.actionDetail != null) sb.append("      ActionDetail: ").append(t.actionDetail).append("\n");
	                if (t.spell != null) sb.append("      Spell: ").append(t.spell).append("\n");
	                if (t.textMatch != null) sb.append("      TextMatch: ").append(t.textMatch).append("\n");
	                if (t.objectType != null) sb.append("      ObjectType: ").append(t.objectType).append("\n");
	                sb.append("      Player: ").append(t.player).append("\n");
	            }
	        }

	        sb.append("\n");
	    }

	    player.sendMessage(sb.toString());
	}


	private void handleMobIdInput(String input) {
		try {
			int mobId = Integer.parseInt(input.trim());
			if (mobId <= 0) {
				player.sendMessage("Mob ID must be a positive number.");
				return;
			}

			// Optionally, validate the mob exists in your world data:
			// MobTemplate mobTemplate = player.getCurrentWorld().getMobTemplate(mobId);
			// if (mobTemplate == null) { player.sendMessage("Mob not found."); return; }

			pendingMobId = mobId;
			player.sendMessage("Enter the load chance for Mob " + mobId + " (1-100):");
			state = ZoneScriptEditorState.AWAITING_MOB_LOAD_CHANCE;

		} catch (NumberFormatException e) {
			player.sendMessage("Invalid Mob ID. Please enter a number.");
		}
	}

	private void handleMobLoadChance(String input) {
		if (pendingMobId <= 0 || editingRoomId < 0) {
			player.sendMessage("No Mob ID or room selected. Returning to room menu.");
			state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
			showRoomScriptMenu(editingRoomId);
			return;
		}

		try {
			int chance = Integer.parseInt(input.trim());
			if (chance < 1 || chance > 100) {
				player.sendMessage("Load chance must be between 1 and 100.");
				return;
			}

			// Create the mob spawn object
			BasicZoneScript.MobSpawnWithInventory mobSpawn = 
					new BasicZoneScript.MobSpawnWithInventory(pendingMobId, chance / 100.0);

			// Find the room in zoneScript
			BasicZoneScript.Room room = zoneScript.getRooms().stream()
					.filter(r -> r.roomId == editingRoomId)
					.findFirst()
					.orElseGet(() -> zoneScript.createRoom(editingRoomId));

			// Add mob to room
			room.mobs.add(convertToZoneScriptMob(mobSpawn));

			player.sendMessage("Added Mob " + pendingMobId + " with " + chance + "% load chance to Room " + editingRoomId + ".");

			// Reset pending mob
			pendingMobId = -1;

			// Return to room script menu
			state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
			showRoomScriptMenu(editingRoomId);

		} catch (NumberFormatException e) {
			player.sendMessage("Invalid number. Enter a load chance between 1 and 100.");
		}
	}
	
	private ZoneScript.Mob convertToZoneScriptMob(BasicZoneScript.MobSpawnWithInventory spawn) { 
	    ZoneScript.Mob mob = new ZoneScript.Mob();
	    mob.mobId = spawn.mobId;
	    mob.percent = (int) (spawn.chance * 100);

	    // Convert equipment (null-safe)
	    if (spawn.equipment != null) {
	        for (ZoneScript.EquipmentEntry item : spawn.equipment) {
	            ZoneScript.EquipmentEntry eq = new ZoneScript.EquipmentEntry();
	            eq.objectId = item.objectId;
	            eq.slot = item.slot;        // may be null
	            eq.percent = item.percent;  // or default to 100 if you prefer
	            mob.equipment.add(eq);
	        }
	    }

	    // Convert inventory (null-safe)
	    if (spawn.inventory != null) {
	        for (ZoneScript.ZoneObject item : spawn.inventory) {
	            ZoneScript.ZoneObject obj = new ZoneScript.ZoneObject();
	            obj.objectId = item.objectId;
	            obj.percent = item.percent; // or default to 100
	            mob.inventory.add(obj);
	        }
	    }

	    return mob;
	}



	private void handleObjectIdInput(String input) {
	    try {
	        int objectId = Integer.parseInt(input.trim());
	        if (objectId <= 0) {
	            player.sendMessage("Object ID must be greater than 0.");
	            return;
	        }

	        pendingObjectId = objectId;
	        player.sendMessage("Enter load chance for Object " + objectId + " (1-100):");
	        state = ZoneScriptEditorState.AWAITING_OBJECT_LOAD_CHANCE;

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid Object ID. Enter a number greater than 0.");
	    }
	}

	private void handleObjectLoadChance(String input) {
	    if (pendingObjectId <= 0 || editingRoomId < 0) {
	        player.sendMessage("No Object ID or room selected. Returning to room menu.");
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);
	        return;
	    }

	    try {
	        int chance = Integer.parseInt(input.trim());
	        if (chance < 1 || chance > 100) {
	            player.sendMessage("Load chance must be between 1 and 100.");
	            return;
	        }

	        // Create ObjectSpawn
	        BasicZoneScript.ObjectSpawn objSpawn = new BasicZoneScript.ObjectSpawn(pendingObjectId, chance / 100.0);

	        // Find the room
	        BasicZoneScript.Room room = zoneScript.getRooms().stream()
	            .filter(r -> r.roomId == editingRoomId)
	            .findFirst()
	            .orElseGet(() -> zoneScript.createRoom(editingRoomId));

	        // Add object to room
	        room.objects.add(convertToZoneScriptObject(objSpawn));

	        player.sendMessage("Added Object " + pendingObjectId + " with " + chance + "% load chance to Room " + editingRoomId + ".");

	        // Reset pending object
	        pendingObjectId = -1;

	        // Return to room script menu
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid number. Enter a load chance between 1 and 100.");
	    }
	}
	private ZoneScript.ZoneObject convertToZoneScriptObject(BasicZoneScript.ObjectSpawn spawn) {
	    ZoneScript.ZoneObject obj = new ZoneScript.ZoneObject();
	    obj.objectId = spawn.objectId;
	    obj.percent = (int) (spawn.chance * 100);
	    obj.contains.addAll(spawn.contains);
	    return obj;
	}
	
	private void handleContainerObjectId(String input) {
	    try {
	        int containerId = Integer.parseInt(input.trim());
	        if (containerId <= 0) {
	            player.sendMessage("Container Object ID must be greater than 0.");
	            return;
	        }

	        // Check if container exists in the room
	        BasicZoneScript.Room room = zoneScript.getRooms().stream()
	            .filter(r -> r.roomId == editingRoomId)
	            .findFirst()
	            .orElseGet(() -> zoneScript.createRoom(editingRoomId));

	        ZoneScript.ZoneObject container = room.objects.stream()
	            .filter(o -> o.objectId == containerId)
	            .findFirst()
	            .orElse(null);

	        if (container == null) {
	            // If container doesn't exist, create it with 100% chance
	            container = new ZoneScript.ZoneObject();
	            container.objectId = containerId;
	            container.percent = 100;
	            room.objects.add(container);
	        }

	        pendingContainerObjectId = containerId;
	        player.sendMessage("Enter Object ID to put inside Container " + containerId + ":");
	        state = ZoneScriptEditorState.AWAITING_INNER_OBJECT_ID;

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid Object ID. Enter a number greater than 0.");
	    }
	}

	private void handleInnerObjectId(String input) {
	    if (pendingContainerObjectId <= 0 || editingRoomId < 0) {
	        player.sendMessage("No container selected. Returning to room menu.");
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);
	        return;
	    }

	    try {
	        int innerId = Integer.parseInt(input.trim());
	        if (innerId <= 0) {
	            player.sendMessage("Inner Object ID must be greater than 0.");
	            return;
	        }

	        // Find the room and container
	        BasicZoneScript.Room room = zoneScript.getRooms().stream()
	            .filter(r -> r.roomId == editingRoomId)
	            .findFirst()
	            .orElseGet(() -> zoneScript.createRoom(editingRoomId));

	        ZoneScript.ZoneObject container = room.objects.stream()
	            .filter(o -> o.objectId == pendingContainerObjectId)
	            .findFirst()
	            .orElse(null);

	        if (container == null) {
	            player.sendMessage("Container not found in room.");
	            state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	            showRoomScriptMenu(editingRoomId);
	            return;
	        }

	        // Create the inner object
	        ZoneScript.ZoneObject inner = new ZoneScript.ZoneObject();
	        inner.objectId = innerId;
	        inner.percent = 100;

	        // Add to container
	        container.contains.add(inner);

	        player.sendMessage("Added Object " + innerId + " inside Container " + pendingContainerObjectId + ".");

	        // Reset pending
	        pendingContainerObjectId = -1;

	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid Object ID. Enter a number greater than 0.");
	    }
	}

	private void handleDoorDirection(String input) {
	    if (editingRoomId < 0) {
	        player.sendMessage("No room selected. Returning to main menu.");
	        state = ZoneScriptEditorState.MAIN_MENU;
	        showMenu();
	        return;
	    }

	    input = input.trim().toUpperCase();
	    if (input.isEmpty()) {
	        player.sendMessage("Direction cannot be empty.");
	        return;
	    }

	    editingDoorDirection = input;
	    player.sendMessage("Enter door states (comma-separated) for direction " + editingDoorDirection + ". Options: OPEN, CLOSED, LOCKED, REMOTE");
	    state = ZoneScriptEditorState.AWAITING_DOOR_STATE;
	}

	private void handleDoorState(String input) {
	    if (editingRoomId < 0 || editingDoorDirection == null) {
	        player.sendMessage("No room or direction selected. Returning to main menu.");
	        state = ZoneScriptEditorState.MAIN_MENU;
	        showMenu();
	        return;
	    }

	    try {
	        String[] parts = input.split(",");
	        Set<DoorState> states = new HashSet<>();
	        for (String part : parts) {
	            try {
	                states.add(DoorState.valueOf(part.trim().toUpperCase()));
	            } catch (IllegalArgumentException e) {
	                player.sendMessage("Invalid door state: " + part.trim());
	            }
	        }

	        Map<String, Set<DoorState>> doorMap = zoneScript.doorStates.computeIfAbsent(editingRoomId, k -> new HashMap<>());

	        doorMap.put(editingDoorDirection, states);

	        player.sendMessage("Door " + editingDoorDirection + " updated: " + states);

	        // Reset pending values
	        editingDoorDirection = null;
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);

	    } catch (Exception e) {
	        player.sendMessage("Failed to parse door states. Enter as comma-separated values: OPEN, CLOSED, LOCKED, REMOTE");
	    }
	}

	private void handleAddMobEquipOrInventory(String input) {
	    switch (input.trim()) {
	        case "1" -> { 
	            player.sendMessage("Enter ObjectID to equip:");
	            state = ZoneScriptEditorState.AWAITING_ADD_EQUIP_OBJECT_ID;
	        }
	        case "2" -> {
	            player.sendMessage("Enter ObjectID to add to inventory:");
	            state = ZoneScriptEditorState.AWAITING_ADD_INVENTORY_OBJECT_ID;
	        }
	        default -> player.sendMessage("Invalid choice. Type 1 for Equipment or 2 for Inventory.");
	    }
	}


	private void handleAddEquipObjectId(String input) {
	    try {
	        int objectId = Integer.parseInt(input.trim());
	        if (objectId <= 0) { 
	            player.sendMessage("Object ID must be positive."); 
	            return; 
	        }
	        pendingObjectId = objectId;

	        // Prompt for slot
	        player.sendMessage("Enter EquipSlot for Object " + objectId + ". Options: " + Arrays.toString(EquipSlot.values()));
	        state = ZoneScriptEditorState.AWAITING_EQUIP_SLOT;

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid Object ID. Enter a number greater than 0.");
	    }
	}


	private void handleAddInventoryObjectId(String input) {
	    try {
	        int objId = Integer.parseInt(input.trim());
	        BasicZoneScript.Room room = zoneScript.getRooms().stream()
	                .filter(r -> r.roomId == editingRoomId)
	                .findFirst().orElse(null);
	        BasicZoneScript.Mob mob = room.mobs.get(pendingMobId);

	        ZoneScript.ZoneObject obj = new ZoneScript.ZoneObject();
	        obj.objectId = objId;
	        obj.percent = 100;
	        mob.inventory.add(obj);

	        player.sendMessage("Added Object " + objId + " to Mob " + mob.mobId + "'s inventory.");
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);

	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid Object ID.");
	    }
	}
	private void handleEquipSlot(String input) {
	    try {
	        pendingEquipSlot = EquipSlot.valueOf(input.trim().toUpperCase());
	    } catch (IllegalArgumentException e) {
	        player.sendMessage("Invalid EquipSlot. Options: " + Arrays.toString(EquipSlot.values()));
	        return;
	    }

	    // Find the mob in the room
	    BasicZoneScript.Room room = zoneScript.getRooms().stream()
	            .filter(r -> r.roomId == editingRoomId)
	            .findFirst().orElse(null);

	    if (room == null || pendingMobId < 0 || room.mobs.size() <= pendingMobId) {
	        player.sendMessage("Cannot find mob. Returning to room menu.");
	        state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	        showRoomScriptMenu(editingRoomId);
	        return;
	    }

	    BasicZoneScript.Mob mob = room.mobs.get(pendingMobId);

	    ZoneScript.EquipmentEntry eq = new ZoneScript.EquipmentEntry();
	    eq.objectId = pendingObjectId;
	    eq.slot = pendingEquipSlot;
	    eq.percent = 100;

	    mob.equipment.add(eq);

	    player.sendMessage("Added Object " + pendingObjectId + " to Mob " + mob.mobId + " in slot " + pendingEquipSlot);

	    // Reset pending
	    pendingObjectId = -1;
	    pendingEquipSlot = null;

	    state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	    showRoomScriptMenu(editingRoomId);
	}

	
	private void handleSelectMobForEquip(String input) {
	    try {
	        int index = Integer.parseInt(input.trim()) - 1;
	        BasicZoneScript.Room room = zoneScript.getRooms().stream()
	                .filter(r -> r.roomId == editingRoomId)
	                .findFirst().orElse(null);
	        if (room == null || index < 0 || index >= room.mobs.size()) {
	            player.sendMessage("Invalid mob selection.");
	            state = ZoneScriptEditorState.EDITING_ROOM_SCRIPT;
	            showRoomScriptMenu(editingRoomId);
	            return;
	        }

	        pendingMobId = index;  // store index instead of MobID

	        player.sendMessage("1) Add Equipment");
	        player.sendMessage("2) Add Inventory Item");
	        player.sendMessage("Choose an option:");
	        state = ZoneScriptEditorState.AWAITING_CHOOSE_EQUIP_OR_INVENTORY;  // <--- set state here
	    } catch (NumberFormatException e) {
	        player.sendMessage("Invalid input. Enter a number.");
	    }
	}



	@Override
	public boolean save() {
		// unused, we use saveZoneScript
		return false;
	}

} // end