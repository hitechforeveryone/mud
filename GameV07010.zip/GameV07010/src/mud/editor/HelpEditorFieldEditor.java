package mud.editor;

import java.util.*;

import mud.core.Player;

public class HelpEditorFieldEditor implements Editor {
    private final HelpEditor parent;
    private final int fieldNumber;
    private Player player;
    private boolean multilineMode = false;
    private List<String> lines;

    public HelpEditorFieldEditor(HelpEditor parent, int fieldNumber, Player player) {
        this.parent = parent;
        this.fieldNumber = fieldNumber;
        this.player = player;
        this.lines = parent.getBodyLines(); 
    }



    public void handleInput(Player player, String input) {
        String trimmed = input.trim().toLowerCase();

        if (trimmed.equals("append")) {
            player.startMultilineInput(this);
            player.sendMessage("Enter text to append (END to finish):");
            return;

        } else if (trimmed.equals("done")) {
            // Finish editing body, return to main editor menu
            player.setEditor(parent);
            parent.showMenu();
            return;

        } else if (trimmed.equals("clear")) {
            // Clear all body lines
            parent.setField(2, "");
            player.sendMessage("Body cleared.");
            startEditing();
            return;

        } else if (trimmed.startsWith("edit ")) {
            try {
                int line = Integer.parseInt(trimmed.substring(5).trim()) - 1;
                player.setEditor(new HelpBodyLineEditor(parent, line, player));
            } catch (NumberFormatException e) {
                player.sendMessage("Invalid line number.");
                startEditing();
            }
            return;

        } else if (trimmed.matches("^\\d+$")) {
            // Just a number = edit that line
            int line = Integer.parseInt(trimmed) - 1;
            player.setEditor(new HelpBodyLineEditor(parent, line, player));
            return;

        } else if (trimmed.startsWith("insert ")) {
            try {
                int line = Integer.parseInt(trimmed.substring(7).trim()) - 1;
                insertLineAt(player, line);
            } catch (NumberFormatException e) {
                player.sendMessage("Invalid line number for insert.");
            }
            return;

        } else if (trimmed.startsWith("delete ")) {
            try {
                int line = Integer.parseInt(trimmed.substring(7).trim()) - 1;
                deleteLineAt(player, line);
            } catch (NumberFormatException e) {
                player.sendMessage("Invalid line number for delete.");
            }
            return;

        } else {
            player.sendMessage("Unknown command. Type 'edit <line>', 'insert <line>', 'delete <line>', 'append', 'clear', or 'done'.");
            startEditing();
        }
    }

    private void insertLineAt(Player player, int line) {
        List<String> lines = parent.getBodyLines();

        if (line < 0 || line > lines.size()) {
            player.sendMessage("Line number out of range.");
            startEditing();
            return;
        }

        // Insert empty line at position
        lines.add(line, "");
        parent.setField(2, String.join("\n", lines));
        player.sendMessage("Inserted empty line at " + (line + 1) + ".");
        startEditing();
    }

    private void deleteLineAt(Player player, int line) {
        List<String> lines = parent.getBodyLines();

        if (line < 0 || line >= lines.size()) {
            player.sendMessage("Line number out of range.");
            startEditing();
            return;
        }

        lines.remove(line);
        parent.setField(2, String.join("\n", lines));
        player.sendMessage("Deleted line " + (line + 1) + ".");
        startEditing();
    }


    public void onCancel(Player player) {
        player.setEditor(parent);
        parent.startEditing();
    }

    public void applyMultilineInput(Player player, String body) {
        parent.setField(fieldNumber, body);
        player.setEditor(parent);
        parent.startEditing(); // 
    }


    @Override
    public void startEditing() {
        if (fieldNumber == 2) {
            showBodyMenu();
        } else {
            // normal single line editing
            showMenu();
        }
    }

	@Override
	public void stopEditing() {
		// TODO Auto-generated method stub
		
	}

	   @Override
	    public void handleInput(String input) {
	        if (fieldNumber != 2) {
	            // For fields 1 and 3, single line input
	            parent.setField(fieldNumber, input);
	            player.setEditor(parent);
	            parent.startEditing();
	            return;
	        }

	        // For body editing (fieldNumber == 2)
	        String trimmed = input.trim();
	        if (!multilineMode) {
	            // Not in multiline input collection mode yet - handle commands
	            if (trimmed.equalsIgnoreCase("done")) {
	                // Save changes and return
	                parent.setField(fieldNumber, String.join("\n", lines));
	                player.setEditor(parent);
	                parent.startEditing();
	            } else if (trimmed.equalsIgnoreCase("clear")) {
	                lines.clear();
	                player.sendMessage("Body cleared.");
	                showBodyMenu();
	            } else if (trimmed.equalsIgnoreCase("append")) {
	                multilineMode = true;
	                player.sendMessage("(Appending mode started. Type END on a new line to finish.)");
	            } else if (trimmed.toLowerCase().startsWith("edit ")) {
	                try {
	                    int lineNum = Integer.parseInt(trimmed.substring(5).trim());
	                    if (lineNum < 1 || lineNum > lines.size()) {
	                        player.sendMessage("Invalid line number.");
	                        showBodyMenu();
	                    } else {
	                        player.setEditor(new HelpBodyLineEditor(parent, lineNum - 1, player));
	                        player.getEditor().startEditing();
	                    }
	                } catch (NumberFormatException e) {
	                    player.sendMessage("Invalid line number format.");
	                    showBodyMenu();
	                }
	            } else {
	                player.sendMessage("Unknown command.");
	                showBodyMenu();
	            }
	        } else {
	            // In multiline input mode (appending)
	            if (trimmed.equalsIgnoreCase("END")) {
	                multilineMode = false;
	                parent.setField(fieldNumber, String.join("\n", lines));
	                player.sendMessage("Appending finished.");
	                showBodyMenu();
	            } else {
	                lines.add(input);
	            }
	        }
	    }


	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getEditorName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void showMenu() {
	    if (fieldNumber == 2) {
	        List<String> lines = parent.getBodyLines();
	        player.sendMessage("Current body:");
	        for (int i = 0; i < lines.size(); i++) {
	            player.sendMessage(String.format("%2d) %s", i + 1, lines.get(i)));
	        }
	        player.sendMessage("""
	            Type 'edit <line>' to edit a line,
	            'append' to add to the end,
	            'clear' to start fresh,
	            or 'done' to return to the main menu.
	            """);
	    } else {
	        // existing title/alias logic
	    }
	}
	
    private void showBodyMenu() {
        player.sendMessage("Current body:");
        for (int i = 0; i < lines.size(); i++) {
            player.sendMessage((i+1) + ") " + lines.get(i));
        }
        player.sendMessage(
            "Type 'edit <line>' to edit a line,\n" +
            "'append' to add to the end,\n" +
            "'clear' to start fresh,\n" +
            "or 'done' to return to the main menu."
        );
    }
	
}// end HelpEditorFieldEditor


