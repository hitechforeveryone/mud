package mud.core;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

import mud.config.Config;

public class MudLogger {

    private static final String LOG_DIR = Config.LOGS_DIR;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void logDeath(Player player, String cause) {
        String locationId = "" + player.getCurrentWorld().getWorldId() + "_" 
                                + player.getCurrentZone().getZoneId() + "-" 
                                + player.getCurrentRoom().getId();
        String entry = String.format("[%s] Player: %s | Level: %d | Location: %s | Cause: %s",
                LocalDateTime.now().format(formatter),
                player.getName(),
                player.getLevel(),
                locationId,
                cause);
        writeLog("deaths.txt", entry);
    }

    public static void logSystemEvent(String message) {
        String entry = String.format("[%s] SYSTEM: %s",
                LocalDateTime.now().format(formatter),
                message);
        writeLog("system.txt", entry);
    }

    public static void logPlayerReport(Player player, String message) {
        String entry = String.format("[%s] Player: %s | %s",
                LocalDateTime.now().format(formatter),
                player.getName(),
                message);
        writeLog("reports.txt", entry);
    }

    private static void writeLog(String filename, String entry) {
        try {
            File dir = new File(LOG_DIR);
            if (!dir.exists()) dir.mkdirs(); // ensure directory exists
            File file = new File(dir, filename);

            // Append to file using PrintWriter
            try (PrintWriter out = new PrintWriter(new FileWriter(file, true))) {
                out.println(entry);
            }

        } catch (IOException e) {
            System.err.println("Failed to write log file: " + filename);
            e.printStackTrace();
        }
    }

    public static String handleReportCommand(Player player, String[] tokens) {
        if (tokens.length < 2) {
            return "Usage: /report <message>";
        }

        String message = String.join(" ", java.util.Arrays.copyOfRange(tokens, 1, tokens.length));
        logPlayerReport(player, message);
        return "Your report has been logged. Thank you!";
    }

	public static String handleViewLogCommand(Player player, String[] tokens) {
	    if (tokens.length < 2) {
	        return "Usage: /viewlog <deaths|system|reports> [lines]";
	    }

	    String logType = tokens[1].toLowerCase();
	    int lines = 20; // default
	    if (tokens.length >= 3) {
	        try {
	            lines = Integer.parseInt(tokens[2]);
	        } catch (NumberFormatException e) {
	            return "Invalid number of lines: " + tokens[2];
	        }
	    }

	    String filename;
	    switch (logType) {
	        case "deaths": filename = "deaths.txt"; break;
	        case "system": filename = "system.txt"; break;
	        case "reports": filename = "reports.txt"; break;
	        default: return "Unknown log type: " + logType;
	    }

	    File file = new File(Config.LOGS_DIR, filename);
	    if (!file.exists()) return "Log file not found: " + filename;

	    try {
	        java.util.List<String> allLines = java.nio.file.Files.readAllLines(file.toPath());
	        // show only the last 'lines' entries
	        int start = Math.max(0, allLines.size() - lines);
	        StringBuilder sb = new StringBuilder();
	        for (int i = start; i < allLines.size(); i++) {
	            sb.append(allLines.get(i)).append("\n");
	        }
	        return sb.toString();
	    } catch (IOException e) {
	        e.printStackTrace();
	        return "Failed to read log file: " + filename;
	    }
	}
} // end
