package mud.core;

import java.util.HashMap;
import java.util.Map;

public enum EquipSlot {
    NONE("None"),
    LIGHTSOURCE("Lightsource"),
    HEAD("Head"),
    NECK("Neck"),
    SHOULDERS("Shoulders"),
    CHEST("Chest"),
    WRISTS("Wrists"),
    HANDS("Hands"),
    FINGER1("Finger1"),
    FINGER2("Finger2"),
    WAIST("Waist"),
    LEGS("Legs"),
    FEET("Feet"),
    TRINKET1("Trinket1"),
    TRINKET2("Trinket2"),
    MAINHAND("Mainhand"),
    OFFHAND("Offhand"),
    TWOHAND("Twohand"),
    WEAPON("Weapon");

	private final String slotName;
	
	EquipSlot(String slotName) {
		this.slotName = slotName;
	}
	public String getslotName() {
		return slotName;
	}
    private static final Map<String, EquipSlot> lookup = new HashMap<>();

    static {
        // Populate all canonical aliases
        lookup.put("none", NONE);

        lookup.put("lightsource", LIGHTSOURCE);
        lookup.put("light source", LIGHTSOURCE);
        lookup.put("light", LIGHTSOURCE);

        lookup.put("head", HEAD);
        lookup.put("helm", HEAD);
        lookup.put("helmet", HEAD);

        lookup.put("neck", NECK);
        lookup.put("necklace", NECK);

        lookup.put("shoulders", SHOULDERS);
        lookup.put("shoulder", SHOULDERS);

        lookup.put("body", CHEST);
        lookup.put("chest", CHEST);
        lookup.put("shirt", CHEST);
        lookup.put("armor", CHEST);
        lookup.put("robe", CHEST);

        lookup.put("wrists", WRISTS);
        lookup.put("wrist", WRISTS);
        lookup.put("bracer", WRISTS);

        lookup.put("hands", HANDS);
        lookup.put("gloves", HANDS);
        lookup.put("hand", HANDS);

        lookup.put("finger1", FINGER1);
        lookup.put("1.finger", FINGER1);
        lookup.put("ring1", FINGER1);
        lookup.put("ring", FINGER1); // default to first slot
        lookup.put("finger", FINGER1);

        lookup.put("finger2", FINGER2);
        lookup.put("ring2", FINGER2);
        lookup.put("2.finger", FINGER2);

        lookup.put("waist", WAIST);
        lookup.put("belt", WAIST);

        lookup.put("legs", LEGS);
        lookup.put("pants", LEGS);
        lookup.put("trousers", LEGS);

        lookup.put("feet", FEET);
        lookup.put("boots", FEET);
        lookup.put("shoes", FEET);

        lookup.put("trinket1", TRINKET1);
        lookup.put("trinket2", TRINKET2);
        lookup.put("2.trinket", TRINKET2);
        lookup.put("trinket", TRINKET1); // default to 1st slot

        lookup.put("mainhand", MAINHAND);
        lookup.put("weapon", MAINHAND);
        lookup.put("sword", MAINHAND);
        lookup.put("axe", MAINHAND);

        lookup.put("offhand", OFFHAND);
        lookup.put("shield", OFFHAND);
        lookup.put("grab", OFFHAND);

        lookup.put("twohand", TWOHAND);
        lookup.put("two-handed", TWOHAND);
        
        lookup.put("ranged", MAINHAND);
        
        
    }

    public static EquipSlot fromString(String input) {
        if (input == null) return null;
        return lookup.get(input.trim().toLowerCase());
    }
    
    public boolean isCompatibleWith(EquipSlot otherSlot) {
        if (this == TWOHAND && otherSlot == OFFHAND) return false;
        if (this == OFFHAND && otherSlot == TWOHAND) return false;
 

        // OFFHAND items may go in MAINHAND (e.g., dagger in either hand)
        if ((this == MAINHAND && otherSlot == OFFHAND) ||
            (this == OFFHAND && otherSlot == MAINHAND)) {
            return true;
        }

        return this == otherSlot;
    }
    
} // end EquipSlot
