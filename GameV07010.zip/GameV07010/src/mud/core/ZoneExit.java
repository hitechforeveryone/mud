package mud.core;

public class ZoneExit{


    private String targetWorldId;
    private int targetZoneId;
    private int targetRoomId;
    private Direction direction;

    public ZoneExit(String targetWorldId, int targetZoneId, int targetRoomId) {
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
        
    }
    
    public ZoneExit(String targetWorldId, int targetZoneId, int targetRoomId, Direction direction) {
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
        this.direction = direction;
    }
    
    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }
    public String getTargetWorldId() {
        return targetWorldId;
    }

    public int getTargetZoneId() {
        return targetZoneId;
    }

    public int getTargetRoomId() {
        return targetRoomId;
    }

    public void setTargetWorldId(String id) {
        this.targetWorldId = id;
    }

    public void setTargetZoneId(int id) {
        this.targetZoneId = id;
    }

    public void setTargetRoomId(int id) {
        this.targetRoomId = id;
    }
    public int getZoneId() {
        return targetZoneId;
    }
    public String getWorldId() {
        return targetWorldId;
    }

    public int getRoomId() {
        return targetRoomId;
    }
}
