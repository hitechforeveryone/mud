package mud.core;

public enum WeatherType {
    CLEAR,
    CLOUDY,
    RAIN,
    STORM,
    SNOW,
    FOG,
    WINDY,
    HEATWAVE,
    COLD_SNAP,
    VOID,
    BLIGHT,
    COLD,
    NONE;

    public String getDescription() {
        return switch (this) {
        	case NONE -> "A windless breeze gently ruffles the dust.";
        	case VOID -> "A gentle emptiness surrounds you.";
            case CLEAR -> "The skies are clear.";
            case CLOUDY -> "Clouds drift across the sky.";
            case RAIN -> "Rain falls from the sky.";
            case STORM -> "A fierce storm rages.";
            case SNOW -> "Snowflakes drift gently down.";
            case FOG -> "A thick fog blankets the area.";
            case WINDY -> "Strong winds howl through.";
            case HEATWAVE -> "A sweltering heat grips the land.";
            case COLD -> "A chill lingers in the air.";
            case COLD_SNAP -> "A sharp cold bites the air.";
            case BLIGHT -> "A foul, acrid wind blows, carrying the stench of decay and poisoned earth.";
            
            
            
            default -> "The skies are clear.";
        };
    }
}
