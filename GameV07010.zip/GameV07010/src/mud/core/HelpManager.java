package mud.core;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import mud.config.Config;

public class HelpManager {
    private static Map<String, HelpEntry> helpEntries = new HashMap<>();

    public static void addHelpEntry(HelpEntry entry) {
        helpEntries.put(entry.getKeyword(), entry);
        for (String alias : entry.getAliases()) {
            helpEntries.put(alias, entry);
        }
    }

    public static HelpEntry getHelpEntry(String keyword) {
        return helpEntries.get(keyword.toLowerCase());
    }

    public static List<HelpEntry> getAllEntries() {
        List<HelpEntry> list = new ArrayList<>(new HashSet<>(helpEntries.values())); // de-dupe
        list.sort(Comparator.comparing(e -> e.getKeyword().toLowerCase()));
        return list;
    }
    // end


    public static Set<String> getAllKeywords() {
        return helpEntries.keySet();
    }

    public static List<HelpEntry> search(String query) {
        return getAllEntries().stream()
            .filter(entry -> entry.getKeyword().contains(query.toLowerCase()) ||
                             entry.getTitle().toLowerCase().contains(query.toLowerCase()))
            .sorted(Comparator.comparing(HelpEntry::getKeyword))
            .collect(Collectors.toList());
    }
    public static void saveAllToDisk() {
        File dir = new File(Config.HELPS_DIR);
        if (!dir.exists()) dir.mkdirs();

        List<HelpEntry> sortedEntries = getAllEntries().stream()
        	    .sorted(Comparator.comparing(HelpEntry::getKeyword))
        	    .toList();

        	for (HelpEntry entry : sortedEntries) {
            File file = new File(dir, entry.getKeyword() + ".txt");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("# Keyword: " + entry.getKeyword() + "\n");
                writer.write("# Title: " + entry.getTitle() + "\n");
                if (!entry.getAliases().isEmpty()) {
                    List<String> sortedAliases = new ArrayList<>(entry.getAliases());
                    Collections.sort(sortedAliases);
                    writer.write("# Aliases: " + String.join(",", sortedAliases) + "\n");
                }

                writer.write("\n");
                writer.write(entry.getBody());
            } catch (IOException e) {
                System.err.println("Failed to save help entry: " + entry.getKeyword());
                e.printStackTrace();
            }
        }
    }
    public static void saveEntryToDisk(HelpEntry entry) {
        File dir = new File(Config.HELPS_DIR);
        if (!dir.exists()) dir.mkdirs();

        File file = new File(dir, entry.getKeyword() + ".txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("# Keyword: " + entry.getKeyword() + "\n");
            writer.write("# Title: " + entry.getTitle() + "\n");
            if (!entry.getAliases().isEmpty()) {
                writer.write("# Aliases: " + String.join(",", entry.getAliases()) + "\n");
            }
            writer.write("\n");
            writer.write(entry.getBody());
        } catch (IOException e) {
            System.err.println("Failed to save help entry: " + entry.getKeyword());
            e.printStackTrace();
        }
    }


    public static void loadAllFromDisk() {
        helpEntries.clear(); // optional if you allow live reload

        File dir = new File(Config.HELPS_DIR);
        if (!dir.exists()) return;

        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".txt"));
        if (files == null) return;

        for (File file : files) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String keyword = null;
                String title = "";
                List<String> aliases = new ArrayList<>();
                StringBuilder body = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("# Keyword: ")) {
                        keyword = line.substring(11).trim().toLowerCase();
                    } else if (line.startsWith("# Title: ")) {
                        title = line.substring(9).trim();
                    } else if (line.startsWith("# Aliases: ")) {
                        String[] parts = line.substring(11).split(",");
                        for (String part : parts) {
                            aliases.add(part.trim().toLowerCase());
                        }
                    } else {
                        body.append(line).append("\n");
                    }
                }

                if (keyword != null) {
                    HelpEntry entry = new HelpEntry(keyword, title, body.toString().trim());
                    aliases.forEach(entry::addAlias);
                    addHelpEntry(entry);
                }

            } catch (IOException e) {
                System.err.println("Failed to load help file: " + file.getName());
                e.printStackTrace();
            }
        }
    }


} // end HelpManager
