package mud.core;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ObjectManager {
    private static final Map<Integer, ObjectItem> objectsById = new ConcurrentHashMap<>();
    private static final Map<Integer, ObjectItem> objTemplates = new HashMap<>();
    

    public static void addObject(ObjectItem obj) {
        objectsById.put(obj.getObjID(), obj);
    }

    public static ObjectItem getObjectById(int id) {
        System.out.println("DEBUG getObjectById → searching for: " + id);
        System.out.println("Keys in object map: " + objectsById.keySet());
        return objectsById.get(id);
    }

    public static void removeObject(int id) {
        objectsById.remove(id);
    }

    // In ObjectManager.java
    public static ObjectItem createObjById(int id) {
    	ObjectItem prototype = objTemplates.get(id);

        if (prototype == null) {
            // Try loading from file if not already registered
        	ObjectItem loaded = WorldManager.loadObj(String.valueOf(id));
            if (loaded != null) {
                registerObjTemplate(loaded); // Register it
                addObject(loaded);
                prototype = loaded;
            }
        }

        return prototype != null ? prototype.clone() : null;
    }

    
    public static void registerObjTemplate(int id, ObjectItem mob) {
        objTemplates.put(id, mob);
    }

    
    public static void loadObjTemplates() {
        // Example hardcoded:
    	ObjectItem blob = new ObjectItem();
        blob.setName("a blob");
        
        // Set other properties...

        registerObjTemplate(blob);
        addObject(blob);
    }

    public static void registerObjTemplate(ObjectItem obj) {
        objTemplates.put(obj.getObjID(), obj);
    }

    // Additional helper methods as needed...
}
