package mud.core;

public enum ArmorType {
    NONE(0),
    CLOTH(1),
    LEATHER(3),
    CHAIN(5),
    SCALE(7),
    SPLINT(8),
    PLATE(10),
	DRAGON_SCALE(12);

    private final int defenseBonus;

    ArmorType(int defenseBonus) {
        this.defenseBonus = defenseBonus;
    }

    public int getDefenseBonus() {
        return defenseBonus;
    }
	
    /**
     * Parses a string into an ArmorType, case-insensitively,
     * supporting flexible aliases (e.g., "cloth armor", "mail").
     */
    public static ArmorType fromString(String input) {
        if (input == null) return NONE;

        String normalized = input.trim().toLowerCase();

        switch (normalized) {
            case "none":
                return NONE;
            case "cloth":
            case "cloth armor":
                return CLOTH;
            case "leather":
            case "leather armor":
                return LEATHER;
            case "chainmail":
            case "chain mail":
                return CHAIN;
            case "scalemail":
            case "scale mail":
            case "scale armor":
            	return SCALE;
            case "splint":
            case "splint mail":
            case "splint armor":
            	return SPLINT;
            case "plate":
            case "plate armor":
                return PLATE;
            case "dragon scale":
            case "dragon_scale":
            	return DRAGON_SCALE;
            default:
                return NONE; // fallback
        }
    }

    @Override
    public String toString() {
        // Optional: make output title-cased like "Cloth"
        return name().charAt(0) + name().substring(1).toLowerCase();
    }
}
