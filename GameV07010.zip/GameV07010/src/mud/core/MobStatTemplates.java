package mud.core;

import java.util.HashMap;
import java.util.Map;

public class MobStatTemplates {

    // Base stats: STR, STA, AGI, INT, CHA
    public static final Map<String, int[]> BASE_STATS = Map.ofEntries(
        Map.entry("NONE", new int[]{10, 10, 10, 10, 10}),
        Map.entry("AQUATIC", new int[]{12, 15, 8, 7, 10}),
        Map.entry("BEAST", new int[]{14, 12, 11, 5, 10}),
        Map.entry("CRITTER", new int[]{3, 5, 18, 6, 8}),
        Map.entry("DEMON", new int[]{15, 12, 12, 14, 12}),
        Map.entry("DRAGONKIN", new int[]{20, 18, 10, 12, 10}),
        Map.entry("ELEMENTAL", new int[]{16, 16, 9, 9, 10}),
        Map.entry("FLYING", new int[]{8, 10, 16, 8, 10}),
        Map.entry("HUMANOID", new int[]{10, 10, 10, 10, 10}),
        Map.entry("GIANT", new int[]{22, 20, 6, 8, 10}),
        Map.entry("MAGIC", new int[]{7, 9, 10, 18, 12}),
        Map.entry("MECHANICAL", new int[]{15, 15, 5, 10, 8}),
        Map.entry("PLANT", new int[]{11, 13, 7, 10, 12}),
        Map.entry("UNDEAD", new int[]{13, 14, 8, 9, 10})
    );

    public static final Map<String, int[]> SUBRACE_MODIFIERS = new HashMap<>();

    static {
        // Aquatic
        SUBRACE_MODIFIERS.put("FISH", new int[]{0, 2, 2, -1, 0});
        SUBRACE_MODIFIERS.put("MERFOLK", new int[]{1, 1, 1, 1, 2});
        SUBRACE_MODIFIERS.put("SEASERPENT", new int[]{3, 2, -1, 0, 1});
        SUBRACE_MODIFIERS.put("KRAKEN", new int[]{4, 4, -2, 0, 1});
        SUBRACE_MODIFIERS.put("SHARK", new int[]{2, 2, 1, -1, 0});
        SUBRACE_MODIFIERS.put("WHALE", new int[]{5, 5, -3, 0, 1});
        SUBRACE_MODIFIERS.put("CRUSTACEAN", new int[]{1, 3, 0, -1, 0});
        SUBRACE_MODIFIERS.put("CEPHALOPOD", new int[]{0, 1, 1, 2, 1});
        SUBRACE_MODIFIERS.put("LEVIATHAN", new int[]{6, 6, -2, 2, 2});
        SUBRACE_MODIFIERS.put("SEA_ELDER", new int[]{2, 2, 2, 3, 4});

        // Beast
        SUBRACE_MODIFIERS.put("WOLF", new int[]{2, 1, 2, 0, 1});
        SUBRACE_MODIFIERS.put("BEAR", new int[]{4, 3, -1, 0, 0});
        SUBRACE_MODIFIERS.put("LARGECAT", new int[]{2, 1, 3, -1, 1});
        SUBRACE_MODIFIERS.put("BOAR", new int[]{3, 2, 0, 0, 0});
        SUBRACE_MODIFIERS.put("CERVID", new int[]{1, 1, 2, 1, 2});
        SUBRACE_MODIFIERS.put("BOVIDAE", new int[]{3, 3, -1, 0, 1});
        SUBRACE_MODIFIERS.put("SNAKE", new int[]{1, 0, 3, 1, 0});
        SUBRACE_MODIFIERS.put("LIZARD", new int[]{1, 1, 1, 1, 0});
        SUBRACE_MODIFIERS.put("CHIMERA", new int[]{5, 4, 2, 2, 2});

        // Critter
        SUBRACE_MODIFIERS.put("VERMIN", new int[]{0, 0, 2, 0, 0});
        SUBRACE_MODIFIERS.put("INSECT", new int[]{0, 1, 2, 0, 0});
        SUBRACE_MODIFIERS.put("RODENT", new int[]{0, 1, 2, 1, 0});
        SUBRACE_MODIFIERS.put("SPIDER", new int[]{0, 1, 3, 1, 0});
        SUBRACE_MODIFIERS.put("GIANT_ANT", new int[]{1, 2, 2, 0, 0});

        // Demon
        SUBRACE_MODIFIERS.put("IMPS", new int[]{-2, -1, 3, 1, 2});
        SUBRACE_MODIFIERS.put("FIRE_DEMON", new int[]{3, 2, 1, 2, 2});
        SUBRACE_MODIFIERS.put("SHADOW_DEMON", new int[]{1, 1, 3, 2, 2});
        SUBRACE_MODIFIERS.put("HELLHOUND", new int[]{4, 3, 2, 0, 1});
        SUBRACE_MODIFIERS.put("SUCCUBUS", new int[]{0, 1, 2, 3, 4});
        SUBRACE_MODIFIERS.put("BALOR", new int[]{6, 5, 2, 4, 4});
        SUBRACE_MODIFIERS.put("VILE_SPIRIT", new int[]{1, 0, 2, 3, 2});
        SUBRACE_MODIFIERS.put("PIT_LORD", new int[]{5, 5, 2, 3, 3});
        SUBRACE_MODIFIERS.put("HELLSPAWN", new int[]{1, 1, 2, 2, 2});
        SUBRACE_MODIFIERS.put("ABYSSAL_WRAITH", new int[]{0, 2, 3, 3, 2});
        SUBRACE_MODIFIERS.put("FIRELORD", new int[]{5, 3, 2, 5, 5});
        SUBRACE_MODIFIERS.put("INFERNAL_ARCHON", new int[]{6, 6, 3, 4, 4});

        // Dragonkin
        SUBRACE_MODIFIERS.put("TRUEDRAGON", new int[]{5, 5, 2, 3, 3});
        SUBRACE_MODIFIERS.put("DRAGONBLOOD", new int[]{3, 3, 1, 2, 2});
        SUBRACE_MODIFIERS.put("WYVERN", new int[]{4, 2, 2, 0, 1});
        SUBRACE_MODIFIERS.put("DRAKE", new int[]{3, 2, 2, 1, 1});
        SUBRACE_MODIFIERS.put("LANDDRAGON", new int[]{4, 3, 1, 1, 2});
        SUBRACE_MODIFIERS.put("WYRM", new int[]{3, 4, 1, 2, 2});
        SUBRACE_MODIFIERS.put("DRAGONKIN", new int[]{2, 2, 2, 2, 2});
        SUBRACE_MODIFIERS.put("DRAKONID", new int[]{3, 3, 1, 2, 2});
        SUBRACE_MODIFIERS.put("CELESTIAL_DRAGON", new int[]{5, 4, 2, 5, 5});
        SUBRACE_MODIFIERS.put("VOID_DRAGON", new int[]{6, 4, 3, 4, 4});
        SUBRACE_MODIFIERS.put("DRACOLICH", new int[]{6, 5, 2, 6, 5});


     // Elemental
        SUBRACE_MODIFIERS.put("FIRE_ELEMENTAL", new int[]{2, 0, 1, 3, 1});
        SUBRACE_MODIFIERS.put("WATER_ELEMENTAL", new int[]{1, 2, 1, 2, 1});
        SUBRACE_MODIFIERS.put("EARTH_ELEMENTAL", new int[]{3, 3, -1, 0, 0});
        SUBRACE_MODIFIERS.put("AIR_ELEMENTAL", new int[]{1, 1, 3, 1, 1});
        // hybrid and advanced elementals
        SUBRACE_MODIFIERS.put("LAVA_ELEMENTAL", new int[]{4, 2, 0, 3, 2});     // Fire + Earth
        SUBRACE_MODIFIERS.put("ICE_ELEMENTAL", new int[]{3, 3, -1, 2, 2});     // Water + Ice
        SUBRACE_MODIFIERS.put("STORM_ELEMENTAL", new int[]{2, 1, 3, 3, 2});    // Air + Lightning
        SUBRACE_MODIFIERS.put("MUD_ELEMENTAL", new int[]{3, 3, 0, 1, 1});      // Water + Earth
        SUBRACE_MODIFIERS.put("MAGMA_ELEMENTAL", new int[]{5, 3, 0, 3, 3});    // Boss-level Fire + Earth
        SUBRACE_MODIFIERS.put("TWILIGHT_ELEMENTAL", new int[]{2, 2, 2, 4, 4}); // Shadow + Air + Arcane

        // Flying
        SUBRACE_MODIFIERS.put("HARPY", new int[]{1, 1, 3, 0, 1});
        SUBRACE_MODIFIERS.put("AVIAN", new int[]{0, 1, 3, 1, 1});
        SUBRACE_MODIFIERS.put("CLOUD", new int[]{0, 1, 2, 2, 1});
        SUBRACE_MODIFIERS.put("ROOK", new int[]{0, 0, 2, 1, 0});      // small bird swarms
        SUBRACE_MODIFIERS.put("PHOENIX", new int[]{4, 3, 2, 5, 4});   // legendary rebirth bird

        // Humanoid
        SUBRACE_MODIFIERS.put("HUMAN", new int[]{0, 0, 0, 0, 1});
        SUBRACE_MODIFIERS.put("ELF", new int[]{0, 0, 1, 2, 2});
        SUBRACE_MODIFIERS.put("HALFELF", new int[]{0, 1, 1, 1, 2});
        SUBRACE_MODIFIERS.put("DWARF", new int[]{2, 2, -1, 0, 1});
        SUBRACE_MODIFIERS.put("ORC", new int[]{3, 2, -1, -1, 0});
        SUBRACE_MODIFIERS.put("TROLL", new int[]{3, 3, 0, -1, 0});
        SUBRACE_MODIFIERS.put("TAUREN", new int[]{4, 3, -2, 0, 1});
        SUBRACE_MODIFIERS.put("WERECREATURE", new int[]{3, 2, 2, -1, 1});
        SUBRACE_MODIFIERS.put("GNOME", new int[]{-1, 0, 2, 2, 2});
        SUBRACE_MODIFIERS.put("HALFORC", new int[]{2, 2, 0, 0, 1});
        SUBRACE_MODIFIERS.put("DROW", new int[]{0, 0, 2, 2, 2});

        // Giant
        SUBRACE_MODIFIERS.put("JOTUN", new int[]{5, 4, -2, 0, 1});
        SUBRACE_MODIFIERS.put("FIREGIANT", new int[]{4, 3, -1, 2, 2});
        SUBRACE_MODIFIERS.put("CLOUDGIANT", new int[]{3, 2, 2, 2, 2});
        SUBRACE_MODIFIERS.put("FROSTGIANT", new int[]{4, 4, -1, 0, 1});
        SUBRACE_MODIFIERS.put("STONEGIANT", new int[]{5, 5, -2, -1, 1});
        SUBRACE_MODIFIERS.put("STORMGIANT", new int[]{5, 4, 1, 2, 2});
        SUBRACE_MODIFIERS.put("HILLGIANT", new int[]{3, 3, -1, 0, 1});
        SUBRACE_MODIFIERS.put("OGRE", new int[]{4, 3, -2, -1, 0});
        SUBRACE_MODIFIERS.put("ETTIN", new int[]{5, 3, -2, -1, 0});
        SUBRACE_MODIFIERS.put("TITAN", new int[]{6, 6, 0, 4, 3});

        // Magic
        SUBRACE_MODIFIERS.put("ARCANE_BEING", new int[]{0, 0, 0, 4, 4});
        SUBRACE_MODIFIERS.put("FAE", new int[]{0, 1, 2, 3, 4});
        SUBRACE_MODIFIERS.put("ILLUSION", new int[]{0, 0, 2, 3, 3});
        SUBRACE_MODIFIERS.put("SPRITE", new int[]{0, 0, 1, 3, 3});

        // Mechanical
        SUBRACE_MODIFIERS.put("GOLEM", new int[]{5, 5, -3, 0, 0});
        SUBRACE_MODIFIERS.put("AUTOMATON", new int[]{3, 3, 0, 1, 1});
        SUBRACE_MODIFIERS.put("CLOCKWORK", new int[]{2, 2, 1, 2, 1});

        // Plant
        SUBRACE_MODIFIERS.put("VINEBEAST", new int[]{2, 3, -1, 1, 1});
        SUBRACE_MODIFIERS.put("TREANT", new int[]{4, 4, -2, 0, 1});
        SUBRACE_MODIFIERS.put("SPOREBORN", new int[]{1, 2, 1, 2, 2});
        SUBRACE_MODIFIERS.put("ENTLING", new int[]{2, 2, 0, 2, 2});
        SUBRACE_MODIFIERS.put("FLOWERSPIRIT", new int[]{0, 1, 1, 3, 3});

        // Undead
        SUBRACE_MODIFIERS.put("SKELETON", new int[]{1, 1, 2, 0, 0});
        SUBRACE_MODIFIERS.put("GHOST", new int[]{0, 0, 3, 2, 2});
        SUBRACE_MODIFIERS.put("ZOMBIE", new int[]{3, 3, -2, -1, 0});
        SUBRACE_MODIFIERS.put("WIGHT", new int[]{2, 2, 0, 1, 1});
        SUBRACE_MODIFIERS.put("VAMPIRE", new int[]{2, 2, 2, 3, 3});
        SUBRACE_MODIFIERS.put("LICH", new int[]{0, 0, 0, 5, 4});
        SUBRACE_MODIFIERS.put("BANSHEE", new int[]{0, 1, 3, 2, 3});
        SUBRACE_MODIFIERS.put("DEATHKNIGHT", new int[]{4, 4, 1, 3, 3});
        SUBRACE_MODIFIERS.put("DRACOLICH", new int[]{6, 5, 2, 6, 5});

        
        
    }

    // --- Accessors ---
    public static int[] getBaseStats(String race) {
        return BASE_STATS.getOrDefault(race.toUpperCase(), new int[]{10, 10, 10, 10, 10});
    }

    public static int[] getBaseStats(String race, String subrace) {
        int[] base = getBaseStats(race);
        int[] mod = SUBRACE_MODIFIERS.getOrDefault(subrace.toUpperCase(), new int[]{0, 0, 0, 0, 0});
        return new int[]{
            base[0] + mod[0],
            base[1] + mod[1],
            base[2] + mod[2],
            base[3] + mod[3],
            base[4] + mod[4]
        };
    }
}
