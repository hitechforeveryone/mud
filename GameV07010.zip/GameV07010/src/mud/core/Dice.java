package mud.core;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Centralized dice / RNG utility for the MUD.
 * Use this instead of Random or ad-hoc rolls.
 */
public final class Dice {

    private Dice() {
        // Utility class
    }

    /**
     * Roll a number between min and max (inclusive).
     */
    public static int roll(int min, int max) {
        if (max < min)
            return min;

        return ThreadLocalRandom.current().nextInt(max - min + 1) + min;
    }

    /**
     * Roll 1..max (inclusive).
     */
    public static int roll(int max) {
        return roll(1, max);
    }

    /**
     * Roll percent chance (1–100).
     */
    public static int percent() {
        return roll(1, 100);
    }

    /**
     * Returns true if percent chance succeeds.
     */
    public static boolean chance(int percent) {
        if (percent <= 0) return false;
        if (percent >= 100) return true;
        return roll(1, 100) <= percent;
    }

    /**
     * Roll multiple dice and sum them.
     * Example: rollDice(3, 6) = 3d6
     */
    public static int rollDice(int number, int sides) {
        int total = 0;
        for (int i = 0; i < number; i++) {
            total += roll(1, sides);
        }
        return total;
    }
}
// end
