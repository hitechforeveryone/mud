package mud.core;

public class StatusEffect {
	private EffectType type; // POISON, BLEED, STUN, etc.
	private int duration;
	private int potency;
	private boolean isStackable;
	private boolean isBeneficial;

	private int hpBonus = 0;
	private int mpBonus = 0;
	private int strengthBonus;
	private int staminaBonus;
	private int intellectBonus;
	private int agilityBonus;
	private int hitrollBonus;
	private int damrollBonus;

	public void setHpBonus(int val) { this.hpBonus = val; }

	public int getMpBonus() { return mpBonus; }
	public void setMpBonus(int val) { this.mpBonus = val; }

	public StatusEffect(int hpBonus, int strengthBonus /*, others */) {
		this.hpBonus = hpBonus;
		this.strengthBonus = strengthBonus;
	}

	public void apply(Mob target) {
		// Logic for stacking or refreshing effects
	}

	public void tick(Mob target) {
		// Applies per-tick logic (e.g., DoT or HoT)
	}
	public EffectType getType() {
		return type;
	}
	public void setType(EffectType type) {
		this.type = type;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getPotency() {
		return potency;
	}
	public void setPotency(int potency) {
		this.potency = potency;
	}
	public boolean isStackable() {
		return isStackable;
	}
	public void setStackable(boolean isStackable) {
		this.isStackable = isStackable;
	}
	public boolean isBeneficial() {
		return isBeneficial;
	}
	public void setBeneficial(boolean isBeneficial) {
		this.isBeneficial = isBeneficial;
	}

	public int getHpBonus() {
		return hpBonus;
	}

	public int getStrengthBonus() {
		return strengthBonus;
	}

	public int getStaminaBonus() {
		return staminaBonus;
	}

	public void setStaminaBonus(int staminaBonus) {
		this.staminaBonus = staminaBonus;
	}

	public int getIntellectBonus() {
		return intellectBonus;
	}

	public void setIntellectBonus(int intellectBonus) {
		this.intellectBonus = intellectBonus;
	}

	public int getAgilityBonus() {
		return agilityBonus;
	}

	public void setAgilityBonus(int agilityBonus) {
		this.agilityBonus = agilityBonus;
	}

	public void setStrengthBonus(int strengthBonus) {
		this.strengthBonus = strengthBonus;
	}

	public int getHitrollBonus() { return hitrollBonus; }

	public int getDamrollBonus() { return damrollBonus; }
	
	
	
	
} // end StatusEffect
