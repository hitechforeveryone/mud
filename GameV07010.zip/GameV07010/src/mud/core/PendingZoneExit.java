package mud.core;

public class PendingZoneExit {
    Room sourceRoom;
    Direction direction;
    private int targetWorldId;
    private int targetZoneId;
    private int targetRoomId;
    ZoneExit zoneExit;

    public PendingZoneExit(Room sourceRoom, Direction direction, int targetWorldId, int targetZoneId, int targetRoomId) {
        this.sourceRoom = sourceRoom;
        this.direction = direction;
        this.targetWorldId = targetWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
		this.zoneExit = null;
    }
    public PendingZoneExit(Room sourceRoom, Direction direction, String targetWorldId, int targetZoneId, int targetRoomId) {
        this.sourceRoom = sourceRoom;
        this.direction = direction;
        int tWorldId = Integer.parseInt(targetWorldId);
        this.targetWorldId = tWorldId;
        this.targetZoneId = targetZoneId;
        this.targetRoomId = targetRoomId;
		this.zoneExit = null;
    }
    

    public PendingZoneExit(Room sourceRoom, Direction direction, ZoneExit zoneExit) {
        this.sourceRoom = sourceRoom;
        this.direction = direction;
		this.targetWorldId = 0;
		this.targetZoneId = 0;
		this.targetRoomId = 0;
        this.zoneExit = zoneExit;
    }
    
    public Room getSourceRoom() {
        return sourceRoom;
    }

    public Direction getDirection() {
        return direction;
    }

    public int getTargetWorldId() {
        return targetWorldId;
    }

    public int getTargetZoneId() {
        return targetZoneId;
    }

    public int getTargetRoomId() {
        return targetRoomId;
    }

    public ZoneExit getZoneExit() {
        return zoneExit;
    }

	public void setSourceRoom(Room sourceRoom) {
		this.sourceRoom = sourceRoom;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public void setTargetWorldId(int targetWorldId) {
		this.targetWorldId = targetWorldId;
	}

	public void setTargetZoneId(int targetZoneId) {
		this.targetZoneId = targetZoneId;
	}

	public void setTargetRoomId(int targetRoomId) {
		this.targetRoomId = targetRoomId;
	}

	public void setZoneExit(ZoneExit zoneExit) {
		this.zoneExit = zoneExit;
	}
    
}
