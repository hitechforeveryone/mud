package mud.core;

import java.util.*;

public class MobAsPlayer extends Player {
    private final Mob mob;

    public MobAsPlayer(Mob mob) {
        super();
        this.mob = mob;

        // Copy identifiers & basic info
        this.setName(mob.getMobName());
        this.setRoom(mob.getRoom());
        this.setCurrentZone(mob.getCurrentRoom() != null ? mob.getCurrentRoom().getZone() : null);
        this.setCurrentWorld(mob.getZone() != null ? mob.getZone().getWorld() : null);
        this.setPrivilegeLevel(0);

        // Copy stats
        this.setLevel(mob.getLevel());
        this.setStrength(mob.getStrength());
        this.setStamina(mob.getStamina());
        this.setAgility(mob.getAgility());
        this.setIntellect(mob.getIntellect());
        this.setCharisma(mob.getCharisma());
        this.setMaxHP(mob.getMaxHP());
        this.setCurrentHP(mob.getCurrentHP());
        this.setMaxMP(mob.getMaxMP());
        this.setCurrentMP(mob.getCurrentMP());
        this.setReincarnateMax(mob.getReincarnateMax());
        this.setReincarnateRemaining(mob.getReincarnateRemaining());

        // Behavior and affects
        this.setBehaviorFlags(new HashSet<>(mob.getBehaviorFlags()));
        this.setAffectFlags(mob.getAffectFlags());

        // Inventory and equipment
        this.getInventory().clear();
        for (ObjectItem item : mob.getInventory()) this.getInventory().add(item.clone());
        this.getEquipment().clear();
        for (Map.Entry<EquipSlot, ObjectItem> e : mob.getEquipment().entrySet())
            this.getEquipment().put(e.getKey(), e.getValue().clone());

        // Keywords, descriptions, profession/race
        this.setShortDescription(mob.getShortDescription());
        this.setExtendedDescription(mob.getExtendedDescription());
        this.setProfession(mob.getProfession());
        this.setRace(mob.getRace());
        this.setSubrace(mob.getSubrace());
        this.setRank(mob.getRank());
        this.setKeywords(new LinkedHashSet<>(mob.getKeywords()));

        // Shop
        this.setShopKeeper(mob.isShopKeeper());
        if (mob.getShopProfile() != null) this.setShopProfile(mob.getShopProfile().copy());
        this.getShopInventory().clear();
        if (mob.getShopInventory() != null) {
            for (ObjectItem item : mob.getShopInventory()) this.addShopItem(item.clone());
        }

        // Speeches & sentry
        this.setSpeeches(new ArrayList<>(mob.getSpeeches()));
        this.setSentryDirection(mob.getSentryDirection());
        this.setSentryMessage(mob.getSentryMessage());
    }

    // Delegate all key methods to the underlying Mob
    @Override
    public void sendMessage(String msg) {
        // Optionally log or display in console
        System.out.println("[MobAsPlayer " + mob.getMobName() + "] " + msg);
    }

    @Override
    public String getName() {
        return mob.getMobName();
    }

    @Override
    public boolean isAdmin() {
        return false;
    }

    @Override
    public Room getRoom() {
        return mob.getRoom();
    }

    @Override
    public int getLevel() {
        return mob.getLevel();
    }

    @Override
    public int getStrength() {
        return mob.getStrength();
    }

    @Override
    public int getStamina() {
        return mob.getStamina();
    }

    @Override
    public int getAgility() {
        return mob.getAgility();
    }

    @Override
    public int getIntellect() {
        return mob.getIntellect();
    }
    
    @Override
    public int getCharisma() {
        return mob.getCharisma();
    }

    @Override
    public int getCurrentHP() {
        return mob.getCurrentHP();
    }

    @Override
    public int getMaxHP() {
        return mob.getMaxHP();
    }

    @Override
    public int getCurrentMP() {
        return mob.getCurrentMP();
    }

    @Override
    public int getMaxMP() {
        return mob.getMaxMP();
    }

    @Override
    public boolean hasEffect(EffectType effect) {
        return mob.hasEffect(effect);
    }

    @Override
    public boolean hasAffect(MobAffectFlag flag) {
        return mob.hasAffect(flag);
    }

    @Override
    public void addEffect(EffectType effect) {
        mob.addEffect(effect);
    }

    @Override
    public void removeEffect(EffectType effect) {
        mob.removeEffect(effect);
    }

    @Override
    public List<ObjectItem> getInventory() {
        return mob.getInventory();
    }

    @Override
    public Map<EquipSlot, ObjectItem> getEquipment() {
        return mob.getEquipment();
    }

    public void moveToRoom(Room room) {
        mob.setCurrentRoom(room);
    }

    // Add more overrides as needed for commands to work correctly
}
