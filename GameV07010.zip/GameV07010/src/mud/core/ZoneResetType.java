package mud.core;

public enum ZoneResetType {
    NEVER, // 0
    WHEN_EMPTY, // 1
    ALWAYS, //2
    RESET_AND_UNLOAD //3
}