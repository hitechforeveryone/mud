package mud.core;

public enum WeaponType {
    NONE,
    SWORD,
    DAGGER,
    HAMMER,
    AXE,
    SPEAR,
    WHIP,
    RANGED;

    public static WeaponType fromString(String input) {
        if (input == null) return null;
        String normalized = input.trim().toLowerCase();
        switch (normalized) {
            case "none": return NONE;
            case "sword": return SWORD;
            case "dagger": return DAGGER;
            case "hammer": return HAMMER;
            case "axe": return AXE;
            case "spear": return SPEAR;
            case "whip": return WHIP;
            case "ranged": return RANGED;
            default: return null;
        }
    }
} // end WeaponType
