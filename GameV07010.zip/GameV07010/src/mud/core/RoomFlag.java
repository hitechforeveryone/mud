package mud.core;

public enum RoomFlag {
    BORDER       (1 << 0), // TODO
    FALL         (1 << 1),
    NOMOB        (1 << 2),
    SCRIPTED     (1 << 3), // TODO
    UNDERWATER   (1 << 4),
    OUTSIDE      (0 << 5),
    DARK         (1 << 6),
    TUNNEL       (1 << 7),
    CAMP         (1 << 8),
    RENT         (1 << 9),
    DUMP         (1 << 10), // TODO
    ON_WATER	 (1 << 11),
    QUIET		(1 << 12),
    NOSUMMON	(1 << 13),
    LIT			(1 << 14);
	

    private final int bit;

    RoomFlag(int bit) {
        this.bit = bit;
    }

    public int getBit() {
        return bit;
    }
}
