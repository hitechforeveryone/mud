package mud.core;

import java.util.*;

import mud.config.Config;
import mud.editor.WorldEditor;
import mud.system.GameClock;

public class World {
	
	private String worldId;
	private String name;
	private String Owner;
	private Map<Integer, Zone> zones = new HashMap<>();
	int startingZoneId = Config.DEFAULT_LOGIN_ZONE;
	private int startingRoomNumber;
	private GameClock clock;
	private List<Moon> moons = new ArrayList<>();
	WorldEditor editor; // ✅ prevents it from being serialized
	public List<Room> rooms = new ArrayList<>();
    
    
	public World() {
	    // Set up defaults or leave fields unset until populated manually
		this.worldId = "0";
		this.name = "dummy world";

	}

	
    public World(String worldId, String name, GameClock clock) {
        this.worldId = worldId.toLowerCase();
        this.moons = new ArrayList<>(); // ✅ This line must exist
        this.name = name;
        this.clock = clock;
    }

    public String getWorldId() {
        return worldId;
    }

    public String getName() {
        return name;
    }

    public GameClock getClock() {
        return clock;
    }

    public void addZone(int id, Zone zone) {
        zones.put(id, zone);
      //  zone.setWorld(this);
    }

    public Zone getZone(int id) {
        return zones.get(id);
    }

    public Collection<Zone> getZones() {
        return zones.values(); // if zones is a Map<String, Zone>
    }

    public Room getRoom(int zoneId, int roomNumber) {
        Zone zone = getZone(zoneId);
        return (zone != null) ? zone.getRoom(roomNumber) : null;
    }

    public void setStartingLocation(int zoneId, int roomNumber) {
        this.startingZoneId = zoneId;
        this.startingRoomNumber = roomNumber;
    }

    public Room getStartingRoom() {
    	//startingZoneId = -1; // means "not set"

        if (startingZoneId != -1) {
            Zone zone = zones.get(startingZoneId);
            return (zone != null) ? zone.getRoom(startingRoomNumber) : null;
        }

        // fallback: first zone + room 0
        List<Integer> sorted = new ArrayList<>(zones.keySet());
        Collections.sort(sorted);
        if (!sorted.isEmpty()) {
            Zone first = zones.get(sorted.get(0));
            return (first != null) ? first.getRoom(0) : null;
        }

        return null;
    }
    public List<Room> getRooms() {
        List<Room> allRooms = new ArrayList<>();
        for (Zone zone : getZones()) {
            allRooms.addAll(zone.getRooms().values());
        }
        return allRooms;
    }



    // Optional: Calendar accessors via clock
    public String getCurrentDate() {
        return clock.getCurrentDateString();
    }

    public boolean isNight() {
        return clock.isNight();
    }

    public boolean isDay() {
        return clock.isDay();
    }

	public int getStartingZoneId() {
		return startingZoneId;
	}

	public void setStartingZoneId(int startingZoneId) {
		this.startingZoneId = startingZoneId;
	}

	public int getStartingRoomNumber() {
		return startingRoomNumber;
	}

	public void setStartingRoomNumber(int startingRoomNumber) {
		this.startingRoomNumber = startingRoomNumber;
	}

	public String getOwner() {
		return Owner;
	}

	public void setOwner(String owner) {
		Owner = owner;
	}

	public void setWorldId(String worldId) {
		this.worldId = worldId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setZones(Map<Integer, Zone> zones) {
		this.zones = zones;
	}

	public void setClock(GameClock clock) {
		this.clock = clock;
	}

    public void addMoon(Moon moon) {
        moons.add(moon);
    }

    public List<Moon> getMoons() {
        return this.moons;
    }
	
    public void removeZone(int zoneId) {
    	
        zones.remove(zoneId);
    }

	
} // end World
