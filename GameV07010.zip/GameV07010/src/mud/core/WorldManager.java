package mud.core;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import mud.Shop.*;
import mud.config.*;
import mud.scripting.*;
import mud.system.*;

public class WorldManager {

	// --- Global Game Clock (shared across all worlds) ---
	public static final CalendarSystem GLOBAL_CALENDAR = new CalendarSystem();
	public static final GameClock GLOBAL_CLOCK = new GameClock(GLOBAL_CALENDAR);

	static {
		GLOBAL_CLOCK.start();

		CalendarSystem calendar = GLOBAL_CLOCK.getCalendar();
		// set some default defaults from CalendarSystem
		calendar.setDaysPerWeek(6);
		calendar.setWeeksPerMonth(5);
		calendar.setMonthsPerYear(12);
		calendar.setDayNames(List.of("Primeday", "Twosday", "Threesday", "Foursday", "Fiveday", "Sixthday"));
		calendar.setMonthNames(List.of(
				"Frostmere", "Snowwane", "Thawmarch", "Rainfell", "Bloomreach", "Sungold",
				"Emberbright", "Dustcall", "Harvestwane", "Coldfall", "Starwatch", "Yearsend"
				));

	}

	public static GameClock getGlobalClock() {
		return GLOBAL_CLOCK;
	}

	// --- Primary registries ---
	// worldId (lowercased) -> World
	private static final Map<String, World> worlds = new ConcurrentHashMap<>();
	// composite key "worldId:zoneId" -> Zone (prevents collisions across worlds)
	private static final Map<String, Zone> zonesByKey = new ConcurrentHashMap<>();
	// active players keyed by lowercase player name
	private static final Map<String, Player> activePlayers = new ConcurrentHashMap<>();
	private static final List<Player> onlinePlayers = Collections.synchronizedList(new ArrayList<>());
	// global object and mob registries
	public static final Map<Integer, ObjectItem> objects = new ConcurrentHashMap<>();
	private static final List<Mob> globalMobList = Collections.synchronizedList(new ArrayList<>());
	private static final List<ObjectItem> globalObjList = Collections.synchronizedList(new ArrayList<>());

	// optional current world pointer
	private static volatile World currentWorld;

	// small helper classes used by loaders
	static class PendingExit {
		Room fromRoom;
		Direction direction;
		int targetRoomId;

		PendingExit(Room fromRoom, Direction direction, int targetRoomId) {
			this.fromRoom = fromRoom;
			this.direction = direction;
			this.targetRoomId = targetRoomId;
		}
	}

	// -------------------------
	// World management helpers
	// -------------------------

	private static String normalizeWorldId(String worldId) {
		return worldId == null ? null : worldId.toLowerCase();
	}

	private static String zoneKey(String worldId, int zoneId) {
		return normalizeWorldId(worldId) + ":" + zoneId;
	}

	// store world under canonical worldId (lowercased)
	public static void addWorld(World world) {
		if (world == null || world.getWorldId() == null) return;
		worlds.put(normalizeWorldId(world.getWorldId()), world);
	}

	public static void registerWorld(World world) {
		if (world == null || world.getWorldId() == null) return;
		worlds.put(normalizeWorldId(world.getWorldId()), world);
	}

	public static World getWorld(String id) {
		if (id == null) return null;
		return worlds.get(normalizeWorldId(id));
	}

	// convenience numeric lookup (preserves behavior for callers that pass ints)
	public static World getWorld(int id) {
		return getWorld(String.valueOf(id));
	}

	// legacy method: returns world by display name (not a recommended lookup)
	public static World getWorldByName(String name) {
		if (name == null) return null;
		for (World w : worlds.values()) {
			if (w.getName() != null && w.getName().equalsIgnoreCase(name)) return w;
		}
		return null;
	}

	public static Collection<World> getAllWorlds() {
		return worlds.values();
	}

	public static List<String> getWorldNames() {
		List<String> names = new ArrayList<>(worlds.keySet());
		Collections.sort(names);
		return names;
	}

	public static void setWorld(World world) {
		currentWorld = world;
	}

	public static World getWorld() {
		return currentWorld;
	}

	// -------------------------
	// Zone registry (composite-key)
	// -------------------------

	public static void registerZone(World world, Zone zone) {
		if (world == null || zone == null) return;
		zone.setParentWorld(world);
		zone.setWorld(world);
		String key = zoneKey(world.getWorldId(), zone.getZoneId());
		zonesByKey.put(key, zone);
		// also make sure the world has the zone
		world.addZone(zone.getZoneId(), zone);
	}



	// fallback: find zone by id across any world (ambiguous — use carefully)
	public static Zone getZone(int zoneId) {
		for (Zone z : zonesByKey.values()) {
			if (z.getZoneId() == zoneId) return z;
		}
		return null;
	}

	// gather all zones (across all worlds)
	public static Collection<Zone> getAllZones() {
		return zonesByKey.values();
	}

	// -------------------------
	// Player management
	// -------------------------

	public static void addPlayer(Player player) {
		if (player == null || player.getName() == null) return;
		String key = player.getName().toLowerCase();
		activePlayers.put(key, player);
		synchronized (onlinePlayers) {
			if (!onlinePlayers.contains(player)) {
				onlinePlayers.add(player);
			}
		}
	}

	public static void removePlayer(Player player) {
		if (player == null || player.getName() == null) return;
		activePlayers.remove(player.getName().toLowerCase());
		synchronized (onlinePlayers) {
			onlinePlayers.remove(player);
		}
	}

	public static List<Player> getAllPlayers() {
		synchronized (onlinePlayers) {
			return new ArrayList<>(onlinePlayers);
		}
	}

	public static Player getPlayer(String name) {
		if (name == null) return null;
		return activePlayers.get(name.toLowerCase());
	}

	public static Player getPlayerByName(String name) {
		return getPlayer(name);
	}

	public static List<String> getActivePlayerNames() {
		List<String> names = new ArrayList<>();
		for (Player p : activePlayers.values()) {
			names.add(p.getName());
		}
		return names;
	}

	public static List<Player> getActivePlayers() {
		return new ArrayList<>(activePlayers.values());
	}

	// -------------------------
	// World / Zone creation utilities
	// -------------------------

	// Create a new world with at least a login zone
	public static World createWorld(String worldId) {
		if (worldId == null) throw new IllegalArgumentException("worldId cannot be null");
		String normalized = normalizeWorldId(worldId);
		World world = new World(normalized, Config.DEFAULT_WORLD_ID, GLOBAL_CLOCK);
		world.setWorldId(normalized);
		addWorld(world);

		int zoneId = Config.DEFAULT_LOGIN_ZONE;
		Zone newZone = new Zone();
		newZone.setZoneId(zoneId);
		registerZone(world, newZone);

		// Give zone a script
		ZoneScript script = ZoneScriptRegistry.createForZone(newZone);
		if (script == null) {
			script = new BasicZoneScript(newZone, zoneId);
		}
		newZone.setScript(script);
		newZone.initialize();

		// ensure parent links
		newZone.setParentWorld(world);
		newZone.setWorld(world);

		return world;
	}

	public static World createTithriusWorld() {
		String worldId = normalizeWorldId(Config.DEFAULT_WORLD_ID);
		int zoneId = 0;

		World world = new World(worldId, "tithrius", GLOBAL_CLOCK);
		world.setWorldId(worldId);
		world.setName("tithrius");
		world.setOwner("Aetherion, the Shaper of the Veil");
		world.setStartingZoneId(zoneId);
		world.setStartingRoomNumber(0);

		Zone zone = new Zone();
		zone.setZoneId(zoneId);
		zone.setName("The Void");
		zone.setWorld(world);
		zone.setParentWorld(world);
		zone.setClimate(Climate.VOID);
		zone.setResetType(ZoneResetType.WHEN_EMPTY);
		zone.setResetTimer(5);

		Room room = new Room();
		room.setId(0);
		room.setName("Starting Room");
		room.setDescription("An empty, dull room.");
		room.setZone(zone);
		zone.addRoom(room.getId(), room);

		ZoneScript script = ZoneScriptRegistry.createForZone(zone);
		if (script == null) {
			script = new BasicZoneScript(zone, zone.getZoneId());
		}
		zone.setScript(script);

		addWorld(world);
		registerZone(world, zone);

		saveZone(zone);
		saveWorld(world);
		return world;
	}

	public static Room getStartingRoom(String worldId) {
		World world = getWorld(worldId);
		if (world == null) {
			world = createWorld(worldId);
		}

		Zone zone = world.getZone(3);
		if (zone == null) throw new IllegalStateException("Missing zone 'forest' in world: " + worldId);

		Room room = zone.getRoom(0);
		if (room == null) throw new IllegalStateException("Missing room 0 in zone: forest");

		return room;
	}

	public static Room getDefaultLoginRoom() {
		World defaultWorld = getWorld(Config.DEFAULT_WORLD_ID);
		if (defaultWorld == null) {
			throw new IllegalStateException("Default world not found.");
		}

		Zone defaultZone = defaultWorld.getZone(Config.DEFAULT_LOGIN_ZONE);
		if (defaultZone == null) {
			throw new IllegalStateException("Default login zone " + Config.DEFAULT_LOGIN_ZONE + " not found.");
		}

		Room defaultRoom = defaultZone.getRoom(Config.DEFAULT_LOGIN_ROOM);
		if (defaultRoom == null) {
			throw new IllegalStateException("Default login room " + Config.DEFAULT_LOGIN_ROOM
					+ " not found in zone '" + defaultZone.getName() + "'.");
		}

		return defaultRoom;
	}

	// -------------------------
	// Room lookups
	// -------------------------

	public static Room getRoomFromIds(String worldId, int zoneId, int roomId) {
		if (worldId == null) return null;
		World world = getWorld(worldId);
		if (world == null) return null;
		Zone zone = world.getZone(zoneId);
		if (zone == null) return null;
		return zone.getRoom(roomId);
	}



	// Ambiguous global room-by-id — returns first found (use only for debugging)
	public static Room getRoomById(int roomId) {
		for (World w : getAllWorlds()) {
			for (Zone z : w.getZones()) {
				Room r = z.getRoomById(roomId);
				if (r != null) return r;
			}
		}
		return null;
	}

	// -------------------------
	// Persistence: save/load worlds/zones
	// -------------------------

	public static boolean saveWorld(World world) {
		if (world == null || world.getWorldId() == null) return false;

		File dir = new File(Config.WORLDS_DIR);
		dir.mkdirs();
		File file = new File(dir, world.getWorldId().toLowerCase() + ".world.txt");

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
			writer.write("World Name: " + world.getName() + "\n");
			writer.write("World ID: " + world.getWorldId() + "\n");
			writer.write("Owner: " + world.getOwner() + "\n");
			writer.write("Starting Zone: " + world.getStartingZoneId() + "\n");
			writer.write("Starting Room: " + world.getStartingRoomNumber() + "\n");
		
			List<Moon> moons = world.getMoons();
			writer.write("Moons: " + moons.size() + "\n");
			for (Moon moon : moons) {
				writer.write("  Moon: " + moon.getName() + "\n");
				writer.write("    OrbitDays: " + moon.getOrbitDays() + "\n");
				writer.write("    MoonPhase: " + moon.getPhase() + "\n");			
			}

			world.getClock();
			// when saving world
			writer.write("Tick: " + world.getClock().getTickCounter() + "\n");

			
			// Sort zones numerically by ZoneId
			List<Zone> zones = new ArrayList<>(world.getZones());
			zones.sort(Comparator.comparingInt(Zone::getZoneId));

			writer.write("Zones: " + zones.size() + "\n");
			for (Zone zone : zones) {
				writer.write("  Zone " + zone.getZoneId() + ": " + zone.getName() + "\n");
			}

			return true;
		} catch (IOException e) {
			System.err.println("Failed to save world: " + e.getMessage());
			return false;
		}
	} // end


	public static void loadAll() {
		File dir = new File(Config.WORLDS_DIR);
		if (!dir.exists()) return;
		File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".world.txt"));
		if (files == null) return;
		for (File file : files) {
			World w = loadWorldFromFile(file);
			if (w != null) {
				registerWorld(w);
				System.out.println("✅ Loaded world: " + w.getWorldId() + " (" + w.getName() + ")");
			}
		}
		// testAllWorldsTraversal();
	}

	private static World loadWorldFromFile(File file) {
		String name = file.getName();
		if (!name.endsWith(".world.txt")) return null;
		String id = name.substring(0, name.indexOf(".world.txt"));
		return loadWorld(id);
	}

	public static World loadWorld(String worldId) {
		if (worldId == null) return null;

		File file = new File(Config.WORLDS_DIR, normalizeWorldId(worldId) + ".world.txt");
		if (!file.exists()) {
			System.err.println("World file not found: " + file.getAbsolutePath());
			return null;
		}

		World world = new World();
		world.setClock(GLOBAL_CLOCK);
		GameClock clock = world.getClock();

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			Moon currentMoon = null;

			Map<Integer, Zone> loadedZones = new HashMap<>();

			while ((line = reader.readLine()) != null) {
				if (line.trim().isEmpty()) continue;

				// --- Moons ---
				if (line.startsWith("  Moon:")) {
					currentMoon = new Moon();
					currentMoon.setName(line.substring("  Moon:".length()).trim());

				}
				else if (line.startsWith("    OrbitDays:") && currentMoon != null) {
					try {
						int orbit = Integer.parseInt(line.substring("    OrbitDays:".length()).trim());
						currentMoon.setOrbitDays(orbit);
						world.addMoon(currentMoon);
						currentMoon = null;
					} catch (NumberFormatException ignored) {}	
				}
				else if (line.startsWith("    MoonPhase:") && currentMoon != null) {
					try {
						int orbit = Integer.parseInt(line.substring("    OrbitDays:".length()).trim());
						currentMoon.setOrbitDays(orbit);
						world.addMoon(currentMoon);
						currentMoon = null;
					} catch (NumberFormatException ignored) {}	
				}
				

				 // --- Clock ---
			    else if (line.startsWith("Tick:")) {
			        GameClock.setCurrentTick(Long.parseLong(line.substring("Tick:".length()).trim()));
			    }


				// --- Key : Value ---
				else if (line.contains(":")) {
					String[] parts = line.split(":", 2);
					String key = parts[0].trim().toLowerCase();
					String value = parts[1].trim();

					switch (key) {
					case "world name" -> world.setName(value);
					case "world id" -> world.setWorldId(value);
					case "owner" -> world.setOwner(value);
					case "starting zone", "startingzoneid" ->
						world.setStartingZoneId(Integer.parseInt(value));
					case "starting room", "startingroomnumber" ->
						world.setStartingRoomNumber(Integer.parseInt(value));

					case "zones" -> {
						while ((line = reader.readLine()) != null) {
							if (line.trim().isEmpty() || !line.startsWith("  ")) break;

							line = line.trim();
							if (line.toLowerCase().startsWith("zone")) {
								String[] zoneParts = line.split(":", 2);
								if (zoneParts.length < 2) continue;

								int zoneId = Integer.parseInt(
									zoneParts[0].replaceAll("[^0-9]", "")
								);

								Zone zone = loadZone(world.getWorldId(), zoneId);
								if (zone != null) {
									zone.setParentWorld(world);
									zone.setWorld(world);
									loadedZones.put(zone.getZoneId(), zone);
									registerZone(world, zone);
								}
							}
						}
					}
					default -> {}
					}
				}
			}

			// register world
			worlds.put(normalizeWorldId(world.getWorldId()), world);

			// load zones (safety)
			loadZonesForWorld(world);

			// lighting now reflects restored time
			boolean isNight = clock.isNight();

			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					room.setNightTime(isNight);
					room.recalculateLighting();
				}
			}

			// traversal tests
			for (Zone zone : world.getZones()) {
				testZoneTraversalCanonical(zone);
			}

			return world;

		} catch (IOException e) {
			System.err.println("Failed to load world " + worldId + ": " + e.getMessage());
			return null;
		}
	} // end


	// -------------------------
	// Zone / room loading
	// -------------------------
	// ------------------------------------------------------------
	// saveZone(zone) — Writes a zone file using your exact template
	// ------------------------------------------------------------
	public static boolean saveZone(Zone zone) {
		if (zone == null) return false;

		int worldId = Integer.parseInt( zone.getWorld().getWorldId());
		int zoneId = zone.getZoneId();

		String fileName = worldId + "_" + zoneId + ".zone.txt";
		File dir = new File(Config.ZONES_DIR);
		if (!dir.exists()) dir.mkdirs();
		File file = new File(dir, fileName);

		try (PrintWriter out = new PrintWriter(new FileWriter(file))) {

			// Header
			out.println("Zone ID: " + zoneId);
			out.println("Zone Name: " + zone.getName());
			out.println("Zone Owner: " + zone.getOwner());
			out.println("World ID: " + worldId);
			out.println("Climate: " + zone.getClimate());
			out.println("Reset Type: " + zone.getResetType());
			out.println("Reset Timer: " + zone.getResetTimer());
			out.println("Rooms:");

			// Rooms block
			for (Room room : zone.getRooms().values()) {
				out.println("  Room ID: " + room.getId());
				out.println("  Name: " + room.getName());
				out.println("  Short Description: " + room.getShortDescription());
				out.println("  Description: " + room.getDescription());
				out.println("  Tunnel Limit: " + room.getTunnelNum());
				out.println("  Flags: ");

				// Exits
				out.println("  Exits:");
				room.getExits().forEach((direction, exit) -> {
					out.println("    Direction: " + direction.name());
					out.println("    Target Room ID: " + exit.getId());
				});

				// Zone Exits
				out.println("  ZoneExits:");
				room.getZoneExits().forEach((direction, ze) -> {
					out.println("    Direction: " + direction.name());
					out.println("    Target World ID: " + ze.getTargetWorldId());
					out.println("    Target Zone ID: " + ze.getTargetZoneId());
					out.println("    Target Room ID: " + ze.getTargetRoomId());
				});

				// Doors
				out.println("  Doors:");
				room.getDoors().forEach((direction, door) -> {
					out.println("    Direction: " + direction.name());
					out.println("    Name: " + door.getDoorName());
					out.println("    Short Description: " + door.getShortDescription());
					out.println("    Long Description: " + door.getLongDescription());
					out.println("    Keywords: " + String.join(" ", door.getKeywords()));
					out.println("    Open: " + door.isOpen());
					out.println("    Locked: " + door.isLocked());
					out.println("    Lockable: " + door.isLockable());
					out.println("    Hidden: " + door.isHidden());
					out.println("    doorKey: " + door.getDoorKeyId());


				}          
						);
				out.println("");
			}

		} catch (IOException e) {
			System.err.println("Failed to save zone " + zoneId + " in world " + worldId);
			e.printStackTrace();
		}
		return true;
	}
	
	public static Zone getZone(String worldId, int zoneId) {
	    for (Zone z : zonesByKey.values()) {
	        if (z.getZoneId() == zoneId && z.getParentWorld() != null && z.getParentWorld().getWorldId().equals(worldId)) {
	            return z;
	        }
	    }
	    return null;
	}

	public static Room getRoom(String worldId, int zoneId, int roomId) {
	    Zone z = getZone(worldId, zoneId);
	    return (z != null) ? z.getRoom(roomId) : null;
	}

	
	/*
	public static void testZoneTraversalWithZoneExits(Zone zone) {
	    if (zone == null) {
	        System.err.println("[ERROR] Zone is null!");
	        return;
	    }

	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    Map<Integer, Room> allRooms = zone.getRooms();
	    System.out.println("Zone " + zone.getZoneId() + " rooms loaded: " + allRooms.size());

	    if (allRooms.isEmpty()) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    // Ensure all exits point to canonical room objects
	    for (Room room : allRooms.values()) {
	        for (Direction dir : Direction.values()) {
	            if (dir == Direction.NONE) continue;
	            Room target = room.getExit(dir);
	            if (target != null && allRooms.containsKey(target.getId())) {
	                room.setExit(dir, allRooms.get(target.getId()));
	            }
	        }
	        // Canonicalize ZoneExits as well
	        for (ZoneExit ze : room.getZoneExits()) {
	            int targetId = ze.getTargetRoomId();
	            if (allRooms.containsKey(targetId)) {
	                ze.setTargetRoom(allRooms.get(targetId));
	            }
	        }
	    }

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    Room startRoom = allRooms.values().iterator().next();
	    visited.add(startRoom.getId());
	    queue.add(startRoom);

	    while (!queue.isEmpty()) {
	        Room current = queue.poll();

	        // Traverse normal exits
	        for (Direction dir : Direction.values()) {
	            if (dir == Direction.NONE) continue;
	            Room next = current.getExit(dir);
	            if (next != null && !visited.contains(next.getId())) {
	                visited.add(next.getId());
	                queue.add(next);
	            }
	        }

	        // Traverse ZoneExits
	        for (ZoneExit ze : current.getZoneExits()) {
	            Room target = ze.getTargetRoom();
	            if (target != null && !visited.contains(target.getId())) {
	                visited.add(target.getId());
	                queue.add(target);
	            }
	        }
	    }

	    // Report unreachable rooms
	    if (visited.size() == allRooms.size()) {
	        System.out.println("✅ Zone " + zone.getZoneId() + " traversal successful: all " + visited.size() + " rooms reachable.");
	    } else {
	        Set<Integer> missing = new HashSet<>(allRooms.keySet());
	        missing.removeAll(visited);

	        System.err.println("❌ Traversal failed for Zone " + zone.getZoneId() + " in World " + worldId +
	                ": visited " + visited.size() + "/" + allRooms.size() + " rooms.");
	        System.err.println(" → Unreachable Room IDs: " + missing);

	        for (Integer id : missing) {
	            Room r = allRooms.get(id);
	            if (r != null) {
	                System.err.println("    " + id + ": " + r.getName());
	            }
	        }
	    }

	    // Optional: Print all ZoneExits in the zone
	    System.out.println("\nZoneExits in Zone " + zone.getZoneId() + ":");
	    for (Room room : allRooms.values()) {
	        for (ZoneExit ze : room.getZoneExits()) {
	            System.out.println("  Room " + room.getId() + " → ZoneExit → Room " + ze.getTargetRoomId() +
	                               " (" + ze.getDirection() + ")");
	        }
	    }
	}
*/
	
	public static void testZoneTraversalCanonical(Zone zone) {
	    if (zone == null) {
	        System.err.println("[ERROR] Zone is null!");
	        return;
	    }

	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    Map<Integer, Room> allRooms = zone.getRooms();
	    
	    System.out.println("Zone " + zone.getZoneId() + " rooms loaded: " + allRooms.size()); // should print 150

	    if (allRooms.isEmpty()) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    // Start BFS from the first room in the map
	    Room startRoom = allRooms.values().iterator().next();
	    visited.add(startRoom.getId());
	    queue.add(startRoom);

	    while (!queue.isEmpty()) {
	        Room current = queue.poll();

	        for (Direction dir : Direction.values()) {
	            if (dir == Direction.NONE) continue;

	            Room next = current.getExit(dir);
	            if (next != null) {
	                int nextId = next.getId();
	                if (!visited.contains(nextId) && allRooms.containsKey(nextId)) {
	                    visited.add(nextId);
	                    queue.add(allRooms.get(nextId)); // use canonical room
	                }
	            }
	        }
	    }

	    // Report results
	    if (visited.size() == allRooms.size()) {
	        System.out.println("✅ Zone " + zone.getZoneId() + " traversal successful: all " + visited.size() + " rooms reachable.");
	    } else {
	        Set<Integer> missing = new HashSet<>(allRooms.keySet());
	        missing.removeAll(visited);

	        System.err.println("❌ Traversal failed for Zone " + zone.getZoneId() + " in World " + worldId +
	                ": visited " + visited.size() + "/" + allRooms.size() + " rooms.");
	        System.err.println(" → Unreachable Room IDs: " + missing);

	        for (Integer id : missing) {
	            Room r = allRooms.get(id);
	            if (r != null) {
	                System.err.println("    " + id + ": " + r.getName());
	            }
	        }
	    }
	}

	public static void testZoneTraversalFailOnly(Zone zone) {
	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    Map<Integer, Room> allRooms = zone.getRooms();
	    System.out.println("Zone rooms loaded: " + allRooms.size()); // should print 150

	    if (allRooms.isEmpty()) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    // Start from the first room in the zone
	    Room startRoom = allRooms.values().iterator().next();
	    queue.add(startRoom);
	    visited.add(startRoom.getId());

	    // BFS traversal
	    while (!queue.isEmpty()) {
	        Room room = queue.poll();

	        for (Direction dir : Direction.values()) {
	            if (dir == Direction.NONE) continue;

	            Room next = room.getExit(dir);
	            if (next != null && allRooms.containsKey(next.getId()) && visited.add(next.getId())) {
	                queue.add(next);
	            }
	        }
	    }

	    // Check for unreachable rooms
	    if (visited.size() != allRooms.size()) {
	        Set<Integer> missing = new HashSet<>(allRooms.keySet());
	        missing.removeAll(visited);

	        System.err.println("❌ Traversal failed for Zone " + zone.getZoneId() + " in World " + worldId +
	                ": visited " + visited.size() + "/" + allRooms.size() + " rooms.");
	        System.err.println(" → Unreachable Room IDs: " + missing);

	        for (Integer id : missing) {
	            Room r = allRooms.get(id);
	            if (r != null) {
	                System.err.println("    " + id + ": " + r.getName());
	            }
	        }
	    } else {
	        System.out.println("✅ Zone " + zone.getZoneId() + " traversal successful: all " + visited.size() + " rooms reachable.");
	    }
	}


	
	public static void testZoneTraversalRobust(Zone zone) {
	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    // Start at first room
	    Room startRoom = zone.getRooms().values().stream().findFirst().orElse(null);
	    if (startRoom == null) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    queue.add(startRoom);
	    visited.add(startRoom.getId());

	    System.out.println("Starting BFS traversal from Room " + startRoom.getId() + " (" + startRoom.getName() + ")");

	    while (!queue.isEmpty()) {
	        Room room = queue.poll();

	        System.out.println("Visiting Room " + room.getId() + " (" + room.getName() + ")");

	        // Check all 10 directions
	        for (Direction dir : Direction.values()) {
	            if (dir == Direction.NONE) continue; // skip NONE
	            Room next = room.getExit(dir);
	            if (next != null) {
	                System.out.println("  Exit " + dir + " → Room " + next.getId() + " (" + next.getName() + ")");
	                if (visited.add(next.getId())) {
	                    queue.add(next);
	                }
	            }
	        }
	    }

	    // Detect unreachable rooms
	    Set<Integer> allRoomIds = zone.getRooms().keySet();
	    if (visited.size() != allRoomIds.size()) {
	        Set<Integer> missing = new HashSet<>(allRoomIds);
	        missing.removeAll(visited);
	        System.err.println("❌ Traversal failed for Zone " + zone.getZoneId() + " in World " + worldId +
	                ": visited " + visited.size() + "/" + allRoomIds.size() + " rooms.");
	        System.err.println(" → Unreachable Room IDs: " + missing);
	        for (Integer id : missing) {
	            Room r = zone.getRooms().get(id);
	            if (r != null) {
	                System.err.println("    " + id + ": " + r.getName());
	            }
	        }
	    } else {
	        System.out.println("✅ Zone " + zone.getZoneId() + " traversal successful: all " + visited.size() + " rooms reachable.");
	    }
	}


	public static void testZoneTraversal2(Zone zone) {
	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    // Start at first room
	    Room startRoom = zone.getRooms().values().stream().findFirst().orElse(null);
	    if (startRoom == null) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    queue.add(startRoom);
	    visited.add(startRoom.getId());
	    while (!queue.isEmpty()) {
	        Room room = queue.poll();

	        // Only follow normal exits within the zone
	        for (Direction dir : Direction.values()) {
	            Room next = room.getExit(dir);
	            if (next != null && visited.add(next.getId())) {
	                queue.add(next);
	            }
	        }

            int sourceZoneId = (room.getZone() != null)
                    ? room.getZone().getZoneId()
                    : -1;
	        
	        // Report zone exits for completeness but don't traverse them
	        for (Direction dir : Direction.values()) {
	            ZoneExit ze = room.getZoneExit(dir);
	            if (ze != null) {
	                Room target = getRoom(ze.getWorldId(), ze.getZoneId(), ze.getRoomId());
	                if (target == null) {
	                	System.err.printf(
	                		    "[ZONE EXIT ERROR]%n" +
	                		    "  Source:%n" +
	                		    "    World : %s%n" +
	                		    "    Zone  : %d%n" +
	                		    "    Room  : %d (%s)%n" +
	                		    "    Dir   : %s%n" +
	                		    "    File  : %s_%d.zone.txt%n" +
	                		    "  Target:%n" +
	                		    "    World : %s%n" +
	                		    "    Zone  : %d%n" +
	                		    "    Room  : %d%n%n",
	                		    worldId,              // String
	                		    sourceZoneId,         // int
	                		    room.getId(),         // int
	                		    room.getName(),       // String
	                		    dir,                  // enum → %s
	                		    worldId,              // String for filename
	                		    sourceZoneId,         // int for filename
	                		    ze.getWorldId(),      // String
	                		    ze.getZoneId(),       // int
	                		    ze.getRoomId()        // int
	                		);


	                }
	            }
	        }
	    }


	    // Only report if traversal did NOT reach all rooms
	    if (visited.size() != zone.getRooms().size()) {
	        System.err.println("❌ Traversal failed for Zone " + zone.getZoneId() + " in World " + worldId +
	                ": visited " + visited.size() + "/" + zone.getRooms().size() + " rooms.");
	        Set<Integer> missing = new HashSet<>(zone.getRooms().keySet());
	        missing.removeAll(visited);
	        System.err.println(" → Unreachable Room IDs: " + missing);
	    } else {
	        System.out.println("✅ Zone " + zone.getZoneId() + " traversal successful: all " + visited.size() + " rooms reachable.");
	    }
	}

	
	public static void testZoneTraversal(Zone zone) {
	    World world = zone.getWorld();
	    String worldId = world != null ? world.getWorldId() : "UNKNOWN";

	    System.out.println("🌐 Testing Zone: " + zone.getZoneId() + " (" + zone.getName() + ") in World: " + worldId);

	    Set<Integer> visited = new HashSet<>();
	    Queue<Room> queue = new LinkedList<>();

	    // Start at first room
	    Room startRoom = zone.getRooms().values().stream().findFirst().orElse(null);
	    if (startRoom == null) {
	        System.err.println("[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!");
	        return;
	    }

	    queue.add(startRoom);
	    visited.add(startRoom.getId());

	    while (!queue.isEmpty()) {
	        Room room = queue.poll();
	        System.out.println("Visiting Room " + room.getId() + " (" + room.getName() + ")");

	        for (Direction dir : Direction.values()) {
	            // Check normal exits
	            Room next = room.getExit(dir);
	            if (next != null && !visited.contains(next.getId())) {
	                System.out.println(" → Moving " + dir + " to Room " + next.getId() + " (" + next.getName() + ")");
	                visited.add(next.getId());
	                queue.add(next);
	            }

	            // Check zone exits
	            ZoneExit ze = room.getZoneExit(dir);
	            if (ze != null) {

	                int sourceZoneId = (room.getZone() != null)
	                        ? room.getZone().getZoneId()
	                        : -1;

	                Room target = getRoom(ze.getWorldId(), ze.getZoneId(), ze.getRoomId());

	                if (target == null) {
	                    System.err.printf(
	                        "%n[ZONE EXIT ERROR]%n" +
	                        "  Source:%n" +
	                        "    World : %s%n" +
	                        "    Zone  : %d%n" +
	                        "    Room  : %d (%s)%n" +
	                        "    Dir   : %s%n" +
	                        "    File  : %s_%d.zone.txt%n" +
	                        "  Target:%n" +
	                        "    World : %s%n" +
	                        "    Zone  : %d%n" +
	                        "    Room  : %d%n%n",
	                        worldId,
	                        sourceZoneId,
	                        room.getId(),
	                        room.getName(),
	                        dir,
	                        worldId, sourceZoneId,
	                        ze.getWorldId(),
	                        ze.getZoneId(),
	                        ze.getRoomId()
	                    );
	                    continue;
	                }

	                if (visited.contains(target.getId())) {
	                    System.out.println(
	                        " ↺ ZoneExit " + dir + " → " +
	                        ze.getWorldId() + "/" + ze.getZoneId() + "/" + ze.getRoomId() +
	                        " (" + target.getName() + ") [already visited]"
	                    );
	                    continue;
	                }

	                System.out.println(
	                    " ↗ ZoneExit " + dir + " → " +
	                    ze.getWorldId() + "/" + ze.getZoneId() + "/" + ze.getRoomId() +
	                    " (" + target.getName() + ")"
	                );

	                visited.add(target.getId());
	                queue.add(target);
	            }

	            
	            
	        }
	    }

	    System.out.println("✅ Traversal complete for Zone " + zone.getZoneId() + " in World " + worldId +
	        ": visited " + visited.size() + "/" + zone.getRooms().size() + " rooms.");
	}

	public static void testAllWorldsTraversal() {
	    Collection<World> allWorlds = getAllWorlds();
	    List<String> missingExitsReport = new ArrayList<>();

	    for (World world : allWorlds) {
	        String worldId = world.getWorldId();
	        System.out.println("🌍 Traversing World: " + worldId);

	        for (Zone zone : world.getZones()) {
	            System.out.println("  🔹 Zone " + zone.getZoneId() + " (" + zone.getName() + ")");
	            Set<Integer> visited = new HashSet<>();
	            Queue<Room> queue = new LinkedList<>();

	            Room startRoom = zone.getRooms().values().stream().findFirst().orElse(null);
	            if (startRoom == null) {
	                String msg = "[ERROR] Zone " + zone.getZoneId() + " in World " + worldId + " has no rooms!";
	                System.err.println(msg);
	                missingExitsReport.add(msg);
	                continue;
	            }

	            queue.add(startRoom);
	            visited.add(startRoom.getId());

	            while (!queue.isEmpty()) {
	                Room room = queue.poll();
	                for (Direction dir : Direction.values()) {
	                    // Normal exits
	                    Room next = room.getExit(dir);
	                    if (next != null && !visited.contains(next.getId())) {
	                        visited.add(next.getId());
	                        queue.add(next);
	                    }

	                    // Zone exits
	                    ZoneExit ze = room.getZoneExit(dir);
	                    if (ze != null) {
	                        Room target = getRoom(ze.getWorldId(), ze.getZoneId(), ze.getRoomId());
	                        if (target != null && !visited.contains(target.getId())) {
	                            visited.add(target.getId());
	                            queue.add(target);
	                        } else {
	                            String msg = String.format("[MISSING] ZoneExit from Room %d (%s) in Zone %d, World %s → target %s/%d/%d",
	                                    room.getId(), room.getName(), zone.getZoneId(), worldId,
	                                    ze.getWorldId(), ze.getZoneId(), ze.getRoomId());
	                            System.err.println(msg);
	                            missingExitsReport.add(msg);
	                        }
	                    }
	                }
	            }

	            System.out.println("    ✅ Traversal complete: visited " + visited.size() + "/" + zone.getRooms().size() + " rooms.");
	        }
	    }

	    // Final report
	    System.out.println("\n===== FULL TRAVERSAL REPORT =====");
	    if (missingExitsReport.isEmpty()) {
	        System.out.println("All zones and exits are valid! 🎉");
	    } else {
	        System.out.println("Found missing exits/rooms:");
	        missingExitsReport.forEach(System.out::println);
	    }
	}


	
	
	public static Zone loadZone(String worldId, int zoneId) {
			// original, worked before we did some changes 
		File file = new File(Config.ZONES_DIR, normalizeWorldId(worldId) + "_" + zoneId + ".zone.txt");
		if (!file.exists()) {
			System.err.println("Zone file not found: " + file.getAbsolutePath());
			return null;
		}

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			Zone zone = new Zone();
			zone.setZoneId(zoneId);
			zone.setWorld(getWorld(worldId));
			zone.setParentWorld(getWorld(worldId));

			Room currentRoom = null;
			Direction currentDirection = null;
			Door currentDoor = null;
			List<PendingExit> pendingExits = new ArrayList<>();
			List<Room> parsedRooms = new ArrayList<>();

			String line;
			String pushbackLine = null;

			while (true) {
				if (pushbackLine != null) {
					line = pushbackLine;
					pushbackLine = null;
				} else {
					line = reader.readLine();
				}
				if (line == null) break;
				line = line.trim();
				if (line.isEmpty()) continue;

				if (line.startsWith("Zone ID:")) {
					zone.setZoneId(Integer.parseInt(line.substring("Zone ID:".length()).trim()));
				} else if (line.startsWith("Zone Name:")) {
					zone.setName(line.substring("Zone Name:".length()).trim());
				} else if (line.startsWith("Zone Owner:")) {
					zone.setOwner(line.substring("Zone Owner:".length()).trim());
				} else if (line.startsWith("World ID:")) {
					String parsedWorldId = line.substring("World ID:".length()).trim();
					World parsedWorld = getWorld(parsedWorldId);
						zone.setWorld(parsedWorld);
						zone.setParentWorld(parsedWorld);

				} else if (line.startsWith("Climate:")) {
					zone.setClimate(Climate.valueOf(line.substring("Climate:".length()).trim().toUpperCase()));
				} else if (line.startsWith("Reset Type:")) {
					zone.setResetType(ZoneResetType.valueOf(line.substring("Reset Type:".length()).trim().toUpperCase()));
				} else if (line.startsWith("Reset Timer:")) {
					zone.setResetTimer(Integer.parseInt(line.substring("Reset Timer:".length()).trim()));
				} else if (line.startsWith("Room ID:")) {
					if (currentRoom != null) {
						zone.addRoom(currentRoom.getId(), currentRoom);
						parsedRooms.add(currentRoom);
					}
					int roomId = Integer.parseInt(line.substring("Room ID:".length()).trim());
					currentRoom = new Room(roomId);
					currentRoom.setZone(zone);
					currentDirection = null;
					currentDoor = null;
				} else if (currentRoom != null) {
					if (line.startsWith("Name:")) {
						currentRoom.setName(line.substring("Name:".length()).trim());
					} else if (line.startsWith("Short Description:")) {
						currentRoom.setShortDescription(line.substring("Short Description:".length()).trim());
					} else if (line.startsWith("Description:")) {
						currentRoom.setDescription(line.substring("Description:".length()).trim());
					} else if (line.startsWith("Tunnel Limit:")) {
						currentRoom.setTunnelNum(Integer.parseInt(line.substring("Tunnel Limit:".length()).trim()));
					} else if (line.startsWith("Flags:")) {
						currentRoom.clearFlags();
						String flagsLine = line.substring("Flags:".length()).trim();
						if (!flagsLine.isEmpty()) {
							for (String flagStr : flagsLine.split(",")) {
								try {
									RoomFlag flag = RoomFlag.valueOf(flagStr.trim());
									currentRoom.setFlag(flag);
								} catch (IllegalArgumentException ignored) {
								}
							}
						}
					} else if (line.equals("Exits:")) {
						while ((line = reader.readLine()) != null) {
							line = line.trim();
							if (line.isEmpty()) break;
							if (line.startsWith("Direction:")) {
								currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
							} else if (line.startsWith("Target Room ID:") && currentDirection != null) {
								int targetRoomId = Integer.parseInt(line.substring("Target Room ID:".length()).trim());
								pendingExits.add(new PendingExit(currentRoom, currentDirection, targetRoomId));
								currentDirection = null;
							} else if (line.startsWith("ZoneExits:") || line.startsWith("Doors:") || line.startsWith("Room ID:")) {
								pushbackLine = line;
								break;
							}
						}
					} else if (line.equals("ZoneExits:")) {
						while ((line = reader.readLine()) != null) {
							line = line.trim();
							if (line.isEmpty()) break;
							if (line.startsWith("Direction:")) {
								currentDirection = Direction.valueOf(line.substring("Direction:".length()).trim());
							} else if (line.startsWith("Target World ID:") && currentDirection != null) {
								String targetWorldId = line.substring("Target World ID:".length()).trim();
								String zoneLine = reader.readLine().trim();
								String roomLine = reader.readLine().trim();

								int targetZoneId = Integer.parseInt(zoneLine.substring("Target Zone ID:".length()).trim());
								int targetRoomId = Integer.parseInt(roomLine.substring("Target Room ID:".length()).trim());

								ZoneExit zoneExit = new ZoneExit(targetWorldId, targetZoneId, targetRoomId, currentDirection);
								currentRoom.setZoneExit(currentDirection, zoneExit);

								Room targetRoom = getRoom(targetWorldId, targetZoneId, targetRoomId);
								if (targetRoom != null) {
									currentRoom.setExit(currentDirection, targetRoom);
								} else {
									System.out.printf("[DEBUG] targetRoom is null for %s/%d/%d%n", targetWorldId, targetZoneId, targetRoomId);
								}
								currentDirection = null;
							} else if (line.startsWith("Doors:") || line.startsWith("Room ID:") || line.startsWith("Exits:")) {
								pushbackLine = line;
								break;
							}
						}
					} else if (line.equals("Doors:")) {
						while ((line = reader.readLine()) != null) {
							line = line.trim();
							if (line.isEmpty()) break;
							if (line.startsWith("Direction:")) {
								currentDirection = Direction.fromString(line.substring("Direction:".length()).trim());
								currentDoor = new Door();
								currentRoom.setDoor(currentDirection, currentDoor);
							} else if (currentDoor != null) {
								if (line.startsWith("Name:")) {
									currentDoor.setDoorName(line.substring("Name:".length()).trim());
								} else if (line.startsWith("Short Description:")) {
									currentDoor.setShortDescription(line.substring("Short Description:".length()).trim());
								} else if (line.startsWith("Long Description:")) {
									currentDoor.setLongDescription(line.substring("Long Description:".length()).trim());
								} else if (line.startsWith("Keywords:")) {
									String kwLine = line.substring("Keywords:".length()).trim();
									currentDoor.setKeywords(kwLine.isEmpty() ? List.of() : List.of(kwLine.split(",")));
								} else if (line.startsWith("Open:")) {
									currentDoor.setOpen(Boolean.parseBoolean(line.substring("Open:".length()).trim()));
								} else if (line.startsWith("Locked:")) {
									currentDoor.setLocked(Boolean.parseBoolean(line.substring("Locked:".length()).trim()));
								} else if (line.startsWith("Lockable:")) {
									currentDoor.setLockable(Boolean.parseBoolean(line.substring("Lockable:".length()).trim()));
								}
								else if (line.startsWith("Hidden:")) {
									currentDoor.setHidden(Boolean.parseBoolean(line.substring("Hidden:".length()).trim()));
								}
								else if (line.startsWith("doorKey:")) {
									currentDoor.setDoorKeyId(Integer.parseInt(line.substring("doorKey:".length()).trim()));
								}   


								else if (line.startsWith("Room ID:") || line.startsWith("ZoneExits:") || line.startsWith("Exits:")) {
									pushbackLine = line;
									break;
								}
							}
						}
					}
				}
			}

			if (currentRoom != null && !parsedRooms.contains(currentRoom)) {
				zone.addRoom(currentRoom.getId(), currentRoom);
				parsedRooms.add(currentRoom);
			}

			for (PendingExit pe : pendingExits) {
				Room target = zone.getRoom(pe.targetRoomId);
				if (target != null) {
					pe.fromRoom.setExit(pe.direction, target);
				} else {
				//	System.err.printf("Missing room %d for exit from room %d in zone %d%n",
				//			pe.targetRoomId, pe.fromRoom.getId(), zone.getZoneId());
				}
			}

			registerZone(getWorld(worldId) != null ? getWorld(worldId) : new World(), zone);

			// attach script if present
			ZoneScript script = zone.getOrCreateScript();
			
			zone.initialize(); //

			System.out.println("✅ Attached script " + script.getZoneId() + " to zone (" + zone.getZoneId() + ":" + zone.getName() + ")");
			

			//   testZoneTraversal(zone);
			
			System.out.println("✅ Loaded zone " + zone.getZoneId() + " (" + zone.getName() + ")");
			return zone;

		} catch (IOException e) {
			System.err.println("Failed to load zone: " + e.getMessage());
			return null;
		}
	}
	


	public static void loadZonesForWorld(World world) {
		if (world == null || world.getWorldId() == null) return;
		File zoneDir = new File(Config.ZONES_DIR);
		ZoneScriptRegistry.registerDefaults(world);
		File[] files = zoneDir.listFiles((d, name) -> name.startsWith(world.getWorldId() + "_") && name.endsWith(".zone.txt"));
		if (files == null) return;

		for (File file : files) {
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				Zone zone = loadZone(world.getWorldId(), parseZoneIdFromFilename(file.getName()));
				if (zone != null) {
					zone.setParentWorld(world);
					zone.setWorld(world);
					registerZone(world, zone);
					System.out.println("✅ Attached zone " + zone.getZoneId() + " to world " + world.getWorldId());
				}
			} catch (Exception e) {
				System.err.println("Failed to load zone file: " + file.getName());
				e.printStackTrace();
			}
		}

		loadAllMobsFromDisk();
		loadAllObjsFromDisk();
	}

	private static int parseZoneIdFromFilename(String name) {
		try {
			// expected like "<worldId>_<zoneId>.zone.txt"
			String[] parts = name.split("_");
			if (parts.length < 2) return 0;
			String after = parts[parts.length - 1];
			return Integer.parseInt(after.split("\\.")[0]);
		} catch (Exception e) {
			return 0;
		}
	}


	
	// -------------------------
	// Mob / Object loaders
	// -------------------------

	// ---------------------- SAVE MOB ----------------------
	public static boolean saveMob(Mob mob) {
	    if (mob == null) return false;
	    File dir = new File(Config.MOBS_DIR);
	    dir.mkdirs();
	    File file = new File(dir, mob.getId() + ".mob.txt");

	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
	        writer.write("MobId: " + mob.getId() + "\n");
	        writer.write("MobName: " + mob.getMobName() + "\n");
	        writer.write("ShortDesc: " + mob.getShortDescription() + "\n");
	        writer.write("LongDesc: " + mob.getLongDescription() + "\n");
	        writer.write("ExtDesc: " + mob.getExtendedDescription() + "\n");
	        writer.write("Keywords: " + String.join(" ", mob.getKeywords()) + "\n");
	        writer.write("Level: " + mob.getLevel() + "\n");
	        writer.write("Profession: " + mob.getProfession() + "\n");
	        writer.write("Race: " + mob.getRace() + "\n");
	        writer.write("Subrace: " + mob.getSubrace() + "\n");
	        writer.write("Rank: " + mob.getRank() + "\n");
	        writer.write("STR: " + mob.getStrength() + "\n");
	        writer.write("STA: " + mob.getStamina() + "\n");
	        writer.write("AGI: " + mob.getAgility() + "\n");
	        writer.write("INT: " + mob.getIntellect() + "\n");
	        writer.write("CHA: " + mob.getCharisma() + "\n");
	        writer.write("HP: " + mob.getMaxHP() + "\n");
	        writer.write("MP: " + mob.getMaxMP() + "\n");
	        writer.write("ReincarnateMax: " + mob.getReincarnateMax() + "\n");
	        if (mob.getSentryDirection() != null) writer.write("SentryDir: " + mob.getSentryDirection() + "\n");
	        if (mob.getSentryMessage() != null) writer.write("SentryMsg: " + mob.getSentryMessage() + "\n");
	        writer.write("BehaviorFlags: " + String.join(",", mob.getBehaviorFlagsAsStrings()) + "\n");
	        writer.write("AffectFlags: " + String.join(",", mob.getAffectFlagsAsStrings()) + "\n");
	        if (!mob.getSpeeches().isEmpty()) writer.write("Speeches: " + String.join("|", mob.getSpeeches()) + "\n");

	        // ShopInventory
	        if (mob.isShopKeeper() && !mob.getShopInventory().isEmpty()) {
	            writer.write("ShopInventory:\n");
	            for (ObjectItem item : mob.getShopInventory()) {
	                writer.write("  " + item.getObjID() + "\n");
	            }
	        }

	        // ShopProfile
	        if (mob.getShopProfile() != null) {
	            ShopProfile profile = mob.getShopProfile();
	            writer.write("ShopProfile:\n");
	            writer.write("  BuyModifier: " + profile.getBuyModifier() + "\n");
	            writer.write("  SellModifier: " + profile.getSellModifier() + "\n");
	            writer.write("  MaxCopper: " + profile.getMaxCopper() + "\n");
	            writer.write("  Buys: " + String.join(",", profile.getBuysAsStrings()) + "\n");
	            writer.write("  Sells: " + String.join(",", profile.getSellsAsStrings()) + "\n");
	        }

	        return true;
	    } catch (IOException e) {
	        System.err.println("Failed to save mob: " + e.getMessage());
	        return false;
	    }
	}

	// ---------------------- LOAD MOB ----------------------
	public static Mob loadMob(String mobId) {
	    File file = new File(Config.MOBS_DIR, mobId + ".mob.txt");
	    if (!file.exists()) return null;

	    Mob mob = new Mob();
	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            line = line.trim();
	            if (line.isEmpty() || !line.contains(":")) continue;

	            String[] parts = line.split(":", 2);
	            String key = parts[0].trim();
	            String value = parts[1].trim();

	            switch (key) {
	                case "MobId" -> mob.setId(Integer.parseInt(value));
	                case "MobName" -> mob.setMobName(value);
	                case "ShortDesc" -> mob.setShortDescription(value);
	                case "LongDesc" -> mob.setLongDescription(value);
	                case "ExtDesc" -> mob.setExtendedDescription(value);
	                case "Keywords" -> {
	                    for (String kw : value.split(" ")) {
	                            mob.addKeyword(kw); // addKeyword() already lowercases
	                      //      System.out.println("Added keyword: '" + kw + "' to mob " + mob.getId());
	                      //     System.out.println(mob.getKeywords());
	                    }
	                }
	                case "Level" -> mob.setLevel(Integer.parseInt(value));
	                case "Profession" -> mob.setProfession(Profession.valueOf(value.toUpperCase()));
	                case "Race" -> mob.setRace(value);
	                case "Subrace" -> mob.setSubrace(value);
	                case "Rank" -> mob.setRank(MobRank.valueOf(value.toUpperCase()));
	                case "STR" -> mob.setStrength(Integer.parseInt(value));
	                case "STA" -> mob.setStamina(Integer.parseInt(value));
	                case "AGI" -> mob.setAgility(Integer.parseInt(value));
	                case "INT" -> mob.setIntellect(Integer.parseInt(value));
	                case "CHA" -> mob.setCharisma(Integer.parseInt(value));
	                case "HP" -> {
	                    mob.setMaxHP(Integer.parseInt(value));
	                    mob.setCurrentHP(mob.getMaxHP());
	                }
	                case "MP" -> {
	                    mob.setMaxMP(Integer.parseInt(value));
	                    mob.setCurrentMP(mob.getMaxMP());
	                }
	                case "ReincarnateMax" -> {
	                    int count = Integer.parseInt(value);
	                    mob.setReincarnateMax(count);
	                    mob.setReincarnateRemaining(count);
	                }
	                case "SentryDir" -> mob.setSentryDirection(value);
	                case "SentryMsg" -> mob.setSentryMessage(value);
	                case "BehaviorFlags" -> {
	                    for (String flag : value.split(",")) {
	                        try { mob.addBehavior(MobBehaviorFlag.valueOf(flag.trim().toUpperCase())); } catch (IllegalArgumentException ignored) {}
	                    }
	                }
	                case "AffectFlags" -> {
	                    if (value == null || value.isBlank()) break;

	                    for (String flagName : value.split(",")) {
	                        String flag = flagName.trim();
	                        if (flag.isEmpty()) continue;

	                        try {
	                            mob.addAffect(MobAffectFlag.valueOf(flag.toUpperCase()));
	                        } catch (IllegalArgumentException e) {
	                            System.err.println("Unknown affect flag: " + flag);
	                        }
	                    }
	                }

	                case "Speeches" -> {
	                    List<String> speeches = Arrays.stream(value.split("\\|"))
	                        .map(String::trim).filter(s -> !s.isEmpty()).toList();
	                    mob.setSpeeches(speeches);
	                }

	                case "ShopInventory" -> {
	                 //   System.out.println("[DEBUG] Loading ShopInventory for mob " + mobId);
	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) continue;
	                        if (line.contains(":")) break; // stop at next top-level key

	                        try {
	                            ObjectItem item = loadObj(line);
	                            if (item != null) {
	                                mob.addShopItem(item);
	                            //    System.out.println("[DEBUG] Added shop item: " + item.getObjID());
	                            } else {
	                                System.out.println("[DEBUG] Failed to load shop item: " + line);
	                            }
	                        } catch (NumberFormatException e) {
	                            System.err.println("[DEBUG] Invalid shop item ID: " + line);
	                        }
	                    }
	                    // outer loop will process the breaking line
	                }

	                case "ShopProfile" -> {
	                    System.out.println("[DEBUG] Loading ShopProfile for mob " + mobId);
	                    ShopProfile profile = new ShopProfile();

	                    while ((line = reader.readLine()) != null) {
	                        line = line.trim();
	                        if (line.isEmpty()) continue;
	                        if (line.contains(":")) break; // stop at next top-level key

	                        String[] parts2 = line.split(":", 2);
	                        if (parts2.length != 2) continue;

	                        String k = parts2[0].trim();
	                        String v = parts2[1].trim();

	                        switch (k) {
	                            case "BuyModifier" -> profile.setBuyModifier(Double.parseDouble(v));
	                            case "SellModifier" -> profile.setSellModifier(Double.parseDouble(v));
	                            case "MaxCopper" -> profile.setMaxCopper(Integer.parseInt(v));
	                            case "Buys" -> profile.setBuys(ObjectType.fromStringList(v.split(",")));
	                            case "Sells" -> profile.setSells(ObjectType.fromStringList(v.split(",")));
	                        }
	                    }

	                    mob.setShopProfile(profile);
	                    System.out.println("[DEBUG] Loaded ShopProfile for mob " + mobId + ": " + profile);
	                    // outer loop will process the breaking line
	                }

	                default -> {
	                	// Line doesn't match parser format anything, do nothing
	                }
	            }
	        }

	        // Ensure shopkeeper behavior is set if profile or inventory exists
	        if ((mob.getShopProfile() != null || !mob.getShopInventory().isEmpty()) &&
	            !mob.hasBehavior(MobBehaviorFlag.SHOPKEEPER)) {
	            mob.addBehavior(MobBehaviorFlag.SHOPKEEPER);
	            System.out.println("[DEBUG] Marked mob " + mob.getId() + " as SHOPKEEPER");
	        }
	        
	        /*
	        //recalibrate the mobs as they get loaded
	        mob.initialize();
	        saveMob(mob);
	        System.out.println("mob stats recalibrated");
	       */
	        
	        MobManager.registerMobTemplate(mob);
	        registerMob(mob);
	        return mob;

	    } catch (IOException e) {
	        System.err.println("Failed to load mob: " + e.getMessage());
	        return null;
	    }
	}
	// end



	public static void loadAllMobsFromDisk() {
		File dir = new File(Config.MOBS_DIR);
		File[] files = dir.listFiles((d, name) -> name.endsWith(".mob.txt"));
		if (files == null) return;
		for (File file : files) {
			String idStr = file.getName().split("\\.")[0];
			try {
				Mob mob = loadMob(idStr);
				if (mob != null) {
					MobManager.registerMobTemplate(mob);
					registerMob(mob);
				}
			} catch (Exception e) {
				System.err.println("Failed to load mob: " + idStr);
			}
		}
	}

	private static void loadAllObjsFromDisk() {
		File dir = new File(Config.OBJECTS_DIR);
		File[] files = dir.listFiles((d, name) -> name.endsWith(".Object.txt"));
		if (files == null) return;
		for (File file : files) {
			String idStr = file.getName().split("\\.")[0];
			try {
				ObjectItem obj = loadObj(idStr);
				if (obj != null) {
					ObjectManager.registerObjTemplate(obj);
					ObjectManager.addObject(obj);
					registerObj(obj);
				}
			} catch (Exception e) {
				System.err.println("Failed to load object: " + idStr);
			}
		}
	}

	public static ObjectItem loadObj(String objId) {
		File file = new File(Config.OBJECTS_DIR, objId + ".Object.txt");
		if (!file.exists()) return null;

		ObjectItem obj = new ObjectItem();
		obj.setObjID(Integer.parseInt(objId));

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (!line.contains(":")) continue;
				String[] parts = line.split(":", 2);
				String key = parts[0].trim();
				String value = parts[1].trim();
				switch (key) {
				case "Name" -> obj.setName(value);
				case "Short Description" -> obj.setShortDescription(value);
				case "Long Description" -> obj.setLongDescription(value);
				case "Extended Description" -> obj.setExtDescription(value);
                case "Keywords" -> {
                    for (String kw : value.split(" ")) {
                            obj.addKeyword(kw); // addKeyword() already lowercases

                    }
                }

				case "EquipSlots" -> {
					for (String s : value.split(" ")) {
						if (!s.isBlank()) {
							obj.setEquipSlot(EquipSlot.valueOf(s.trim().toUpperCase()));
						}
					}
				}
				case "Durability" -> {
					try {
						String[] dparts = value.split("[/]");
						int cur = Integer.parseInt(dparts[0].trim());
						int max = (dparts.length > 1) ? Integer.parseInt(dparts[1].trim()) : cur;
						obj.setDurability(cur);
						obj.setMaxDurability(max);
					} catch (Exception e) {
						System.err.println("Bad Durability format: " + value);
					}
				}
				case "Value" -> {
					String[] vals = value.split(",");
					if (vals.length == 4) {
						obj.setValueCopper(Integer.parseInt(vals[0].trim()));
						obj.setValueSilver(Integer.parseInt(vals[1].trim()));
						obj.setValueGold(Integer.parseInt(vals[2].trim()));
						obj.setValuePlatinum(Integer.parseInt(vals[3].trim()));
					}
				}
				case "ItemEffects" -> {
					if (!value.isBlank()) {
						EnumSet<ItemEffect> effects = EnumSet.noneOf(ItemEffect.class);
						for (String s : value.split(",")) {
							String trimmed = s.trim();
							if (trimmed.isEmpty()) continue;
							try {
								ItemEffect effect = ItemEffect.valueOf(trimmed.toUpperCase());
								effects.add(effect);
							} catch (IllegalArgumentException e) {
								System.err.println("Unknown ItemEffect: " + trimmed);
							}
						}
						obj.setEffects(effects);
					} else {
						obj.setEffects(EnumSet.noneOf(ItemEffect.class));
					}
				}
				case "ItemType" -> obj.setType(ObjectType.valueOf(value.toUpperCase()));
				case "WeaponType" -> obj.setWeaponType(WeaponType.valueOf(value.toUpperCase()));
				case "WeaponDamageType" -> obj.setDamageType(WeaponDamageType.valueOf(value.toUpperCase()));
				case "diceCount" -> obj.setDiceCount(Integer.parseInt(value));
				case "diceSides" -> obj.setDiceSides(Integer.parseInt(value));
				case "damageBonus" -> obj.setDamageBonus(Integer.parseInt(value));
				case "ArmorType" -> obj.setArmorType(ArmorType.valueOf(value.toUpperCase()));
				case "StrengthBonus" -> obj.setStrengthBonus(Integer.parseInt(value));
				case "StaminaBonus" -> obj.setStaminaBonus(Integer.parseInt(value));
				case "IntellectBonus" -> obj.setIntellectBonus(Integer.parseInt(value));
				case "AgilityBonus" -> obj.setAgilityBonus(Integer.parseInt(value));
				case "CharismaBonus" -> obj.setCharismaBonus(Integer.parseInt(value));
				case "hitrollBonus" -> obj.setHitrollBonus(Integer.parseInt(value));
				case "damrollBonus" -> obj.setDamrollBonus(Integer.parseInt(value));
				case "hpBonus" -> obj.setHpBonus(Integer.parseInt(value));
				case "mpBonus" -> obj.setMpBonus(Integer.parseInt(value));
				case "Vorpal" -> obj.setVorpal(Boolean.parseBoolean(value));
				case "Poisoned" -> obj.setPoisoned(Boolean.parseBoolean(value));
				case "Intelligent" -> obj.setIntelligent(Boolean.parseBoolean(value));
				case "flatDamage" -> obj.setFlatDamage(Integer.parseInt(value));
				case "IntDamType" -> {
					if (!value.isBlank()) {
						try {
							MagicDamageType dmgType = MagicDamageType.valueOf(value.toUpperCase());
							obj.setIntDamType(dmgType);
						} catch (IllegalArgumentException e) {
							obj.setIntDamType(null);
						}
					} else {
						obj.setIntDamType(null);
					}
				}
				case "Vampiric" -> obj.setVampiric(Boolean.parseBoolean(value));
				case "vampiricPercent" -> obj.setVampiricPercent(Integer.parseInt(value));
				case "Sapient" -> obj.setSapient(Boolean.parseBoolean(value));
				case "sapientSpeeches" -> {
					if (!value.isBlank()) {
						String[] lines = value.split("\\|");
						List<String> speeches = new ArrayList<>();
						for (String v : lines) {
							String trimmed = v.trim();
							if (!trimmed.isEmpty()) speeches.add(trimmed);
						}
						obj.setSapientSpeeches(speeches);
					} else {
						obj.setSapientSpeeches(new ArrayList<>());
					}
				}
				case "Stackable" -> obj.setStackable(Boolean.parseBoolean(value));
				case "StackCount" -> obj.setStackCount(Integer.parseInt(value));
				case "StackSize" -> obj.setStackSize(Integer.parseInt(value));
				case "maxStackSize" -> obj.setMaxStackSize(Integer.parseInt(value));
				case "Container" -> obj.setContainer(Boolean.parseBoolean(value));
				case "size" -> obj.setSize(Integer.parseInt(value));
				case "lockable" -> obj.setLockable(Boolean.parseBoolean(value));
				case "locked" -> obj.setLocked(Boolean.parseBoolean(value));
				case "closed" -> obj.setClosed(Boolean.parseBoolean(value));
				case "Charges" -> obj.setCharges(Integer.valueOf(value));
				case "MaxCharges" -> obj.setMaxCharges(Integer.valueOf(value));
				case "Spells" -> obj.setSpells(Arrays.asList(value.split(" ")));
				case "spellLevel" -> obj.setSpellLvl(Integer.valueOf(value));
				case "HPRestore" -> obj.setHpRestore(Integer.valueOf(value));
				case "MPRestore" -> obj.setMpRestore(Integer.valueOf(value));
				case "Duration" -> obj.setDuration(Integer.valueOf(value));
				case "AssemblesInto" -> obj.setAssemblesInto(Integer.valueOf(value));
				case "AssemblyRoot" -> obj.setAssemblyRoot(Integer.valueOf(value));
				default -> {
				}
				}
			}
			ObjectManager.registerObjTemplate(obj);
			ObjectManager.addObject(obj);
			registerObj(obj);
			return obj;
		} catch (IOException e) {
			System.err.println("Failed to load object: " + e.getMessage());
			return null;
		}
	}

	// -------------------------
	// Global registries and helpers
	// -------------------------

	public static void registerObj(ObjectItem obj) {
		if (obj != null && !globalObjList.contains(obj)) globalObjList.add(obj);
		try {
			objects.put(obj.getObjID(), obj);
		} catch (Exception ignored) {
		}
	}

	public static void unregisterObj(ObjectItem obj) {
		if (obj == null) return;
		globalObjList.remove(obj);
		objects.remove(obj.getObjID());
	}

	public static List<ObjectItem> getAllObjs() {
		List<ObjectItem> all = new ArrayList<>();
		for (World w : getAllWorlds()) {
			for (Zone z : w.getZones()) {
				all.addAll(
						z.getRoomsAsList()
						.stream()
						.flatMap(r -> r.getObjects().stream())
						.toList()
						);
			}
		}
		return all;
	}


	public static void registerMob(Mob mob) {
		if (mob != null && !globalMobList.contains(mob)) globalMobList.add(mob);
	}

	public static void unregisterMob(Mob mob) {
		if (mob == null) return;
		globalMobList.remove(mob);
	}

	public static List<Mob> getAllMobs() {
		List<Mob> all = new ArrayList<>();
		for (World w : getAllWorlds()) {
			for (Zone z : w.getZones()) {
				for (Room r : z.getRooms().values()) {
					all.addAll(r.getMobs());
				}
			}
		}
		return all;
	}

	public static Mob getMobById(int id, Room currentRoom) {
		if (currentRoom != null) {
			for (Mob m : currentRoom.getMobs()) if (m.getId() == id) return m;
		}
		for (Mob m : globalMobList) {
			if (m.getId() == id) return m;
		}
		return null;
	}

	public static Mob findMobByName(String name) {
		if (name == null || name.isBlank()) return null;
		String lower = name.toLowerCase();
		for (Zone z : getAllZones()) {
			for (Room r : z.getRooms().values()) {
				for (Mob m : r.getMobs()) {
					if (m.getMobName() != null && m.getMobName().equalsIgnoreCase(name)) return m;
					if (m.getKeywords() != null) {
						for (String kw : m.getKeywords()) if (kw.equalsIgnoreCase(lower)) return m;
					}
				}
			}
		}
		return null;
	}
	
	public static ObjectItem getObjectByIdOrName(String input) {
		try {
			int id = Integer.parseInt(input);
			return objects.get(id);
		} catch (NumberFormatException e) {
			for (ObjectItem obj : objects.values()) {
				if (obj.getName() != null && obj.getName().equalsIgnoreCase(input)) return obj;
			}
			return null;
		}
	}

	public static ObjectItem getObjectById(int id) {
		return objects.get(id);
	}

	public static void printAllWorlds() {
		for (World w : worlds.values()) {
			System.out.println("- " + w.getWorldId() + " (" + w.getName() + ")");
		}
	}

	public static String getWorldStatBlock(World world) {
		if (world == null) return "No world is currently loaded.\n";
		StringBuilder sb = new StringBuilder();
		sb.append("World ID: ").append(world.getWorldId()).append("\n");
		sb.append("World Name: ").append(world.getName()).append("\n");
		sb.append("World Owner: ").append(world.getOwner()).append("\n");
		if (world.getClock() != null) sb.append("Time: ").append(world.getClock().getFormattedTime(world)).append("\n");
		if (world.getClock() != null) sb.append("Date: ").append(world.getClock().getFormattedDate()).append("\n");
		sb.append("Zones:\n");
		List<Zone> zs = new ArrayList<>(world.getZones());
		zs.sort(Comparator.comparingInt(Zone::getZoneId));
		for (Zone z : zs) {
			sb.append(" - ").append(z.getZoneId()).append(" : ").append(z.getName()).append(" : ").append(z.getOwner()).append("\n");
		}
		return sb.toString();
	}

	public static Zone createOrAttachZone(World world, int zoneId) {
		Zone zone = world.getZone(zoneId);
		if (zone != null) return zone;

		zone = new Zone();
		zone.setZoneId(zoneId);
		zone.setWorld(world);
		zone.setParentWorld(world);

		// Use the ZoneScriptRegistry to assign a script
		ZoneScript script = ZoneScriptRegistry.createForZone(zone);
		
		
		zone.setScript(script);

		zone.initialize(); // Populate rooms/mobs if script supports it
		world.addZone(zoneId, zone);

		return zone;
	}
	
	public static World getOrCreateWorld(String worldId) {
		World world = getWorld(worldId);
		if (world != null) return world;

		System.out.println("World '" + worldId + "' not found. Creating...");

		// Create new world
		World newWorld = new World(worldId.toLowerCase(), "Generated World: " + worldId, GLOBAL_CLOCK);
		addWorld(newWorld);

		// Add at least 1 default zone
		int zoneId = Config.DEFAULT_LOGIN_ZONE;
		Zone defaultZone = createOrAttachZone(newWorld, zoneId);
		defaultZone.setName("Town of Nowhere");

		// Add fallback room if needed
		if (defaultZone.getRoom(Config.DEFAULT_LOGIN_ROOM) == null) {
			Room room = new Room(Config.DEFAULT_LOGIN_ROOM);
			room.setName("Default Room");
			room.setZone(defaultZone);
			defaultZone.addRoom(Config.DEFAULT_LOGIN_ROOM, room);
		}

		return newWorld;
	}
	
	public static boolean worldExists(String id) {
		if (id == null) return false;
		return worlds.containsKey(id.toLowerCase());
	}

	public static void unloadZone(Zone zone) {
		
		if (zone == null) return;

		// Example: remove zone from the world it belongs to
		World world = zone.getWorld();

		if (world != null) {
			zone.resetZone();
			world.removeZone(zone.getZoneId());
			System.out.println("Zone " + zone.getZoneId() + " unloaded from world " + world.getWorldId());
		} else {
			System.err.println("Cannot unload zone: zone has no associated world.");
		}

		// Additional cleanup if needed
	}

	public static void clear() {
	    worlds.clear();
	}
	// end

	

} // end WorldManager
