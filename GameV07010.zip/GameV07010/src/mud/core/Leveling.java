package mud.core;

public final class Leveling {

    private static final long BASE_EXP = 5000;
    private static final double GROWTH_RATE = 1.25;

    private Leveling() {}

    /** EXP required to go FROM this level TO the next */
    public static long getExpToNextLevel(int level) {
        level = Math.max(level, 1);
        return (long)(BASE_EXP * Math.pow(GROWTH_RATE, level - 1));
    }

    /** Total EXP required to reach a level (optional, but useful) */
    public static long getTotalExpForLevel(int level) {
        long total = 0;
        for (int i = 1; i < level; i++) {
            total += getExpToNextLevel(i);
        }
        return total;
    }
    
}
// end
