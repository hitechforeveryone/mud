package mud.core;

import java.util.List;

public interface HasKeywords {
    List<String> getKeywords();
    default boolean hasKeyword(String keyword) {
        if (keyword == null) return false;
        return getKeywords().stream().anyMatch(k -> k.equalsIgnoreCase(keyword));
    }
}
// end HasKeywords
