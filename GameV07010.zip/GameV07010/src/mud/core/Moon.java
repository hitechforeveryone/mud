package mud.core;

import mud.system.GameClock;

public class Moon {
	

	
    private String name;
    private int orbitDays;
    private int currentDay = 0;

    private MoonPhase previousPhase = null;
    
    // Eclipse tracking
    private boolean isEclipse = false; // true if eclipse occurs today
    private int eclipseDayOffset = -1; // -1 = no eclipses
    private EclipseType eclipseType = null; // null if no eclipse today
    
    
    public Moon() {
    	
    }
    public Moon(String name) {
    	this.name = name;
    }
    
    public Moon(String name, int orbitDays) {
        this.name = name;
        this.orbitDays = orbitDays;
    }
    
    public Moon(String name, int orbitDays, int eclipseDayOffset, EclipseType type) {
        this.name = name;
        this.orbitDays = orbitDays;
        this.eclipseDayOffset = eclipseDayOffset % orbitDays;
        this.eclipseType = type;
    }

    public void advance() {
        previousPhase = getPhase();
        currentDay = (currentDay + 1) % orbitDays;
        updateEclipse();
    }

    private void updateEclipse() {
        if (eclipseDayOffset < 0) {
            isEclipse = false;
            eclipseType = null;
            return;
        }

        if (currentDay == eclipseDayOffset) {
            isEclipse = true;

            // Rule: full moon ⇒ lunar, new moon ⇒ solar
            if (getPhase() == MoonPhase.FULL_MOON) {
                eclipseType = EclipseType.LUNAR;
            } else if (getPhase() == MoonPhase.NEW_MOON) {
                eclipseType = EclipseType.SOLAR;
            } else {
                // Offset hit but phase mismatch → no eclipse
                isEclipse = false;
                eclipseType = null;
            }
        } else {
            isEclipse = false;
            eclipseType = null;
        }
    }

    public boolean isEclipseDay() {
        return isEclipse;
    }

    public EclipseType getEclipseType() {
        return eclipseType;
    }
    
    /** Returns a modifier from eclipse (1 = normal light, 0 = full eclipse). */
    public double getEclipseModifier() {
        if (!isEclipseDay()) return 1.0;

        return switch (eclipseType) {
            case SOLAR -> 0.0; // full blackout
            case LUNAR -> {
                // Partial dim depending on phase
                if (getPhase() == MoonPhase.FULL_MOON) yield 0.3; // strong dim
                else yield 0.6; // mild dim for non-full lunar phases
            }
        };
    }


    // Eclipse types
    public enum EclipseType {
        LUNAR,
        SOLAR
    }
    public int getCurrentDay() {
        return currentDay;
    }

    public String getName() {
        return name;
    }

    public int getOrbitDays() {
        return orbitDays;
    }

    public boolean isFullMoon() {
        return getPhase() == MoonPhase.FULL_MOON;
    }

    public MoonPhase getPhase() {
        int phaseCount = MoonPhase.getPhaseCount();

        // Normalize current day into [0, orbitDays)
        int dayInOrbit = GameClock.getCurrentDayIndex() % orbitDays;


        // Determine phase index
        int phaseIndex = (int) ((double) dayInOrbit / orbitDays * phaseCount);

        // Safety clamp
        phaseIndex = Math.min(phaseIndex, phaseCount - 1);

        return MoonPhase.fromIndex(phaseIndex);
    }
    
    


    public boolean enteredFullMoon() {
        return getPhase() == MoonPhase.FULL_MOON &&
               previousPhase != MoonPhase.FULL_MOON;
    }
    
    public String getPhaseName() {
        return getPhase().name().replace("_", " ").toLowerCase();
    }

    /** Returns the light contribution of this moon (0 = dark, 1 = full moon). */
    public int getLightContribution() {
        if (getPhase() == MoonPhase.FULL_MOON) return 1;
        if (getPhase() == MoonPhase.WAXING_GIBBOUS || getPhase() == MoonPhase.WANING_GIBBOUS) return 1; // optional partial moonlight
        return 0;
    }

 

    
	public void setName(String name) {
		this.name = name;
	}

	public void setOrbitDays(int orbitDays) {
		this.orbitDays = orbitDays;
	}

    public void setCurrentDay(int day) {
        this.currentDay = day % orbitDays;
    }
	

	public MoonPhase getPreviousPhase() {
	    return previousPhase;
	}

	public void setPreviousPhase(MoonPhase phase) {
	    this.previousPhase = phase;
	}

	
	
}
