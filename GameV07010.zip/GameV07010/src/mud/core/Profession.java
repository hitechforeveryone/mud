package mud.core;

public enum Profession {
	NONE,
    WARRIOR,
    MAGE,
    PRIEST,
    ROGUE,
    HUNTER,
    PALADIN,
    DRUID,
    SHAMAN,
    WARLOCK,
    MONK,
    BARD,
    NECROMANCER,
    MECHANIC;

    public static Profession fromString(String input) {
        if (input == null) return null;
        String normalized = input.trim().toLowerCase();
        switch (normalized) {
            case "warrior": return WARRIOR;
            case "mage": return MAGE;
            case "priest": return PRIEST;
            case "rogue": return ROGUE;
            case "hunter": return HUNTER;
            case "paladin": return PALADIN;
            case "druid": return DRUID;
            case "shaman": return SHAMAN;
            case "warlock": return WARLOCK;
            case "monk": return MONK;
            case "bard": return BARD;
            case "necromancer": return NECROMANCER;
            case "mechanic": return MECHANIC;
            default: return null;
        }
    }
} // end Profession
