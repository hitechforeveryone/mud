package mud.core;

import java.util.ArrayList;
import java.util.List;

public class HelpEntry {
    private String keyword;
    private String title;
    private String body;
    private List<String> aliases;

    public HelpEntry(String keyword, String title, String body) {
        this.keyword = keyword.toLowerCase();
        this.title = title;
        this.body = body;
        this.aliases = new ArrayList<>();
    }

    public String getKeyword() { return keyword; }
    public String getTitle() { return title; }
    public String getBody() { return body; }
    public List<String> getAliases() { return aliases; }

    public void addAlias(String alias) {
        aliases.add(alias.toLowerCase());
    }

    public boolean matches(String input) {
        String query = input.toLowerCase();
        return keyword.equals(query) || aliases.contains(query);
    }
}
