package mud.core;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MobManager {
    private static final Map<Integer, Mob> mobsById = new ConcurrentHashMap<>();
    private static final Map<Integer, Mob> mobTemplates = new HashMap<>();

    // Add or update a mob in the manager
    public static void addMob(Mob mob) {
        mobsById.put(mob.getId(), mob);
    }

    // Retrieve mob by ID
    public static Mob getMobById(int id) {
        return mobsById.get(id);
    }

    // Remove a mob by ID
    public static void removeMob(int id) {
        mobsById.remove(id);
    }

 // In MobManager.java
    public static Mob createMobById(int id) {
        Mob prototype = mobTemplates.get(id);

        if (prototype == null) {
            // Try loading from file if not already registered
            Mob loaded = WorldManager.loadMob(String.valueOf(id));
            if (loaded != null) {
                registerMobTemplate(loaded); // Register it
                prototype = loaded;
            }
        }

        return prototype != null ? prototype.clone() : null;
    }

    public static Mob createMobByIdOrNextFree(int requestedId) {
        // 1️⃣ Special case: clone Mob 0 if it exists
        if (requestedId == 0 && mobTemplates.containsKey(0)) {
            return mobTemplates.get(0).clone();
        }

        // 2️⃣ If requested ID is free, create new mob with that ID
        if (!mobTemplates.containsKey(requestedId)) {
            Mob newMob = new Mob(requestedId);
            registerMobTemplate(newMob);
            return newMob;
        }

        // 3️⃣ Requested ID is taken (non-zero):
        //    - Option A: clone existing template
        //    - Option B: auto-assign next free ID
        // Here we clone if a template exists for that ID
        Mob prototype = mobTemplates.get(requestedId);
        if (prototype != null) {
            return prototype.clone();
        }

        // 4️⃣ Fallback: assign next available ID if somehow no template exists
        int nextId = getNextAvailableMobId();
        Mob newMob = new Mob(nextId);
        registerMobTemplate(newMob);
        return newMob;
    }


    
    public static int getNextAvailableMobId() {
        // Find the lowest non-negative integer not currently used in mobTemplates
        int nextId = 0;
        while (mobTemplates.containsKey(nextId)) {
            nextId++;
        }
        return nextId;
    }

    public static void registerMobTemplate(int id, Mob mob) {
        mobTemplates.put(id, mob);
    }

    
    public static void loadMobTemplates() {
        // Example hardcoded:
        Mob blob = new Mob();
        blob.setMobName("a blob");
        blob.setLevel(1);
        // Set other properties...

        registerMobTemplate(0, blob);
    }

    public static void registerMobTemplate(Mob mob) {
        mobTemplates.put(mob.getId(), mob);
    }




    // Other helper methods as needed...
}
