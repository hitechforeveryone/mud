package mud.core;

public class Ansi {
    // Reset / Style
    public static final String RESET = "\u001B[0m";
    public static final String BOLD = "\u001B[1m";
    public static final String UNDERLINE = "\u001B[4m";
    public static final String REVERSED = "\u001B[7m";

    // Standard foreground colors
    public static final String BLACK = "\u001B[30m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String CYAN = "\u001B[36m";
    public static final String WHITE = "\u001B[37m";
    public static final String GREY = "\u001B[90m";

    // Bright / High-intensity foreground colors
    public static final String BRIGHT_BLACK = "\u001B[90m";
    public static final String BRIGHT_RED = "\u001B[91m";
    public static final String BRIGHT_GREEN = "\u001B[92m";
    public static final String BRIGHT_YELLOW = "\u001B[93m";
    public static final String BRIGHT_BLUE = "\u001B[94m";
    public static final String BRIGHT_MAGENTA = "\u001B[95m";
    public static final String BRIGHT_CYAN = "\u001B[96m";
    public static final String BRIGHT_WHITE = "\u001B[97m";

    // Extended 256-color foreground (bright/unique)
    public static final String ORANGE = "\u001B[38;5;208m";
    public static final String PINK = "\u001B[38;5;205m";
    public static final String LIGHT_PURPLE = "\u001B[38;5;141m";
    public static final String LIGHT_BLUE = "\u001B[38;5;117m";
    public static final String TEAL = "\u001B[38;5;30m";
    public static final String LIME = "\u001B[38;5;118m";
    public static final String LIGHT_GREY = "\u001B[38;5;250m";
    public static final String DARK_RED = "\u001B[38;5;88m";
    public static final String DARK_GREEN = "\u001B[38;5;22m";
    public static final String DARK_BLUE = "\u001B[38;5;18m";
    public static final String DARK_PURPLE = "\u001B[38;5;54m";
    public static final String BROWN = "\u001B[38;5;94m";
    public static final String CYAN_BLUE = "\u001B[38;5;44m";
    public static final String GOLD = "\u001B[38;5;214m";
    public static final String SILVER = "\u001B[38;5;250m";

    // Background colors
    public static final String BG_BLACK = "\u001B[40m";
    public static final String BG_RED = "\u001B[41m";
    public static final String BG_GREEN = "\u001B[42m";
    public static final String BG_YELLOW = "\u001B[43m";
    public static final String BG_BLUE = "\u001B[44m";
    public static final String BG_MAGENTA = "\u001B[45m";
    public static final String BG_CYAN = "\u001B[46m";
    public static final String BG_WHITE = "\u001B[47m";

    // Bright backgrounds
    public static final String BG_BRIGHT_BLACK = "\u001B[100m";
    public static final String BG_BRIGHT_RED = "\u001B[101m";
    public static final String BG_BRIGHT_GREEN = "\u001B[102m";
    public static final String BG_BRIGHT_YELLOW = "\u001B[103m";
    public static final String BG_BRIGHT_BLUE = "\u001B[104m";
    public static final String BG_BRIGHT_MAGENTA = "\u001B[105m";
    public static final String BG_BRIGHT_CYAN = "\u001B[106m";
    public static final String BG_BRIGHT_WHITE = "\u001B[107m";

    // Additional special-purpose foregrounds
    public static final String FLAME = ORANGE;
    public static final String POISON = GREEN;
    public static final String MAGIC = LIGHT_PURPLE;
    public static final String SHADOW = DARK_PURPLE;
    public static final String WATER = LIGHT_BLUE;
    public static final String HEAL = BRIGHT_GREEN;
    public static final String WARNING = BRIGHT_YELLOW;
    public static final String HIGHLIGHT = BRIGHT_CYAN;
}
