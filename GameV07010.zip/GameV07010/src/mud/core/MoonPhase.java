package mud.core;

public enum MoonPhase {

    NEW_MOON(0, "New Moon"),
    WAXING_CRESCENT(1, "Waxing Crescent"),
    FIRST_QUARTER(2, "First Quarter"),
    WAXING_GIBBOUS(3, "Waxing Gibbous"),
    FULL_MOON(4, "Full Moon"),
    WANING_GIBBOUS(5, "Waning Gibbous"),
    LAST_QUARTER(6, "Last Quarter"),
    WANING_CRESCENT(7, "Waning Crescent");

    private final int phaseIndex;
    private final String displayName;

    MoonPhase(int phaseIndex, String displayName) {
        this.phaseIndex = phaseIndex;
        this.displayName = displayName;
    }

    /** 0–7 phase position in the lunar cycle */
    public int getPhaseIndex() {
        return phaseIndex;
    }

    /** Total number of phases */
    public static int getPhaseCount() {
        return values().length;
    }

    /** Human-friendly name */
    public String getDisplayName() {
        return displayName;
    }

    /** Advance to next phase (wraps automatically) */
    public MoonPhase next() {
        return values()[(phaseIndex + 1) % values().length];
    }

    /** Go to previous phase (wraps automatically) */
    public MoonPhase previous() {
        return values()[(phaseIndex - 1 + values().length) % values().length];
    }
    
    public static MoonPhase fromIndex(int index) {
        for (MoonPhase phase : values()) {
            if (phase.phaseIndex == index) {
                return phase;
            }
        }
        return NEW_MOON; // safe fallback
    }
    

    @Override
    public String toString() {
        return displayName;
    }
}
