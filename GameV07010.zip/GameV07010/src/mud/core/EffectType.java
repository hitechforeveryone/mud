package mud.core;

public enum EffectType {
	AOE, // general aoe
	BUFF, // general buff
	DEBUFF, // general debuff
    DOT, // general DoT
    HOT, // general HoT
	
    FROSTBITE, // ice type snare effects
    WEB, // shadow type snare effects
    HOLD, // arcane type snare effects
    ENTANGLE, // nature type snare effects
    ROOT, // earth type snare effects
    
    ICEWALL, // room-ice type wall (exit blocker) effect
    FIREWALL, // room-fire type wall (exit blocker) effect
    EARTHWALL, // room-earth type wall (exit blocker) effect
    METALWALL, // room-metal type wall (exit blocker) effect
    
    STRENGTH, // strength effect
    WEAKENESS, // weakness effect
    
    UNDERWATER_BREATHING, // underwater breathing effect
    WATER_WALK, // water walk effect
     
    FIRE_SHIELD, // Fire Shield effect
    FORCEFUL_HAND, // Forceful Hand effect
    CRUSHING_GRIP, // Crushing Grip effect
    MIRROR_IMAGE, // mirror image effect
    SHADOW_CLONE, // shadow clone effect
    BONE_SHIELD, // bone shield effect
    
    LEVITATE, // Levitate effect
    
    SANCTUARY, // TODO
    SHIELD, // TODO

    DETECT_INVISIBLE, // TODO
    INVISIBILITY, // TODO
    
	BLEED,
    BLESSING,
    BLIND,
    BLUR,
    BURN,
    CURSE,
    


	BERSERK,
    DISORIENT,
    FEAR,
    CHARM,
    CONFUSE,
    SILENCE,
    STUN,
    TAME,
    
    MAGIC,
    POISON,
    REGENERATION,


    PORTAL, 
    

    
    // more effects as needed

;

	public EffectType getType() {
		return this;
	}
}