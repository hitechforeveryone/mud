package mud.core;

public enum ItemEffect {

    BERSERK("Berserk", Ansi.RED, "[glints with bloody light]", "🔥"),
    BLESSED("Blessed", Ansi.BLUE, "[glows with a holy light]",  "✨"),
    BURNING("Burning", Ansi.FLAME,"[burning brightly]",        "🔥"),
    CURSED("Cursed",  Ansi.RED, "[glows with an unholy light]", "☠️"),

    DETECT_INVISIBLE("Detect Invisible", Ansi.LIGHT_GREY, "[vibrates slightly]", "💫"),
    DETECT_MAGIC("Detect Magic", Ansi.LIGHT_GREY, "[vibrates gently]",   "💫"),

    GLOW("Glow", Ansi.LIGHT_GREY, "[glows softly]",  "✨"),
    HIDE("Hide", Ansi.LIGHT_GREY, "[fades out of sight]", "🕶️"),
    HOLYSYMBOL("Holy",Ansi.WHITE, "[glows slightly]", "✨"),
    HUMMING("Humming",Ansi.LIGHT_GREY, "[hums softly]", "🎵"),

    INVISIBLE("Invisible", Ansi.LIGHT_GREY, "[disappears from sight]", "🔍"),
    LEVITATE("Levitate", Ansi.LIGHT_GREY, "[floats gently]", "🌪️"),
    MAGIC("Magic", Ansi.MAGIC, "[glows brightly]", "🔮"),

    NO_DROP("No Drop", Ansi.LIGHT_GREY, "[clings tightly]", "🔒"),
    NOBREAK("No Break", Ansi.LIGHT_GREY, "[resists crumbling]", "🪨"),
    NOCHARM("No Charm", Ansi.LIGHT_BLUE, "[resists charms]", "🪬"),
    NOIDLE("No Idle", Ansi.LIGHT_GREY, "[sits quietly]", "⏳"),
    NORENT("No Rent", Ansi.LIGHT_GREY, "[gently rots]", "✖️"),
    NOSUMMON("No Summon", Ansi.LIGHT_GREY, "[resists movement]", "🚫🌀"),
    NOTAKE("No Take", Ansi.LIGHT_GREY, "[resists being taken]", "✋"),

    POISONED("Poisoned", Ansi.POISON, "[glows greenly]", "☣️"),
    SNEAK("Sneak", Ansi.LIGHT_GREY, "[dampens sound]", "👣"),
    UNDERWATERBREATHING("Underwater Breathing", Ansi.CYAN_BLUE, "[bubbles slightly]", "🫧"),
    VORPAL("Vorpal", Ansi.WHITE, "[shakes visibly]", "🗡️"),
    WATER_WALK("Water Walk", Ansi.WATER, "[floats gently]", "🌪️");

    private final String displayName;
    private final String color;
    private final String visualText;
    private final String emoji;

    ItemEffect(String displayName, String color, String visualText, String emoji) {
        this.displayName = displayName;
        this.color = color;
        this.visualText = visualText;
        this.emoji = emoji;
    }

    public String getDisplayName() { return displayName; }
    public String getColor()       { return color; }
    public String getVisualText()  { return visualText; }
    public String getEmoji()       { return emoji; }
}
