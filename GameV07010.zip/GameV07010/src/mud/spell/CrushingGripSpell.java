package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.spell.effects.CrushingGripEffect;

public class CrushingGripSpell implements Spell {

    private int duration; // 20 ticks (customize)

    @Override
    public String getName() {
        return "crushing.grip";
    }

    @Override
    public String getDescription() {
        return "Conjures a crushing spectral fist that deals periodic crushing damage to your foe.";
    }

    public boolean cast(Mob caster, Mob ignored) {

        if (caster.hasEffect(EffectType.CRUSHING_GRIP)) {
            caster.sendMessage("You already wield a Crushing Grip.");
            return false;
        }
        
        duration = 10 + caster.getIntellect();

        CrushingGripEffect effect = new CrushingGripEffect(caster, duration);
        caster.addEffect(effect);

        caster.getRoom().broadcast(
            caster.getMobName() + " summons a massive spectral fist that clenches with lethal force!",
            caster
        );

        caster.sendMessage("A spectral fist materializes beside you, ready to crush your enemies.");

        return true;
    }

    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isInstantCast() { return true; }
    @Override public int getLevelRequired() { return 1; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isDirectional() { return false; }

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MAGE, Profession.NECROMANCER,Profession.WARLOCK);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {

        if (caster.hasEffect(EffectType.CRUSHING_GRIP)) {
            caster.sendMessage("You already wield a Crushing Grip.");
            return false;
        }
        
        duration = 10 + caster.getIntellect();

        CrushingGripEffect effect = new CrushingGripEffect(caster, duration);
        caster.addEffect(effect);

        caster.getRoom().broadcast(
            caster.getMobName() + " summons a massive spectral fist that clenches with lethal force!",
            caster
        );

        caster.sendMessage("A spectral fist materializes beside you, ready to crush your enemies.");

        return true;
	}
}
