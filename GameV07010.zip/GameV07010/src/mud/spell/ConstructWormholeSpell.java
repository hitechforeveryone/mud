// ConstructWormholeSpell.java
package mud.spell;

import mud.core.*;
import mud.spell.effects.WormholeEffect;

import java.util.Set;
import java.util.UUID;

public class ConstructWormholeSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.SUMMON;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
	
    int duration;
    
    @Override
    public String getName() {
        return "construct.wormhole";
    }

    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("You must specify someone to construct a wormhole to.");
            return false;
        }

        Room casterRoom = caster.getCurrentRoom();
        Room targetRoom = target.getCurrentRoom();

        if (targetRoom == null) {
            caster.sendMessage("The wormhole fizzles — destination not found.");
            return false;
        }

        if (casterRoom == targetRoom) {
            caster.sendMessage("A wormhole to the same room would tear spacetime apart! No.");
            return false;
        }
        if (casterRoom.getZone().getWorld() != targetRoom.getZone().getWorld()) {
            caster.sendMessage("This small of a wormhole would not reach that far! No.");
            return false;
        }

        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A distortion field blocks all wormhole formation here.");
            return false;
        }
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A wormhole cannot form near " + target.getMobName() + ".");
            return false;
        }


        String portalId = UUID.randomUUID().toString();

        duration = 5 + caster.getIntellect();

        WormholeEffect fromEff = new WormholeEffect(casterRoom, targetRoom, portalId, duration);
        WormholeEffect toEff = new WormholeEffect(targetRoom, casterRoom, portalId, duration);

        casterRoom.addRoomEffect(fromEff);
        targetRoom.addRoomEffect(toEff);

        casterRoom.broadcastToRoom("A violent rift of twisting metal and sparking wires tears open!" + icon);
        targetRoom.broadcastToRoom("A crackling wormhole of gears and raw electricity bursts into existence!" + icon);

        caster.sendMessage("You construct an unstable wormhole linking your location to " + target.getMobName() + "!");
        target.sendMessage("A mechanical wormhole rips open nearby, linked to " + caster.getMobName() + "!");

        return true;
    }

    @Override
    public String getDescription() {
        return "Constructs a gear-driven electric wormhole linking two rooms.";
    }


    @Override public int getLevelRequired() { return 10; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean cast(Mob caster, Direction dir) { return false; }
    @Override public boolean isDirectional() { return false; }

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MECHANIC);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return duration;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
        if (target == null) {
            caster.sendMessage("You must specify someone to construct a wormhole to.");
            return false;
        }

        Room casterRoom = caster.getCurrentRoom();
        Room targetRoom = target.getCurrentRoom();

        if (targetRoom == null) {
            caster.sendMessage("The wormhole fizzles — destination not found.");
            return false;
        }

        if (casterRoom == targetRoom) {
            caster.sendMessage("A wormhole to the same room would tear spacetime apart! No.");
            return false;
        }
        if (casterRoom.getZone().getWorld() != targetRoom.getZone().getWorld()) {
            caster.sendMessage("This small of a wormhole would not reach that far! No.");
            return false;
        }

        if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A distortion field blocks all wormhole formation here.");
            return false;
        }
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A wormhole cannot form near " + target.getMobName() + ".");
            return false;
        }


        String portalId = UUID.randomUUID().toString();

        duration = 5 + caster.getIntellect();

        WormholeEffect fromEff = new WormholeEffect(casterRoom, targetRoom, portalId, duration);
        WormholeEffect toEff = new WormholeEffect(targetRoom, casterRoom, portalId, duration);

        casterRoom.addRoomEffect(fromEff);
        targetRoom.addRoomEffect(toEff);

        casterRoom.broadcastToRoom("A violent rift of twisting metal and sparking wires tears open!" + icon);
        targetRoom.broadcastToRoom("A crackling wormhole of gears and raw electricity bursts into existence!" + icon);

        caster.sendMessage("You construct an unstable wormhole linking your location to " + target.getMobName() + "!");
        target.sendMessage("A mechanical wormhole rips open nearby, linked to " + caster.getMobName() + "!");

        return true;
	}
} // end

