package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

public class DamageAbsorbSpell implements Spell {

    private static final int ABSORB_AMOUNT = 30; // total damage to absorb

    @Override
    public String getName() {
        return "damage_absorb";
    }

    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to protect.");
            return false;
        }

        // Assume Mob has an absorbShield field or method to add absorb points
        if (target.addDamageAbsorb(ABSORB_AMOUNT)) {
            caster.sendMessage("You cast a protective shield on " + target.getMobName() + ", absorbing up to " + ABSORB_AMOUNT + " damage.");
            if (target != caster) {
                target.sendMessage(caster.getMobName() + " casts a shield on you, protecting you from damage.");
                target.addEffect(EffectType.SHIELD);
            }
            // Broadcast to others in the room except caster and target
            if (caster.getCurrentRoom() != null) {
                caster.getCurrentRoom().broadcastExcept(
                    caster.getMobName() + " casts a glowing shield around " + target.getMobName() + ".",
                    caster, target
                );
            }
            return true;
        } else {
            caster.sendMessage(target.getMobName() + " already has a damage absorb shield active.");
            return false;
        }
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
        if (target == null) {
            caster.sendMessage("There is no target to protect.");
            return false;
        }

        // Assume Mob has an absorbShield field or method to add absorb points
        if (target.addDamageAbsorb(ABSORB_AMOUNT)) {
            caster.sendMessage("You cast a protective shield on " + target.getMobName() + ", absorbing up to " + ABSORB_AMOUNT + " damage.");
            if (target != caster) {
                target.sendMessage(caster.getMobName() + " casts a shield on you, protecting you from damage.");
                target.addEffect(EffectType.SHIELD);
            }
            // Broadcast to others in the room except caster and target
            if (caster.getCurrentRoom() != null) {
                caster.getCurrentRoom().broadcastExcept(
                    caster.getMobName() + " casts a glowing shield around " + target.getMobName() + ".",
                    caster, target
                );
            }
            return true;
        } else {
            caster.sendMessage(target.getMobName() + " already has a damage absorb shield active.");
            return false;
        }
	}
}
