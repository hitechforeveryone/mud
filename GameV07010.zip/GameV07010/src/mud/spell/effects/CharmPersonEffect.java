package mud.spell.effects;

import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;
import mud.core.EffectType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CharmPersonEffect implements Effect {

    private static final List<CharmPersonEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private Mob target;
    private Mob caster;
    private int remainingTicks;

    public CharmPersonEffect(Mob target, Mob caster, int durationTicks) {
        this.target = target;
        this.caster = caster;
        this.remainingTicks = durationTicks;
        ACTIVE_EFFECTS.add(this);
    }

    @Override
    public String getName() {
        return "Charm Person";
    }

    @Override
    public EffectType getType() {
        return EffectType.CHARM;
    }

    @Override
    public void tick() {
        if (target == null || target.getCurrentRoom() == null || caster == null) {
            remainingTicks = 0;
            expire();
            return;
        }

        // Assist caster: attack caster's target if target has one
        Mob assistTarget = caster.getCurrentTarget();
        if (assistTarget != null && assistTarget != target) {
            target.setTarget(assistTarget);
            target.setCurrentTarget(assistTarget);
            target.sendMessage("You obey " + caster.getMobName() + " and attack " + assistTarget.getMobName() + "!");
        }

        // TODO
        // help caster with spells logic
        

        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }

    private void expire() {
        target.removeEffect(EffectType.CHARM);
        ACTIVE_EFFECTS.remove(this);
        target.sendMessage("Your loyalty to " + caster.getMobName() + " fades.");
    }

    public static void tickAll() {
        Iterator<CharmPersonEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            CharmPersonEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
