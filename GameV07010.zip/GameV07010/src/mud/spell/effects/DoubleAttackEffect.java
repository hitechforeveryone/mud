package mud.spell.effects;

import mud.core.*;

public class DoubleAttackEffect implements Effect {

    private final Mob target;
    private boolean permanent = true;
    MobAffectFlag DA = MobAffectFlag.DOUBLEATTACK;
    
    public DoubleAttackEffect(Mob target) {
        this.target = target;
        this.target.setAffect(DA); // Enable double attack
    }

    @Override
    public void tick() {
        // Passive/permanent effects don’t need ticking logic
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent effect
    }

    @Override
    public String getName() {
        return "double_attack";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
    
    public void onRemove() {
    	target.removeAffect(DA);
    }

    @Override
    public int getHpBonus() {
        return 0;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public EffectType getType() {
        return null;
    }

    @Override
    public int getDuration() {
        return 0;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}

	public boolean isPermanent() {
		return permanent;
	}

	public void setPermanent(boolean permanent) {
		this.permanent = permanent;
	}
} // end
