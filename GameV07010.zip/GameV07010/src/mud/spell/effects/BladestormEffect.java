package mud.spell.effects;

import java.util.*;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Room;
import mud.core.ObjectItem;

public class BladestormEffect implements Effect {

    private static final List<BladestormEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob caster;
    private ObjectItem weapon = null;
    private final int damagePerTick;
    private final int totalTicks;
    private int ticksPassed = 0;

    private final MagicDamageType damageType = MagicDamageType.PHYSICAL;
    private final String icon;

    public BladestormEffect(Mob caster, ObjectItem weapon, int damagePerTick, int totalTicks) {
        this.caster = caster;
        this.weapon = weapon;
        this.damagePerTick = damagePerTick;
        this.totalTicks = totalTicks;

        this.icon = (weapon != null)
                ? weapon.getDamageTypePretty()
                : "";
        
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<BladestormEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            BladestormEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        if (caster == null || caster.getCurrentRoom() == null) return;

        Room room = caster.getCurrentRoom();
        ticksPassed++;

        String weaponType = (weapon != null)
        	    ? weapon.getWeaponType().toString()
        	    : "blade";


        // Broadcast per tick
        room.broadcast(
            "A rain of swirling " + weaponType + "s lashes the room! " + icon,
            caster
        );

        for (Mob m : room.getMobs()) {
            if (m == caster) continue;

            // Party safe
            if (caster instanceof Player pc &&
                pc.getParty() != null &&
                pc.getParty().getMembers().contains(m))
                continue;

            m.takeDamage(damagePerTick, damageType);

            m.sendMessage("You are lashed by the raining " + weaponType + "s " + icon +
                          " for " + damagePerTick + " damage!");

            if (m.getTarget() == null) {
                m.setTarget(caster);
            }
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public Mob getTarget() { return caster; }

    @Override
    public String getName() { return "Bladestorm"; }

    @Override
    public int getHpBonus() { return 0; }

    @Override
    public int getStrengthBonus() { return 0; }

    @Override
    public EffectType getType() { return EffectType.AOE; }

    @Override
    public int getDuration() { return totalTicks; }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
} // end
