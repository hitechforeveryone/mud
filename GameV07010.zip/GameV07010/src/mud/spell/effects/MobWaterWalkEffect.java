package mud.spell.effects;

import mud.core.*;
import java.util.*;

public class MobWaterWalkEffect implements Effect {

    private static final List<MobWaterWalkEffect> ACTIVE = new ArrayList<>();

    private final Mob target;
    private int duration;
    private boolean expired = false;

    public MobWaterWalkEffect(Mob caster, Mob target, int duration) {
        this.target = target;
        this.duration = duration;
        ACTIVE.add(this);
    }

    @Override
    public String getName() {
        return "Water Walk";
    }

    @Override
    public EffectType getType() {
        return EffectType.WATER_WALK;
    }

    @Override
    public boolean isExpired() {
        return expired;
    }

    @Override
    public void tick() {
        if (duration > 0) { duration--; return; }
        expired = true;
    }

    @Override
    public Mob getTarget() { return target; }

    @Override
    public int getDuration() { return duration; }

    @Override
    public Direction getDirection() { return null; }

    @Override
    public void onApply(Room room) {}

    public static void tickAll() {
        Iterator<MobWaterWalkEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            MobWaterWalkEffect e = it.next();
            e.tick();
            if (e.isExpired()) {
            	e.target.sendMessage("It suddenly gets harder to float on top of the water.");
            	it.remove();
            }
        }
    }
}
