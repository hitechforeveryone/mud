package mud.spell.effects;

import mud.core.Mob;

public interface IncomingAttackListener {
    boolean onIncomingAttack(Mob attacker, Mob defender);
}
// end
