package mud.spell.effects;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class BerserkEffect implements Effect {

    private static final Random RNG = new Random();
    private static final List<BerserkEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private int remainingTicks;  // -1 = permanent

    public BerserkEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Berserk";
    }

    @Override
    public EffectType getType() {
        return EffectType.BERSERK;
    }

    @Override
    public void tick() {
        if (remainingTicks > 0) {
            remainingTicks--;
            if (remainingTicks <= 0) {
                expire();
            }
        }
    }

    public void onKill(Mob killedMob) {
        Room room = target.getRoom();
        if (room == null) return;

        // Find next target in room
        List<Mob> mobs = room.getMobs();
        mobs.remove(target); // don’t attack self
        mobs.remove(killedMob); // skip corpse, if still present

        if (mobs.isEmpty()) {
            target.sendMessage("Your rage finds no more victims!");
            return;
        }

        Mob nextTarget = mobs.get(RNG.nextInt(mobs.size()));

        target.sendMessage("⚔ In a blood frenzy, you turn on " + nextTarget.getMobName() + "!");
        room.broadcastExcept(
                target.getMobName() + " turns in a berserk fury toward " + nextTarget.getMobName() + "!",
                target, nextTarget
        );

        target.setTarget(nextTarget);
        nextTarget.setTarget(target);
    }

    private void expire() {
        target.removeEffect(EffectType.BERSERK);
        ACTIVE_EFFECTS.remove(this);
        target.sendMessage("Your berserk rage fades, leaving you exhausted.");
    }

    public static void tickAll() {
        Iterator<BerserkEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            BerserkEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
    @Override
    public boolean isExpired() {
        return remainingTicks == 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() { return null; }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
