package mud.spell.effects;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

public class BlessEffect implements Effect {
    private int duration;

    public BlessEffect(int duration) {
        this.duration = duration;
    }

    @Override
    public EffectType getType() {
        return EffectType.BLESSING;
    }

    @Override
    public int getDuration() {
        return duration;
    }

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Mob getTarget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
