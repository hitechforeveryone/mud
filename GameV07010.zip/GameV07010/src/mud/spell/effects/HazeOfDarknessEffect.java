package mud.spell.effects;

import java.util.*;

import mud.core.*;

public class HazeOfDarknessEffect implements Effect {

    private static final List<HazeOfDarknessEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Room room;
    private final int totalTicks;
    private int ticksPassed = -1;
    private boolean applied = false;

    public HazeOfDarknessEffect(Room room, int totalTicks) {
        this.room = room;
        this.totalTicks = totalTicks;
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<HazeOfDarknessEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            HazeOfDarknessEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        ticksPassed++;

        if (!applied) {
            applied = true;
            room.setLightLevel(0); // immediately dark
            return;
        }

        if (ticksPassed >= totalTicks) {
            room.recalculateLighting(); // restore ambient light
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public String getName() {
        return "Haze of Darkness";
    }

    @Override
    public EffectType getType() {
        return EffectType.DEBUFF;
    }

    @Override public int getDuration() { return totalTicks; }
    @Override public int getHpBonus() { return 0; }
    @Override public int getStrengthBonus() { return 0; }
    @Override public Mob getTarget() { return null; }
    @Override public Direction getDirection() { return null; }
    @Override public void onApply(Room room) {}
}
