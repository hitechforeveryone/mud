package mud.spell.effects;

import java.util.*;

import mud.core.*;

public class ContinualLightEffect implements Effect {

    private static final List<ContinualLightEffect> ACTIVE = new LinkedList<>();

    private final ObjectItem target;
    private final Mob caster;
    private int duration;
    private boolean expired = false;
    private Room appliedRoom;

    public ContinualLightEffect(Mob caster, ObjectItem target, int duration) {
        this.caster = caster;
        this.target = target;
        this.duration = duration;

        target.addEffect(ItemEffect.GLOW);

        appliedRoom = caster.getCurrentRoom();
        if (appliedRoom != null) {
            appliedRoom.setLightLevel(3); // ✨ MAGICAL
        }
    }

    @Override
    public String getName() {
        return "Continual Light";
    }

    @Override
    public EffectType getType() {
        return EffectType.BUFF;
    }

    @Override
    public void tick() {
        if (expired) return;

        if (--duration <= 0) {
            expire();
        }
    }

    private void expire() {
        expired = true;
        target.removeEffect(ItemEffect.GLOW);

        if (appliedRoom != null) {
            appliedRoom.recalculateLighting(); // 🔁 fallback to ambient
        }
    }

    @Override
    public boolean isExpired() {
        return expired;
    }

    // ---------- Static ticking ----------

    public static void register(ContinualLightEffect eff) {
        if (eff != null) ACTIVE.add(eff);
    }

    public static void tickAll() {
        Iterator<ContinualLightEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            ContinualLightEffect eff = it.next();
            eff.tick();
            if (eff.isExpired()) {
                it.remove();
            }
        }
    }

    // ---------- Boilerplate ----------

    @Override public Mob getTarget() { return caster; }
    @Override public int getDuration() { return duration; }
    @Override public Direction getDirection() { return null; }
    @Override public void onApply(Room room) {}
}
