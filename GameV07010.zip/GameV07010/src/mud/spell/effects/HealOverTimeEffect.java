package mud.spell.effects;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

public class HealOverTimeEffect implements Effect {

    protected final Mob target;
    private final int healPerTick;
    private final int duration;
    private int ticks;

    public HealOverTimeEffect(Mob target, int healPerTick, int duration) {
        this.target = target;
        this.healPerTick = healPerTick;
        this.duration = duration;
        this.ticks = 0;
    }

    @Override
    public void tick() {
        if (isExpired()) return;
        this.target.heal(healPerTick);
        this.target.sendMessage("You are healed for " + healPerTick + " health.");
        ticks++;
    }

    @Override
    public boolean isExpired() {
        return ticks >= duration;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public String getName() {
        return "Heal Over Time";
    }

	@Override
	public int getHpBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStrengthBonus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
