package mud.spell.effects;

import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Direction;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class MirrorImageEffect implements Effect {
    private static final CopyOnWriteArrayList<MirrorImageEffect> ACTIVE_EFFECTS = new CopyOnWriteArrayList<>();

    private final Mob target;
    private int images;
    private final int totalTicks;
    private int ticksPassed = 0;

    public MirrorImageEffect(Mob target, int images, int durationTicks) {
        this.target = target;
        this.images = images;
        this.totalTicks = durationTicks;

        ACTIVE_EFFECTS.add(this);
        this.target.addEffect(this);
        this.target.addEffect(EffectType.MIRROR_IMAGE);

        target.sendMessage("You are surrounded by shimmering mirror images!");
        Room r = target.getRoom();
        if (r != null) {
            r.broadcastExcept(target.getMobName() + " shimmers as multiple illusory images appear!", target, null);
        }
    }

    public static void tickAll() {
        Iterator<MirrorImageEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            MirrorImageEffect effect = it.next();
            effect.tick();

            if (effect.isExpired()) {
                ACTIVE_EFFECTS.remove(effect);
                effect.target.removeEffect(EffectType.MIRROR_IMAGE);
                effect.target.removeEffect(effect.getName());
                effect.target.sendMessage("Your mirror images fade away.");

                Room r = effect.target.getRoom();
                if (r != null) {
                    r.broadcastExcept(effect.target.getMobName() + "'s mirror images fade away.", effect.target, null);
                }
            }
        }
    }
    
    public void addImages(int amt) {
        if (amt <= 0) return;

        // Increase the image count
        this.images += amt;

        // Optional: cap images based on your spell design
        int maxImages = 6;
        if (this.images > maxImages) {
            this.images = maxImages;
        }
    }

    
    public boolean onIncomingAttack(Mob attacker, Mob target) {
        MirrorImageEffect eff = target.getEffect(MirrorImageEffect.class);
        if (eff == null) return false;

        if (eff.images > 0) {
            eff.images--;

            attacker.sendMessage("Your attack strikes a mirror image, shattering it!");
            target.sendMessage("An incoming attack shatters one of your mirror images!");

            // Attack is completely negated
            attacker.setTarget(null);
            attacker.setCurrentTarget(null);
            attacker.setInCombat(false);
            
            target.setTarget(null);
            target.setCurrentTarget(null);
            target.setInCombat(false);
            
            Room r = target.getRoom();
            if (r != null) {
                r.broadcastToExcept(attacker, target,
                    attacker.getMobName() + " strikes one of " + target.getMobName() + "'s mirror images, shattering it!");
            }

            return true; // attack blocked
        }

        return false; // no images left
    }

    @Override
    public void tick() {
        ticksPassed++;
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public String getName() {
        return "mirror image";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public EffectType getType() {
        return EffectType.MIRROR_IMAGE;
    }

    @Override
    public int getDuration() {
        return totalTicks - ticksPassed;
    }

    public int getImages() {
        return images;
    }

    @Override
    public Direction getDirection() {
        return null;
    }

    @Override
    public void onApply(Room room) {
        // unused
    }
}
// end