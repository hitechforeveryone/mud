package mud.spell.effects;

import java.util.*;

import mud.core.*;

public class DancingLightsEffect implements Effect {

    private static final List<DancingLightsEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Room room;
    private final int totalTicks;
    private int ticksPassed = 0;
    private boolean applied = false;

    public DancingLightsEffect(Room room, int totalTicks) {
        this.room = room;
        this.totalTicks = totalTicks;
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<DancingLightsEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            DancingLightsEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        if (!applied) {
            applied = true;
            applyLight();
            return;
        }

        ticksPassed++;

        if (ticksPassed < totalTicks && ticksPassed % 3 == 0) {
            room.broadcastToRoom("The dancing lights shimmer and drift lazily through the air ✨.");
        }

        if (ticksPassed >= totalTicks) {
            expire();
        }
    }

    private void applyLight() {
        // Only increase light if current ambient < 1
        if (room.getLightLevel() < 1) {
            room.setLightLevel(1);
        }
        room.broadcastToRoom("Soft magical lights float upward, illuminating the room ✨.");
    }

    private void expire() {
        room.broadcastToRoom("The magical lights fade away, and the room dims once more.");
        // Restore room to ambient/moonlight/daylight
        room.recalculateLighting();
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public String getName() {
        return "Dancing Lights";
    }

    @Override
    public EffectType getType() {
        return EffectType.BUFF;
    }

    @Override
    public int getDuration() {
        return totalTicks;
    }

    // ------------------- boilerplate -------------------
    @Override public int getHpBonus() { return 0; }
    @Override public int getStrengthBonus() { return 0; }
    @Override public Mob getTarget() { return null; }
    @Override public Direction getDirection() { return null; }
    @Override public void onApply(Room room) {}
}
