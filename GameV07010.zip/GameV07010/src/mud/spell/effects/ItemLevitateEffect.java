

// ItemLevitateEffect with static tickAll
package mud.spell.effects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import mud.core.*;

public class ItemLevitateEffect implements Effect {

    private static final List<ItemLevitateEffect> ACTIVE = new ArrayList<>();

    private final Mob caster;
    private final ObjectItem target;
    private int duration;
    private boolean expired = false;

    public ItemLevitateEffect(Mob caster, ObjectItem target, int duration) {
        this.caster = caster;
        this.target = target;
        this.duration = duration;

        target.addEffect(ItemEffect.LEVITATE);
        ACTIVE.add(this);
    }

    @Override
    public String getName() { return "Item Levitation"; }

    @Override
    public EffectType getType() { return EffectType.BUFF; }

    @Override
    public boolean isExpired() { return expired; }

    @Override
    public void tick() {
        if (expired) return;

        if (duration-- <= 0) {
            expired = true;
            target.removeEffect(ItemEffect.LEVITATE);
        }
    }

    public static void tickAll() {
        Iterator<ItemLevitateEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            ItemLevitateEffect eff = it.next();
            eff.tick();
            if (eff.isExpired()) it.remove();
        }
    }

    @Override
    public Mob getTarget() { return caster; }
    @Override
    public int getDuration() { return duration; }
    @Override
    public Direction getDirection() { return null; }
    @Override
    public void onApply(Room room) {}
}
// end