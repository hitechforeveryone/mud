package mud.spell.effects;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.Mob;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ConfusionEffect implements Effect {

    private static final Random RNG = new Random();
    private static final List<ConfusionEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private int remainingTicks;

    public ConfusionEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Confusion";
    }

    @Override
    public EffectType getType() {
        return EffectType.CONFUSE;
    }

    @Override
    public void tick() {
        if (remainingTicks <= 0) {
            expire();
            return;
        }

        if (target == null || target.getRoom() == null) {
            remainingTicks = 0;
            expire();
            return;
        }

        // Make sure target cannot act “rationally.”
        target.setTarget(null);
        target.setCurrentTarget(null);

        Room room = target.getRoom();

        // Different random confusion behaviors
        int behavior = RNG.nextInt(4);

        switch (behavior) {
            case 0 -> {
                target.sendMessage("You feel dizzy and disoriented...");
                room.broadcastExcept(target.getMobName() + " stumbles around in confusion.", target);
            }
            case 1 -> {
                // Random movement (stagger around)
                List<Direction> dirs = new ArrayList<>(room.getExits().keySet());
                if (!dirs.isEmpty()) {
                    Direction moveDir = dirs.get(RNG.nextInt(dirs.size()));
                    target.sendMessage("You stagger " + moveDir.name().toLowerCase() + " in a daze.");
                    room.broadcastExcept(target.getMobName() + " staggers " + moveDir.name().toLowerCase() + ".", target);

                }
            }
            case 2 -> {
                target.sendMessage("Your thoughts scramble—nothing makes sense!");
                room.broadcastExcept(target.getMobName() + " mutters incoherently.", target);
            }
            case 3 -> {
                target.sendMessage("You spin around, utterly confused.");
                room.broadcastExcept(target.getMobName() + " spins in circles, confused.", target);
            }
        }

        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }
    public static void tickAll() {
        Iterator<ConfusionEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            ConfusionEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
    private void expire() {
        target.removeEffect(EffectType.CONFUSE);
        ACTIVE_EFFECTS.remove(this);
        target.sendMessage("Your mind clears. You are no longer confused.");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public Direction getDirection() {
        return null;
    }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
