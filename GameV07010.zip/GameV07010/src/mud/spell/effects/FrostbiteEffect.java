package mud.spell.effects;

import mud.core.Mob;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;

public class FrostbiteEffect implements Effect {
	
    private final MagicDamageType damageType = MagicDamageType.ICE;
    private final String icon = damageType.getIcon();
    
    private static final List<FrostbiteEffect> ACTIVE_EFFECTS = new ArrayList<>();
    private Mob target;
    private int remainingTicks;

    public FrostbiteEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "frostbite";
    }


    public static void tickAll() {
        Iterator<FrostbiteEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            FrostbiteEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
 
    public void tick() {
        remainingTicks--;
        if (remainingTicks <= 0) {
            expire();
        }
    }
    

    private void expire() {
        target.removeEffect(EffectType.FROSTBITE);
        target.getCurrentRoom().broadcastToRoom("The icey " + getName() + icon + " around " + target.getMobName() + " melts away.");
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

	@Override
	public Direction getDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EffectType getType() {
		// TODO Auto-generated method stub
		return EffectType.FROSTBITE;
	}

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
