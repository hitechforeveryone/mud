package mud.spell.effects;

import mud.core.Mob;
import mud.core.Room;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;

public class BlindEffect implements Effect {

	private static final List<BlindEffect> ACTIVE_EFFECTS = new ArrayList<>();private final 
    
    MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();

    private Mob target;
    private int remainingTicks;

    public BlindEffect(Mob target, int durationTicks) {
        this.target = target;
        this.remainingTicks = durationTicks;
    }

    @Override
    public String getName() {
        return "Blind";
    }

    @Override
    public EffectType getType() {
        return EffectType.BLIND;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public Direction getDirection() {
        return null;
    }

    @Override
    public int getDuration() {
        return remainingTicks;
    }

    @Override
    public boolean isExpired() {
        return remainingTicks <= 0;
    }

    public static void tickAll() {
        Iterator<BlindEffect> it = ACTIVE_EFFECTS.iterator();

        while (it.hasNext()) {
            BlindEffect effect = it.next();
            effect.tick();

            if (effect.isExpired()) {
                it.remove();
            }
        }
    }
    
    public void tick() {
        remainingTicks--;

        if (remainingTicks <= 0) {
            expire();
        }
    }

    public void expire() {
        target.removeEffect(EffectType.BLIND);
        target.sendMessage("Your vision clears as the " + getName() + icon + " fades.");
    }

	@Override
	public void onApply(Room room) {
		// TODO Auto-generated method stub
		
	}
}
