package mud.spell.effects;

import mud.core.*;
import java.util.*;

public class ItemWaterWalkEffect implements Effect {

    private static final List<ItemWaterWalkEffect> ACTIVE = new ArrayList<>();

    private final Mob caster;
    private final ObjectItem target;
    private int duration;
    private boolean expired = false;

    public ItemWaterWalkEffect(Mob caster, ObjectItem target, int duration) {
        this.caster = caster;
        this.target = target;
        this.duration = duration;

        target.addEffect(ItemEffect.WATER_WALK);
        ACTIVE.add(this);
    }

    @Override
    public String getName() { return "Water Walk (Item)"; }

    @Override
    public EffectType getType() { return EffectType.BUFF; }

    @Override
    public boolean isExpired() { return expired; }

    @Override
    public void tick() {
        if (duration > 0) { duration--; return; }
        if (!expired) {
            expired = true;
            target.removeEffect(ItemEffect.WATER_WALK);
        }
    }

    @Override
    public Mob getTarget() { return caster; }

    @Override
    public int getDuration() { return duration; }

    @Override
    public Direction getDirection() { return null; }

    @Override
    public void onApply(Room room) {}

    public static void tickAll() {
        Iterator<ItemWaterWalkEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            ItemWaterWalkEffect e = it.next();
            e.tick();
            if (e.isExpired()) it.remove();
        }
    }
}
