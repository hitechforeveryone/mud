package mud.spell.effects;

import mud.core.*;
import java.util.*;

public class MobUnderwaterBreathingEffect implements Effect {

    private static final List<MobUnderwaterBreathingEffect> ACTIVE = new ArrayList<>();

    private final Mob target;
    private int duration;
    private boolean expired = false;

    public MobUnderwaterBreathingEffect(Mob caster, Mob target, int duration) {
        this.target = target;
        this.duration = duration;
        ACTIVE.add(this);
    }

    @Override
    public String getName() { return "Underwater Breathing"; }

    @Override
    public EffectType getType() { return EffectType.UNDERWATER_BREATHING; }

    @Override
    public boolean isExpired() { return expired; }

    @Override
    public void tick() {
        if (duration > 0) { duration--; return; }
        expired = true;
    }

    @Override
    public Mob getTarget() { return target; }

    @Override
    public int getDuration() { return duration; }

    @Override
    public Direction getDirection() { return null; }

    @Override
    public void onApply(Room room) {}

    public static void tickAll() {
        Iterator<MobUnderwaterBreathingEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            MobUnderwaterBreathingEffect e = it.next();
            e.tick();            
            if (e.isExpired()) {
            	it.remove();
            	e.target.sendMessage("It suddenly get's harder to breathe.");
            }
        }
    }
}
