// MobLevitateEffect with static tickAll
package mud.spell.effects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import mud.core.*;

public class MobLevitateEffect implements Effect {

    private static final List<MobLevitateEffect> ACTIVE = new ArrayList<>();

    private final Mob target;
    private int duration;
    private boolean expired = false;

    public MobLevitateEffect(Mob caster, Mob target, int duration) {
        this.target = target;
        this.duration = duration;

        target.addEffect(EffectType.LEVITATE);
        ACTIVE.add(this);
    }

    @Override
    public String getName() { return "Levitate"; }

    @Override
    public EffectType getType() { return EffectType.LEVITATE; }

    @Override
    public boolean isExpired() { return expired; }

    @Override
    public void tick() {
        if (expired) return;

        if (duration-- <= 0) {
            expired = true;
            target.sendMessage("You feel yourself sink to the ground.");
            target.removeEffect(EffectType.LEVITATE);
        }
    }

    public static void tickAll() {
        Iterator<MobLevitateEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            MobLevitateEffect eff = it.next();
            eff.tick();
            if (eff.isExpired()) it.remove();
        }
    }

    @Override
    public Mob getTarget() { return target; }
    @Override
    public int getDuration() { return duration; }
    @Override
    public Direction getDirection() { return null; }
    @Override
    public void onApply(Room room) {}
}
// end


