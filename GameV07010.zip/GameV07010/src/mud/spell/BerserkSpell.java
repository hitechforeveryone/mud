package mud.spell;

import java.util.Set;

import mud.core.Direction;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.EffectType;
import mud.spell.effects.BerserkEffect;

public class BerserkSpell implements Spell {

    private final int duration = 12; // or -1 for permanent berserk

    public boolean cast(Mob caster, Mob target) {

        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        if (target.hasEffect(EffectType.BERSERK)) {
            caster.sendMessage(target.getMobName() + " is already in a berserk rage!");
            return false;
        }

        BerserkEffect be = new BerserkEffect(target, duration);
        target.addEffect(be);

        target.sendMessage("🔥 A furious rage overwhelms you! You go BERSERK!");
        caster.sendMessage("You drive " + target.getMobName() + " into a berserk frenzy!");
        
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(
                caster.getMobName() + " drives " + target.getMobName() + " into a berserk frenzy!");
        }

        return true;
    }

    @Override public String getName() { return "berserk"; }
    @Override public boolean cast(Mob c, Direction d) { return false; }
    @Override public String getDescription() { return "Drives the target into a killing rage, attacking endlessly."; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return Set.of(Profession.BARD, Profession.WARLOCK);
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		return duration;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {

        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        if (target.hasEffect(EffectType.BERSERK)) {
            caster.sendMessage(target.getMobName() + " is already in a berserk rage!");
            return false;
        }

        BerserkEffect be = new BerserkEffect(target, duration);
        target.addEffect(be);

        target.sendMessage("🔥 A furious rage overwhelms you! You go BERSERK!");
        caster.sendMessage("You drive " + target.getMobName() + " into a berserk frenzy!");
        
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(
                caster.getMobName() + " drives " + target.getMobName() + " into a berserk frenzy!");
        }

        return true;
	}
}
