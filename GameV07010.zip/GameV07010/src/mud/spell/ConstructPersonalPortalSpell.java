package mud.spell;

import mud.core.*;
import java.util.*;


public class ConstructPersonalPortalSpell implements Spell {


	MagicDamageType damageType = MagicDamageType.SUMMON;
	String icon = damageType.getIcon();
	String typeName = damageType.getPrettyName().toLowerCase();


	@Override
	public String getName() {
		return "construct.personal.portal";
	}


	@Override
	public String getDescription() {
		return "Opens a personal portal allowing the caster to travel instantly to a target within the zone. (transport spoof)";
	}


	public boolean cast(Mob caster, Mob target) {
		if (target == null) {
			caster.sendMessage("You must specify someone to portal to.");
			return false;
		}

		Room casterRoom = caster.getCurrentRoom();
		Room targetRoom = target.getCurrentRoom();


		// Same zone check
		if (!casterRoom.getZone().equals(targetRoom.getZone())) {
			caster.sendMessage(target.getMobName() + " is not in this zone.");
			return false;
		}


		// NOTELEPORT flags
		if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("Mystic interference prevents you from opening a portal here.");
			return false;
		}


		if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("A strange force blocks your portal from forming at the target's location.");
			return false;
		}



		// Portal transfer
		casterRoom.broadcast(caster.getMobName() + " opens a swirling mechanical portal and steps through!", caster);


		casterRoom.removeMob(caster);
		targetRoom.addMob(caster);
		caster.setRoom(targetRoom);


		targetRoom.broadcast(caster.getMobName() + " emerges from a whirring gear-driven portal!", target);


		caster.sendMessage("You step through your personal portal and arrive near " + target.getMobName() + "!");


		return true;
	}

	@Override
	public int getLevelRequired() {
		return 8;
	}


	@Override
	public boolean isInstantCast() {
		return true;
	}


	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}


    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MECHANIC);
    }


	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 35;
	}


	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
		if (target == null) {
			caster.sendMessage("You must specify someone to portal to.");
			return false;
		}

		Room casterRoom = caster.getCurrentRoom();
		Room targetRoom = target.getCurrentRoom();


		// Same zone check
		if (!casterRoom.getZone().equals(targetRoom.getZone())) {
			caster.sendMessage(target.getMobName() + " is not in this zone.");
			return false;
		}


		// NOTELEPORT flags
		if (casterRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("Mystic interference prevents you from opening a portal here.");
			return false;
		}


		if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
			caster.sendMessage("A strange force blocks your portal from forming at the target's location.");
			return false;
		}



		// Portal transfer
		casterRoom.broadcast(caster.getMobName() + " opens a swirling mechanical portal and steps through!", caster);


		casterRoom.removeMob(caster);
		targetRoom.addMob(caster);
		caster.setRoom(targetRoom);


		targetRoom.broadcast(caster.getMobName() + " emerges from a whirring gear-driven portal!", target);


		caster.sendMessage("You step through your personal portal and arrive near " + target.getMobName() + "!");


		return true;
	}
}
// end