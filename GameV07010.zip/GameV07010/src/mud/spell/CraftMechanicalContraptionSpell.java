package mud.spell;

import java.util.*;
import mud.core.*;

public class CraftMechanicalContraptionSpell implements Spell {

    @Override
    public String getName() {
        return "Craft.Mechanical.Contraption";
    }

    @Override
    public String getDescription() {
        return "Constructs a mechanical familiar to serve the caster.";
    }

    public boolean cast(Mob caster, Mob target) {
        Mob contraption = SpellUtils.summonFamiliar(caster, SpellUtils.MECHANICAL_FAMILIARS);
        if (contraption == null) return false;

        // Messaging
        caster.sendMessage("You carefully assemble " + contraption.getMobName() + ", and it springs to life!");
        caster.getCurrentRoom().broadcastExcept(contraption.getMobName() + " activates beside " + caster.getMobName() + ".", caster);

        return true;
    }


    public boolean cast(Mob caster, ObjectItem obj) { return false; }
    public boolean cast(Mob caster, Mob target, ObjectItem tarObj) { return false; }
    public boolean cast(Mob caster, Mob target, String msg) { return false; }
    public boolean cast(Mob caster, Direction tarDir) { return false; }

    public Set<Profession> getProfessions() {
        return EnumSet.of(Profession.MECHANIC);
    }

    public int getLevelRequired() { return 1; }
    public boolean isInstantCast() { return false; }
    public boolean isAoE() { return false; }
    public boolean isSelfTarget() { return true; }
    public boolean isDirectional() { return false; }
    public boolean isAbility() { return false; }
    public boolean isNPCCastable() { return false; }
    public int getManaCost() { return 20; }
    public int getDuration() { return 0; }

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
        Mob contraption = SpellUtils.summonFamiliar(caster, SpellUtils.MECHANICAL_FAMILIARS);
        if (contraption == null) return false;

        // Messaging
        caster.sendMessage("You carefully assemble " + contraption.getMobName() + ", and it springs to life!");
        caster.getCurrentRoom().broadcastExcept(contraption.getMobName() + " activates beside " + caster.getMobName() + ".", caster);

        return true;
	}
}
// end
