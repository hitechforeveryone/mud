package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.Profession;
import mud.core.Direction;
import mud.core.ObjectItem;
import mud.core.MagicDamageType;
import mud.spell.effects.DancingLightsEffect;

import java.util.Set;

public class DancingLightsSpell implements Spell {

    MagicDamageType damageType = MagicDamageType.LIGHT;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    int duration; 
    
    @Override
    public String getName() {
        return "dancing.lights";
    }

    @Override
    public String getDescription() {
        return "Summons floating motes of light that illuminate the room for a short duration.";
    }

    public boolean cast(Mob caster, Mob target) {
        Room room = caster.getCurrentRoom();

        if (room.hasFlag(RoomFlag.LIT)) {
            caster.sendMessage("The room is already brightly lit by lingering magical lights.");
            return false;
        }

        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        duration = 8 + caster.getIntellect();

        room.broadcastToRoom(caster.capitalize(caster.getMobName()) + " casts dancing lights! Magical motes of colored light swirl into existence, illuminating the area " + icon + ".");

        DancingLightsEffect effect = new DancingLightsEffect(room, duration);
        effect.tick();

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 1;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }

    @Override
    public boolean isAoE() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false;
    }

    @Override
    public boolean isDirectional() {
        return false;
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MAGE, Profession.MECHANIC, Profession.BARD);
    }

    @Override
    public boolean isAbility() {
        return false;
    }

    @Override
    public int getManaCost() {
        return 10;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        return false;
    }

    @Override
    public boolean isNPCCastable() {
        return false;
    }

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return duration;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
        Room room = caster.getCurrentRoom();

        if (room.hasFlag(RoomFlag.LIT)) {
            caster.sendMessage("The room is already brightly lit by lingering magical lights.");
            return false;
        }


        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        duration = 8 + caster.getIntellect();

        room.broadcastToRoom(caster.capitalize(caster.getMobName()) + " casts dancing lights! Magical motes of colored light swirl into existence, illuminating the area " + icon + ".");

        DancingLightsEffect effect = new DancingLightsEffect(room, duration);
        effect.tick();

        return true;
	}
}
// end

