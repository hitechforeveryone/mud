package mud.spell;

import mud.core.*;
import mud.scripting.ZoneScript;

import java.util.List;
import java.util.Random;
import java.util.Set;

public class ConstructEmergencyGatewaySpell implements Spell {

    private static final Random RANDOM = new Random();

    @Override
    public String getName() {
        return "construct.emergency.gateway";
    }

    @Override
    public String getDescription() {
        return "Triggers an emergency recall protocol, extracting you to a recall node.";
    }

    public boolean cast(Mob caster, Mob target) {

        if (caster == null || caster.getCurrentRoom() == null) {
            return false;
        }

        Mob construct = caster.getPet();
        if (construct == null) {
            caster.sendMessage("You have no construct bound to you.");
            return false;
        }

        Room constructRoom = construct.getCurrentRoom();
        if (constructRoom == null) {
            caster.sendMessage("Your construct cannot be located.");
            return false;
        }

        Zone currentZone = constructRoom.getZone();
        if (currentZone == null) {
            caster.sendMessage("The construct is not within a valid zone.");
            return false;
        }

        ZoneScript script = currentZone.getScript();
        if (script == null || script.getRecallNodes().isEmpty()) {
            caster.sendMessage("No recall nodes are defined in this zone.");
            return false;
        }

        // Pick random recall node (same as Word of Recall)
        List<ZoneScript.RecallNode> nodes = script.getRecallNodes();
        ZoneScript.RecallNode targetNode = nodes.get(RANDOM.nextInt(nodes.size()));

        Room targetRoom = currentZone.getRoom(targetNode.roomId);
        if (targetRoom == null) {
            caster.sendMessage("Emergency gateway failed to lock onto a valid location.");
            return false;
        }

        // NOSUMMON checks (identical logic)
        if (constructRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A suppression field prevents the construct from being extracted.");
            return false;
        }
        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
            caster.sendMessage("A suppression field blocks the gateway destination.");
            return false;
        }

        int manaCost = getManaCost();
        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You lack the energy to initiate an emergency gateway.");
            return false;
        }
        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        // Perform teleport (same sequence as Recall)
        
        
        
        constructRoom.removeMob(construct);
        targetRoom.addMob(construct);
        construct.setCurrentRoom(targetRoom);
        construct.setRoom(targetRoom);
        constructRoom.removeMob(caster);
        targetRoom.addMob(caster);
        caster.setCurrentRoom(targetRoom);
        caster.setRoom(targetRoom);

        // Messaging
        caster.sendMessage("You trigger an emergency recall protocol!");
        constructRoom.broadcastToRoom(
                construct.getMobName() + " collapses into a vortex of sparks and grinding metal!"
        );
        targetRoom.broadcastExcept(
                construct.getMobName() + " slams into reality through a crackling gateway!",
                construct
        );

        return true;
    }


	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, ObjectItem tarObj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Mob target, String msg) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		   return Set.of(Profession.MECHANIC); // multiple
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, Mob target, int spellLevel) {
	      if (caster == null || caster.getCurrentRoom() == null) {
	            return false;
	        }

	        Mob construct = caster.getPet();
	        if (construct == null) {
	            caster.sendMessage("You have no construct bound to you.");
	            return false;
	        }

	        Room constructRoom = construct.getCurrentRoom();
	        if (constructRoom == null) {
	            caster.sendMessage("Your construct cannot be located.");
	            return false;
	        }

	        Zone currentZone = constructRoom.getZone();
	        if (currentZone == null) {
	            caster.sendMessage("The construct is not within a valid zone.");
	            return false;
	        }

	        ZoneScript script = currentZone.getScript();
	        if (script == null || script.getRecallNodes().isEmpty()) {
	            caster.sendMessage("No recall nodes are defined in this zone.");
	            return false;
	        }

	        // Pick random recall node (same as Word of Recall)
	        List<ZoneScript.RecallNode> nodes = script.getRecallNodes();
	        ZoneScript.RecallNode targetNode = nodes.get(RANDOM.nextInt(nodes.size()));

	        Room targetRoom = currentZone.getRoom(targetNode.roomId);
	        if (targetRoom == null) {
	            caster.sendMessage("Emergency gateway failed to lock onto a valid location.");
	            return false;
	        }

	        // NOSUMMON checks (identical logic)
	        if (constructRoom.hasFlag(RoomFlag.NOSUMMON)) {
	            caster.sendMessage("A suppression field prevents the construct from being extracted.");
	            return false;
	        }
	        if (targetRoom.hasFlag(RoomFlag.NOSUMMON)) {
	            caster.sendMessage("A suppression field blocks the gateway destination.");
	            return false;
	        }

	        int manaCost = getManaCost();
	        if (caster.getCurrentMP() < manaCost) {
	            caster.sendMessage("You lack the energy to initiate an emergency gateway.");
	            return false;
	        }
	        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

	        // Perform teleport (same sequence as Recall)
	        
	        
	        
	        constructRoom.removeMob(construct);
	        targetRoom.addMob(construct);
	        construct.setCurrentRoom(targetRoom);
	        construct.setRoom(targetRoom);
	        constructRoom.removeMob(caster);
	        targetRoom.addMob(caster);
	        caster.setCurrentRoom(targetRoom);
	        caster.setRoom(targetRoom);

	        // Messaging
	        caster.sendMessage("You trigger an emergency recall protocol!");
	        constructRoom.broadcastToRoom(
	                construct.getMobName() + " collapses into a vortex of sparks and grinding metal!"
	        );
	        targetRoom.broadcastExcept(
	                construct.getMobName() + " slams into reality through a crackling gateway!",
	                construct
	        );

	        return true;
	}
	
	
	
} // end constructEmergencyGateway
