package mud.core.enums;

public enum Climate {

    NONE(
        "Undefined",
        "A place with no defining climate, neither warm nor cold, wet nor dry. It feels strangely neutral.",
        "Weather is nearly nonexistent, with long stretches of stillness and rare disturbances."
    ),

    TEMPERATE(
        "Temperate",
        "A balanced environment with moderate conditions and distinct seasonal changes, ideal for sustaining life.",
        "Weather shifts steadily with the seasons, bringing rain, warmth, cooling winds, and occasional snow."
    ),

    DESERT(
        "Desert",
        "A dry and unforgiving land of relentless sun and scarce water, where survival is never guaranteed.",
        "Most days are clear and hot, with bursts of extreme heat, strong winds, and rare but sudden storms."
    ),

    ARCTIC(
        "Arctic",
        "A frozen wasteland dominated by ice and bitter cold, where warmth is a fleeting memory.",
        "Snow and deep cold are constant, broken only by brief clear skies or drifting fog."
    ),

    TROPICAL(
        "Tropical",
        "A hot, humid region overflowing with dense vegetation and vibrant life.",
        "Frequent rain and powerful storms define the climate, with heavy humidity and lingering fog."
    ),

    SWAMP(
        "Swamp",
        "A stagnant, waterlogged environment thick with decay and life intertwined.",
        "Rain and fog are ever-present, with heavy air and occasional outbreaks of foul or corrupted conditions."
    ),

    MOUNTAIN(
        "Mountain",
        "A rugged, high-altitude region where conditions are harsh and ever-changing.",
        "Wind, fog, and sudden storms are common, with snow dominating colder seasons."
    ),

    FOREST(
        "Forest",
        "A dense woodland where towering trees filter light and life thrives beneath a heavy canopy.",
        "Rain and fog are frequent, with calm, sheltered conditions and only occasional storms."
    ),

    BLIGHTED(
        "Blighted",
        "A corrupted land where nature has withered and something unnatural has taken root.",
        "Blight seeps into the air, mixing with storms, rain, and fog to create a hostile atmosphere."
    ),

    HIGHLAND(
        "Highland",
        "An elevated landscape of rolling heights and open exposure to the elements.",
        "Winds and cold are common, with occasional snow and brief periods of clarity."
    ),

    COASTAL(
        "Coastal",
        "A shoreline region shaped by the constant push and pull of the sea.",
        "Rain, fog, and wind dominate, with storms more frequent in colder seasons."
    ),

    COLD(
        "Cold",
        "A persistently chilly region where warmth is rare but not entirely absent.",
        "Snow, cold snaps, and biting winds are common, with occasional clear breaks."
    ),

    PLAINS(
        "Plains",
        "A wide, open landscape with little shelter from the sky or wind.",
        "Weather varies widely, bringing storms, rain, wind, and snow depending on the season."
    ),

    VOID(
        "Void",
        "An unnatural expanse where reality feels unstable and the world itself seems fractured.",
        "Conditions fluctuate unpredictably, shifting between clarity and surreal disturbances."
    );

    private final String shortDesc;
    private final String longDesc;
    private final String weatherDesc;

    Climate(String shortDesc, String longDesc, String weatherDesc) {
        this.shortDesc = shortDesc;
        this.longDesc = longDesc;
        this.weatherDesc = weatherDesc;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public String getLongDesc() {
        return longDesc;
    }

    public String getWeatherDesc() {
        return weatherDesc;
    }

    public static Climate fromString(String input) {
        for (Climate c : values()) {
            if (c.name().equalsIgnoreCase(input.trim())) {
                return c;
            }
        }
        return null;
    }
}