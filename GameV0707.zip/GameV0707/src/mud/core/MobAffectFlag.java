package mud.core;

public enum MobAffectFlag {
    NOKILL(1 << 0),
    REGENERATION(1 << 1),
    REINCARNATE(1 << 2),
	DOUBLEATTACK(1 << 3),
	DUALWIELD(1 << 4),
	INVISIBLE(1 << 5),
	NOSUMMON(1 << 6),
	HIDE(1 << 7),
	SNEAK(1 << 8),
	
	SECONDHIT(1 << 9), // monk flag
	OFFHANDHIT(1 << 10), // monk flag
	BLOCK(1<<11), // monk flag
	;

    private final int bit;
    MobAffectFlag(int bit) { this.bit = bit; }
    public int getBit() { return bit; }
}