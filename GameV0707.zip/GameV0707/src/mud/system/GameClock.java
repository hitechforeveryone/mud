package mud.system;

import mud.core.*;
import mud.spell.*;
import mud.spell.effects.*;
import mud.combat.*;
import mud.config.*;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class GameClock {


	private static int currentTick = 0;
	private final int ticksPerDay = Config.ticksPerDay; // 60 ticks = 1 game day
	private int ticksPerWeatherUpdate = ticksPerDay / 4;
	private int ticksPerSpeech = ticksPerDay / 8;
	private final int sunriseTick = Config.sunriseTick; // example: tick 15
	private final int sunsetTick = Config.sunsetTick;  // example: tick 45
	private int currentDay = 0;
	private int currentMonth = 0;
	private int currentWeek = 0;
	private int currentYear = 0;
	int currentHour;

	private final CalendarSystem calendar;
	private List<Moon> moons = new ArrayList<>();
	private int tickCounter = 0;

	public GameClock(CalendarSystem calendar) {
		this.calendar = calendar;
	}

	public void start() {
		startMobMovementTicker();
		startCombatTicker();    // 
		startWorldTicker();     // 

	}

	private void startWorldTicker() {
		Thread clockThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(10 * 1000); // 10-second global ticks
					tick();
					tickAllMobs();
				} catch (InterruptedException e) {
					System.err.println("GameClock interrupted.");
					break;
				}
			}
		});

		clockThread.setDaemon(true);
		clockThread.setName("GameClock-Thread");
		clockThread.start();
	}

	public void startCombatTicker() {
		Thread combatThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(1000); // 1 second ticks for combat
					tickCombat();       // run only combat logic
				} catch (InterruptedException e) {
					System.err.println("Combat thread interrupted.");
					break;
				}
			}
		});

		combatThread.setDaemon(true);
		combatThread.setName("CombatTick-Thread");
		combatThread.start();
	}

	private void startMobMovementTicker() {
		Thread mobMoveThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(5000); // Every 5 seconds

				} catch (InterruptedException e) {
					System.err.println("Mob movement thread interrupted.");
					break;
				}
			}
		});
		mobMoveThread.setDaemon(true);
		mobMoveThread.setName("MobMovement-Thread");
		mobMoveThread.start();
	}

	public void tick() {

		tickCounter++;
		int tickOfDay = tickCounter % ticksPerDay;

		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					// corpse stuff, this works
					for (ObjectItem obj : room.getObjects()) {
						if (obj.isCorpse()) {
							obj.decrementDecay();
							if (obj.getDecayTicks() == (Config.ticksPerDay-1)) {
								room.broadcastToRoom("The " + obj.getName() + " is starting to smell foul...");
							}			        
							if (obj.getDecayTicks() <= 0) {
								handleCorpseDecay(room, obj);
							}
						}
					}// end corpse stuff

				}
			}


			if (tickOfDay == sunriseTick) {
				//		System.out.println("SUNRISE TRIGGERED");
				updateRoomLighting(true);   // sunrise → NOT night
				//		System.out.println("Tick of Day: " + tickOfDay);
				broadcastToOutsidePlayers(world,"🌅 The sun rises on the world.");
			}   // 

			if (tickOfDay == sunsetTick) {
				//		System.out.println("SUNSET TRIGGERED");
				updateRoomLighting(false);    // sunset → night begins
				//		System.out.println("Tick of Day: " + tickOfDay);
				broadcastToOutsidePlayers(world,"🌇 The sun sets over the land.");
			}
		}


		if (tickCounter % ticksPerWeatherUpdate == 0) {
			//		System.out.println("[Weather] Ticking weather update...");
			for (World world : WorldManager.getAllWorlds()) {
				//			System.out.println("[Weather] World: " + world.getName());
				WeatherSystem.updateWeather(world);

				// testing this
				sendMoons(world);
			}
		}



		// Mob & Object Speeches, undewaterTck dmg
		// this works as intended
		if (tickCounter % ticksPerSpeech == 0) {
			// these work
			objSpeechTick(); 
			mobSpeechTick();
			underwaterTick();
		}

		spellTicks();

		// Mob Movement and MobBehavior stuff
		MobAI.tickMobBehavior(); // partly works, still adding AI stuff to this
		MobAI.tickMobMovement(); // this one works


		// ✅ Trigger advanceDay at END of tick cycle
		if (tickOfDay == ticksPerDay - 1) {
			advanceDay();   // This is now the only call
		}

	} // end tick

	private void underwaterTick() {
		// If PLAYER (not Mob) is underwater, and does Not have UNDERWATER_BREATHING, take 5% MaxHP damage
		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				for (Room room : zone.getRooms().values()) {
					if (room.hasFlag(RoomFlag.UNDERWATER)) {
						for (Player p : room.getPlayers()) {
							if (!p.hasEffect(EffectType.UNDERWATER_BREATHING)) {
								int drownDmg = 0;
								drownDmg = (int) p.getMaxHP()/20;
								p.takeDamage(drownDmg, MagicDamageType.WATER);
								String icon = MagicDamageType.WATER.getIcon();
								p.sendMessage(Ansi.RED + "-" + drownDmg + icon + Ansi.RESET);
								p.sendMessage("You feel a burning sensation in your chest as your run out of air.");
							}
						}
					}
				}
			}
		}
	}


	private void mobSpeechTick() {
		// If mob is Talker, say random speech from speech list
		//		System.out.println("[Speeches] Ticking Talker Mob speeches...");
		for (Mob mob: WorldManager.getAllMobs()) {
			if (mob.isTalker()) {
				Random random = new Random();
				int randomIndex = random.nextInt(mob.getSpeeches().size());
				String randomSpeech = mob.getMobName() + " says '" + mob.getSpeeches().get(randomIndex) + "'";
				mob.getRoom().broadcast(randomSpeech, mob);
			}
		}
	}


	private void objSpeechTick() {
		// if obj is Sapient, say random speech from speech list
		//		System.out.println("[Speeches] Ticking Sapient Object speeches...");
		for (Mob mob : WorldManager.getAllMobs()) {
			for (ObjectItem obj : mob.getEquipment().values()) {
				if (obj != null && obj.isSapient() && obj.getSapientSpeeches() != null) {
					List<String> speeches = obj.getSapientSpeeches();
					// Skip if list is empty
					if (speeches.isEmpty()) {
						continue;
					}
					// Safe random index
					int randomIndex = ThreadLocalRandom.current().nextInt(speeches.size());
					String line = speeches.get(randomIndex);
					String randomSpeech = capitalizeFirstLetter(obj.getName()) + " whispers '" + line + "'";
					mob.sendMessage(randomSpeech);
					mob.getRoom().broadcast(mob.getMobName() + "'s " + obj.getName() + " whispers to them.", mob);
				}
			}
		}	
	}


	public static void tickCombat() {
		Set<Mob> alreadyProcessed = new HashSet<>();

		for (Mob mob : WorldManager.getAllMobs()) {
			Mob target = mob.getTarget();

			// Skip invalid or already processed
			if (target == null || mob.isDead() || target.isDead() || alreadyProcessed.contains(mob) || alreadyProcessed.contains(target)) {
				continue;
			}

			if (mob.canAttack()) {
				StringBuilder roundSummary = new StringBuilder();

				// Mob attacks target
				roundSummary.append(CombatManager.performAttack(mob, target)).append("\n");
				mob.setLastAttackTime();

				// Check if target is still alive before they counterattack
				if (!target.isDead() && target.canAttack() && target.getTarget() == mob) {
					roundSummary.append(CombatManager.performAttack(target, mob)).append("\n");
					target.setLastAttackTime();
				}

				// Final HP/MP summary (if both still exist)
				if (!mob.isDead() && !target.isDead()) {
					roundSummary.append(CombatManager.getCombatStatus(mob, target));
				}

				// Send result to both players if applicable
				if (mob instanceof Player playerMob) {
					playerMob.sendMessage(roundSummary.toString().trim());
				}

				if (target instanceof Player playerTarget) {
					playerTarget.sendMessage(roundSummary.toString().trim());
				}

				// Log for debugging
				System.out.println("[Combat Tick] " + mob.getMobName() + " vs " + target.getMobName());
				System.out.println(roundSummary);

				// Mark both as processed
				alreadyProcessed.add(mob);
				alreadyProcessed.add(target);
			}
		}
	}




	public void advanceDay() {
		int lastAdvancedTick = -1;
		if (currentTick == lastAdvancedTick) {
			System.err.println("⚠️ Skipping duplicate advanceDay() call");
			return;
		}

		lastAdvancedTick = currentTick;
		currentTick += ticksPerDay;

		for (World world : WorldManager.getAllWorlds()) {
			for (Zone zone : world.getZones()) {
				zone.incrementResetCounter();

				checkZoneReset(zone,currentDay);						
			}
		}

		System.out.println("[GameClock] New day: " + getCurrentDateString());
		for (Player player : WorldManager.getActivePlayers()) {
			World world = player.getCurrentWorld();
			sendDateAndMoonInfo(player, world);
		}

	} // end advanceDay

	// --- Time of Day ---
	public boolean isNight() {
		int tickOfDay = tickCounter % ticksPerDay;
		return tickOfDay < sunriseTick || tickOfDay >= sunsetTick;
	}


	public boolean isDay() {
		return !isNight();
	}

	public static int getCurrentTick() {
		return currentTick;
	}

	public int getCurrentDayIndex() {
		return currentTick / ticksPerDay;
	}



	public String getCurrentDateString() {
		int dayIndex = getCurrentDayIndex(); // This must be counting total in-game days.

		String dayName = calendar.getDayName(dayIndex);
		int week = calendar.getWeekOfMonth(dayIndex); // 0-based index
		String month = calendar.getMonthNameByDay(dayIndex); // ✅ FIXED
		int year = calendar.getYear(dayIndex);

		return String.format("%s, Week %d of %s, Year %d", dayName, week, month, year);
	}
	
	

	// --- Moon Management ---
	
	public void addMoon(Moon moon) {
		moons.add(moon);
	}

	public List<Moon> getMoons() {
		return moons;
	}

	
	public void setMoons(List<Moon> moons) {
		this.moons = moons;
	}


	public String getDayOfWeek() {
		return calendar.getDayName(getCurrentDay());
	}

	public String getFormattedDate() {
		return String.format("%s, Week %d of %s, Year %d", 
				getDayOfWeek(), currentWeek, getCurrentMonthName(), currentYear);
	}

	public String getCurrentMonthName() {
		return calendar.getMonthName(currentMonth);
	}
	public int getCurrentDayOfYear() {
		return (currentMonth * calendar.getDaysPerMonth()) + currentDay;
	}
	public int getCurrentDay() {
		return currentDay;
	}

	public int getCurrentMonth() {
		return currentMonth;
	}

	public int getCurrentWeek() {
		return currentWeek;
	}

	public int getCurrentYear() {
		return currentYear;
	}

	public Moon getMoonByName(String name) {
		for (Moon m : moons) {
			if (m.getName().equalsIgnoreCase(name)) return m;
		}
		return null;
	}

	public void sendDateAndMoonInfo(Player player, World world) {

	    player.sendMessage("📅 Date: " + getCurrentDateString());

	    List<Moon> moons = world.getMoons();
	    if (moons != null && !moons.isEmpty()) {

	        for (Moon moon : moons) {
	            MoonPhase phase = moon.getPhase();

	            player.sendMessage(
	                "🌙 " + moon.getName()
	                + " — Phase: "
	                + phase.getDisplayName()
	                + " (" + (phase.getPhaseIndex() + 1)
	                + "/" + MoonPhase.getPhaseCount() + ")"
	            );
	        }

	    } else {
	        // player.sendMessage("🌙 No Moons");
	    }

	    Zone zone = player.getCurrentRoom().getZone();
	    if (zone != null && zone.getCurrentWeather() != null) {
	        player.sendMessage("☁️ Weather: " + zone.getCurrentWeather().getDescription());
	    }
	}	// end sendDateAndMoonInfo


	public void sendMoons(World world) {
	    List<Moon> moons = world.getMoons();
	    if (moons == null || moons.isEmpty()) return;

	    boolean lightingChanged = false;

	    for (Moon moon : moons) {
	        moon.advance();

	        if (moon.enteredFullMoon()) {
	            String message = "🌕 " + moon.getName() + " is full, bathing the land in light.";
	            broadcastToOutsidePlayers(world, message);
	            lightingChanged = true;

	            if (moon.isEclipseDay()) {
	                triggerEclipseEvent(world, moon);
	            }
	        }
	    }

	    boolean allNew = moons.stream()
	            .allMatch(m -> m.getPhase() == MoonPhase.NEW_MOON);

	    if (allNew && world.isDay()) {
	        triggerGrandCelestialEvent(world);
	        lightingChanged = true;
	    }

	    if (lightingChanged) {
	        updateRoomLightingWithCelestials(world);

	        // Recalculate individual room light to apply override effects correctly
	        for (Zone zone : world.getZones()) {
	            for (Room room : zone.getRooms().values()) {
	                room.recalculateLighting();
	            }
	        }
	    }
	}


	private void triggerGrandCelestialEvent(World world) {

		System.out.println("A grand solar event occurs, darkening the sky!");
		for (Player player : WorldManager.getActivePlayers()) {
			if (player.getWorld() == world) {
				player.sendMessage("A grand solar event occurs, darkening the sky!");
			}
		}
	} // end triggerGrandCelestialEvent

	private void triggerEclipseEvent(World world, Moon moon) {
	    switch (moon.getEclipseType()) {
	    case LUNAR:
	        for (Player player : WorldManager.getActivePlayers()) {
	            if (player.getWorld() == world && player.getCurrentRoom().isOutside()) {
	                player.sendMessage("🌑 A lunar eclipse shrouds " + moon.getName() + "!");
	            }
	        }
	        break;

	    case SOLAR:
	        for (Player player : WorldManager.getActivePlayers()) {
	            if (player.getWorld() == world && player.getCurrentRoom().isOutside()) {
	                player.sendMessage("🌘 A solar eclipse darkens the sky!");
	            }
	        }
	        break;
	    }
	}	// end triggerEclipseEvent

	private void updateRoomLighting(boolean isDay) {
	    boolean isNight = !isDay;

	    for (World world : WorldManager.getAllWorlds()) {
	        for (Zone zone : world.getZones()) {
	            for (Room room : zone.getRooms().values()) {
	                int baseLevel = 0; // default night

	                boolean hasLightSource = room.getObjects().stream()
	                        .anyMatch(obj -> obj.getType() == ObjectType.LIGHTSOURCE);

	                if (hasLightSource) baseLevel = 3;       // magical light
	                else if (isDay) baseLevel = 2;           // daylight

	                room.setBaseLightLevel(baseLevel);
	                room.setNightTime(isNight);              // set room boolean
	                room.recalculateLighting();              // apply overrides (moons, spells)
	            }
	        }
	    }
	}


	
	private void updateRoomLightingWithCelestials(World world) {
	    boolean isDay = world.isDay();

	    // Compute the maximum moonlight and eclipse factor
	    int moonLight = 0;
	    double eclipseModifier = 1.0;

	    for (Moon moon : world.getMoons()) {
	        moonLight = Math.max(moonLight, moon.getLightContribution());
	        eclipseModifier = Math.min(eclipseModifier, moon.getEclipseModifier());
	    }

	    for (Zone zone : world.getZones()) {
	        for (Room room : zone.getRooms().values()) {

	            // Don't override temporary magical light effects
	            if (room.getLightLevel() != room.getBaseLightLevel()) continue;

	            int level = 0;

	            boolean hasLightSource = room.getObjects().stream()
	                    .anyMatch(obj -> obj.getType() == ObjectType.LIGHTSOURCE);

	            if (hasLightSource) {
	                level = 3; // artificial / magical
	            }
	            else if (isDay) {
	                level = 2; // daylight
	            }
	            else if (room.hasFlag(RoomFlag.OUTSIDE)) {
	                // Nighttime outside: moonlight adjusted for eclipses
	                level = (int)Math.round(moonLight * eclipseModifier);
	            }
	            else {
	                level = 0; // indoor night
	            }

	            room.setBaseLightLevel(level);
	        }
	    }
	}




	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";
		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}


	public CalendarSystem getCalendar() {
		return calendar;
	}
	private String capitalizeFirstLetter(String input) {
		if (input == null || input.isEmpty()) return input;
		return input.substring(0, 1).toUpperCase() + input.substring(1);
	}

	public String getSunriseTime() {
		return ticksToTimeString(sunriseTick);
	}

	public String getSunsetTime() {
		return ticksToTimeString(sunsetTick);
	}

	// Helper to convert tick to HH:mm format (assumes 60 ticks per 24 hours)
	private String ticksToTimeString(int tick) {
		// 60 ticks = 24 hours
		// So each tick = 24/60 = 0.4 hours = 24 minutes
		double hoursDecimal = (tick * 24.0) / ticksPerDay;
		int hours = (int) hoursDecimal;
		int minutes = (int) ((hoursDecimal - hours) * 60);

		String ampm = (hours >= 12) ? "PM" : "AM";
		int displayHour = hours % 12;
		if (displayHour == 0) displayHour = 12;

		return String.format("%02d:%02d %s", displayHour, minutes, ampm);
	}

	private void checkZoneReset(Zone zone, int currentDay) {

		ZoneResetType type = zone.getResetType();
		int timer = zone.getResetTimer();
		if (timer <= 0) return; // skip if no timer set
		boolean ready = zone.getDaysSinceReset() >= timer;
		if (!ready) return;
		switch (type) {
		case NEVER: // default, zone never undocks/resets
			break;
		case WHEN_EMPTY: {// Reset when empty
			if (!zone.hasPlayers()) zone.resetZone();
			break;
		}
		case ALWAYS: // Always reset
		{
			System.out.println("Resetting zone: " + zone.getName());
			zone.resetZone();
			break;
		}
		case RESET_AND_UNLOAD: {// Reset and unload
			if (!zone.hasPlayers()) {
				zone.resetZone();

				System.out.println("Resetting zone: " + zone.getName());
				WorldManager.unloadZone(zone);
			}                     
			break;
		}
		default:

			break;
		}
	}


	private void broadcastToOutsidePlayers(World world, String message) {
		System.out.println("📣 Broadcasting to outside players in world " + world.getWorldId());
		System.out.println("🧍 Active players: " + WorldManager.getActivePlayers().size());

		for (Player player : WorldManager.getActivePlayers()) {
			if (player.getCurrentWorld() != world) {
				continue; // 🚫 different world
			}

			Room room = player.getCurrentRoom();
			if (room == null) {
				System.out.println("🚫 Player " + player.getName() + " is not in a room.");
				continue;
			}

			if (room.hasFlag(RoomFlag.OUTSIDE)) {
				System.out.println("✅ Sending outside mesg to " + player.getName());
				player.sendMessage(message);
			} else {
				System.out.println("⛔ Room " + room.getId() + " is not outside for player " + player.getName());
			}
		}
	}

	public String getFormattedTime(World world) {
	    StringBuilder sb = new StringBuilder();

	    int curTick = world.getClock().tickCounter;
	    int dayOfYear = getCurrentDayOfYear();
	    int currentMonth = getCurrentMonth();
	    int currentWeek = getCurrentWeek();
	    int currentYear = getCurrentYear();

	    String dayName = calendar.getDayName(dayOfYear);
	    String monthName = calendar.getMonthName(currentMonth);

	    sb.append("📅 Date: ")
	      .append(dayName)
	      .append(", Week ").append(currentWeek)
	      .append(" of ").append(monthName)
	      .append(", Year ").append(currentYear)
	      .append("\n");

	    // Moon info (prettified, indexed)
	    if (world.getMoons() != null && !world.getMoons().isEmpty()) {
	        for (Moon moon : world.getMoons()) {
	            MoonPhase phase = moon.getPhase();

	            sb.append("🌙 ")
	              .append(moon.getName())
	              .append(" — Phase: ").append(phase.getDisplayName())
	              .append(" (").append(phase.getPhaseIndex() + 1)
	              .append("/")
	              .append(MoonPhase.getPhaseCount()).append(")\n");
	        }
	    }

	    String timeDesc = calendar.getTimeOfDay(curTick);
	    sb.append("🕒 Time: ")
	      .append(timeDesc)
	      .append(" - Hour: ")
	      .append(ticksToTimeString(curTick));

	    return sb.toString();
	} // end getFormattedTime


	public void tickAllMobs() {
		for (Mob mob : WorldManager.getAllMobs()) {
			mob.passiveRegenTick();
		}
	}

	private void handleCorpseDecay(Room room, ObjectItem corpse) {
		// Drop loot on the floor
		for (ObjectItem loot : corpse.getContents()) {
			room.addObject(loot);
		}
		corpse.getContents().clear();

		// Remove corpse object
		room.removeObject(corpse);
		room.broadcastToRoom("The " + corpse.getName() + " decays into dust, leaving its contents behind.");
	}



	public void mobSpellsExpire() {
		// TODO
		// make these all expire
		// Mob Spells and Effect Ticks 
	}
	public void roomSpellsExpire() {
		// TODO
		// make these all expire
		// Room aoe Spells and Effect/ticks
	}

	public void spellTicks() {
		// TODO

		// Spells and Effect Ticks
		BerserkEffect.tickAll(); // attack next player
		BladestormEffect.tickAll(); 
		BleedEffect.tickAll();
		BlindEffect.tickAll();
		BoneShieldEffect.tickAll();

		CharmPersonEffect.tickAll();
		ConfusionEffect.tickAll();
		ContinualLightEffect.tickAll();
		CrushingGripEffect.tickAll();

		DancingLightsEffect.tickAll();

		EntangleEffect.tickAll();

		FearEffect.tickAll();
		FireShieldEffect.tickAll();
		FlameBarrierEffect.tickAll(); // icewall spoof
		ForcefulHandEffect.tickAll();
		FortifyEffect.tickAll(); // icewall spoof
		FrostbiteEffect.tickAll();

		HoldEffect.tickAll();

		IcewallEffect.tickAll(); // icewall temp block an exit
		ItemLevitateEffect.tickAll();
		ItemWaterWalkEffect.tickAll();

		LifeBloomEffect.tickAll();

		MirrorImageEffect.tickAll();
		MobLevitateEffect.tickAll();
		MobUnderwaterBreathingEffect.tickAll();
		MobWaterWalkEffect.tickAll();

		PoisonEffect.tickAll();
		PortalEffect.tickAll();

		RampartEffect.tickAll(); // icewall spoof
		RootEffect.tickAll();

		SapEffect.tickAll();
		ShadowCloneEffect.tickAll();
		SilenceEffect.tickAll();
		SpatialDisruptorEffect.tickAll(); // room nosumm
		StunEffect.tickAll(); // 

		TrackSpell.tick();

		WebEffect.tickAll();
		WormholeEffect.tickAll();
	}

} // end GameClock
