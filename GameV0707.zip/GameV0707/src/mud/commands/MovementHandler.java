package mud.commands;

import mud.core.Direction;
import mud.core.Door;
import mud.core.EffectType;
import mud.core.ItemEffect;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.Player;
import mud.core.Room;
import mud.core.RoomFlag;
import mud.core.World;
import mud.core.WorldManager;
import mud.core.Zone;
import mud.core.ZoneExit;
import mud.spell.effects.FlameBarrierEffect;
import mud.spell.effects.FortifyEffect;
import mud.spell.effects.IcewallEffect;
import mud.spell.effects.RampartEffect;

public class MovementHandler {


	static boolean isDirection(String word) {
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(word)) return true;
		}
		return false;
	}

	// Updated handleMovement with FALL handling incorporated
	@SuppressWarnings("unused")
	static String handleMovement(Player player, String direction) {
		Room current = player.getCurrentRoom();
		Direction dirEnum = Direction.fromString(direction);

		boolean hasBoat = false;	    
		for (ObjectItem ob : player.getInventory())  {
			if (ob.getType() == ObjectType.BOAT) {
				hasBoat = true;
			}
		}


		if (!player.isAttacking()) {
			if (dirEnum == null) return "Invalid direction.";

			String restriction = checkMovementRestrictions(player, dirEnum);
			if (restriction != null) return restriction;

			Door door = current.getDoor(dirEnum);
			if (door != null) {
				if (!door.isOpen()) return "🛋 The " + door.getDoorName() + " is closed.";
				if (door.isLocked()) return "🔒 The " + door.getDoorName() + " is locked.";
			}

			// --- Cross-Zone Exit Handling ---
			ZoneExit crossZoneExit = current.getZoneExit(dirEnum);
			if (crossZoneExit != null) {
				Zone nextZone = WorldManager.loadZone(crossZoneExit.getWorldId(), crossZoneExit.getTargetZoneId());
				nextZone.setParentWorld(WorldManager.loadWorld(crossZoneExit.getTargetWorldId()));
				Room nextRoom = nextZone.getRoom(crossZoneExit.getTargetRoomId());

				if (nextRoom == null) return "⚠️ The path seems blocked (target room not loaded).";
				if (nextZone == null) return "⚠️ The path seems blocked (target zone missing).";

				current.setExit(dirEnum, nextRoom);
				Direction reverse = dirEnum.getOpposite();
				nextRoom.setExit(reverse, current);


				// handle dest ON_WATER flag
				if (nextRoom.hasFlag(RoomFlag.ON_WATER) && (!player.hasEffect(EffectType.WATER_WALK) || hasBoat==false)) {
					return "You require a boat to go that way.";
				}


				int nRmCnt = nextRoom.getPlayers().size();	            
				if (nextRoom.hasFlag(RoomFlag.TUNNEL) && (nRmCnt >= nextRoom.getTunnelNum())) {
					return "That tunnel is too narrow for another person.";
				}

				World w = nextRoom.getZone().getParentWorld();

				current.removeMob(player);
				nextRoom.addMob(player);
				player.setCurrentRoom(nextRoom);
				player.setCurrentZone(nextRoom.getZone());
				player.setCurrentWorld(w);
				player.setRoom(nextRoom);  

				player.sendMessage("You travel " + direction + " to world: " + w.getWorldId() + " zone:" + nextZone.getZoneId() + ".");
				LookHandler.handleLook(player, new String[]{"look"});

				// Fall check
				handleFall(player, nextRoom);
				return null;
			}

			// --- Normal In-Zone Movement ---
			Room next = current.getExit(dirEnum);
			if (next == null) return "You can't go that way.";

			Zone currentZone = player.getCurrentZone();
			if (currentZone == null) return "⚠️ Movement failed: You are not currently in a valid zone.";

			// handle dest ON_WATER flag
			if (next.hasFlag(RoomFlag.ON_WATER) && (!player.hasEffect(EffectType.WATER_WALK) || hasBoat==false)) {
				return "You require a boat to go that way.";
			}

			int nRmCnt = next.getPlayers().size();	            
			if (next.hasFlag(RoomFlag.TUNNEL) && (nRmCnt >= next.getTunnelNum())) {
				return "That tunnel is too narrow for another person.";
			}

			current.removeMob(player);
			next.addMob(player);
			player.setCurrentRoom(next);

			player.sendMessage("You move " + direction + ".");
			LookHandler.handleLook(player, new String[]{"look"});

			// Fall check
			handleFall(player, next);
		} else {
			player.sendMessage("You are in combat.");
		}

		return null;
	}

	// --- FALL HANDLING ---
	private static void handleFall(Player player, Room room) {
		if (!room.hasFlag(RoomFlag.FALL)) return;

		boolean levEquipped = false;	    
		for (ObjectItem ob : player.getEquipment().values())  {
			if (ob.hasEffect(ItemEffect.LEVITATE)) {
				levEquipped = true;
			}
		}

		boolean levitating = player.hasEffect(EffectType.LEVITATE)
				|| levEquipped==true;

		if (levitating) {
			player.sendMessage("You hover safely over the drop.");
			return;
		}

		Room down = room.getExit(Direction.DOWN);
		if (down == null) {
			player.sendMessage("You slip… but nowhere to fall!");
			return;
		}

		// Perform fall
		room.removeMob(player);
		down.addMob(player);
		player.setCurrentRoom(down);

		player.sendMessage("You fall!\n");
		LookHandler.handleLook(player, new String[]{"look"});
	}

	public static String checkMovementRestrictions(Mob player, Direction dir) {
		// barrier/wall visuals		
		// --- ICEWALL (per-room-direction blocking) ---
		if (player.getCurrentRoom().hasEffectOnExit(dir, IcewallEffect.class)) {
			return "A massive wall of ice blocks the " + dir.toString().toLowerCase() + " exit!";
		}

		// --- Rampart (per-room-direction blocking) ---
		if (player.getCurrentRoom().hasEffectOnExit(dir, RampartEffect.class)) {
			return "A rampart of stone bares the " + dir.toString().toLowerCase() + " exit!";
		}

		// --- Fortify (per-room-direction blocking) ---
		if (player.getCurrentRoom().hasEffectOnExit(dir, FortifyEffect.class)) {
			return "A steel fortification blocks the " + dir.toString().toLowerCase() + " exit!";
		}
		// --- Flame Barrier (per-room-direction blocking) ---
		if (player.getCurrentRoom().hasEffectOnExit(dir, FlameBarrierEffect.class)) {
			return "A barrier of flames blocks the " + dir.toString().toLowerCase() + " exit!";
		}


		// player has Effect
		// --- STUN ---
		if (player.hasEffect(EffectType.STUN)) {
			return "💪 You are stunned and cannot move!";
		}

		// --- ROOT (cannot move at all) ---
		if (player.hasEffect(EffectType.ROOT)) {
			return "🌍 Your legs are rooted to the ground!";
		}

		// --- ENTANGLE (cannot move at all) ---
		if (player.hasEffect(EffectType.ENTANGLE)) {
			return "🌿 You are entangled and cannot move!";
		}

		// --- WEB (movement blocked) ---
		if (player.hasEffect(EffectType.WEB)) {
			return "🕷️ Sticky webs bind your legs—you can’t move!";
		}

		// --- FROSTBITE (cannot move at all) ---
		if (player.hasEffect(EffectType.FROSTBITE)) {
			return "❄️ Your feet are frozen to the ground!";
		}

		// --- HOLD (cannot move at all) ---
		if (player.hasEffect(EffectType.HOLD)) {
			return "💫 You are held immobile!";
		}

		// More effects can be added here...

		return null; // no restriction found
	}

	
}
