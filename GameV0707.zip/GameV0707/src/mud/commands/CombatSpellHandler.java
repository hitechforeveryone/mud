package mud.commands;

import java.util.*;

import mud.combat.*;
import mud.core.*;
import mud.spell.*;
import mud.spell.effects.*;

public class CombatSpellHandler {

	public static String handleConsider(Player player, Mob target) { 
		if (target == null) return "Consider what?";

		StringBuilder sb = new StringBuilder();
		String reset = Ansi.RESET;

		if (player.hasEffect("blind")) {
			return Ansi.BOLD + "You consider " + target.getMobName() + "..." + reset + "\n"
					+ "But you can't see a thing!\n";
		}

		int playerLevel = player.getLevel();
		int mobLevel = target.getLevel();
		int levelDiff = mobLevel - playerLevel;

		boolean isHigher = mobLevel > playerLevel;

		// Display flags
		boolean showFullStats = !isHigher;              // lower or equal mobs always full
		boolean showPartialStats = isHigher && levelDiff <= 5; // slightly higher partially masked
		boolean showIdentity = !isHigher || levelDiff <= 8;    // identity masking for higher mobs

		// Header
		sb.append(Ansi.BOLD)
		.append("╔══════════════════════════════════════╗\n")
		.append("║         Consider: ").append(target.getMobName()).append("\n")
		.append("╠══════════════════════════════════════╣\n")
		.append(reset);

		// Level & EXP
		sb.append("║ Level: ");
		if (showIdentity) {
			sb.append(mobLevel)
			.append(mobLevel > playerLevel ? " (Stronger)" :
				mobLevel < playerLevel ? " (Weaker)" : " (Evenly matched)")
			.append("    EXP Reward: ").append(target.getExpValue());
		} else {
			sb.append("???    EXP Reward: ???");
		}
		sb.append("\n");

		// Effects
		List<String> effectStrings = target.getActiveEffects().stream()
				.map(e -> switch (e.getName().toLowerCase()) {
				case "bleeding" -> Ansi.RED + "[BLEEDING]" + reset;
				case "shielded" -> Ansi.CYAN + "[SHIELDED]" + reset;
				case "burning" -> Ansi.MAGENTA + "[BURNING]" + reset;
				default -> "[" + e.getName().toUpperCase() + "]";
				}).toList();

		if (!effectStrings.isEmpty()) {
			sb.append("║ Effects: ").append(String.join(" ", effectStrings)).append("\n");
		}

		// Identity
		sb.append("╠═════════ Identity ═══════════════════╣\n");
		if (showFullStats || (isHigher && levelDiff <= 8)) {
			sb.append("Race: ").append(target.getRace());
			String subrace = target.getSubrace();
			if (subrace != null && !subrace.isBlank() && !subrace.equalsIgnoreCase("none")) {
				sb.append(" — Subrace: ").append(subrace);
			}
			sb.append("\n");
		} else {
			sb.append("Race: ???\n");
		}

		// Profession & Rank
		String profession = showFullStats ? 
				(target.getProfession() != null ? target.getProfession().toString() : "None") : "???";
		String rank = showFullStats ? 
				(target.getRank() != null ? target.getRank().name().replace('_', ' ') : "???") : "???";

		sb.append("Profession: ").append(profession).append(" — Rank: ").append(rank).append("\n");

		// Stats
		sb.append("╠═════════ Stats ══════════════════════╣\n");
		if (showFullStats) {
			sb.append("Stats: Str ").append(target.getStrength())
			.append(", Sta ").append(target.getStamina())
			.append(", Int ").append(target.getIntellect())
			.append(", Agi ").append(target.getAgility()).append("\n");
		} else if (showPartialStats) {
			sb.append("Stats: Str ???, Sta ???, Int ???, Agi ???\n");
		} else {
			sb.append("Stats: Str ????, Sta ????, Int ????, Agi ????\n");
		}

		sb.append("╚══════════════════════════════════════╝\n\n");

		// Extended description
		sb.append("\n").append(target.getLongDescription());
		sb.append("\n").append(target.getExtendedDescription());

		// Danger assessment
		if (levelDiff == 0) sb.append("You and ").append(target.getMobName()).append(" are evenly matched.\n");
		else if (levelDiff < 0) sb.append(target.getMobName()).append(" seems weaker than you.\n");
		else if (levelDiff > 0 && levelDiff <= 3) sb.append(target.getMobName()).append(" might be a fair fight.\n");
		else if (levelDiff > 3 && levelDiff <= 6) sb.append(target.getMobName()).append(" seems stronger than you.\n");
		else sb.append("You sense great danger from ").append(target.getMobName()).append("...\n");



		return sb.toString();
	} 


	
	static String handleAttack(Player player, String targetInput) {
		if (player == null || player.getCurrentRoom() == null) {
			return "You're nowhere and can't attack anything.";
		}

		Room room = player.getCurrentRoom();

		// Parse input like "2.goblin"
		int targetIndex = 1;
		String keyword = targetInput.toLowerCase();

		if (targetInput.contains(".")) {
			String[] parts = targetInput.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// fallback: treat whole string as keyword
				targetIndex = 1;
				keyword = targetInput.toLowerCase();
			}
		}

		// Find matching mobs by keyword
		List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
		if (matchingMobs.size() < targetIndex) {
			return "No such target.";
		}

		Mob target = matchingMobs.get(targetIndex - 1);

		if (target == player) return "You can't attack yourself.";
		if (!player.canAttack()) {
			player.sendMessage("You're still recovering from your last attack!");
			return "";
		}

		player.setLastAttackTime();

		// Mark both as engaged in combat
		player.setTarget(target);
		if (target.getTarget() == null) {
			target.setTarget(player); // Mob knows who attacked it
		}

		return CombatManager.performAttack(player, target);
	}


	public static boolean handleShortCast(Player player, String[] tokens) {
		if (player == null || tokens == null || tokens.length == 0) {
			return false;
		}

		String spellName = tokens[0].toLowerCase();
		String targetName = (tokens.length > 1)
				? String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length)).toLowerCase()
						: null;

		Spell spell = SpellManager.getSpellByName(spellName);
		if (spell == null) {
			return false; // not an ability, let normal command flow continue
		}

		// Only shortcut abilities / instant casts
		if (!spell.isAbility() && !spell.isInstantCast()) {
			return false;
		}

		// --- Profession Restriction ---
		if (player.getPrivilegeLevel() == 0) {
			Profession prof = player.getProfession();
			if (prof == null || !spell.getProfessions().contains(prof)) {
				player.sendMessage("You lack the training to use that ability.");
				return true;
			}
		}

		Room room = player.getCurrentRoom();

		// --- AUTO self-target ---
		if ((targetName == null || targetName.isEmpty()) && spell.isSelfTarget()) {
			boolean success = spell.cast(player, player);
			if (!success) {
				player.sendMessage("Your ability fails.");
			}
			return true;
		}

		if (targetName == null || targetName.isEmpty()) {
			player.sendMessage(spell.getName() + " on whom?");
			return true;
		}

		// 1) MOB in room
		Mob mobTarget = findMobTarget(room, targetName);
		if (mobTarget != null) {
			if (mobTarget.isDead()) {
				player.sendMessage(mobTarget.getMobName() + " is already dead.");
				return true;
			}

			boolean success = spell.cast(player, mobTarget);
			if (!success) {
				player.sendMessage("Your ability fails.");
			}
			return true;
		}

		// 2) Directional
		Direction dir = Direction.fromString(targetName);
		if (dir != null && spell.isDirectional()) {
			Room next = room.getExit(dir);
			if (next == null) {
				player.sendMessage("No such direction exists.");
				return true;
			}

			boolean success = spell.cast(player, dir);
			if (!success) {
				player.sendMessage("Your ability fizzles.");
			}
			return true;
		}

		// 3) Object — inventory
		ObjectItem invObj = player.getInventory().stream()
				.filter(o -> o.matchesKeyword(targetName))
				.findFirst()
				.orElse(null);

		if (invObj != null) {
			boolean success = spell.cast(player, invObj);
			if (!success) {
				player.sendMessage("Nothing happens.");
			}
			return true;
		}

		// 4) Object — room
		ObjectItem roomObj = room.getObjects().stream()
				.filter(o -> o.matchesKeyword(targetName))
				.findFirst()
				.orElse(null);

		if (roomObj != null) {
			boolean success = spell.cast(player, roomObj);
			if (!success) {
				player.sendMessage("Nothing happens.");
			}
			return true;
		}

		player.sendMessage("You see no such target.");
		return true;
	} // end



	static String handleCast(Player player, String spellName, String targetName) {

		Spell spell = SpellManager.getSpellByName(spellName);
		if (spell == null) {
			return "No such spell exists.";
		}

		// --- Profession Restriction ---
		if (player.getPrivilegeLevel() == 0) {
			Profession prof = player.getProfession();
			if (prof == null || !spell.getProfessions().contains(prof)) {
				return "You lack the knowledge to cast that spell.";
			}
		}

		// Silence / Quiet
		if (player.hasEffect(EffectType.SILENCE)) {
			return "You try to cast, but no sound escapes your lips...";
		}
		if (player.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
			return "You cannot cast here. The room is quieted.";
		}

		// Mana check
		if (spell.getManaCost() > player.getCurrentMP()) {
			return "You lack the mana to cast that spell.";
		}

		Room room = player.getCurrentRoom();

		// AUTO self-target
		if ((targetName == null || targetName.isEmpty()) && spell.isSelfTarget()) {
			boolean success = spell.cast(player, player);
			if (success) {
				player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
				return "You cast " + spell.getName() + " on yourself.";
			}
			return "Your spell fizzles.";
		}

		if (targetName == null || targetName.isEmpty()) {
			return "Cast on what?";
		}

		String tName = targetName.toLowerCase();

		// 1) MOB in room
		Mob mobTarget = findMobTarget(room, tName);
		if (mobTarget != null) {
			if (mobTarget.isDead()) return mobTarget.getMobName() + " is already dead.";
			boolean success = spell.cast(player, mobTarget);
			if (success) {
				player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
				return "You cast " + spell.getName() + " on " + mobTarget.getMobName() + ".";
			}
			return "Your spell fails.";
		}

		// 2) Directional
		Direction dir = Direction.fromString(tName);
		if (dir != null && spell.isDirectional()) {
			Room next = room.getExit(dir);
			if (next == null) return "No such direction exists.";
			boolean success = spell.cast(player, dir);
			if (success) {
				player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
				return "You cast " + spell.getName() + " to the " + dir.name().toLowerCase() + ".";
			}
			return "Your spell fizzles.";
		}

		// 3) Object — inventory
		ObjectItem invObj = player.getInventory().stream()
				.filter(o -> o.matchesKeyword(tName))
				.findFirst()
				.orElse(null);

		if (invObj != null) {
			boolean success = spell.cast(player, invObj);
			if (success) {
				player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
				return "You cast " + spell.getName() + " on " + invObj.getName() + ".";
			}
			return "Nothing happens.";
		}

		// 4) Object — room
		ObjectItem roomObj = room.getObjects().stream()
				.filter(o -> o.matchesKeyword(tName))
				.findFirst()
				.orElse(null);

		if (roomObj != null) {
			boolean success = spell.cast(player, roomObj);
			if (success) {
				player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
				return "You cast " + spell.getName() + " on " + roomObj.getName() + ".";
			}
			return "Nothing happens.";
		}

		return "You see no such target.";
	}

	public static Mob findMobTarget(Room room, String input) {
		if (room == null || input == null || input.isEmpty())
			return null;

		input = input.toLowerCase().trim();
		List<Mob> mobs = room.getMobs();
		if (mobs.isEmpty()) return null;

		int index = 1; // default
		String search = input;

		// ----- Parse numbered format: "2.orc" -----
		if (input.contains(".")) {
			String[] parts = input.split("\\.", 2);
			try {
				index = Integer.parseInt(parts[0]);
				search = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// treat as normal multi-keyword chain
				index = 1;
				search = input;
			}
		}

		// Split multi-keyword chain (orc.elder → ["orc","elder"])
		String[] chain = search.split("\\.");

		List<Mob> matches = new ArrayList<>();

		for (Mob mob : mobs) {
			String mobName = mob.getMobName().toLowerCase();
			List<String> keywords = mob.getKeywords().stream()
					.map(String::toLowerCase)
					.toList();

			boolean match = false;

			// 1. Exact name match
			if (mobName.equals(search)) match = true;

			// 2. Exact keyword match
			if (!match && keywords.contains(search)) match = true;

			// 3. Multi-keyword chain match
			if (!match && chain.length > 1) {
				boolean chainMatch = true;
				for (String word : chain) {
					if (!(mobName.contains(word) || keywords.contains(word))) {
						chainMatch = false;
						break;
					}
				}
				if (chainMatch) match = true;
			}

			// 4. Prefix/partial match
			if (!match) {
				if (mobName.startsWith(search)) match = true;
				else {
					for (String kw : keywords) {
						if (kw.startsWith(search)) {
							match = true;
							break;
						}
					}
				}
			}

			if (match) matches.add(mob);
		}

		if (matches.isEmpty()) return null;

		// numbered selection: "2.orc"
		if (index > 1) {
			if (index <= matches.size()) {
				return matches.get(index - 1);
			}
			return null; // requested index out of range
		}

		// default: return first match
		return matches.get(0);
	}

	public static String handleTarget(Mob caster, String targetName) {
		if (caster == null || caster.getCurrentRoom() == null || targetName == null) {
			return null;
		}

		Room room = caster.getCurrentRoom();

		// Parse input like "2.goblin"
		int targetIndex = 1;
		String keyword = targetName.toLowerCase();

		if (targetName.contains(".")) {
			String[] parts = targetName.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// fallback: treat whole string as keyword
				targetIndex = 1;
				keyword = targetName.toLowerCase();
			}
		}

		// Find matching mobs by keyword
		List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
		if (matchingMobs == null || matchingMobs.size() < targetIndex) {
			if (caster instanceof Player player) {
				player.sendMessage("No such target.");
			}
			return null;
		}

		Mob target = matchingMobs.get(targetIndex - 1);
		if (target == caster) {
			if (caster instanceof Player player) {
				player.sendMessage("You cannot target yourself.");
				//   return "You cannot target yourself.";
			}
			return null;
		}

		caster.setTarget(target);
		if (caster instanceof Player player) {
			player.sendMessage("You target " + target.getMobName() + ".");
		}
		return null;
	} // end handTarget
	
	
	public static String handleSpell(Player player) {
		StringBuilder sb = new StringBuilder();

		Profession prof = player.getProfession();
		if (prof == null) {
			return "You have no profession and therefore no spells.";
		}

		// Fetch all spells associated with this profession
		Collection<Spell> all =
				SpellRegister.getInstance().getSpellsForProfession(prof);

		if (all == null || all.isEmpty()) {
			return "You have no spells or abilities for your profession.";
		}

		List<Spell> abilities = new ArrayList<>();
		List<Spell> spellList = new ArrayList<>();

		for (Spell sp : all) {
			if (sp.isAbility()) {
				abilities.add(sp);
			} else {
				spellList.add(sp);
			}
		}

		// Alphabetical sorting
		abilities.sort(Comparator.comparing(Spell::getName));
		spellList.sort(Comparator.comparing(Spell::getName));

		sb.append("Abilities:\n");
		if (abilities.isEmpty()) {
			sb.append(" (none)\n");
		} else {
			for (Spell ab : abilities) {
				sb.append(" ")
				.append(ab.getName())
				.append(" - ")
				.append(ab.getDescription())
				.append("\n");
			}
		}

		sb.append("\nSpells:\n");
		if (spellList.isEmpty()) {
			sb.append(" (none)\n");
		} else {
			for (Spell sp : spellList) {
				sb.append(" ")
				.append(sp.getName())
				.append(" - ")
				.append(sp.getDescription())
				.append("\n");
			}
		}

		return sb.toString();
	} // end
	

	public static void handleEnter(Player player, String args) {
		Room room = player.getCurrentRoom();
		if (room == null) return;

		List<Effect> effects = room.getEffects();
		if (effects == null || effects.isEmpty()) {
			player.sendMessage("There is no portal or wormhole here.");
			return;
		}

		PortalEffect portal = null;
		WormholeEffect wormhole = null;

		for (Effect e : effects) {
			if (e instanceof WormholeEffect w) {
				wormhole = w;
				break;
			}
			if (e instanceof PortalEffect p) {
				portal = p;
				break;
			}
		}

		if (portal == null && wormhole == null) {
			player.sendMessage("There is no portal or wormhole here to enter.");
			return;
		}

		Room destination = null;

		if (wormhole != null) {
			destination = wormhole.getDestinationRoom();
		} else if (portal != null) {
			destination = portal.getDestinationRoom();
		}

		if (destination == null) {
			player.sendMessage("The rift flickers and leads nowhere.");
			return;
		}

		// Themed messages
		if (wormhole != null) {
			player.sendMessage("You step into the crackling mechanical wormhole...");
			room.broadcast(player.getName() + " is swallowed by a vortex of gears and lightning!", player);
		} else {
			player.sendMessage("You step into the shimmering portal...");
			room.broadcast(player.getName() + " steps into the shimmering portal and vanishes.", player);
		}

		destination.addMob(player);
		room.removeMob(player);
		player.setRoom(destination);
		player.setCurrentRoom(destination);

		if (wormhole != null) {
			destination.broadcast(player.getName() + " erupts from a twisting wormhole of metal and crackling energy!", player);
			player.sendMessage("You emerge from a vortex of gears and electric arcs.");
		} else {
			destination.broadcast(player.getName() + " materializes from a glowing portal.", player);
			player.sendMessage("You emerge from a glowing portal.");
		}
	}


	public static void handleSeal(Player player, String args) {

		Room room = player.getCurrentRoom();
		if (room == null) return;

		List<Effect> effects = room.getEffects();
		if (effects == null || effects.isEmpty()) {
			player.sendMessage("There is no portal or wormhole here to seal.");
			return;
		}

		PortalEffect portal = null;
		WormholeEffect wormhole = null;

		for (Effect e : effects) {
			if (e instanceof WormholeEffect w) {
				wormhole = w;
				break;
			}
			if (e instanceof PortalEffect p) {
				portal = p;
				break;
			}
		}

		if (portal == null && wormhole == null) {
			player.sendMessage("There is no portal or wormhole here to seal.");
			return;
		}

		// ----- WORMHOLE -----
		if (wormhole != null) {

			String id = wormhole.getWormholeId();
			Room otherRoom = wormhole.getToRoom();

			// Find matching wormhole in the destination room
			WormholeEffect counterpart = null;
			for (Effect e : otherRoom.getEffects()) {
				if (e instanceof WormholeEffect w && w.getWormholeId().equals(id)) {
					counterpart = w;
					break;
				}
			}

			// Remove both copies properly
			room.removeRoomEffect(wormhole);
			wormhole.expire(room);

			if (counterpart != null) {
				otherRoom.removeRoomEffect(counterpart);
				counterpart.expire(otherRoom);
			}

			room.broadcastToRoom("The mechanical wormhole screeches, sparks violently, and implodes!");
			otherRoom.broadcastToRoom("The mechanical wormhole screeches, sparks violently, and implodes!");

			player.sendMessage("You force the wormhole to collapse.");
			return;
		}

		// ----- PORTAL -----
		if (portal != null) {

			Room otherRoom = portal.getDestinationRoom();
			PortalEffect counterpart = null;

			// Find the matching portal on the other side
			for (Effect e : otherRoom.getEffects()) {
				if (e instanceof PortalEffect p2 && p2.getDestinationRoom() == room) {
					counterpart = p2;
					break;
				}
			}

			room.removeRoomEffect(portal);
			portal.expire(room);

			if (counterpart != null) {
				otherRoom.removeRoomEffect(counterpart);
				counterpart.expire(otherRoom);
			}

			room.broadcastToRoom("The shimmering portal collapses in on itself!");
			otherRoom.broadcastToRoom("The shimmering portal collapses in on itself!");

			player.sendMessage("You seal the portal.");
		}
	}
	
} // end
