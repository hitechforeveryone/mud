package mud.commands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import mud.core.Direction;
import mud.core.Door;
import mud.core.EquipSlot;
import mud.core.ItemEffect;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Room;

public class InteractionHandler {

	public static void handleClose(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Close what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Close what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try door first
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (door.isClosed()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already closed.");
					return;
				}

				// Close this side
				door.setClosed(true);

				// Close the corresponding door in the destination room
				Room dest = currentRoom.getExit(dir);
				if (dest != null) {
					Direction reverseDir = dir.getOpposite();
					Door destDoor = dest.getDoor(reverseDir);
					if (destDoor != null) {
						destDoor.setClosed(true);
					}
				}

				player.sendMessage("You close the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " closes the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}


		// Search container in room or inventory
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to close.");
			return;
		}
		if (container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already closed.");
			return;
		}

		container.setClosed(true);
		player.sendMessage("You close the " + container.getName() + ".");
	}

	public static void handleUnlock(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Unlock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Unlock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// -------------------
		// Handle doors first
		// -------------------
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}

				if (!door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is not locked.");
					return;
				}

				// --- Key check ---
				int keyId = door.getDoorKeyId();
				if (keyId != -1) {
					boolean hasKey = false;
					for (ObjectItem item : player.getInventory()) {
						if (item.getObjID() == keyId) {
							hasKey = true;
							break;
						}
					}

					if (!hasKey) {
						player.sendMessage("You don't have the key to unlock the " +
								dir.name().toLowerCase() + " door.");
						return;
					}
				}

				// Unlock this door
				door.setLocked(false);

				// Unlock matching door in destination room
				Room dest = currentRoom.getExit(dir);
				if (dest != null) {
					Direction reverse = dir.getOpposite();
					Door destDoor = dest.getDoor(reverse);
					if (destDoor != null) {
						destDoor.setLocked(false);
					}
				}

				player.sendMessage("You unlock the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(
						player.getName() + " unlocks the " + dir.name().toLowerCase() + " door.",
						player
						);
				return;
			}
		}

		// -----------------------
		// Handle containers next
		// -----------------------
		ObjectItem container = null;

		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to unlock.");
			return;
		}

		if (!container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is not locked.");
			return;
		}

		// --- Key check (same as doors) ---
		int keyId = container.getKeyNum(); // assumed existing
		if (keyId != -1) {
			boolean hasKey = false;
			for (ObjectItem item : player.getInventory()) {
				if (item.getObjID() == keyId) {
					hasKey = true;
					break;
				}
			}

			if (!hasKey) {
				player.sendMessage("You don't have the key to unlock the " + container.getName() + ".");
				return;
			}
		}

		container.setLocked(false);
		player.sendMessage("You unlock the " + container.getName() + ".");
	} 
	// end handleUnlock



	public static void handleLock(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Lock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Lock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// -------------------
		// Handle doors first
		// -------------------
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}

				if (door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already locked.");
					return;
				}

				// --- Key check ---
				int keyId = door.getDoorKeyId();
				if (keyId != -1) {
					boolean hasKey = false;
					for (ObjectItem item : player.getInventory()) {
						if (item.getObjID() == keyId) {
							hasKey = true;
							break;
						}
					}

					if (!hasKey) {
						player.sendMessage("You don't have the key to lock the " +
								dir.name().toLowerCase() + " door.");
						return;
					}
				}

				// Lock this door
				door.setLocked(true);

				// Lock the matching door in the destination room
				Room dest = currentRoom.getExit(dir);
				if (dest != null) {
					Direction reverse = dir.getOpposite();
					Door destDoor = dest.getDoor(reverse);
					if (destDoor != null) {
						destDoor.setLocked(true);
					}
				}

				player.sendMessage("You lock the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(
						player.getName() + " locks the " + dir.name().toLowerCase() + " door.",
						player
						);
				return;
			}
		}

		// -----------------------
		// Handle containers next
		// -----------------------
		ObjectItem container = null;

		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to lock.");
			return;
		}

		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is already locked.");
			return;
		}

		// --- Must be closed first (same as doors) ---
		if (!container.isClosed()) {
			player.sendMessage("You must close the " + container.getName() + " before locking it.");
			return;
		}

		// --- Key check (same behavior as doors) ---
		int keyId = container.getKeyNum(); // assumed existing
		if (keyId != -1) {
			boolean hasKey = false;
			for (ObjectItem item : player.getInventory()) {
				if (item.getObjID() == keyId) {
					hasKey = true;
					break;
				}
			}

			if (!hasKey) {
				player.sendMessage("You don't have the key to lock the " + container.getName() + ".");
				return;
			}
		}

		// Lock container
		container.setLocked(true);
		player.sendMessage("You lock the " + container.getName() + ".");

	} // end handleLock

	static String handleDrop(Player player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have anything.";

		ObjectItem toDrop = null;
		String lowerItemName = itemName.toLowerCase();

		for (ObjectItem item : inventory) {
			if (item != null && item.getName() != null &&
					item.getName().toLowerCase().contains(lowerItemName)) {
				toDrop = item;
				break;
			}
		}

		if (toDrop == null) return "You don't have that.";

		inventory.remove(toDrop);
		player.getCurrentRoom().addObject(toDrop);
		return "You drop: " + toDrop.getName();
	}


	static void handleEquipment(Player player) {
		Map<EquipSlot, ObjectItem> eq = player.getEquipment();

		player.sendMessage("📦 Currently Equipped:");

		for (Map.Entry<EquipSlot, ObjectItem> entry : eq.entrySet()) {
			EquipSlot slot = entry.getKey();
			ObjectItem item = entry.getValue();


			String itemName = (item != null) ? item.getName() : "Empty";
			player.sendMessage(slot.name() + ": " + itemName);
		}
	} // end



	static String handleEquip(Player player, String[] args) {
		if (args.length == 0) return "Equip what?";

		// --- STEP 1: Determine if last token is an EquipSlot ---
		EquipSlot chosenSlot = null;
		String itemName;

		if (args.length > 1) {
			try {
				chosenSlot = EquipSlot.valueOf(args[args.length - 1].toUpperCase());
				itemName = String.join(" ", Arrays.copyOfRange(args, 0, args.length - 1));
			} catch (IllegalArgumentException e) {
				chosenSlot = null;
				itemName = String.join(" ", args);
			}
		} else {
			itemName = args[0];
		}

		String lowerItemName = itemName.substring(6).toLowerCase().replaceAll("[^a-z0-9]", "");

		// --- STEP 2: Find the item in inventory ---
		ObjectItem target = null;
		for (ObjectItem item : player.getInventory()) {
			if (item == null || item.getName() == null) continue;

			// check cleaned name and keywords
			String cleanedItemName = item.getName().toLowerCase().replaceAll("[^a-z0-9]", "");

			boolean match = cleanedItemName.contains(lowerItemName) ||
					item.getKeywordSummary().contains(lowerItemName) ||
					(item.getKeywords() != null && item.matchesKeyword(itemName)) ||
					(item.getKeywords() != null && item.hasKeyword(itemName));

			if (match) {
				target = item;
				//		player.sendMessage("[Debug] Found item in inventory: " + target.getName());
				break;
			}
		}

		if (target == null) return "You don't have that item.";

		// --- STEP 3: Determine allowed slots ---
		List<EquipSlot> allowedSlots = new ArrayList<>(target.getEquipSlot());
		allowedSlots.removeIf(s -> s == EquipSlot.NONE);
		if (allowedSlots.isEmpty()) return "This item cannot be equipped anywhere.";

		// --- STEP 4: Determine final slot ---
		EquipSlot finalSlot;
		if (chosenSlot != null) {
			if (!allowedSlots.contains(chosenSlot)) return "Item cannot be equipped to that slot.";
			finalSlot = chosenSlot;
		} else {
			finalSlot = allowedSlots.get(0);
		}

		// --- STEP 5: Equip ---
		ObjectItem removed = player.unequip(finalSlot);
		if (removed != null) player.getInventory().add(removed);
		//	    player.getRoom().broadcastExcept(player.getName() + " unequip's their " + removed.getName() + "." , player);

		player.equip(finalSlot, target);
		player.getInventory().remove(target);

		return "You equip the " + target.getName() + " in your " + finalSlot.toString().toLowerCase() + ".";
	} // end




	public static String handleUseItem(Player player, String itemName) {

		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null) return "You don't have any items.";

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName)) {
				item = i;
				break;
			}
			if (i.matchesKeyword(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) return "You don't have that item.";

		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			String msg = "You use one " + item.getName() + ".";
			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg += " You have used the last one.";
			}
			// TODO: Apply item effects here
			return msg;
		} else {
			inventory.remove(item); // or keep if reusable
			// TODO: Apply item effects here
			return "You use " + item.getName() + ".";
		}
	} // end handleUseItem



/*
	private static ObjectItem findContainerInRoomOrInventory(Room room, List<ObjectItem> inventory, String keyword) {
		for (ObjectItem obj : room.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		for (ObjectItem obj : inventory) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		return null;
	}
*/
	
	public static void handleGet(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are nowhere.");
			return;
		}
		Room room = player.getCurrentRoom();

		if (args.length < 2) {
			player.sendMessage("Usage: get <item|all> [from <container>]");
			return;
		}

		// Detect if command contains "from"
		int fromIndex = -1;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("from")) {
				fromIndex = i;
				break;
			}
		}

		String itemName;
		String containerName = null;

		if (fromIndex == -1) {
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		} else {
			if (fromIndex == 1 || fromIndex == args.length - 1) {
				player.sendMessage("Usage: get <item|all> [from <container>]");
				return;
			}
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, fromIndex)).toLowerCase();
			containerName = String.join(" ", Arrays.copyOfRange(args, fromIndex + 1, args.length)).toLowerCase();
		}

		List<ObjectItem> sourceItems;

		if (containerName == null) {
			sourceItems = filterGettable(player, room.getObjects());
		} else {
			// Find container in room
			int containerIndex = 1;
			String containerKeyword = containerName;
			if (containerName.contains(".")) {
				String[] parts = containerName.split("\\.", 2);
				try {
					containerIndex = Integer.parseInt(parts[0]);
					containerKeyword = parts[1];
				} catch (NumberFormatException e) {
					containerIndex = 1;
				}
			}

			List<ObjectItem> containers = room.findObjectsByKeyword(containerKeyword);
			if (containers.isEmpty() || containers.size() < containerIndex) {
				player.sendMessage("There is no " + containerKeyword + " here.");
				return;
			}

			ObjectItem container = containers.get(containerIndex - 1);
			if (container.getContents() == null) {
				player.sendMessage("The " + containerKeyword + " is empty.");
				return;
			}

			sourceItems = filterGettable(player, container.getContents());
		}

		if (itemName.equals("all")) {
			if (sourceItems.isEmpty()) {
				player.sendMessage("There is nothing to get.");
				return;
			}
			List<ObjectItem> toRemove = new ArrayList<>();
			for (ObjectItem item : sourceItems) {
				player.addItem(item);
				toRemove.add(item);
				player.sendMessage("You take " + item.getShortDescription() + ".");
			}
			sourceItems.removeAll(toRemove);
		} else {
			List<ObjectItem> matchingItems = sourceItems.stream()
					.filter(i -> i.getName().toLowerCase().contains(itemName))
					.collect(Collectors.toList());

			if (matchingItems.isEmpty()) {
				player.sendMessage("You don't see that here.");
				return;
			}

			ObjectItem itemToGet = matchingItems.get(0);
			sourceItems.remove(itemToGet);
			player.addItem(itemToGet);
			player.sendMessage("You take " + itemToGet.getShortDescription() + ".");
		}
	}

	// ---------------------
	// Filter items that are gettable
	private static List<ObjectItem> filterGettable(Player player, List<ObjectItem> items) {
		List<ObjectItem> gettable = new ArrayList<>();
		for (ObjectItem item : items) {
			if (item.hasEffect(ItemEffect.NOTAKE)) {
				player.sendMessage("You cannot take " + item.getShortDescription() + ".");
			} else {
				gettable.add(item);
			}
		}
		return gettable;
	}

	public static void handleOpen(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Open what?");
			return;
		}

		// Parse direction or target from args, supporting inputs like:
		// "open east", "open door east", "open the east door"
		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Open what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try to interpret target as a direction for door
		// Try to interpret target as a direction for door
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is locked.");
					return;
				}
				if (!door.isClosed()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already open.");
					return;
				}

				// Open this side
				door.setClosed(false);

				// Open the corresponding door in the destination room
				Room dest = currentRoom.getExit(dir);
				if (dest != null) {
					Direction reverseDir = dir.getOpposite();
					Door destDoor = dest.getDoor(reverseDir);
					if (destDoor != null) {
						destDoor.setClosed(false);
					}
				}

				player.sendMessage("You open the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " opens the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}


		// Search for container in room or inventory by keywords
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to open.");
			return;
		}
		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is locked.");
			return;
		}
		if (!container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already open.");
			return;
		}

		container.setClosed(false);
		player.sendMessage("You open the " + container.getName() + ".");
	}

	public static String handleUnequip(Player player, String itemNameOrSlot) {
		if (itemNameOrSlot == null || itemNameOrSlot.trim().isEmpty()) {
			return "Unequip what?";
		}

		String input = itemNameOrSlot.trim().toLowerCase();

		// --- Special case: unequip all ---
		if (input.equals("all")) {
			StringBuilder sb = new StringBuilder();
			boolean any = false;

			for (Map.Entry<EquipSlot, ObjectItem> entry : player.getEquipment().entrySet()) {
				ObjectItem item = entry.getValue();
				if (item != null) {
					player.getInventory().add(item);
					entry.setValue(null);
					sb.append("You unequip the ").append(item.getName())
					.append(" from your ").append(entry.getKey().name().toLowerCase()).append(".\n");
					any = true;
				}
			}

			if (!any) return "You are not wearing or wielding anything.";
			return sb.toString().trim();
		}

		// --- Normal case: try parsing as slot ---
		EquipSlot slot = EquipSlot.fromString(input);
		ObjectItem unequipped = null;

		if (slot != null) {
			unequipped = player.getEquipment().get(slot);
		} else {
			// Try matching by item name if no valid slot
			for (Map.Entry<EquipSlot, ObjectItem> entry : player.getEquipment().entrySet()) {
				ObjectItem item = entry.getValue();
				if (item != null && item.getName().equalsIgnoreCase(input)) {
					slot = entry.getKey();
					unequipped = item;
					break;
				}
			}
		}

		if (unequipped == null || slot == null) {
			return "You are not wearing or wielding that.";
		}

		// Remove from equipped slot
		player.getEquipment().put(slot, null);

		// Add to inventory
		player.getInventory().add(unequipped);

		player.sendMessage("You unequip the " + unequipped.getName() + " from your " + slot.name().toLowerCase() + ".");
		player.getRoom().broadcastExcept(player.getName() + " unequipped " + unequipped.getName() + ".", player);

		return null;
	} // end handleUnequip


	
	// Include this helper method as before
	private static String parseDirectionOrTarget(String[] args) {
		String joined = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		joined = joined.replaceAll("\\bdoor\\b", "")
				.replaceAll("\\bthe\\b", "")
				.trim();
		if (joined.isEmpty()) return null;
		String[] parts = joined.split("\\s+");
		return parts[0];
	}



} // end InteractionHandler
