package mud.commands;

import java.util.*;

import mud.core.*;
import mud.Shop.*;
import mud.editor.*;

public class CommandProcessor {

	static WorldManager worldManager;

	@SuppressWarnings("static-access")
	public CommandProcessor(WorldManager worldManager) {
		this.worldManager = worldManager;
	}

	public static String processCommand(String input, Player player) throws Exception {
		// Quick check for common shorthand commands before tokenization
		if (input.startsWith("'")) { // ' = say
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Say what?";
			return CommunicationHandler.handleSay(player, message);
		}
		if (input.startsWith("\"")) { // " = shout or yell
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Shout what?";
			CommunicationHandler.handleShout(player, message);
			return null;
		}
		if (input.startsWith("%") || input.startsWith("%%")) { // % or %% = grape
			String message = input.replaceFirst("^%+", "").trim();
			if (message.isEmpty()) return "Usage: grapevine <message>";
			CommunicationHandler.handleGrapevine(player, message);
			return null;
		}
		if (input.startsWith(":")) { // : = emote
			String message = input.substring(1).trim();
			if (message.isEmpty()) return "Emote what?";
			CommunicationHandler.handleEmote(player, message);
			return null;
		}

		// if player is in multiline editor
		if (player.isAwaitingMultiline()) {
			if (input.trim().equalsIgnoreCase("END")) {
				player.setAwaitingMultiline(false);

				if (player.getMultilineEditor() instanceof HelpEditorFieldEditor subEditor) {
					subEditor.applyMultilineInput(player, player.getMultilineBuffer().toString().trim());
				}
				player.cancelMultilineInput();
			} else {
				player.appendMultilineInput(input);
			}
			return null; // important: do not process normal commands while in multiline
		}

		if (input == null || input.trim().isEmpty()) {
			return "You must enter a command.";
		}

		String[] tokens = input.trim().split("\\s+");
		String cmd = tokens[0].toLowerCase();

		// implicit list of admin commands for admin players
		Set<String> adminCommands = Set.of("pkick", "psummon", "goto", "setlevel");

		if (adminCommands.contains(cmd) && !player.isAdmin()) {
			return "You do not have permission to use that command.";
		}

		// Directional movement shortcut
		if (MovementHandler.isDirection(cmd)) {
			return MovementHandler.handleMovement(player, cmd);
		}

		switch (cmd) {
		// Admin Commands // TODO
		case "/restartgame": return null; // Reserved for future restart command
		case "/shutdown": return null; // reserved for server shutdown
		case "pkick":    return AdminCommandHandler.handleKick(player, tokens); // kick player from server
		case "psummon":  return AdminCommandHandler.handleSummon(player, tokens); // global summons of player
		case "goto":     return AdminCommandHandler.handleGoto(player, tokens); // goto player room from coords wId zId rId
		case "setlevel": return AdminCommandHandler.handleSetLevel(player, tokens); // set a player lvl
		case "stat": StatCommandHandler.handleStat(player,tokens); return null; // currently open to all
		case "load": return AdminCommandHandler.handleLoad(player,Arrays.copyOfRange(tokens, 1, tokens.length));
		case "unload":{	return AdminCommandHandler.handleUnload(player,tokens); // unload zone 
			}
		case "purge": return AdminCommandHandler.handlePurge(player, tokens); // remove/purge mob/mobs from room
		case "list": {
			AdminCommandHandler.handleList(player, tokens); return null;
			}
		case "create": {
			String result = AdminCommandHandler.handleCreate(player, tokens);
			return (result == null) ? "Failed to create object. Check your input." : result;
			}
		case "csave": {
			return AdminCommandHandler.handleCSave(player, tokens);		}
		case "edit": {
			if (player.getEditor() != null) {
				System.out.println("[DEBUG] Passing input to editor: " + player.getEditor().getEditorName());
				player.getEditor().handleInput(input);	return null;
			}
			AdminCommandHandler.handleEdit(player, tokens);	return null;
		}


		case "title": {
			if (tokens.length < 2) return "Set your title to what?";  // set player's title
			return AdminCommandHandler.handleTitle(player, tokens[1].trim());
			}

		// TESTING  SECTION //



		// END TESTING SECTION //


		// game exits	
		case "quit": { GameExitHandler.handleQuit(player); return null;
			} // signal to ClientHandler
		case "rent": { GameExitHandler.handleRent(player);	return null;
		}
		case "camp": { GameExitHandler.handleCamp(player);	return null;
		}

		

		// world info
		case "time": { WorldInfoHandler.handleTime(player);	return null;
		}
		case "date": { WorldInfoHandler.handleDate(player);	return null;
		}
		case "weather": { WorldInfoHandler.handleWeather(player); return null;
		}
		case "calendar": { WorldInfoHandler.handleCalendar(player);	return null;
		}


		
		// Movement
		case "go": {
			if (tokens.length < 2) return "Move where?";
			return MovementHandler.handleMovement(player, tokens[1].toLowerCase());
		}

		
		
		// communication
		case "emote": {
			if (tokens.length < 2) return "Emote what?";
			CommunicationHandler.handleEmote(player, input.substring(input.indexOf(' ') + 1));
			return null;}

		case "frown": { CommunicationHandler.handleEmote(player, "frowns intently."); return null;
		} 
		case "grin": { CommunicationHandler.handleEmote(player, "grins evily."); return null;
		} 
		case "sigh": { CommunicationHandler.handleEmote(player, "sighs gently."); return null;
		} 
		case "dance": { CommunicationHandler.handleEmote(player, "dances wildly about the room."); return null;
		} 

		case "grape":
		case "grapevine": {
			if (tokens.length < 2) {
				return "Usage: grapevine <message>";
				}
			CommunicationHandler.handleGrapevine(player, input.substring(input.indexOf(' '))); return null;	}
		case "say": {
			if (tokens.length < 2) return "Say what?";
			return CommunicationHandler.handleSay(player, input.substring(input.indexOf(' ')));
			}
		case "yell":
		case "shout": {
			if (tokens.length < 2) {
				return "Shout what?";
			}
			CommunicationHandler.handleShout(player, input.substring(input.indexOf(' ')));
			return null;
			}
		case "tell": {
			CommunicationHandler.handleTell(player, tokens);
			return null;
			}
		case "reply": {
			CommunicationHandler.handleReply(player, tokens);
			return null;
			}
		case "whisper": {
			CommunicationHandler.handleWhisper(player, tokens);
			return null;
			}

		
		
		// Help
		case "help":
			return HelpHandler.handleHelp(player,tokens); // TODO: help system, add more helps
		case "hedit":
			if (tokens.length < 2) {
				player.sendMessage("Usage: hedit <keyword>");
				return null;
			}
			String keyword = tokens[1].toLowerCase();
			HelpEntry existing = HelpManager.getHelpEntry(keyword);
			if (existing != null) {
				player.setEditor(new HelpEditor(existing,player));
			} else {
				player.setEditor(new HelpEditor(keyword,player));
				player.sendMessage("Creating new help entry for: " + keyword);
			}
			return null;
		case "hindex":
			return HelpHandler.handleHindex(player,tokens); 


		case "party": {
			return PartyHandler.handleParty(player, tokens);
		}

		
		
		// --- combat stuff ---
		case "consider": {
			Mob target = player.getCurrentRoom().findMobByName(tokens[1]);
			if (target == null) return "There is no such creature here.";
			return CombatSpellHandler.handleConsider(player, target);
		}
		case "target": { 
			if (tokens.length < 2) return "target whom?";
			return CombatSpellHandler.handleTarget(player, tokens[1].toLowerCase());
		}
		case "kill":
		case "attack": {
			if (tokens.length < 2) return "Attack whom?";
			return CombatSpellHandler.handleAttack(player, tokens[1].toLowerCase());
		}

		//spells 
		case "cast": { 
			if (tokens.length < 3) return "Cast what on whom?";
			return CombatSpellHandler.handleCast(player, tokens[1], tokens[2].toLowerCase());
		}
		case "spell":
		case "spells": {
			return CombatSpellHandler.handleSpell(player);
		}
		case "enter":
			CombatSpellHandler.handleEnter(player,tokens.toString());
			return null;
		case "seal":
			CombatSpellHandler.handleSeal(player,tokens.toString());
			return null;


			//abilities
		case "backstab": {
			// TODO
			return null;
		}
		case "detect.trap": {
			// TODO
			return null;
		}
		case "disable.trap": {
			// TODO
			return null;
		}
		case "disabling.blow": {
			// TODO
			return null;
		}
		case "disarm": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "double.attack": {
			// passive
			return null;
		}
		case "dual.wield": {
			// passive
			return null;
		}
		case "evicerate": {
			// TODO
			return null;
		}
		case "flee": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null; 	
		}
		case "gouge": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "headbutt": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "kick": {
			if (tokens.length < 2) return "Kick who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "pick.lock": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "pickpocket": {
			// TODO
			return null;
		}
		case "punch": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "rend": {
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "rescue": {
			if (tokens.length < 2) return "Rescue who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}
		case "retreat": {
			// TODO
			return null;
		}
		case "second.hit": {
			// passive
			return null;
		}
		case "track": {
			if (tokens.length < 2) return "Track who?";
			CombatSpellHandler.handleShortCast(player, tokens);
			return null;
		}



		// Info
		case "look": { LookHandler.handleLook(player, tokens); return null;
		}
		case "who": { LookHandler.handleWho(player); return null;
		}
		case "score" : return LookHandler.handleScore(player);
		case "inventory":
		case "inv": return LookHandler.handleInventory(player);
		case "examine":	return LookHandler.handleExamine(player,tokens); // TODO: update show extended object/mob info

		

		// obj management
		case "take":
		case "get": {
			if (tokens.length < 2) return "Get what?";
			InteractionHandler.handleGet(player, tokens);
			return null;
		}
		case "drop": {
			if (tokens.length < 2) return "Drop what?";
			return InteractionHandler.handleDrop(player, tokens[1].toLowerCase());
		}
		case "equip": {
			if (tokens.length < 2) return "Equip what?";
			return InteractionHandler.handleEquip(player, tokens);
		}
		case "grab": {
			// TODO // if tokens[1] has offhand for an equipslot, equip to offhand slot // for use with wands? shields? offhand weapons?
			return null;
		}
		case "light": {
			// TODO  // if tokens[1] is lightsource, equip to lightsource slot
		}
		case "unequip": {
			if (tokens.length < 2) return "Unequip what?";
			return InteractionHandler.handleUnequip(player, tokens[1].toLowerCase());
		}
		case "use": {
			if (tokens.length < 2) return "Use what?";
			return InteractionHandler.handleUseItem(player, tokens[1].toLowerCase());
		}
		case "eat": {
			// TODO // if tokens[1] is food, increase player hp by ....
		}
		case "drink":{
			// TODO 
		}
		case "open": {
			InteractionHandler.handleOpen(player, tokens);
			return null;
		}
		case "close": {
			InteractionHandler.handleClose(player, tokens);
			return null;
		}
		case "lock": {
			InteractionHandler.handleLock(player, tokens);
			return null;
		}
		case "unlock": {
			InteractionHandler.handleUnlock(player, tokens);
			return null;
		}
		case "equipment": {
			InteractionHandler.handleEquipment(player);
			return null;
		}

		

		// --- Bank & Shop stuff ---
		case "coins": return  player.getMoneyString();
		case "exchange":  { 
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			BankShopHandler.handleExchange(player);
			return null;
		}
		case "deposit": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Deposit what amount?";
			return BankShopHandler.handleDepositCoins(player, tokens[1]);
		}
		case "withdraw": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Withdraw what amount?";
			return BankShopHandler.handleWithdrawCoins(player, tokens[1]);
		}
		case "vaultdeposit": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Deposit which item?";
			return BankShopHandler.handleDepositItem(player, tokens[1]);
		}
		case "vaultwithdraw": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			if (tokens.length < 2) return "Withdraw which item?";
			return BankShopHandler.handleWithdrawItem(player, tokens[1]);
		}
		case "vaultlist": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			return BankShopHandler.handleListVault(player);
		}
		case "vaultbuy": {
			Mob banker = player.getCurrentRoom().getBanker();
			if (banker == null) return "There is no banker here.";

			return BankShopHandler.handlePurchaseVault(player);
		}
		// shop stuff // seems to work
		case "shoplist": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return ShopManager.listShop(player, shopkeeper);
		}
		case "buy": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return BankShopHandler.handleBuy(player,tokens);
		}
		case "sell": {
			Mob shopkeeper = player.getCurrentRoom().getShopkeeper();
			if (shopkeeper == null) return "There is no shopkeeper here.";

			return BankShopHandler.handleSell(player,tokens);
		}



		// --- End of Commands ---

		default:
			return "Unknown command: " + cmd;
		}
	} // end processCommand



		
		
	

	// match keyword across mob/player/obj
	static boolean matchesKeyword(HasKeywords entity, String keyword) {
		if (keyword == null) return false;
		for (String key : entity.getKeywords()) {
			if (key != null && key.equalsIgnoreCase(keyword)) {
				return true;
			}
		}
		return false;
	}



} // end CommandProcessor
