package mud.spell;

import mud.core.*;
import mud.spell.effects.*;


import java.util.Random;
import java.util.Set;

public class StunningBlowSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    private static final Random random = new Random();
  

    @Override
    public String getName() {
        return "stunning.blow"; // might rename to smash
    }

    @Override
    public String getDescription() {
        return "Strike your foe with a blow that may stun them, preventing action for a short time.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || target == null) {
            return false;
        }

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        // Chance to stun: based on caster's Strength vs target's Stamina
        int chance = 50 + (caster.getStrength() - target.getStamina()) * 5;
        int roll = random.nextInt(100) + 1;

        int stunTime = random.nextInt(3)+1;
    	StunEffect STUN = new StunEffect(target, stunTime);
        if (roll <= chance) {
            target.addEffect(STUN); // stunned for 2–3 ticks
           // target.addEffect(EffectType.STUN); // this is actually set by the StunEffect
            if (caster instanceof Player player) {
                player.sendMessage("You smash " + target.getMobName() + " with a "+ getName() + icon + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You are smashed by a "+ getName() + icon + " from " + caster.getMobName() + "!");
            }
            
            if (!caster.getInCombat()) {
            	caster.setTarget(target);
            	caster.setInCombat(true);
            }
        	if (!target.getInCombat()) {
        		target.setTarget(caster);
        		target.setInCombat(true);
        	}
            
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your "+ getName() + icon + " fails to connect properly.");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to smash you with a "+ getName() + icon + " but failed.");
            }
            return false;
        }
    }


    @Override
    public int getLevelRequired() {
        return 3;
    }

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public Set<Profession> getProfessions() {
      //  return Set.of(Profession.MAGE, Profession.CLERIC); // multiple
    	return Set.of(Profession.MONK);
    }

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
