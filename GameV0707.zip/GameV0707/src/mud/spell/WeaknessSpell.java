package mud.spell;

import mud.core.*;
import mud.spell.effects.WeaknessEffect;

import java.util.Set;

public class WeaknessSpell implements Spell {
    public static final MagicDamageType damageType = MagicDamageType.BLEED;
    public static final String icon = damageType.getIcon();
    public static final String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "weakness";
    }

    @Override
    public String getDescription() {
        return "Temporarily reduces the target's Strength by 2 + 10% of your Intellect.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to weaken.");
            return false;
        }

        int penalty = 2 + (int)(caster.getIntellect() * 0.10);
        int durationTicks = 20; // adjust as needed

        WeaknessEffect effect = new WeaknessEffect(target, penalty, durationTicks);
        target.addEffect(effect);

        caster.sendMessage("You cast " + getName() + " on " + target.getMobName() + ", reducing their Strength " + icon + "!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " casts " + getName() + " on you, weakening your Strength!");
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        return false; // Not applicable
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false; // Not directional
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.BARD, Profession.WARLOCK, Profession.MAGE); // example
    }

    @Override public int getLevelRequired() { return 1; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return true; }
    @Override public int getManaCost() { return 5; } // example
}
