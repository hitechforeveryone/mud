package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.MirrorImageEffect;

public class MirrorImageSpell implements Spell {
	
    private final MagicDamageType damageType = MagicDamageType.ARCANE;
    private final String icon = damageType.getIcon();
    @Override
    public String getName() {
        return "mirror.image";
    }

    @Override
    public String getDescription() {
        return "Creates several illusory duplicates that may absorb incoming attacks.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Self-target only
        if (caster == null) return false;

        int min = 4;
        int max = 6;

        int count = min + (int)(Math.random() * ((max - min) + 1));

        MirrorImageEffect existing = caster.getEffect(MirrorImageEffect.class);
        if (existing != null) {
            caster.sendMessage("Your mirror images swirl and reform around you." + icon);
 
            existing.addImages(count);
        } else {
            caster.addEffect(new MirrorImageEffect(caster, count, 30)); // 30 ticks
            caster.addEffect(EffectType.MIRROR_IMAGE);
        }
        
        target.addEffect(EffectType.MIRROR_IMAGE);
        
        caster.sendMessage("✨ Multiple shimmering images of yourself split away and surround you!" + icon);
        caster.getRoom().broadcastExcept(
            caster.getMobName() + " suddenly splits into several shimmering copies!" + icon, caster
        );

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 6;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean isAoE() { return false; }

    @Override
    public boolean cast(Mob caster, Direction dir) { return false; }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
