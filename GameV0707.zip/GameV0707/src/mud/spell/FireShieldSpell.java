package mud.spell;

import mud.spell.effects.FireShieldEffect;
import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Player;
import mud.core.Profession;

import java.util.Random;
import java.util.Set;

public class FireShieldSpell implements Spell {
    private static final Random random = new Random();
    
    private final MagicDamageType damageType = MagicDamageType.FIRE;
    private final String icon = damageType.getIcon();
    
    @Override
    public String getName() {
        return "fires.hield";
    }

    @Override
    public String getDescription() {
        return "Envelops you or your ally in a blazing fire shield, burning attackers who strike them.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null) return false;
        if (target == null) target = caster; // default to self-cast

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        // Prevent stacking the same shield
        if (target.hasEffect(EffectType.FIRE_SHIELD)) {
            if (caster instanceof Player player) {
                player.sendMessage(target.getMobName() + " is already protected by a fire shield.");
            }
            return false;
        }

        // Duration can scale with caster intellect or level
        int duration = 3 + random.nextInt(3); // 3–5 ticks
        FireShieldEffect effect = new FireShieldEffect(target, duration);
        target.addEffect(effect);
        target.addEffect(EffectType.FIRE_SHIELD);

        if (caster instanceof Player playerCaster) {
            if (caster == target) {
                playerCaster.sendMessage("You surround yourself with a blazing fire shield " + icon + "!");
            } else {
                playerCaster.sendMessage("You cast a fire shield " + icon + " around " + target.getMobName() + "!");
            }
        }

        if (target instanceof Player playerTarget && caster != target) {
            playerTarget.sendMessage(caster.getMobName() + " surrounds you with a blazing fire shield " + icon + "!");
        }

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 5;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
// end
