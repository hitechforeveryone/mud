package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.ShadowCloneEffect;

public class ShadowCloneSpell implements Spell {

    private final MagicDamageType damageType = MagicDamageType.SHADOW;
    private final String icon = damageType.getIcon();
    @Override
    public String getName() {
        return "shadow.clone";
    }

    @Override
    public String getDescription() {
        return "Creates several shadowy clones that may absorb incoming attacks.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Self-target only
        if (caster == null) return false;

        int min = 4;
        int max = 6;

        int count = min + (int)(Math.random() * ((max - min) + 1));

        ShadowCloneEffect existing = caster.getEffect(ShadowCloneEffect.class);
        if (existing != null) {
            caster.sendMessage("Your shadow images swirl and reform around you." + icon);
 
            existing.addImages(count);
        } else {
            caster.addEffect(new ShadowCloneEffect(caster, count, 30)); // 30 ticks
            caster.addEffect(EffectType.SHADOW_CLONE);
        }
        
        target.addEffect(EffectType.SHADOW_CLONE);
        
        caster.sendMessage(icon +" Multiple shadowy clones of yourself split away and surround you!" + icon);
        caster.getRoom().broadcastExcept(
            caster.getMobName() + " suddenly splits into several shadow clones!" + icon, caster
        );

        return true;
    }

    @Override
    public int getLevelRequired() {
        return 6;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean isAoE() { return false; }

    @Override
    public boolean cast(Mob caster, Direction dir) { return false; }

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.ROGUE);
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}
}
