package mud.spell;

import mud.commands.*;
import mud.core.*;

import java.util.*;;

public class GustOfWindSpell implements Spell {

	private final MagicDamageType damageType = MagicDamageType.AIR;
	private final String icon = damageType.getIcon();
	
	private static final Random random = new Random();

	@Override
	public String getName() {
		return "gust.of.wind";
	}

	@Override
	public String getDescription() {
		return "A powerful gust of wind that blows the target into a random adjacent room.";
	}

	@Override
	public boolean cast(Mob caster, Mob target) {
		if (caster == null || target == null) return false;

		Room current = caster.getCurrentRoom();
		if (current == null || target.getCurrentRoom() != current) {
			if (caster instanceof Player p) p.sendMessage("Your target is not here.");
			return false;
		}

		// Collect valid exits that aren't blocked by closed/locked doors
		Map<Direction, Room> exits = current.getExits();
		if (exits == null || exits.isEmpty()) {
			caster.sendMessage("There is nowhere for the wind to blow your target!");
			return false;
		}

		List<Direction> validDirs = new ArrayList<>();
		for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
			Door door = current.getDoor(entry.getKey());
			if (door != null && (!door.isOpen() || door.isLocked())) continue;
			validDirs.add(entry.getKey());
		}

		if (validDirs.isEmpty()) {
			caster.sendMessage("All exits are blocked; your " + getName().replace("."," ") + icon + " fails.");
			return false;
		}

		// Pick a random exit
		Direction chosenDir = validDirs.get(random.nextInt(validDirs.size()));
		Room nextRoom = exits.get(chosenDir);

		if (MovementHandler.checkMovementRestrictions(target, chosenDir) == null) {

			// Move target
			current.removeMob(target);
			nextRoom.addMob(target);
			target.setCurrentRoom(nextRoom);
			caster.setCurrentTarget(null);
			caster.setTarget(null);

			// Notify caster, target, and rooms
			caster.sendMessage("You unleash a " + getName().replace("."," ") + icon + "! " + target.getMobName() + " is blown " + chosenDir.name().toLowerCase() + "!");
			target.sendMessage("A violent " + getName().replace("."," ") + icon + " sweeps you " + chosenDir.name().toLowerCase() + "!");
			current.broadcastExcept(target.getMobName() + " is blown away by a " + getName().replace("."," ") + icon + "!", caster, target);
			nextRoom.broadcast(target.getMobName() + " is blown in by a " + getName().replace("."," ") + icon + "!", target);

			// Optional: deal light wind damage
			int damage = 5 + caster.getIntellect() / 2;
			target.takeDamage(damage, damageType);     
		}
		return true;
	}

	@Override
	public int getLevelRequired() {
		return 2;
	}

	@Override
	public boolean isInstantCast() {
		return false;
	}

	@Override
	public boolean isAoE() {
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.PRIEST, Profession.DRUID, Profession.MAGE, Profession.WARLOCK); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}
}
