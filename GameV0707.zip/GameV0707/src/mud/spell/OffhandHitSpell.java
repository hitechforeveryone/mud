
package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.*;

public class OffhandHitSpell implements Spell{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "offhand.hit";
	}

	@Override
	public String getDescription() {
        return "Grants a passive chance to attack with offhand.";
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually.
        applyPassive(caster);
        return true;
    }

    /**
     * Apply passive effect if missing.
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("offhand_hit")) {
           mob.addEffect(new OffhandHitEffect(mob));
        }
    }

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return Set.of(Profession.MONK);
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

}
