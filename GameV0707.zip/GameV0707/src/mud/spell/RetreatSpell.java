package mud.spell;

import mud.core.*;

import java.util.*;

public class RetreatSpell implements Spell {

    private final Random random = new Random();

    private static final int BASE_FAIL_CHANCE = 30;
    private static final int MIN_FAIL_CHANCE = 5;
    private static final int AGI_PER_REDUCTION = 2; // 1% per 2 Agi

    @Override
    public String getName() {
        return "retreat";
    }

    @Override
    public String getDescription() {
        return "Attempt to retreat carefully from combat. Agility improves success.";
    }

    // ------------------------------------------------------------
    // RANDOM RETREAT
    // ------------------------------------------------------------
    public boolean cast(Mob caster) {
        if (caster == null || caster.getCurrentRoom() == null) {
            caster.sendMessage("You are nowhere.");
            return false;
        }

        Room room = caster.getCurrentRoom();
        Map<Direction, Room> exits = room.getExits();

        if (exits == null || exits.isEmpty()) {
            caster.sendMessage("You have nowhere to retreat!");
            return false;
        }

        List<Direction> validDirs = new ArrayList<>();
        for (Map.Entry<Direction, Room> e : exits.entrySet()) {
            if (e.getValue() != null)
                validDirs.add(e.getKey());
        }

        if (validDirs.isEmpty()) {
            caster.sendMessage("You look for an opening, but find none!");
            return false;
        }

        Direction dir = validDirs.get(random.nextInt(validDirs.size()));
        return retreatTo(caster, dir);
    }

    // ------------------------------------------------------------
    // DIRECTIONAL RETREAT
    // ------------------------------------------------------------
    @Override
    public boolean cast(Mob caster, Direction dir) {
        if (dir == null) {
            caster.sendMessage("Retreat where?");
            return false;
        }

        return retreatTo(caster, dir);
    }

    // ------------------------------------------------------------
    // CORE MOVE LOGIC
    // ------------------------------------------------------------
    private boolean retreatTo(Mob caster, Direction dir) {
        Room current = caster.getCurrentRoom();
        Room next = current.getExit(dir);

        if (next == null) {
            caster.sendMessage("You cannot retreat that way!");
            return false;
        }

        // --------------------
        // HARD BLOCK CHECK
        // --------------------
        if (MobAI.isMovementBlocked(caster, current, dir)) {
            caster.sendMessage("Your escape route is blocked!");
            current.broadcast(caster.getMobName() + " tries to retreat, but is blocked!", caster);
            return false;
        }

        // --------------------
        // AGILITY-SCALED FAIL
        // --------------------
        int agility = Math.max(0, caster.getAgility());
        int reduction = agility / AGI_PER_REDUCTION;

        int failChance = Math.max(
                MIN_FAIL_CHANCE,
                BASE_FAIL_CHANCE - reduction
        );

        if (random.nextInt(100) < failChance) {
            caster.sendMessage("You attempt to retreat, but lose your footing!");
            current.broadcast(caster.getMobName() + " tries to retreat, but falters!", caster);
            return false;
        }

        // --------------------
        // MOVE
        // --------------------
        current.removeMob(caster);
        next.addMob(caster);
        caster.setCurrentRoom(next);

        // Drop combat
        if (caster.getTarget() != null)
            caster.getTarget().setTarget(null);

        caster.setTarget(null);
        caster.setCurrentTarget(null);

        caster.sendMessage("You retreat " + dir.name().toLowerCase() + ", staying light on your feet.");

        current.broadcast(caster.getMobName() + " retreats " + dir.name().toLowerCase() + ".", caster);
        next.broadcast(caster.getMobName() + " steps in cautiously, retreating from battle.", caster);

        return true;
    }

    // ------------------------------------------------------------
    // Spell metadata
    // ------------------------------------------------------------
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAbility() { return true; }
    @Override public boolean isDirectional() { return true; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 0; }
    @Override public int getLevelRequired() { return 1; }
    @Override public Set<Profession> getProfessions() { return null; }

    @Override public boolean cast(Mob caster, Mob target) { return false; }
    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
}
// end
