package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.MagicDamageType;
import mud.spell.effects.FrostbiteEffect;

public class FrostbiteSpell implements Spell {

	
    private final MagicDamageType damageType = MagicDamageType.ICE;
    private final String icon = damageType.getIcon();
    private int durationTicks;


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        // Check if target is already iced
        if (target.hasEffect(EffectType.FROSTBITE)) {
            caster.sendMessage(target.getMobName() + " is already trapped in an " + getName().replace(".", " ") + icon + ".");
            return false;
        }

        durationTicks = 5;
        
        // Apply FrostbiteEffect
        FrostbiteEffect fb = new FrostbiteEffect(target, durationTicks);
        target.addEffect(fb);
        target.addEffect(EffectType.FROSTBITE);

        target.sendMessage("Freezing ice from the " + getName().replace(".", " ") + icon + " binds you to the ground, preventing movement!");
        caster.sendMessage("You freeze " + target.getMobName() + " in a " + getName().replace(".", " ") + icon + "!");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " casts a " + getName().replace(".", " ") + icon + " on " + target.getMobName() + "!");
        }
        return true;
    }

	@Override
	public String getName() {
		return "frostbite";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Fires a finger of frost energy at the target, freezing them in place.";
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// false, must be cast on mob
		return false;
	}

	@Override
	public int getLevelRequired() {
		// 
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// 
		return false;
	}

	@Override
	public boolean isAoE() {
		// 
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// 
		return false;
	}

	@Override
	public boolean isDirectional() {
		// 
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.MAGE, Profession.WARLOCK, Profession.BARD); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
