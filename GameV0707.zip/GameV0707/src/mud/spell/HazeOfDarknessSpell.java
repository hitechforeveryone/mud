package mud.spell;

import mud.core.*;
import mud.spell.effects.HazeOfDarknessEffect;

import java.util.Set;

public class HazeOfDarknessSpell implements Spell {

    int manaCost = 15;
    
	@Override
    public String getName() {
        return "haze.of.darkness";
    }

    @Override
    public String getDescription() {
        return "A dark haze descends, plunging the room into darkness for a short duration.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        Room room = caster.getCurrentRoom();
        if (room == null) return false;


        if (caster.getCurrentMP() < manaCost) {
            caster.sendMessage("You don't have enough mana to cast Haze of Darkness.");
            return false;
        }

        caster.setCurrentMP(caster.getCurrentMP() - manaCost);

        int durationTicks = 6; // duration of darkness
        HazeOfDarknessEffect effect = new HazeOfDarknessEffect(room, durationTicks);
        effect.tick(); // apply immediately

        room.broadcastToRoom(caster.capitalize(caster.getMobName())
                + " casts Haze of Darkness! A thick, black haze envelops the room.");

        return true;
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.NECROMANCER, Profession.WARLOCK);
    }

    @Override
    public int getLevelRequired() { return 1; }

    @Override public boolean cast(Mob caster, ObjectItem obj) { return false; }
    @Override public boolean cast(Mob caster, Direction tarDir) { return false; }

    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return true; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return manaCost; }
}
