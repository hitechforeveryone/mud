package mud.spell;

import mud.core.*;
import mud.spell.effects.*;

import java.util.Set;

public class UnderwaterBreathingSpell implements Spell {

    private static final int DEFAULT_DURATION = 20; // ticks, adjust as needed

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) return false;

        // Already has Underwater Breathing?
        for (Effect eff : target.getActiveEffects()) {
            if (eff.getType() == EffectType.UNDERWATER_BREATHING) {
                caster.sendMessage(target.getMobName() + " can already breathe underwater.");
                return false;
            }
        }

        MobUnderwaterBreathingEffect eff = new MobUnderwaterBreathingEffect(caster, target, DEFAULT_DURATION);
        target.addEffect(eff);
        caster.sendMessage("You grant " + target.getMobName() + " the ability to breathe underwater!");
        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem target) {
    	return false;
    }

    @Override
    public String getName() { return "Underwater.Breathing"; }

    @Override
    public String getDescription() {
        return "Allows a mob or item to breathe underwater for a duration.";
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.HUNTER, Profession.DRUID, Profession.MAGE);
    }

    @Override public boolean cast(Mob caster, Direction tarDir) { return false; }

    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 10; }
}
