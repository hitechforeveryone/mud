package mud.spell;

import mud.core.Mob;
import mud.core.ObjectItem;
import mud.core.Profession;
import mud.core.WeaponType;

import java.util.Set;

import mud.core.Direction;
import mud.core.EffectType;
import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.spell.effects.FrostbiteEffect;

public class FreezingShotSpell implements Spell {

	
    private final MagicDamageType damageType = MagicDamageType.ICE;
    private final String icon = damageType.getIcon();
    private int durationTicks;


    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to cast this on.");
            return false;
        }

        if ((caster.getEquippedItem(EquipSlot.MAINHAND) != null && caster.getEquippedItem(EquipSlot.MAINHAND).getWeaponType() == WeaponType.RANGED) || (caster.getEquippedItem(EquipSlot.OFFHAND) != null && caster.getEquippedItem(EquipSlot.OFFHAND).getWeaponType() == WeaponType.RANGED)) {
        
        int baseDamage = 5 + caster.getAgility();
        int scaledDamage = (int) (baseDamage * caster.getRank().getMultiplier());
        durationTicks = 5;
        
        target.takeDamage(scaledDamage, damageType);
        
        // Apply FrostbiteEffect
        FrostbiteEffect fb = new FrostbiteEffect(target, durationTicks);
        target.addEffect(fb);
        target.addEffect(EffectType.FROSTBITE);
        
        target.sendMessage("Freezing ice from the " + getName().replace(".", " ") + icon + " binds you to the ground, preventing movement!");
        caster.sendMessage("You freeze " + target.getMobName() + " in place with a " + getName().replace(".", " ") + icon + "!");

        // Optional: broadcast to room
        if (caster.getRoom() != null) {
            caster.getRoom().broadcastToRoom(caster.getMobName() + " casts a " + getName().replace(".", " ") + icon + " on " + target.getMobName() + "!");
        }
        return true;
        }
        
        else {
        	caster.sendMessage("You must have a range weapon equipped.");
        	return false;
        }
    }

	@Override
	public String getName() {
		return "freezing.shot";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Fires an icy cold shot at the target, dealing damage and freezing them in place.";
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// false, must be cast on mob
		return false;
	}

	@Override
	public int getLevelRequired() {
		// 
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// 
		return false;
	}

	@Override
	public boolean isAoE() {
		// 
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// 
		return false;
	}

	@Override
	public boolean isDirectional() {
		// 
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		return Set.of(Profession.HUNTER, Profession.MECHANIC); // multiple
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean cast(Mob caster, ObjectItem obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return true;
	}
}
