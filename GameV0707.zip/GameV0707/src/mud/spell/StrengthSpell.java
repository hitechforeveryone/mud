package mud.spell;

import mud.core.*;
import mud.spell.effects.StrengthEffect;

import java.util.Set;

public class StrengthSpell implements Spell {
    private final MagicDamageType damageType = MagicDamageType.BLEED;
    private final String icon = damageType.getIcon();
    @Override
    public String getName() {
        return "strength";
    }

    @Override
    public String getDescription() {
        return "Temporarily enhances the target's Strength by 2 + 10% of your Intellect.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to enhance.");
            return false;
        }

        int bonus = 2 + (int)(caster.getIntellect() * 0.10);
        int durationTicks = 20; // adjust as needed, e.g., 20 combat ticks

        StrengthEffect effect = new StrengthEffect(target, bonus, durationTicks);
        target.addEffect(effect);

        caster.sendMessage("You cast " + getName() + " on " + target.getMobName() + ", increasing their Strength." + icon + "!");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " casts " + getName() + " on you, enhancing your Strength!");
        }

        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem obj) {
        return false; // Not applicable
    }

    @Override
    public boolean cast(Mob caster, Direction tarDir) {
        return false; // Not directional
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.BARD, Profession.MAGE, Profession.WARLOCK); // example
    }

    @Override public int getLevelRequired() { return 1; }
    @Override public boolean isInstantCast() { return true; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return true; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return true; }
    @Override public int getManaCost() { return 5; } // example
}
