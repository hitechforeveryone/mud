// ContinualLightSpell.java
package mud.spell;

import java.util.Set;

import mud.core.*;
import mud.spell.effects.ContinualLightEffect;

public class ContinualLightSpell implements Spell {



	@Override
	public boolean cast(Mob caster, ObjectItem target) {
	    if (target == null) return false;

	    if (target.hasEffect(ItemEffect.GLOW)) {
	        caster.sendMessage(target.getName() + " is already glowing.");
	        return false;
	    }

	    int duration = 10;

	    ContinualLightEffect eff = new ContinualLightEffect(caster, target, duration);
	    target.addEffect(eff);
	    ContinualLightEffect.register(eff); // 🔑 REQUIRED

	    caster.sendMessage("You imbue " + target.getName() + " with a brilliant magical glow!");

	    Room room = caster.getCurrentRoom();
	    if (room != null) {
	        room.broadcast(
	            caster.getMobName() + " casts Continual Light on " + target.getName() + ".",
	            caster
	        );
	    }

	    return true;
	}


	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "continual.light";
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cast(Mob caster, Mob target) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cast(Mob caster, Direction tarDir) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Profession> getProfessions() {
		// TODO Auto-generated method stub
		return Set.of(Profession.MAGE, Profession.BARD,Profession.WARLOCK, Profession.MECHANIC);
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAoE() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelfTarget() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDirectional() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAbility() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNPCCastable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getManaCost() {
		// TODO Auto-generated method stub
		return 0;
	}
}
// end
