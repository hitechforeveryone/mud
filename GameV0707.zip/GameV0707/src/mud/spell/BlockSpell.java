package mud.spell;

import java.util.Set;

import mud.core.Mob;
import mud.core.Profession;
import mud.spell.effects.BlockEffect;

public class BlockSpell implements Spell {

    private static final int BLOCK_CHANCE = 25; // percent

    @Override
    public String getName() {
        return "block";
    }

    @Override
    public String getDescription() {
        return "Grants a passive chance to deflect incoming attacks.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually
        applyPassive(caster);
        return true;
    }

    /**
     * Apply the passive effect if missing
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("block")) {
            mob.addEffect(new BlockEffect(mob, BLOCK_CHANCE, Integer.MAX_VALUE)); // permanent until removed
        }
    }

    @Override
    public int getLevelRequired() {
        return 0; // adjust as needed
    }

    @Override
    public boolean isInstantCast() {
        return true; // passive, always active once applied
    }

    @Override
    public boolean isAoE() {
        return false;
    }

    @Override
    public boolean isSelfTarget() {
        return true;
    }

    @Override
    public boolean cast(Mob caster, mud.core.Direction tarDir) {
        return false;
    }

    @Override
    public boolean isDirectional() {
        return false;
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MONK); // multiple
    }

    @Override
    public boolean isAbility() {
        return true;
    }

    @Override
    public int getManaCost() {
        return 0;
    }

    @Override
    public boolean isNPCCastable() {
        return true;
    }

    @Override
    public boolean cast(Mob caster, mud.core.ObjectItem obj) {
        return false;
    }
}
