package mud.spell.effects;

import mud.core.*;

public class BlockEffect implements Effect {

    private final Mob target;
    private final boolean permanent = true;
    private final int blockChance; // percent chance to block
    private final MobAffectFlag flag = MobAffectFlag.BLOCK;

    public BlockEffect(Mob target, int blockChance, int duration) {
        this.target = target;
        this.blockChance = blockChance;
        this.target.setAffect(flag); // Enable block passive
    }

    /**
     * Called by combat system to determine if an attack is blocked
     */
    public boolean tryBlock() {
        if (target.isDead()) return false;
        return Math.random() <= blockChance / 100.0;
    }


    public boolean onIncomingAttack(Mob attacker, Mob target) {
        BlockEffect eff = target.getEffect(BlockEffect.class);
        if ((eff !=null) || !tryBlock()) return false; // check chance first
        else {

            attacker.sendMessage("Your attack has been blocked!");
            target.sendMessage("You deflect an incoming attack with your arm!");
            
            System.out.println("Attack Blocked");
            
            // Attack is completely negated
            attacker.setTarget(null);
            attacker.setCurrentTarget(null);
            attacker.setInCombat(false);
            
            target.setTarget(null);
            target.setCurrentTarget(null);
            target.setInCombat(false);
            
            Room r = target.getRoom();
            r.broadcastToExcept(attacker, target, target.getMobName() + " deflect's " + attacker.getMobName() + "s attack with their arm!");
          


            return true; // attack blocked
        }

    }
    
    @Override
    public void tick() {
        // Permanent/passive effect does not need ticking
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent
    }

    @Override
    public String getName() {
        return "block";
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public void onRemove() {
        target.removeAffect(flag);
    }

    @Override
    public int getHpBonus() { return 0; }

    @Override
    public int getStrengthBonus() { return 0; }

    @Override
    public EffectType getType() {  return null; }

    @Override
    public int getDuration() { return 0; }

    @Override
    public Direction getDirection() { return null; }

    @Override
    public void onApply(Room room) {
        // No room logic needed for passive block
    }

	public boolean isPermanent() {
		return permanent;
	}
}
