package mud.spell;

import mud.core.*;
import mud.spell.effects.*;

import java.util.Set;

public class WaterWalkSpell implements Spell {

    private static final int DEFAULT_DURATION = 20; // ticks, adjust as needed

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) return false;

        // Already has Water Walk?
        for (Effect eff : target.getActiveEffects()) {
            if (eff.getType() == EffectType.WATER_WALK) {
                caster.sendMessage(target.getMobName() + " is already able to walk on water.");
                return false;
            }
        }

        MobWaterWalkEffect eff = new MobWaterWalkEffect(caster, target, DEFAULT_DURATION);
        target.addEffect(eff);
        caster.sendMessage("You grant " + target.getMobName() + " the ability to walk on water!");
        return true;
    }

    @Override
    public boolean cast(Mob caster, ObjectItem target) {
    	return false;
    }

    @Override
    public String getName() { return "water.walk"; }

    @Override
    public String getDescription() {
        return "Allows a mob or item to walk on water for a duration.";
    }

    @Override
    public Set<Profession> getProfessions() {
        return Set.of(Profession.MAGE, Profession.DRUID, Profession.SHAMAN, Profession.BARD);
    }

    @Override public boolean cast(Mob caster, Direction tarDir) { return false; }
    public boolean cast(Mob caster, Mob target, Direction dir) { return false; }
    public boolean cast(Mob caster) { return false; }
    public boolean cast(Mob caster, ObjectItem obj, Direction dir) { return false; }
    public boolean cast(Mob caster, Direction tarDir, ObjectItem obj) { return false; }

    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return false; }
    @Override public boolean isAoE() { return false; }
    @Override public boolean isSelfTarget() { return false; }
    @Override public boolean isDirectional() { return false; }
    @Override public boolean isAbility() { return false; }
    @Override public boolean isNPCCastable() { return false; }
    @Override public int getManaCost() { return 10; }
}
