package mud.server;

import mud.commands.*;
import mud.config.Config;
import mud.core.*;
import mud.system.PlayerLoader;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class LoginManager {

    public static Player loginOrCreate(BufferedReader in, PrintWriter out) throws IOException {
        out.println("Welcome to the MUD!");
        out.println("Game Version: " + Config.gameVersion); 
        while (true) {
            out.print("""
            1) Login
            2) Create New Player
            3) Change Password
            4) Quit
            """);

            out.println("Choose an option (1-4): ");
            String input = in.readLine().trim().toLowerCase();

            switch (input) {
                case "1", "login" -> {
                	out.println("Enter username: ");
                    Player p = handleLogin(in, out);
                    if (p != null) return p;
                }
                case "2", "create", "new" -> {
                	out.println("Great! Choose a username: ");
                    Player p = handleCreate(in, out);
                	p = handleLogin(in,out);
                    if (p != null)
                    	return p;

                }
                case "3", "password", "changepw" -> handlePasswordChange(in, out);
                case "4", "quit", "exit" -> {
                    out.println("Goodbye!");
                    
                   // System.exit(0); // this also shuts down Server
                    in.close(); // closes this connections
                    
                }
                default -> out.println("Invalid input. Try again.");
            }
        }
    }

    private static Player handleLogin(BufferedReader in, PrintWriter out) throws IOException {
        out.print("Enter username: ");
        String name = in.readLine().trim();

        Player existing = WorldManager.getPlayerByName(name);
        if (existing != null) {
            out.println("⚠️ You were already logged in. Disconnecting previous session...");

            // Disconnect old session
            ClientHandler oldHandler = existing.getClientHandler();
            if (oldHandler != null) {
                oldHandler.sendMessage("⚠️ You have been disconnected due to login from another location.");
                oldHandler.disconnect();
            }

            // Remove from room
            Room oldRoom = existing.getCurrentRoom();
            if (oldRoom != null) {
                oldRoom.removeMob(existing);
            }

            WorldManager.removePlayer(existing);
            existing.setClientHandler(null);
        }

        Player player = PlayerLoader.load(name);
        if (player == null) {
            out.println("Error: Could not load player. The file might be corrupted or incompatible.");
            return null;
        }


        player.setWriter(out);

        out.print("Enter password: ");
        String password = in.readLine().trim();

        if (!player.checkPassword(password)) {
            out.println("Incorrect password.");
            return null;
        }

        out.println("Welcome back, " + player.getName() + "!");

        // ✅ Restore room
        Room savedRoom = WorldManager.getRoomFromIds(
            player.getRespawnWorldId(),
            player.getRespawnZoneId(),
            player.getRespawnRoomId()
        );
        if (savedRoom == null) {
            savedRoom = WorldManager.getDefaultLoginRoom();
            System.out.println("⚠️ Respawn room not found. Using default login room.");
        }
        // test respawn room logic
        System.out.println("Loaded respawn: W=" + player.getRespawnWorldId()
        + " Z=" + player.getRespawnZoneId()
        + " R=" + player.getRespawnRoomId());

        
        player.setCurrentRoom(savedRoom);
        player.setRoom(savedRoom);
        player.setCurrentZone(savedRoom.getZone());
        player.setCurrentWorld(savedRoom.getZone().getWorld());
        if (!savedRoom.getMobs().contains(player)) {
            savedRoom.addMob(player);
        }

     // Before assigning room or calling WorldManager.addPlayer(player)
        if (existing != null && existing != player) {
            System.out.println("⚠ Reconnecting: Removing previous instance of player " + name);
            
            // Remove from current room if present
            Room oldRoom = existing.getCurrentRoom();
            if (oldRoom != null) {
                oldRoom.removeMob(existing);
            }

            // Remove from global player list
            WorldManager.removePlayer(existing);

            // Null out the handler to avoid dangling messages
            existing.setClientHandler(null);
        }

        
        // ✅ Track in global player list
        WorldManager.addPlayer(player);

        // Save automatically for low-privilege players
        if (player.getPrivilegeLevel() <= 2) {
            PlayerLoader.save(player);
        }

        savedRoom.broadcastToRoom("Player " + player.getName() + " has entered the world.");
        ensureZoneConsistency(player);
        
        LookHandler.lookRoom(player,player.getCurrentRoom()); // display the room
        
        return player;
    }




    private static Player handleCreate(BufferedReader in, PrintWriter out) throws IOException {
        out.print("Choose a player/username: ");
        String name = in.readLine().trim();

        if (PlayerLoader.exists(name)) {
            out.println("That player already exists.");
            return null;
        }

        out.println("New Player name chosen. Welcome, " + name + "!");

        out.println("Choose a password: ");
        String password = in.readLine().trim();

        Player player = new Player(name);
        player.setPassword(password);
        player.setPrivilegeLevel(1);

        out.println("\n--- Player Setup ---");

        out.println("Enter a short description (e.g., A wiry rogue): ");
        player.setShortDescription(in.readLine().trim());

        out.println("Enter an extended description (optional): ");
        player.setExtendedDescription(in.readLine().trim());

        out.println("Enter space-separated keywords (e.g., rogue wiry human): ");
        Set<String> keywords = Arrays.stream(in.readLine().trim().split(" "))
            .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toSet());
        player.setKeywords(keywords);

        player.setRace(MobRace.HUMANOID.name());

        out.println("Choose a subrace:");
        List<MobSubRace> validSubraces = Arrays.stream(MobSubRace.values())
            .filter(sr -> sr.getParentRace() == MobRace.HUMANOID)
            .collect(Collectors.toList());
        for (MobSubRace sr : validSubraces) {
            out.println("- " + sr.name());
        }
        while (true) {
            out.print("Enter subrace: ");
            String input = in.readLine().trim().toUpperCase();
            try {
                MobSubRace selected = MobSubRace.valueOf(input);
                if (selected.getParentRace() != MobRace.HUMANOID) throw new IllegalArgumentException();
                player.setSubrace(selected.name());
                break;
            } catch (IllegalArgumentException e) {
                out.println("\u274C Invalid subrace. Try again.");
            }
        }

        out.println("Choose a profession:");
        for (Profession p : Profession.values()) {
            out.println("- " + p.name());
        }
        while (true) {
            out.println("Enter profession: ");
            String input = in.readLine().trim().toUpperCase();
            try {
                player.setProfession(Profession.valueOf(input));
                break;
            } catch (IllegalArgumentException e) {
                out.println("\u274C Invalid profession. Try again.");
            }
        }

        out.println("\nYou may enter 'help <topic>' or 'hindex' to browse help topics, or type 'done' to finish.");
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.equalsIgnoreCase("done")) break;
            if (line.toLowerCase().startsWith("help ")) {
                String topic = line.substring(5);
                HelpEntry entry = HelpManager.getHelpEntry(topic);
                if (entry != null) {
                    out.println("\n-- Help: " + entry.getKeyword() + " --");
                    out.println(entry.getBody());
                } else {
                    out.println("No help entry for: " + topic);
                }
            } else if (line.equalsIgnoreCase("hindex")) {
                out.println("Available help topics:");
                for (HelpEntry entry : HelpManager.getAllEntries()) {
                    out.println("- " + entry.getKeyword());
                }
            } else {
                out.println("Unknown input. Type 'done' to finish.");
            }
        }

        player.regenerateStatsFromRaceLevelAndRank();

        Room loginRoom = WorldManager.getRoomFromIds(
            Config.DEFAULT_WORLD_ID,
            Config.DEFAULT_LOGIN_ZONE,
            Config.DEFAULT_LOGIN_ROOM
        );

        if (loginRoom == null) {
            out.println("\u26A0 Default login room not found. Aborting.");
            return null;
        }

        World world = loginRoom.getZone().getWorld();
        Zone zone = loginRoom.getZone();

        player.setCurrentWorld(world);
        player.setCurrentZone(zone);
        player.setCurrentRoom(loginRoom);

        player.setRespawnWorldId(world.getWorldId());
        player.setRespawnZoneId(zone.getZoneId());
        player.setRespawnRoomId(loginRoom.getId());

        player.updateRespawnLocationFromCurrentRoom();

        PlayerLoader.save(player);
        out.println("Player created. Welcome, " + name + "!");
        out.println("Press any key to login.");
        return player;
    }




    private static void handlePasswordChange(BufferedReader in, PrintWriter out) throws IOException {
        out.print("Enter your username: ");
        String name = in.readLine().trim();

        if (!PlayerLoader.exists(name)) {
            out.println("No such player.");
            return;
        }

        out.print("Enter current password: ");
        String oldPass = in.readLine().trim();
        Player player = PlayerLoader.load(name);

        if (player == null || !player.checkPassword(oldPass)) {
            out.println("Incorrect password.");
            return;
        }

        out.print("Enter new password: ");
        String newPass = in.readLine().trim();
        player.setPassword(newPass);
        PlayerLoader.save(player);
        out.println("Password changed successfully.");
    }
    
    
    public static void ensureZoneConsistency(Player player) {
        Room room = player.getCurrentRoom();

        if (room != null) {
            player.setRoom(room);
            Zone zone = room.getZone();
            if (zone != null) {
                player.setCurrentZone(zone);
            }
        }
    }

    
} // end
