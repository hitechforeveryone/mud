package game3;

public class equipment {
	
	int eqNum;
	String eqName;
	String eqShortDesc;
	String eqLongDesc;
	String[] eqKeyWords;
	String eqSlot;
	String eqDmg;
	int eqAddStr;
	int eqAddStam;
	int eqAddInt;
	int eqAddAgi;
	
}
