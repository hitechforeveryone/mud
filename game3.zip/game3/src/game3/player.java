package game3;

public class player {
	
	int playerNum; // 0
	String playerName; //1 a name
	String playerShortDesc; //2 a sentence fragment. ex "a fat, hairy dwarf"
	String playerLongDesc; //3 a short paragraph
	String[] playerKeyWords = new String[3]; //4 keywords
	int playerHP = 100; //5 hp
	int playerMP = 100; //6 mp
	int playerLvl = 1; //7 lvl
	int Stam = 10; //8 increases player HPs
	int Str = 10; //9 increases player base dmg
	int Intel = 10; //10 higher intel increases player mana
	int Agility = 10; //11 higher agility increases critical strike chance
	String headSlot = "nothing";//12
	String neckSlot = "nothing";//13
	String shoulderSlot = "nothing";//14
	String chestSlot = "nothing";//15
	String wristSlot = "nothing";//16
	String handSlot = "nothing";//17
	String finger1 = "nothing";//18
	String finger2 = "nothing";//19
	String waistSlot = "nothing";//20
	String legSlot = "nothing";//21
	String footSlot = "nothing";//22
	String trinket1Slot = "nothing";//23
	String trinket2Slot = "nothing";//24
	String weapon1Slot = "nothing";//25
	String weaponShieldSlot = "nothing";//26

	String playerRace = "none"; //27 human, elf, half-elf, dwarf, orc, troll, tauren, ...
	String playerTier = "0"; //28 
	/*
	 * 	Player Tier ranks:
	 * 		players can have ranks, higher ranks increase their health and damage and available spells/abilities
	 * 		Tier 0 - default tier
	 * 		Tier 1 - hp, dps increase by 125%
	 * 		Tier 2 - hp, dps increase 150%
	 * 		Tier 3 - hp, dps increase 175%
	 * 		Tier 4 - hp, dps increase 200%
	 * 		Tier Imm - hp, dps increase 1000%
	 * 		Tier GImm - access to dev tools
	 */

	

	int playerXP = 0;//29
	/*
	 *   XP for lvl 1-2 = 1000 XP, lvl 2-3 = 1500, lvl 3-4 = 2250, 3375, 5063, 7594, 11391, 17087, 25630,
	 *   38445, 57667, 86501, 129751, 194626. 291939, 437904, 656863
	 *   XP increases by 1.5x per subsequent level
	 */
	int playerIsAlive = 1;//30
	String playerGender = "none";//31

	static int xplvl1 = 0;
	static int xplvl2 = 1000;
	static int xplvl3 = 1500;
	static int xplvl4 = 2250;
	static int xplvl5 = 3375;
	static int xplvl6 = 5063;
	static int xplvl7 = 7594;
	static int xplvl8 = 11391;
	static int xplvl9 = 17087;
	static int xplvl10 = 25630;
	static int xplvl11 = 25630;
	static int xplvl12 = 38445;
	static int xplvl13 = 57667;
	static int xplvl14 = 86501;
	static int xplvl15 = 129751;
	static int xplvl16 = 194626;
	static int xplvl17 = 291939;
	static int xplvl18 = 437904;
	static int xplvl19 = 656863;
	static int xplvl20 = 985294;
	static int xplvl21 = 1477941;
	static int xplvl22 = 2216911;
	static int xplvl23 = 3325367;
	static int xplvl24 = 4988051;
	static int xplvl25 = 7482076;
	static int xplvl26 = 11223114;
	static int xplvl27 = 16834701;
	static int xplvl28 = 25252006;
	static int xplvl29 = 37878009;
	static int xplvl30 = 56817013;
	
	public void returnPlayerScore() {
		System.out.println("Player Name: " + getPlayerName());
		System.out.println("Description: " + getPlayerLongDesc());
		System.out.println("Race: " + getPlayerRace() + "  Level: [ " + getPlayerLvl() + "]   Tier: [" + getPlayerTier() + "]");
		System.out.println("XP: [" + getPlayerXP() + "]");
		int xptoNextLevel = 0;
		if (getPlayerLvl() == 1) {  xptoNextLevel = xplvl2 - getPlayerXP(); }
		if (getPlayerLvl() == 2) {  xptoNextLevel = xplvl3 - getPlayerXP(); }
		if (getPlayerLvl() == 3) {  xptoNextLevel = xplvl4 - getPlayerXP(); }
		if (getPlayerLvl() == 4) {  xptoNextLevel = xplvl5 - getPlayerXP(); }
		if (getPlayerLvl() == 5) {  xptoNextLevel = xplvl6 - getPlayerXP(); }
		if (getPlayerLvl() == 6) {  xptoNextLevel = xplvl7 - getPlayerXP(); }
		if (getPlayerLvl() == 7) {  xptoNextLevel = xplvl8 - getPlayerXP(); }
		if (getPlayerLvl() == 8) {  xptoNextLevel = xplvl9 - getPlayerXP(); }
		if (getPlayerLvl() == 9) {  xptoNextLevel = xplvl10 - getPlayerXP(); }
		if (getPlayerLvl() == 10) {  xptoNextLevel = xplvl11 - getPlayerXP(); }
		if (getPlayerLvl() == 11) {  xptoNextLevel = xplvl12 - getPlayerXP(); }
		if (getPlayerLvl() == 12) {  xptoNextLevel = xplvl13 - getPlayerXP(); }
		if (getPlayerLvl() == 13) {  xptoNextLevel = xplvl14 - getPlayerXP(); }
		if (getPlayerLvl() == 14) {  xptoNextLevel = xplvl15 - getPlayerXP(); }
		if (getPlayerLvl() == 15) {  xptoNextLevel = xplvl16 - getPlayerXP(); }
		if (getPlayerLvl() == 16) {  xptoNextLevel = xplvl17 - getPlayerXP(); }
		if (getPlayerLvl() == 17) {  xptoNextLevel = xplvl18 - getPlayerXP(); }
		if (getPlayerLvl() == 18) {  xptoNextLevel = xplvl19 - getPlayerXP(); }
		if (getPlayerLvl() == 19) {  xptoNextLevel = xplvl20 - getPlayerXP(); }
		if (getPlayerLvl() == 20) {  xptoNextLevel = xplvl21 - getPlayerXP(); }
		if (getPlayerLvl() == 21) {  xptoNextLevel = xplvl22 - getPlayerXP(); }
		if (getPlayerLvl() == 22) {  xptoNextLevel = xplvl23 - getPlayerXP(); }
		if (getPlayerLvl() == 23) {  xptoNextLevel = xplvl24 - getPlayerXP(); }
		if (getPlayerLvl() == 24) {  xptoNextLevel = xplvl25 - getPlayerXP(); }
		if (getPlayerLvl() == 25) {  xptoNextLevel = xplvl26 - getPlayerXP(); }
		if (getPlayerLvl() == 26) {  xptoNextLevel = xplvl27 - getPlayerXP(); }
		if (getPlayerLvl() == 27) {  xptoNextLevel = xplvl28 - getPlayerXP(); }
		if (getPlayerLvl() == 28) {  xptoNextLevel = xplvl29 - getPlayerXP(); }
		if (getPlayerLvl() == 29) {  xptoNextLevel = xplvl30 - getPlayerXP(); }
		if (getPlayerLvl() == 30) {  xptoNextLevel = xplvl30 - getPlayerXP(); }
		
		System.out.println("XP to next Level: " + xptoNextLevel);
		System.out.println("HPs: [" + getPlayerHP() + "]   MPs: [" + getPlayerMP() + "]");
		System.out.println("Stamina: " + getStam() + "  Strength: " + getStr() + "   Intelligence: " + getIntel() + "   Agility: " + getAgility());
	}

	public void returnPlayerInfo() {
		System.out.println("Player Name: " + getPlayerName());
		System.out.println("Description: " + getPlayerLongDesc());
		System.out.println("Race: " + getPlayerRace() + "  Level: [ " + getPlayerLvl() + "]   Tier: [" + getPlayerTier() + "]");
		System.out.println("XP: [" + getPlayerXP() + "]");
		System.out.println("HPs: [" + getPlayerHP() + "]   MPs: [" + getPlayerMP() + "]");
		System.out.println("Stamina: " + getStam() + "  Strength: " + getStr() + "   Intelligence: " + getIntel() + "   Agility: " + getAgility());
		System.out.println("Equiped Items -----------------------------------------------------------");
		System.out.println("Head Slot: " + getHeadSlot());
		System.out.println("Neck Slot: " + getNeckSlot());
		System.out.println("Shoulder Slot: " + getShoulderSlot());
		System.out.println("Chest Slot: " + getChestSlot());
		System.out.println("Wrist Slot: " + getWristSlot());
		System.out.println("Hand Slot: " + getHandSlot());		
		System.out.println("Finger Slot: " + getFinger1());
		System.out.println("Finger Slot: " + getFinger2());
		System.out.println("Waist Slot: " + getWaistSlot());
		System.out.println("Leg Slot: " + getLegSlot());
		System.out.println("Foot Slot: " + getFootSlot());
		System.out.println("Trinket Slot: " + getTrinket1Slot());
		System.out.println("Trinket Slot: " + getTrinket2Slot());
		System.out.println("Weapon Slot: " + getWeapon1Slot());
		System.out.println("Offhand Slot: " + getWeaponShieldSlot());

	}


	public int getPlayerNum() {
		return playerNum;
	}

	public void setPlayerNum(int playerNum) {
		this.playerNum = playerNum;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getPlayerShortDesc() {
		return playerShortDesc;
	}

	public void setPlayerShortDesc(String playerShortDesc) {
		this.playerShortDesc = playerShortDesc;
	}

	public String getPlayerLongDesc() {
		return playerLongDesc;
	}

	public void setPlayerLongDesc(String playerLongDesc) {
		this.playerLongDesc = playerLongDesc;
	}

	public String[] getPlayerKeyWords() {
		return playerKeyWords;
	}

	public void setPlayerKeyWords(String[] playerKeyWords) {
		this.playerKeyWords = playerKeyWords;
	}

	public int getPlayerHP() {
		return playerHP;
	}

	public void setPlayerHP(int playerHP) {
		this.playerHP = playerHP;
	}

	public int getPlayerMP() {
		return playerMP;
	}

	public void setPlayerMP(int playerMP) {
		this.playerMP = playerMP;
	}

	public int getPlayerLvl() {
		return playerLvl;
	}

	public void setPlayerLvl(int playerLvl) {
		this.playerLvl = playerLvl;
	}

	public int getStam() {
		return Stam;
	}

	public void setStam(int stam) {
		Stam = stam;
	}

	public int getStr() {
		return Str;
	}

	public void setStr(int str) {
		Str = str;
	}

	public int getIntel() {
		return Intel;
	}

	public void setIntel(int intel) {
		Intel = intel;
	}

	public int getAgility() {
		return Agility;
	}

	public void setAgility(int agility) {
		Agility = agility;
	}

	public String getHeadSlot() {
		return headSlot;
	}

	public void setHeadSlot(String headSlot) {
		this.headSlot = headSlot;
	}

	public String getNeckSlot() {
		return neckSlot;
	}

	public void setNeckSlot(String neckSlot) {
		this.neckSlot = neckSlot;
	}

	public String getShoulderSlot() {
		return shoulderSlot;
	}

	public void setShoulderSlot(String shoulderSlot) {
		this.shoulderSlot = shoulderSlot;
	}

	public String getChestSlot() {
		return chestSlot;
	}

	public void setChestSlot(String chestSlot) {
		this.chestSlot = chestSlot;
	}

	public String getWristSlot() {
		return wristSlot;
	}

	public void setWristSlot(String wristSlot) {
		this.wristSlot = wristSlot;
	}

	public String getHandSlot() {
		return handSlot;
	}

	public void setHandSlot(String handSlot) {
		this.handSlot = handSlot;
	}

	public String getFinger1() {
		return finger1;
	}

	public void setFinger1(String finger1) {
		this.finger1 = finger1;
	}

	public String getFinger2() {
		return finger2;
	}

	public void setFinger2(String finger2) {
		this.finger2 = finger2;
	}

	public String getWaistSlot() {
		return waistSlot;
	}

	public void setWaistSlot(String waistSlot) {
		this.waistSlot = waistSlot;
	}

	public String getLegSlot() {
		return legSlot;
	}

	public void setLegSlot(String legSlot) {
		this.legSlot = legSlot;
	}

	public String getFootSlot() {
		return footSlot;
	}

	public void setFootSlot(String footSlot) {
		this.footSlot = footSlot;
	}

	public String getTrinket1Slot() {
		return trinket1Slot;
	}

	public void setTrinket1Slot(String trinket1Slot) {
		this.trinket1Slot = trinket1Slot;
	}

	public String getTrinket2Slot() {
		return trinket2Slot;
	}

	public void setTrinket2Slot(String trinket2Slot) {
		this.trinket2Slot = trinket2Slot;
	}

	public String getWeapon1Slot() {
		return weapon1Slot;
	}

	public void setWeapon1Slot(String weapon1Slot) {
		this.weapon1Slot = weapon1Slot;
	}

	public String getWeaponShieldSlot() {
		return weaponShieldSlot;
	}

	public void setWeaponShieldSlot(String weaponShieldSlot) {
		this.weaponShieldSlot = weaponShieldSlot;
	}

	public String getPlayerRace() {
		return playerRace;
	}

	public void setPlayerRace(String playerRace) {
		this.playerRace = playerRace;
	}

	public String getPlayerTier() {
		return playerTier;
	}

	public void setPlayerTier(String playerTier) {
		this.playerTier = playerTier;
	}

	public int getPlayerXP() {
		return playerXP;
	}

	public void setPlayerXP(int playerXP) {
		this.playerXP = playerXP;
	}

	public int getPlayerIsAlive() {
		return playerIsAlive;
	}


	public void setPlayerIsAlive(int playerIsAlive) {
		this.playerIsAlive = playerIsAlive;
	}


	public String getPlayerGender() {
		return playerGender;
	}


	public void setPlayerGender(String playerGender) {
		this.playerGender = playerGender;
	}

}
