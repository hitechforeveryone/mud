package game3;

import java.util.ArrayList;

public class objects {
	// Default Object
	int objNum;
	public int getObjNum() {
		return objNum;
	}

	public void setObjNum(int objNum) {
		this.objNum = objNum;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjShortDesc() {
		return objShortDesc;
	}

	public void setObjShortDesc(String objShortDesc) {
		this.objShortDesc = objShortDesc;
	}

	public String getObjLongDesc() {
		return objLongDesc;
	}

	public void setObjLongDesc(String objLongDesc) {
		this.objLongDesc = objLongDesc;
	}

	public String getObjExtDesc() {
		return objExtDesc;
	}

	public void setObjExtDesc(String objExtDesc) {
		this.objExtDesc = objExtDesc;
	}

	public String[] getObjKeyWords() {
		return objKeyWords;
	}

	public void setObjKeyWords(String[] objKeyWords) {
		this.objKeyWords = objKeyWords;
	}

	public void returnObjInfo() {
		System.out.println("Object: " + getObjNum());
		System.out.println("Object Name: " + getObjName());
		System.out.println("Object Description: " + getObjLongDesc());
		System.out.println("Object Description: " + getObjExtDesc());
	}

	String objName;
	String objShortDesc;
	String objLongDesc;
	String objExtDesc;
	String[] objKeyWords = new String[3];
	ArrayList<String> objContains = new ArrayList<String>(20);
	public void setAddStam(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAddStr(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAddInt(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAddAgi(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setTakeable(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setDurability(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAddMP(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAddHP(String string) {
		// TODO Auto-generated method stub
		
	}

}
