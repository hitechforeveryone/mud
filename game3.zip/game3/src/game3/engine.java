package game3;

//IMPORTS
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;



public class engine {

	/////////////////////////////////////////////////////////////////
	//  INITIALIZERS 
	/////////////////////////////////////////////////////////////////

	// files and paths
	static String worldPath = "src/game3/world.txt";
	Path worldPath1 = Paths.get(worldPath);
	static String  mobPath = "src/game3/mobs.txt";
	Path mobPath1 = Paths.get(mobPath);
	static String objPath = "src/game3/objects.txt";
	Path objPath1 = Paths.get(objPath);
	static String eqPath = "src/game3/equipment.txt";
	Path eqPath1 = Paths.get(eqPath);
	static String kinput;
	static Scanner input = new Scanner(System.in);

	static String[][] World = new String[1000000][50];
	static String[][] Objects = new String[1000000][50]; // default 10000 objects, up to 50 args per object
	static String[][] Equipment = new String[1000000][50];
	static String[][] Mobs = new String[1000000][50]; //default 10000 mobs, up to 50 rags per mob
	static String[][] csvArray = new String[10000][50];
	static String[] tmobsarr = new String[6];
	static String[] tobjsarr = new String[6];
	static room newRoom = new room();
	static room exN = new room();
	static room exNE = new room();
	static room exE = new room();
	static room exSE = new room();
	static room exS = new room();
	static room exSW = new room();
	static room exW = new room();
	static room exNW = new room();
	static room exU = new room();
	static room exD = new room();
	static mob tmob0 = new mob();
	static mob tmob1 = new mob();
	static mob tmob2 = new mob();
	static mob tmob3 = new mob();
	static mob tmob4 = new mob();
	static mob tmob5 = new mob();

	static objects tobj0 = new objects();
	static objects tobj1 = new objects();
	static objects tobj2 = new objects();
	static objects tobj3 = new objects();
	static objects tobj4 = new objects();
	static objects tobj5 = new objects();

	static player newPlayer = new player();

	// timers for sun, moons and weather
	int sundelaytime = 30; //  set for halfday in seconds (1/2 day)
	long sundelay = sundelaytime * 1000; // get from milliseconds to seconds
	long moon1delay = sundelaytime * 1000;
	long moon2delay = sundelaytime * 1000/2; // double speed!
	long moon3delay = sundelaytime * 1000; // 
	long rainyweather = sundelaytime * 2000; // 1 game day
	SunTask task = new SunTask();
	Moon1Task task1 = new Moon1Task();
	Moon2Task task2 = new Moon2Task();
	Moon3Task task3 = new Moon3Task();
	RainyWeather task4 = new RainyWeather();
	Timer suntimer = new Timer("Sunrise");
	Timer moontimer1 = new Timer("Moon1rise");
	Timer moontimer2 = new Timer("Moon2rise");
	Timer moontimer3 = new Timer("Moon3rise");
	Timer raintimer = new Timer ("Rainy Weather");

	static int daynum = 0; // days since start
	static int daytime = 0; // day status. 2 cycle
	static int moontime1 = 0; // moon 1 status, 6 status cycle
	static int moontime2 = 0; // moon 2 status, 2 status, 2x speed
	static int moontime3 = 0; // 
	static int raintime = 0; // rain status, 2 cycle
	static String sunstatus = "visible";
	static String moon1status = "visible";
	static String moon2status = "visible";
	static String moon3status = "visible";
	static String weatherstatus = "clear";

	static long startTime = System.nanoTime();



	/////////////////////////////////////////////////////////////////
	//  Engine Start
	/////////////////////////////////////////////////////////////////
	@SuppressWarnings({ "all" })
	public static void main(String[] args) throws IOException
	{


		System.out.println("Initializing");



		String csvFile = worldPath;
		File file = new File(csvFile);
		String csvData = "";
		String cvsSplitBy = "|";
		String[] rowData = new String[50];
		ArrayList<String> World2 = new ArrayList<String>(10);
		int troomNum = 0;
		int tmobNum = 0;
		int tobjNum = 0;

		if (file.exists()) {
			// read csv file to array
			try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
				Scanner scanner = new Scanner(br);
				System.out.println("Reading " + csvFile + " File.");
				String line = "";
				while (scanner.hasNextLine()) {
					line = scanner.nextLine();
					String[] tworld = new String[50];
					line = line.replace("||", "|");
					tworld = line.split("\\|");
					World[troomNum][0] = tworld[0];
					World[troomNum][1] = tworld[1];
					World[troomNum][2] = tworld[2];
					World[troomNum][3] = tworld[3];
					World[troomNum][4] = tworld[4];
					World[troomNum][5] = tworld[5];
					World[troomNum][6] = tworld[6];
					World[troomNum][7] = tworld[7];
					World[troomNum][8] = tworld[8];
					World[troomNum][9] = tworld[9];
					World[troomNum][10] = tworld[10];
					World[troomNum][11] = tworld[11];
					World[troomNum][12] = tworld[12];
					World[troomNum][13] = tworld[13];
					World[troomNum][14] = tworld[14];
					World[troomNum][15] = tworld[15];
					World[troomNum][16] = tworld[16];
					World[troomNum][17] = tworld[17];
					World[troomNum][18] = tworld[18];
					World[troomNum][19] = tworld[19];
					World[troomNum][20] = tworld[20];
					World[troomNum][21] = tworld[21];
					World[troomNum][22] = tworld[22];
					World[troomNum][23] = tworld[23];
					World[troomNum][24] = tworld[24];
					World[troomNum][25] = tworld[25];
					World[troomNum][26] = tworld[26];
					World[troomNum][27] = tworld[27];
					World[troomNum][28] = tworld[28];
					World[troomNum][29] = tworld[29];
					World[troomNum][30] = tworld[30];
					World[troomNum][31] = tworld[31];
					World[troomNum][32] = tworld[32];
					World[troomNum][33] = tworld[33];
					World[troomNum][34] = tworld[34];
					World[troomNum][35] = tworld[35];
					World[troomNum][36] = tworld[36];
					World[troomNum][37] = tworld[37];
					World[troomNum][38] = tworld[38];
					World[troomNum][39] = tworld[39];
					World[troomNum][40] = tworld[40];
					World[troomNum][41] = tworld[41];
					World[troomNum][42] = tworld[42];
					World[troomNum][43] = tworld[43];
					World[troomNum][44] = tworld[44];
					World[troomNum][45] = tworld[45];
					World[troomNum][46] = tworld[46];
					World[troomNum][47] = tworld[47];
					World[troomNum][48] = tworld[48];
					World[troomNum][49] = tworld[49];

					troomNum++;

					test();
				}


			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		else {
			// write sample csv
			System.out.println("World File doesn't exist!");
			System.out.println("Writing default room data.");
			csvData = "0|The Last Keg Goodnight Inn|a worn building|This rugged building has withstood many tales and adventures.  The wood has aged to a deep reddish color.The smells of rich foods and strong drinks have permently stained the air.  Here and there you see a tiredadventurer, sleeping away his woes.  A large hearth sits in the corner, merrily burning.  A faint crackling of the flames can be heard over the dull whispers in the room.|-1|-1|-1|-1|-1|-1|-1|-1|-1|-1|[1, 0]|[0]|1|1|1|1|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null";

			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile));
				writer.write(csvData);
				writer.close();
			} catch (IOException e) {
				System.out.println("Error writing " + csvFile + " file: " + e.getMessage());
			}
		}

		csvFile = mobPath;
		file = new File(csvFile);
		csvData = "";
		cvsSplitBy = "|";

		if (file.exists()) {
			// read csv file to array
			try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
				Scanner scanner = new Scanner(br);
				System.out.println("Reading " + csvFile + " File.");
				String line = "";
				while (scanner.hasNextLine()) {
					line = scanner.nextLine();
					String[] tmob = new String[50];
					line = line.replace("||", "|");
					tmob = line.split("\\|");

					Mobs[tmobNum][0] = tmob[0];
					Mobs[tmobNum][1] = tmob[1];
					Mobs[tmobNum][2] = tmob[2];
					Mobs[tmobNum][3] = tmob[3];
					Mobs[tmobNum][4] = tmob[4];
					Mobs[tmobNum][5] = tmob[5];
					Mobs[tmobNum][6] = tmob[6];
					Mobs[tmobNum][7] = tmob[7];
					Mobs[tmobNum][8] = tmob[8];
					Mobs[tmobNum][9] = tmob[9];
					Mobs[tmobNum][10] = tmob[10];
					Mobs[tmobNum][11] = tmob[11];
					Mobs[tmobNum][12] = tmob[12];
					Mobs[tmobNum][13] = tmob[13];
					Mobs[tmobNum][14] = tmob[14];
					Mobs[tmobNum][15] = tmob[15];
					Mobs[tmobNum][16] = tmob[16];
					Mobs[tmobNum][17] = tmob[17];
					Mobs[tmobNum][18] = tmob[18];
					Mobs[tmobNum][19] = tmob[19];
					Mobs[tmobNum][20] = tmob[20];
					Mobs[tmobNum][21] = tmob[21];
					Mobs[tmobNum][22] = tmob[22];
					Mobs[tmobNum][23] = tmob[23];
					Mobs[tmobNum][24] = tmob[24];
					Mobs[tmobNum][25] = tmob[25];
					Mobs[tmobNum][26] = tmob[26];
					Mobs[tmobNum][27] = tmob[27];
					Mobs[tmobNum][28] = tmob[28];
					Mobs[tmobNum][29] = tmob[29];
					Mobs[tmobNum][30] = tmob[30];
					Mobs[tmobNum][31] = tmob[31];
					Mobs[tmobNum][32] = tmob[32];
					Mobs[tmobNum][33] = tmob[33];
					Mobs[tmobNum][34] = tmob[34];
					Mobs[tmobNum][35] = tmob[35];
					Mobs[tmobNum][36] = tmob[36];
					Mobs[tmobNum][37] = tmob[37];
					Mobs[tmobNum][38] = tmob[38];
					Mobs[tmobNum][39] = tmob[39];
					Mobs[tmobNum][40] = tmob[40];
					Mobs[tmobNum][41] = tmob[41];
					Mobs[tmobNum][42] = tmob[42];
					Mobs[tmobNum][43] = tmob[43];
					Mobs[tmobNum][44] = tmob[44];
					Mobs[tmobNum][45] = tmob[45];
					Mobs[tmobNum][46] = tmob[46];
					Mobs[tmobNum][47] = tmob[47];
					Mobs[tmobNum][48] = tmob[48];
					Mobs[tmobNum][49] = tmob[49];

					tmobNum++;
					test();
				}


			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		else {
			// write sample csv
			System.out.println("Mob File doesn't exist!");
			System.out.println("Writing default mob data.");
			csvData = "0|The Spectre|a floating spectre|You see before you a floating spectre.  It has no physical form, its semi-transparent body phases in and out of transparency.|1000|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|magic|null|normal|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null";

			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile));
				writer.write(csvData);
				writer.close();
			} catch (IOException e) {
				System.out.println("Error writing " + csvFile + " file: " + e.getMessage());
			}
		}


		csvFile = objPath;
		file = new File(csvFile);
		csvData = "";
		cvsSplitBy = "|";

		if (file.exists()) {
			// read csv file to array
			try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
				Scanner scanner = new Scanner(br);
				System.out.println("Reading " + csvFile + " File.");
				String line = "";
				while (scanner.hasNextLine()) {
					line = scanner.nextLine();
					String[] tobj = new String[50];
					line = line.replace("||", "|");
					tobj = line.split("\\|");

					Objects[tobjNum][0] = tobj[0];
					Objects[tobjNum][1] = tobj[1];
					Objects[tobjNum][2] = tobj[2];
					Objects[tobjNum][3] = tobj[3];
					Objects[tobjNum][4] = tobj[4];
					Objects[tobjNum][5] = tobj[5];
					Objects[tobjNum][6] = tobj[6];
					Objects[tobjNum][7] = tobj[7];
					Objects[tobjNum][8] = tobj[8];
					Objects[tobjNum][9] = tobj[9];
					Objects[tobjNum][10] = tobj[10];
					Objects[tobjNum][11] = tobj[11];
					Objects[tobjNum][12] = tobj[12];
					Objects[tobjNum][13] = tobj[13];
					Objects[tobjNum][14] = tobj[14];
					Objects[tobjNum][15] = tobj[15];
					Objects[tobjNum][16] = tobj[16];
					Objects[tobjNum][17] = tobj[17];
					Objects[tobjNum][18] = tobj[18];
					Objects[tobjNum][19] = tobj[19];
					Objects[tobjNum][20] = tobj[20];
					Objects[tobjNum][21] = tobj[21];
					Objects[tobjNum][22] = tobj[22];
					Objects[tobjNum][23] = tobj[23];
					Objects[tobjNum][24] = tobj[24];
					Objects[tobjNum][25] = tobj[25];
					Objects[tobjNum][26] = tobj[26];
					Objects[tobjNum][27] = tobj[27];
					Objects[tobjNum][28] = tobj[28];
					Objects[tobjNum][29] = tobj[29];
					Objects[tobjNum][30] = tobj[30];
					Objects[tobjNum][31] = tobj[31];
					Objects[tobjNum][32] = tobj[32];
					Objects[tobjNum][33] = tobj[33];
					Objects[tobjNum][34] = tobj[34];
					Objects[tobjNum][35] = tobj[35];
					Objects[tobjNum][36] = tobj[36];
					Objects[tobjNum][37] = tobj[37];
					Objects[tobjNum][38] = tobj[38];
					Objects[tobjNum][39] = tobj[39];
					Objects[tobjNum][40] = tobj[40];
					Objects[tobjNum][41] = tobj[41];
					Objects[tobjNum][42] = tobj[42];
					Objects[tobjNum][43] = tobj[43];
					Objects[tobjNum][44] = tobj[44];
					Objects[tobjNum][45] = tobj[45];
					Objects[tobjNum][46] = tobj[46];
					Objects[tobjNum][47] = tobj[47];
					Objects[tobjNum][48] = tobj[48];
					Objects[tobjNum][49] = tobj[49];

					tobjNum++;
					test();
				}


			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		else {
			// write sample csv
			System.out.println("Object File doesn't exist!");
			System.out.println("Writing default object data.");
			csvData = "0|A worn and delapidated sign.|an aged sign|This sign has weathered the ages.  Its lettering is worn and faded from time and the elements.|Adventurers beware!  The Universe is highly unstable.  Temporal and Spacial anamolies may appear at any time.|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null|null";
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile));
				writer.write(csvData);
				writer.close();
			} catch (IOException e) {
				System.out.println("Error writing " + csvFile + " file: " + e.getMessage());
			}
		}







		int playerLastRoom = 0;

		// START UP THE GAME
		buildCurrentRoom(playerLastRoom);
		commandAnalyzer("look");




	}





	public static void test() {
		System.out.println(World[0][1]);
		System.out.println(Mobs[0][1]);
		System.out.println(Objects[0][1]);
	}

	private static void commandAnalyzer(String st) {
		String tempString = st;

		//	String[] temparr = tempString.split(" ");

		switch (tempString) {

		case "score":
			displayPlayerScore();
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "equipment":
			displayPlayerEQ();
			break;
		case "time":
			displayCurrentTime();
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "north":
			if ("north".equalsIgnoreCase(kinput) && Integer.parseInt(exN.getRoomNum()) != -1) {
				int t = Integer.parseInt(exN.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "north east":
			if ("north east".equalsIgnoreCase(kinput) && Integer.parseInt(exNE.getRoomNum()) != -1) {
				int t = Integer.parseInt(exNE.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "east":
			if ("east".equalsIgnoreCase(kinput) && Integer.parseInt(exE.getRoomNum()) != -1) {
				int t = Integer.parseInt(exE.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "south east":
			if ("south east".equalsIgnoreCase(kinput) && Integer.parseInt(exSE.getRoomNum()) != -1) {
				int t = Integer.parseInt(exSE.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "south":
			if ("south".equalsIgnoreCase(kinput) && Integer.parseInt(exS.getRoomNum()) != -1) {
				int t = Integer.parseInt(exS.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "south west":
			if ("south west".equalsIgnoreCase(kinput) && Integer.parseInt(exSW.getRoomNum()) != -1) {
				int t = Integer.parseInt(exSW.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "west":
			if ("west".equalsIgnoreCase(kinput) && Integer.parseInt(exW.getRoomNum()) != -1) {
				int t = Integer.parseInt(exW.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "north west":
			if ("north west".equalsIgnoreCase(kinput) && Integer.parseInt(exNW.getRoomNum()) != -1) {
				int t = Integer.parseInt(exNW.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "up":
			if ("up".equalsIgnoreCase(kinput) && Integer.parseInt(exU.getRoomNum()) != -1) {
				int t = Integer.parseInt(exU.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "down":
			if ("down".equalsIgnoreCase(kinput) && Integer.parseInt(exD.getRoomNum()) != -1) {
				int t = Integer.parseInt(exD.getRoomNum());
				buildCurrentRoom(t);
				look("null");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
			else { 
				System.out.println("You can't go that way.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);

			}
			break;
		case "look":
			look("null");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look north":
			look("north");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		case "look north east":
			look("north east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look east":
			look("east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look south east":
			look("south east");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look south":
			look("south");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look south west":
			look("south west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look west":
			look("west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look north west":
			look("north west");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look up":
			look("up");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;
		case "look down":
			look("down");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
			break;	
		case "camp":
			if (Integer.parseInt(newRoom.getCamp()) == 1) { System.out.println("You pitch a tent and lie down beside a small fire, lit to ward off the cold.");
			System.exit(0); }
			else {
				System.out.println("You may not make camp here.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
			}
			break;
		case "exit":
			System.out.println("Goodbye.");
			System.exit(0);
			break;

		case "rent":
			if (Integer.parseInt(newRoom.getRent()) == 1) {
				System.out.println("The innkeeper glances at you with indifference and tosses out a room key.");
				System.exit(0);

			}
			else {
				System.out.println("You must find an inn to rent.");
				kinput = input.nextLine();
				commandAnalyzer(kinput);
				break;
			}
		default:
			System.out.println("Huh?");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
	}

	public static void displayPlayerScore() {
		newPlayer.returnPlayerScore();
	}

	public static void displayPlayerEQ() {
		newPlayer.returnPlayerInfo();
	}

	public static void look(String l) {

		if ("null".equalsIgnoreCase(l)) {
			newRoom.returnRoomInfo();


			if (tmobsarr[0]==null) {	} 
			else { System.out.println("You see " + tmob0.getMobShortDesc() + "."); }
			if (tmobsarr[1]==null) {	} 
			else { System.out.println("You see " + tmob1.getMobShortDesc() + "."); }
			if (tmobsarr[2]==null) {	} 
			else { System.out.println("You see " + tmob2.getMobShortDesc() + "."); }
			if (tmobsarr[3]==null) {	} 
			else { System.out.println("You see " + tmob3.getMobShortDesc() + "."); }
			if (tmobsarr[4]==null) {	} 
			else { System.out.println("You see " + tmob4.getMobShortDesc() + "."); }
			if (tmobsarr[5]==null) {	} 
			else { System.out.println("You see " + tmob5.getMobShortDesc() + "."); }
			if ((tmobsarr[0]==null) && (tmobsarr[1]==null) && (tmobsarr[2]==null) && (tmobsarr[3]==null) && (tmobsarr[4]==null) && (tmobsarr[5]==null)) {
				System.out.println("You do not see any creatures nearby.");
			}

			if ("null".equalsIgnoreCase(tobjsarr[0])) {	} 
			else { System.out.println("You see " + tobj0.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[1])) {	} 
			else { System.out.println("You see " + tobj1.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[2])) {	} 
			else { System.out.println("You see " + tobj2.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[3])) {	} 
			else { System.out.println("You see " + tobj3.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[4])) {	} 
			else { System.out.println("You see " + tobj4.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[5])) {	} 
			else { System.out.println("You see " + tobj5.getObjShortDesc() + "."); }
			if ("null".equalsIgnoreCase(tobjsarr[0]) && "null".equalsIgnoreCase(tobjsarr[1]) && "null".equalsIgnoreCase(tobjsarr[2]) && "null".equalsIgnoreCase(tobjsarr[3]) && "null".equalsIgnoreCase(tobjsarr[4]) && "null".equalsIgnoreCase(tobjsarr[5])) {
				System.out.println("You do not see anything of note.");
			}	



			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}


		else if ("north".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitN()) != -1) {
			System.out.println("You see " + exN.getRoomShortDesc() + ".");
			if (exN.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitN()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitNE()) != -1) {
			System.out.println("You see " + exNE.getRoomShortDesc() + ".");
			if (exNE.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitE()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitE()) != -1) {
			System.out.println("You see " + exE.getRoomShortDesc() + ".");
			if (exE.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitE()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("south east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitSE()) != -1) {
			System.out.println("You see " + exSE.getRoomShortDesc() + ".");
			if (exSE.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south east".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitSE()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("south".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitS()) != -1) {
			System.out.println("You see " + exS.getRoomShortDesc() + ".");
			if (exS.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitS()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("south west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitSW()) != -1) {
			System.out.println("You see " + exSW.getRoomShortDesc() + ".");
			if (exSW.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("south west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitSW()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);

		}
		else if ("west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitW()) != -1) {
			System.out.println("You see " + exW.getRoomShortDesc() + ".");
			if (exW.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitW()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("north west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitNW()) != -1) {
			System.out.println("You see " + exNW.getRoomShortDesc() + ".");
			if (exNW.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("north west".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitNW()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("up".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitU()) != -1) {
			System.out.println("You see " + exU.getRoomShortDesc() + ".");
			if (exU.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("up".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitU()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
		else if ("down".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitD()) != -1) {
			System.out.println("You see " + exD.getRoomShortDesc() + ".");
			if (exD.getMobsInRoom() != null) {
				System.out.println("You see some shadows stirring in the other room.");
			}
			kinput = input.nextLine();
			commandAnalyzer(kinput);
		}
		else if ("down".equalsIgnoreCase(l) && Integer.parseInt(newRoom.getExitD()) == -1) {
			System.out.println("You cannot see anything that way.");
			kinput = input.nextLine();
			commandAnalyzer(kinput);		
		}
	}

	@SuppressWarnings("all")
	public static void buildCurrentRoom(int i) {


		// build world/rooms arr
		int currentRoomNum = i;
		String i2 = String.valueOf(i);

		// create new/current room
		//		room newRoom = new room();
		newRoom.setRoomNum(i2);
		int enumb = Integer.parseInt( newRoom.getRoomNum());
		newRoom.setRoomName(World[i][1]);
		newRoom.setRoomShortDesc(World[i][2]);
		newRoom.setRoomLongDesc(World[i][3]);
		newRoom.setExitN(World[enumb][4]);
		newRoom.setExitNE(World[i][4]);
		newRoom.setExitNE( World[i][5]);
		newRoom.setExitE( World[i][6]);
		newRoom.setExitSE( World[i][7]);
		newRoom.setExitS( World[i][8]);
		newRoom.setExitSW( World[i][9]);
		newRoom.setExitW( World[i][10]);
		newRoom.setExitNW( World[i][11]);
		newRoom.setExitU( World[i][12]);
		newRoom.setExitD( World[i][13]);


		tmobsarr[0] = "null";
		tmobsarr[1] = "null";
		tmobsarr[2] = "null";
		tmobsarr[3] = "null";
		tmobsarr[4] = "null";
		tmobsarr[5] = "null";

		tobjsarr[0] = "null";
		tobjsarr[1] = "null";
		tobjsarr[2] = "null";
		tobjsarr[3] = "null";
		tobjsarr[4] = "null";
		tobjsarr[5] = "null";


		String[] array = new String[6];
		array[0] = "stuff";
		if(array[1] == null)
		{
			System.out.println("Array test");
			System.out.println(array[0].toString());
		}
		else
		{
			System.out.println("not null");
		}


		String tobjsar = World[i][14].toString();
		if(tobjsar == null) {System.out.println("No Objects in Room."); }
		{
			tobjsar = tobjsar.replace("[", "");
			tobjsar = tobjsar.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			newRoom.setObjsInRoom(tobjsarr);
		}
		String arg = World[i][14].toString();
		String tstring = arg.replace("[", "");
		tstring = tstring.replace("]", "");
		tstring = tstring.replace(",", "");
		tmobsarr = tstring.split("\\s+");
		newRoom.setMobsInRoom(tmobsarr);


		/*
		// testing mob array
		System.out.println(Mobs[0][1]);
		System.out.println("Mobs: " + Arrays.toString(newRoom.getMobsInRoom()));
		 */

		/*
		// testing obj array
		System.out.println(Objects[0][1]);
		System.out.println("Objects: " + Arrays.toString(newRoom.getObjsInRoom()));	
		 */


		newRoom.setLit( World[currentRoomNum][16].toString());
		newRoom.setCamp( World[currentRoomNum][17].toString());
		newRoom.setRent( World[currentRoomNum][18].toString());
		newRoom.setInside( World[currentRoomNum][19].toString());

		// create rooms for various directions

		int eN = Integer.parseInt( newRoom.getExitN());
		int eNE = Integer.parseInt(newRoom.getExitNE());
		int eE = Integer.parseInt(newRoom.getExitE());
		int eSE = Integer.parseInt(newRoom.getExitSE());
		int eS =Integer.parseInt( newRoom.getExitS());
		int eSW = Integer.parseInt(newRoom.getExitSW());
		int eW = Integer.parseInt(newRoom.getExitW());
		int eNW = Integer.parseInt(newRoom.getExitNW());
		int eU = Integer.parseInt(newRoom.getExitU());
		int eD = Integer.parseInt(newRoom.getExitD());


		if (-1 != eN) {
			//	int t = Integer.parseInt(World[enumb][4]);
			exN.setRoomNum(World[enumb][4]);
		}
		if (-1 != eNE) {
			//	int t = Integer.parseInt(World[enumb][5]);
			exNE.setRoomNum(World[enumb][5]);
		}
		if (-1 != eE) {
			//	int t = Integer.parseInt(World[enumb][6]);
			exE.setRoomNum(World[enumb][6]);
		}
		if (-1 != eSE) {
			//	int t = Integer.parseInt(World[enumb][7]);
			exSE.setRoomNum(World[enumb][7]);
		}
		if (-1 != eS) {
			//	int t = Integer.parseInt(World[enumb][8]);
			exS.setRoomNum(World[enumb][8]);
		}
		if (-1 != eSW) {
			//	int t = Integer.parseInt(World[enumb][9]);
			exSW.setRoomNum(World[enumb][9]);
		}
		if (-1 != eW) {
			//	int t = Integer.parseInt(World[enumb][10]);
			exW.setRoomNum(World[enumb][10]);
		}
		if (-1 != eNW) {
			//	int t = Integer.parseInt(World[enumb][11]);
			exNW.setRoomNum(World[enumb][11]);
		}
		if (-1 != eU) {
			//	int t = Integer.parseInt(World[enumb][12]);
			exU.setRoomNum(World[enumb][12]);
		}
		if (-1 != eD) {
			//	int t = Integer.parseInt(World[enumb][13]);
			exD.setRoomNum(World[enumb][13]);
		}
		if (-1 != eN) {
			exN.setRoomShortDesc(World[eN][2]);
		}
		if (-1 != eNE) {
			exNE.setRoomShortDesc(World[eNE][2]);
		}
		if (-1 != eE) {
			exE.setRoomShortDesc(World[eE][2]);
		}
		if (-1 != eSE) {
			exSE.setRoomShortDesc(World[eSE][2]);
		}
		if (-1 != eS) {
			exS.setRoomShortDesc(World[eS][2]);
		}
		if (-1 != eSW) {
			exSW.setRoomShortDesc(World[eSW][2]);
		}
		if (-1 != eW) {
			exW.setRoomShortDesc(World[eW][2]);
		}
		if (-1 != eNW) {
			exNW.setRoomShortDesc(World[eNW][2]);
		}
		if (-1 != eU) {
			exU.setRoomShortDesc(World[eU][2]);
		}
		if (-1 != eD) {
			exD.setRoomShortDesc(World[eD][2]);
		}



		/*

		// create the mobs for the room

		 */

		String tmobsar = new String();
		String t = "null";
		int t0;
		int t1;
		int t2;
		int t3;
		int t4;
		int t5;
		if (tmobsarr[0]==null) { System.out.println("No Mob 0"); }
		else {
			t0 = Integer.parseInt(tmobsarr[0]); 
			tmob0.setMobNum(t0);
			tmob0.setMobName(Mobs[t0][1]);
			tmob0.setMobShortDesc(Mobs[t0][2]);
			tmob0.setMobLongDesc(Mobs[t0][3]);
			t = Mobs[t0][4];

			if (!"null".equalsIgnoreCase(t)) { 
				//	t = t.replace("[", "");
				//	t = t.replace("]", ""); }
				{ System.out.println("Mob"); }
				tmobsar = tmobsar.replace(",", "");
				tmobsarr = tmobsar.split("\\s+");
				tmob0.setMobKeyWords(tmobsarr);
				if (!"null".equalsIgnoreCase(Mobs[t0][5])) { tmob0.setMobHP(Integer.parseInt(Mobs[t0][5])); }	{ tmob0.setMobHP(100); } // mob hp
				if (!"null".equalsIgnoreCase(Mobs[t0][6])) { tmob0.setMobMP(Integer.parseInt(Mobs[t0][6])); }{tmob0.setMobMP(100); } // mob mp			
				if (!"null".equalsIgnoreCase(Mobs[t0][7])) { tmob0.setMobLvl(Integer.parseInt(Mobs[t0][7])); }{tmob0.setMobLvl(1); }  // mob level
				if (!"null".equalsIgnoreCase(Mobs[t0][8])) { tmob0.setStam(Integer.parseInt(Mobs[t0][8])); }{tmob0.setStam(10); }  // mob stam
				if (!"null".equalsIgnoreCase(Mobs[t0][9])) { tmob0.setStr(Integer.parseInt(Mobs[t0][9])); }{tmob0.setStr(10); } // mob str
				if (!"null".equalsIgnoreCase(Mobs[t0][10])) { tmob0.setIntel(Integer.parseInt(Mobs[t0][10])); }{tmob0.setIntel(1); } // mob int
				if (!"null".equalsIgnoreCase(Mobs[t0][11])) { tmob0.setAgility(Integer.parseInt(Mobs[t0][11])); }{tmob0.setAgility(10); } // mob agi
				tmob0.setHeadSlot(Mobs[t0][12]); // head slot
				tmob0.setNeckSlot(Mobs[t0][13]);  // neck slot
				tmob0.setShoulderSlot(Mobs[t0][14]); // shoulder slot
				tmob0.setChestSlot(Mobs[t0][15]); // chest
				tmob0.setWristSlot(Mobs[t0][16]); // wrist
				tmob0.setHandSlot(Mobs[t0][17]); // hand
				tmob0.setFinger1(Mobs[t0][18]); // finger 1
				tmob0.setFinger1(Mobs[t0][19]); // finger 2
				tmob0.setFinger1(Mobs[t0][20]); // leg
				tmob0.setFinger1(Mobs[t0][21]); // trinket 1
				tmob0.setFinger1(Mobs[t0][22]); // trinket 2
				tmob0.setFinger1(Mobs[t0][23]); // weapon 1
				tmob0.setFinger1(Mobs[t0][24]); // weapon/shield
				tmob0.setFinger1(Mobs[t0][25]); // race
				tmob0.setFinger1(Mobs[t0][26]); // subrace
				tmob0.setFinger1(Mobs[t0][27]); // rank
				tmob0.setFinger1(Mobs[t0][28]); // xp val
				if(!"null".equalsIgnoreCase(Mobs[t0][29])) { tmob0.setmobIsAlive(Integer.parseInt(Mobs[t0][29]));} { tmob0.setmobIsAlive(1);} // is alive
				tmob0.setMobGender(Mobs[t0][30]); // mob gender
			}
		}


		if (tmobsarr[1]!=null) {
			t1 = Integer.parseInt(tmobsarr[1]);
			tmob1.setMobNum(t1);
			tmob1.setMobName(Mobs[t1][1]);
			tmob1.setMobShortDesc(Mobs[t1][2]);
			tmob1.setMobLongDesc(Mobs[t1][3]);
			t = Mobs[t1][4];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tmobsar = tmobsar.replace(",", "");
			tmobsarr = tmobsar.split("\\s+");
			tmob1.setMobKeyWords(tmobsarr);
			if (!"null".equalsIgnoreCase(Mobs[t1][5])) { tmob1.setMobHP(Integer.parseInt(Mobs[t1][5])); }	{ tmob1.setMobHP(100); } // mob hp
			if (!"null".equalsIgnoreCase(Mobs[t1][6])) { tmob1.setMobMP(Integer.parseInt(Mobs[t1][6])); }{tmob1.setMobMP(100); } // mob mp			
			if (!"null".equalsIgnoreCase(Mobs[t1][7])) { tmob1.setMobLvl(Integer.parseInt(Mobs[t1][7])); }{tmob1.setMobLvl(1); }  // mob level
			if (!"null".equalsIgnoreCase(Mobs[t1][8])) { tmob1.setStam(Integer.parseInt(Mobs[t1][8])); }{tmob1.setStam(10); }  // mob stam
			if (!"null".equalsIgnoreCase(Mobs[t1][9])) { tmob1.setStr(Integer.parseInt(Mobs[t1][9])); }{tmob1.setStr(10); } // mob str
			if (!"null".equalsIgnoreCase(Mobs[t1][10])) { tmob1.setIntel(Integer.parseInt(Mobs[t1][10])); }{tmob1.setIntel(1); } // mob int
			if (!"null".equalsIgnoreCase(Mobs[t1][11])) { tmob1.setAgility(Integer.parseInt(Mobs[t1][11])); }{tmob1.setAgility(10); } // mob agi
			tmob1.setHeadSlot(Mobs[t1][12]); // head slot
			tmob1.setNeckSlot(Mobs[t1][13]);  // neck slot
			tmob1.setShoulderSlot(Mobs[t1][14]); // shoulder slot
			tmob1.setChestSlot(Mobs[t1][15]); // chest
			tmob1.setWristSlot(Mobs[t1][16]); // wrist
			tmob1.setHandSlot(Mobs[t1][17]); // hand
			tmob1.setFinger1(Mobs[t1][18]); // finger 1
			tmob1.setFinger1(Mobs[t1][19]); // finger 2
			tmob1.setFinger1(Mobs[t1][20]); // leg
			tmob1.setFinger1(Mobs[t1][21]); // trinket 1
			tmob1.setFinger1(Mobs[t1][22]); // trinket 2
			tmob1.setFinger1(Mobs[t1][23]); // weapon 1
			tmob1.setFinger1(Mobs[t1][24]); // weapon/shield
			tmob1.setFinger1(Mobs[t1][25]); // race
			tmob1.setFinger1(Mobs[t1][26]); // subrace
			tmob1.setFinger1(Mobs[t1][27]); // rank
			tmob1.setFinger1(Mobs[t1][28]); // xp val
			if(!"null".equalsIgnoreCase(Mobs[t1][29])) { tmob1.setmobIsAlive(Integer.parseInt(Mobs[t1][29]));} { tmob1.setmobIsAlive(1);} // is alive
			tmob1.setMobGender(Mobs[t1][30]); // mob gender
		}
		if ((tmobsarr[2]!=null)) {
			t2 = Integer.parseInt(tmobsarr[2]);
			tmob2.setMobNum(t2);
			tmob2.setMobName(Mobs[t2][1]);
			tmob2.setMobShortDesc(Mobs[t2][2]);
			tmob2.setMobLongDesc(Mobs[t2][3]);
			t = Mobs[t2][4];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tmobsar = tmobsar.replace(",", "");
			tmobsarr = tmobsar.split("\\s+");
			tmob2.setMobKeyWords(tmobsarr);
			if (!"null".equalsIgnoreCase(Mobs[t2][5])) { tmob2.setMobHP(Integer.parseInt(Mobs[t2][5])); }	{ tmob2.setMobHP(100); } // mob hp
			if (!"null".equalsIgnoreCase(Mobs[t2][6])) { tmob2.setMobMP(Integer.parseInt(Mobs[t2][6])); }{tmob2.setMobMP(100); } // mob mp			
			if (!"null".equalsIgnoreCase(Mobs[t2][7])) { tmob2.setMobLvl(Integer.parseInt(Mobs[t2][7])); }{tmob2.setMobLvl(1); }  // mob level
			if (!"null".equalsIgnoreCase(Mobs[t2][8])) { tmob2.setStam(Integer.parseInt(Mobs[t2][8])); }{tmob2.setStam(10); }  // mob stam
			if (!"null".equalsIgnoreCase(Mobs[t2][9])) { tmob2.setStr(Integer.parseInt(Mobs[t2][9])); }{tmob2.setStr(10); } // mob str
			if (!"null".equalsIgnoreCase(Mobs[t2][10])) { tmob2.setIntel(Integer.parseInt(Mobs[t2][10])); }{tmob2.setIntel(1); } // mob int
			if (!"null".equalsIgnoreCase(Mobs[t2][11])) { tmob2.setAgility(Integer.parseInt(Mobs[t2][11])); }{tmob2.setAgility(10); } // mob agi
			tmob2.setHeadSlot(Mobs[t2][12]); // head slot
			tmob2.setNeckSlot(Mobs[t2][13]);  // neck slot
			tmob2.setShoulderSlot(Mobs[t2][14]); // shoulder slot
			tmob2.setChestSlot(Mobs[t2][15]); // chest
			tmob2.setWristSlot(Mobs[t2][16]); // wrist
			tmob2.setHandSlot(Mobs[t2][17]); // hand
			tmob2.setFinger1(Mobs[t2][18]); // finger 1
			tmob2.setFinger1(Mobs[t2][19]); // finger 2
			tmob2.setFinger1(Mobs[t2][20]); // leg
			tmob2.setFinger1(Mobs[t2][21]); // trinket 1
			tmob2.setFinger1(Mobs[t2][22]); // trinket 2
			tmob2.setFinger1(Mobs[t2][23]); // weapon 1
			tmob2.setFinger1(Mobs[t2][24]); // weapon/shield
			tmob2.setFinger1(Mobs[t2][25]); // race
			tmob2.setFinger1(Mobs[t2][26]); // subrace
			tmob2.setFinger1(Mobs[t2][27]); // rank
			tmob2.setFinger1(Mobs[t2][28]); // xp val
			if(!"null".equalsIgnoreCase(Mobs[t2][29])) { tmob2.setmobIsAlive(Integer.parseInt(Mobs[t2][29]));} { tmob2.setmobIsAlive(1);} // is alive
			tmob2.setMobGender(Mobs[t2][30]); // mob gender
		}
		if ((tmobsarr[3]!=null)) {
			t3 = Integer.parseInt(tmobsarr[3]);
			tmob3.setMobNum(t3);
			tmob3.setMobName(Mobs[t3][1]);
			tmob3.setMobShortDesc(Mobs[t3][2]);
			tmob3.setMobLongDesc(Mobs[t3][3]);
			t = Mobs[t3][4];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tmobsar = tmobsar.replace(",", "");
			tmobsarr = tmobsar.split("\\s+");
			tmob3.setMobKeyWords(tmobsarr);
			if (!"null".equalsIgnoreCase(Mobs[t3][5])) { tmob3.setMobHP(Integer.parseInt(Mobs[t3][5])); }	{ tmob3.setMobHP(100); } // mob hp
			if (!"null".equalsIgnoreCase(Mobs[t3][6])) { tmob3.setMobMP(Integer.parseInt(Mobs[t3][6])); }{tmob3.setMobMP(100); } // mob mp			
			if (!"null".equalsIgnoreCase(Mobs[t3][7])) { tmob3.setMobLvl(Integer.parseInt(Mobs[t3][7])); }{tmob3.setMobLvl(1); }  // mob level
			if (!"null".equalsIgnoreCase(Mobs[t3][8])) { tmob3.setStam(Integer.parseInt(Mobs[t3][8])); }{tmob3.setStam(10); }  // mob stam
			if (!"null".equalsIgnoreCase(Mobs[t3][9])) { tmob3.setStr(Integer.parseInt(Mobs[t3][9])); }{tmob3.setStr(10); } // mob str
			if (!"null".equalsIgnoreCase(Mobs[t3][10])) { tmob3.setIntel(Integer.parseInt(Mobs[t3][10])); }{tmob3.setIntel(1); } // mob int
			if (!"null".equalsIgnoreCase(Mobs[t3][11])) { tmob3.setAgility(Integer.parseInt(Mobs[t3][11])); }{tmob3.setAgility(10); } // mob agi
			tmob3.setHeadSlot(Mobs[t3][12]); // head slot
			tmob3.setNeckSlot(Mobs[t3][13]);  // neck slot
			tmob3.setShoulderSlot(Mobs[t3][14]); // shoulder slot
			tmob3.setChestSlot(Mobs[t3][15]); // chest
			tmob3.setWristSlot(Mobs[t3][16]); // wrist
			tmob3.setHandSlot(Mobs[t3][17]); // hand
			tmob3.setFinger1(Mobs[t3][18]); // finger 1
			tmob3.setFinger1(Mobs[t3][19]); // finger 2
			tmob3.setFinger1(Mobs[t3][20]); // leg
			tmob3.setFinger1(Mobs[t3][21]); // trinket 1
			tmob3.setFinger1(Mobs[t3][22]); // trinket 2
			tmob3.setFinger1(Mobs[t3][23]); // weapon 1
			tmob3.setFinger1(Mobs[t3][24]); // weapon/shield
			tmob0.setFinger1(Mobs[t3][25]); // race
			tmob3.setFinger1(Mobs[t3][26]); // subrace
			tmob3.setFinger1(Mobs[t3][27]); // rank
			tmob3.setFinger1(Mobs[t3][28]); // xp val
			if(!"null".equalsIgnoreCase(Mobs[t3][29])) { tmob3.setmobIsAlive(Integer.parseInt(Mobs[t3][29]));} { tmob3.setmobIsAlive(1);} // is alive
			tmob3.setMobGender(Mobs[t3][30]); // mob gender
		}
		if (tmobsarr[4]!=null) {
			t4 = Integer.parseInt(tmobsarr[4]);
			tmob4.setMobNum(t4);
			tmob4.setMobName(Mobs[t4][1]);
			tmob4.setMobShortDesc(Mobs[t4][2]);
			tmob4.setMobLongDesc(Mobs[t4][3]);
			t = Mobs[t4][4];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tmobsar = tmobsar.replace(",", "");
			tmobsarr = tmobsar.split("\\s+");
			tmob4.setMobKeyWords(tmobsarr);
			if (!"null".equalsIgnoreCase(Mobs[t4][5])) { tmob4.setMobHP(Integer.parseInt(Mobs[t4][5])); }	{ tmob4.setMobHP(100); } // mob hp
			if (!"null".equalsIgnoreCase(Mobs[t4][6])) { tmob4.setMobMP(Integer.parseInt(Mobs[t4][6])); }{tmob4.setMobMP(100); } // mob mp			
			if (!"null".equalsIgnoreCase(Mobs[t4][7])) { tmob4.setMobLvl(Integer.parseInt(Mobs[t4][7])); }{tmob4.setMobLvl(1); }  // mob level
			if (!"null".equalsIgnoreCase(Mobs[t4][8])) { tmob4.setStam(Integer.parseInt(Mobs[t4][8])); }{tmob4.setStam(10); }  // mob stam
			if (!"null".equalsIgnoreCase(Mobs[t4][9])) { tmob4.setStr(Integer.parseInt(Mobs[t4][9])); }{tmob4.setStr(10); } // mob str
			if (!"null".equalsIgnoreCase(Mobs[t4][10])) { tmob4.setIntel(Integer.parseInt(Mobs[t4][10])); }{tmob4.setIntel(1); } // mob int
			if (!"null".equalsIgnoreCase(Mobs[t4][11])) { tmob4.setAgility(Integer.parseInt(Mobs[t4][11])); }{tmob4.setAgility(10); } // mob agi
			tmob4.setHeadSlot(Mobs[t4][12]); // head slot
			tmob4.setNeckSlot(Mobs[t4][13]);  // neck slot
			tmob4.setShoulderSlot(Mobs[t4][14]); // shoulder slot
			tmob4.setChestSlot(Mobs[t4][15]); // chest
			tmob4.setWristSlot(Mobs[t4][16]); // wrist
			tmob4.setHandSlot(Mobs[t4][17]); // hand
			tmob4.setFinger1(Mobs[t4][18]); // finger 1
			tmob4.setFinger1(Mobs[t4][19]); // finger 2
			tmob4.setFinger1(Mobs[t4][20]); // leg
			tmob4.setFinger1(Mobs[t4][21]); // trinket 1
			tmob4.setFinger1(Mobs[t4][22]); // trinket 2
			tmob4.setFinger1(Mobs[t4][23]); // weapon 1
			tmob4.setFinger1(Mobs[t4][24]); // weapon/shield
			tmob4.setFinger1(Mobs[t4][25]); // race
			tmob4.setFinger1(Mobs[t4][26]); // subrace
			tmob4.setFinger1(Mobs[t4][27]); // rank
			tmob4.setFinger1(Mobs[t4][28]); // xp val
			if(!"null".equalsIgnoreCase(Mobs[t4][29])) { tmob4.setmobIsAlive(Integer.parseInt(Mobs[t4][29]));} { tmob4.setmobIsAlive(1);} // is alive
			tmob4.setMobGender(Mobs[t4][30]); // mob gender
		}
		if (tmobsarr[5]!=null) {
			t5 = Integer.parseInt(tmobsarr[5]);
			tmob5.setMobNum(t5);
			tmob5.setMobName(Mobs[t5][1]);
			tmob5.setMobShortDesc(Mobs[t5][2]);
			tmob5.setMobLongDesc(Mobs[t5][3]);
			t = Mobs[t5][4];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tmobsar = tmobsar.replace(",", "");
			tmobsarr = tmobsar.split("\\s+");
			tmob5.setMobKeyWords(tmobsarr);
			if (!"null".equalsIgnoreCase(Mobs[t5][5])) { tmob5.setMobHP(Integer.parseInt(Mobs[t5][5])); }	{ tmob5.setMobHP(100); } // mob hp
			if (!"null".equalsIgnoreCase(Mobs[t5][6])) { tmob5.setMobMP(Integer.parseInt(Mobs[t5][6])); }{tmob5.setMobMP(100); } // mob mp			
			if (!"null".equalsIgnoreCase(Mobs[t5][7])) { tmob5.setMobLvl(Integer.parseInt(Mobs[t5][7])); }{tmob5.setMobLvl(1); }  // mob level
			if (!"null".equalsIgnoreCase(Mobs[t5][8])) { tmob5.setStam(Integer.parseInt(Mobs[t5][8])); }{tmob5.setStam(10); }  // mob stam
			if (!"null".equalsIgnoreCase(Mobs[t5][9])) { tmob5.setStr(Integer.parseInt(Mobs[t5][9])); }{tmob5.setStr(10); } // mob str
			if (!"null".equalsIgnoreCase(Mobs[t5][10])) { tmob5.setIntel(Integer.parseInt(Mobs[t5][10])); }{tmob5.setIntel(1); } // mob int
			if (!"null".equalsIgnoreCase(Mobs[t5][11])) { tmob5.setAgility(Integer.parseInt(Mobs[t5][11])); }{tmob5.setAgility(10); } // mob agi
			tmob5.setHeadSlot(Mobs[t5][12]); // head slot
			tmob5.setNeckSlot(Mobs[t5][13]);  // neck slot
			tmob5.setShoulderSlot(Mobs[t5][14]); // shoulder slot
			tmob5.setChestSlot(Mobs[t5][15]); // chest
			tmob5.setWristSlot(Mobs[t5][16]); // wrist
			tmob5.setHandSlot(Mobs[t5][17]); // hand
			tmob5.setFinger1(Mobs[t5][18]); // finger 1
			tmob5.setFinger1(Mobs[t5][19]); // finger 2
			tmob5.setFinger1(Mobs[t5][20]); // leg
			tmob5.setFinger1(Mobs[t5][21]); // trinket 1
			tmob5.setFinger1(Mobs[t5][22]); // trinket 2
			tmob5.setFinger1(Mobs[t5][23]); // weapon 1
			tmob5.setFinger1(Mobs[t5][24]); // weapon/shield
			tmob5.setFinger1(Mobs[t5][25]); // race
			tmob5.setFinger1(Mobs[t5][26]); // subrace
			tmob5.setFinger1(Mobs[t5][27]); // rank
			tmob5.setFinger1(Mobs[t5][28]); // xp val
			if(!"null".equalsIgnoreCase(Mobs[t5][29])) { tmob5.setmobIsAlive(Integer.parseInt(Mobs[t5][29]));} { tmob5.setmobIsAlive(1);} // is alive
			tmob5.setMobGender(Mobs[t5][30]); // mob gender

		}




		// create the objs for the room
		tobjsar = Arrays.toString(newRoom.getObjsInRoom());
		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");
		tobjsar = tobjsar.replace(",", "");
		String[] tobjsarr = tobjsar.split("\\s+");
		if (tobjsarr[0]!=null) {
			t0 = Integer.parseInt(tobjsarr[0]);  
			tobj0.setObjNum(t0); // obj #
			tobj0.setObjName(Objects[t0][1]); // obj Name
			tobj0.setObjShortDesc(Objects[t0][2]); // obj short desc
			tobj0.setObjLongDesc(Objects[t0][3]); // obj long desc
			tobj0.setObjExtDesc(Objects[t0][4]); // obj ext desc
			t = Objects[t0][5];
			//			t = t.replace("[", "");
			//			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj0.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t0][6])) {tobj0.setAddStam(Objects[t0][6]);}{tobj0.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t0][7])) {tobj0.setAddStr(Objects[t0][7]);}{tobj0.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t0][8])) {tobj0.setAddInt(Objects[t0][8]);}{tobj0.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t0][9])) {tobj0.setAddAgi(Objects[t0][9]);}{tobj0.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t0][10])) {tobj0.setAddHP(Objects[t0][10]);}{tobj0.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t0][11])) {tobj0.setAddMP(Objects[t0][11]);}{tobj0.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t0][12])) {tobj0.setDurability(Objects[t0][12]);}{tobj0.setDurability("0");} // durability
			if (!"null".equalsIgnoreCase(Objects[t0][13])) {tobj0.setTakeable(Objects[t0][13]);}{tobj0.setTakeable("0");}  // takeable
			t = Objects[t0][14];
			//			t = t.replace("[", "");
			//			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			//			tobj0.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (tobjsarr[1]!=null) {
			t1 = Integer.parseInt(tobjsarr[1]);  
			tobj1.setObjNum(t1); // obj #
			tobj1.setObjName(Objects[t1][1]); // obj Name
			tobj1.setObjShortDesc(Objects[t1][2]); // obj short desc
			tobj1.setObjLongDesc(Objects[t1][3]); // obj long desc
			tobj1.setObjExtDesc(Objects[t1][4]); // obj ext desc
			t = Objects[t1][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj1.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t1][6])) {tobj1.setAddStam(Objects[t1][6]);}{tobj1.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t1][7])) {tobj1.setAddStr(Objects[t1][7]);}{tobj1.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t1][8])) {tobj1.setAddInt(Objects[t1][8]);}{tobj1.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t1][9])) {tobj1.setAddAgi(Objects[t1][9]);}{tobj1.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t1][10])) {tobj1.setAddHP(Objects[t1][10]);}{tobj1.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t1][11])) {tobj1.setAddMP(Objects[t1][11]);}{tobj1.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t1][12])) {tobj1.setDurability(Objects[t1][12]);}{tobj1.setDurability("0");} // durability
			if (!"null".equalsIgnoreCase(Objects[t1][13])) {tobj1.setTakeable(Objects[t1][13]);}{tobj1.setTakeable("0");}  // takeable
			t = Objects[t1][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			//			tobjsarr = tobjsar.split("\\s+");
			//			tobj1.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (tobjsarr[2]!=null) {
			t2 = Integer.parseInt(tobjsarr[2]);  
			tobj2.setObjNum(t2); // obj #
			tobj2.setObjName(Objects[t2][1]); // obj Name
			tobj2.setObjShortDesc(Objects[t2][2]); // obj short desc
			tobj2.setObjLongDesc(Objects[t2][3]); // obj long desc
			tobj2.setObjExtDesc(Objects[t2][4]); // obj ext desc
			t = Objects[t2][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj2.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t2][6])) {tobj2.setAddStam(Objects[t2][6]);}{tobj2.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t2][7])) {tobj2.setAddStr(Objects[t2][7]);}{tobj2.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t2][8])) {tobj2.setAddInt(Objects[t2][8]);}{tobj2.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t2][9])) {tobj2.setAddAgi(Objects[t2][9]);}{tobj2.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t2][10])) {tobj2.setAddHP(Objects[t2][10]);}{tobj2.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t2][11])) {tobj2.setAddMP(Objects[t2][11]);}{tobj2.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t2][12])) {tobj2.setDurability(Objects[t2][12]);}{tobj2.setDurability("0");} // durability
			if (!"null".equalsIgnoreCase(Objects[t2][13])) {tobj2.setTakeable(Objects[t2][13]);}{tobj2.setTakeable("0");}  // takeable
			t = Objects[t2][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			//			tobj2.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (tobjsarr[3]!=null) {
			t3 = Integer.parseInt(tobjsarr[3]);  
			tobj3.setObjNum(t3); // obj #
			tobj3.setObjName(Objects[t3][1]); // obj Name
			tobj3.setObjShortDesc(Objects[t3][2]); // obj short desc
			tobj3.setObjLongDesc(Objects[t3][3]); // obj long desc
			tobj3.setObjExtDesc(Objects[t3][4]); // obj ext desc
			t = Objects[t3][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj3.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t3][6])) {tobj3.setAddStam(Objects[t3][6]);}{tobj3.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t3][7])) {tobj3.setAddStr(Objects[t3][7]);}{tobj3.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t3][8])) {tobj3.setAddInt(Objects[t3][8]);}{tobj3.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t3][9])) {tobj3.setAddAgi(Objects[t3][9]);}{tobj3.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t3][10])) {tobj3.setAddHP(Objects[t3][10]);}{tobj3.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t3][11])) {tobj3.setAddMP(Objects[t3][11]);}{tobj3.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t3][12])) {tobj3.setDurability(Objects[t3][12]);}{tobj3.setDurability("0");} // durability
			if (!"null".equalsIgnoreCase(Objects[t3][13])) {tobj3.setTakeable(Objects[t3][13]);}{tobj3.setTakeable("0");}  // takeable
			t = Objects[t3][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			//			tobj3.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (tobjsarr[4]!=null) {
			t4 = Integer.parseInt(tobjsarr[4]);  
			tobj4.setObjNum(t4); // obj #
			tobj4.setObjName(Objects[t4][1]); // obj Name
			tobj4.setObjShortDesc(Objects[t4][2]); // obj short desc
			tobj4.setObjLongDesc(Objects[t4][3]); // obj long desc
			tobj4.setObjExtDesc(Objects[t4][4]); // obj ext desc
			t = Objects[t4][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj4.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t4][6])) {tobj4.setAddStam(Objects[t4][6]);}{tobj4.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t4][7])) {tobj4.setAddStr(Objects[t4][7]);}{tobj4.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t4][8])) {tobj4.setAddInt(Objects[t4][8]);}{tobj4.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t4][9])) {tobj4.setAddAgi(Objects[t4][9]);}{tobj4.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t4][10])) {tobj4.setAddHP(Objects[t4][10]);}{tobj4.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t4][11])) {tobj4.setAddMP(Objects[t4][11]);}{tobj4.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t4][12])) {tobj4.setDurability(Objects[t4][12]);}{tobj4.setDurability("0");} // durability
			if (!"null".equalsIgnoreCase(Objects[t4][13])) {tobj4.setTakeable(Objects[t4][13]);}{tobj4.setTakeable("0");}  // takeable
			t = Objects[t4][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			//			tobj4.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (tobjsarr[5]!=null) {
			t5 = Integer.parseInt(tobjsarr[5]);  
			tobj5.setObjNum(t5); // obj #
			tobj5.setObjName(Objects[t5][1]); // obj Name
			tobj5.setObjShortDesc(Objects[t5][2]); // obj short desc
			tobj5.setObjLongDesc(Objects[t5][3]); // obj long desc
			tobj5.setObjExtDesc(Objects[t5][4]); // obj ext desc
			t = Objects[t5][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj5.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t5][6])) {tobj5.setAddStam(Objects[t5][6]);}{tobj5.setAddStam("0");} // stam
			if (!"null".equalsIgnoreCase(Objects[t5][7])) {tobj5.setAddStr(Objects[t5][7]);}{tobj5.setAddStr("0");} // str
			if (!"null".equalsIgnoreCase(Objects[t5][8])) {tobj5.setAddInt(Objects[t5][8]);}{tobj5.setAddInt("0");} // int
			if (!"null".equalsIgnoreCase(Objects[t5][9])) {tobj5.setAddAgi(Objects[t5][9]);}{tobj5.setAddAgi("0");} // agi
			if (!"null".equalsIgnoreCase(Objects[t5][15])) {tobj5.setAddHP(Objects[t5][10]);}{tobj5.setAddHP("0");} // hp
			if (!"null".equalsIgnoreCase(Objects[t5][11])) {tobj5.setAddMP(Objects[t5][11]);}{tobj5.setAddMP("0");} // mp
			if (!"null".equalsIgnoreCase(Objects[t5][12])) {tobj5.setDurability(Objects[t5][12]);}{tobj5.setDurability("0");} // durability

		}

	}



	public void start() {
		// cancel/clear any existing timers
		suntimer.cancel();
		moontimer1.cancel();
		moontimer2.cancel();
		moontimer3.cancel();
		raintimer.cancel();
		// make new timers
		suntimer = new Timer("Sunrise");
		moontimer1 = new Timer("Moon1rise");
		moontimer2 = new Timer("Moon2rise");
		moontimer3 = new Timer("Moon3rise");
		raintimer = new Timer("Rainy Weather");
		Date executionDate = new Date(); // no params = now
		Date executionDate1 = new Date();
		Date executionDate2 = new Date();
		Date executionDate3 = new Date();
		Date executionDate4 = new Date();
		// start the timers
		suntimer.scheduleAtFixedRate(task, executionDate, sundelay);
		moontimer1.scheduleAtFixedRate(task1, executionDate1, moon1delay);
		moontimer2.scheduleAtFixedRate(task2, executionDate2, moon2delay);
		moontimer3.scheduleAtFixedRate(task3, executionDate3, moon3delay);
		raintimer.scheduleAtFixedRate(task4, executionDate4, rainyweather);

	}

	// 30 day weather cycle
	private class RainyWeather extends TimerTask {
		public void run() {
			if (raintime == 0) {
				System.out.println("The weather begins to clear.");
				weatherstatus = "clear";
				raintime = 1;
			}
			else if (raintime == 1) {
				System.out.println("The skies clear and the clouds disperse.");
				raintime = 2;
			}
			else if (raintime == 2) {
				raintime = 3;
			}
			else if (raintime == 3) {
				raintime = 4;
			}
			else if (raintime == 4) {
				System.out.println("The weather cools and the clouds gather.");
				weatherstatus = "overcast";
				raintime = 5;
			}
			else if (raintime == 5) {
				System.out.println("The skies clear and the clouds disperse.");
				weatherstatus = "clear";
				raintime = 6;
			}
			else if (raintime == 6) {
				raintime = 7;
			}
			else if (raintime == 7) {
				raintime = 8;
			}
			else if (raintime == 8) {
				raintime = 9;
			}
			else if (raintime == 9) {
				System.out.println("The winds blow and the clouds gather.");
				weatherstatus = "overcast";
				raintime = 10;
			}
			else if (raintime == 10) {
				System.out.println("The skies clear and the clouds disperse.");
				weatherstatus = "clear";
				raintime = 11;
			}			
			else if (raintime == 11) {
				raintime = 12;
			}
			else if (raintime == 12) {
				raintime = 13;
			}
			else if (raintime == 13) {
				raintime = 14;
			}
			else if (raintime == 14) {
				System.out.println("The winds blow and the clouds gather.");
				weatherstatus = "overcast";
				raintime = 15;
			}
			else if (raintime == 15) {
				System.out.println("It begins to rain.");
				weatherstatus = "rainy";
				raintime = 16;
			}			
			else if (raintime == 16) {
				System.out.println("It drizzles lightly.");
				weatherstatus = "rainy";
				raintime = 17;
			}
			else if (raintime == 17) {
				System.out.println("The skies clear and the clouds disperse.");
				weatherstatus = "clear";
				raintime = 18;
			}
			else if (raintime == 18) {
				System.out.println("It drizzles lightly.");
				weatherstatus = "rainy";
				raintime = 19;
			}
			else if (raintime == 19) {
				System.out.println("The skies clear and the clouds disperse.");
				weatherstatus = "clear";
				raintime = 20;
			}
			else if (raintime == 20) {

				raintime = 21;
			}
			else if (raintime == 21) {
				System.out.println("The suns shine brightly.");
				weatherstatus = "clear";
				raintime = 22;
			}
			else if (raintime == 22) {
				raintime = 23;
			}
			else if (raintime == 23) {
				raintime = 24;
			}
			else if (raintime == 24) {
				System.out.println("The suns shine brightly.");
				weatherstatus = "clear";
				raintime = 25;
			}
			else if (raintime == 25) {
				raintime = 26;
			}
			else if (raintime == 26) {
				raintime = 27;
			}
			else if (raintime == 27) {
				System.out.println("The suns shine and the winds blow.");
				weatherstatus = "clear";
				raintime = 28;
			}
			else if (raintime == 28) {
				System.out.println("The weather cools and the clouds gather.");
				weatherstatus = "overcast";
				raintime = 29;
			}
			else if (raintime == 29) {
				System.out.println("It begins to rain.");
				weatherstatus = "rainy";
				raintime = 30;
			}
			else {
				System.out.println("It pours heavily.");
				weatherstatus = "rainy";
				raintime = 0;
			}
		}
	}


	// Suns cycle
	private class SunTask extends TimerTask {
		public void run() {
			if (daytime == 0) {
				System.out.println("day " + daynum);
				System.out.println("The twin suns spiral around each other as they rise in the eastern sky.");
				sunstatus = "visible";
				daytime = 1;
				daynum++;
			}
			else {
				System.out.println("The suns spiral and fade in the western horizon.");
				sunstatus = "hidden";
				daytime = 0;
			}
		}
	}

	// Xifos, largest moon
	private class Moon1Task extends TimerTask {
		public void run() {	
			if (moontime1 == 0) {
				System.out.println("Xifos, the largest of the moons, rises in the northern sky.");
				moon1status = "visible";
				moontime1 = 1;
			}
			else if (moontime1 == 1) {
				//	System.out.println("Xifos ascends to its apex.");
				moon1status = "visible";
				moontime1 = 2;
			}
			else if (moontime1 == 2) {
				System.out.println("Xifos sinks in the southern sky.");
				moon1status = "visible";
				moontime1 = 3;
			}
			else if (moontime1 == 3) {
				moon1status = "hidden";
				moontime1 = 4;
			}
			else if (moontime1 == 4) {
				moon1status = "hidden";
				moontime1 = 5;
			}
			else  {
				moon1status = "hidden";
				moontime1 = 0;
			}
		}
	}

	private class Moon2Task extends TimerTask {
		public void run() {
			if (moontime2 == 0) {
				System.out.println("Cristos appears briefly on the horizon.");
				moontime2 = 1;
			}
			else 	{
				moontime2 = 0;
				moon2status = "hidden";
			}
		}
	}


	private class Moon3Task extends TimerTask {
		public void run() {
			if (moontime3 == 0) {
				System.out.println("Mithos rises in the southeastern sky.");
				moontime3 = 1;
				moon3status = "visible";
			}
			else if (moontime3 == 1) {
				System.out.println("Mithos progresses across the majority of the sky.");
				moontime3 = 2;
				moon3status = "visible";
			}
			else {
				moontime3 = 0;
				moon3status = "hidden";
			}
		}
	}


	public static void displayCurrentTime() {
		long endTime   = System.nanoTime();
		long totalTime = (endTime - startTime) / 1000000000; // move to seconds~!
		SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm:ss");
		String time = localDateFormat.format(new Date());
		System.out.println("Day: [" + daynum + "]");
		System.out.println("Current Time: " + totalTime); // add "time"
		System.out.println("Current local time: " + time);
		System.out.println("Suns: [" + sunstatus + "]");
		System.out.println("Moons: Xifos [" + moon1status + "] Critos [" + moon2status + "] Mithos [" + moon3status + "]");
		System.out.println("Weather Status: [" + weatherstatus + "]");
		try {
			Thread.sleep(5000);

			//	look("null");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}


}

//END OF JAVA FILE