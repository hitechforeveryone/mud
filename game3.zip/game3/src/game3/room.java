package game3;

import java.util.Arrays;

public class room {


	// display the room
	public void returnRoomInfo() {
		System.out.println("Room: " + getRoomNum());
		System.out.println("Room Name: " + getRoomName());
		System.out.println("Room Description: " + getRoomLongDesc());
		System.out.println("Exits: N[" + getExitN() + "] NE[" + getExitNE() + "] E[" + getExitE() + "] SE[" + getExitSE() 
		+ "] S[" + getExitS() + "] SW[" + getExitSW() + "] W[" + getExitW() + "] NW[" + getExitNW() + "] U[" + getExitU() + "] D[" + getExitD() + "]");		

		System.out.println("Mobs: " + Arrays.toString(getMobsInRoom()));
		System.out.println("Objects: " + Arrays.toString(getObjsInRoom()));

	}



	public String getRoomNum() {
		return roomNum;
	}
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomShortDesc() {
		return roomShortDesc;
	}
	public void setRoomShortDesc(String roomShortDesc) {
		this.roomShortDesc = roomShortDesc;
	}
	public String getRoomLongDesc() {
		return roomLongDesc;
	}
	public void setRoomLongDesc(String roomLongDesc) {
		this.roomLongDesc = roomLongDesc;
	}
	public String getExitN() {
		return exitN;
	}
	public void setExitN(String exitN) {
		this.exitN = exitN;
	}
	public String getExitNE() {
		return exitNE;
	}
	public void setExitNE(String exitNE) {
		this.exitNE = exitNE;
	}
	public String getExitE() {
		return exitE;
	}
	public void setExitE(String exitE) {
		this.exitE = exitE;
	}
	public String getExitSE() {
		return exitSE;
	}
	public void setExitSE(String exitSE) {
		this.exitSE = exitSE;
	}
	public String getExitS() {
		return exitS;
	}
	public void setExitS(String exitS) {
		this.exitS = exitS;
	}
	public String getExitSW() {
		return exitSW;
	}
	public void setExitSW(String exitSW) {
		this.exitSW = exitSW;
	}
	public String getExitW() {
		return exitW;
	}
	public void setExitW(String exitW) {
		this.exitW = exitW;
	}
	public String getExitNW() {
		return exitNW;
	}
	public void setExitNW(String exitNW) {
		this.exitNW = exitNW;
	}
	public String getExitU() {
		return exitU;
	}
	public void setExitU(String exitU) {
		this.exitU = exitU;
	}
	public String getExitD() {
		return exitD;
	}
	public void setExitD(String exitD) {
		this.exitD = exitD;
	}
	public String[] getMobsInRoom() {
		return mobsInRoom;
	}
	public void setMobsInRoom(String[] mobsInRoom) {
		this.mobsInRoom = mobsInRoom;
	}
	public String[] getObjsInRoom() {
		return objsInRoom;
	}
	public void setObjsInRoom(String[] objsInRoom) {
		this.objsInRoom = objsInRoom;
	}
	public String getLit() {
		return lit;
	}
	public void setLit(String lit) {
		this.lit = lit;
	}
	public String getCamp() {
		return camp;
	}
	public void setCamp(String camp) {
		this.camp = camp;
	}
	public String getRent() {
		return rent;
	}
	public void setRent(String rent) {
		this.rent = rent;
	}
	public String getInside() {
		return inside;
	}
	public void setInside(String inside) {
		this.inside = inside;
	}

	public void resetRoom() {
		roomNum = "-1";
		roomName = null;
		roomShortDesc = null;
		roomLongDesc = null;
		exitN = "-1";
		exitNE = "-1";
		exitE = "-1";
		exitSE = "-1";
		exitS = "-1";
		exitSW = "-1";
		exitW = "-1";
		exitNW = "-1";
		exitU = "-1";
		exitD = "-1";
		mobsInRoom = new String[6];
		objsInRoom = new String[6];
		lit = "1";
		camp = "1";
		rent = "1";
		inside = "1";
		v20 = "-1"; // 20
		v21 = "-1"; // 21
		v22 = "-1"; // 22
		v23 = "-1"; // 23
		v24 = "-1"; // 24
		v25 = "-1"; // 25
		v26 = "-1"; // 26
		v27 = "-1"; // 27
		v28 = "-1"; // 28
		v29 = "-1"; // 29
		v30 = "-1"; // 30
		v31 = "-1"; // 31
		v32 = "-1"; // 32
		v33 = "-1"; // 33
		v34 = "-1"; // 34
		v35 = "-1"; // 35
		v36 = "-1"; // 36
		v37 = "-1"; // 37
		v38 = "-1"; // 38
		v39 = "-1"; // 39
		v40 = "-1"; // 40
		v41 = "-1"; // 41
		v42 = "-1"; // 42
		v43 = "-1"; // 43
		v44 = "-1"; // 44
		v45 = "-1"; // 45
		v46 = "-1"; // 46
		v47 = "-1"; // 47
		v48 = "-1"; // 48
		v49 = "-1"; // 49
		
	}

	String roomNum = "-1"; // 0
	String roomName = "-1";  // 1 
	String roomShortDesc = "-1";  // 2
	String roomLongDesc = "-1";  // 3 
	String exitN = "-1"; // 4
	String exitNE = "-1";  // 5
	String exitE = "-1";  // 6
	String exitSE = "-1";  // 7
	String exitS = "-1"; // 8
	String exitSW = "-1"; // 9
	String exitW = "-1"; // 10
	String exitNW = "-1";  // 11
	String exitU = "-1";  // 12
	String exitD = "-1";  // 13
	String[] mobsInRoom = new String[6]; // 14
	String[] objsInRoom = new String[6]; // 15
	String lit = "1"; // 16
	String camp = "1"; // 17
	String rent = "1"; // 18
	String inside = "1"; // 19
	String v20 = "-1"; // 20
	String v21 = "-1"; // 21
	String v22 = "-1"; // 22
	String v23 = "-1"; // 23
	String v24 = "-1"; // 24
	String v25 = "-1"; // 25
	String v26 = "-1"; // 26
	String v27 = "-1"; // 27
	String v28 = "-1"; // 28
	String v29 = "-1"; // 29
	String v30 = "-1"; // 30
	String v31 = "-1"; // 31
	String v32 = "-1"; // 32
	String v33 = "-1"; // 33
	String v34 = "-1"; // 34
	String v35 = "-1"; // 35
	String v36 = "-1"; // 36
	String v37 = "-1"; // 37
	String v38 = "-1"; // 38
	String v39 = "-1"; // 39
	String v40 = "-1"; // 40
	String v41 = "-1"; // 41
	String v42 = "-1"; // 42
	String v43 = "-1"; // 43
	String v44 = "-1"; // 44
	String v45 = "-1"; // 45
	String v46 = "-1"; // 46
	String v47 = "-1"; // 47
	String v48 = "-1"; // 48
	String v49 = "-1"; // 49
}
