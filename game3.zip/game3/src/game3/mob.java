package game3;


public class mob {
	int mobNum = -1; //0
	String mobName; //1
	String mobShortDesc; //2
	String mobLongDesc;//3
	String[] mobKeyWords = new String[3];//4
	int mobHP = 100;//5
	int mobMP = 100;//6
	int mobLvl = 1;//7
	int Stam = 10;//8
	int Str = 10;//9
	int Intel = 10;//10
	int Agility = 10;//11
	String headSlot = "none";//12
	String neckSlot = "none";//13
	String shoulderSlot = "none";//14
	String chestSlot = "none";//15
	String wristSlot = "none";//16
	String handSlot = "none";//17
	String finger1 = "none";//18
	String finger2 = "none";//19
	String waistSlot = "none";//20
	String legSlot = "none";//21
	String footSlot = "none";//22
	String trinket1Slot = "none";//23
	String trinket2Slot = "none";//24
	String weapon1Slot = "none";//25
	String weaponShieldSlot = "none";//26

	String mobRace = "none"; //27 aquatic, beast, critter, dragonkin, elemental, flying, humanoid, magic, mechanical, undead
	/*		player races considered Humanoid
	 * aquatic - +150% dmg to elemental, -33% from magic
	 * beast -	+150% dmg to critter, -33% from flying
	 * critter - +150% to undead, -33 from humanoid, 
	 * dragonkin - +150% to magic, -33% from undead
	 * elemental - +150% to mechanical, -33% critter
	 * flying -  +150% to aquatic, -33% from dragonkin 
	 * humanoid - +150% to dragonkin, -33% from beast
	 * magic - +150% to flying, -33% from mechanical
	 * mechanical - +150% to beast, -33% from elemental 
	 * undead -  +150% to humanoid, -33% from aquatic
	 */
	String mobSubRace = "none";//28
	String mobRank = "normal";//29
	/*
	 * 	mob ranks:
	 * 		mobs can have ranks, higher ranks increase their health and damage
	 * 		null/common/normal - hp, dps the same
	 * 		elite - hp, dps increase by 125%
	 * 		chieftain - hp, dps increase 150%
	 * 		lord - hp, dps increase 175%
	 * 		high lord - hp, dps increase 200%
	 * 		great lord - hp, dps increase 225%
	 * 		grand lord - hp, dps increase 250%
	 * 		Mythic - hp, dps increase 300%
	 * 		Archaic Species - hp, dps increase by 750%
	 * 		God Rank - hp, dps increase 1000%
	 */

	int mobXPVal = 75;//30
	int mobIsAlive = 1;//31
	String mobGender = "none";//32
	String v33 = "null";//33
	String v34 = "null";//34
	String v35 = "null";//35
	String v36 = "null";//36
	String v37 = "null";//37
	String v38 = "null";//38
	String v39 = "null";//39
	String v40 = "null";//40
	String v41 = "null";//41
	String v42 = "null";//42
	String v43 = "null";//43
	String v44 = "null";//44
	String v45 = "null";//45
	String v46 = "null";//46
	String v47 = "null";//47
	String v48 = "null";//48
	String v49 = "null";//49 

	
	
	public void returnmobInfo() {
		System.out.println("Mob Name: " + getMobName());
		System.out.println("Description: " + getMobLongDesc());
		System.out.println("Race: " + getmobRace() + ": " + getmobSubRace() + "  Level: [" + getMobLvl() + "]   Rank: [" + getmobRank() + "]");
		System.out.println("HPs: [" + getMobHP() + "]   MPs: [" + getMobMP() + "]");
		System.out.println("Stamina: " + getStam() + "  Strength: " + getStr() + "   Intelligence: " + getIntel() + "   Agility: " + getAgility());
		System.out.println("Equiped Items -----------------------------------------------------------");
		System.out.println("Head Slot: " + getHeadSlot());
		System.out.println("Neck Slot: " + getNeckSlot());
		System.out.println("Shoulder Slot: " + getShoulderSlot());
		System.out.println("Chest Slot: " + getChestSlot());
		System.out.println("Wrist Slot: " + getWristSlot());
		System.out.println("Hand Slot: " + getHandSlot());		
		System.out.println("Finger Slot: " + getFinger1());
		System.out.println("Finger Slot: " + getFinger2());
		System.out.println("Waist Slot: " + getWaistSlot());
		System.out.println("Leg Slot: " + getLegSlot());
		System.out.println("Foot Slot: " + getFootSlot());
		System.out.println("Trinket Slot: " + getTrinket1Slot());
		System.out.println("Trinket Slot: " + getTrinket2Slot());
		System.out.println("Weapon Slot: " + getWeapon1Slot());
		System.out.println("Offhand Slot: " + getWeaponShieldSlot());

	}



	public int getMobNum() {
		return mobNum;
	}
	public void setMobNum(int mobNum) {
		this.mobNum = mobNum;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public String getMobShortDesc() {
		return mobShortDesc;
	}
	public void setMobShortDesc(String mobShortDesc) {
		this.mobShortDesc = mobShortDesc;
	}
	public String getMobLongDesc() {
		return mobLongDesc;
	}
	public void setMobLongDesc(String mobLongDesc) {
		this.mobLongDesc = mobLongDesc;
	}
	public String[] getMobKeyWords() {
		return mobKeyWords;
	}
	public void setMobKeyWords(String[] mobKeyWords) {
		this.mobKeyWords = mobKeyWords;
	}
	public int getMobHP() {
		return mobHP;
	}
	public void setMobHP(int mobHP) {
		this.mobHP = mobHP;
	}
	public int getMobMP() {
		return mobMP;
	}
	public void setMobMP(int mobMP) {
		this.mobMP = mobMP;
	}
	public int getMobLvl() {
		return mobLvl;
	}
	public void setMobLvl(int mobLvl) {
		this.mobLvl = mobLvl;
	}
	public int getStam() {
		return Stam;
	}
	public void setStam(int stam) {
		Stam = stam;
	}
	public int getStr() {
		return Str;
	}
	public void setStr(int str) {
		Str = str;
	}
	public int getIntel() {
		return Intel;
	}
	public void setIntel(int intel) {
		Intel = intel;
	}
	public int getAgility() {
		return Agility;
	}
	public void setAgility(int agility) {
		Agility = agility;
	}
	public String getHeadSlot() {
		return headSlot;
	}
	public void setHeadSlot(String headSlot) {
		this.headSlot = headSlot;
	}
	public String getNeckSlot() {
		return neckSlot;
	}
	public void setNeckSlot(String neckSlot) {
		this.neckSlot = neckSlot;
	}
	public String getShoulderSlot() {
		return shoulderSlot;
	}
	public void setShoulderSlot(String shoulderSlot) {
		this.shoulderSlot = shoulderSlot;
	}
	public String getChestSlot() {
		return chestSlot;
	}
	public void setChestSlot(String chestSlot) {
		this.chestSlot = chestSlot;
	}
	public String getWristSlot() {
		return wristSlot;
	}
	public void setWristSlot(String wristSlot) {
		this.wristSlot = wristSlot;
	}
	public String getHandSlot() {
		return handSlot;
	}
	public void setHandSlot(String handSlot) {
		this.handSlot = handSlot;
	}
	public String getFinger1() {
		return finger1;
	}
	public void setFinger1(String finger1) {
		this.finger1 = finger1;
	}
	public String getFinger2() {
		return finger2;
	}
	public void setFinger2(String finger2) {
		this.finger2 = finger2;
	}
	public String getWaistSlot() {
		return waistSlot;
	}
	public void setWaistSlot(String waistSlot) {
		this.waistSlot = waistSlot;
	}
	public String getLegSlot() {
		return legSlot;
	}
	public void setLegSlot(String legSlot) {
		this.legSlot = legSlot;
	}
	public String getFootSlot() {
		return footSlot;
	}
	public void setFootSlot(String footSlot) {
		this.footSlot = footSlot;
	}
	public String getTrinket1Slot() {
		return trinket1Slot;
	}
	public void setTrinket1Slot(String trinket1Slot) {
		this.trinket1Slot = trinket1Slot;
	}
	public String getTrinket2Slot() {
		return trinket2Slot;
	}
	public void setTrinket2Slot(String trinket2Slot) {
		this.trinket2Slot = trinket2Slot;
	}
	public String getWeapon1Slot() {
		return weapon1Slot;
	}
	public void setWeapon1Slot(String weapon1Slot) {
		this.weapon1Slot = weapon1Slot;
	}
	public String getWeaponShieldSlot() {
		return weaponShieldSlot;
	}
	public void setWeaponShieldSlot(String weaponShieldSlot) {
		this.weaponShieldSlot = weaponShieldSlot;
	}
	public void setmobRace(String race) {
		this.mobRace = race;
	}
	public String getmobRace() {
		return mobRace;
	}
	public void setmobSubRace(String subrace) {
		this.mobSubRace = subrace;
	}
	public String getmobSubRace() {
		return mobSubRace;
	}
	public void setmobRank(String rank) {
		this.mobRank = rank;
	}

	public String getmobRank() {
		return mobRank;
	}
	public void setmobXPVal(int xp) {
		this.mobXPVal = xp;
	}
	public int getmobXPVal() {
		return mobXPVal;
	}
	public void setMobGender(String g) {
		this.mobGender = g;
	}
	public String getMobGender() {
		return mobGender;
	}
	public void setmobIsAlive(int i) {
		this.mobIsAlive = i;
	}
	public int getmobIsAlive() {
		return mobIsAlive;
	}



	public String getMobRace() {
		return mobRace;
	}



	public void setMobRace(String mobRace) {
		this.mobRace = mobRace;
	}



	public String getMobSubRace() {
		return mobSubRace;
	}



	public void setMobSubRace(String mobSubRace) {
		this.mobSubRace = mobSubRace;
	}



	public String getMobRank() {
		return mobRank;
	}



	public void setMobRank(String mobRank) {
		this.mobRank = mobRank;
	}



	public int getMobXPVal() {
		return mobXPVal;
	}



	public void setMobXPVal(int mobXPVal) {
		this.mobXPVal = mobXPVal;
	}



	public int getMobIsAlive() {
		return mobIsAlive;
	}



	public void setMobIsAlive(int mobIsAlive) {
		this.mobIsAlive = mobIsAlive;
	}



	public String getV33() {
		return v33;
	}



	public void setV33(String v33) {
		this.v33 = v33;
	}



	public String getV34() {
		return v34;
	}



	public void setV34(String v34) {
		this.v34 = v34;
	}



	public String getV35() {
		return v35;
	}



	public void setV35(String v35) {
		this.v35 = v35;
	}



	public String getV36() {
		return v36;
	}



	public void setV36(String v36) {
		this.v36 = v36;
	}



	public String getV37() {
		return v37;
	}



	public void setV37(String v37) {
		this.v37 = v37;
	}



	public String getV38() {
		return v38;
	}



	public void setV38(String v38) {
		this.v38 = v38;
	}



	public String getV39() {
		return v39;
	}



	public void setV39(String v39) {
		this.v39 = v39;
	}



	public String getV40() {
		return v40;
	}



	public void setV40(String v40) {
		this.v40 = v40;
	}



	public String getV41() {
		return v41;
	}



	public void setV41(String v41) {
		this.v41 = v41;
	}



	public String getV42() {
		return v42;
	}



	public void setV42(String v42) {
		this.v42 = v42;
	}



	public String getV43() {
		return v43;
	}



	public void setV43(String v43) {
		this.v43 = v43;
	}



	public String getV44() {
		return v44;
	}



	public void setV44(String v44) {
		this.v44 = v44;
	}



	public String getV45() {
		return v45;
	}



	public void setV45(String v45) {
		this.v45 = v45;
	}



	public String getV46() {
		return v46;
	}



	public void setV46(String v46) {
		this.v46 = v46;
	}



	public String getV47() {
		return v47;
	}



	public void setV47(String v47) {
		this.v47 = v47;
	}



	public String getV48() {
		return v48;
	}



	public void setV48(String v48) {
		this.v48 = v48;
	}



	public String getV49() {
		return v49;
	}



	public void setV49(String v49) {
		this.v49 = v49;
	}


}
