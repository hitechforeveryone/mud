package Game;

import java.util.Arrays;

public class mob {
	int mobNum; //0
	String mobName; //1
	String mobShortDesc; //2
	String mobLongDesc;//3
	String[] mobKeyWords = new String[3];//4
	
	
	int mobHP;//5
	int mobMaxHP;
	int mobMP;//6
	int mobMaxMP;
	int mobLvl;//7
	int Stam;//8
	int Str;//9
	int Intel;//10
	int Agility;//11
	String headSlot = "0";//12
	String neckSlot = "0";//13
	String shoulderSlot = "0";//14
	String chestSlot = "0";//15
	String wristSlot = "0";//16
	String handSlot = "0";//17
	String finger1 = "0";//18
	String finger2 = "0";//19
	String waistSlot = "0";//20
	String legSlot = "0";//21
	String footSlot = "0";//22
	String trinket1Slot = "0";//23
	String trinket2Slot = "0";//24
	String weapon1Slot = "0";//25
	String weaponShieldSlot = "0";//26

	String mobRace = "none"; //27 aquatic, beast, critter, dragonkin, elemental, flying, humanoid, magic, mechanical, undead, none
	/*		player races considered Humanoid
	 * aquatic - +150% dmg to elemental, -33% from magic
	 * beast -	+150% dmg to critter, -33% from flying
	 * critter - +150% to undead, -33 from humanoid, 
	 * dragonkin - +150% to magic, -33% from undead
	 * elemental - +150% to mechanical, -33% critter
	 * flying -  +150% to aquatic, -33% from dragonkin 
	 * humanoid - +150% to dragonkin, -33% from beast
	 * magic - +150% to flying, -33% from mechanical
	 * mechanical - +150% to beast, -33% from elemental 
	 * undead -  +150% to humanoid, -33% from aquatic
	 */
	
	
	String mobSubRace = "none";//28
	String mobRank = "normal";//29  // playerTier
	/*
	 * 	mob ranks:
	 * 		mobs can have ranks, higher ranks increase their health and damage
	 * 		null/common/normal - hp, dps the same
	 * 		elite - hp, dps increase by 125%
	 * 		chieftain - hp, dps increase 150%
	 * 		lord - hp, dps increase 175%
	 * 		high lord - hp, dps increase 200%
	 * 		great lord - hp, dps increase 225%
	 * 		grand lord - hp, dps increase 250%
	 * 		Mythic - hp, dps increase 300%
	 * 		Archaic Species - hp, dps increase by 750%
	 * 		God Rank - hp, dps increase 1000%
	 */

	int mobXPVal;//30
	int mobIsAlive = 1;//31
	String mobGender = "none";//32

	String mobClass = "none";//33
	int attackable = 1;//34
	int wanders = 0;//35  // set to 1 on players? or does nothing for players
	String v36 = "atPeace";//36 // inCombat?
	String v37 = "none";//37 // target?
	String v38 = "nonAggressive";//38	// isAggressive ?
	String v39 = "0";//39 //
	String v40 = "0";//40
	String v41 = "0";//41
	String v42 = "0";//42
	String v43 = "0";//43
	String v44 = "0";//44
	String v45 = "0";//45
	
	int v46 = 0;//46 // is talker
	String v47 = "0";//47 // speech 1
	String v48 = "0";//48 // speech 2
	String v49 = "0";//49 // speech 3
	
	objects mobHelm = new objects();
	objects mobNeck = new objects();
	objects mobShoulder = new objects();
	objects mobChest = new objects();
	objects mobWrist = new objects();
	objects mobHand = new objects();
	objects mobFinger1 = new objects();
	objects mobFinger2 = new objects();
	objects mobWaist = new objects();
	objects mobLeg = new objects();
	objects mobFoot = new objects();
	objects mobTrinket1 = new objects();
	objects mobTrinket2 = new objects();
	objects mobWeapon1 = new objects();
	objects mobWeaponShield = new objects();
	

	public int getAgility() {
		return Agility;
	}

	public int getAttackable() {
		return attackable;
	}

	public String getChestSlot() {
		return chestSlot;
	}

	public String getFinger1() {
		return finger1;
	}

	public String getFinger2() {
		return finger2;
	}

	public String getFootSlot() {
		return footSlot;
	}

	public String getHandSlot() {
		return handSlot;
	}

	public String getHeadSlot() {
		return headSlot;
	}

	public int getHP() {
		return mobHP;
	}

	public int getIntel() {
		return Intel;
	}

	public String getKeyWord(int i) {
		String temp = Arrays.toString(getMobKeyWords());
		temp = temp.replace("[", "");
		temp = temp.replace("]", "");
		String[] split = temp.split(",");		
		return split[i];
	}
	


	public String getLegSlot() {
		return legSlot;
	}

	public int getMaxHP() {
		return mobMaxHP;
	}

	public int getMaxMP() {
		return mobMaxMP;
	}

	public String getMobClass() {
		return mobClass;
	}

	public String getMobGender() {
		return mobGender;
	}

	public int getMobHP() {
		return mobHP;
	}

	public int getmobIsAlive() {
		return mobIsAlive;
	}

	public int getMobIsAlive() {
		return mobIsAlive;
	}

	public String[] getMobKeyWords() {
		return mobKeyWords;
	}

	public String getMobLongDesc() {
		return mobLongDesc;
	}

	public int getMobLvl() {
		return mobLvl;
	}

	public int getMobMP() {
		return mobMP;
	}

	public String getMobName() {
		return mobName;
	}

	public int getMobNum() {
		return mobNum;
	}

	public String getmobRace() {
		return mobRace;
	}

	public String getMobRace() {
		return mobRace;
	}

	public String getmobRank() {
		return mobRank;
	}

	public String getMobRank() {
		return mobRank;
	}

	public String getMobShortDesc() {
		return mobShortDesc;
	}

	public String getmobSubRace() {
		return mobSubRace;
	}

	public String getMobSubRace() {
		return mobSubRace;
	}

	public int getmobXPVal() {
		return mobXPVal;
	}

	public int getMobXPVal() {
		return mobXPVal;
	}

	public int getMP() {
		return mobMP;
	}

	public String getNeckSlot() {
		return neckSlot;
	}

	public String getShortDesc() {
		return mobShortDesc;
	}

	public String getShoulderSlot() {
		return shoulderSlot;
	}

	public int getStam() {
		return Stam;
	}

	public int getStr() {
		return Str;
	}

	public String getTrinket1Slot() {
		return trinket1Slot;
	}


	public String getTrinket2Slot() {
		return trinket2Slot;
	}

	public int getWanders() {
		return wanders;
	}

	public String getV36() {
		return v36;
	}

	public String getV37() {
		return v37;
	}

	public String getV38() {
		return v38;
	}

	public String getV39() {
		return v39;
	}

	public String getV40() {
		return v40;
	}

	public String getV41() {
		return v41;
	}

	public String getV42() {
		return v42;
	}

	public String getV43() {
		return v43;
	}

	public String getV44() {
		return v44;
	}

	public String getV45() {
		return v45;
	}

	public int getV46() {
		return v46;
	}

	public String getV47() {
		return v47;
	}

	public String getV48() {
		return v48;
	}

	public String getV49() {
		return v49;
	}

	public String getWaistSlot() {
		return waistSlot;
	}

	public String getWeapon1Slot() {
		return weapon1Slot;
	}

	public String getWeaponShieldSlot() {
		return weaponShieldSlot;
	}
	
	public String getWristSlot() {
		return wristSlot;
	}

	
	public void resetStats() {
		//resets the mobs base stats for use with defaults
		mobHP = 100;//5
		mobMP = 100;//6
		mobMaxHP = 100;
		mobMaxMP = 100;
		mobLvl = 1;//7
		Stam = 10;//8
		Str = 10;//9
		Intel = 10;//10
		Agility = 10;//11
		mobXPVal = 75;
	}
	@SuppressWarnings("unused")
	public void reset() {
		mobNum = 0; //0
		mobName = "null"; //1
		mobShortDesc = "null"; //2
		mobLongDesc = "null";//3
		String[] mobKeyWords = new String[3];//4
		mobKeyWords[0] = "null";
		mobKeyWords[1] = "null";
		mobKeyWords[2] = "null";
		mobHP = 100;//5
		mobMP = 100;//6
		mobLvl = 1;//7
		Stam = 10;//8
		Str = 10;//9
		Intel = 10;//10
		Agility = 10;//11
		headSlot = "0";//12
		neckSlot = "0";//13
		shoulderSlot = "0";//14
		chestSlot = "0";//15
		wristSlot = "0";//16
		handSlot = "0";//17
		finger1 = "0";//18
		finger2 = "0";//19
		waistSlot = "0";//20
		legSlot = "0";//21
		footSlot = "0";//22
		trinket1Slot = "0";//23
		trinket2Slot = "0";//24
		weapon1Slot = "0";//25
		weaponShieldSlot = "0";//26

		String mobRace = "none"; //27 aquatic, beast, critter, dragonkin, elemental, flying, humanoid, magic, mechanical, undead
		String mobSubRace = "none";//28
		String mobRank = "normal";//29
		int mobXPVal = 75;//30
		int mobIsAlive = 1;//31
		String mobGender = "none";//32
		String mobClass = "none";//33

		int attackable = 1;//34
		
		wanders = 0;//35
		String v36 = "atPeace";//36 // inCombat?
		String v37 = "none";//37 // target?
		String v38 = "nonAggressive";//38	// isAggressive ?
		String v39 = "unused";//39
		String v40 = "unused";//40
		String v41 = "unused";//41
		String v42 = "unused";//42
		String v43 = "unused";//43
		String v44 = "unused";//44
		String v45 = "unused";//45
		int v46 = 0;//46 // mobTalker
		String v47 = "0";//47 // speech1
		String v48 = "0";//48 // speech2
		String v49 = "0";//49  // speech3
		
		mobHelm.resetObject();
		mobNeck.resetObject();
		mobShoulder.resetObject();
		mobChest.resetObject();
		mobWrist.resetObject();
		mobHand.resetObject();
		mobFinger1.resetObject();
		mobFinger2.resetObject();
		mobWaist.resetObject();
		mobLeg.resetObject();
		mobFoot.resetObject();
		mobTrinket1.resetObject();
		mobTrinket2.resetObject();
		mobWeapon1.resetObject();
		mobWeaponShield.resetObject();
		
	}

	public void returnmobInfo() {
		// used for editor
		System.out.println("Mob Number: " + getMobNum()); //0
		System.out.println("Mob Name: " + getMobName()); //1
		System.out.println("Mob Short Desc: " + getMobShortDesc());
		System.out.println("Mob Long Desc: " + getMobLongDesc());
		String t = Arrays.toString(getMobKeyWords());
		t.replace("[", "");
		t.replace("]", "");
		System.out.println("Keywords: "+ t);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "  Keyword 2: " + getKeyWord(1).strip() + "  Keyword 1: " + getKeyWord(2).strip());
		System.out.println("Class: [" + getMobClass() + "]");
		System.out.println("Race: [" + getmobRace() + "]  Subrace: [" + getmobSubRace() + "]  Level: [" + getMobLvl() + "]   Rank: [" + getmobRank() + "]");
		System.out.println("XP Value: " + getMobXPVal()); 
		System.out.println("Attackable: " + getAttackable() + "  " + "Talker: " + getV46() + "  " + "Wanders: " + getWanders());
		System.out.println("HPs: [" + getMobHP() + "/" + getMaxHP() +"]   MPs: [" + getMobMP() + "/" + getMaxMP() +"]");
		System.out.println("Stamina: " + getStam() + "  Strength: " + getStr() + "   Intelligence: " + getIntel() + "   Agility: " + getAgility());
		System.out.println("Equiped Items -----------------------------------------------------------");
		System.out.println("Head Slot: " + getHeadSlot());
		System.out.println("Neck Slot: " + getNeckSlot());
		System.out.println("Shoulder Slot: " + getShoulderSlot());
		System.out.println("Chest Slot: " + getChestSlot());
		System.out.println("Wrist Slot: " + getWristSlot());
		System.out.println("Hand Slot: " + getHandSlot());		
		System.out.println("Finger Slot: " + getFinger1());
		System.out.println("Finger Slot: " + getFinger2());
		System.out.println("Waist Slot: " + getWaistSlot());
		System.out.println("Leg Slot: " + getLegSlot());
		System.out.println("Foot Slot: " + getFootSlot());
		System.out.println("Trinket Slot: " + getTrinket1Slot());
		System.out.println("Trinket Slot: " + getTrinket2Slot());
		System.out.println("Weapon Slot: " + getWeapon1Slot());
		System.out.println("Offhand Slot: " + getWeaponShieldSlot());

	}

	public void setAgility(int agility) {
		Agility = agility;
	}

	public void setAttackable(int i) {
		this.attackable = i;
	}

	public void setChestSlot(String chestSlot) {
		this.chestSlot = chestSlot;
	}

	public void setFinger1(String finger1) {
		this.finger1 = finger1;
	}

	public void setFinger2(String finger2) {
		this.finger2 = finger2;
	}

	public void setFootSlot(String footSlot) {
		this.footSlot = footSlot;
	}

	public void setHandSlot(String handSlot) {
		this.handSlot = handSlot;
	}

	public void setHeadSlot(String headSlot) {
		this.headSlot = headSlot;
	}

	public void setHP(int hp) {
		this.mobHP = hp;
	}

	public void setIntel(int intel) {
		Intel = intel;
	}

	public void setLegSlot(String legSlot) {
		this.legSlot = legSlot;
	}

	public void setMaxHP(int mMaxHP) {
		this.mobMaxHP = mMaxHP;
	}

	public void setMaxMP(int mMaxMP) {
		this.mobMaxMP = mMaxMP;
	}

	public void setMobClass(String mobClass) {
		this.mobClass = mobClass;
	}

	public void setMobGender(String g) {
		this.mobGender = g;
	}

	public void setMobHP(int mobHP) {
		this.mobHP = mobHP;
	}

	public void setmobIsAlive(int i) {
		this.mobIsAlive = i;
	}

	public void setMobIsAlive(int mobIsAlive) {
		this.mobIsAlive = mobIsAlive;
	}

	public void setMobKeyWords(String[] mobKeyWords) {
		this.mobKeyWords = mobKeyWords;
	}
	public void setMobKeyword1(String s) {
		this.mobKeyWords[0] = s;
	}
	public void setMobKeyword2(String s) {
		this.mobKeyWords[1] = s;
	}
	public void setMobKeyword3(String s) {
		this.mobKeyWords[2] = s;
	}
	public void setMobLongDesc(String mobLongDesc) {
		this.mobLongDesc = mobLongDesc;
	}

	public void setMobLvl(int mobLvl) {
		this.mobLvl = mobLvl;
	}

	public void setMobMP(int mobMP) {
		this.mobMP = mobMP;
	}

	public void setMobName(String mobName) {
		this.mobName = mobName;
	}

	public void setMobNum(int mobNum) {
		this.mobNum = mobNum;
	}

	public void setmobRace(String race) {
		this.mobRace = race;
	}

	public void setMobRace(String mobRace) {
		this.mobRace = mobRace;
	}

	public void setmobRank(String rank) {
		this.mobRank = rank;
	}

	public void setMobRank(String mobRank) {
		this.mobRank = mobRank;
	}

	public void setMobShortDesc(String mobShortDesc) {
		this.mobShortDesc = mobShortDesc;
	}

	public void setmobSubRace(String subrace) {
		this.mobSubRace = subrace;
	}

	public void setMobSubRace(String mobSubRace) {
		this.mobSubRace = mobSubRace;
	}

	public void setmobXPVal(int xp) {
		this.mobXPVal = xp;
	}

	public void setMobXPVal(int mobXPVal) {
		this.mobXPVal = mobXPVal;
	}

	public void setMP(int mp) {
		this.mobMP = mp;
	}

	public void setNeckSlot(String neckSlot) {
		this.neckSlot = neckSlot;
	}

	public void setShoulderSlot(String shoulderSlot) {
		this.shoulderSlot = shoulderSlot;
	}

	public void setStam(int stam) {
		Stam = stam;
	}

	public void setStr(int str) {
		Str = str;
	}

	public void setTrinket1Slot(String trinket1Slot) {
		this.trinket1Slot = trinket1Slot;
	}

	public void setTrinket2Slot(String trinket2Slot) {
		this.trinket2Slot = trinket2Slot;
	}

	public void setWanders(int wanders) {
		this.wanders = wanders;
	}

	public void setV36(String v36) {
		this.v36 = v36;
	}

	public void setV37(String v37) {
		this.v37 = v37;
	}

	public void setV38(String v38) {
		this.v38 = v38;
	}

	public void setV39(String v39) {
		this.v39 = v39;
	}

	public void setV40(String v40) {
		this.v40 = v40;
	}

	public void setV41(String v41) {
		this.v41 = v41;
	}

	public void setV42(String v42) {
		this.v42 = v42;
	}

	public void setV43(String v43) {
		this.v43 = v43;
	}

	public void setV44(String v44) {
		this.v44 = v44;
	}

	public void setV45(String v45) {
		this.v45 = v45;
	}

	public void setV46(int v46) {
		this.v46 = v46;
	}

	public void setV47(String v47) {
		this.v47 = v47;
	}

	public void setV48(String v48) {
		this.v48 = v48;
	}

	public void setV49(String v49) {
		this.v49 = v49;
	}

	public void setWaistSlot(String waistSlot) {
		this.waistSlot = waistSlot;
	}

	public void setWeapon1Slot(String weapon1Slot) {
		this.weapon1Slot = weapon1Slot;
	}

	public void setWeaponShieldSlot(String weaponShieldSlot) {
		this.weaponShieldSlot = weaponShieldSlot;
	}

	public void setWristSlot(String wristSlot) {
		this.wristSlot = wristSlot;
	}

	public String toString() {
		return mobNum + "|" + mobName + "|" + mobShortDesc + "|" + mobLongDesc + "|" + Arrays.toString(mobKeyWords)
		+ "|" + mobHP + "|" + mobMaxHP + "|" + mobMP + "|" + mobMaxMP + "|" + mobLvl + "|" + Stam + "|" + Str
		+ "|" + Intel + "|" + Agility + "|" + headSlot + "|" + neckSlot + "|" + shoulderSlot + "|" + chestSlot
		+ "|" + wristSlot + "|" + handSlot + "|" + finger1 + "|" + finger2 + "|" + waistSlot + "|" + legSlot
		+ "|" + footSlot + "|" + trinket1Slot + "|" + trinket2Slot + "|" + weapon1Slot + "|" + weaponShieldSlot
		+ "|" + mobRace + "|" + mobSubRace + "|" + mobRank + "|" + mobXPVal + "|" + mobIsAlive + "|" + mobGender
		+ "|" + mobClass + "|" + attackable + "|" + wanders + "|" + v36 + "|" + v37 + "|" + v38 + "|" + v39 + "|" + v40 + "|"
		+ v41 + "|" + v42 + "|" + v43 + "|" + v44 + "|" + v45 + "|" + v46 + "|" + v47 + "|" + v48 + "|" + v49;
	}




}
