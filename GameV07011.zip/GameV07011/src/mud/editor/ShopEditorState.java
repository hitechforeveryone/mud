package mud.editor;

public enum ShopEditorState {
    MAIN_MENU,
    SET_BUY_MOD,
    SET_SELL_MOD,
    SET_MAX_COPPER,
    TOGGLE_BUYS,
    TOGGLE_SELLS,
    ADD_ITEM,
    REMOVE_ITEM
}

