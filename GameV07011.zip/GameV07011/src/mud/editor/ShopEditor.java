package mud.editor;

import mud.Shop.*;
import mud.core.*;

import java.util.*;

public class ShopEditor implements Editor {

    private final Mob mob;
    private final Player player;
    private boolean finished = false;

    private ShopEditorState state = ShopEditorState.MAIN_MENU;

    public ShopEditor(Mob mob, Player player) {
        this.mob = mob;
        this.player = player;

        // Ensure mob has a ShopProfile
        if (mob.getShopProfile() == null) {
            mob.setShopProfile(new ShopProfile());
        }

        // Ensure SHOPKEEPER flag
        if (!mob.hasBehavior(MobBehaviorFlag.SHOPKEEPER)) {
            mob.addBehavior(MobBehaviorFlag.SHOPKEEPER);
        }

        player.sendMessage("Now editing shop for mob: " + mob.getMobName());
        displayMenu();
    }

    @Override
    public void startEditing() {
        displayMenu();
    }

    @Override
    public void handleInput(String input) {
        switch (state) {
            case MAIN_MENU -> handleMainMenu(input);
            case SET_BUY_MOD -> handleBuyMod(input);
            case SET_SELL_MOD -> handleSellMod(input);
            case SET_MAX_COPPER -> handleMaxCopper(input);
            case TOGGLE_BUYS -> handleToggleBuys(input);
            case TOGGLE_SELLS -> handleToggleSells(input);
            case ADD_ITEM -> handleAddItem(input);
            case REMOVE_ITEM -> handleRemoveItem(input);
        }
    }

    // ------------------ MAIN MENU ------------------
    private void handleMainMenu(String input) {
        switch (input) {
            case "1" -> showShopInfo();
            case "2" -> {
                state = ShopEditorState.SET_BUY_MOD;
                player.sendMessage("Enter new buy modifier (current: " + mob.getShopProfile().getBuyModifier() + "):");
            }
            case "3" -> {
                state = ShopEditorState.SET_SELL_MOD;
                player.sendMessage("Enter new sell modifier (current: " + mob.getShopProfile().getSellModifier() + "):");
            }
            case "4" -> {
                state = ShopEditorState.SET_MAX_COPPER;
                player.sendMessage("Enter max copper shopkeeper can hold (-1 = unlimited, current: " + mob.getShopProfile().getMaxCopper() + "):");
            }
            case "5" -> {
                state = ShopEditorState.TOGGLE_BUYS;
                showObjectTypeMenu(mob.getShopProfile().getBuys(), "Buys");
            }
            case "6" -> {
                state = ShopEditorState.TOGGLE_SELLS;
                showObjectTypeMenu(mob.getShopProfile().getSells(), "Sells");
            }
            case "7" -> listInventory();
            case "8" -> {
                state = ShopEditorState.ADD_ITEM;
                player.sendMessage("Enter object ID to add to shop inventory:");
            }
            case "9" -> {
                state = ShopEditorState.REMOVE_ITEM;
                listInventory();
                player.sendMessage("Enter inventory number to remove:");
            }
            case "10" -> {
                mob.getShopInventory().clear();
                player.sendMessage("Shop inventory cleared.");
                displayMenu();
            }
            case "11" -> {
            	save();
                finished = true;
                player.setEditor(null);
                player.sendMessage("Exiting ShopEditor.");
            }
            default -> displayMenu();
        }
    }

    private void displayMenu() {
        player.sendMessage("""
                --- Shop Editor: %s ---
                1) Show Shop Info
                2) Set Buy Modifier
                3) Set Sell Modifier
                4) Set Max Copper
                5) Toggle Buy Item Types
                6) Toggle Sell Item Types
                7) List Shop Inventory
                8) Add Item to Inventory
                9) Remove Item from Inventory
                10) Clear Inventory
                11) Back to Mob Editor
                Choose option:""".formatted(mob.getMobName()));
    }

    // ------------------ SHOP INFO ------------------
    private void showShopInfo() {
        ShopProfile profile = mob.getShopProfile();
        player.sendMessage("--- Shop Info ---");
        player.sendMessage("Buy Modifier: " + profile.getBuyModifier());
        player.sendMessage("Sell Modifier: " + profile.getSellModifier());
        player.sendMessage("Max Copper: " + profile.getMaxCopper());
        player.sendMessage("Buys: " + String.join(", ", profile.getBuysAsStrings()));
        player.sendMessage("Sells: " + String.join(", ", profile.getSellsAsStrings()));
        listInventory();
        displayMenu();
    }

    private void listInventory() {
        var inventory = mob.getShopInventory();
        if (inventory.isEmpty()) {
            player.sendMessage("Shop inventory is empty.");
            return;
        }
        player.sendMessage("--- Shop Inventory ---");
        int idx = 1;
        for (ObjectItem item : inventory) {
            int sellPrice = ShopManager.getSellPrice(mob, item);
            int buyPrice = ShopManager.getBuyPrice(mob, item);
            player.sendMessage(String.format("[%d] %s (ID %s) - Sell: %s, Buy: %s",
                    idx++, item.getShortDescription(), item.getObjID(),
                    formatCoins(sellPrice), formatCoins(buyPrice)));
        }
    }

    private static String formatCoins(int copper) {
        int gold = copper / 10000;
        copper %= 10000;
        int silver = copper / 100;
        copper %= 100;

        StringBuilder sb = new StringBuilder();
        if (gold > 0) sb.append(gold).append(" gold");
        if (silver > 0) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(silver).append(" silver");
        }
        if (gold == 0 && silver == 0) sb.append(copper).append(" copper");
        return sb.toString();
    }

    // ------------------ SHOP PROFILE SETTERS ------------------
    private void handleBuyMod(String input) {
        try {
            double mod = Double.parseDouble(input);
            mob.getShopProfile().setBuyModifier(mod);
            player.sendMessage("Buy modifier set to " + mod);
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input. Enter a decimal number.");
        }
        state = ShopEditorState.MAIN_MENU;
        displayMenu();
    }

    private void handleSellMod(String input) {
        try {
            double mod = Double.parseDouble(input);
            mob.getShopProfile().setSellModifier(mod);
            player.sendMessage("Sell modifier set to " + mod);
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input. Enter a decimal number.");
        }
        state = ShopEditorState.MAIN_MENU;
        displayMenu();
    }

    private void handleMaxCopper(String input) {
        try {
            int max = Integer.parseInt(input);
            mob.getShopProfile().setMaxCopper(max);
            player.sendMessage("Max copper set to " + max);
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input. Enter an integer.");
        }
        state = ShopEditorState.MAIN_MENU;
        displayMenu();
    }

    // ------------------ TOGGLE ITEM TYPES ------------------
    private void showObjectTypeMenu(Set<ObjectType> set, String title) {
        player.sendMessage("--- " + title + " Item Types ---");
        for (ObjectType type : ObjectType.values()) {
            player.sendMessage(" - " + type.name() + (set.contains(type) ? " [ON]" : " [off]"));
        }
        player.sendMessage("Enter item type to toggle, or 'back' to return:");
    }

    private void handleToggleBuys(String input) {
        handleToggleObjectType(input, mob.getShopProfile().getBuys());
    }

    private void handleToggleSells(String input) {
        handleToggleObjectType(input, mob.getShopProfile().getSells());
    }

    private void handleToggleObjectType(String input, Set<ObjectType> set) {
        if (input.equalsIgnoreCase("back")) {
            state = ShopEditorState.MAIN_MENU;
            displayMenu();
            return;
        }
        try {
            ObjectType type = ObjectType.valueOf(input.toUpperCase());
            if (set.contains(type)) {
                set.remove(type);
                player.sendMessage("Removed: " + type.name());
            } else {
                set.add(type);
                player.sendMessage("Added: " + type.name());
            }
        } catch (IllegalArgumentException e) {
            player.sendMessage("Invalid object type.");
        }
        showObjectTypeMenu(set, "Updating Types");
    }

    // ------------------ INVENTORY ------------------
    private void handleAddItem(String input) {
        try {
            ObjectItem item = WorldManager.loadObj(input);
            if (item == null) {
                player.sendMessage("Invalid object ID.");
            } else {
                mob.addShopItem(item);
                player.sendMessage("Added: " + item.getShortDescription());
            }
        } catch (Exception e) {
            player.sendMessage("Failed to add item: " + e.getMessage());
        }
        state = ShopEditorState.MAIN_MENU;
        displayMenu();
    }

    private void handleRemoveItem(String input) {
        try {
            int idx = Integer.parseInt(input);
            var inventory = mob.getShopInventory();
            if (idx < 1 || idx > inventory.size()) {
                player.sendMessage("Invalid inventory number.");
            } else {
                ObjectItem removed = inventory.remove(idx - 1);
                player.sendMessage("Removed: " + removed.getShortDescription());
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid input. Enter inventory number.");
        }
        state = ShopEditorState.MAIN_MENU;
        displayMenu();
    }

    @Override
    public void stopEditing() { finished = true; }
    @Override
    public void showMenu() { displayMenu(); }
    @Override
    public boolean save() {
        WorldManager.saveMob(mob);
        player.sendMessage("Mob saved.");
        return true;
    }
    @Override
    public String getEditorName() { return "ShopEditor for mob " + mob.getId(); }
    @Override
    public void tick() {}
    @Override
    public boolean isFinished() { return finished; }


}
