package mud.commands;

import java.util.*;

import mud.combat.*;
import mud.core.*;
import mud.spell.*;
import mud.spell.effects.*;

public class CombatSpellHandler {

	static String tName;
	
	public static String handleAssist(Mob assister) {
	    if (assister == null || assister.getCurrentRoom() == null) {
	        if (assister instanceof Player player) player.sendMessage("You can't assist from nowhere.");
	        return "You are nowhere and cannot assist anyone.";
	    }

	    Mob originalTarget = assister.getTarget();
	    if (originalTarget == null) {
	        if (assister instanceof Player player) player.sendMessage("You have no one to assist right now.");
	        return "No one to assist.";
	    }

	    Mob assistTarget = originalTarget.getTarget(); // The foe of the person you're assisting
	    if (assistTarget == null || assistTarget.isDead()) {
	        if (assister instanceof Player player) player.sendMessage("Your ally has no current target, or the target is dead.");
	        return "No valid target to attack.";
	    }

	    if (assistTarget == assister) {
	        if (assister instanceof Player player) player.sendMessage("You cannot attack yourself.");
	        return "Cannot attack yourself.";
	    }

	    if (assister instanceof Player player && !player.canAttack()) {
	        player.sendMessage("You are still recovering from your last attack!");
	        return "";
	    }

	    assister.setTarget(assistTarget); // Mark assister as engaged with the same target
	    if (assistTarget.getTarget() == null) assistTarget.setTarget(assister); // Mob sees who attacked

	    if (assister instanceof Player player) player.setLastAttackTime();

	    return CombatManager.performAttack(assister, assistTarget);
	}

	

	
	static String handleAttack(Mob player, String targetInput) {
		if (player == null || player.getCurrentRoom() == null) {
			return "You're nowhere and can't attack anything.";
		}

		Room room = player.getCurrentRoom();

		// Parse input like "2.goblin"
		int targetIndex = 1;
		String keyword = targetInput.toLowerCase();

		if (targetInput.contains(".")) {
			String[] parts = targetInput.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// fallback: treat whole string as keyword
				targetIndex = 1;
				keyword = targetInput.toLowerCase();
			}
		}

		// Find matching mobs by keyword
		List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
		if (matchingMobs.size() < targetIndex) {
			return "No such target.";
		}

		Mob target = matchingMobs.get(targetIndex - 1);

		if (target == player) return "You can't attack yourself.";
		if (!player.canAttack()) {
			player.sendMessage("You're still recovering from your last attack!");
			return "";
		}

		player.setLastAttackTime();

		// Mark both as engaged in combat
		player.setTarget(target);
		if (target.getTarget() == null) {
			target.setTarget(player); // Mob knows who attacked it
		}

		
		return CombatManager.performAttack(player, target);
	}


	public static boolean handleShortCast(Player player, String[] tokens) {
	    if (player == null || tokens == null || tokens.length == 0) return false;

	    String spellName = tokens[0].toLowerCase();
	    String targetName = (tokens.length > 1)
	            ? String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length)).toLowerCase()
	            : null;

	    Spell spell = SpellManager.getSpellByName(spellName);
	    if (spell == null) return false; // Not a spell/ability, let normal command flow continue

	    // Only shortcut abilities / instant casts
	    if (!spell.isAbility() && !spell.isInstantCast()) return false;

	    // Profession restriction
	    if (player.getPrivilegeLevel() == 0) {
	        Profession prof = player.getProfession();
	        if (prof == null || !spell.getProfessions().contains(prof)) {
	            player.sendMessage("You lack the training to use that ability.");
	            return true;
	        }
	    }

	    // --- Unified casting restriction check ---
	 // For abilities, ignore room quiet and silence
	    String restrictionMsg = checkCastingRestrictions(player, true, true);
	    if (restrictionMsg != null) {
	        player.sendMessage(restrictionMsg);
	        return true;
	    }


	    Room room = player.getCurrentRoom();
	    if (room == null) {
	        player.sendMessage("You are nowhere.");
	        return true;
	    }

	    // Auto self-target
	    if ((targetName == null || targetName.isEmpty()) && spell.isSelfTarget()) {
	        if (!spell.cast(player, player)) player.sendMessage("Your ability fails.");
	        return true;
	    }

	    if (targetName == null || targetName.isEmpty()) {
	        player.sendMessage(spell.getName() + " on whom?");
	        return true;
	    }

	    // Try to resolve target
	    if (attemptCastOnTargets(player, spell, targetName)) return true;

	    player.sendMessage("You see no such target.");
	    return true;
	}

	// ---------------------------------------------------
	// Unified handleCast with casting restriction check
	// ---------------------------------------------------
	public static String handleCast(Player player, String spellName, String targetName) {
	    if (player == null || spellName == null || spellName.isEmpty()) return "Cast what?";

	    Spell spell = SpellManager.getSpellByName(spellName.toLowerCase());
	    if (spell == null) return "No such spell exists.";

	    // Profession restriction
	    if (player.getPrivilegeLevel() == 0) {
	        Profession prof = player.getProfession();
	        if (prof == null || !spell.getProfessions().contains(prof))
	            return "You lack the knowledge to cast that spell.";
	    }

	    // --- Unified casting restriction check ---
	 // Normal spells: respect room quiet and silence
	    String restrictionMsg = checkCastingRestrictions(player, false, false);
	    if (restrictionMsg != null) return restrictionMsg;


	    // Mana check
	    if (spell.getManaCost() > player.getCurrentMP())
	        return "You lack the mana to cast that spell.";

	    Room room = player.getCurrentRoom();
	    if (room == null) return "You are nowhere.";

	    // Self-target auto-cast
	    if ((targetName == null || targetName.isEmpty()) && spell.isSelfTarget()) {
	        if (!spell.cast(player, player)) return "Your spell fizzles.";
	        player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
	        return "You cast " + spell.getName() + ".";
	    }

	    if (targetName == null || targetName.isEmpty())
	        return spell.getName() + " on what?";

	    // Resolve target and cast
	    boolean success = attemptCastOnTargets(player, spell, targetName);
	    if (!success) return "You see no such target.";

	    player.setCurrentMP(player.getCurrentMP() - spell.getManaCost());
	    return "You cast " + spell.getName() + ".";
	}

	// ---------------------------------------------------
	// Helper method: try casting on various targets
	// ---------------------------------------------------
	private static boolean attemptCastOnTargets(Player player, Spell spell, String targetName) {
	    Room room = player.getCurrentRoom();
	    int typeFilter = -1;

	    // Parse numbered prefix "2.goblin"
	    String tName = targetName.toLowerCase();
	    if (tName.matches("^\\d+\\..+")) {
	        int dotIndex = tName.indexOf('.');
	        try {
	            typeFilter = Integer.parseInt(tName.substring(0, dotIndex));
	            tName = tName.substring(dotIndex + 1);
	        } catch (NumberFormatException ignored) {}
	    }

	    String[] sections = tName.split("\\.");

	    // --- 1) MOB in room ---
	    if (typeFilter == -1 || typeFilter == 1) {
	        for (Mob mob : room.getMobs()) {
	            if (mob != null && matchesSections(mob.getMobName(), mob.getKeywords(), sections)) {
	                if (mob.isDead()) {
	                    player.sendMessage(mob.getMobName() + " is already dead.");
	                    return true;
	                }
	                spell.cast(player, mob);
	                return true;
	            }
	        }
	    }

	    // --- 2) Specialized spells: LocateCreature / LocateObject ---
	    if (typeFilter == -1 || typeFilter == 2) {
	        if (spell instanceof LocateCreatureSpell lc) return lc.cast(player, sections);
	        if (spell instanceof LocateObjectSpell lo) return lo.cast(player, sections);
	    }

	    // --- 3) Inventory objects ---
	    if (typeFilter == -1 || typeFilter == 3) {
	        ObjectItem invObj = player.getInventory().stream()
	                .filter(o -> matchesSections(o.getName(), o.getKeywords(), sections))
	                .findFirst().orElse(null);
	        if (invObj != null) {
	            spell.cast(player, invObj);
	            return true;
	        }
	    }

	    // --- 4) Room objects ---
	    if (typeFilter == -1 || typeFilter == 4) {
	        ObjectItem roomObj = room.getObjects().stream()
	                .filter(o -> matchesSections(o.getName(), o.getKeywords(), sections))
	                .findFirst().orElse(null);
	        if (roomObj != null) {
	            spell.cast(player, roomObj);
	            return true;
	        }
	    }

	    // --- 5) Directional ---
	    if ((typeFilter == -1 || typeFilter == 5) && spell.isDirectional()) {
	        Direction dir = Direction.fromString(tName);
	        if (dir != null) {
	            Room next = room.getExit(dir);
	            if (next == null) {
	                player.sendMessage("No such direction exists.");
	                return true;
	            }
	            spell.cast(player, dir);
	            return true;
	        }
	    }

	    return false;
	}


    // ======================================================
    // Checks if all sections match in order in name or keywords
    // ======================================================
 // Checks if all sections match in order in name or keywords
    public static boolean matchesSections(String name, Collection<String> keywords, String[] sections) {
        name = name.toLowerCase();
        for (String section : sections) {
            boolean found = name.contains(section);
            if (!found && keywords != null) {
                found = keywords.stream().anyMatch(k -> k.toLowerCase().contains(section));
            }
            if (!found) return false;
        }
        return true;
    }


	public static Mob findMobTarget(Room room, String input) {
		if (room == null || input == null || input.isEmpty())
			return null;

		input = input.toLowerCase().trim();
		List<Mob> mobs = room.getMobs();
		if (mobs.isEmpty()) return null;

		int index = 1; // default
		String search = input;

		// ----- Parse numbered format: "2.orc" -----
		if (input.contains(".")) {
			String[] parts = input.split("\\.", 2);
			try {
				index = Integer.parseInt(parts[0]);
				search = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// treat as normal multi-keyword chain
				index = 1;
				search = input;
			}
		}

		// Split multi-keyword chain (orc.elder → ["orc","elder"])
		String[] chain = search.split("\\.");

		List<Mob> matches = new ArrayList<>();

		for (Mob mob : mobs) {
			String mobName = mob.getMobName().toLowerCase();
			List<String> keywords = mob.getKeywords().stream()
					.map(String::toLowerCase)
					.toList();

			boolean match = false;

			// 1. Exact name match
			if (mobName.equals(search)) match = true;

			// 2. Exact keyword match
			if (!match && keywords.contains(search)) match = true;

			// 3. Multi-keyword chain match
			if (!match && chain.length > 1) {
				boolean chainMatch = true;
				for (String word : chain) {
					if (!(mobName.contains(word) || keywords.contains(word))) {
						chainMatch = false;
						break;
					}
				}
				if (chainMatch) match = true;
			}

			// 4. Prefix/partial match
			if (!match) {
				if (mobName.startsWith(search)) match = true;
				else {
					for (String kw : keywords) {
						if (kw.startsWith(search)) {
							match = true;
							break;
						}
					}
				}
			}

			if (match) matches.add(mob);
		}

		if (matches.isEmpty()) return null;

		// numbered selection: "2.orc"
		if (index > 1) {
			if (index <= matches.size()) {
				return matches.get(index - 1);
			}
			return null; // requested index out of range
		}

		// default: return first match
		return matches.get(0);
	}

	public static String handleTarget(Mob caster, String targetName) {
		if (caster == null || caster.getCurrentRoom() == null || targetName == null) {
			return null;
		}

		Room room = caster.getCurrentRoom();

		// Parse input like "2.goblin"
		int targetIndex = 1;
		String keyword = targetName.toLowerCase();

		if (targetName.contains(".")) {
			String[] parts = targetName.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// fallback: treat whole string as keyword
				targetIndex = 1;
				keyword = targetName.toLowerCase();
			}
		}

		// Find matching mobs by keyword
		List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
		if (matchingMobs == null || matchingMobs.size() < targetIndex) {
			if (caster instanceof Player player) {
				player.sendMessage("No such target.");
			}
			return null;
		}

		Mob target = matchingMobs.get(targetIndex - 1);
		if (target == caster) {
			if (caster instanceof Player player) {
				player.sendMessage("You cannot target yourself.");
				//   return "You cannot target yourself.";
			}
			return null;
		}

		caster.setTarget(target);
		if (caster instanceof Player player) {
			player.sendMessage("You target " + target.getMobName() + ".");
		}
		return null;
	} // end handTarget
	
	
	public static String handleSpell(Player player) {
		StringBuilder sb = new StringBuilder();

		Profession prof = player.getProfession();
		if (prof == null) {
			return "You have no profession and therefore no spells.";
		}

		// Fetch all spells associated with this profession
		Collection<Spell> all =
				SpellRegister.getInstance().getSpellsForProfession(prof);

		if (all == null || all.isEmpty()) {
			return "You have no spells or abilities for your profession.";
		}

		List<Spell> abilities = new ArrayList<>();
		List<Spell> spellList = new ArrayList<>();

		for (Spell sp : all) {
			if (sp.isAbility()) {
				abilities.add(sp);
			} else {
				spellList.add(sp);
			}
		}

		// Alphabetical sorting
		abilities.sort(Comparator.comparing(Spell::getName));
		spellList.sort(Comparator.comparing(Spell::getName));

		sb.append("Abilities:\n");
		if (abilities.isEmpty()) {
			sb.append(" (none)\n");
		} else {
			for (Spell ab : abilities) {
				sb.append(" ")
				.append(ab.getName())
				.append(" - ")
				.append(ab.getDescription())
				.append("\n");
			}
		}

		sb.append("\nSpells:\n");
		if (spellList.isEmpty()) {
			sb.append(" (none)\n");
		} else {
			for (Spell sp : spellList) {
				sb.append(" ")
				.append(sp.getName())
				.append(" - ")
				.append(sp.getDescription())
				.append("\n");
			}
		}

		return sb.toString();
	} // end
	

	public static void handleEnter(Player player, String args) {
		Room room = player.getCurrentRoom();
		if (room == null) return;

		List<Effect> effects = room.getEffects();
		if (effects == null || effects.isEmpty()) {
			player.sendMessage("There is no portal or wormhole here.");
			return;
		}

		PortalEffect portal = null;
		WormholeEffect wormhole = null;

		for (Effect e : effects) {
			if (e instanceof WormholeEffect w) {
				wormhole = w;
				break;
			}
			if (e instanceof PortalEffect p) {
				portal = p;
				break;
			}
		}

		if (portal == null && wormhole == null) {
			player.sendMessage("There is no portal or wormhole here to enter.");
			return;
		}

		Room destination = null;

		if (wormhole != null) {
			destination = wormhole.getDestinationRoom();
		} else if (portal != null) {
			destination = portal.getDestinationRoom();
		}

		if (destination == null) {
			player.sendMessage("The rift flickers and leads nowhere.");
			return;
		}

		// Themed messages
		if (wormhole != null) {
			player.sendMessage("You step into the crackling mechanical wormhole...");
			room.broadcast(player.getName() + " is swallowed by a vortex of gears and lightning!", player);
		} else {
			player.sendMessage("You step into the shimmering portal...");
			room.broadcast(player.getName() + " steps into the shimmering portal and vanishes.", player);
		}

		destination.addMob(player);
		room.removeMob(player);
		player.setRoom(destination);
		player.setCurrentRoom(destination);

		if (wormhole != null) {
			destination.broadcast(player.getName() + " erupts from a twisting wormhole of metal and crackling energy!", player);
			player.sendMessage("You emerge from a vortex of gears and electric arcs.");
		} else {
			destination.broadcast(player.getName() + " materializes from a glowing portal.", player);
			player.sendMessage("You emerge from a glowing portal.");
		}
	}


	public static void handleSeal(Player player, String args) {

		Room room = player.getCurrentRoom();
		if (room == null) return;

		List<Effect> effects = room.getEffects();
		if (effects == null || effects.isEmpty()) {
			player.sendMessage("There is no portal or wormhole here to seal.");
			return;
		}

		PortalEffect portal = null;
		WormholeEffect wormhole = null;

		for (Effect e : effects) {
			if (e instanceof WormholeEffect w) {
				wormhole = w;
				break;
			}
			if (e instanceof PortalEffect p) {
				portal = p;
				break;
			}
		}

		if (portal == null && wormhole == null) {
			player.sendMessage("There is no portal or wormhole here to seal.");
			return;
		}

		// ----- WORMHOLE -----
		if (wormhole != null) {

			String id = wormhole.getWormholeId();
			Room otherRoom = wormhole.getToRoom();

			// Find matching wormhole in the destination room
			WormholeEffect counterpart = null;
			for (Effect e : otherRoom.getEffects()) {
				if (e instanceof WormholeEffect w && w.getWormholeId().equals(id)) {
					counterpart = w;
					break;
				}
			}

			// Remove both copies properly
			room.removeRoomEffect(wormhole);
			wormhole.expire(room);

			if (counterpart != null) {
				otherRoom.removeRoomEffect(counterpart);
				counterpart.expire(otherRoom);
			}

			room.broadcastToRoom("The mechanical wormhole screeches, sparks violently, and implodes!");
			otherRoom.broadcastToRoom("The mechanical wormhole screeches, sparks violently, and implodes!");

			player.sendMessage("You force the wormhole to collapse.");
			return;
		}

		// ----- PORTAL -----
		if (portal != null) {

			Room otherRoom = portal.getDestinationRoom();
			PortalEffect counterpart = null;

			// Find the matching portal on the other side
			for (Effect e : otherRoom.getEffects()) {
				if (e instanceof PortalEffect p2 && p2.getDestinationRoom() == room) {
					counterpart = p2;
					break;
				}
			}

			room.removeRoomEffect(portal);
			portal.expire(room);

			if (counterpart != null) {
				otherRoom.removeRoomEffect(counterpart);
				counterpart.expire(otherRoom);
			}

			room.broadcastToRoom("The shimmering portal collapses in on itself!");
			otherRoom.broadcastToRoom("The shimmering portal collapses in on itself!");

			player.sendMessage("You seal the portal.");
		}
	}
	
	

	public static boolean isCastingBlocked(Mob mob, Room room) {
		
		if (room == null) return true;
		
		if (room.hasFlag(RoomFlag.QUIET)) { 
			return true;
		}
		if (room.hasEffect(SilenceEffect.class)) {
			return true;
		}
		
	    if (mob.hasEffect(EffectType.STUN)) return true; // stunned
	    if (mob.hasEffect(EffectType.SILENCE)) return true; // silenced
	    if (mob.hasEffect(EffectType.FEAR)) return true; // feared
	    if (mob.hasEffect(EffectType.CONFUSE)) return true; // confused
	    if (mob.hasEffect(EffectType.DISORIENT)) return true; // disoriented
	    
		return false;
	}
    /**
     * --- Player-facing check: returns message if casting is blocked ---
     */
	// Unified casting restriction check
	// ignoreRoomQuiet -> skip room quiet check
	// ignoreSilence -> skip player silenced effect check
	public static String checkCastingRestrictions(Mob mob, boolean ignoreRoomQuiet, boolean ignoreSilence) {
	    Room room = mob.getCurrentRoom();
	    if (room == null) return "You are nowhere.";

	    if (!ignoreRoomQuiet && room.hasFlag(RoomFlag.QUIET)) {
	        return "You cannot cast here. The room is quieted.";
	    }

	    if (room.hasEffect(SilenceEffect.class)) {
	        return "You try to cast, but a magical silence prevents you!";
	    }

	    if (mob.hasEffect(EffectType.STUN)) return "💪 You are stunned and cannot cast!";
	    if (!ignoreSilence && mob.hasEffect(EffectType.SILENCE)) return "💫 You are silenced and cannot cast!";
	    if (mob.hasEffect(EffectType.FEAR)) return "😱 You are too afraid to cast!";
	    if (mob.hasEffect(EffectType.CONFUSE)) return "😵 You are confused and fail to cast!";
	    if (mob.hasEffect(EffectType.DISORIENT)) return "😵 You are disoriented and cannot focus!";

	    return null; // allowed
	}

	
	
} // end
