package mud.core;

public enum TreasureValue {

}
