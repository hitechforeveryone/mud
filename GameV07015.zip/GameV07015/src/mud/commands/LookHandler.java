package mud.commands;

import java.util.*;
import java.util.stream.Collectors;

import mud.combat.*;
import mud.core.*;
import mud.spell.effects.*;
import mud.system.GameClock;

public class LookHandler {

	public static void handleLook(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are nowhere.");
			return;
		}

		Room room = player.getCurrentRoom();

		if (args.length < 2 || args[0].equalsIgnoreCase("look") && args.length == 1) {
			lookRoom(player, room);
			return;
		}

		String combinedTarget = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		int targetIndex = 1;
		String keyword = combinedTarget;

		if (combinedTarget.contains(".")) {
			String[] parts = combinedTarget.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1];
			} catch (NumberFormatException e) {
				targetIndex = 1;
			}
		}



		List<ObjectItem> matches = room.findObjectsByKeyword(keyword);
		if (matches.size() >= targetIndex) {
			ObjectItem targetItem = matches.get(targetIndex - 1);
			if (targetItem != null && targetItem.getName().toLowerCase().contains("corpse")) {
				if (targetItem.getContents() != null && !targetItem.getContents().isEmpty()) {
					String contents = targetItem.getContents().stream()
							.map(ObjectItem::getShortDescription)
							.collect(Collectors.joining(", "));
					player.sendMessage("Inside the corpse you see: " + contents);
				} else {
					player.sendMessage("The corpse is empty.");
				}
				return;
			}
		}



		// 1. Direction Look
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(keyword)) {
				Room nextRoom = room.getExit(dir);
				if (nextRoom == null) {
					player.sendMessage("There is nothing in that direction.");
					return;
				}

				if (room.isDark() || room.isNightTime()) {
					player.sendMessage("It is too dark to see.");
					return;
				}

				Door door = room.getDoor(dir);
				if (door != null && door.isClosed()) {
					player.sendMessage("You see " + door.getShortDescription() + ".");
					if (door.isLocked()) player.sendMessage("It is locked.");
					return;
				}

				player.sendMessage("You see " + nextRoom.getShortDescription() + ".");
				return;
			}
		}

		// 2. Door Look
		List<Door> matchingDoors = room.getMatchingDoors(keyword);
		if (!matchingDoors.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingDoors.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			Door door = matchingDoors.get(targetIndex - 1);
			player.sendMessage(door.getFullDescription());
			return;
		}

		// 3. Mob Look
		List<Mob> matchingMobs = room.getMatchingMobs(keyword, player);
		if (!matchingMobs.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingMobs.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			Mob mob = matchingMobs.get(targetIndex - 1);
			lookMob(player, mob);
			return;
		}

		// 4. Object Look
		List<ObjectItem> matchingItems = room.getMatchingObjects(keyword);
		if (!matchingItems.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingItems.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			ObjectItem item = matchingItems.get(targetIndex - 1);
			lookObject(player, item);
			return;
		}




		player.sendMessage("You don't see anything like that here.");
	} // end handleLook

	public static void lookRoom(Player player, Room room) {
	    StringBuilder sb = new StringBuilder();
	    StringBuilder att = new StringBuilder();

	    // Room flags
	    Set<RoomFlag> flags = room.getFlags();
	    String flagsString = flags.isEmpty() ? "None" :
	        flags.stream().map(Enum::name).map(String::toLowerCase).collect(Collectors.joining(", "));

	    // Room attributes (basic ones)
	    List<String> attrs = new ArrayList<>();
	    if (room.isOutside()) attrs.add("outside");
	    if (attrs.isEmpty()) att.append("none");
	    else att.append(String.join(", ", attrs));

	    // Check if player has a light source
	 // Check if player has a light source
	    ObjectItem light = player.getEquippedItem(EquipSlot.LIGHTSOURCE);
	    boolean hasLight = light != null && (light.getDuration() == -1 || light.getDuration() > 0);

	    boolean canSee;
	    boolean tooDark;

	    int lightLevel = room.getLightLevel();

	    if (player.hasEffect(EffectType.BLIND)) {
	        canSee = false;
	        tooDark = true;
	    }
	    else if (lightLevel == 0) {
	        // Pitch dark
	    	 canSee = hasLight;

	        // Only outside rooms care about night darkness
	        tooDark = room.isOutside() && room.isNightTime() && !canSee;
	    }
	    else {
	        // Any light level >= 1 allows vision
	        canSee = true;
	        tooDark = false;
	    }


	    switch (room.getLightLevel()) {
	        case 0 -> { // pitch dark
	        	 canSee = hasLight;

	          //  tooDark = room.isOutside() && !canSee;
	        }
	        case 1 -> { // moonlit / dim
	            canSee = true; // can see roughly
	            tooDark = false;
	        }
	        case 2, 3 -> { // daylight or magical
	            canSee = true;
	            tooDark = false;
	        }
	        default -> { // fallback
	            canSee = false;
	            tooDark = true;
	        }
	    }

	    // Room ID & Name
	    sb.append("[").append(room.getId()).append("] ").append(Ansi.BOLD)
	      .append(AdminCommandHandler.capitalize( room.getName())).append(Ansi.RESET).append("\n");

	    if (player.hasEffect(EffectType.BLIND)) {
	        sb.append("You have been blinded.\n");
	        roomFlagsAtts(room, sb, flagsString, att);
	    }
	    else if (tooDark && !canSee && room.isOutside()) {
	        sb.append("It is too dark to see.\n");
	        roomFlagsAtts(room, sb, flagsString, att);
	    }
	    else {
	        sb.append(room.getFullDescription()).append("\n");
	        roomFlagsAtts(room, sb, flagsString, att);

	     // Exits
	        List<String> exits = new ArrayList<>();

	        for (Direction dir : Direction.values()) {

	            // Local exit
	            if (room.getExit(dir) != null) {
	                exits.add(dir.name().toLowerCase());
	                continue;
	            }

	            // Cross-zone exit (TRANSIENT)
	            ZoneExit ze = room.getZoneExit(dir);
	            if (ze != null && ze.isActive(GameClock.getCurrentTick())) {
	                exits.add(dir.name().toLowerCase());
	            }
	            if (ze != null && !ze.isActive(GameClock.getCurrentTick())) {
	                 sb.append("[DEBUG inactive exit ").append(dir).append("]\n");
	            }
	        }

	        sb.append(exits.isEmpty()
	            ? "There are no obvious exits.\n"
	            : "Exits: " + String.join(", ", exits) + "\n");

	        // Doors
	        for (Direction dir : Direction.values()) {
	            Door door = room.getDoor(dir);
	            
	            if (door != null && !door.isHidden()) {
	                sb.append("To the ").append(dir.name().toLowerCase()).append(" is a ")
	                  .append(door.isClosed() ? "closed" : "open")
	                  .append(" door: ").append(door.getShortDescription()).append("\n");
	            }
	            
	            
	            
	            doorBarrierVisuals(room, sb, dir);
	        }

	        // Portals
	        portalVisuals(room, sb);

	        // Mobs
	        for (Mob mob : room.getMobs()) {
	            if (mob != null && !mob.getMobName().equalsIgnoreCase(player.getName())) {
	                sb.append("You see ").append(mob.getShortDescription());
	                mobSpellVisuals(mob, sb);
	                sb.append(".\n");
	            }
	        }

	        // Objects
	        for (ObjectItem item : room.getObjects()) {
	            sb.append("There is ").append(item.getShortDescription()).append(" here.")
	              .append(objVisuals(item)).append("\n");
	        }

	        sb.append("\n");
	    }

	    // Player status bar
	    sb.append(CombatFormatter.formatBuffs(player))
	      .append(CombatFormatter.formatDebuffs(player)).append(".\n")
	      .append(AdminCommandHandler.capitalize(player.getName()))
	      .append(":HP: ").append(player.getCurrentHP()).append("/").append(player.getMaxHP())
	      .append(" MP: ").append(player.getCurrentMP()).append("/").append(player.getMaxMP());

	    if (player.getTarget() != null && !player.getTarget().isDead()) {
	        sb.append("  ").append(AdminCommandHandler.capitalize( player.getTarget().getMobName()))
	          .append(":HP: ").append(player.getTarget().getCurrentHP()).append("/").append(player.getTarget().getMaxHP())
	          .append(" MP: ").append(player.getTarget().getCurrentMP()).append("/").append(player.getTarget().getMaxMP());
	    }

	    sb.append("\n");

	    player.sendMessage(sb.toString());

	} // end lookRoom


	private static void roomFlagsAtts(Room room, StringBuilder sb, String flagsString, StringBuilder att ) {
		// TODO Auto-generated method stub

		sb.append("Flags: ").append(flagsString).append("\n"); // to be muted later
		sb.append("Attributes: ").append(att.toString()).append("\n"); // end
	}

	private static void doorBarrierVisuals(Room room, StringBuilder sb, Direction dir) {
		// TODO Auto-generated method stub
		// ----------- ICE WALL VISUAL ------------
		if (room.hasEffectOnExit(dir, IcewallEffect.class)) {
			sb.append("A thick wall of ice blocks the way to the ")
			.append(dir.name().toLowerCase()).append(". ❄️\n");
		}
		// ----------- Fortify VISUAL ------------
		if (room.hasEffectOnExit(dir, FortifyEffect.class)) {
			sb.append("A fortification of steel blocks the way to the ")
			.append(dir.name().toLowerCase()).append(". ⚙️\n");
		}  
		// ----------- Rampart VISUAL ------------
		if (room.hasEffectOnExit(dir, RampartEffect.class)) {
			sb.append("A stone rampart blocks the way to the ")
			.append(dir.name().toLowerCase()).append(". 🌍\n");
		}
		// ----------- Flame Barrier VISUAL ------------
		if (room.hasEffectOnExit(dir, FlameBarrierEffect.class)) {
			sb.append("A barrier of flames blocks the way to the ")
			.append(dir.name().toLowerCase()).append(". 🔥\n");
		}	            

		// put other room exit-block visual types here

	}

	private static StringBuilder portalVisuals(Room room, StringBuilder sb) {

	    for (Effect effect : room.getEffects()) {

	        // ------------------- PORTAL -------------------
	        if (effect instanceof PortalEffect portal) {
	            Room destination = portal.getDestination();
	            String destName = destination != null ? destination.getName() : "somewhere unknown";

	            sb.append("A shimmering ")
	              .append(Ansi.CYAN).append("portal").append(Ansi.RESET)
	              .append(" stands here, linking to ")
	              .append(destName)
	              .append(". 🌐\n");
	        }

	        // ------------------- WORMHOLE -------------------
	        else if (effect instanceof WormholeEffect wormhole) {
	            Room destination = wormhole.getDestination();
	            String destName = destination != null ? destination.getName() : "an unstable location";

	            sb.append("Gears grind and rotate within a ")
	              .append(Ansi.MAGENTA).append("mechanical wormhole").append(Ansi.RESET)
	              .append(" leading to ")
	              .append(destName)
	              .append(". 🌐\n");
	        }
	        
	        // ------------------- INTERSPATIAL TUNNEL -------------------
	        else if (effect instanceof InterspatialTunnelEffect tunnel) {
	            Room destination = tunnel.getDestinationRoom();
	            String destName = destination != null ? destination.getName() : "a distant world";

	            sb.append("A shimmering ")
	              .append(Ansi.YELLOW).append("interspatial tunnel").append(Ansi.RESET)
	              .append(" hums with energy, connecting to ")
	              .append(destName)
	              .append(". 🌌\n");
	        }
	        
	        
	        // other portal-type visuals
	        
	    }
	    	
	    return sb;
	}


	private static StringBuilder mobSpellVisuals(Mob mob, StringBuilder sb) {

	    if (mob.getEffect(FireShieldEffect.class) != null) {
	        sb.append(" ").append(Ansi.RED).append("[Fire Shield]").append(Ansi.RESET);
	    }

	    Effect mi = mob.getEffect(MirrorImageEffect.class);
	    if (mi != null && mi.getVisualCount() > 0) {
	        sb.append(" ").append(Ansi.LIGHT_GREY)
	          .append("[Mirror Images x").append(mi.getVisualCount()).append("]")
	          .append(Ansi.RESET);
	    }

	    Effect sc = mob.getEffect(ShadowCloneEffect.class);
	    if (sc != null && sc.getVisualCount() > 0) {
	        sb.append(" ").append(Ansi.GREY)
	          .append("[Shadow Clones x").append(sc.getVisualCount()).append("]")
	          .append(Ansi.RESET);
	    }

	    Effect bs = mob.getEffect(BoneShieldEffect.class);
	    if (bs != null && bs.getVisualCount() > 0) {
	        sb.append(" ").append(Ansi.GREY)
	          .append("[Bone Shields x").append(bs.getVisualCount()).append("]")
	          .append(Ansi.RESET);
	    }

	    // add more Mob Spell Visuals here (Sanctuary, etc.)

	    return sb;
	}


	static StringBuilder objVisuals(ObjectItem item) {
	    StringBuilder sb = new StringBuilder();
	    
	    // these are driven from the Enum
	    for (ItemEffect effect : ItemEffect.values()) {
	        if (item.hasEffect(effect)) {
	            sb.append(" ")
	              .append(effect.getColor())
	              .append(effect.getVisualText())
	              .append(effect.getEmoji())
	              .append(Ansi.RESET);
	        }
	    }

	    return sb;
	}


	private static void lookMob(Player player, Mob mob) {
		StringBuilder sb = new StringBuilder();
		sb.append(Ansi.BOLD).append(mob.getMobName()).append(Ansi.RESET).append("\n");
		sb.append(mob.getLongDescription()).append("\n");


		// Spell Buffs 
		// TODO


		// Equipment
		Map<EquipSlot, ObjectItem> equipment = mob.getEquipment();
		boolean anyEquipped = equipment.values().stream().anyMatch(Objects::nonNull);
		if (anyEquipped) {
			sb.append("Equipped:\n");
			for (Map.Entry<EquipSlot, ObjectItem> entry : equipment.entrySet()) {
				if (entry.getValue() != null) {
					sb.append("  - ").append(entry.getKey().name().toLowerCase()).append(": ")
					.append(entry.getValue().getName()).append("\n");
				}
			}
		}

		// Inventory
		List<ObjectItem> inventoryItems = mob.getInventory();
		if (!inventoryItems.isEmpty()) {
			sb.append("Carrying:\n");
			for (ObjectItem item : inventoryItems) {
				sb.append("  - ").append(AdminCommandHandler.capitalize( item.getName())).append("\n");
			}
		}

		player.sendMessage(sb.toString());
	} // end lookMob

	private static void lookObject(Player player, ObjectItem item) {
		StringBuilder sb = new StringBuilder();
		String reset = Ansi.RESET;

		// Icon based on ObjectType
		String icon = switch (item.getType()) {
		case WEAPON -> "⚔️";
		case ARMOR -> "🛡️";
		case CONTAINER -> "📦";
		case POTION -> "🧪";
		case FOOD -> "🍗";
		case DRINK -> "🥤";
		case SCROLL -> "📜";
		case WAND -> "✨";
		case STAFF -> "🔮";
		case TREASURE -> "💰";
		case COIN -> "🪙";
		case LIGHTSOURCE -> "🕯️";
		case KEY -> "🗝️";
		case SIGN -> "📋";
		case TRASH -> "🗑️";
		case CONTROLLER -> "🎛️";
		case PART -> "⚙️";
		case NONE -> "📎";
		default -> "📎";
		};

		sb.append(Ansi.BOLD).append(icon).append(" ").append(AdminCommandHandler.capitalize( item.getName())).append(reset).append("\n");

		// Short/Long/Extended descriptions
		sb.append(item.getLongDescription()).append("\n");
		//sb.append(item.getExtDescription()).append("\n");

		// Optional info
		if (item.isStackable()) {
			sb.append("Stack: ").append(item.getStackCount());
			if (item.getMaxStackSize() > 0)
				sb.append(" / ").append(item.getMaxStackSize());
			sb.append("\n");
		}

		if (item.getDurability() > 0) {
			sb.append("Durability: ").append(item.getDurability()).append("\n");
		}

		if (item.getMaxCharges() > 0) {
			sb.append("Charges: ").append(item.getCharges()).append(" / ").append(item.getMaxCharges()).append("\n");
		}

		// Bonus stats (if any)
		List<String> bonuses = new ArrayList<>();
		if (item.getStrengthBonus() != 0) bonuses.add("Str +" + item.getStrengthBonus());
		if (item.getStaminaBonus() != 0) bonuses.add("Sta +" + item.getStaminaBonus());
		if (item.getAgilityBonus() != 0) bonuses.add("Agi +" + item.getAgilityBonus());
		if (item.getIntellectBonus() != 0) bonuses.add("Int +" + item.getIntellectBonus());
		if (item.getCharismaBonus() != 0) bonuses.add("Cha + " + item.getCharismaBonus());
		if (item.getHpBonus() > 0) bonuses.add("HP +" + item.getHpBonus());
		if (item.getMpBonus() > 0) bonuses.add("MP +" + item.getMpBonus());
		if (item.getHitrollBonus() != 0) bonuses.add("Hit +" + item.getHitrollBonus());
		if (item.getDamrollBonus() != 0) bonuses.add("Dam +" + item.getDamrollBonus());

		if (!bonuses.isEmpty()) {
			sb.append("Bonuses: ").append(String.join(", ", bonuses)).append("\n");
		}

		// Weapon info
		if (item.isWeapon()) {
			sb.append("Damage: ").append(item.getDiceCount()).append("d").append(item.getDiceSides());
			if (item.getDamageType() != null)
				sb.append(" ").append(item.getDamageType().name().toLowerCase());
			if (item.getWeaponType() != null)
				sb.append(" (").append(item.getWeaponType().name().toLowerCase()).append(")");
			sb.append("\n");
		}

		// Armor info
		if (item.isArmor()) {
			sb.append("Armor Type: ").append(item.getArmorType().name().toLowerCase()).append("\n");
		}

		player.sendMessage(sb.toString());
	} // end lookObject


	public static String handleExamine(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null || args.length < 2) {
			return "Examine what?";
		}

		String input = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		int index = 1;
		String keyword = input;

		// Parse "2.goblin" style input
		if (input.matches("^\\d+\\..+")) {
			String[] parts = input.split("\\.", 2);
			index = Integer.parseInt(parts[0]);
			keyword = parts[1].trim();
		}

		final int finalIndex = index;
		final String finalKeyword = keyword;
		Room room = player.getCurrentRoom();

		// Match mob by keyword or name
		List<Mob> mobMatches = room.getMobs().stream()
				.filter(m -> m.getMobName().equalsIgnoreCase(finalKeyword) || m.hasKeyword(finalKeyword))
				.collect(Collectors.toList());

		if (finalIndex <= mobMatches.size()) {
			examineMob(player, mobMatches.get(finalIndex - 1));
			return "";
		}

		// Match object by keyword or name
		List<ObjectItem> objMatches = room.getObjects().stream()
				.filter(o -> o.getName().equalsIgnoreCase(finalKeyword) || o.hasKeyword(finalKeyword))
				.collect(Collectors.toList());

		if (finalIndex <= objMatches.size()) {
			examineObject(player, objMatches.get(finalIndex - 1));
			return "";
		}

		return "You don't see that here.";
	}


	// --- Handle Consider ---
	public static String handleConsider(Player player, Mob target) {
	    if (target == null) return "Consider what?";

	    StringBuilder sb = new StringBuilder();
	    int playerLevel = player.getLevel();
	    int mobLevel = target.getLevel();
	    int levelDiff = mobLevel - playerLevel;
	    boolean isHigher = mobLevel > playerLevel;

	    boolean showFullStats = !isHigher;
	    boolean showPartialStats = isHigher && levelDiff <= 5;
	    boolean showIdentity = !isHigher || levelDiff <= 8;

	    if (player.hasEffect("blind")) {
	        return Ansi.BOLD + "You consider " + target.getMobName() + "..." + Ansi.RESET + "\n"
	               + "But you can't see a thing!\n";
	    }

	    sb.append(buildBoxHeader("Consider: " + target.getMobName()));

	    // Level & EXP
	    sb.append("║ Level: ")
	      .append(showIdentity
	              ? mobLevel + (mobLevel > playerLevel ? " (Stronger)" :
	                            mobLevel < playerLevel ? " (Weaker)" : " (Evenly matched)")
	                + "    EXP Reward: " + target.getExpReward()
	              : "???    EXP Reward: ???")
	      .append("\n");

	    // Effects
	    String effects = formatEffects(target.getActiveEffects());
	    if (!effects.isEmpty()) sb.append("║ Effects: ").append(effects).append("\n");

	    // Identity
	    sb.append("╠═════════ Identity ═══════════════════╣\n");
	    if (showFullStats || (isHigher && levelDiff <= 8)) {
	        sb.append("Race: ").append(target.getRace());
	        if (target.getSubrace() != null && !target.getSubrace().isBlank() && !target.getSubrace().equalsIgnoreCase("none"))
	            sb.append(" — Subrace: ").append(target.getSubrace());
	        sb.append("\n");
	    } else {
	        sb.append("Race: ???\n");
	    }
	    sb.append("Profession: ")
	      .append(showFullStats && target.getProfession() != null ? target.getProfession() : "???")
	      .append(" — Rank: ")
	      .append(showFullStats && target.getRank() != null ? target.getRank().name().replace('_',' ') : "???")
	      .append("\n");

	    // Stats
	    sb.append("╠═════════ Stats ══════════════════════╣\n");
	    if (showFullStats) {
	        sb.append("Str ").append(target.getStrength())
	          .append(", Sta ").append(target.getStamina())
	          .append(", Int ").append(target.getIntellect())
	          .append(", Agi ").append(target.getAgility())
	          .append(", Cha ").append(target.getCharisma())
	          .append("\n");
	    } else if (showPartialStats) {
	        sb.append("Str ???, Sta ???, Int ???, Agi ???, Cha ???\n");
	    } else {
	        sb.append("Str ????, Sta ????, Int ????, Agi ????, Cha ????\n");
	    }

	    sb.append(buildBoxFooter());

	    // Description
	    sb.append("╠═════════ Description ════════════════╣\n")
	      .append(target.getLongDescription()).append("\n")
	      .append(target.getExtendedDescription()).append("\n");

	    // Danger assessment
	    if (levelDiff == 0) sb.append("You and ").append(target.getMobName()).append(" are evenly matched.\n");
	    else if (levelDiff < 0) sb.append(target.getMobName()).append(" seems weaker than you.\n");
	    else if (levelDiff > 0 && levelDiff <= 3) sb.append(target.getMobName()).append(" might be a fair fight.\n");
	    else if (levelDiff > 3 && levelDiff <= 6) sb.append(target.getMobName()).append(" seems stronger than you.\n");
	    else sb.append("You sense great danger from ").append(target.getMobName()).append("...\n");

	    return sb.toString();
	}

	public static void examineMob(Player examiner, Mob target) {
	    if (examiner == null || target == null) return;

	    StringBuilder sb = new StringBuilder();
	    int playerLevel = examiner.getLevel();
	    int mobLevel = target.getLevel();
	    int levelDiff = mobLevel - playerLevel;
	    boolean isHigher = mobLevel > playerLevel;

	    boolean showFullStats = !isHigher;
	    boolean showPartialStats = isHigher && levelDiff <= 5;
	    boolean showIdentity = !isHigher || levelDiff <= 8;

	    if (examiner.hasEffect("blind")) {
	        examiner.sendMessage(Ansi.BOLD + "You examine " + target.getMobName() + "..." + Ansi.RESET +
	                            "\nBut you can't see a thing!");
	        return;
	    }

	    sb.append(buildBoxHeader("Examine: " + target.getMobName()));

	    // Level & EXP
	    sb.append("║ Level: ");
	    sb.append(showIdentity ? mobLevel + (mobLevel > playerLevel ? " (Stronger)" :
	                  mobLevel < playerLevel ? " (Weaker)" : " (Evenly matched)") +
	                  "    EXP Reward: " + target.getExpReward()
	                  : "???    EXP Reward: ???").append("\n");

	    // Effects
	    String effects = formatEffects(target.getActiveEffects());
	    if (!effects.isEmpty()) sb.append("║ Effects: ").append(effects).append("\n");

	    // Identity
	    sb.append("╠═════════ Identity ═══════════════════╣\n");
	    if (showFullStats || (isHigher && levelDiff <= 8)) {
	        sb.append("Race: ").append(target.getRace());
	        if (target.getSubrace() != null && !target.getSubrace().isBlank() && !target.getSubrace().equalsIgnoreCase("none"))
	            sb.append(" — Subrace: ").append(target.getSubrace());
	        sb.append("\n");
	    } else {
	        sb.append("Race: ???\n");
	    }
	    sb.append("Profession: ")
	      .append(showFullStats && target.getProfession() != null ? target.getProfession() : "???")
	      .append(" — Rank: ")
	      .append(showFullStats && target.getRank() != null ? target.getRank().name().replace('_',' ') : "???")
	      .append("\n");

	    // Stats
	    sb.append("╠═════════ Stats ══════════════════════╣\n");
	    if (showFullStats) {
	        sb.append("Str ").append(target.getStrength())
	          .append(", Sta ").append(target.getStamina())
	          .append(", Int ").append(target.getIntellect())
	          .append(", Agi ").append(target.getAgility())
	          .append(", Cha ").append(target.getCharisma())
	          .append("\n");
	    } else if (showPartialStats) {
	        sb.append("Str ??, Sta ??, Int ??, Agi ??, Cha ??\n");
	    } else {
	        sb.append("Str ????, Sta ????, Int ????, Agi ????, Cha ????\n");
	    }

	    // Equipment
	    sb.append("╠═════════ Equipment ══════════════════╣\n");
	    if (!target.getEquipment().isEmpty()) {
	        for (ObjectItem item : target.getEquipment().values()) {
	            if (item != null) sb.append("  ").append(item.getShortDescription()).append("\n");
	        }
	    } else sb.append("  None\n");

	    // Inventory
	    sb.append("╠═════════ Inventory ══════════════════╣\n");
	    sb.append(!target.getInventory().isEmpty() ? "  They are carrying several items.\n" : "  Inventory empty.\n");

	    sb.append(buildBoxFooter());

	    // Description
	    sb.append("╠═════════ Description ════════════════╣\n")
	      .append(target.getLongDescription()).append("\n")
	      .append(target.getExtendedDescription()).append("\n");

	    examiner.sendMessage(sb.toString());
	} // end examineMob


	// --- Unified helpers ---
	private static String buildBoxHeader(String title) {
	    return Ansi.BOLD
	        + "╔══════════════════════════════════════╗\n"
	        + "║ " + String.format("%-36s", title) + " \n"
	        + "╠══════════════════════════════════════╣\n"
	        + Ansi.RESET;
	}

	private static String buildBoxFooter() {
	    return "╚══════════════════════════════════════╝\n";
	}

	private static String formatEffects(List<Effect> effects) {
	    String reset = Ansi.RESET;
	    if (effects.isEmpty()) return "";
	    return effects.stream()
	        .map(e -> switch(e.getName().toLowerCase()) {
	            case "bleeding" -> Ansi.RED + "[BLEEDING]" + reset;
	            case "shielded" -> Ansi.CYAN + "[SHIELDED]" + reset;
	            case "burning" -> Ansi.MAGENTA + "[BURNING]" + reset;
	            default -> "[" + e.getName().toUpperCase() + "]";
	        })
	        .toList()
	        .stream()
	        .reduce((a,b) -> a + " " + b)
	        .orElse("");
	}

	// --- Examine Object ---
	public static void examineObject(Player player, ObjectItem obj) {
	    if (player == null || obj == null) return;

	    StringBuilder sb = new StringBuilder();
	    String reset = Ansi.RESET;

	    sb.append(buildBoxHeader("Examine Object: " + AdminCommandHandler.capitalize(obj.getName())));

	    // Effects / magical properties
	    List<String> effects = new ArrayList<>();
	    if (obj.hasEffect(ItemEffect.GLOW)) effects.add(Ansi.WHITE + "glows brightly" + reset);
	    if (obj.hasEffect(ItemEffect.BLESSED)) effects.add(Ansi.GREEN + "glows green" + reset);
	    if (obj.hasEffect(ItemEffect.CURSED)) effects.add(Ansi.RED + "glows red" + reset);
	    if (obj.hasEffect(ItemEffect.MAGIC)) effects.add(Ansi.BLUE + "glows blue" + reset);
	    if (obj.hasEffect(ItemEffect.HUMMING)) effects.add(Ansi.WHITE + "hums softly" + reset);
	    if (obj.hasEffect(ItemEffect.VORPAL)) effects.add(Ansi.WHITE + "shines with deadly light" + reset);
	    if (obj.hasEffect(ItemEffect.POISONED) || obj.isPoisoned()) effects.add(Ansi.GREEN + "drips poison" + reset);
	    if (obj.hasEffect(ItemEffect.BURNING)) effects.add(Ansi.RED + "is engulfed in flames" + reset);

	    if (!effects.isEmpty()) sb.append("║ Effects: ").append(String.join(", ", effects)).append("\n");

	    // Stats / Bonuses
	    sb.append("╠═════════ Stats ══════════════════════╣\n");
	    sb.append("  Type: ").append(obj.getType()).append("\n");
	    if (obj.getDamageBonus() != 0) sb.append("  Damage Bonus: ").append(obj.getDamageBonus()).append("\n");
	    if (obj.getDefenseBonus() != 0) sb.append("  Defense Bonus: ").append(obj.getDefenseBonus()).append("\n");
	    if (obj.getEquipSlot() != null) sb.append("  Equip Slot: ").append(obj.getEquipSlot()).append("\n");
	  
	    if (obj.getObjectType()==ObjectType.CONTAINER) {
	    sb.append("Contents: ");	
	    	for (ObjectItem o : obj.getContents()) {
	    		sb.append(o.getName()).append("\n");
	    	}
	    }

	    sb.append("\n").append(buildBoxFooter()).append("\n");

	    // Description
	    if (obj.getExtDescription() != null && !obj.getExtDescription().isBlank()) {
	        sb.append("╠═════════ Description ════════════════╣\n");
	        sb.append(obj.getExtDescription()).append("\n");
	    }

	    
	    
	    
	    player.sendMessage(sb.toString());
	}


	
	
	public static String handleInventory(Player player) {
		if (player == null) {
			return "You are... nothing?";
		}

		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) {
			return "You are carrying nothing.";
		}

		StringBuilder sb = new StringBuilder();
		sb.append("You are carrying:\n");

		int index = 1;
		for (ObjectItem item : inventory) {

			if (item != null) {
				sb.append(String.format("  %d. %s", index++, item.getShortDescription()))
				// Effects / magical properties	
				.append(LookHandler.objVisuals(item)).append("\n");
			}
		}

		return sb.toString().trim();
	}

	public static String handleWho(Player viewer) {
		List<Player> players = WorldManager.getActivePlayers();

		List<String> gImmsVisible = new ArrayList<>();
		List<String> gImmsHidden  = new ArrayList<>();
		List<String> immsVisible  = new ArrayList<>();
		List<String> immsHidden   = new ArrayList<>();
		List<String> mortalsVisible = new ArrayList<>();
		List<String> mortalsHidden  = new ArrayList<>();

		for (Player p : players) {
			boolean isInvisible = p.hasEffect(EffectType.INVISIBILITY)
					|| p.getEquipment().values().stream()
					.anyMatch(o -> o.hasEffect(ItemEffect.INVISIBLE));

			String display = p.getDisplayName();
			int privilege = p.getPrivilegeLevel();

			// Determine list based on privilege
			if (privilege == 2) { // GImms
				if (isInvisible && viewer.getPrivilegeLevel() < 2) {
					gImmsHidden.add("GImm " + display);
				} else {
					gImmsVisible.add("GImm " + display);
				}
			} else if (privilege == 1) { // Imms
				if (isInvisible && viewer.getPrivilegeLevel() < 1) {
					immsHidden.add(" Imm " + display);
				} else {
					immsVisible.add(" Imm " + display);
				}
			} else { // Mortals
				if (isInvisible && viewer.getPrivilegeLevel() < 1) {
					mortalsHidden.add("     " + display);
				} else {
					mortalsVisible.add("     " + display);
				}
			}
		}

		viewer.sendMessage("Players online (" + players.size() + "):");

		gImmsVisible.forEach(viewer::sendMessage);
		immsVisible.forEach(viewer::sendMessage);
		mortalsVisible.forEach(viewer::sendMessage);

		// Optional: show hidden players for privileged viewers
		if (viewer.getPrivilegeLevel() >= 1) {
			if (!gImmsHidden.isEmpty()) viewer.sendMessage("🔹 Invisible GImms:");
			gImmsHidden.forEach(viewer::sendMessage);

			if (!immsHidden.isEmpty()) viewer.sendMessage("🔹 Invisible Imms:");
			immsHidden.forEach(viewer::sendMessage);

			if (!mortalsHidden.isEmpty()) viewer.sendMessage("🔹 Invisible Players:");
			mortalsHidden.forEach(viewer::sendMessage);
		}

		return null;
	} // end handleWho


	public static String handleScore(Player player) {
		if (player == null) return "You are nowhere.";

		int level = player.getLevel();
		long currentExp = player.getExperience();
		long nextLevelExp = Leveling.getExpToNextLevel(level + 1);
		long prevLevelExp = Leveling.getExpToNextLevel(level - 1);
		long expIntoLevel = currentExp - prevLevelExp;
		long expToNextLevel = nextLevelExp - prevLevelExp;

		double progress = Math.min(1.0, Math.max(0.0, (double) expIntoLevel / expToNextLevel));

		// Create a 20-character progress bar with gradient
		int barLength = 20;
		int filledLength = (int) Math.round(progress * barLength);

		StringBuilder bar = new StringBuilder();
		for (int i = 0; i < barLength; i++) {
			if (i < filledLength) {
				double ratio = (double) (i + 1) / barLength;
				if (ratio < 0.33) bar.append(Ansi.GREEN).append("█");
				else if (ratio < 0.66) bar.append(Ansi.YELLOW).append("█");
				else bar.append(Ansi.RED).append("█");
			} else {
				bar.append(Ansi.GREY).append("░");
			}
		}
		bar.append(Ansi.RESET); // reset at the end

		// Build the score display
		StringBuilder sb = new StringBuilder();
		sb.append(Ansi.BOLD)
		.append("╔══════════════════ Player Score ══════════════════╗\n")
		.append(Ansi.RESET);
		sb.append("Level: ").append(level).append("\n");
		sb.append("EXP: ").append(currentExp).append(" / ").append(nextLevelExp)
		.append("  (").append((int) (progress * 100)).append("%)\n");
		sb.append("Progress: ").append(bar).append("\n");
		sb.append("╚══════════════════════════════════════════════════╝\n");

		return sb.toString();
	}
	
	
}
