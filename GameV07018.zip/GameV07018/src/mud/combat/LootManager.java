package mud.combat;

import mud.core.*;
import mud.core.enums.TreasureValue;

public class LootManager {

    public static void spawnDeathLoot(Mob mob, Room room) {
        if (mob == null || room == null) return;

        spawnCoins(mob, room);
        spawnGems(mob, room);
    }
    
    public static void spawnDeathLoot(Mob mob, ObjectItem container) {
        if (mob == null || container == null) return;

        spawnCoins(mob, container);
        spawnGems(mob, container);
    }

    // ---------------- COINS ----------------
    private static void spawnCoins(Mob mob, Room room) {
        TreasureValue tv = mob.getTreasureValue();
        if (tv == TreasureValue.NONE) return;

        int level = mob.getLevel();
        double rankMult = mob.getRank().getMultiplier();

        int baseCoins = level * mob.getRank().getTierValue();

        int totalCoins = (int)(
            baseCoins
            * tv.getTier()
            * rankMult
        );

        totalCoins = Dice.roll(
            (int)(totalCoins * 0.75),
            (int)(totalCoins * 1.25)
        );

        if (totalCoins <= 0) return;

        dropCoins(room, totalCoins);
    }

 // ---------------- COINS (container version) ----------------
    private static void spawnCoins(Mob mob, ObjectItem container) {
        TreasureValue tv = mob.getTreasureValue();
        if (tv == TreasureValue.NONE) return;

        int level = mob.getLevel();
        double rankMult = mob.getRank().getMultiplier();

        int baseCoins = level * mob.getRank().getTierValue();

        int totalCoins = (int)(            baseCoins
            * tv.getTier()
            * rankMult
        );

        totalCoins = Dice.roll(
            (int)(totalCoins * 0.75),
            (int)(totalCoins * 1.25)
        );

        if (totalCoins <= 0) return;

        dropCoins(container, totalCoins);
    }

    private static void dropCoins(Room room, int totalCoins) {
        ObjectItem pile = createCoinPile(totalCoins);
        if (pile != null) {
            room.addObject(pile);
        }
    }

    private static void dropCoins(ObjectItem container, int totalCoins) {
        ObjectItem pile = createCoinPile(totalCoins);
        if (pile != null) {
            container.addContents(pile);
        }
    }



    private static ObjectItem createCoinPile(int totalCoins) {
        if (totalCoins <= 0) return null;

        int plat = totalCoins / 1000;
        totalCoins %= 1000;

        int gold = totalCoins / 100;
        totalCoins %= 100;

        int silver = totalCoins / 10;
        int copper = totalCoins % 10;

        ObjectItem pile = ObjectManager.createObjById(Currency.PILE_ID);
        if (pile == null) return null;

        // IMPORTANT: value format is (p, g, s, c)
        pile.setValue(plat, gold, silver, copper);

        return pile;
    }

    
    // ---------------- GEMS ----------------
    private static void spawnGems(Mob mob, Room room) {
        int tier = mob.getTreasureValue().getTier();
        if (tier < 2) return;

        int gemRolls = switch (tier) {
        case 2 -> Dice.chance(30) ? 1 : 0;       // increase from 10% → 30%
        case 3 -> Dice.chance(60) ? Dice.roll(1, 2) : 0; // 60% chance to get 1–2 gems
        case 4 -> Dice.roll(1, 3);               // 1–3 gems instead of 0–1
        case 5 -> Dice.roll(2, 5);               // 2–5 gems instead of 1–3
        default -> 0;
    };

        for (int i = 0; i < gemRolls; i++) {
            int gemId = pickGemByLevel(mob.getLevel(), mob.getTreasureValue().getTier());
            ObjectItem gem = ObjectManager.createObjById(gemId);
            if (gem != null) {
                room.addObject(gem);
            }
        }
    }

    private static int pickGemByLevel(int level, int treasureTier) {
        int roll = Dice.roll(1, 100);
        int[] pool;

        // Base odds by level
        int smallChance;
        int mediumChance;

        if (level < 10) {
            smallChance = 100;
            mediumChance = 0;
        } else if (level < 25) {
            smallChance = 25;
            mediumChance = 75;
        } else {
            smallChance = 10;
            mediumChance = 30;
        }

        // TreasureValue bias (pushes upward, never downward)
        smallChance -= treasureTier * 2;     // OPULENT trims smalls
        mediumChance += treasureTier * 2;    // OPULENT boosts mediums

        smallChance = Math.max(0, smallChance);
        mediumChance = Math.min(90, mediumChance);

        if (roll <= smallChance) {
            pool = GemIds.SMALL_GEMS;
        } else if (roll <= smallChance + mediumChance) {
            pool = GemIds.MEDIUM_GEMS;
        } else {
            pool = GemIds.LARGE_GEMS;
        }

        return pool[Dice.roll(0, pool.length - 1)];
    }


    
 // ---------------- GEMS (container version) ----------------
    private static void spawnGems(Mob mob, ObjectItem container) {
        int tier = mob.getTreasureValue().getTier();
        if (tier < 2) return;

        int gemRolls = switch (tier) {
            case 2 -> Dice.chance(30) ? 1 : 0;
            case 3 -> Dice.chance(60) ? Dice.roll(1, 2) : 0;
            case 4 -> Dice.roll(1, 3);
            case 5 -> Dice.roll(2, 5);
            default -> 0;
        };

        for (int i = 0; i < gemRolls; i++) {
            int gemId = pickGemByLevel(mob.getLevel(), mob.getTreasureValue().getTier());
            ObjectItem gem = ObjectManager.createObjById(gemId);
            if (gem != null) {
                container.addContents(gem);
            }
        }
    }

    
}