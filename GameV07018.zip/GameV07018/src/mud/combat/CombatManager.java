package mud.combat;

import java.util.*;

import mud.core.*;
import mud.core.enums.EffectType;
import mud.core.enums.EquipSlot;
import mud.core.enums.MobAffectFlag;
import mud.core.enums.Profession;
import mud.core.enums.WeaponDamageType;
import mud.spell.*;
import mud.spell.Spell;
import mud.spell.effects.*;

public final class CombatManager {

	private CombatManager() {}

	public static class CombatMessages {
		public String attackerMsg;
		public String targetMsg;
		public String roomMsg;

		public CombatMessages(String attackerMsg, String targetMsg, String roomMsg) {
			this.attackerMsg = attackerMsg;
			this.targetMsg = targetMsg;
			this.roomMsg = roomMsg;
		}
	}

	// --------------------------------------------------
	// Public entry point — ONE attack, nothing more
	// --------------------------------------------------
	public static String performAttack(Mob attacker, Mob target) {
	    if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
	        return "Invalid combatants.";
	    }

	    attacker.setInCombat(true);
	    target.setInCombat(true);

	    List<String> allMessages = new ArrayList<>();

	    ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
	    ObjectItem offHand  = attacker.getEquipment().get(EquipSlot.OFFHAND);

	    // MAIN ATTACK
	    allMessages.add(performSingleAttack(attacker, target, mainHand, false));

	    // =========================
	    // PASSIVE ATTACKS
	    // =========================
	    for (PassiveAttack pa : PASSIVE_ATTACKS) {

	        // Check if attacker has effect or flag
	        boolean hasEffect = attacker.hasEffect(pa.effectName) || attacker.hasAffect(pa.flag);
	        if (!hasEffect) continue;

	        // Check profession restriction
	        if (!pa.getProfessions().contains(attacker.getProfession())) continue;

	        // Hand requirement checks
	        if (pa.requiresMainHand && (mainHand == null || !mainHand.isWeapon())) continue;
	        if (pa.requiresOffHand && (offHand == null || !offHand.isWeapon())) continue;
	        if (pa.unarmed && (mainHand != null || offHand != null)) continue;

	        // Compute chance based on level
	        double chance = Math.min(attacker.getLevel() * pa.levelMultiplier, pa.maxChance);
	        if (Math.random() >= chance) continue;

	        // Determine which weapon to use
	        ObjectItem weapon = null;
	        if (pa.requiresMainHand) weapon = mainHand;
	        else if (pa.requiresOffHand) weapon = offHand;
	        else if (pa.unarmed) weapon = null;

	        // Perform attack
	        allMessages.add(performSingleAttack(attacker, target, weapon, pa.isOffhand));
	    }

	    // Handle counter-attack
	    if (!target.isDead() || target.getTarget() == null) {
	        target.setTarget(attacker);
	        target.setCurrentTarget(target);
	        target.setInCombat(true);
	        // Optional: reactive attack could go here
	    }

	    // Check for death AFTER all attacks
	    if (target.isDead() || target.getCurrentHP() <= 0) {
	        DeathManager.clearCombat(attacker, target);
	    }

	    return String.join("\n", allMessages);
	}



	// -----------------------
	// PERFORM SINGLE ATTACK REFACTORED
	// -----------------------
	public static String performSingleAttack(
	        Mob attacker,
	        Mob target,
	        ObjectItem weapon,
	        boolean isOffhand
	) {

	    WeaponDamageType dmgType =
	            (weapon != null && weapon.getDamageType() != null)
	                    ? weapon.getDamageType()
	                    : WeaponDamageType.HIT;

	    String icon = dmgType.getIcon();
	    String verb = dmgType.getPrettyName().toLowerCase();
	    String handLabel = isOffhand ? " (offhand)" : "";

	    int baseDamage = rollWeaponDamage(weapon, attacker);
	    int bonusDamage = attacker.getStrength() / 2;

	    double vorpal = (weapon != null && weapon.isVorpal()) ? 1.25 : 1.0;
	    int intDamage = (weapon != null && weapon.isIntelligent()) ? weapon.getFlatDamage() : 0;

	    int rawDamage = (int)((baseDamage * vorpal) + intDamage + bonusDamage);
	    rawDamage = (int)(rawDamage * attacker.getRank().getMultiplier());

	    DamageContext ctx = new DamageContext(
	            attacker,
	            target,
	            rawDamage,
	            DamageContext.DamageSource.MELEE
	    );

	    ctx.setWeaponDamageType(dmgType);

	 // Check for defensive illusions
	    if (handleDefensiveIllusions(attacker, target, ctx)) {
	        return "Your attack was blocked by a defensive effect!";
	    }

	    /* =========================
	     * Apply armor reduction
	     * ========================= */
	    int defenseBonus = target.getEquipment().values().stream()
	            .filter(obj -> obj != null && obj.getArmorType() != null)
	            .mapToInt(obj -> obj.getArmorType().getDefenseBonus())
	            .sum();

	    defenseBonus = Math.min(defenseBonus, 99);
	    ctx.modifyDamagePercent(1.0 - (defenseBonus / 100.0));

	    /* =========================
	     * Effect hooks (BEFORE damage)
	     * ========================= */
	    for (Effect e : target.getActiveEffects()) {
	        e.onBeforeDamage(attacker, target, ctx);
	    }

	    for (Effect e : attacker.getActiveEffects()) {
	        e.onBeforeDamage(attacker, target, ctx);
	    }

	    /* =========================
	     * Apply final damage
	     * ========================= */
	    int damageTaken = ctx.getFinalDamage();

	    if (!ctx.isBlocked() && !ctx.isAbsorbed()) {
	        damageTaken = Math.max(1, damageTaken);
	        target.takeDamage(damageTaken);
	    }

	    /* =========================
	     * Effect hooks (AFTER damage)
	     * ========================= */
	    for (Effect e : target.getActiveEffects()) {
	        e.onAfterDamage(attacker, target, ctx);
	    }

	    for (Effect e : attacker.getActiveEffects()) {
	        e.onAfterDamage(attacker, target, ctx);
	    }

	    /* =========================
	     * Vampiric weapons
	     * ========================= */
	    if (weapon != null && weapon.getVampiricPercent() > 0 && damageTaken > 0) {
	        int heal = (int)(damageTaken * weapon.getVampiricPercent());
	        if (heal > 0) attacker.heal(heal);
	    }

	    /* =========================
	     * Death check
	     * ========================= */
	    if (target.getCurrentHP() <= 0) {
	        DeathManager.handleDeath(attacker, target);
	    }

	    String finalVerb = conjugateVerb(verb, attacker);

	    return String.format(
	            "%s %s%s %s for %d damage! %s",
	            attacker.getMobName(),
	            finalVerb,
	            handLabel,
	            target.getMobName(),
	            damageTaken,
	            icon
	    );
	}
	// end



	private static String conjugateVerb(String verb, Mob attacker) {
		if (attacker instanceof Player) {
			return verb; // player sees: "You hit X"
		}
		// simple English 3rd-person singular
		if (verb.endsWith("s") || verb.endsWith("x") || verb.endsWith("z") || verb.endsWith("ch") || verb.endsWith("sh")) {
			return verb + "es";
		}
		if (verb.endsWith("y") && verb.length() > 1 && !isVowel(verb.charAt(verb.length()-2))) {
			return verb.substring(0, verb.length()-1) + "ies";
		}
		return verb + "s";
	}

	private static boolean isVowel(char c) {
		return "aeiou".indexOf(Character.toLowerCase(c)) != -1;
	}


	// --------------------------------------------------
	// Helpers (PURE)
	// --------------------------------------------------

	private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
		return weapon != null ? weapon.rollDamage() : 1;
	}

	private static boolean handleDefensiveIllusions(Mob attacker, Mob target, DamageContext ctx) {
	    if (target == null || ctx == null) return false;

	    for (Effect e : target.getActiveEffects()) {
	        e.onBeforeDamage(attacker, target, ctx);
	        if (ctx.isBlocked()) {
	            return true; // attack was blocked by an effect
	        }
	    }

	    return false; // no effect blocked the attack
	}



	public static String getCombatStatus(Mob a, Mob b) {
		StringBuilder sb = new StringBuilder();

		sb.append(a.getMobName())
		.append(": HP ")
		.append(a.getCurrentHP()).append("/").append(a.getMaxHP())
		.append(" MP ").append(a.getCurrentMP()).append("/").append(a.getMaxMP())
		.append(" ")
		.append(CombatFormatter.formatBuffs(a))
		.append(CombatFormatter.formatDebuffs(a))
		.append("\n");

		sb.append(b.getMobName())
		.append(": HP ")
		.append(b.getCurrentHP()).append("/").append(b.getMaxHP())
		.append(" MP ").append(b.getCurrentMP()).append("/").append(b.getMaxMP())
		.append(" ")
		.append(CombatFormatter.formatBuffs(b))
		.append(CombatFormatter.formatDebuffs(b));

		return sb.toString();
	}

	static boolean handleCombatRoundInterupt(Mob attacker) {
		// check if stun/fear/etc and return "" (nothing) instead of continuing with combat
		// TODO
		for (EffectType e: attacker.getActEffects()) {
			if (e==EffectType.STUN) {
				attacker.sendMessage("You can't do that while stunned.");
				return true;
			}
			if (e==EffectType.FEAR) {
				attacker.sendMessage("You can't do that while feared.");
				return true;
			}
			if (e==EffectType.CONFUSE) {
				attacker.sendMessage("You can't do that while confused.");
				return true;
			}
			if (e==EffectType.DISORIENT) {
				attacker.sendMessage("You can't do that while disoriented.");
				return true;
			}

		}

		return false;	

	}

	 private static class PassiveAttack {
	        String effectName;
	        MobAffectFlag flag;
	        boolean requiresMainHand;
	        boolean requiresOffHand;
	        boolean unarmed;
	        Spell spell;             
	        double levelMultiplier;
	        double maxChance;
	        boolean isOffhand;

	        public PassiveAttack(String effectName, MobAffectFlag flag,
	                             boolean requiresMainHand, boolean requiresOffHand,
	                             boolean unarmed, Spell spell,
	                             double levelMultiplier, double maxChance, boolean isOffhand) {
	            this.effectName = effectName;
	            this.flag = flag;
	            this.requiresMainHand = requiresMainHand;
	            this.requiresOffHand = requiresOffHand;
	            this.unarmed = unarmed;
	            this.spell = spell;
	            this.levelMultiplier = levelMultiplier;
	            this.maxChance = maxChance;
	            this.isOffhand = isOffhand;
	        }

	        public Set<Profession> getProfessions() {
	            return spell.getProfessions();
	        }
	    }

	    // =========================
	    // Define your table of passive attacks here
	    // =========================
	    private static final List<PassiveAttack> PASSIVE_ATTACKS = List.of(
	        new PassiveAttack("second_hit", MobAffectFlag.SECONDHIT, false, false, true,
	                new SecondHitSpell(), 0.05, 0.5, true),
	        new PassiveAttack("double_attack", MobAffectFlag.DOUBLEATTACK, true, false, false,
	                new DoubleAttackSpell(), 0.05, 0.5, true),
	        new PassiveAttack("offhand_hit", MobAffectFlag.OFFHANDHIT, false, false, true,
	                new OffhandHitSpell(), 0.05, 0.5, true),
	        new PassiveAttack("dual_wield", MobAffectFlag.DUALWIELD, false, true, false,
	                new DualWieldSpell(), 0.03, 0.4, true)
	    );


} // end combatmanager
