package mud.combat;

import mud.core.*;
import mud.spell.effects.*;

public class CombatFormatter {

	public static String formatBuffs(Mob mob) {
	    StringBuilder sb = new StringBuilder();
	    sb.append("Buffs[");

	    boolean hasBuffs = false;

	    // FIRE SHIELD
	    if (mob.getEffect(FireShieldEffect.class) != null) {
	        hasBuffs = true;
	        sb.append(Ansi.RED).append("F").append(Ansi.RESET);
	    }

	    // MIRROR IMAGE, SHADOW CLONE, BONE SHIELD
	    for (Effect e : mob.getActiveEffects()) {
	        int count = e.getVisualCount();
	        if (count > 0) {
	            hasBuffs = true;
	            String symbol = "?";
	            if (e instanceof MirrorImageEffect) symbol = "i";
	            if (e instanceof ShadowCloneEffect) symbol = "s";
	            if (e instanceof BoneShieldEffect) symbol = "b";

	            for (int j = 0; j < count; j++) {
	                sb.append(Ansi.GREY).append(symbol).append(Ansi.RESET);
	            }
	        }
	    }

	    // Other buffs like Crushing Grip, Forceful Hand, Strength
	    if (mob.getEffect(CrushingGripEffect.class) != null) {
	        hasBuffs = true;
	        sb.append(Ansi.GREY).append("C").append(Ansi.RESET);
	    }
	    if (mob.getEffect(ForcefulHandEffect.class) != null) {
	        hasBuffs = true;
	        sb.append(Ansi.GREY).append("F").append(Ansi.RESET);
	    }
	    if (mob.getEffect(StrengthEffect.class) != null) {
	        hasBuffs = true;
	        sb.append(Ansi.GREY).append("+").append(Ansi.RESET);
	    }

	    if (!hasBuffs) sb.append("none");
	    sb.append("]");
	    return sb.toString();
	}




	public static String formatDebuffs(Mob mob) {
		StringBuilder sb = new StringBuilder();
		sb.append(" Debuffs[");
		boolean hasdeBuffs = false;

		// Mental Impairment
		// --- Blind ---
		if (mob.getEffect(BlindEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("B").append(Ansi.RESET);
		}
		// --- Charm ---
		if (mob.getEffect(CharmPersonEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("C").append(Ansi.RESET);
		}
		// --- Confusion ---
		if (mob.getEffect(ConfusionEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("c").append(Ansi.RESET);
		}
		// --- Fear ---
		if (mob.getEffect(FearEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("f").append(Ansi.RESET);
		}
		// --- SAP ---
		if (mob.getEffect(SilenceEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.RED).append("s").append(Ansi.RESET);
		}
		// --- SILENCE ---
		if (mob.getEffect(SilenceEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("S").append(Ansi.RESET);
		}
		// --- STUN ---
		if (mob.getEffect(StunEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.WHITE).append("s").append(Ansi.RESET);
		}	    
		// --- SLEEP ---
		// TODO
		//	    if (mob.getEffect(SleepEffect.class) != null) {
		//	        hasdeBuffs = true;
		//	        sb.append(Ansi.WHITE).append("S").append(Ansi.RESET);
		//	    }

		// Movement Impairment
		// --- Entangle ---
		if (mob.getEffect(EntangleEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREEN).append("E").append(Ansi.RESET);
		}
		// --- Frostbite ---
		if (mob.getEffect(FrostbiteEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.BLUE).append("F").append(Ansi.RESET);
		}
		// --- Hold ---
		if (mob.getEffect(HoldEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("H").append(Ansi.RESET);
		}
		// --- Root ---
		if (mob.getEffect(RootEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.CYAN).append("R").append(Ansi.RESET);
		}
		// --- Web ---
		if (mob.getEffect(WebEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("W").append(Ansi.RESET);
		}



		// Other Debuffs
		// --- Berserk ---
		if (mob.getEffect(BerserkEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.ORANGE).append("b").append(Ansi.RESET);
		}
		// --- Bleed ---
		if (mob.getEffect(BleedEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.RED).append("B").append(Ansi.RESET);
		}	    
		// --- Poison ---
		if (mob.getEffect(PoisonEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREEN).append("P").append(Ansi.RESET);
		}
		// --- Weakness ---
		if (mob.getEffect(WeaknessEffect.class) != null) {
			hasdeBuffs = true;
			sb.append(Ansi.GREY).append("-").append(Ansi.RESET);
		}
		
		
		
		
		// TODO
		// burn etc





		if (!hasdeBuffs) {
			sb.append("none");
		}

		sb.append("]");
		return sb.toString();
	}


}// end
