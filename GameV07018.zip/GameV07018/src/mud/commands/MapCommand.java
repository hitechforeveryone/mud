package mud.commands;

import java.util.*;

import mud.config.Config;
import mud.core.*;
import mud.map.*;

public class MapCommand {

	// map (by itself) lists all maps // map with string loads specific map
	public static void execute(Mob player, String arg) {
		if (arg == null || arg.isEmpty()) {
			player.sendMessage("Available maps:");
			for (AsciiMap m : MapManager.all()) {
				player.sendMessage(" - " + m.getName());
			}
			return;
		}

		AsciiMap map = MapManager.get(arg + ".map.txt");
		if (map == null) {
			player.sendMessage("No such map.");
			return;
		}

		player.sendMessage(MapRenderer.render(map));
	}

	// displays current zone's map
	public static void execute(Mob player) {
		player.sendMessage(ZoneMapRenderer.renderFor(player));
	}

	

	public static void handleMap(Mob player, String[] cells) {

	    if (cells == null || cells.length == 0) {
	        usage(player);
	        return;
	    }

	    // --------------------
	    // map
	    // --------------------
	    if (cells.length == 1) {
	        player.sendMessage(ZoneMapRenderer.renderFor(player));
	        return;
	    }

	    String sub = cells[1].toLowerCase();

	    // --------------------
	    // map here
	    // --------------------
	    if (cells.length == 2 && sub.equals("here")) {
	        player.sendMessage(ZoneMapRenderer.renderFor(player));
	        return;
	    }

	    // --------------------
	    // map world
	    // --------------------
	    if (cells.length == 2 && sub.equals("world")) {
	        if (player.getCurrentRoom() == null || player.getCurrentRoom().getZone() == null) {
	            player.sendMessage("You are nowhere.");
	            return;
	        }

	        int worldId = Integer.parseInt( player.getCurrentRoom().getZone().getWorld().getWorldId());
	        WorldMap map = WorldMapManager.get(worldId);

	        if (map == null) {
	            player.sendMessage("No world map exists for this world.");
	            return;
	        }

	        player.sendMessage(WorldMapRenderer.render(map));
	        return;
	    }

	    // --------------------
	    // map world <worldId>
	    // --------------------
	    if (cells.length == 3 && sub.equals("world")) {
	        try {
	            int worldId = Integer.parseInt(cells[2]);
	            WorldMap map = WorldMapManager.get(worldId);

	            if (map == null) {
	                player.sendMessage("No world map exists for that world.");
	                return;
	            }

	            player.sendMessage(WorldMapRenderer.render(map));
	            return;

	        } catch (NumberFormatException e) {
	            player.sendMessage("World ID must be a number.");
	            return;
	        }
	    }

	    // --------------------
	    // map list
	    // --------------------
	    if (cells.length == 2 && sub.equals("list")) {
	        player.sendMessage("Loaded zone maps:");

	        List<ZoneMap> maps = new ArrayList<>(ZoneMapManager.all());

	        // Sort by WorldId first, then ZoneId
	        maps.sort(Comparator
	            .comparingInt(ZoneMap::getWorldId)
	            .thenComparingInt(ZoneMap::getZoneId)
	        );

	        for (ZoneMap map : maps) {
	        	World tworld = WorldManager.getWorld(map.getWorldId());
	            Zone tzone = WorldManager.getZone(tworld.getWorldId(), map.getZoneId());
	            

	            player.sendMessage(
	                " - World " + map.getWorldId()
	                + " Zone " + map.getZoneId()
	                + ": " + (tzone != null ? tzone.getName() : "(unknown zone/zone not loaded)")
	            );
	        }
	        return;
	    }
	    // end


	    // --------------------
	    // map reload
	    // --------------------
	    if (cells.length == 2 && sub.equals("reload")) {
	        if (((Player) player).getPrivilegeLevel() <= 0) {
	            player.sendMessage("You lack the power to do that.");
	            return;
	        }

	        ZoneMapManager.reload();
	        WorldMapManager.reload(Config.MAPS_DIR);

	        player.sendMessage("All maps reloaded.");
	        return;
	    }

	    // --------------------
	    // map validate
	    // --------------------
	    if (cells.length == 2 && sub.equals("validate")) {
	        if (((Player) player).getPrivilegeLevel() <= 0) {
	            player.sendMessage("You lack the power to do that.");
	            return;
	        }

	        validateMaps(player);
	        return;
	    }

	    // --------------------
	    // map <worldId> <zoneId>
	    // --------------------
	    if (cells.length == 3) {
	        try {
	            int worldId = Integer.parseInt(cells[1]);
	            int zoneId  = Integer.parseInt(cells[2]);

	            ZoneMap map = ZoneMapManager.get(worldId, zoneId);
	            if (map == null) {
	                player.sendMessage("No map exists for that zone.");
	                return;
	            }

	            StringBuilder sb = new StringBuilder();
	            sb.append("== Zone ").append(worldId)
	              .append(":").append(zoneId).append(" ==\n");

	            for (String line : map.getLines()) {
	                sb.append(line).append("\n");
	            }

	            player.sendMessage(sb.toString());
	            return;

	        } catch (NumberFormatException e) {
	            player.sendMessage("World ID and Zone ID must be numbers.");
	            return;
	        }
	    }

	    usage(player);
	}
	// end


    private static void usage(Mob player) {
        player.sendMessage("Usage:");
        player.sendMessage("  map");
        player.sendMessage("  map here");
        player.sendMessage("  map world");
        player.sendMessage("  map world <worldId>");
        player.sendMessage("  map <worldId> <zoneId>");
        player.sendMessage("  map list");
        if (((Player) player).getPrivilegeLevel() >0) {

            player.sendMessage("  map reload");
            player.sendMessage("  map validate");
        }
    }

    // --------------------
    // Validation Logic
    // --------------------
    private static void validateMaps(Mob player) {

        for (ZoneMap map : ZoneMapManager.all()) {

            Zone zone = WorldManager.getZone(
                String.valueOf( map.getWorldId()),
                map.getZoneId()
            );

            if (zone == null) {
                player.sendMessage("[WARN] Map "
                    + map.getWorldId() + ":" + map.getZoneId()
                    + " has no matching zone.");
                continue;
            }

            int mapHeight = map.getLines().size();
            int mapWidth = 0;
            for (String line : map.getLines()) {
                mapWidth = Math.max(mapWidth, line.length());
            }

            int roomCount = zone.getRooms().size();

            if (mapWidth * mapHeight < roomCount) {
                player.sendMessage("[WARN] Zone "
                    + zone.getName()
                    + " has more rooms (" + roomCount
                    + ") than map cells (" + (mapWidth * mapHeight) + ").");
            } else {
                player.sendMessage("[OK] Zone "
                    + zone.getName()
                    + " (" + roomCount + " rooms).");
            }
        }

        player.sendMessage("Map validation complete.");
    }
    
}
// end
