package mud.commands;

import java.util.*;
import java.util.stream.Collectors;

import mud.core.*;
import mud.core.Currency;
import mud.core.enums.Direction;
import mud.core.enums.EffectType;
import mud.core.enums.EquipSlot;
import mud.core.enums.ItemEffect;
import mud.core.enums.MobAffectFlag;
import mud.core.enums.ObjectType;
import mud.scripting.*;
import mud.spell.*;
import mud.spell.effects.PoisonEffect;

public class InteractionHandler {

	public static String handleFollowCommand(Mob follower, String[] args) {
		if (args.length < 2) return "Follow whom?";
		String targetName = String.join(" ", Arrays.copyOfRange(args, 1, args.length));

		Mob target = resolveFollowTarget(follower, targetName);
		if (target == null) return "You don't see anyone like that here.";
		if (target == follower) return "You cannot follow yourself.";
		if (follower.getFollowTarget() == target)
			return "You are already following " + target.getMobName() + ".";

		follower.setFollowTarget(target);
		target.addFollower(follower); // ✅ Register follower with leader

		follower.sendMessage("You begin following " + target.getMobName() + ".");
		if (target instanceof Player) {
			target.sendMessage(follower.getMobName() + " begins following you.");
		}

		Room room = follower.getCurrentRoom();
		if (room != null && follower.isVisible()
				&& !follower.hasAffect(MobAffectFlag.SNEAK)
				&& !follower.hasAffect(MobAffectFlag.INVISIBLE)) {
			room.broadcastToExcept(follower, follower,
					follower.getMobName() + " starts following " + target.getMobName() + ".");
		}

		return null;
	}


	// --- FOLLOW HANDLER (fires automatically when a leader moves) ---
	public static void handleFollow(Mob leader, Room fromRoom, Room toRoom, Direction dir) {
		if (leader == null || fromRoom == null || toRoom == null) return;

		// Use leader's follower list instead of fromRoom.getMobs()
		List<Mob> followers = new ArrayList<>(leader.getFollowers());

		for (Mob follower : followers) {
			if (follower == null || follower.isDead()) continue;
			moveFollower(follower, dir);
		}
	}




	private static Mob resolveFollowTarget(Mob seeker, String input) {

		Room room = seeker.getCurrentRoom();
		if (room == null) return null;

		int index = 1;
		String name = input;

		// Handle "2.goblin" syntax
		if (input.matches("^\\d+\\..+")) {
			int dot = input.indexOf('.');
			index = Integer.parseInt(input.substring(0, dot));
			name = input.substring(dot + 1);
		}

		List<Mob> matches = new ArrayList<>();

		// 1) Players first
		for (Mob mob : room.getPlayers()) {
			if (matchesNameOrKeywords(mob, name)) {
				matches.add(mob);
			}
		}

		// 2) Then mobs
		for (Mob mob : room.getMobs()) {
			if (mob == seeker) continue;
			if (matchesNameOrKeywords(mob, name)) {
				matches.add(mob);
			}
		}

		if (matches.isEmpty()) return null;
		if (index > matches.size()) return null;

		return matches.get(index - 1);
	}
	// end

	// --- MOVE FOLLOWER ---
	private static void moveFollower(Mob follower, Direction dir) {
		Room fromRoom = follower.getCurrentRoom();
		if (fromRoom == null) return;

		Room toRoom = fromRoom.getExit(dir);
		if (toRoom == null) return;

		if (MovementHandler.isMovementBlocked(follower, fromRoom, dir)) {
			if (follower instanceof Player) {
				follower.sendMessage("You try to follow, but cannot move.");
			}
			return;
		}

		// 🔥 delegate to moveMob for full movement logic 🔥
		System.out.println(follower.getMobName() + "tried to follow");
		MovementHandler.moveMob(follower, dir);
	}
	// end



	private static boolean matchesNameOrKeywords(Mob mob, String input) {

		String lower = input.toLowerCase();

		// Match mob name
		if (mob.getMobName().toLowerCase().contains(lower)) {
			return true;
		}

		// Match keywords
		for (String kw : mob.getKeywords()) {
			if (kw.toLowerCase().startsWith(lower)) {
				return true;
			}
		}

		return false;
	}
	// end


	/**
	 * Handle the 'order' command.
	 * Players can control their familiars; admins can control any mob.
	 *
	 * @param player The player issuing the order
	 * @param targetName The mob/familiar to order
	 * @param command The command string to execute
	 * @return Feedback message
	 */
	public static String handleOrder(Player player, String targetName, String command) {
		if (player == null || targetName == null || command == null || targetName.isBlank() || command.isBlank()) {
			return "Usage: order <target> <command>";
		}

		Room room = player.getCurrentRoom();
		if (room == null) return "You are nowhere. Cannot issue orders.";

		Mob target = null;
		for (Mob m : room.getMobs()) {
			if (m.hasKeyword(targetName)) {
				target = m;
				break;
			}
		}
		if (target == null) return "There is no " + targetName + " here.";

		// Ownership / permission check
		boolean canControl = target.getMaster() == player || player.getPrivilegeLevel() > 0;
		if (!canControl) return target.getMobName() + " will not obey you!";

		Player pseudoPlayer = new Player();
		// Adapt Mob into a "fake player" for command processing  
		if (target instanceof Player) {
			// do nothing, its already a Player
		}
		else {
			pseudoPlayer = new MobAsPlayer(target);

			room.removeMob(target);
			pseudoPlayer.setCurrentRoom(room);
			pseudoPlayer.setCurrentRoom(room);
		}


		String result;
		try {
			result = CommandProcessor.processCommand(command, pseudoPlayer);
		} catch (Exception e) {
			result = target.getMobName() + " failed to execute the command: " + e.getMessage();
		}

		return result != null ? "Ordered " + target.getMobName() + ": " + result : "Ordered " + target.getMobName() + ".";
	}


	public static void handleClose(Mob player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Close what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Close what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// -------------------
		// Handle doors first
		// -------------------
		Direction dir = resolveDoorDirection(currentRoom, target);
		if (dir != null) {
			Door door = currentRoom.getDoor(dir);
			if (door == null) {
				player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
				return;
			}
			if (door.isClosed()) {
				player.sendMessage("The " + door.getDoorName() + " is already closed.");
				return;
			}

			door.setClosed(true);

			Room dest = currentRoom.getExit(dir);
			if (dest != null) {
				Door destDoor = dest.getDoor(dir.getOpposite());
				if (destDoor != null) {
					destDoor.setClosed(true);
				}
			}

			player.sendMessage("You close the " + door.getDoorName() + ".");
			currentRoom.broadcast(player.getMobName() + " closes the " + door.getDoorName() + ".", player);
			return;
		}



		// Search container in room or inventory
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to close.");
			return;
		}
		if (container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already closed.");
			return;
		}

		container.setClosed(true);
		player.sendMessage("You close the " + container.getName() + ".");
	}

	public static void handleUnlock(Mob player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Unlock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Unlock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// -------------------
		// Handle doors first
		// -------------------
		Direction dir = resolveDoorDirection(currentRoom, target);
		if (dir != null) {
			Door door = currentRoom.getDoor(dir);
			if (door == null) {
				player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
				return;
			}

			if (!door.isLocked()) {
				player.sendMessage("The " + door.getDoorName() + " is not locked.");
				return;
			}

			int keyId = door.getDoorKeyId();
			if (keyId != -1) {
				boolean hasKey = false;
				for (ObjectItem item : player.getInventory()) {
					if (item.getObjID() == keyId) {
						hasKey = true;
						break;
					}
				}
				if (!hasKey) {
					player.sendMessage("You don't have the key to unlock the " + door.getDoorName() + ".");
					return;
				}
			}

			door.setLocked(false);

			Room dest = currentRoom.getExit(dir);
			if (dest != null) {
				Door destDoor = dest.getDoor(dir.getOpposite());
				if (destDoor != null) {
					destDoor.setLocked(false);
				}
			}

			player.sendMessage("You unlock the " + door.getDoorName() + ".");
			currentRoom.broadcast(player.getMobName() + " unlocks the " + door.getDoorName() + ".", player);
			return;
		}



		// -----------------------
		// Handle containers next
		// -----------------------
		ObjectItem container = null;

		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to unlock.");
			return;
		}

		if (!container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is not locked.");
			return;
		}

		// --- Key check (same as doors) ---
		int keyId = container.getKeyNum(); // assumed existing
		if (keyId != -1) {
			boolean hasKey = false;
			for (ObjectItem item : player.getInventory()) {
				if (item.getObjID() == keyId) {
					hasKey = true;
					break;
				}
			}

			if (!hasKey) {
				player.sendMessage("You don't have the key to unlock the " + container.getName() + ".");
				return;
			}
		}

		container.setLocked(false);
		player.sendMessage("You unlock the " + container.getName() + ".");
	} 
	// end handleUnlock



	public static void handleLock(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Lock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Lock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// -------------------
		// Handle doors first
		// -------------------
		Direction dir = resolveDoorDirection(currentRoom, target);
		if (dir != null) {
			Door door = currentRoom.getDoor(dir);
			if (door == null) {
				player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
				return;
			}

			if (door.isLocked()) {
				player.sendMessage("The " + door.getDoorName() + " is already locked.");
				return;
			}

			if (!door.isClosed()) {
				player.sendMessage("You must close the " + door.getDoorName() + " before locking it.");
				return;
			}

			int keyId = door.getDoorKeyId();
			if (keyId != -1) {
				boolean hasKey = false;
				for (ObjectItem item : player.getInventory()) {
					if (item.getObjID() == keyId) {
						hasKey = true;
						break;
					}
				}
				if (!hasKey) {
					player.sendMessage("You don't have the key to lock the " + door.getDoorName() + ".");
					return;
				}
			}

			door.setLocked(true);

			Room dest = currentRoom.getExit(dir);
			if (dest != null) {
				Door destDoor = dest.getDoor(dir.getOpposite());
				if (destDoor != null) {
					destDoor.setLocked(true);
				}
			}

			player.sendMessage("You lock the " + door.getDoorName() + ".");
			currentRoom.broadcast(player.getName() + " locks the " + door.getDoorName() + ".", player);
			return;
		}


		// -----------------------
		// Handle containers next
		// -----------------------
		ObjectItem container = null;

		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to lock.");
			return;
		}

		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is already locked.");
			return;
		}

		// --- Must be closed first (same as doors) ---
		if (!container.isClosed()) {
			player.sendMessage("You must close the " + container.getName() + " before locking it.");
			return;
		}

		// --- Key check (same behavior as doors) ---
		int keyId = container.getKeyNum(); // assumed existing
		if (keyId != -1) {
			boolean hasKey = false;
			for (ObjectItem item : player.getInventory()) {
				if (item.getObjID() == keyId) {
					hasKey = true;
					break;
				}
			}

			if (!hasKey) {
				player.sendMessage("You don't have the key to lock the " + container.getName() + ".");
				return;
			}
		}

		// Lock container
		container.setLocked(true);
		player.sendMessage("You lock the " + container.getName() + ".");

	} // end handleLock

	public static String handleDrop(Mob player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have anything.";

		ObjectItem toDrop = null;
		String lowerItemName = itemName.toLowerCase();

		for (ObjectItem item : inventory) {
			if (item != null && item.getName() != null &&
					item.getName().toLowerCase().contains(lowerItemName)) {
				toDrop = item;
				break;
			}
		}

		if (toDrop == null) return "You don't have that.";

		inventory.remove(toDrop);
		player.getCurrentRoom().addObject(toDrop);
		return "You drop: " + toDrop.getName();
	}

	public static String handleDropCoins(Mob player, String itemName) {
	    if (player == null || player.getCurrentRoom() == null) return "You are nowhere.";

	    // Get total coins in copper
	    int totalCopper = player.getTotalCopper();
	    if (totalCopper <= 0) return "You have no coins to drop.";

	    int dropCopper = 0;

	    // Normalize input
	    String lower = itemName.toLowerCase().trim();

	    // Remove trailing "coin" or "coins"
	    if (lower.endsWith(" coin")) lower = lower.substring(0, lower.length() - 5).trim();
	    else if (lower.endsWith(" coins")) lower = lower.substring(0, lower.length() - 6).trim();

	    if (lower.isEmpty()) {
	        // just "drop coin(s)" → drop all
	        dropCopper = totalCopper;
	    } else {
	        // parse input like "1p 5g 2s"
	        String[] parts = lower.split("\\s+");
	        for (String part : parts) {
	            if (part.isEmpty()) continue;

	            char unit = part.charAt(part.length() - 1); // last char is unit
	            String numberStr = part.substring(0, part.length() - 1);

	            int amount;
	            try {
	                amount = Integer.parseInt(numberStr);
	            } catch (NumberFormatException e) {
	                return "Invalid coin amount: " + part;
	            }

	            switch (unit) {
	                case 'p' -> dropCopper += amount * 10000;
	                case 'g' -> dropCopper += amount * 1000;
	                case 's' -> dropCopper += amount * 100;
	                case 'c' -> dropCopper += amount;
	                default -> player.sendMessage("Invalid coin unit: " + unit + " (use p/g/s/c)");
	            }
	        }

	        if (dropCopper <= 0) return "You have no coins to drop.";
	        if (dropCopper > totalCopper) dropCopper = totalCopper; // can't drop more than player has
	    }

	    // Remove the coins from player
	    boolean success = player.subtractCopper(dropCopper);
	    if (!success) return "You don't have enough coins to drop.";

	    // Create pile object
	    ObjectItem pile = ObjectManager.createObjById(Currency.PILE_ID);
	    if (pile != null) {
	        pile.setValueFromCopper(dropCopper);
	        pile.setStackCount(1);
	        player.getCurrentRoom().addObject(pile);
	    }

	    return Player.formatCoinsFromCopper(dropCopper) + ".";
	}


	public static void handleEquipment(Mob player) {
		Map<EquipSlot, ObjectItem> eq = player.getEquipment();

		player.sendMessage("📦 Currently Equipped:");

		for (Map.Entry<EquipSlot, ObjectItem> entry : eq.entrySet()) {
			EquipSlot slot = entry.getKey();
			ObjectItem item = entry.getValue();


			String itemName = (item != null) ? item.getName() : "Empty";
			player.sendMessage(slot.name() + ": " + itemName);
		}
	} // end



	public static String handleEquip(Mob mob, String[] args) {
		if (args.length == 0) return "Equip what?";

		// --- STEP 1: Determine if last token is an EquipSlot ---
		EquipSlot chosenSlot = null;
		String itemName;

		if (args.length > 1) {
			try {
				chosenSlot = EquipSlot.valueOf(args[args.length - 1].toUpperCase());
				itemName = String.join(" ", Arrays.copyOfRange(args, 0, args.length - 1));
			} catch (IllegalArgumentException e) {
				chosenSlot = null;
				itemName = String.join(" ", args);
			}
		} else {
			itemName = args[0];
		}

		String lowerItemName = itemName.substring(6).toLowerCase().replaceAll("[^a-z0-9]", "");

		// --- STEP 2: Find the item in inventory ---
		ObjectItem target = null;
		for (ObjectItem item : mob.getInventory()) {
			if (item == null || item.getName() == null) continue;

			// check cleaned name and keywords
			String cleanedItemName = item.getName().toLowerCase().replaceAll("[^a-z0-9]", "");

			boolean match = cleanedItemName.contains(lowerItemName) ||
					item.getKeywordSummary().contains(lowerItemName) ||
					(item.getKeywords() != null && item.matchesKeyword(itemName)) ||
					(item.getKeywords() != null && item.hasKeyword(itemName));

			if (match) {
				target = item;
				//		player.sendMessage("[Debug] Found item in inventory: " + target.getName());
				break;
			}
		}

		if (target == null) return "You don't have that item.";

		// --- STEP 3: Determine allowed slots ---
		List<EquipSlot> allowedSlots = new ArrayList<>(target.getEquipSlot());
		allowedSlots.removeIf(s -> s == EquipSlot.NONE);
		if (allowedSlots.isEmpty()) return "This item cannot be equipped anywhere.";

		// --- STEP 4: Determine final slot ---
		EquipSlot finalSlot;
		if (chosenSlot != null) {
			if (!allowedSlots.contains(chosenSlot)) return "Item cannot be equipped to that slot.";
			finalSlot = chosenSlot;
		} else {
			finalSlot = allowedSlots.get(0);
		}

		// --- STEP 5: Equip ---
		ObjectItem removed = mob.unequip(finalSlot);
		if (removed != null) mob.getInventory().add(removed);
		//	    player.getRoom().broadcastExcept(player.getName() + " unequip's their " + removed.getName() + "." , player);

		mob.equip(finalSlot, target);
		mob.getInventory().remove(target);

		return "You equip the " + target.getName() + " in your " + finalSlot.toString().toLowerCase() + ".";
	} // end

	public static String handleGrab(Mob player, String[] args) {
		if (args.length == 0) return "Grab what?";

		// --- STEP 1: Determine item name ---
		String itemName = String.join(" ", args);
		String lowerItemName = itemName.toLowerCase().replaceAll("[^a-z0-9]", "");

		// --- STEP 2: Find the item in inventory ---
		ObjectItem target = null;
		for (ObjectItem item : player.getInventory()) {
			if (item == null || item.getName() == null) continue;

			String cleanedItemName = item.getName().toLowerCase().replaceAll("[^a-z0-9]", "");

			boolean match =
					cleanedItemName.contains(lowerItemName) ||
					item.getKeywordSummary().contains(lowerItemName) ||
					(item.getKeywords() != null && item.matchesKeyword(itemName)) ||
					(item.getKeywords() != null && item.hasKeyword(itemName));

			if (match) {
				target = item;
				break;
			}
		}

		if (target == null) return "You don't have that item.";


		// --- STEP 3: Validate offhand equip ---
		if (!target.getEquipSlot().contains(EquipSlot.OFFHAND)) {
			return "You can't grab that in your offhand.";
		}

		// --- STEP 4: Equip to OFFHAND ---
		ObjectItem removed = player.unequip(EquipSlot.OFFHAND);
		if (removed != null) {
			player.getInventory().add(removed);
		}

		player.equip(EquipSlot.OFFHAND, target);
		player.getInventory().remove(target);

		return "You grab the " + target.getName() + " in your offhand.";
	} // end handleGrab

	public static String handleLight(Mob player, String[] args) {
		if (args.length == 0) return "Light what?";

		// --- STEP 1: Determine if last token is an EquipSlot ---
		@SuppressWarnings("unused")
		EquipSlot chosenSlot = null;
		String itemName;

		if (args.length > 1) {
			try {
				chosenSlot = EquipSlot.valueOf(args[args.length - 1].toUpperCase());
				itemName = String.join(" ", Arrays.copyOfRange(args, 0, args.length - 1));
			} catch (IllegalArgumentException e) {
				chosenSlot = null;
				itemName = String.join(" ", args);
			}
		} else {
			itemName = args[0];
		}

		// ⚠️ Intentionally mirrors handleEquip behavior
		String lowerItemName = itemName.substring(6)
				.toLowerCase()
				.replaceAll("[^a-z0-9]", "");

		// --- STEP 2: Find the item in inventory ---
		ObjectItem target = null;
		for (ObjectItem item : player.getInventory()) {
			if (item == null || item.getName() == null) continue;

			String cleanedItemName =
					item.getName().toLowerCase().replaceAll("[^a-z0-9]", "");

			boolean match =
					cleanedItemName.contains(lowerItemName) ||
					item.getKeywordSummary().contains(lowerItemName) ||
					(item.getKeywords() != null && item.matchesKeyword(itemName)) ||
					(item.getKeywords() != null && item.hasKeyword(itemName));

			if (match) {
				target = item;
				break;
			}
		}

		if (target == null) return "You don't have that item.";

		// --- STEP 3: Validate light source ---
		if (target.getObjectType() != ObjectType.LIGHTSOURCE) {
			return "That isn't a light source.";
		}

		List<EquipSlot> allowedSlots = new ArrayList<>(target.getEquipSlot());
		allowedSlots.removeIf(s -> s == EquipSlot.NONE);

		if (!allowedSlots.contains(EquipSlot.LIGHTSOURCE)) {
			return "You can't light that.";
		}

		// --- STEP 4: Check duration ---
		if (target.getDuration() == 0) {
			player.sendMessage("That light source is burned out.");
		}

		// --- STEP 5: Equip to LIGHTSOURCE ---
		ObjectItem removed = player.unequip(EquipSlot.LIGHTSOURCE);
		if (removed != null) player.getInventory().add(removed);

		player.equip(EquipSlot.LIGHTSOURCE, target);
		player.getInventory().remove(target);

		
		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), target);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

		
		return "You light the " + target.getName() + ".";
	} // end handleLight


	public static String handleUseItem(Mob player, String[] tokens) {
		if (player == null || tokens == null || tokens.length < 2) {
			return "Use what?";
		}

		String itemName = tokens[1];
		String targetName = (tokens.length >= 3) ? tokens[2] : null;

		// --- STEP 1: Search equipped items ---
		ObjectItem item = null;
		for (EquipSlot slot : EquipSlot.values()) {
			ObjectItem equipped = player.getEquippedItem(slot);
			if (equipped == null) continue;

			if (equipped.getName().equalsIgnoreCase(itemName) || equipped.matchesKeyword(itemName)) {
				item = equipped;
				break;
			}
		}

		if (item == null) return "You don't have that item equipped.";

		// --- STEP 2: Validate type ---
		if (item.getObjectType() != ObjectType.WAND && item.getObjectType() != ObjectType.STAFF) {
			return "You can't use that item in this way.";
		}

		// --- STEP 3: Check charges ---
		if (item.getCharges() <= 0) {
			return "You try to use the " + item.getName() + ", but it has no charges left.";
		}
		item.setCharges(item.getCharges() - 1);

		Room room = player.getCurrentRoom();
		if (room == null) return "You are nowhere to use that.";

		StringBuilder msg = new StringBuilder();
		msg.append("You use the ").append(item.getName()).append(".");

		int spellLevel = item.getSpellLvl();

		// --- WAND: single target ---
		if (item.getObjectType() == ObjectType.WAND) {
			if (targetName == null || targetName.isEmpty()) {
				msg.append("\nYou must specify a target for the wand.");
				return msg.toString();
			}

			Mob target = null;
			for (Mob m : room.getMobs()) {
				if (m.getMobName().equalsIgnoreCase(targetName) || m.matchesKeyword(targetName)) {
					target = m;
					break;
				}
			}

			if (target == null) {
				msg.append("\nNo such target is present.");
				return msg.toString();
			}

			for (String spellName : item.getSpells()) {
				String result = SpellManager.castScrollSpell(spellName, player, target, spellLevel);
				msg.append("\n").append(result);
			}
		}

		// --- STAFF: self + party ---
		else if (item.getObjectType() == ObjectType.STAFF) {
			List<Mob> targets = new ArrayList<>(room.getMobs());
			targets.add(player); // include self

			for (Mob target : targets) {
				for (String spellName : item.getSpells()) {
					String result = SpellManager.castScrollSpell(spellName, player, target, spellLevel);
					msg.append("\n").append(result);
				}
			}
		}

		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), item);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

		
		return msg.toString();
	}




	public static String handleRecite(Mob player, String[] tokens) {
		if (tokens == null || tokens.length < 2) {
			return "Usage: recite <scroll> [target]";
		}

		String itemName = tokens[1];

		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have any items.";

		// Find the scroll in inventory
		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName) || i.matchesKeyword(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) return "You don't have that item.";

		if (item.getObjectType() != ObjectType.SCROLL) {
			return "You can't recite that.";
		}

		Room room = player.getCurrentRoom();
		if (room == null) return "You are nowhere to cast that.";

		StringBuilder msg = new StringBuilder();
		msg.append("You recite ").append(item.getName());

		// Reduce stack if stackable
		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg.append(". You have recited the last one.");
			} else {
				msg.append(".");
			}
		} else {
			inventory.remove(item);
			msg.append(".");
		}

		// Cast each spell on the target(s)
		for (String spellName : item.getSpells()) {
			int spellLevel = item.getSpellLvl();

			Spell spell = SpellManager.getSpellByName(spellName);
			if (spell == null) {
				msg.append("\nNothing happens for ").append(spellName).append(".");
				continue;
			}

			if (spell.isAoE()) {
				// AoE: hit all mobs and players in room
				boolean hitSomething = false;

				for (Mob m : new ArrayList<>(room.getMobs())) {
					if (m == player) continue; // skip caster if not self-target
					if (spell.cast(player, m, spellLevel)) hitSomething = true;
				}

				for (Player p : new ArrayList<>(room.getPlayers())) {
					if (p == player && !spell.isSelfTarget()) continue;
					if (spell.cast(player, p, spellLevel)) hitSomething = true;
				}

				msg.append("\n").append(hitSomething ? "The scroll releases its magic in the room!" 
						: "The scroll has no effect.");

			} else {
				// Single target: require tokens[2]
				if (tokens.length < 3) {
					msg.append("\nYou need to specify a target for ").append(spellName).append(".");
					continue;
				}

				String targetName = tokens[2];
				Mob target = null;
				for (Mob m : room.getMobs()) {
					if (m.getMobName().equalsIgnoreCase(targetName) || m.matchesKeyword(targetName)) {
						target = m;
						break;
					}
				}

				if (target == null) {
					msg.append("\nNo such target here for ").append(spellName).append(".");
					continue;
				}

				String result = SpellManager.castScrollSpell(spellName, player, target, spellLevel);
				msg.append("\n").append(result);
			}
		}

		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), item);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

		
		
		return msg.toString();
	}





	public static String handleQuaff(Mob player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have any items.";

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName) || i.matchesKeyword(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) return "You don't have that item.";

		if (item.getObjectType() != ObjectType.POTION) {
			return "You can't quaff that.";
		}

		StringBuilder msg = new StringBuilder();
		msg.append("You quaff ").append(item.getName()).append(".");

		// Reduce stack if stackable
		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg.append(" You have quaffed the last one.");
			}
		} else {
			inventory.remove(item);
		}

		// Cast each spell on the player using castPotionSpell
		for (String spellName : item.getSpells()) {
			// Force self-targeting for potions

			String result = SpellManager.castPotionSpell(spellName, player, player,item.getSpellLvl());
			msg.append("\n").append(result);
		}

		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), item);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

		
		return msg.toString();
	}



	public static String handleEat(Player player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) {
			return "You don't have any items.";
		}

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName) || i.matchesKeyword(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) {
			return "You don't have that item.";
		}

		// Only enforce FOOD restriction for normal players
		if (player.getPrivilegeLevel() < 1 && item.getObjectType() != ObjectType.FOOD) {
			return "You can't eat that.";
		}

		int hpRestore = item.getHpRestore();

		// Apply healing
		player.setCurrentHP(Math.min(player.getCurrentHP() + hpRestore, player.getMaxHP()));

		// Apply poison if present
		if (item.isPoisoned()) {
			player.sendMessage("That tasted slightly funny.");
			int duration = 3;
			int damagePerTick = 5;
			PoisonEffect poison = new PoisonEffect(player, duration, damagePerTick);
			player.addEffect(poison);
			player.addEffect(EffectType.POISON);
		}

		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), item);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

		
		// Handle consumption
		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			String msg = "You eat one of the " + item.getName() + ".";

			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg += " You have eaten the last one.";
			}
			return msg;
		} else {
			inventory.remove(item);
			return "You eat the " + item.getName() + ".";
		}
	} // end handleEat

	public static String handleDrink(Mob player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) {
			return "You don't have any items.";
		}

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName) || i.matchesKeyword(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) {
			return "You don't have that item.";
		}



		int mpRestore = item.getMpRestore();

		// Apply healing
		player.setCurrentMP(Math.min(player.getCurrentMP() + mpRestore, player.getMaxMP()));

		// Apply poison if present
		if (item.isPoisoned()) {
			player.sendMessage("That tasted strange.");
			int duration = 3;
			int damagePerTick = 5;
			PoisonEffect poison = new PoisonEffect(player, duration, damagePerTick);
			player.addEffect(poison);
			player.addEffect(EffectType.POISON);
		}

		// fire trigger
	    ZoneScript.Room scriptRoom = player.getCurrentRoom().getScriptRoom();	   
	    TriggerContext ctx =
	            TriggerContext.forUse(player, player.getCurrentRoom(), item);	 
	    ZoneScript.fireTriggers(player.getCurrentRoom(), scriptRoom, TriggerType.ON_USE, ctx);

	    
		// Handle consumption
		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			String msg = "You drink one of the " + item.getName() + ".";

			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg += " You have finished the last one.";
			}
			return msg;
		} else {
			inventory.remove(item);
			return "You drink the " + item.getName() + ".";
		}

	} // end handleDrink




	/*
	private static ObjectItem findContainerInRoomOrInventory(Room room, List<ObjectItem> inventory, String keyword) {
		for (ObjectItem obj : room.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		for (ObjectItem obj : inventory) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		return null;
	}
	 */

	public static void handleGet(Mob player, String[] args) { 
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are nowhere.");
			return;
		}
		Room room = player.getCurrentRoom();

		if (args.length < 2) {
			player.sendMessage("Usage: get <item|all> [from <container>]");
			return;
		}

		// Detect if command contains "from"
		int fromIndex = -1;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("from")) {
				fromIndex = i;
				break;
			}
		}

		String itemName;
		String containerName = null;
		ObjectItem container = null; // declare outside for scope

		if (fromIndex == -1) {
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		} else {
			if (fromIndex == 1 || fromIndex == args.length - 1) {
				player.sendMessage("Usage: get <item|all> [from <container>]");
				return;
			}
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, fromIndex)).toLowerCase();
			containerName = String.join(" ", Arrays.copyOfRange(args, fromIndex + 1, args.length)).toLowerCase();
		}

		List<ObjectItem> sourceItems;

		if (containerName == null) {
			sourceItems = filterGettable(player, room.getObjects());
		} else {
			// Find container in room
			int containerIndex = 1;
			String containerKeyword = containerName;
			if (containerName.contains(".")) {
				String[] parts = containerName.split("\\.", 2);
				try {
					containerIndex = Integer.parseInt(parts[0]);
					containerKeyword = parts[1];
				} catch (NumberFormatException e) {
					containerIndex = 1;
				}
			}

			List<ObjectItem> containers = room.findObjectsByKeyword(containerKeyword);
			if (containers.isEmpty() || containers.size() < containerIndex) {
				player.sendMessage("There is no " + containerKeyword + " here.");
				return;
			}

			container = containers.get(containerIndex - 1);
			if (container.getContents() == null) {
				player.sendMessage("The " + containerKeyword + " is empty.");
				return;
			}

			sourceItems = filterGettable(player, container.getContents());
		}

		List<ObjectItem> toRemove = new ArrayList<>();

		if (itemName.equals("all")) {
			if (sourceItems.isEmpty()) {
				player.sendMessage("There is nothing to get.");
				return;
			}

			for (ObjectItem item : sourceItems) {
				if (item.getType() == ObjectType.COIN) {
					int coinValue = item.getTotalValueInCopper();
					if (coinValue <= 0) continue;
					player.addCopper(coinValue);
					player.sendMessage("You collect " + formatCoins(item)  + " coin(s).");

					// Remove coin from container or room
					if (containerName != null) {
						container.removeContents(item);
					} else {
						room.removeObject(item);
					}

				} else {
					player.addItem(item);
					player.sendMessage("You take " + item.getShortDescription() + ".");
					// Remove item from container or room
					if (containerName != null) {
						container.removeContents(item);
					} else {
						room.removeObject(item);
					}
				}
				toRemove.add(item);
			}

			// Clean up temp list
			sourceItems.removeAll(toRemove);


		} else {
			List<ObjectItem> matchingItems = sourceItems.stream()
					.filter(i -> i.getName().toLowerCase().contains(itemName))
					.collect(Collectors.toList());

			if (matchingItems.isEmpty()) {
				player.sendMessage("You don't see that here.");
				return;
			}

			ObjectItem itemToGet = matchingItems.get(0);
			sourceItems.remove(itemToGet);

			if (itemToGet.getType() == ObjectType.COIN) {
				int coinValue = itemToGet.getTotalValueInCopper();
				if (coinValue <= 0) return;

			    player.sendMessage("You collect " + formatCoins(itemToGet) + ".");

			    if (containerName != null) {
			        container.removeContents(itemToGet);
			    } else {
			        room.removeObject(itemToGet);
			    }
			}

			else {
				player.addItem(itemToGet);
				player.sendMessage("You take " + itemToGet.getShortDescription() + ".");
				room.removeObject(itemToGet);
			}
		}
	}

	private static String formatCoins(ObjectItem coin) {
	    StringBuilder sb = new StringBuilder();

	    if (coin.getValuePlatinum() > 0) sb.append(coin.getValuePlatinum()).append("p ");
	    if (coin.getValueGold() > 0)     sb.append(coin.getValueGold()).append("g ");
	    if (coin.getValueSilver() > 0)   sb.append(coin.getValueSilver()).append("s ");
	    if (coin.getValueCopper() > 0)   sb.append(coin.getValueCopper()).append("c");

	    return sb.toString().trim(); // <- return a String, not StringBuilder
	}
	// deduct coins from a pile, returns a new ObjectItem with removed coins
	public static ObjectItem splitCoins(ObjectItem pile, int p, int g, int s, int c) {
	    if (pile == null || pile.getType() != ObjectType.COIN) return null;

	    int actualP = Math.min(p, pile.getValuePlatinum());
	    int actualG = Math.min(g, pile.getValueGold());
	    int actualS = Math.min(s, pile.getValueSilver());
	    int actualC = Math.min(c, pile.getValueCopper());

	    // reduce original pile
	    pile.setValue(
	        pile.getValuePlatinum() - actualP,
	        pile.getValueGold() - actualG,
	        pile.getValueSilver() - actualS,
	        pile.getValueCopper() - actualC
	    );

	    // create new pile for dropped coins
	    ObjectItem newPile = ObjectManager.createObjById(Currency.PILE_ID);
	    newPile.setValue(actualP, actualG, actualS, actualC);
	    return newPile;
	}



	// ---------------------
	// Filter items that are gettable
	private static List<ObjectItem> filterGettable(Mob player, List<ObjectItem> items) {
		List<ObjectItem> gettable = new ArrayList<>();
		for (ObjectItem item : items) {
			if (item.hasEffect(ItemEffect.NOTAKE)) {
				player.sendMessage("You cannot take " + item.getShortDescription() + ".");
			} else {
				gettable.add(item);
			}
		}
		return gettable;
	}

	public static void handleOpen(Mob player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Open what?");
			return;
		}

		// Parse direction or target from args, supporting inputs like:
		// "open east", "open door east", "open the east door"
		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Open what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try to interpret target as a direction for door
		// Try to interpret target as a direction for door
		Direction dir = null;

		// First: exact direction match
		for (Direction d : Direction.values()) {
			if (d.name().equalsIgnoreCase(target)) {
				dir = d;
				break;
			}
		}

		// Second: keyword-based door match
		if (dir == null) {
			dir = findDoorByKeyword(currentRoom, target);
		}

		if (dir != null) {
			Door door = currentRoom.getDoor(dir);
			if (door == null) {
				player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
				return;
			}
			if (door.isLocked()) {
				player.sendMessage(door.getDoorName() + " is locked.");
				return;
			}
			if (!door.isClosed()) {
				player.sendMessage(door.getDoorName() + " is already open.");
				return;
			}

			// Open this side
			door.setClosed(false);

			// Open the other side
			Room dest = currentRoom.getExit(dir);
			if (dest != null) {
				Door destDoor = dest.getDoor(dir.getOpposite());
				if (destDoor != null) {
					destDoor.setClosed(false);
				}
			}

			player.sendMessage("You open " + door.getDoorName().toLowerCase() + ".");
			currentRoom.broadcast(
					player.getMobName() + " opens " + door.getDoorName().toLowerCase() + ".", 
					player
					);
			return;
		}



		// Search for container in room or inventory by keywords
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && CommandProcessor.matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to open.");
			return;
		}
		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is locked.");
			return;
		}
		if (!container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already open.");
			return;
		}

		container.setClosed(false);
		player.sendMessage("You open the " + container.getName() + ".");
	}

	private static String parseDirectionOrTarget(String[] args) {
		String joined = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		joined = joined.replaceAll("\\bthe\\b", "")
				.replaceAll("\\bopen\\b", "")
				.trim();
		if (joined.isEmpty()) return null;
		return joined.split("\\s+")[0]; // still first token for now
	}


	private static Direction findDoorByKeyword(Room room, String target) {
		if (target == null || target.isEmpty()) return null;

		String[] targetParts = target.toLowerCase().split("[\\s._-]+");

		for (Direction dir : Direction.values()) {
			Door door = room.getDoor(dir);
			if (door == null) continue;

			for (String kw : door.getKeywords()) {
				String[] kwParts = kw.toLowerCase().split("[\\s._-]+");

				for (String t : targetParts) {
					for (String k : kwParts) {
						if (k.contains(t)) {
							return dir;
						}
					}
				}
			}

			// Fallback: generic "door"
			if (target.equalsIgnoreCase("door")) {
				return dir;
			}
		}
		return null;
	}
	// end


	private static Direction resolveDoorDirection(Room room, String target) {
		// Direct direction match
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				return dir;
			}
		}

		// Keyword match on doors
		for (Direction dir : Direction.values()) {
			Door door = room.getDoor(dir);
			if (door == null) continue;

			for (String kw : door.getKeywords()) {
				if (kw.equalsIgnoreCase(target)) {
					return dir;
				}
			}

			// Fallback generic "door"
			if (target.equalsIgnoreCase("door")) {
				return dir;
			}
		}

		return null;
	}
	// end


	public static String handleUnequip(Mob player, String itemNameOrSlot) {
		if (itemNameOrSlot == null || itemNameOrSlot.trim().isEmpty()) {
			return "Unequip what?";
		}

		String input = itemNameOrSlot.trim().toLowerCase();

		// --- Special case: unequip all ---
		if (input.equals("all")) {
			StringBuilder sb = new StringBuilder();
			boolean any = false;

			for (Map.Entry<EquipSlot, ObjectItem> entry : player.getEquipment().entrySet()) {
				ObjectItem item = entry.getValue();
				if (item != null) {
					player.getInventory().add(item);
					entry.setValue(null);
					sb.append("You unequip the ").append(item.getName())
					.append(" from your ").append(entry.getKey().name().toLowerCase()).append(".\n");
					any = true;
				}
			}

			if (!any) return "You are not wearing or wielding anything.";
			return sb.toString().trim();
		}

		// --- Normal case: try parsing as slot ---
		EquipSlot slot = EquipSlot.fromString(input);
		ObjectItem unequipped = null;

		if (slot != null) {
			unequipped = player.getEquipment().get(slot);
		} else {
			// Try matching by item name if no valid slot
			for (Map.Entry<EquipSlot, ObjectItem> entry : player.getEquipment().entrySet()) {
				ObjectItem item = entry.getValue();
				if (item != null && item.getName().equalsIgnoreCase(input)) {
					slot = entry.getKey();
					unequipped = item;
					break;
				}
			}
		}

		if (unequipped == null || slot == null) {
			return "You are not wearing or wielding that.";
		}

		// Remove from equipped slot
		player.getEquipment().put(slot, null);

		// Add to inventory
		player.getInventory().add(unequipped);

		player.sendMessage("You unequip the " + unequipped.getName() + " from your " + slot.name().toLowerCase() + ".");
		player.getCurrentRoom().broadcastExcept(player.getMobName() + " unequipped " + unequipped.getName() + ".", player);

		return null;
	} // end handleUnequip






} // end InteractionHandler
