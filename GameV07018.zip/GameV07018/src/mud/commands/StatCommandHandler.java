package mud.commands;

import mud.Shop.BankManager;
import mud.core.*;
import mud.editor.*;
import mud.scripting.ZoneScript;

import java.util.*;

@SuppressWarnings("unused")
public class StatCommandHandler {

    public static void handleStat(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("Usage: stat <mob|object|player|room|zone|world> <id/name>");
            return;
        }

        String type = args[1].toLowerCase();
        String identifier = String.join(" ", Arrays.copyOfRange(args, 2, args.length));

        switch (type) {
            case "mob" -> statMob(player, identifier);
            case "obj" -> statObject(player, identifier);
            case "object" -> statObject(player, identifier);
            case "player" -> statPlayer(player, identifier);
            case "room" -> statRoom(player);
            case "script" -> statScript(player);
            case "zonescript" -> statScript(player);
            case "zone" -> statZone(player);
            case "world" -> {
                if (args.length == 2) {
                    statWorld(player, identifier);
                } else {
                    statWorld(player, null);
                }
            }

            default -> player.sendMessage("Unknown stat type: " + type);
        }
    }

    private static void statMob(Player player, String idOrName) {
        try {
            int id = Integer.parseInt(idOrName);
            Mob mob = WorldManager.getMobById(id,player.getCurrentRoom());
            if (mob == null) {
                player.sendMessage("No mob with ID " + id);
                return;
            }
            player.sendMessage(mob.returnStatBlock());
        } catch (NumberFormatException e) {
            Mob mob = WorldManager.findMobByName(idOrName);
            if (mob == null) {
                player.sendMessage("No mob named '" + idOrName + "'");
                return;
            }
            player.sendMessage(mob.returnStatBlock());
        }
    }

    private static void statObject(Player player, String idOrName) {
    //	int id = Integer.valueOf(idOrName);
    //    ObjectItem obj = WorldManager.getObjectById(id);
        
        try {
            int id = Integer.parseInt(idOrName);
            ObjectItem obj = WorldManager.getObjectById(id); 
            if (obj == null) {
                player.sendMessage("No obj with ID " + id);
                return;
            }
            player.sendMessage(obj.returnStatBlock());
        } catch (NumberFormatException e) {
        	ObjectItem obj = WorldManager.getObjectByIdOrName(idOrName);
            if (obj == null) {
                player.sendMessage("No obj named '" + idOrName + "'");
                return;
            }
            player.sendMessage(obj.returnStatBlock());;
        }
    }

    private static void statPlayer(Player player, String name) {
        Player target = WorldManager.getPlayerByName(name);
        if (target != null) {
        	player.sendMessage(target.returnStatBlock());
        	player.sendMessage(BankManager.listVaultContents(player));
        }
        else player.sendMessage("Player not found: " + name);
    }

    private static void statRoom(Player player) {
        Room room = player.getCurrentRoom();
        player.sendMessage(room.returnStatBlock());
    }

    private static void statZone(Player player) {
        Zone zone = player.getCurrentRoom().getZone();
        player.sendMessage(zone.returnStatBlock());
    }

    private static void statScript(Player player) {
    	ZoneScript zs = player.getCurrentZone().getScript();
    	player.sendMessage(zs.returnStatBlock());
    }
    
    private static void statWorld(Player player, String identifier) {
        World world = null;
        world = player.getCurrentWorld();

        if (identifier == null || identifier.isBlank()) {
            Room currentRoom = player.getCurrentRoom();
            if (currentRoom != null) {
                Zone currentZone = currentRoom.getZone();
                if (currentZone != null) {
                    world = currentZone.getWorld();
                }
            }
        } else {
            world = WorldManager.getWorld();

            // Try by name if ID lookup failed
            if (world == null) {
            	player.getCurrentWorld();
            	
            }
        }
        world = player.getWorld();
        if (world == null) {
            player.sendMessage("World not found: " + (identifier != null ? identifier : "(current)"));
            return;
        }

        player.sendMessage(WorldManager.getWorldStatBlock(world));
    }

    

} // end
