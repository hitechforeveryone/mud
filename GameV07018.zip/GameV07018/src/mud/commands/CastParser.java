package mud.commands;

import mud.core.*;
import mud.core.enums.Direction;
import mud.spell.Spell;
import java.util.List;

public class CastParser {

    /**
     * Parse raw target input and produce a fully resolved CastSpec
     */
    public static CastSpec parse(Mob caster, Spell spell, String rawTarget) {
        if (caster == null || spell == null) return null;

        // Create the spec with raw input
        CastSpec spec = new CastSpec(caster, spell, rawTarget);

        // --- Auto self-target ---
        if ((rawTarget == null || rawTarget.isEmpty()) && spell.isSelfTarget()) {
            spec.setSelfTarget();
            return spec;
        }

        if (rawTarget == null || rawTarget.isEmpty()) {
            return spec; // will be handled by caller as "no target"
        }

        String targetName = rawTarget.toLowerCase().trim();
        int typeFilter = -1;

        // Parse numbered format like "2.goblin"
        if (targetName.matches("^\\d+\\..+")) {
            int dotIndex = targetName.indexOf('.');
            try {
                typeFilter = Integer.parseInt(targetName.substring(0, dotIndex));
                targetName = targetName.substring(dotIndex + 1);
            } catch (NumberFormatException ignored) {}
        }

        String[] sections = targetName.split("\\."); // multi-keyword chain

        Room room = caster.getCurrentRoom();
        if (room == null) return spec;

        // -----------------------------------------------------
        // 1) MOB in room
        // -----------------------------------------------------
        if (typeFilter == -1 || typeFilter == 1) {
            List<Mob> mobs = room.getMobs();
            for (Mob mob : mobs) {
                if (mob != null && matchesSections(mob.getMobName(), mob.getKeywords(), sections)) {
                    if (!mob.isDead()) {
                        spec.setMobTarget(mob);
                        return spec;
                    } else {
                        caster.sendMessage(mob.getMobName() + " is already dead.");
                        return spec;
                    }
                }
            }
        }

        // -----------------------------------------------------
        // 2) Specialized zone-wide / locate spells
        // -----------------------------------------------------
        if (typeFilter == -1 || typeFilter == 2) {
            if (spell instanceof mud.spell.LocateCreatureSpell lc) {
                if (lc.cast(caster, sections)) {
                    spec.setZoneMobTarget(null); // could be extended if we want exact mob
                    return spec;
                }
            }
            if (spell instanceof mud.spell.LocateObjectSpell lo) {
                if (lo.cast(caster, sections)) {
                    spec.setObjectTarget(null); // optional
                    return spec;
                }
            }
        }

        // -----------------------------------------------------
        // 3) Inventory objects
        // -----------------------------------------------------
        if (typeFilter == -1 || typeFilter == 3) {
            ObjectItem invObj = caster.getInventory().stream()
                    .filter(o -> matchesSections(o.getName(), o.getKeywords(), sections))
                    .findFirst().orElse(null);
            if (invObj != null) {
                spec.setObjectTarget(invObj);
                return spec;
            }
        }

        // -----------------------------------------------------
        // 4) Room objects
        // -----------------------------------------------------
        if (typeFilter == -1 || typeFilter == 4) {
            ObjectItem roomObj = room.getObjects().stream()
                    .filter(o -> matchesSections(o.getName(), o.getKeywords(), sections))
                    .findFirst().orElse(null);
            if (roomObj != null) {
                spec.setObjectTarget(roomObj);
                return spec;
            }
        }

        // -----------------------------------------------------
        // 5) Directional target
        // -----------------------------------------------------
        if ((typeFilter == -1 || typeFilter == 5) && spell.isDirectional()) {
            Direction dir = Direction.fromString(targetName);
            if (dir != null) {
                spec.setDirectionTarget(dir);
                return spec;
            }
        }

        // -----------------------------------------------------
        // 6) Zone-wide mobs
        // -----------------------------------------------------
        if (typeFilter == -1 || typeFilter == 6) {
            Zone zone = room.getZone();
            if (zone != null) {
                for (Room r : zone.getRooms().values()) {
                    for (Mob m : r.getMobs()) {
                        if (m != null && matchesSections(m.getMobName(), m.getKeywords(), sections)) {
                            if (!m.isDead()) {
                                spec.setZoneMobTarget(m);
                                return spec;
                            }
                        }
                    }
                }
            }
        }

        // If nothing matched, spec.targetType stays NONE
        return spec;
    }

    // -----------------------
    // Helper: multi-section keyword matching
    // -----------------------
    private static boolean matchesSections(String name, List<String> keywords, String[] sections) {
        name = name.toLowerCase();
        for (String section : sections) {
            boolean found = name.contains(section);
            if (!found && keywords != null) {
                found = keywords.stream().anyMatch(k -> k.toLowerCase().contains(section));
            }
            if (!found) return false;
        }
        return true;
    }

}
