package mud.commands;

import mud.core.*;
import mud.core.enums.Direction;
import mud.spell.Spell;

public class CastSpec {

    // -------------------------------------------------
    // Who / what
    // -------------------------------------------------
    private final Mob caster;
    private final Spell spell;

    // -------------------------------------------------
    // Target resolution
    // -------------------------------------------------
    public enum TargetType {
        SELF,
        MOB,
        OBJECT,
        DIRECTION,
        ZONE_MOB,
        NONE
    }

    private TargetType targetType = TargetType.NONE;

    private Mob mobTarget;
    private ObjectItem objectTarget;
    private Direction directionTarget;

    // Raw input (for messages / scripts)
    private final String rawTarget;

    // Optional metadata
    private int spellLevel = -1;

    // -------------------------------------------------
    // Constructor
    // -------------------------------------------------
    public CastSpec(Mob caster, Spell spell, String rawTarget) {
        this.caster = caster;
        this.spell = spell;
        this.rawTarget = rawTarget;
    }

    // -------------------------------------------------
    // Setters (used ONLY by CastParser)
    // -------------------------------------------------
    public void setSelfTarget() {
        this.targetType = TargetType.SELF;
    }

    public void setMobTarget(Mob mob) {
        this.targetType = TargetType.MOB;
        this.mobTarget = mob;
    }

    public void setObjectTarget(ObjectItem obj) {
        this.targetType = TargetType.OBJECT;
        this.objectTarget = obj;
    }

    public void setDirectionTarget(Direction dir) {
        this.targetType = TargetType.DIRECTION;
        this.directionTarget = dir;
    }

    public void setZoneMobTarget(Mob mob) {
        this.targetType = TargetType.ZONE_MOB;
        this.mobTarget = mob;
    }

    public void setSpellLevel(int level) {
        this.spellLevel = level;
    }

    // -------------------------------------------------
    // Getters (used by CombatSpellHandler)
    // -------------------------------------------------
    public Mob getCaster() {
        return caster;
    }

    public Spell getSpell() {
        return spell;
    }

    public TargetType getTargetType() {
        return targetType;
    }

    public Mob getMobTarget() {
        return mobTarget;
    }

    public ObjectItem getObjectTarget() {
        return objectTarget;
    }

    public Direction getDirectionTarget() {
        return directionTarget;
    }

    public String getRawTarget() {
        return rawTarget;
    }

    public int getSpellLevel() {
        return spellLevel > 0 ? spellLevel : caster.getLevel();
    }

    // -------------------------------------------------
    // Convenience helpers
    // -------------------------------------------------
    public boolean hasTarget() {
        return targetType != TargetType.NONE;
    }

    public boolean isSelf() {
        return targetType == TargetType.SELF;
    }
}
