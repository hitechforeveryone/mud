package mud.core;

public final class Currency {
	public static final int PILE_ID = 10;
    public static final int COPPER_ID = 11;
    public static final int SILVER_ID = 12;
    public static final int GOLD_ID   = 13;
    public static final int PLAT_ID   = 14;

    private Currency() {}
}
