package mud.core.enums;


public enum TreasureValue {
    NONE(0),
    POOR(1),
    MODEST(2),
    RICH(3),
    WEALTHY(4),
    OPULENT(5);

    private final int tier;

    TreasureValue(int tier) {
        this.tier = tier;
    }

    public int getTier() {
        return tier;
    }
}
