package mud.core.enums;

public enum RoomDirection {
    NORTH, EAST, SOUTH, WEST, UP, DOWN, NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST;
}
