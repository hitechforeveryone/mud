package mud.core.enums;

public enum WeaponDamageType {
    HIT("hit", "💥"),              // Default/fallback
    BITE("bite", "🦷"),
    CLAW("claw", "🐾"),
    CLEAVE("cleave", "🪓"),
    CRUSH("crush", "🦴 "),
    HOOK("hook", "🪝"),
    SLASH("slash", "🗡️"),
    PIERCE("pierce", "📌"),
    POUND("pound", "🔨"),
    SHOOT("shoot", "🏹"),
    SMITE("smite", "🕊️"),
    SPEAR("spear", "⚚"),
    STAB("stab", "🔪"),
    STING("sting", "🐝"),
    WHIP("whip", "🔗"),
    VAMPIRIC("vampiric", "🧛"),
    MAGIC("magical", "✨");

    private final String prettyName;
    private final String icon;

    WeaponDamageType(String prettyName, String icon) {
        this.prettyName = prettyName;
        this.icon = icon;
    }

    public String getPrettyName() {
        return prettyName;
    }

    public String getIcon() {
        return icon;
    }

    public static WeaponDamageType fromString(String input) {
        if (input == null) return null;
        String normalized = input.trim().toLowerCase();
        for (WeaponDamageType type : values()) {
            if (type.name().equalsIgnoreCase(normalized) || type.prettyName.equalsIgnoreCase(normalized)) {
                return type;
            }
        }
        return null;
    }
}
