package mud.core;

public final class IdUtil {

    private static final int ID_WIDTH = 7;

    public static String format(int id) {
        return String.format("%0" + ID_WIDTH + "d", id);
    }

    public static int parse(String s) {
        return Integer.parseInt(s); // leading zeros are fine
    }

    private IdUtil() {}
}
