package mud.core;

import mud.core.enums.MagicDamageType;
import mud.core.enums.WeaponDamageType;

public class DamageContext {

    public enum DamageSource {
        MELEE,
        SPELL,
        EFFECT,
        ENVIRONMENT
    }

    private final Mob attacker;
    private final Mob target;

    private int baseDamage;
    private int finalDamage;

    private WeaponDamageType weaponDamageType;
    private MagicDamageType magicDamageType;

    private DamageSource source;

    private boolean blocked = false;
    private boolean absorbed = false;

    public DamageContext(
            Mob attacker,
            Mob target,
            int baseDamage,
            DamageSource source
    ) {
        this.attacker = attacker;
        this.target = target;
        this.baseDamage = baseDamage;
        this.finalDamage = baseDamage;
        this.source = source;
    }

    /* =========================
     * Core getters
     * ========================= */

    public Mob getAttacker() { return attacker; }
    public Mob getTarget() { return target; }

    public int getBaseDamage() { return baseDamage; }
    public int getFinalDamage() { return finalDamage; }

    public DamageSource getSource() { return source; }

    public WeaponDamageType getWeaponDamageType() {
        return weaponDamageType;
    }

    public MagicDamageType getMagicDamageType() {
        return magicDamageType;
    }

    /* =========================
     * Mutators (used by Effects)
     * ========================= */

    public void setFinalDamage(int dmg) {
        this.finalDamage = Math.max(0, dmg);
    }

    public void modifyDamagePercent(double percent) {
        this.finalDamage = (int)Math.round(this.finalDamage * percent);
    }

    public void reduceDamage(int amount) {
        this.finalDamage = Math.max(0, this.finalDamage - amount);
    }

    public void block() {
        this.blocked = true;
        this.finalDamage = 0;
    }

    public void absorb() {
        this.absorbed = true;
        this.finalDamage = 0;
    }

    /* =========================
     * Flags
     * ========================= */

    public boolean isBlocked() { return blocked; }
    public boolean isAbsorbed() { return absorbed; }

    /* =========================
     * Type setters
     * ========================= */

    public void setWeaponDamageType(WeaponDamageType type) {
        this.weaponDamageType = type;
    }

    public void setMagicDamageType(MagicDamageType type) {
        this.magicDamageType = type;
    }
}
