package mud.core;

public final class GemIds {

    // Small gems (tier 2)
    public static final int[] SMALL_GEMS = {100, 103, 104, 105}; // add your small gem IDs here

    // Medium gems (tier 3)
    public static final int[] MEDIUM_GEMS = {101, 106, 107, 108};

    // Large gems (tier 4–5)
    public static final int[] LARGE_GEMS = {102, 109, 110, 111};

    private GemIds() {}
}
