package Game;
//TODO
// THE GAME CURRENTLY DOES NOT USE THIS AT ALL THIS IS FOR DESIGN PURPOSES

/////////////////////////////////
// zone should have 100 rooms in it (0-99), the array will continue to build around you if you skip a room
// each room can have up to 6 mobs and 6 objects in it
/////////////////////////////////

public class zone {
	// TODO

	int zoneNum; //0 // should be up to 6 digits?    
	String zoneOwner; //1 Char name?
	String zoneName; //2 optional
	int resetTimer; //3 time till zone reloads, in weeks or months?

	room rm00; // should be 2 digits?
	room rm01;
	room rm02;
	room rm03;
	room rm04;
	room rm05;
	room rm06;
	room rm07;
	room rm08;
	room rm09;

	room rm10;
	room rm11;
	room rm12;
	room rm13;
	room rm14;
	room rm15;
	room rm16;
	room rm17;
	room rm18;
	room rm19;

	room rm20;
	room rm21;
	room rm22;
	room rm23;
	room rm24;
	room rm25;
	room rm26;
	room rm27;
	room rm28;
	room rm29;

	room rm30;
	room rm31;
	room rm32;
	room rm33;
	room rm34;
	room rm35;
	room rm36;
	room rm37;
	room rm38;
	room rm39;

	room rm40;
	room rm41;
	room rm42;
	room rm43;
	room rm44;
	room rm45;
	room rm46;
	room rm47;
	room rm48;
	room rm49;

	room rm50;
	room rm51;
	room rm52;
	room rm53;
	room rm54;
	room rm55;
	room rm56;
	room rm57;
	room rm58;
	room rm59;

	room rm60;
	room rm61;
	room rm62;
	room rm63;
	room rm64;
	room rm65;
	room rm66;
	room rm67;
	room rm68;
	room rm69;

	room rm70;
	room rm71;
	room rm72;
	room rm73;
	room rm74;
	room rm75;
	room rm76;
	room rm77;
	room rm78;
	room rm79;

	room rm80;
	room rm81;
	room rm82;
	room rm83;
	room rm84;
	room rm85;
	room rm86;
	room rm87;
	room rm88;
	room rm89;

	room rm90;
	room rm91;
	room rm92;
	room rm93;
	room rm94;
	room rm95;
	room rm96;
	room rm97;
	room rm98;
	room rm99;




	public void resetZone() {



	} // end resetZone()



} // end zone ....





// TODO
// scripts which load mobs and objs? doors? // load next zone

// roomScript srm00;  // create as needed? // set mob and obj defaults to all 0s?
// setObj0(0,100);setObj1(0,100);setOBj2(0,100);setObj3(0,100);setObj4(0,100);setObj5(0,100); //  set the obj to 0 at 100%?

// setMob0(0,100);setMob1(0,100);setMob2(0,100);setMob3(0,100);setMob4(0,100);setMob5(0,100); // set the mob to 0 at 100%?

// tmob0Head(0,1000;tmob0Neck(0,100);tmob0Shoulder(0,100);tmob0Chest(0,100);tmob0Wrist(0,100);tmob0Hand(0,100);tmob0Finger1(0,100);tmob0Finger2(0,100);
// tmob0Waist(0,100);tmob0Leg(0,100);tmob0Foot(0,100);tmob0Trinket1(0,100);tmob0Trinket2(0,100);tmob0Weapon1(0,100);tmob0Weaponshield(0,100); // set all equip to obj 0 at 100%?

// script load zone xxxxxx
//		to be used for loading next zones
//		to be used for loading the 6 objs in the rooms
//		to be used for loading the 6 mobs in the rooms
//		to be used for loading the equip on the mobs



