package Game;

import java.util.Arrays;

public class objects {
	// head, neck, shoulder, chest, wrist, hands, finger1/2, waist, leg, foot, trinket1/2, weapon, weaponshield

	// Default Object
	int objNum; //0
	String objName; //1
	String objShortDesc; //2
	String objLongDesc; //3
	String objExtDesc; //4
	String[] objKeyWords = new String[3];  //5
	int addStr = 0; //6
	int addStam = 0; //7
	int addInt = 0; //8
	int addAgi = 0; //9
	int addHP = 0 ; //10
	int addMP = 0; //11
	int durability = 0; //12
	int takeable = 1;  //13
	String equipSlot; //14
	String  objval = "0,0,0,0"; // 15 // comma sep value, 4 parameter?
	String objType = "none";// 16 // obj type // none, weapon (MH or OH), armor (armor, trinkets, shields), food, drink, potion?, scroll?, wand?, treasure?, coin?, trash?, containers?
	int stackSize = 1;  //17 // stack size? <20?
	String weaponType = "none"; //18 // weapon type // none, sword, dagger, hammer/mace, spear, whip
	String weaponDmg = "0d0"; //19 // weapon dmg // 0, 
	String wpndmgType = "hits"; //20 // weapon dmg type // hits, slashes, pierces, pound, stab, sting
	String v21 = "unused"; //21 // unused
	
	
	String armorType = "none"; //22 // armor type // none (0%), cloth (1-2%), leather (3-4%), mail (4-5%), plate (5-10%?), shields (5-10%)?
	int dmgRedux = 0; //23 // dmg redux // should be a % between 0-5? up to 10
	
	
	int hpRestore = 0; //24 // food // hps to restore?
	int mpRestore = 0; //25 // drink // mana to restore?
	String potSpell = "none"; //26 // potion? // buff/special effect?, self-target spells
	String scrollSpell = "none"; //27 // scroll // spell? // either self-target or attack?
	String wandSpell = "none"; //28 // wand // spell // attack spells?
	int wandCharge = 0; //29 // wand charges // 0-5?
	int cntSize = 0; //30 // container size?
	String[] cntCont = new String[cntSize]; //31 // container contents?

	String v32 = "unused";
	String v33 = "unused";
	String v34 = "unused";
	String v35 = "unused";
	String v36 = "unused";
	String v37 = "unused";
	String v38 = "unused";
	String v39 = "unused";

	String v40 = "unused";

	String v41 = "0";
	String v42 = "unused";
	String v43 = "unused";
	String v44 = "unused";
	String v45 = "unused";

	int blueGlow = 0; // blue glow
	int redGlow = 0; // red glow
	int hum = 0; // hum
	int cursed = 0; // cursed
	String objglows ="";

	public int getAddAgi() {
		return this.addAgi;
	}

	public int getAddHP() {
		return this.addHP;
	}

	public int getAddInt() {
		return this.addInt;
	}

	public int getAddMP() {
		return this.addMP;
	}

	public int getAddStam() {
		return this.addStam;
	}

	public int getAddStr() {
		return this.addStr;
	}

	public String getArmorType() {
		return this.armorType;
	}

	public int getBlueGlow() {
		return this.blueGlow;
	}

	public String getcntCont(int i) {
		String temp = Arrays.toString(getObjKeyWords());
		temp = temp.replace("[", "");
		temp = temp.replace("]", "");
		temp = temp.strip();
		String[] split = temp.split(",");		
		return split[i];
		//	return this.cntCont;
	}

	public String[] getCntCont() {
		return this.cntCont;
	}

	public int getCntSize() {
		return this.cntSize;
	}

	public int getCursed() {
		return this.cursed;
	}

	public int getDmgRedux() {
		return this.dmgRedux;
	}

	public int getDurability() {
		return this.durability;
	}

	public String getEquipSlot() {
		return this.equipSlot;
	}

	public int getHpRestore() {
		return this.hpRestore;
	}

	public int getHum() {
		return this.hum;
	}

	public String getKeyWord(int i) {
		String temp = Arrays.toString(getObjKeyWords());
		temp = temp.replace("[", "");
		temp = temp.replace("]", "");
		temp = temp.strip();
		String[] split = temp.split(",");		
		return split[i];
	}

	public String getKeyWord1() {
		return this.objKeyWords[0];
	}
	public String getKeyWord2() {
		return this.objKeyWords[1];
	}
	public String getKeyWord3() {
		return this.objKeyWords[2];
	}

	public int getMpRestore() {
		return this.mpRestore;
	}

	public String getObjExtDesc() {
		return this.objExtDesc;
	}

	public String getObjGlows() {
		objglows = "";
		String bglow = "";
		String rglow = "";
		String humm = "";
		String curses = "";
		if (getBlueGlow() == 1) {
			bglow = "...it glows blue ";
		}
		else { bglow = "  "; }
		if (getRedGlow() == 1 ) {
			rglow = "...it glows red ";
		}
		else { rglow = " "; }
		if (getHum() == 1) {
			humm = "...it hums dangerously ";
		}
		else { humm = " "; }
		if (getCursed() == 1) {
			curses = "...it is cursed!";
		}
		else { curses = " "; }

		objglows =  bglow + rglow + humm + curses ; 
		return this.objglows;
	}

	public String[] getObjKeyWords() {
		return this.objKeyWords;
	}

	public String getObjLongDesc() {
		return this.objLongDesc;
	}

	public String getObjName() {
		return this.objName;
	}

	public int getObjNum() {
		return this.objNum;
	}

	public String getObjShortDesc() {
		return this.objShortDesc;
	}

	public String getObjType() {
		return this.objType;
	}

	public String getObjval() {
		return this.objval;
	}

	public String getPotSpell() {
		return this.potSpell;
	}

	public int getRedGlow() {
		return this.redGlow;
	}

	public String getScrollSpell() {
		return this.scrollSpell;
	}

	public int getStackSize() {
		return this.stackSize;
	}

	public int getTakeable() {
		return this.takeable;
	}

	public String getV21() {
		return this.v21;
	}

	public String getV32() {
		return this.v32;
	}

	public String getV33() {
		return this.v33;
	}

	public String getV34() {
		return this.v34;
	}

	public String getV35() {
		return this.v35;
	}

	public String getV36() {
		return this.v36;
	}

	public String getV37() {
		return this.v37;
	}

	public String getV38() {
		return this.v38;
	}

	public String getV39() {
		return this.v39;
	}

	public String getV40() {
		return this.v40;
	}

	public String getV41() {
		return this.v41;
	}

	public String getV42() {
		return this.v42;
	}

	public String getV43() {
		return this.v43;
	}

	public String getV44() {
		return this.v44;
	}

	public String getV45() {
		return this.v45;
	}

	public int getWandCharge() {
		return this.wandCharge;
	}

	public String getWandSpell() {
		return this.wandSpell;
	}

	public String getWeaponDmg() {
		return this.weaponDmg;
	}

	public String getWeaponType() {
		return this.weaponType;
	}

	public String getWpndmgType() {
		return this.wpndmgType;
	}

	public void setAddAgi(int addAgi) {
		this.addAgi = addAgi;
	}

	public void setAddHP(int addHP) {
		this.addHP = addHP;
	}

	public void setAddInt(int addInt) {
		this.addInt = addInt;
	}

	public void setAddMP(int addMP) {
		this.addMP = addMP;
	}

	public void setAddStam(int addStam) {
		this.addStam = addStam;
	}

	public void setAddStr(int addStr) {
		this.addStr = addStr;
	}

	public void setArmorType(String armorType) {
		this.armorType = armorType;
	}

	public void setBlueGlow(int blueGlow) {
		this.blueGlow = blueGlow;
	}

	public void setCntCont(String[] cntCont) {
		this.cntCont = cntCont;
	}

	public void setCntSize(int cntSize) {
		this.cntSize = cntSize;
	}

	public void setCursed(int cursed) {
		this.cursed = cursed;
	}

	public void setDmgRedux(int dmgRedux) {
		this.dmgRedux = dmgRedux;
	}

	public void setDurability(int durability) {
		this.durability = durability;
	}

	public void setEquipSlot(String equipSlot) {
		this.equipSlot = equipSlot;
	}

	public void setHpRestore(int hpRestore) {
		this.hpRestore = hpRestore;
	}

	public void setHum(int hum) {
		this.hum = hum;
	}

	public void setMpRestore(int mpRestore) {
		this.mpRestore = mpRestore;
	}

	public void setObjExtDesc(String objExtDesc) {
		this.objExtDesc = objExtDesc;
	}

	public void setObjKeyWords(String[] objKeyWords) {
		this.objKeyWords = objKeyWords;
	}
	public void setMobKeyWords(String[] objKeyWords) {
		this.objKeyWords = objKeyWords;
	}
	public void setObjKeyword1(String s) {
		this.objKeyWords[0] = s;
	}
	public void setObjKeyword2(String s) {
		this.objKeyWords[1] = s;
	}
	public void setObjKeyword3(String s) {
		this.objKeyWords[2] = s;
	}

	public void setObjLongDesc(String objLongDesc) {
		this.objLongDesc = objLongDesc;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public void setObjNum(int objNum) {
		this.objNum = objNum;
	}

	public void setObjShortDesc(String objShortDesc) {
		this.objShortDesc = objShortDesc;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public void setObjval(String objval) {
		this.objval = objval;
	}

	public void setPotSpell(String potSpell) {
		this.potSpell = potSpell;
	}

	public void setRedGlow(int redGlow) {
		this.redGlow = redGlow;
	}

	public void setScrollSpell(String scrollSpell) {
		this.scrollSpell = scrollSpell;
	}

	public void setStackSize(int stackSize) {
		this.stackSize = stackSize;
	}

	public void setTakeable(int takeable) {
		this.takeable = takeable;
	}

	public void setV21(String v21) {
		this.v21 = v21;
	}

	public void setV32(String v32) {
		this.v32 = v32;
	}

	public void setV33(String v33) {
		this.v33 = v33;
	}

	public void setV34(String v34) {
		this.v34 = v34;
	}

	public void setV35(String v35) {
		this.v35 = v35;
	}

	public void setV36(String v36) {
		this.v36 = v36;
	}

	public void setV37(String v37) {
		this.v37 = v37;
	}

	public void setV38(String v38) {
		this.v38 = v38;
	}

	public void setV39(String v39) {
		this.v39 = v39;
	}

	public void setV40(String v40) {
		this.v40 = v40;
	}
	public void setV41(String v41) {
		this.v41 = v41;
	}

	public void setV42(String v42) {
		this.v42 = v42;
	}

	public void setV43(String v43) {
		this.v43 = v43;
	}

	public void setV44(String v44) {
		this.v44 = v44;
	}

	public void setV45(String v45) {
		this.v45 = v45;
	}

	public void setWandCharge(int wandCharge) {
		this.wandCharge = wandCharge;
	}

	public void setWandSpell(String wandSpell) {
		this.wandSpell = wandSpell;
	}

	public void setWeaponDmg(String weaponDmg) {
		this.weaponDmg = weaponDmg;
	}

	public void setWeaponType(String weaponType) {
		this.weaponType = weaponType;
	}

	public void setWpndmgType(String wpndmgType) {
		this.wpndmgType = wpndmgType;
	}


	public void resetObject() {

		objNum = 0; //0
		objName = "a lint ball"; //1
		objShortDesc = "none"; //2
		objLongDesc = "object is reset and not initialized"; //3
		objExtDesc = "nothing"; //4

		String[] objKeyWords = new String[3];//5
		objKeyWords[0] = "none"; 
		objKeyWords[1] = "none"; 
		objKeyWords[2] = "none"; 

		addStr = 0; //6
		addStam = 0; //7
		addInt = 0; //8
		addAgi = 0; //9
		addHP = 0 ; //10
		addMP = 0; //11
		durability = 0; //12
		takeable = 1; //13
		equipSlot = "none"; //14

		objval = "0,0,0,0"; // 15 // comma sep value, 4 parameter?

		objType = "none";// 16 // obj type // none, weapon (MH or OH), armor (armor, trinkets, shields), food, drink, potion?, scroll?, wand?, treasure?, coin?, trash?, containers?, sign, book, part?

		stackSize = 1;  //17 // stack size? <20?

		weaponType = "none";//18 // weapon type // none, sword, dagger, hammer/mace, spear, whip
		weaponDmg = "0d0";//19 // weapon dmg // 0, 
		wpndmgType = "hits";//20 // weapon dmg type // hits, slashes, pierces, pound, stab, sting

		v21 = "unused";//21 // unused

		armorType = "none";//22 // armor type // none (0%), cloth (1-2%), leather (3-4%), mail (4-5%), plate (5-10%?), shields (5-10%)?
		dmgRedux = 0;//23 // dmg redux // should be a % between 0-5? up to 10
		
		hpRestore = 0;//24 // food // hps to restore?
		mpRestore = 0;//25 // drink // mana to restore?
		potSpell = "none";//26 // potion? // buff/special effect?, self-target spells
		scrollSpell = "none";//27 // scroll // spell? // either self-target or attack?
		wandSpell = "none";//28 // wand // spell // attack spells?
		wandCharge = 0;//29 // wand charges // 0-5?
		cntSize = 1;//30 // container size
		String[] cntCont = new String[cntSize];//31 // container contents?
		cntCont[0] = "0";

		v32 = "unused";
		v33 = "unused";
		v34 = "unused";
		v35 = "unused";
		v36 = "unused";
		v37 = "unused";
		v38 = "unused";
		v39 = "unused";
		v40 = "unused"; 

		v41 = "unused";
		v42 = "unused";
		v43 = "unused";
		v44 = "unused";
		v45 = "unused";

		blueGlow = 0;// blue glow?
		redGlow = 0;// red glow?
		hum = 0;// hum?
		cursed = 0;// cursed?
	}

	public void returnObjArmor() {
		// returns relevant info for armor 
		System.out.println("from returnObjArmor()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.replace("[","").replace("]","").split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: [" + getKeyWord(0).strip() + "]   Keyword 2: [" + getKeyWord(1).strip()  + "]   Keyword 3: [" + getKeyWord(2).strip() + "]"); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Armor Type: " + getArmorType());
		System.out.println("Damage Redux: " + getDmgRedux());


	}

	public void returnObjBook() {
		// returns relevant info for book objects
		System.out.println("from returnObjBook()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Wand Spell: " + getWandSpell());
		System.out.println("Wand Charges: " + getWandCharge());


	}

	public void returnObjCoin() {
		// returns relevant info for coin objs
		System.out.println("from returnObjTreasure()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		keys.replace("[", "");
		keys.replace("]", "");
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());


	}

	public void returnObjContainer() {
		// returns relevant info for container objs
		System.out.println("from returnObjContainer()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3e
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Container Size: " + getCntSize());


		String cont = Arrays.toString(getCntCont());
		cont.replace("[", "");
		cont.replace("]", "");
		//System.out.println("Keywords: "+ keys);  //4  
		System.out.println("Container Contents: " + cont);


	}

	public void returnObjDrink() {
		//returns relevant info for drink objs
		System.out.println("from returnObjDrink()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Drink Mana Restore: " + getMpRestore());


	}
	public void returnObjectDefStats() {
		System.out.println("Object Durability: " + getDurability());
		System.out.println("Object is Takeable: " + getTakeable());
		System.out.println("Object equip slot: " + getEquipSlot());

		System.out.println("Object Buffs: ");
		System.out.println("Strength: " + getAddStr());
		System.out.println("Stamina: " + getAddStam());
		System.out.println("Intellect: " + getAddInt());
		System.out.println("Agility: " + getAddAgi());
		System.out.println("Health Points: " + getAddHP());
		System.out.println("Mana Points: " + getAddMP());

		System.out.println("Item Blue Glow: " + getBlueGlow());
		System.out.println("Item Red Glow: " + getRedGlow());
		System.out.println("Item Hum: " + getHum());
		System.out.println("Item Cursed: " + getCursed());
	}
	public void returnObjectFull() {
		// returns all obj fields
		System.out.println("from returnObjectFull()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Long Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		keys.replace(" ", "");
		keys.strip();
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Keyword 2: [" + getKeyWord1() + "]   Keyword 2: [" + getKeyWord2()  + "]   Keyword 3: [" + getKeyWord3() + "]"); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());
		System.out.println("Object Durability: " + getDurability());
		System.out.println("Object is Takeable: " + getTakeable());
		System.out.println("Object equip slot: " + getEquipSlot());
		System.out.println("Object Buffs: ");
		System.out.println("Strength: " + getAddStr());
		System.out.println("Stamina: " + getAddStam());
		System.out.println("Intellect: " + getAddInt());
		System.out.println("Agility: " + getAddAgi());
		System.out.println("Health Points: " + getAddHP());
		System.out.println("Mana Points: " + getAddMP());

		System.out.println("Weapon Type: " + getWeaponType());
		System.out.println("Weapon Dmg: " + getWeaponDmg());
		System.out.println("Weapon Dmg Type: " + getWpndmgType());

		System.out.println("Armor Type: " + getArmorType());
		System.out.println("Damage Redux: " + getDmgRedux());
		
		System.out.println("Container Size: " + getCntSize());
		String cont = Arrays.toString(getCntCont());
		cont.replace("[", "");
		cont.replace("]", "");
		//System.out.println("Keywords: "+ keys);  //4  
		System.out.println("Container Contents: " + cont);

		System.out.println("Food HP Restore: " + getHpRestore());
		System.out.println("Drink MP Restore: " + getMpRestore());

		System.out.println("Potion Spell: " + getPotSpell());
		System.out.println("Scroll Spell: " + getScrollSpell());
		System.out.println("Wand Spell: " + getWandSpell());
		System.out.println("Wand Charges: " + getWandCharge());

		System.out.println("Item Blue Glow: " + getBlueGlow());
		System.out.println("Item Red Glow: " + getRedGlow());
		System.out.println("Item Hum: " + getHum());
		System.out.println("Item Cursed: " + getCursed());
	} // end returnObjectFull()

	public void returnObjectInfo() {
		// returns the object info
		// getObjNum //0 not returned to user

		System.out.println("from returnObjectInfo()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		keys.replace(" ", "");
		keys.strip();
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Keyword 2: [" + getKeyWord1() + "]   Keyword 2: [" + getKeyWord2()  + "]   Keyword 3: [" + getKeyWord3() + "]"); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		returnObjectDefStats();
	}

	public void returnObjFood() {
		// returns relevant info for food obj
		System.out.println("from returnObjFood()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Food HP Restore: " + getHpRestore());


	}

	public void returnObjPart() {
		// returns relevant info for parts
		System.out.println("from returnObjPart()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());


	}

	public void returnObjPotion() {
		// returns relevant info for potion types
		System.out.println("from returnObjPotion()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Potion Spell: " + getPotSpell());


	}

	public void returnObjScroll() {
		// returns relevant info for scrolls
		System.out.println("from returnObjScroll()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Scroll Spell: " + getScrollSpell());


	}

	public void returnObjSign() {
		// returns relevant info for signs
		System.out.println("from returnObjSign()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());



	}

	public void returnObjTrash() {
		// returns relevant info for trash
		System.out.println("from returnObjTrash()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());


	}

	public void returnObjTreasure() {
		// returns relevant info for treasure
		System.out.println("from returnObjTreasure()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());


	}

	public void returnObjWand() {
		// returns relevant info for wands
		System.out.println("from returnObjWand()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  
		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Wand Spell: " + getWandSpell());
		System.out.println("Wand Charges: " + getWandCharge());


	}

	public void returnObjWeapon() {
		// returns relevant info for weapons
		System.out.println("from returnObjWeapon()");
		System.out.println("Object ID Num: " + getObjNum());
		System.out.println("Object Name: " + getObjName()); //1
		System.out.println("Object Short Description: " + getObjShortDesc()); //2
		System.out.println("Object Description: " + getObjLongDesc()); //2
		System.out.println("Object Desc Cont: " + getObjExtDesc()); //3
		String keys = Arrays.toString(getObjKeyWords());
		keys.replace("[", "");
		keys.replace("]", "");
		System.out.println("Keywords: "+ keys);  //4  

		String[] split = keys.split(",");
		setObjKeyWords(split);
		System.out.println("Keyword 1: " + getKeyWord(0).strip() + "   Keyword 2: " + getKeyWord(1).strip()  + "   Keyword 3: " + getKeyWord(2).strip()); // this prints out the correct keywords list
		System.out.println("Object Type: " + getObjType());
		System.out.println("Object Value: " + getObjval());

		System.out.println("Weapon Type: " + getWeaponType());
		System.out.println("Weapon Dmg: " + getWeaponDmg());
		System.out.println("Weapon Dmg Hit Type: " + getWpndmgType());


	}

	@Override
	public String toString() {
		return objNum + "|" + objName + "|" + objShortDesc + "|" + objLongDesc + "|" + objExtDesc + "|"
				+ Arrays.toString(objKeyWords) + "|" + addStr + "|" + addStam + "|" + addInt + "|" + addAgi + "|"
				+ addHP + "|" + addMP + "|" + durability + "|" + takeable + "|" + equipSlot + "|" + objval + "|"
				+ objType + "|" + stackSize + "|" + weaponType + "|" + weaponDmg + "|" + wpndmgType + "|" + v21 + "|"
				+ armorType + "|" + dmgRedux + "|" + hpRestore + "|" + mpRestore + "|" + potSpell + "|" + scrollSpell
				+ "|" + wandSpell + "|" + wandCharge + "|" + cntSize + "|" + cntCont + "|" + v32 + "|" + v33 + "|" + v34
				+ "|" + v35 + "|" + v36 + "|" + v37 + "|" + v38 + "|" + v39 + "|" + v40 + "|" + v41 + "|" + v42 + "|"
				+ v43 + "|" + v44 + "|" + v45 + "|" + blueGlow + "|" + redGlow + "|" + hum + "|" + cursed;
	}

}
