package Game;

import java.util.Arrays;

public class room {
	int roomNum; // 0
	String roomName;  // 1 
	String roomShortDesc;  // 2
	String roomLongDesc;  // 3 
	int exitN = 0; // 4
	int exitNE = 0;  // 5
	int exitE = 0;  // 6
	int exitSE = 0;  // 7
	int exitS = 0; // 8
	int exitSW = 0; // 9
	int exitW = 0; // 10
	int exitNW = 0;  // 11
	int exitU = 0;  // 12
	int exitD = 0;  // 13
	String[] mobsInRoom = new String[6]; // 14
	
	String[] objsInRoom = new String[6]; // 15

	int lit = 1; // 16
	int camp = 1; // 17
	int rent = 1; // 18
	int inside = 1; // 19
	int terrain = 1; // 20
	int bank = 0; // 21

	String v22 = "unused"; // 22 // door N isdoor/state/key/short desc/long desc as string?
	String v23 = "unused"; // 23
	String v24 = "unused"; // 24
	String v25 = "unused"; // 25
	String v26 = "unused"; // 26
	String v27 = "unused"; // 27
	String v28 = "unused"; // 28
	String v29 = "unused"; // 29
	String v30 = "unused"; // 30
	String v31 = "unused"; // 31 // door D isDoor/state/key/short desc /long desc as string?
	String v32 = "unused"; // 32
	String v33 = "unused"; // 33
	String v34 = "unused"; // 34
	String v35 = "unused"; // 35
	String v36 = "unused"; // 36
	String v37 = "unused"; // 37
	String v38 = "unused"; // 38
	String v39 = "unused"; // 39
	String v40 = "unused"; // 40
	String v41 = "unused"; // 41
	String v42 = "unused"; // 42
	String v43 = "unused"; // 43
	String v44 = "unused"; // 44
	String v45 = "unused"; // 45
	String v46 = "unused"; // 46
	String v47 = "unused"; // 47
	String v48 = "unused"; // 48
	String v49 = "unused"; // 49 


	public int getBank() {
		return bank;
	}

	public int getCamp() {
		return camp;
	}

	public int getExitD() {
		return exitD;
	}

	public int getExitE() {
		return exitE;
	}

	public int getExitN() {
		return exitN;
	}

	public int getExitNE() {
		return exitNE;
	}

	public int getExitNW() {
		return exitNW;
	}

	public int getExitS() {
		return exitS;
	}

	public int getExitSE() {
		return exitSE;
	}

	public int getExitSW() {
		return exitSW;
	}

	public int getExitU() {
		return exitU;
	}

	public int getExitW() {
		return exitW;
	}

	public int getInside() {
		return inside;
	}

	public int getLit() {
		return lit;
	}

	public String getMobNumAtPos(int p) {
		String mobatP = String.valueOf(mobsInRoom[p]);
		return mobatP;
	}

	public String[] getMobsInRoom() {
		return mobsInRoom;
	}

	public String getObjNumAtPos(int p) {
		String objatP = String.valueOf(objsInRoom[p]);
		return objatP;
	}

	public String[] getObjsInRoom() {
		return objsInRoom;
	}

	public int getRent() {
		return rent;
	}

	public String getRoomLongDesc() {
		return roomLongDesc;
	}

	public String getRoomName() {
		return roomName;
	}

	public int getRoomNum() {
		return roomNum;
	}

	public String getRoomShortDesc() {
		return roomShortDesc;
	}

	public int getTerrain() {
		return terrain;
	}

	public String getV22() {
		return v22;
	}

	public String getV23() {
		return v23;
	}

	public String getV24() {
		return v24;
	}

	public String getV25() {
		return v25;
	}

	public String getV26() {
		return v26;
	}

	public String getV27() {
		return v27;
	}

	public String getV28() {
		return v28;
	}

	public String getV29() {
		return v29;
	}

	public String getV30() {
		return v30;
	}

	public String getV31() {
		return v31;
	}

	public String getV32() {
		return v32;
	}

	public String getV33() {
		return v33;
	}

	public String getV34() {
		return v34;
	}

	public String getV35() {
		return v35;
	}

	public String getV36() {
		return v36;
	}

	public String getV37() {
		return v37;
	}

	public String getV38() {
		return v38;
	}

	public String getV39() {
		return v39;
	}

	public String getV40() {
		return v40;
	}

	public String getV41() {
		return v41;
	}

	public String getV42() {
		return v42;
	}

	public String getV43() {
		return v43;
	}

	public String getV44() {
		return v44;
	}

	public String getV45() {
		return v45;
	}

	public String getV46() {
		return v46;
	}

	public String getV47() {
		return v47;
	}

	public String getV48() {
		return v48;
	}

	public String getV49() {
		return v49;
	}

	public void setBank(int bank) {
		this.bank = bank;
	}

	public void setCamp(int camp) {
		this.camp = camp;
	}

	public void setExitD(int exitD) {
		this.exitD = exitD;
	}

	public void setExitE(int exitE) {
		this.exitE = exitE;
	}

	public void setExitN(int exitN) {
		this.exitN = exitN;
	}

	public void setExitNE(int exitNE) {
		this.exitNE = exitNE;
	}

	public void setExitNW(int exitNW) {
		this.exitNW = exitNW;
	}

	public void setExitS(int exitS) {
		this.exitS = exitS;
	}

	public void setExitSE(int exitSE) {
		this.exitSE = exitSE;
	}

	public void setExitSW(int exitSW) {
		this.exitSW = exitSW;
	}

	public void setExitU(int exitU) {
		this.exitU = exitU;
	}

	public void setExitW(int exitW) {
		this.exitW = exitW;
	}

	public void setInside(int inside) {
		this.inside = inside;
	}

	public void setLit(int lit) {
		this.lit = lit;
	}

	public void setMobNumAtPos(int m, int p) {
		mobsInRoom[p] = String.valueOf(m);
	}

	public void setMobsInRoom(String[] mobsInRoom) {
		this.mobsInRoom = mobsInRoom;
	}

	public void setObjNumAtPos(int o, int p) {
		objsInRoom[p] = String.valueOf(o);
	}

	public void setObjsInRoom(String[] objsInRoom) {
		this.objsInRoom = objsInRoom;
	}

	public void setRent(int rent) {
		this.rent = rent;
	}

	public void setRoomLongDesc(String roomLongDesc) {
		this.roomLongDesc = roomLongDesc;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}

	public void setRoomShortDesc(String roomShortDesc) {
		this.roomShortDesc = roomShortDesc;
	}

	public void setTerrain(int terrain) {
		this.terrain = terrain;
	}

	public void setV22(String v22) {
		this.v22 = v22;
	}

	public void setV23(String v23) {
		this.v23 = v23;
	}

	public void setV24(String v24) {
		this.v24 = v24;
	}

	public void setV25(String v25) {
		this.v25 = v25;
	}

	public void setV26(String v26) {
		this.v26 = v26;
	}

	public void setV27(String v27) {
		this.v27 = v27;
	}

	public void setV28(String v28) {
		this.v28 = v28;
	}

	public void setV29(String v29) {
		this.v29 = v29;
	}

	public void setV30(String v30) {
		this.v30 = v30;
	}

	public void setV31(String v31) {
		this.v31 = v31;
	}

	public void setV32(String v32) {
		this.v32 = v32;
	}

	public void setV33(String v33) {
		this.v33 = v33;
	}

	public void setV34(String v34) {
		this.v34 = v34;
	}

	public void setV35(String v35) {
		this.v35 = v35;
	}

	public void setV36(String v36) {
		this.v36 = v36;
	}

	public void setV37(String v37) {
		this.v37 = v37;
	}

	public void setV38(String v38) {
		this.v38 = v38;
	}

	public void setV39(String v39) {
		this.v39 = v39;
	}

	public void setV40(String v40) {
		this.v40 = v40;
	}

	public void setV41(String v41) {
		this.v41 = v41;
	}

	public void setV42(String v42) {
		this.v42 = v42;
	}

	public void setV43(String v43) {
		this.v43 = v43;
	}

	public void setV44(String v44) {
		this.v44 = v44;
	}

	public void setV45(String v45) {
		this.v45 = v45;
	}

	public void setV46(String v46) {
		this.v46 = v46;
	}

	public void setV47(String v47) {
		this.v47 = v47;
	}

	public void setV48(String v48) {
		this.v48 = v48;
	}

	public void setV49(String v49) {
		this.v49 = v49;
	}

	public void resetRoom() {
		roomNum = 0; //0
		roomName = "The Void"; //1
		roomShortDesc = "nothing but void"; //2
		roomLongDesc = "Nothing has been created yet.  All around is endless void.  When further development has been made, these lands will change."; //3
		exitN = 0; //4
		exitNE = 0; //5
		exitE = 0; //6
		exitSE = 0; //7
		exitS = 0; //8
		exitSW = 0; //9
		exitW = 0; //10
		exitNW = 0; //11
		exitU = 0; //12
		exitD = 0; //13
		mobsInRoom = new String[6]; //14
		objsInRoom = new String[6]; //15
		mobsInRoom[0] = "0";
		mobsInRoom[1] = "0";
		mobsInRoom[2] = "0";
		mobsInRoom[3] = "0";
		mobsInRoom[4] = "0";
		mobsInRoom[5] = "0";
		objsInRoom[0] = "0";
		objsInRoom[1] = "0";
		objsInRoom[2] = "0";
		objsInRoom[3] = "0";
		objsInRoom[4] = "0";
		objsInRoom[5] = "0";
		lit = 1; //16
		camp = 1; //17
		rent = 1; //18
		inside = 1; //19
		terrain = 1; //20
		bank = 0; //21

		v22 = "unused"; // 22
		v23 = "unused"; // 23
		v24 = "unused"; // 24
		v25 = "unused"; // 25
		v26 = "unused"; // 26
		v27 = "unused"; // 27
		v28 = "unused"; // 28
		v29 = "unused"; // 29
		v30 = "unused"; // 30
		v31 = "unused"; // 31
		v32 = "unused"; // 32
		v33 = "unused"; // 33
		v34 = "unused"; // 34
		v35 = "unused"; // 35
		v36 = "unused"; // 36
		v37 = "unused"; // 37
		v38 = "unused"; // 38
		v39 = "unused"; // 39
		v40 = "unused"; // 40
		v41 = "unused"; // 41
		v42 = "unused"; // 42
		v43 = "unused"; // 43
		v44 = "unused"; // 44
		v45 = "unused"; // 45
		v46 = "unused"; // 46
		v47 = "unused"; // 47
		v48 = "unused"; // 48
		v49 = "unused"; // 49
	}

	public void returnRoomInfo() {
		// display the room
		System.out.println("Room: " + getRoomNum());
		System.out.println("Room Name: " + getRoomName());
		int inoutside = getInside();
		int one = 1;
		if (inoutside== one) { 
			System.out.println("Currently Indoors.");
		}
		else { 
			System.out.println("Currently Outdoors.");
		}
		if (getTerrain() ==  1) {
			System.out.println("The terrain and climate is temperate and moderate.");
		}
		else if (getTerrain() == 2) {
			System.out.println("The weather is dry and arrid.");
		}
		else if (getTerrain() == 3) {
			System.out.println("The environment is frigid and harse.");
		}
		else if (getTerrain() == 4) {
			System.out.println("The environment is tropical, humid and rainy");
		}
		else {
			System.out.println("You are currently in a void.");
		}
		System.out.println("Room Description: " + getRoomLongDesc());
		//	System.out.println("Exits: N[" + getExitN() + "] NE[" + getExitNE() + "] E[" + getExitE() + "] SE[" + getExitSE() + "] S[" + 
		//			getExitS() + "] SW[" + getExitSW() + "] W[" + getExitW() + "] NW[" + getExitNW() + "] U[" + getExitU() + "] D[" + 
		//			getExitD() + "]");		


		System.out.print("Exits: ");
		{
			if(getExitN() != 0) {
				System.out.print("N[" + getExitN() + "] ");
			}
			if(getExitNE() != 0) {
				System.out.print("NE[" + getExitNE() + "] ");
			}
			if(getExitE() != 0) {
				System.out.print("E[" + getExitE() + "] ");
			}
			if(getExitSE() != 0) {
				System.out.print("SE[" + getExitSE() + "] ");
			}
			if(getExitS() != 0) {
				System.out.print("S[" + getExitS() + "] ");
			}
			if(getExitSW() != 0) {
				System.out.print("SW[" + getExitSW() + "] ");
			}
			if(getExitW() != 0) {
				System.out.print("W[" + getExitW() + "] ");
			}
			if(getExitNW() != 0) {
				System.out.print("NW[" + getExitNW() + "] ");
			}
			if(getExitU() != 0) {
				System.out.print("U[" + getExitU() + "] ");
			}
			if(getExitD() != 0) {
				System.out.print("D[" + getExitD() + "]");
			}
			if(getExitN() == 0 && getExitNE() == 0 && getExitE() == 0 && getExitSE() == 0 && getExitS() == 0 && getExitSW() == 0 
					&& getExitW() == 0 &&getExitNW() == 0 &&getExitU() == 0 &&getExitD() == 0) { 
				System.out.print("No Exits available.  You are trapped!");
			}
			System.out.println();
		}


		System.out.println("Mobs: " + Arrays.toString(getMobsInRoom()));
		System.out.println("Objects: " + Arrays.toString(getObjsInRoom()));

	}

	public void returnRoomInfo2() {

		System.out.println("Room: " + getRoomNum());
		System.out.println("Room Name: " + getRoomName());
		System.out.println("Room Short Description: " + getRoomShortDesc());
		System.out.println("Room Description: " + getRoomLongDesc());
		System.out.println("Exits: N[" + getExitN() + "] NE[" + getExitNE() + "] E[" + getExitE() + "] SE[" + getExitSE() 
		+ "] S[" + getExitS() + "] SW[" + getExitSW() + "] W[" + getExitW() + "] NW[" + getExitNW() + "] U[" + getExitU() + "] D[" + getExitD() + "]");		

		System.out.println("Mobs: " + Arrays.toString(getMobsInRoom()));
		System.out.println("Objects: " + Arrays.toString(getObjsInRoom()));
		
		
		int inoutside = getInside();
		int campable = getCamp();
		int rentable = getRent();
		int litable = getLit();
		int bankable = getBank();
		int one = 1;
		System.out.println("The indoor/outdoor setting: " + inoutside);
		if (inoutside == one) { 
			System.out.println("Currently Indoors.");
		}
		else { 
			System.out.println("Currently Outdoors.");
		}
		System.out.println("The room camp setting: " + getCamp());
		if (campable == one) {
			System.out.println("Currently able to camp.");
		}
		else {
			System.out.println("Currently Unable to camp.");
		}
		System.out.println("The room rent setting: " + getRent());
		if (rentable == one) {
			System.out.println("Currently able to rent.");
		}
		else {
			System.out.println("Currently Unable to rent.");
		}
		System.out.println("The room lighting setting: " + getLit());
		if (litable == one) {
			System.out.println("Currently lit.");
		}
		else {
			System.out.println("Currently Unlit.");
		}
		System.out.println("The room bank setting" + getBank());
		if (bankable == one) {
			System.out.println("Currently able to bank (exchange coins) here.");
		}
		else {
			System.out.println("Currently unable to bank (exchange coins) here.");
		}
		System.out.println("The terrain setting: " + getTerrain());
		System.out.println("0 = void, 1 = Temperate, 2 = Arrid/Desert, 3 = Tundra/Ice, 4 = Tropical");
		if (getTerrain() ==  1) {
			System.out.println("The terrain and climate is temperate and moderate.");
		}
		else if (getTerrain() == 2) {
			System.out.println("The weather is dry and arrid.");
		}
		else if (getTerrain() == 3) {
			System.out.println("The environment is frigid and harse.");
		}
		else if (getTerrain() == 4) {
			System.out.println("The environment is tropical, humid and rainy");
		}
		else {
			System.out.println("You are currently in a void.");
		}

	} // end returnRoomInfo2

	public String toString() {

		String tmob = mobsInRoom[0].strip() + "," + mobsInRoom[1].strip() + "," + mobsInRoom[2].strip() + "," + mobsInRoom[3].strip() + "," + mobsInRoom[4].strip() + "," + mobsInRoom[5].strip();
		String tobj = objsInRoom[0].strip() + "," + objsInRoom[1].strip() + "," + objsInRoom[2].strip() + "," + objsInRoom[3].strip() + "," + objsInRoom[4].strip() + "," + objsInRoom[5].strip();

		return getRoomNum() + "|" + getRoomName() + "|" + getRoomShortDesc() + "|" + getRoomLongDesc() + "|" + getExitN() + "|" + getExitNE() + "|" + getExitE() + "|" + getExitSE() + "|" + getExitS() 
		+ "|" + getExitSW() + "|" + getExitW() + "|" + getExitNW() + "|" + getExitU() + "|" + getExitD() + "|" + tmob + "|" + tobj + "|" + getLit() + "|" + getCamp() + "|" + getRent() + "|" + + getInside() + "|" + getTerrain() + "|" + getBank() 
		+ "|" + v22 + "|" + v23 + "|" + v24 + "|" + v25 + "|" + v26 + "|" + v27 + "|" + v28 + "|" + v29 + "|" + v30 + "|" + v31 + "|" + v32 + "|" + v33 + "|" + v34 + "|" + v35 + "|" + v36 + "|" + v37
		+ "|" + v38 + "|" + v39 + "|" + v40 + "|" + v41 + "|" + v42 + "|" + v43 + "|" + v44 + "|" + v45 + "|" + v46 + "|" + v47 + "|" + v48 + "|" + v49 ;

	} // end toString

}



//////////////////////////////////////////////////////////////
//
//             DEPRICATED CODE
//
//////////////////////////////////////////////////////////////

/*
 * 	static String worldPath = "src/Game/world.txt";
	static String  mobPath = "src/Game/mobs.txt";
	static String objPath = "src/Game/objects.txt";
	String kinput;
	Scanner input = new Scanner(System.in);
	String[][] World = new String[10000][50];
	String[][] Mobs = new String[10000][50];
	String[][] Objects = new String[10000][50];
	String tline;
	String[] tworld = new String[50];	
	String[] currentRoom = new String[50];
	String[] tmobs = new String[50];
	//	String[] mobsInRoom = new String[6];

	public void buildWorld() {

		FileReader reader = null;
		try {
			reader = new FileReader(worldPath);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		BufferedReader breader = new BufferedReader(reader);

		Scanner input = new Scanner(System.in);
		Scanner scanner = new Scanner(breader);

		while (scanner.hasNextLine()) {
			int troomNum = 0;
			tline = scanner.nextLine();
			tline = tline.replace("||", "|");
			//			System.out.println(tline);
			tworld = tline.split("\\|");
			World[troomNum][0] = tworld[0]; // room #
			World[troomNum][1] = tworld[1]; // room Name
			World[troomNum][2] = tworld[2]; // room short desc
			World[troomNum][3] = tworld[3]; // room long desc
			World[troomNum][4] = tworld[4]; // exit n
			World[troomNum][5] = tworld[5]; // exit ne
			World[troomNum][6] = tworld[6]; // exit e
			World[troomNum][7] = tworld[7]; // exit se
			World[troomNum][8] = tworld[8]; // exit s
			World[troomNum][9] = tworld[9]; // exit sw
			World[troomNum][10] = tworld[10]; // exit w
			World[troomNum][11] = tworld[11]; // exit nw
			World[troomNum][12] = tworld[12]; // exit u
			World[troomNum][13] = tworld[13];  // exit d
			World[troomNum][14] = tworld[14]; //arr[6] mobs in room
			World[troomNum][15] = tworld[15];// arr[6] objs in room

			troomNum++;
		}
		scanner.close();
		input.close();
	}
 */


/*
 * 
		/*
		String[] tobjsarr;
		String tobjsar = Arrays.toString(getObjsInRoom());
		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");
		tobjsar = tobjsar.replace(",", "");
		tobjsarr = tobjsar.split("\\s+");


		if ("null".equalsIgnoreCase(tobjsarr[0])) {	} 
		else { System.out.println("You see " + tobj0.getObjShortDesc() + "1."); }
		if ("null".equalsIgnoreCase(tobjsarr[1])) {	} 
		else { System.out.println("You see " + tobj1.getObjShortDesc() + "2."); }
		if ("null".equalsIgnoreCase(tobjsarr[2])) {	} 
		else { System.out.println("You see " + tobj2.getObjShortDesc() + "3."); }
		if ("null".equalsIgnoreCase(tobjsarr[3])) {	} 
		else { System.out.println("You see " + tobj3.getObjShortDesc() + "4."); }
		if ("null".equalsIgnoreCase(tobjsarr[4])) {	} 
		else { System.out.println("You see " + tobj4.getObjShortDesc() + "5."); }
		if ("null".equalsIgnoreCase(tobjsarr[5])) {	} 
		else { System.out.println("You see " + tobj5.getObjShortDesc() + "6."); }
		if ("null".equalsIgnoreCase(tobjsarr[0]) && "null".equalsIgnoreCase(tobjsarr[1]) && "null".equalsIgnoreCase(tobjsarr[2]) && "null".equalsIgnoreCase(tobjsarr[3]) && "null".equalsIgnoreCase(tobjsarr[4]) && "null".equalsIgnoreCase(tobjsarr[5])) {
			System.out.println("You do not see anything of note.");
		}	
 */

//		returnMobInRoom();
//	returnObjInRoom();


/*
 * 
	public void returnMobInRoom() {
		FileReader reader = null;
		try {
			reader = new FileReader(mobPath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		BufferedReader breader = new BufferedReader(reader);

		Scanner input = new Scanner(System.in);
		Scanner scanner = new Scanner(breader);
		while (scanner.hasNextLine()) {
			int tmobNum = 0;
			tline = scanner.nextLine();
			tline = tline.replace("||", "|");
			tmobs = tline.split("\\|");
			Mobs[tmobNum][0] = tmobs[0]; // mob #
			Mobs[tmobNum][1] = tmobs[1]; // mob Name
			Mobs[tmobNum][2] = tmobs[2]; // mob short desc
			Mobs[tmobNum][3] = tmobs[3]; // mob long desc
			Mobs[tmobNum][4] = tmobs[4]; // mob key words arr[3]
			Mobs[tmobNum][5] = tmobs[5]; // mob hp
			Mobs[tmobNum][6] = tmobs[6]; // mob mp
			Mobs[tmobNum][7] = tmobs[7]; // mob level
			Mobs[tmobNum][8] = tmobs[8]; // mob stam
			Mobs[tmobNum][9] = tmobs[9]; // mob str
			Mobs[tmobNum][10] = tmobs[10]; // mob int
			Mobs[tmobNum][11] = tmobs[11]; // mob agi
			Mobs[tmobNum][12] = tmobs[12]; // head slot
			Mobs[tmobNum][13] = tmobs[13];  // neck slot
			Mobs[tmobNum][14] = tmobs[14]; // shoulder slot
			Mobs[tmobNum][15] = tmobs[15]; // chest
			Mobs[tmobNum][16] = tmobs[16]; // wrist
			Mobs[tmobNum][17] = tmobs[17]; // hand
			Mobs[tmobNum][18] = tmobs[18]; // finger 1
			Mobs[tmobNum][19] = tmobs[19]; // finger 2
			Mobs[tmobNum][20] = tmobs[20]; // leg
			Mobs[tmobNum][21] = tmobs[21]; // trinket 1
			Mobs[tmobNum][22] = tmobs[22]; // trinket 2
			Mobs[tmobNum][23] = tmobs[23]; // weapon 1
			Mobs[tmobNum][24] = tmobs[24]; // weapon/shield
			Mobs[tmobNum][25] = tmobs[25]; // race
			Mobs[tmobNum][26] = tmobs[26]; // subrace
			Mobs[tmobNum][27] = tmobs[27]; // rank
			Mobs[tmobNum][28] = tmobs[28]; // xp val
			Mobs[tmobNum][29] = tmobs[29]; // is alive
			Mobs[tmobNum][30] = tmobs[30]; // mob gender


			tmobNum++;
		}



		String tmobsar = Arrays.toString(getMobsInRoom());
		tmobsar = tmobsar.replace("[", "");
		tmobsar = tmobsar.replace("]", "");

		tmobsar = tmobsar.replace(",", "");
			System.out.println(tmobsar);
		String[] tmobsarr = tmobsar.split("\\s+");
		//	System.out.println(tmobsarr[0]);
		//	System.out.println(Mobs[0][2]);
		mob tmob0 = new mob();
		mob tmob1 = new mob();
		mob tmob2 = new mob();
		mob tmob3 = new mob();
		mob tmob4 = new mob();
		mob tmob5 = new mob();

		int t0;
		int t1;
		int t2;
		int t3;
		int t4;
		int t5;

		if ("null".equalsIgnoreCase(tmobsarr[0])) { }
		else {		
			t0 = Integer.parseInt(tmobsarr[0]); 
			tmob0.setMobNum(t0);
			tmob0.setMobName(Mobs[t0][1]);
			tmob0.setMobShortDesc(Mobs[t0][2]);
			tmob0.setMobLongDesc(Mobs[t0][3]);
		}
		if ("null".equalsIgnoreCase(tmobsarr[1])) { }
		else {
			t1 = Integer.parseInt(tmobsarr[1]);
			tmob1.setMobNum(t1);
			tmob1.setMobName(Mobs[t1][1]);
			tmob1.setMobShortDesc(Mobs[t1][2]);
			tmob1.setMobLongDesc(Mobs[t1][3]);
		}
		if ("null".equalsIgnoreCase(tmobsarr[2])) { }
		else {
			t2 = Integer.parseInt(tmobsarr[2]);
			tmob2.setMobNum(t2);
			tmob2.setMobName(Mobs[t2][1]);
			tmob2.setMobShortDesc(Mobs[t2][2]);
			tmob2.setMobLongDesc(Mobs[t2][3]);
		}
		if ("null".equalsIgnoreCase(tmobsarr[3])) { }
		else {
			t3 = Integer.parseInt(tmobsarr[3]);
			tmob3.setMobNum(t3);
			tmob3.setMobName(Mobs[t3][1]);
			tmob3.setMobShortDesc(Mobs[t3][2]);
			tmob3.setMobLongDesc(Mobs[t3][3]);
		}
		if ("null".equalsIgnoreCase(tmobsarr[4])) { }
		else {
			t4 = Integer.parseInt(tmobsarr[4]);
			tmob4.setMobNum(t4);
			tmob4.setMobName(Mobs[t4][1]);
			tmob4.setMobShortDesc(Mobs[t4][2]);
			tmob4.setMobLongDesc(Mobs[t4][3]);
		}
		if ("null".equalsIgnoreCase(tmobsarr[5])) { }
		else {
			t5 = Integer.parseInt(tmobsarr[5]);
			tmob5.setMobNum(t5);
			tmob5.setMobName(Mobs[t5][1]);
			tmob5.setMobShortDesc(Mobs[t5][2]);
			tmob5.setMobLongDesc(Mobs[t5][3]);
		}




		if ("null".equalsIgnoreCase(tmobsarr[0])) { }
		else {	System.out.println("You see " + tmob0.getMobShortDesc() + "."); }
		if ("null".equalsIgnoreCase(tmobsarr[1])) { }
		else {	System.out.println("You see " + tmob1.getMobShortDesc() + "."); }
		if ("null".equalsIgnoreCase(tmobsarr[2])) { }	
		else {	System.out.println("You see " + tmob2.getMobShortDesc()  + "."); }
		if ("null".equalsIgnoreCase(tmobsarr[3])) { }	
		else {	System.out.println("You see " +  tmob3.getMobShortDesc() + "."); }
		if ("null".equalsIgnoreCase(tmobsarr[4])) { }
		else {	System.out.println("You see " +  tmob4.getMobShortDesc() + "."); }
		if ("null".equalsIgnoreCase(tmobsarr[5])) { }
		else {	System.out.println("You see " +  tmob5.getMobShortDesc() + "."); 
		}
		if ("null".equalsIgnoreCase(tmobsarr[0]) && "null".equalsIgnoreCase(tmobsarr[1]) && "null".equalsIgnoreCase(tmobsarr[2]) && "null".equalsIgnoreCase(tmobsarr[3]) && "null".equalsIgnoreCase(tmobsarr[4]) && "null".equalsIgnoreCase(tmobsarr[5])) {
			System.out.println("You do not see any creatures nearby.");
		}
	}



	public void returnObjInRoom() {

		//		int 
		String tobj;
		int ttobj;

		// create the objs for the room
		String tobjsar = Arrays.toString(getObjsInRoom());
		tobjsar = tobjsar.replace("[", "");
		tobjsar = tobjsar.replace("]", "");
		tobjsar = tobjsar.replace(",", "");
		String[] tobjsarr = tobjsar.split("\\s+");
		objects tobj0 = new objects();
		objects tobj1 = new objects();
		objects tobj2 = new objects();
		objects tobj3 = new objects();
		objects tobj4 = new objects();
		objects tobj5 = new objects();
		int t0;
		int t1;
		int t2;
		int t3;
		int t4;
		int t5;


		t2 = getRoomNum();

		if (!"null".equalsIgnoreCase(tobjsarr[0])) {
			t0 = Integer.parseInt(tobjsarr[0]);  
			tobj0.setObjNum(t0); // obj #
			tobj0.setObjName(Objects[t0][1]); // obj Name
			tobj0.setObjShortDesc(Objects[t0][2]); // obj short desc
			tobj0.setObjLongDesc(Objects[t0][3]); // obj long desc
			tobj0.setObjExtDesc(Objects[t0][4]); // obj ext desc
			String t = Objects[t0][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj0.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t0][6])) {tobj0.setAddStam(Integer.parseInt(Objects[t0][6]));}{tobj0.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t0][7])) {tobj0.setAddStr(Integer.parseInt(Objects[t0][7]));}{tobj0.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t0][8])) {tobj0.setAddInt(Integer.parseInt(Objects[t0][8]));}{tobj0.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t0][9])) {tobj0.setAddAgi(Integer.parseInt(Objects[t0][9]));}{tobj0.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t0][10])) {tobj0.setAddHP(Integer.parseInt(Objects[t0][10]));}{tobj0.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t0][11])) {tobj0.setAddMP(Integer.parseInt(Objects[t0][11]));}{tobj0.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t0][12])) {tobj0.setDurability(Integer.parseInt(Objects[t0][12]));}{tobj0.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t0][13])) {tobj0.setTakeable(Integer.parseInt(Objects[t0][13]));}{tobj0.setTakeable(0);}  // takeable
			t = Objects[t0][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj0.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (!"null".equalsIgnoreCase(tobjsarr[1])) {
			t1 = Integer.parseInt(tobjsarr[1]);  
			tobj1.setObjNum(t1); // obj #
			tobj1.setObjName(Objects[t1][1]); // obj Name
			tobj1.setObjShortDesc(Objects[t1][2]); // obj short desc
			tobj1.setObjLongDesc(Objects[t1][3]); // obj long desc
			tobj1.setObjExtDesc(Objects[t1][4]); // obj ext desc
			String t = Objects[t1][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj1.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t1][6])) {tobj1.setAddStam(Integer.parseInt(Objects[t1][6]));}{tobj1.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t1][7])) {tobj1.setAddStr(Integer.parseInt(Objects[t1][7]));}{tobj1.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t1][8])) {tobj1.setAddInt(Integer.parseInt(Objects[t1][8]));}{tobj1.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t1][9])) {tobj1.setAddAgi(Integer.parseInt(Objects[t1][9]));}{tobj1.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t1][10])) {tobj1.setAddHP(Integer.parseInt(Objects[t1][10]));}{tobj1.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t1][11])) {tobj1.setAddMP(Integer.parseInt(Objects[t1][11]));}{tobj1.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t1][12])) {tobj1.setDurability(Integer.parseInt(Objects[t1][12]));}{tobj1.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t1][13])) {tobj1.setTakeable(Integer.parseInt(Objects[t1][13]));}{tobj1.setTakeable(0);}  // takeable
			t = Objects[t1][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj1.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (!"null".equalsIgnoreCase(tobjsarr[2])) {
			t2 = Integer.parseInt(tobjsarr[2]);  
			tobj2.setObjNum(t2); // obj #
			tobj2.setObjName(Objects[t2][1]); // obj Name
			tobj2.setObjShortDesc(Objects[t2][2]); // obj short desc
			tobj2.setObjLongDesc(Objects[t2][3]); // obj long desc
			tobj2.setObjExtDesc(Objects[t2][4]); // obj ext desc
			String t = Objects[t2][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj2.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t2][6])) {tobj2.setAddStam(Integer.parseInt(Objects[t2][6]));}{tobj2.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t2][7])) {tobj2.setAddStr(Integer.parseInt(Objects[t2][7]));}{tobj2.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t2][8])) {tobj2.setAddInt(Integer.parseInt(Objects[t2][8]));}{tobj2.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t2][9])) {tobj2.setAddAgi(Integer.parseInt(Objects[t2][9]));}{tobj2.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t2][10])) {tobj2.setAddHP(Integer.parseInt(Objects[t2][10]));}{tobj2.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t2][11])) {tobj2.setAddMP(Integer.parseInt(Objects[t2][11]));}{tobj2.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t2][12])) {tobj2.setDurability(Integer.parseInt(Objects[t2][12]));}{tobj2.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t2][13])) {tobj2.setTakeable(Integer.parseInt(Objects[t2][13]));}{tobj2.setTakeable(0);}  // takeable
			t = Objects[t2][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj2.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (!"null".equalsIgnoreCase(tobjsarr[3])) {
			t3 = Integer.parseInt(tobjsarr[3]);  
			tobj3.setObjNum(t3); // obj #
			tobj3.setObjName(Objects[t3][1]); // obj Name
			tobj3.setObjShortDesc(Objects[t3][2]); // obj short desc
			tobj3.setObjLongDesc(Objects[t3][3]); // obj long desc
			tobj3.setObjExtDesc(Objects[t3][4]); // obj ext desc
			String t = Objects[t3][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj3.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t3][6])) {tobj3.setAddStam(Integer.parseInt(Objects[t3][6]));}{tobj3.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t3][7])) {tobj3.setAddStr(Integer.parseInt(Objects[t3][7]));}{tobj3.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t3][8])) {tobj3.setAddInt(Integer.parseInt(Objects[t3][8]));}{tobj3.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t3][9])) {tobj3.setAddAgi(Integer.parseInt(Objects[t3][9]));}{tobj3.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t3][10])) {tobj3.setAddHP(Integer.parseInt(Objects[t3][10]));}{tobj3.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t3][11])) {tobj3.setAddMP(Integer.parseInt(Objects[t3][11]));}{tobj3.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t3][12])) {tobj3.setDurability(Integer.parseInt(Objects[t3][12]));}{tobj3.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t3][13])) {tobj3.setTakeable(Integer.parseInt(Objects[t3][13]));}{tobj3.setTakeable(0);}  // takeable
			t = Objects[t3][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj3.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (!"null".equalsIgnoreCase(tobjsarr[4])) {
			t4 = Integer.parseInt(tobjsarr[4]);  
			tobj4.setObjNum(t4); // obj #
			tobj4.setObjName(Objects[t4][1]); // obj Name
			tobj4.setObjShortDesc(Objects[t4][2]); // obj short desc
			tobj4.setObjLongDesc(Objects[t4][3]); // obj long desc
			tobj4.setObjExtDesc(Objects[t4][4]); // obj ext desc
			String t = Objects[t4][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj4.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t4][6])) {tobj4.setAddStam(Integer.parseInt(Objects[t4][6]));}{tobj4.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t4][7])) {tobj4.setAddStr(Integer.parseInt(Objects[t4][7]));}{tobj4.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t4][8])) {tobj4.setAddInt(Integer.parseInt(Objects[t4][8]));}{tobj4.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t4][9])) {tobj4.setAddAgi(Integer.parseInt(Objects[t4][9]));}{tobj4.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t4][10])) {tobj4.setAddHP(Integer.parseInt(Objects[t4][10]));}{tobj4.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t4][11])) {tobj4.setAddMP(Integer.parseInt(Objects[t4][11]));}{tobj4.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t4][12])) {tobj4.setDurability(Integer.parseInt(Objects[t4][12]));}{tobj4.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t4][13])) {tobj4.setTakeable(Integer.parseInt(Objects[t4][13]));}{tobj4.setTakeable(0);}  // takeable
			t = Objects[t4][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj4.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}
		if (!"null".equalsIgnoreCase(tobjsarr[5])) {
			t5 = Integer.parseInt(tobjsarr[5]);  
			tobj5.setObjNum(t5); // obj #
			tobj5.setObjName(Objects[t5][1]); // obj Name
			tobj5.setObjShortDesc(Objects[t5][2]); // obj short desc
			tobj5.setObjLongDesc(Objects[t5][3]); // obj long desc
			tobj5.setObjExtDesc(Objects[t5][4]); // obj ext desc
			String t = Objects[t5][5];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj5.setObjKeyWords(tobjsarr); // ob key words arr[3]
			if (!"null".equalsIgnoreCase(Objects[t5][6])) {tobj5.setAddStam(Integer.parseInt(Objects[t5][6]));}{tobj5.setAddStam(0);} // stam
			if (!"null".equalsIgnoreCase(Objects[t5][7])) {tobj5.setAddStr(Integer.parseInt(Objects[t5][7]));}{tobj5.setAddStr(0);} // str
			if (!"null".equalsIgnoreCase(Objects[t5][8])) {tobj5.setAddInt(Integer.parseInt(Objects[t5][8]));}{tobj5.setAddInt(0);} // int
			if (!"null".equalsIgnoreCase(Objects[t5][9])) {tobj5.setAddAgi(Integer.parseInt(Objects[t5][9]));}{tobj5.setAddAgi(0);} // agi
			if (!"null".equalsIgnoreCase(Objects[t5][15])) {tobj5.setAddHP(Integer.parseInt(Objects[t5][10]));}{tobj5.setAddHP(0);} // hp
			if (!"null".equalsIgnoreCase(Objects[t5][11])) {tobj5.setAddMP(Integer.parseInt(Objects[t5][11]));}{tobj5.setAddMP(0);} // mp
			if (!"null".equalsIgnoreCase(Objects[t5][12])) {tobj5.setDurability(Integer.parseInt(Objects[t5][12]));}{tobj5.setDurability(0);} // durability
			if (!"null".equalsIgnoreCase(Objects[t5][13])) {tobj5.setTakeable(Integer.parseInt(Objects[t5][13]));}{tobj5.setTakeable(0);}  // takeable
			t = Objects[t5][14];
			t = t.replace("[", "");
			t = t.replace("]", "");
			tobjsar = tobjsar.replace(",", "");
			tobjsarr = tobjsar.split("\\s+");
			tobj5.setequipSlot(tobjsarr); // obj equip slot arr[3]
			//			Objects[tobjNum][15] = tObjects[15]; // undefined
			//			Objects[tobjNum][16] = tObjects[16]; // undefined
			//			Objects[tobjNum][17] = tObjects[17]; // undefined
			//			Objects[tobjNum][18] = tObjects[18]; // undefined
			//			Objects[tobjNum][19] = tObjects[19]; // undefined
			//			Objects[tobjNum][20] = tObjects[20]; // undefined
			//			Objects[tobjNum][21] = tObjects[21]; // undefined
			//			Objects[tobjNum][22] = tObjects[22]; // undefined
			//			Objects[tobjNum][23] = tObjects[23]; // undefined
			//			Objects[tobjNum][24] = tObjects[24]; // undefined
			//			Objects[tobjNum][25] = tObjects[25]; // undefined
			//			Objects[tobjNum][26] = tObjects[26]; // undefined
			//			Objects[tobjNum][27] = tObjects[27]; // undefined
			//			Objects[tobjNum][28] = tObjects[28]; // undefined
			//		Objects[tobjNum][29] = tObjects[29]; // undefined
			//		Objects[tobjNum][30] = tObjects[30]; // undefined
			//		Objects[tobjNum][31] = tObjects[31]; // undefined
			//		Objects[tobjNum][32] = tObjects[32]; // undefined
			//		Objects[tobjNum][33] = tObjects[33]; // undefined
			//		Objects[tobjNum][34] = tObjects[34]; // undefined
			//		Objects[tobjNum][35] = tObjects[35]; // undefined
			//		Objects[tobjNum][36] = tObjects[36]; // undefined
			//		Objects[tobjNum][37] = tObjects[37]; // undefined
			//		Objects[tobjNum][38] = tObjects[38]; // undefined
			//		Objects[tobjNum][39] = tObjects[39]; // undefined
			//		Objects[tobjNum][40] = tObjects[40]; // undefined
			//		Objects[tobjNum][41] = tObjects[41]; // undefined
			//		Objects[tobjNum][42] = tObjects[42]; // undefined
			//		Objects[tobjNum][43] = tObjects[43]; // undefined
			//		Objects[tobjNum][44] = tObjects[44]; // undefined
			//		Objects[tobjNum][45] = tObjects[45]; // undefined
			//		Objects[tobjNum][46] = tObjects[46]; // undefined
			//		Objects[tobjNum][47] = tObjects[47]; // undefined
			//		Objects[tobjNum][48] = tObjects[48]; // undefined
			//		Objects[tobjNum][49] = tObjects[49]; // undefined


		}


		if ("null".equalsIgnoreCase(objsInRoom[0])) {	} 
		else { System.out.println("You see " + tobj0.getObjShortDesc() + "1."); }
		if ("null".equalsIgnoreCase(objsInRoom[1])) {	} 
		else { System.out.println("You see " + tobj1.getObjShortDesc() + "2."); }
		if ("null".equalsIgnoreCase(objsInRoom[2])) {	} 
		else { System.out.println("You see " + tobj2.getObjShortDesc() + "3."); }
		if ("null".equalsIgnoreCase(objsInRoom[3])) {	} 
		else { System.out.println("You see " + tobj3.getObjShortDesc() + "4."); }
		if ("null".equalsIgnoreCase(objsInRoom[4])) {	} 
		else { System.out.println("You see " + tobj4.getObjShortDesc() + "5."); }
		if ("null".equalsIgnoreCase(objsInRoom[5])) {	} 
		else { System.out.println("You see " + tobj5.getObjShortDesc() + "6."); }
		if ("null".equalsIgnoreCase(objsInRoom[0]) && "null".equalsIgnoreCase(tobjsarr[1]) && "null".equalsIgnoreCase(tobjsarr[2]) && "null".equalsIgnoreCase(tobjsarr[3]) && "null".equalsIgnoreCase(tobjsarr[4]) && "null".equalsIgnoreCase(tobjsarr[5])) {
			System.out.println("You do not see anything of note.");
		}	

		if (objsInRoom[0] == null) {
			System.out.println("You do not see any objects in the room.");
		}
		if (objsInRoom[0] != null) {
			tobj = objsInRoom[0];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + objsInRoom[0] + "."); 
		}
		if (objsInRoom[1] != null) {
			tobj = objsInRoom[1];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + objsInRoom[1] + "."); 
		}
		if (objsInRoom[2] != null) {
			tobj = objsInRoom[2];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + objsInRoom[2] + "."); 
		}
		if (objsInRoom[3] != null) {
			tobj = objsInRoom[3];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " +  objsInRoom[3] + "."); 
		}
		if (objsInRoom[4] != null) {
			tobj = objsInRoom[4];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " +  objsInRoom[4] + "."); 
		}
		if (objsInRoom[5] != null)
		{
			tobj = objsInRoom[5];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " +  objsInRoom[5] + "."); 
		}
	}
 */


/*
 * 	public void lookN() {
		if (getLit() == 0) {
			System.out.println("It is too dark to see.");
		}
		else {
			System.out.println("You see " + getRoomShortDesc());
		}
	}
 */

// not yet working properly, need to build 6 obj's to fill and pull data


/*
	public void returnObjInRoom() {
		int t2 = getRoomNum();
		String tobj;
		int ttobj;

		if (objsInRoom[0] == null) {
			System.out.println("You do not see any objects in the room.");
		}
		if (objsInRoom[0] != null) {
			tobj = objsInRoom[0];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}
		if (objsInRoom[1] != null) {
			tobj = objsInRoom[1];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}
		if (objsInRoom[t2][2] != null) {
			tobj = objsInRoom[t2][2];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}
		if (objsInRoom[3] != null) {
			tobj = objsInRoom[3];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}
		if (objsInRoom[4] != null) {
			tobj = objsInRoom[4];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}
		if (objsInRoom[t2][5] != null)
		{
			tobj = objsInRoom[t2][5];
			ttobj = Integer.parseInt(tobj);		
			System.out.println("You see " + Objects[ttobj][2] + "."); 
		}


	}

 */