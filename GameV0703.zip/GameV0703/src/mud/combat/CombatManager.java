package mud.combat;

import mud.core.*;

import java.util.List;
import java.util.Random;

public class CombatManager {
    private static final Random random = new Random();

    public static String performAttack(Mob attacker, Mob target) {
        if (attacker == null || target == null || attacker.isDead() || target.isDead()) {
            return "Invalid combatants.";
        }

        Room curRoom = attacker.getCurrentRoom();
        attacker.setCurrentRoom(curRoom);
        target.setCurrentRoom(curRoom);

        // Prevent movement while in combat
        attacker.setInCombat(true);
        target.setInCombat(true);

        StringBuilder result = new StringBuilder();

        // Primary attack (main hand weapon)
        ObjectItem mainHand = attacker.getEquipment().get(EquipSlot.MAINHAND);
        result.append(performSingleAttack(attacker, target, mainHand, false));

        // Double Attack chance based on level if effect is active
        if (attacker.hasEffect("double_attack")) {
            double doubleAttackChance = Math.min(0.05 * attacker.getLevel(), 0.5); // 5% per level, max 50%
            if (Math.random() < doubleAttackChance) {
                if (mainHand != null && mainHand.isWeapon()) {
                    result.append("\n").append(performSingleAttack(attacker, target, mainHand, true));
                }
            }
        }

        // Offhand attack chance based on level if dual wield effect is active
        if (attacker.hasEffect("dual_wield")) {
            double dualWieldChance = Math.min(0.03 * attacker.getLevel(), 0.4); // 3% per level, max 40%
            if (Math.random() < dualWieldChance) {
                ObjectItem offHand = attacker.getEquipment().get(EquipSlot.OFFHAND);
                if (offHand != null && offHand.isWeapon()) {
                    result.append("\n").append(performSingleAttack(attacker, target, offHand, true));
                }
            }
        }

        if (target.getTarget() == null) {
            target.setTarget(attacker);
        }

        // after attack messages
        String hpMpStatus = String.format("%s:HP: %d/%d MP: %d/%d  %s:HP: %d/%d MP: %d/%d",
            attacker.getMobName(), attacker.getCurrentHP(), attacker.getMaxHP(), attacker.getCurrentMP(), attacker.getMaxMP(),
            target.getMobName(), target.getCurrentHP(), target.getMaxHP(), target.getCurrentMP(), target.getMaxMP());

        // Send directly to players
        if (attacker instanceof Player playerAttacker) {
            playerAttacker.sendMessage(hpMpStatus);
        }
        if (target instanceof Player playerTarget && playerTarget != attacker) {
            playerTarget.sendMessage(hpMpStatus);
        }

        return result.toString().trim();
    }

    public static String getCombatStatus(Mob a, Mob b) {
        return a.getMobName() + ":HP: " + a.getCurrentHP() + "/" + a.getMaxHP() +
               " MP: " + a.getCurrentMP() + "/" + a.getMaxMP() + "  " +
               b.getMobName() + ":HP: " + b.getCurrentHP() + "/" + b.getMaxHP() +
               " MP: " + b.getCurrentMP() + "/" + b.getMaxMP();
    }

    private static String performSingleAttack(Mob attacker, Mob target, ObjectItem weapon, boolean isOffhand) {
        double vorpalDamage = 1.0;
        if (weapon != null && weapon.isVorpal()) {
            vorpalDamage = weapon.getVampiricPercent();
        }

        int intDamage = 0;
        if (weapon != null && weapon.isIntelligent()) {
            intDamage = weapon.getFlatDamage();
        }

        attacker.setTarget(target);
        int baseDamage = rollWeaponDamage(weapon, attacker);
        int bonusDamage = attacker.getStat("Strength") / 2;
        double scaledDamage = ((baseDamage * vorpalDamage) + intDamage + bonusDamage) * attacker.getRank().getMultiplier();
        int totalDamage = (int) scaledDamage;

        // Vampiric healing
        double vampPercent = weapon != null ? weapon.getVampiricPercent() : 0.0;
        int vampHeal = (int) (totalDamage * vampPercent);
        if (vampHeal > 0) {
            attacker.heal(vampHeal);
        }

        // Damage type
        WeaponDamageType dmgType = (weapon != null && weapon.getDamageType() != null)
            ? weapon.getDamageType()
            : WeaponDamageType.HIT;

        String icon = dmgType.getIcon();
        String verb = dmgType.getPrettyName().toLowerCase();
        String handLabel = isOffhand ? " (offhand)" : "";

        // Apply damage
        int TotalDefenseBonus = 0;
        for (ObjectItem obj : target.getEquipment().values()) {
            TotalDefenseBonus = TotalDefenseBonus + obj.getArmorType().getDefenseBonus();
        }
        if (TotalDefenseBonus >= 100) {
            TotalDefenseBonus = 99;
        }

        int damageTaken = (int) totalDamage * (1 - (TotalDefenseBonus / 100));
        if (damageTaken < 1) damageTaken = 1;
        target.takeDamage(damageTaken);

        // Messaging
        String attackerMsg = "You " + verb + handLabel + " " + target.getMobName() + " for " + damageTaken + " damage! " + icon;
        String targetMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " you for " + damageTaken + " damage! " + icon;
        String roomMsg = attacker.getMobName() + " " + verb + "s" + handLabel + " " + target.getMobName() + "! " + icon;
        String vorpalMsg = "";
        if (weapon != null && weapon.isVorpal()) {
            vorpalMsg = attacker.getMobName() + "'s " + weapon.getName() + " cuts " + target.getMobName() + " deeply.";
        }

        if (attacker instanceof Player playerAttacker) {
            playerAttacker.sendMessage(attackerMsg);
        }
        if (target instanceof Player targetPlayer) {
            targetPlayer.sendMessage(targetMsg);
        } else {
            System.out.println("[Mob] " + targetMsg);
        }
        if (weapon != null && weapon.isVorpal()) {
            attacker.getCurrentRoom().broadcastToExcept(attacker, target, vorpalMsg);
        }

        attacker.getCurrentRoom().broadcastToExcept(attacker, target, roomMsg);

        deathStuff(attacker, target);

        return attackerMsg;
    }

    public static void deathStuff(Mob attacker, Mob target) {
        MobAffectFlag NOKILL = MobAffectFlag.NOKILL;
        MobAffectFlag REINCARNATE = MobAffectFlag.REINCARNATE;

        if (target.isDead()) {
            // On death, mark combat over (allow movement again)
            attacker.setInCombat(false);
            target.setInCombat(false);

            if (target.hasAffect(REINCARNATE)) {
                for (int i = target.getReincarnateRemaining(); i > 0;) {
                    int rinc = target.getReincarnateRemaining();

                    target.setCurrentHP(target.getMaxHP() / i);
                    target.setMaxHP(target.getMaxHP() / i);
                    i--;

                    target.getCurrentRoom().broadcast(target.getMobName() + " rises from the dead. They have " + i + " reincarnations remaning.", target);
                    target.setReincarnateRemaining(i);

                    if (rinc == 0) {
                        target.removeAffect(REINCARNATE);
                    }
                    return;
                }
            }

            if (target.hasAffect(NOKILL)) {
                target.setCurrentHP(1);
                attacker.sendMessage("You cannot kill " + target.getMobName() + ".");
                target.setTarget(null);
                attacker.setTarget(null);
                return;
            }

            String deathMsg = target.getMobName() + " has been slain!";

            if (target instanceof Player playerAttacker) {
                playerAttacker.sendMessage(deathMsg);
                playerAttacker.setCurrentHP(1);
                playerAttacker.setCurrentMP(1);
            }

            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You have been slain!");
            }

            attacker.getCurrentRoom().broadcastToExcept(attacker, target, deathMsg);

            // grant exp
            if (attacker instanceof Player player) {
                int exp = target.getExpValue();
                player.gainExpShared(exp);
            }

            // handle levelup check and levelup
            if (attacker.getExp() >= Leveling.getExpToLevel(attacker.getLevel())) {
                attacker.levelUp(attacker.getLevel() + 1);
                attacker.applyLevelScaling(attacker.getLevel());
            } else {
                System.out.println("Not enough exp for levelup");
            }

            attacker.setTarget(null);

            for (Mob mob : WorldManager.getAllMobs()) {
                if (mob.getTarget() == target) {
                    mob.setTarget(null);
                }
            }

            List<ObjectItem> loot = target.dropAllLoot();
            for (ObjectItem item : loot) {
                attacker.getCurrentRoom().addObject(item);
            }

            ObjectItem corpse = new ObjectItem("corpse of " + target.getMobName());
            corpse.setShortDescription("a corpse of " + target.getMobName());
            corpse.setType(ObjectType.TRASH);
            corpse.setContents(loot);
            attacker.getCurrentRoom().addObject(corpse);

            target.setCurrentRoom(null);
            attacker.getCurrentRoom().removeMob(target);
            attacker.getRoom().removeMob(target);
            
            attacker.setInCombat(false);
            target.setInCombat(false);
        }
    }

    private static int rollWeaponDamage(ObjectItem weapon, Mob attacker) {
        if (weapon == null || weapon.getDamageDice() == null) {
            int level = attacker.getLevel();
            if (level >= 75) return rollDice(4, 6);
            if (level >= 50) return rollDice(3, 6);
            if (level >= 20) return rollDice(2, 6);
            if (level >= 10) return rollDice(1, 8);
            return rollDice(1, 6);
        }

        String[] parts = weapon.getDamageDice().split("d");
        int num = Integer.parseInt(parts[0]);
        int sides = Integer.parseInt(parts[1]);

        return rollDice(num, sides) + weapon.getDamageBonus();
    }

    private static int rollDice(int num, int sides) {
        int total = 0;
        for (int i = 0; i < num; i++) {
            total += random.nextInt(sides) + 1;
        }
        return total;
    }

    // --- Leveling system ---
    public static class Leveling {
        private static final int BASE_EXP = 5000;
        private static final double GROWTH_RATE = 1.25;

        public static int getExpToLevel(int level) {
            if (level <= 1) {
                return BASE_EXP;
            }
            return (int) (BASE_EXP * Math.pow(GROWTH_RATE, level - 1));
        }
    }
}
