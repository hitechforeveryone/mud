package mud.core;

import java.util.*;
import java.util.Random;
import java.util.stream.Stream;

import mud.spell.effects.Effect;

public class ObjectItem implements HasKeywords {

	private int objID;
	private String name;
	private String shortDescription;
	private String longDescription;
	private String extDescription;
	private List<EquipSlot> equipSlot = new ArrayList<>();

	private List<String> keywords = new ArrayList<>();
	
	private ObjectType type = ObjectType.NONE;

	private WeaponType weaponType;
	private WeaponDamageType damageType = WeaponDamageType.HIT;
	private ArmorType armorType;

	private String damageDice = null;
	private int damageBonus = 0;

	private int diceCount = 1;  // Number of dice to roll, e.g. 2 in "2d6"
	private int diceSides = 6;  // Number of sides per die, e.g. 6 in "2d6"


	private int strengthBonus = 0;
	private int staminaBonus = 0;
	private int intellectBonus = 0;
	private int agilityBonus = 0;
	private int hitrollBonus = 0;
	private int damrollBonus = 0;
	private int hpBonus = 0;
	private int mpBonus = 0;

	private boolean vorpal = false; // chance to deal 1.5x base damage
	private boolean poisoned = false; // chance to cast PoisonSpell on target
	private boolean intelligent = false;
	private boolean vampiric = false;
	private int vampiricPercent = 0;
	private int flatDamage = 0;
	private boolean sapient = false;
	private List<String> sapientSpeeches = new ArrayList<>();
	private long lastWhisperTick = -1L;
	
	private boolean stackable = false;
	private int stackCount = 1;
	private int stackSize = 1;
	private int maxStackSize = 1;

	private boolean lockable = false;
	private boolean locked = false;
	private boolean closed = false;

	private boolean container = false;
	private boolean isOpen = true;
	private List<ObjectItem> contents = new ArrayList<>();


	private int charges = 0;
	private int maxCharges = 0;

	private int copper = 0;
	private int silver = 0;
	private int gold = 0;
	private int platinum = 0;
	private int valueCopper = 0;
	private int valueSilver = 0;
	private int valueGold = 0;
	private int valuePlatinum = 0;

	private int durability = 0;       // current durability
	private int maxDurability = 0;    // optional max durability

	private static Random random = new Random();



	// ─────────────────────────────────────────────────────────────────────────────
	public ObjectItem() {
	    // Optional: initialize defaults here
	    this.type = ObjectType.NONE;
	    this.equipSlot = new ArrayList<>();
	    this.stackCount = 1;
	    this.maxStackSize = 1;
	    this.stackSize = 1;
	    this.damageType = WeaponDamageType.HIT;
	    this.keywords = new ArrayList<>();
	}
	
	public ObjectItem(String name, String description) {
		this.name = name;
		this.shortDescription = description;
	}

	public ObjectItem(String name) {
		this.name = name;
	}
	// ─────────────────────────────────────────────────────────────────────────────
	// Factory methods

	public static ObjectItem createWeapon(String name, String desc, WeaponType wtype, WeaponDamageType dtype) {
		ObjectItem item = new ObjectItem(name, desc);
		item.type = ObjectType.WEAPON;
		item.weaponType = wtype;
		item.damageType = dtype;
		return item;
	}

	public static ObjectItem createArmor(String name, String desc, ArmorType armorType) {
		ObjectItem item = new ObjectItem(name, desc);
		item.type = ObjectType.ARMOR;
		item.armorType = armorType;
		return item;
	}

	public static ObjectItem createFood(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.FOOD)
				.setStackable(true, 30)
				.setCharges(1);
	}

	public static ObjectItem createDrink(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.DRINK)
				.setStackable(true, 30)
				.setCharges(1);
	}

	public static ObjectItem createPotion(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.POTION)
				.setStackable(true, 30)
				.setCharges(1);
	}

	public static ObjectItem createScroll(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.SCROLL)
				.setStackable(true, 30)
				.setCharges(1);
	}

	public static ObjectItem createWand(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.WAND)
				.setCharges(1);
	}

	public static ObjectItem createStaff(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.STAFF)
				.setCharges(1);
	}

	public static ObjectItem createContainer(String name, String desc) {
		ObjectItem item = new ObjectItem(name, desc);
		item.type = ObjectType.CONTAINER;
		item.container = true;
		item.closed = false;
		item.lockable = false;
		item.locked = false;
		return item;
	}

	public static ObjectItem createKey(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.KEY)
				.setCharges(-1);
	}

	public static ObjectItem createController(String name, String desc) {
		return new ObjectItem(name, desc)
				.setType(ObjectType.CONTROLLER)
				.setCharges(-1);
	}

	public static ObjectItem createCoins(String name, String desc) {
		return new ObjectItem(name, desc).setType(ObjectType.COIN).setStackable(true, 9999);
	}

	public static ObjectItem createTreasure(String name, String desc) {
		return new ObjectItem(name, desc).setType(ObjectType.TREASURE);
	}

	public static ObjectItem createSign(String name, String desc) {
		return new ObjectItem(name, desc).setType(ObjectType.SIGN);
	}

	public static ObjectItem createTrash(String name, String desc) {
		return new ObjectItem(name, desc).setType(ObjectType.TRASH);
	}

	public static ObjectItem createPart(String name, String desc) {
		return new ObjectItem(name, desc).setType(ObjectType.PART).setCharges(1);
	}


	// ─────────────────────────────────────────────────────────────────────────────
	// Stack logic

	public boolean canStackWith(ObjectItem other) {
		return this.stackable && other.stackable &&
				this.name.equalsIgnoreCase(other.name) &&
				this.type == other.type;
	}

	public boolean combineStack(ObjectItem other) {
		if (!canStackWith(other)) return false;
		int available = this.maxStackSize - this.stackCount;
		int toTransfer = Math.min(available, other.stackCount);
		this.stackCount += toTransfer;
		other.stackCount -= toTransfer;
		return true;
	}

	public ObjectItem splitStack(int count) {
		if (!stackable || count <= 0 || count >= stackCount) return null;
		ObjectItem copy = this.copy();
		copy.stackCount = count;
		this.stackCount -= count;
		return copy;
	}

	public ObjectItem copy() {
		ObjectItem copy = new ObjectItem(this.name, this.shortDescription);
		copy.type = this.type;
		copy.weaponType = this.weaponType;
		copy.damageType = this.damageType;
		copy.armorType = this.armorType;
		copy.damageDice = this.damageDice;
		copy.damageBonus = this.damageBonus;
		copy.intelligent = this.intelligent;
		copy.vampiricPercent = this.vampiricPercent;
		copy.flatDamage = this.flatDamage;
		copy.stackable = this.stackable;
		copy.stackCount = this.stackCount;
		copy.maxStackSize = this.maxStackSize;
		copy.lockable = this.lockable;
		copy.locked = this.locked;
		copy.closed = this.closed;
		copy.container = this.container;
		copy.isOpen = this.isOpen;
		copy.charges = this.charges;
		copy.copper = this.copper;
		copy.silver = this.silver;
		copy.gold = this.gold;
		copy.platinum = this.platinum;
		copy.equipSlot = this.equipSlot;
		copy.keywords = new ArrayList<>(this.keywords);
		return copy;
	}

	// ─────────────────────────────────────────────────────────────────────────────
	// Getters / Setters

	public boolean isWeapon() { return type == ObjectType.WEAPON; }
	public boolean isArmor() { return type == ObjectType.ARMOR; }
	public boolean isIntelligent() { return intelligent; }
	public void setIntelligent(boolean val) { this.intelligent = val; }

	public boolean isContainer() { return container; }
	public boolean isClosed() { return closed; }
	public boolean isLocked() { return locked; }
	public boolean isLockable() { return lockable; }
	public void setClosed(boolean b) { this.closed = b; }
	public void setLocked(boolean b) { this.locked = b; }
	public void setLockable(boolean b) { this.lockable = b; }

	public int getCharges() { return charges; }

	public boolean isStackable() { return stackable; }
	public ObjectItem setCharges(int charges) {
		this.charges = charges;
		return this;
	}

	public ObjectItem setStackable(boolean stackable) {
		this.stackable = stackable;
		return this;
	}

	public ObjectItem setStackable(boolean stackable, int maxStackSize) {
		this.stackable = stackable;
		this.maxStackSize = maxStackSize;
		return this;
	}

	public ObjectItem setType(ObjectType type) {
		this.type = type;
		return this;
	}


	public int getStackCount() { return stackCount; }
	public int getMaxStackSize() { return maxStackSize; }
	public void setStackCount(int count) { this.stackCount = count; }
	public void setMaxStackSize(int max) { this.maxStackSize = max; }

	public String getName() { return name; }

	public String getDamageDice() { return damageDice; }
	public int getDamageBonus() { return damageBonus; }
	public void setDamageDice(int num, int sides) { this.damageDice = num + "d" + sides; }
	public void setDamageBonus(int bonus) { this.damageBonus = bonus; }

	public int getFlatDamage() { return flatDamage; }
	public void setFlatDamage(int val) { this.flatDamage = val; }
	public int getVampiricPercent() { return vampiricPercent; }
	public void setVampiricPercent(int val) { this.vampiricPercent = val; }

	public WeaponType getWeaponType() { return weaponType; }
	public ArmorType getArmorType() { return armorType; }
	public WeaponDamageType getDamageType() { return damageType; }
	public void setDamageType(WeaponDamageType type) { this.damageType = type; }

	public Stream<EquipSlot> getEquipSlot() { return equipSlot.stream() ; }
	public void setEquipSlot(EquipSlot slot) { this.equipSlot.add(slot); }

	public ObjectType getObjectType() {
		return type;
	}

	public List<String> getKeywords() { return keywords; }
	

	public String getDamageTypePretty() {
		return damageType != null ? damageType.getPrettyName() + " " + damageType.getIcon() : "Physical 🗡️";
	}

	public int getTotalCopperValue() {
		return copper +
				silver * 100 +
				gold * 1000 +
				platinum * 10000;
	}
	public String getShortDescription() {
		if (shortDescription != null && !shortDescription.isEmpty()) {
			return shortDescription;
		}
		return name;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getExtDescription() {
		return extDescription;
	}

	public void setExtDescription(String extDescription) {
		this.extDescription = extDescription;
	}

	public boolean isOpen() {
		return isOpen;
	}

	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
	}

	public int getCopper() {
		return copper;
	}

	public void setCopper(int copper) {
		this.copper = copper;
	}

	public int getSilver() {
		return silver;
	}

	public void setSilver(int silver) {
		this.silver = silver;
	}

	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getPlatinum() {
		return platinum;
	}

	public void setPlatinum(int platinum) {
		this.platinum = platinum;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public void setWeaponType(WeaponType weaponType) {
		this.weaponType = weaponType;
	}

	public void setArmorType(ArmorType armorType) {
		this.armorType = armorType;
	}

	public void setDamageDice(String damageDice) {
		this.damageDice = damageDice;
	}

	public void setContainer(boolean container) {
		this.container = container;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

	// Add a keyword (safe, lowercase, deduplicates)
	public void addKeyword(String keyword) {
		if (keyword == null || keyword.isEmpty()) return;
		String lower = keyword.toLowerCase();
		if (!keywords.contains(lower)) {
			keywords.add(lower);
		}
	}// end addKeyword

	// Set all keywords at once (overwrites existing)
	public void setKeywords(String... keys) {
		keywords.clear();
		if (keys != null) {
			for (String k : keys) addKeyword(k);
		}
	}// end setKeywords

	// Check for exact keyword match
	public boolean hasKeyword(String keyword) {
		if (keyword == null || keyword.isEmpty()) return false;
		return keywords.contains(keyword.toLowerCase());
	}// end hasKeyword

	// Check for partial keyword match (e.g. "swo" matches "sword")
	public boolean matchesKeyword(String keyword) {
		if (keyword == null || keyword.isEmpty()) return false;
		String lower = keyword.toLowerCase();
		for (String k : keywords) {
			if (k.contains(lower)) return true;
		}
		return false;
	}// end matchesKeyword

	// Optional: Get keywords as string (for debug or `look`)
	public String getKeywordSummary() {
		return String.join(", ", keywords);
	}// end getKeywordSummary

	public boolean consume(int amount) {
		if (amount <= 0) return false;

		boolean depleted = false;

		// Reduce charges
		if (charges >= 0) {
			charges -= amount;
			if (charges < 0) charges = 0;
			if (charges == 0) depleted = true;
		}

		// Reduce stack size
		if (stackable) {
			stackSize -= amount;
			if (stackSize < 0) stackSize = 0;
			if (stackSize == 0) depleted = true;
		}

		return depleted;
	} // end consume


	public int getStackSize() { return stackSize; }
	public void setStackSize(int stackSize) { this.stackSize = stackSize; }
	// In ObjectItem class:

	// Total value stored in copper coins
	private int valueInCopper = 0;

	// Getter/setter for value in copper
	public int getValueInCopper() {
		return valueInCopper;
	}

	public void setValueInCopper(int valueInCopper) {
		this.valueInCopper = Math.max(0, valueInCopper);
	}

	// Calculate sell value (usually less than buy value, e.g., 50%)
	public int getSellValue() {
		return valueInCopper / 2;  // 50% sellback value
	}

	// Calculate buy value (full value or could add markup)
	public int getBuyValue() {
		return valueInCopper;
	}

	// Optionally, methods to get value in coins breakdown (copper/silver/gold/platinum)
	public int getPlatinumValue() {
		return valueInCopper / 10000; // 100 copper * 10 silver * 10 gold = 10000 copper per platinum
	}

	public int getGoldValue() {
		return (valueInCopper / 1000) % 10; // 100 copper * 10 silver = 1000 copper per gold, mod 10 for remainder
	}

	public int getSilverValue() {
		return (valueInCopper / 100) % 10; // 100 copper per silver, mod 10 for remainder
	}

	public int getCopperValue() {
		return valueInCopper % 100;
	}
	// In ObjectItem class

	private int value = 0;  // total value in copper coins

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = Math.max(0, value);
	}

	// You can keep or add getSellValue() and getBuyValue() like this:


	public int rollDamage() {
		if (intelligent && flatDamage >= 0) {
			return flatDamage;
		}

		if (damageDice == null || damageDice.isEmpty()) {
			return 1; // fallback
		}

		String[] parts = damageDice.split("d");
		try {
			int num = Integer.parseInt(parts[0]);
			int sides = Integer.parseInt(parts[1]);

			int total = 0;
			for (int i = 0; i < num; i++) {
				total += random.nextInt(sides) + 1;
			}
			return total + damageBonus;
		} catch (NumberFormatException e) {
			return 1; // fallback in case of malformed dice string
		}
	} // end rollDamage

	public void setValue(int copper, int silver, int gold, int platinum) {
		this.valueCopper = copper;
		this.valueSilver = silver;
		this.valueGold = gold;
		this.valuePlatinum = platinum;
	}

	public int getValueCopper() {
		return valueCopper;
	}

	public int getValueSilver() {
		return valueSilver;
	}

	public int getValueGold() {
		return valueGold;
	}

	public int getValuePlatinum() {
		return valuePlatinum;
	}

	public int getTotalValueInCopper() {
		return valueCopper
				+ (valueSilver * 100)
				+ (valueGold * 1000)
				+ (valuePlatinum * 10000);
	}
	public String getValueString() {
		List<String> parts = new ArrayList<>();
		if (valuePlatinum > 0) parts.add(valuePlatinum + "p");
		if (valueGold > 0) parts.add(valueGold + "g");
		if (valueSilver > 0) parts.add(valueSilver + "s");
		if (valueCopper > 0) parts.add(valueCopper + "c");
		return parts.isEmpty() ? "no value" : String.join(" ", parts);
	}

	public String getFullValueString() {
		int platinum = getPlatinumValue();
		int gold = getGoldValue();
		int silver = getSilverValue();
		int copper = getCopperValue();

		StringBuilder sb = new StringBuilder();
		if (platinum > 0) sb.append(platinum).append("p ");
		if (gold > 0) sb.append(gold).append("g ");
		if (silver > 0) sb.append(silver).append("s ");
		if (copper > 0 || sb.length() == 0) sb.append(copper).append("c");

		return sb.toString().trim();
	}



	public int getHpBonus() {
		return hpBonus;
		}
	
	public void setHpBonus(int value) { 
		this.hpBonus = value;
		}

	public int getMpBonus() { 
		return mpBonus;
		}
	
	public void setMpBonus(int value) { 
		this.mpBonus = value;
		}

	public int getStrengthBonus() {
		return strengthBonus;
	}

	public void setStrengthBonus(int strengthBonus) {
		this.strengthBonus = strengthBonus;
	}

	public int getStaminaBonus() {
		return staminaBonus;
	}

	public void setStaminaBonus(int staminaBonus) {
		this.staminaBonus = staminaBonus;
	}

	public int getIntellectBonus() {
		return intellectBonus;
	}

	public void setIntellectBonus(int intellectBonus) {
		this.intellectBonus = intellectBonus;
	}

	public int getAgilityBonus() {
		return agilityBonus;
	}

	public void setAgilityBonus(int agilityBonus) {
		this.agilityBonus = agilityBonus;
	}

	public int getHitrollBonus() {
		return hitrollBonus;
	}

	public void setHitrollBonus(int hitrollBonus) {
		this.hitrollBonus = hitrollBonus;
	}

	public int getDamrollBonus() {
		return damrollBonus;
	}

	public void setDamrollBonus(int damrollBonus) {
		this.damrollBonus = damrollBonus;
	}

	public static Random getRandom() {
		return random;
	}

	public static void setRandom(Random random) {
		ObjectItem.random = random;
	}

	public ObjectType getType() {
		return type;
	}

	public void setValueCopper(int valueCopper) {
		this.valueCopper = valueCopper;
	}

	public void setValueSilver(int valueSilver) {
		this.valueSilver = valueSilver;
	}

	public void setValueGold(int valueGold) {
		this.valueGold = valueGold;
	}

	public void setValuePlatinum(int valuePlatinum) {
		this.valuePlatinum = valuePlatinum;
	}
	public int getDurability() {
		return durability;
	}

	public void setDurability(int durability) {
		this.durability = Math.max(0, durability);
	}

	public int getMaxDurability() {
		return maxDurability;
	}

	public void setMaxDurability(int maxDurability) {
		this.maxDurability = Math.max(0, maxDurability);
	}
	
	public boolean hasDurability() {
		return maxDurability > 0;
	}
	
	public int getMaxCharges() {
		return maxCharges;
	}

	public void setMaxCharges(int maxCharges) {
		this.maxCharges = Math.max(0, maxCharges);
	}
	
	public boolean hasCharges() {
		return maxCharges > 0;
	}
	
	public boolean useCharge() {
		if (charges > 0) {
			charges--;
			return true;
		}
		return false; // no charges left
	}
	
	public int getDiceCount() {
		return diceCount;
	}

	public void setDiceCount(int diceCount) {
		this.diceCount = Math.max(1, diceCount); // minimum 1 die
	}

	public int getDiceSides() {
		return diceSides;
	}

	public void setDiceSides(int diceSides) {
		this.diceSides = Math.max(2, diceSides); // minimum 2 sides per die
	}
	public String getDamageDiceString() {
		return diceCount + "d" + diceSides;
	}

	public void setVorpal(boolean vorpal) {
		this.vorpal = vorpal;
	}

	public void setPoisoned(boolean poisoned) {
		this.poisoned = poisoned;
	}

	public int getObjID() {
		return objID;
	}

	public void setObjID(int objID) {
		this.objID = objID;
	}
	
	public void setContents(List<ObjectItem> contents) {
	    this.contents = contents;
	}

	public List<ObjectItem> getContents() {
	    return contents;
	}


	public String returnStatBlock() {
	    StringBuilder sb = new StringBuilder();

	    sb.append("📦 Object ID: ").append(getObjID()).append("\n");
	    sb.append("Name: ").append(getName()).append("\n");
	    sb.append("Short Description: ").append(getShortDescription()).append("\n");
	    sb.append("Long Description: ").append(getLongDescription()).append("\n");
	    sb.append("Extended Description: ").append(getExtDescription()).append("\n");
	    sb.append("Keywords: ").append(String.join(", ", getKeywords())).append("\n");

	    sb.append("Item Type: ").append(getObjectType()).append("\n");
	    sb.append("Value: ").append(getValue()).append("\n");

	    // Optional: If it’s a weapon or armor
	    if (isWeapon()) {
	    	sb.append("Damage Type: ").append(getDamageType());
	        sb.append("Weapon Damage: ").append(getDiceSides())
	          .append(" / ").append(getDiceCount()).append("\n");
	    }

	    if (isArmor()) {
	        sb.append("Armor Rating: ").append(getArmorType()).append("\n");
	    }

	    // for later
	    // Optional: Show any flags or magical effects
	    

	    if (!getEffects().isEmpty()) {
	        sb.append("Effects:\n");
	        for (ItemEffect effect : getEffects()) {
	            sb.append("  - ").append(effect.getDisplayName()).append("\n");
	        }
	    }
	    
	    
	    // Speeches
	    sb.append("\nSpeeches: ");
	    if (sapientSpeeches.isEmpty()) {
	    	  sb.append("None");
	    }
	    else {
	    	sb.append(getSapientSpeeches()).append("\n");
	    }
		    
	    return sb.toString();
	}
	private EnumSet<ItemEffect> effects = EnumSet.noneOf(ItemEffect.class);

	public void addEffect(ItemEffect effect) {
	    effects.add(effect);
	}

	public boolean hasEffect(ItemEffect effect) {
	    return effects.contains(effect);
	}
	public EnumSet<ItemEffect> getEffects() {
	    return effects;
	}

	public boolean isBlessed() { return hasEffect(ItemEffect.BLESSED); }
	public boolean isCursed() { return hasEffect(ItemEffect.CURSED); }
	public boolean isMagic() { return hasEffect(ItemEffect.MAGIC); }
	public boolean isHumming() { return hasEffect(ItemEffect.HUMMING); }
	public boolean isVorpal() { return hasEffect(ItemEffect.VORPAL); }
	public boolean isPoisoned() { return hasEffect(ItemEffect.POISONED); }
	public boolean isBurning() { return hasEffect(ItemEffect.BURNING); }

	public int getDefenseBonus() {
	    if (this.type == ObjectType.ARMOR && armorType != null) {
	        return armorType.getDefenseBonus();
	    }
	    return 0;
	}
	public boolean isSapient() {
	    return sapient;
	}

	public void setSapient(boolean sapient) {
	    this.sapient = sapient;
	}

	public void setSapientSpeeches(String... speeches) {
	    sapientSpeeches.clear();
	    sapientSpeeches.addAll(Arrays.asList(speeches));
	}

	public List<String> getSapientSpeeches() {
	    return sapientSpeeches;
	}

	public long getLastWhisperTick() {
	    return lastWhisperTick;
	}

	public void setLastWhisperTick(long tick) {
	    this.lastWhisperTick = tick;
	}
	
	public static void processSapientItemWhispers(Mob mob, long currentTick) {
	    for (ObjectItem item : mob.getInventory()) {
	        if (item.isSapient() && !item.getSapientSpeeches().isEmpty()) {
	            if (currentTick > item.getLastWhisperTick()) {
	                String msg = item.getSapientSpeeches()
	                        .get(ObjectItem.getRandom().nextInt(item.getSapientSpeeches().size()));
	                mob.sendMessage("\uD83C\uDFA7 " + item.getName() + " whispers: '" + msg + "'");
	                item.setLastWhisperTick(currentTick);
	            }
	        }
	    }
	}

	public boolean isVampiric() {
		return vampiric;
	}

	public void setVampiric(boolean vampiric) {
		this.vampiric = vampiric;
	}

	public void setEquipSlot(List<EquipSlot> equipSlot) {
		this.equipSlot = equipSlot;
	}

	public void setSapientSpeeches(List<String> sapientSpeeches) {
		this.sapientSpeeches = sapientSpeeches;
	}

	public void setEffects(EnumSet<ItemEffect> effects) {
		this.effects = effects;
	}

}
// end ObjectItem
