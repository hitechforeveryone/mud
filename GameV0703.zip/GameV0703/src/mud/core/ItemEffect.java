package mud.core;

public enum ItemEffect {
    BLESSED("Blessed", "✨"),
    CURSED("Cursed", "☠️"),
    MAGIC("Magic", "🔮"),
    HUMMING("Humming", "🎵"),
    VORPAL("Vorpal", "🗡️"),
    POISONED("Poisoned", "☣️"),
    BURNING("Burning", "🔥"),
    NO_DROP("No Drop", "🚫"),
    NOIDLE("No Idle", "⏳"),
    NOTAKE("No Take", "✋"),
    NOBREAK("No Break", "🚫"),
    NOSUMMON("No Summon","🚫"),
    NOCHARM("No Charm","🚫"),
    ;

    private final String displayName;
    private final String emoji;

    ItemEffect(String displayName, String emoji) {
        this.displayName = displayName;
        this.emoji = emoji;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getEmoji() {
        return emoji;
    }
}
