package mud.core;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.*;

import mud.core.ObjectItem;
import mud.system.GameClock;
import mud.core.Player;
import mud.core.RoomFlag;
import mud.editor.RoomEditor;

import java.util.stream.Collectors;


public class Room  {


	private int id;
	private Zone zone;

	private String name = "New Room";
	private String description = "An empty, dull room.";
	private String shortDescription = "an empty room";
	private List<Mob> mobs = new ArrayList<>();
	private List<ObjectItem> objects = new ArrayList<>();
	private boolean isDark = false; // default to false
	private boolean isNightTime;
	

	private int roomFlags = 0;   // bitflags to store your new flags, replaces isDark
//	private Set<RoomFlag> flags = EnumSet.noneOf(RoomFlag.class);
	private final Set<RoomFlag> flags = EnumSet.noneOf(RoomFlag.class);

	private int tunnelNum = 0;   // for TUNNEL flag max mobs/players allowed

	private Map<Direction, Room> exits = new HashMap<>();
	
	private transient Map<Direction, Door> doors = new HashMap<>();
	private transient RoomEditor editor;


	public Room() {
		// Initialize with defaults
		this.id = 0;
		this.name = "Unnamed Room";
		this.description = "This room is empty.";
		this.zone = null; // Set later
		// Add any other default init as needed
		 this.zoneExits = new HashMap<>();
	}

	public Room(int id) {
		this.id = id;
		// Initialize other fields if necessary
	}

	public Room(String description) {
		this.description = description;
	}

	public String getFullDescription() {
		StringBuilder sb = new StringBuilder();

		// Core room description
		sb.append(description);

		// Optional environmental feedback
		if (isDark) {
			sb.append("\nIt is very dark here.");
		} else if (isNightTime) {
			sb.append("\nThe moonlight casts eerie shadows across the room.");
		}

		return sb.toString();
	}

    public synchronized void addMob(Mob mob) {
        if (mob == null) return;
        if (mobs.contains(mob)) {
            // Optional: debug
            System.out.println("[Room] Skipping duplicate add for mob " + mob.getMobName() + " in room " + id);
            return;
        }
        mobs.add(mob);
    }

    public synchronized void removeMob(Mob mob) {
        mobs.remove(mob);
    }
    
	public List<Mob> getMobs() {
	   // System.out.println("Room contains mobs: " + mobs.stream().map(Mob::getId).toList());
	    return mobs;
	}


	// Add or set exit in a direction
	public void setExits(Map<Direction, Room> exits) {
		this.exits = exits;
	}

	public Room getExit(Direction dir) {
		return exits.get(dir);
	}

	public void setDoor(Direction dir, Door door) {
		doors.put(dir, door);
	}

	public Door getDoor(Direction dir) {
		return doors.get(dir);
	}

	public void broadcastExcept(String message, Mob... excluded) {
		Set<Mob> exclusions = new HashSet<>(Arrays.asList(excluded));
		for (Mob mob : getMobs()) {
			if (!exclusions.contains(mob)) {
				mob.sendMessage(message);
			}
		}
	}

	public Mob findMobByName(String name) {
		for (Mob mob : mobs) {
			if (mob.getMobName().equalsIgnoreCase(name)) {
				return mob;
			}
		}
		return null;
	}
	public ObjectItem findObjectByName(String name) {
		for (ObjectItem obj : objects) {
			if (obj.getName().equalsIgnoreCase(name)) {
				return obj;
			}
		}
		return null;
	}
	public void addObject(ObjectItem obj) {
		objects.add(obj);
	}

	public void removeObject(ObjectItem obj) {
		objects.remove(obj);
	}

	public List<ObjectItem> getObjects() {
		return objects;
	}

	public List<ObjectItem> findObjectsByKeyword(String keyword) {
	    List<ObjectItem> matches = new ArrayList<>();
	    String lowerKeyword = keyword.toLowerCase();

	    for (ObjectItem obj : this.objects) {  // or this.objects depending on your field name
	        if (obj.getName() != null && obj.getName().toLowerCase().contains(lowerKeyword)) {
	            matches.add(obj);
	        }
	    }

	    return matches;
	}

	public List<Mob> findMobsByKeyword(String keyword) {
	    List<Mob> matches = new ArrayList<>();
	    for (Mob mob : mobs) {
	    	if (mob.hasKeyword(keyword)) {
	    		matches.add(mob);
	    	}
	    }
	    return matches;
	}


	
	

	private static boolean matchesKeyword(HasKeywords entity, String keyword) {
		if (keyword == null) return false;
		for (String key : entity.getKeywords()) {
			if (key != null && key.equalsIgnoreCase(keyword)) {
				return true;
			}
		}
		return false;
	}

	public boolean isNightTime() {
		return WorldManager.getGlobalClock().isNight();
	}
	public Room(String shortDescription, String fullDescription) {
		this.shortDescription = shortDescription;
		this.description = fullDescription;
	}
	public Room(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public boolean isDark() {
		return hasFlag(RoomFlag.DARK);
	}

	public void setDark(boolean value) {
		if (value) setFlag(RoomFlag.DARK);
		else clearFlag(RoomFlag.DARK);
	}

	@SuppressWarnings("unlikely-arg-type")
	public Door getDoor(String direction) {
		return doors.get(direction.toLowerCase());
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name != null ? name : "Unnamed Room";
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<Direction, Room> getExits() {
		return exits;
	}

	public void setDoors(Map<Direction, Door> doors) {
		this.doors = doors;
	}


	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public void setMobs(List<Mob> mobs) {
		this.mobs = mobs;
	}

	public void setObjects(List<ObjectItem> objects) {
		this.objects = objects;
	}
	public String getShortDescription() {
		return name + ": " + description.split("\\.")[0] + ".";  // First sentence
	}
	private Map<Direction, ZoneExit> zoneExits = new HashMap<>();

	public void setZoneExit(Direction dir, ZoneExit ze) {
	    if (zoneExits == null) {
	        zoneExits = new HashMap<>();
	    }
	    zoneExits.put(dir, ze);
	    System.out.println("[DEBUG] ZoneExit set for direction " + dir + ": " + ze);
	}


	public ZoneExit getZoneExit(Direction dir) {
		return zoneExits.get(dir);
	}

    public Map<Direction, ZoneExit> getZoneExits() {
        return Collections.unmodifiableMap(zoneExits);
    }

	public void setZoneExits(Map<Direction, ZoneExit> zoneExits) {
		this.zoneExits = zoneExits;
	}

	public void setNightTime(boolean isNightTime) {
		this.isNightTime = isNightTime;
	}

	public void setExit(Direction dir, Room room) {
		exits.put(dir, room);
	}

	public void broadcastToExcept(Mob excluded1, Mob excluded2, String message) {
		for (Mob mob : mobs) {
			if (mob != excluded1 && mob != excluded2) {
				mob.sendMessage(message);
			}
		}

	} // end broadcastToExcept	

	public void broadcastToRoom(String message) {
		for (Mob mob : mobs) {
			if (mob != null) {
				mob.sendMessage(message);
			}
		}
	} // end broadcastToRoom


	public void broadcastToExcept2(Mob excluded1, Mob excluded2, String message) {
		for (Mob mob : mobs) {
			if (mob != excluded1 && mob != excluded2) {
				mob.sendMessage(message);
			}
		}
	}

	public void broadcast(String message, Mob sender) {
		for (Mob mob : mobs) {
			if (mob != null && mob != sender && mob instanceof Player) {
				((Player) mob).sendMessage(message);
			}
		}
	}

	public Zone getZone() {
		return zone;
	}

	public void setZone(Zone zone) {
		this.zone = zone;
	}

	public Mob getMobByName(String... nameParts) {
		String target = String.join(" ", nameParts).toLowerCase();

		for (Mob mob : getMobs()) {
			for (String keyword : mob.getKeywords()) {
				if (target.equalsIgnoreCase(keyword)) {
					return mob;
				}
			}

			if (mob.getShortDescription().toLowerCase().contains(target) ||
					mob.getMobName().toLowerCase().contains(target)) {
				return mob;
			}
		}
		return null;
	}
	public Map<Direction, String> getAllExits() {
	    Map<Direction, String> all = new HashMap<>();

	    // normal exits (in-zone)
	    for (Map.Entry<Direction, Room> e : exits.entrySet()) {
	        Room r = e.getValue();
	        all.put(e.getKey(), "Room " + r.getId()); // or r.getRoomId() depending on your Room class
	    }

	    // zone exits (cross-zone)
	    for (Map.Entry<Direction, ZoneExit> e : zoneExits.entrySet()) {
	        ZoneExit ze = e.getValue();
	        all.put(e.getKey(), "World " + ze.getTargetWorldId() +
	                            " Zone " + ze.getTargetZoneId() +
	                            " Room " + ze.getTargetRoomId());
	    }

	    return all;
	}


	public List<Door> getMatchingDoors(String keyword) {
		List<Door> matches = new ArrayList<>();
		for (Direction dir : Direction.values()) {
			Door door = getDoor(dir);
			if (door != null && door.hasKeyword(keyword)) {
				matches.add(door);
			}
		}
		return matches;
	}

	public List<Mob> getMatchingMobs(String keyword, Mob exclude) {
		return mobs.stream()
				.filter(mob -> !mob.equals(exclude) && mob.hasKeyword(keyword))
				.toList();
	}

	public List<ObjectItem> getMatchingObjects(String keyword) {
		return objects.stream()
				.filter(obj -> obj.hasKeyword(keyword))
				.toList();
	}
	/*
    public boolean hasFlag(RoomFlag flag) {
        return (roomFlags & flag.getBit()) != 0;
    }
	 
	public void setFlag(RoomFlag flag) {
		roomFlags |= flag.getBit();
	}
*/
	public void clearFlag(RoomFlag flag) {
		roomFlags &= ~flag.getBit();
	}

	public void toggleFlag(RoomFlag flag) {
		roomFlags ^= flag.getBit();
	}
	public int getTunnelNum() {
		return tunnelNum;
	}

	public void setTunnelNum(int tunnelNum) {
		this.tunnelNum = tunnelNum;
	}
	public boolean isOutside() {
		return hasFlag(RoomFlag.OUTSIDE);
	}

	public void setOutside(boolean value) {
		if (value) setFlag(RoomFlag.OUTSIDE);
		else clearFlag(RoomFlag.OUTSIDE);
	}
/*
	public boolean hasPlayers() {
		return mobs.stream().anyMatch(m -> m instanceof Player);
	}
*/
	public void clearMobs() {
		mobs.clear();
	}

	public void clearObjects() {
		objects.clear(); // Assumes your Room class has a List<ObjectItem> named 'objects'
	}

	// Similarly for other important flags like FALL, NOMOB, etc.

	public String getFlagsString() {
		StringBuilder sb = new StringBuilder();
		for (RoomFlag flag : RoomFlag.values()) {
			if (hasFlag(flag)) {
				if (sb.length() > 0) sb.append(", ");
				sb.append(flag.name());
			}
		}
		return sb.length() > 0 ? sb.toString() : "None";
	}

	public boolean setFlagByName(String name) {
		try {
			RoomFlag flag = RoomFlag.valueOf(name.toUpperCase());
			setFlag(flag);
			return true;
		} catch (IllegalArgumentException e) {
			return false;
		}
	}

	public int getRoomFlags() {
		return roomFlags;
	}

	public void setRoomFlags(int roomFlags) {
		this.roomFlags = roomFlags;
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		if (doors == null) {
			doors = new HashMap<>();
		}
		editor = null; // force null editor after deserialization
	}

	public Map<Direction, Door> getDoors() {
		if (doors == null) {
			doors = new HashMap<>();
		}
		return doors;
	}


	public void addFlag(RoomFlag flag) {
		flags.add(flag);
	}

	public void removeFlag(RoomFlag flag) {
		flags.remove(flag);
	}

	public boolean hasFlag(RoomFlag flag) {
		return flags.contains(flag);
	}

	public List<Player> getPlayers() {
	    List<Player> players = new ArrayList<>();
	    for (Mob mob : mobs) {
	        if (mob instanceof Player player) {
	            players.add(player);
	        }
	    }
	    return players;
	}
	
	public boolean hasPlayers() {
	    for (Mob mob : mobs) {
	        if (mob instanceof Player) return true;
	    }
	    return false;
	}



	public Set<RoomFlag> getFlags() {
	    return Collections.unmodifiableSet(flags);
	}

	public void setFlag(RoomFlag flag) {
	    flags.add(flag);
	}

	public void clearFlags() {
	    flags.clear();
	}

	private boolean lit = false;

	public boolean isLit() {
	    return lit;
	}

	public void setLit(boolean lit) {
	    this.lit = lit;
	}
	public ObjectItem getObject(int objectId) {
	    for (ObjectItem obj : objects) {
	        if (obj.getObjID() == objectId) {
	            return obj;
	        }
	    }
	    return null; // Not found
	}

	public String returnStatBlock() {
	    StringBuilder sb = new StringBuilder();

	    sb.append("🏠 Room ID: ").append(getId()).append("\n");
	    sb.append("Name: ").append(getName()).append("\n");
	    sb.append("Short Description: ").append(getShortDescription()).append("\n");
	    sb.append("Long Description: ").append(getDescription()).append("\n");

	    sb.append("Room Flags: ");
	    if (getFlags() != null && !getFlags().isEmpty()) {
	    	sb.append(getFlags().stream()
	    	        .map(Enum::name) // or .toString() if not enum
	    	        .collect(Collectors.joining(", ")));

	    } else {
	        sb.append("None");
	    }
	    sb.append("\n");

	    sb.append("Tunnel Limit: ").append(getTunnelNum()).append("\n");

	    // this works
	    sb.append("Exits:\n");
	    for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
	        Direction dir = entry.getKey();
	        Room dest = entry.getValue();
	        sb.append("  ").append(dir.name()).append(" -> Room ")
	          .append(dest.getId()).append(": ").append(dest.getName());

	        // Check if there's a door for this direction
	        Door door = doors.get(dir);
	        if (door != null) {
	            sb.append(" [Door: ")
	              .append(door.getDoorName()); // or description if you prefer
	            if (door.isLocked()) sb.append(", locked");
	            if (door.isClosed()) sb.append(", closed");
	            sb.append("]");
	        }

	        sb.append("\n");
	    }
	    Map<Direction, ZoneExit> zoneExits = getZoneExits();
	    if (zoneExits != null && !zoneExits.isEmpty()) {
	        for (Map.Entry<Direction, ZoneExit> entry : zoneExits.entrySet()) {
	            ZoneExit ze = entry.getValue();
	            sb.append("  ").append(entry.getKey().name())
	              .append(" => ZoneExit to ")
	              .append("World ").append(ze.getTargetWorldId())
	              .append(" Zone ").append(ze.getTargetZoneId())
	              .append(" Room ").append(ze.getTargetRoomId()).append("\n");
	        }
	    } else {
	        sb.append("ZoneExits: None or not loaded\n");
	    }

	    System.out.println("[DEBUG] ZoneExits map: " + getZoneExits());

	    return sb.toString();
	}



} // end Room