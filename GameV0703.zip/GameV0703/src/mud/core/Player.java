package mud.core;


import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

import mud.editor.Editor;
import mud.editor.HelpEditorFieldEditor;
import mud.server.ClientHandler;
import mud.spell.effects.Effect;

public class Player extends Mob {
	
	private transient PrintWriter writer;


	private String name;
	private World currentWorld;
	private Zone currentZone;
	private String respawnWorldId;
	private int respawnZoneId;
	private int respawnRoomId;
	private String playerTitle = "";
	private int privilegeLevel = 0;

	private String passwordHash;
	private String passwordSalt;

	private int money = 0;
	private int moneyCopper = 0;

	private Party party;
	private String pendingPartyInviteFrom;

	// Transient handler (not serialized)
	private transient ClientHandler handler;
    private String password;
    
    private long lastAttackTime;
    private static final long ATTACK_DELAY = 2000;
 // These should be private
    private StringBuilder multilineBuffer;
    private Editor multilineEditor;
    private boolean awaitingMultiline = false;
    private Player lastTellSender;

    private World rentWorld;
    private Zone rentZone;
    private Room rentRoom;

    public void setRentWorld(World world) { this.rentWorld = world; }
    public void setRentZone(Zone zone) { this.rentZone = zone; }
    public void setRentRoom(Room room) { this.rentRoom = room; }

    public World getRentWorld() { return rentWorld; }
    public Zone getRentZone() { return rentZone; }
    public Room getRentRoom() { return rentRoom; }

    private boolean pendingLogout;

    public boolean isPendingLogout() {
        return pendingLogout;
    }

    public void setPendingLogout(boolean pendingLogout) {
        this.pendingLogout = pendingLogout;
    }

    public boolean canAttack() {
        return System.currentTimeMillis() - lastAttackTime >= ATTACK_DELAY;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
	// Constructors
	public Player() {
		this.name = "unknown player";
	}
	
	public Player(String name) {
		super(name);
		this.name = name;
	}

	public Player(String name, World world) {
		this(name);
		this.currentWorld = world;
		if (world != null) {
			this.setCurrentRoom(world.getStartingRoom());
		}
	}


	public boolean checkPassword(String inputPassword) {
	    return this.password != null && this.password.equals(inputPassword);
	}


	private static String hashPassword(String password, String salt) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(salt.getBytes());
			byte[] hashed = md.digest(password.getBytes());

			StringBuilder sb = new StringBuilder();
			for (byte b : hashed) sb.append(String.format("%02x", b));
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("SHA-256 not available", e);
		}
	}

	private static String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		StringBuilder sb = new StringBuilder();
		for (byte b : salt) sb.append(String.format("%02x", b));
		return sb.toString();
	}

	public String getPasswordSalt() {
		return passwordSalt;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	// === World / Zone ===
	public World getCurrentWorld() {
		return currentWorld;
	}

	public void setCurrentWorld(World world) {
		this.currentWorld = world;
		if (world != null) {
			this.setCurrentRoom(world.getStartingRoom());
		}
	}

	public Zone getCurrentZone() {
		return currentZone;
	}

	public void setCurrentZone(Zone zone) {
		this.currentZone = zone;
	}

	// === Identity ===
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlayerTitle() {
		return playerTitle;
	}

	public void setPlayerTitle(String title) {
		this.playerTitle = title;
	}

	public String getDisplayName() {
		return (name + ", " + playerTitle + " ").trim();
	}

	public int getPrivilegeLevel() {
		return privilegeLevel;
	}

	public void setPrivilegeLevel(int level) {
		this.privilegeLevel = level;
	}

	// === Client Connection ===
	public void setClientHandler(ClientHandler handler) {
		this.handler = handler;
	}

	public ClientHandler getClientHandler() {
		return handler;
	}
/*
	public void sendMessage(String msg) {
		if (handler != null) {
			handler.sendMessage(msg);
			}
		else {
	        System.out.println("[Player] " + msg);
	    };
	}
	*/
	public void setWriter(PrintWriter writer) {
	    this.writer = writer;
	}

	public void sendMessage(String message) {
	    if (writer != null) {
	        writer.println(message);
	        writer.flush();
	    } else {
	        System.out.println("⚠️ Cannot send message to player " + getName() + ": writer is null");
	    }
	}

	public void disconnect() {
		if (handler != null) handler.disconnect();
	}

	// === Equipment ===
	public ObjectItem getEquippedItem(EquipSlot slot) {
		return equipment.get(slot);
	}

	public void equipItem(EquipSlot slot, ObjectItem item) {
		equipment.put(slot, item);
	}

	public ObjectItem unequip(EquipSlot slot) {
		ObjectItem removed = equipment.remove(slot);
	//	if (removed != null) removed.setEquipSlot(null);
		return removed;
	}

	public ObjectItem unequipItem(EquipSlot slot) {
		return unequip(slot); // alias
	}

	// === Money ===
	public int getMoney() {
		return money;
	}

	public void setMoney(int amount) {
		this.money = Math.max(0, amount);
	}

	public void incrementMoney(int amount) {
		if (amount > 0) money += amount;
	}

	public boolean decrementMoney(int amount) {
		if (amount > 0 && money >= amount) {
			money -= amount;
			return true;
		}
		return false;
	}

	public int getMoneyCopper() {
		return moneyCopper;
	}

	public void setMoneyCopper(int copper) {
		this.moneyCopper = Math.max(0, copper);
	}

	public void addMoneyCopper(int copper) {
		if (copper > 0) moneyCopper += copper;
	}

	public boolean removeMoneyCopper(int copper) {
		if (copper > 0 && moneyCopper >= copper) {
			moneyCopper -= copper;
			return true;
		}
		return false;
	}

	public String getMoneyString() {
		int remaining = moneyCopper;
		int platinum = remaining / 10000; remaining %= 10000;
		int gold = remaining / 1000; remaining %= 1000;
		int silver = remaining / 100; remaining %= 100;
		int copper = remaining;

		StringBuilder sb = new StringBuilder();
		if (platinum > 0) sb.append(platinum).append(" platinum ");
		if (gold > 0) sb.append(gold).append(" gold ");
		if (silver > 0) sb.append(silver).append(" silver ");
		if (copper > 0 || sb.isEmpty()) sb.append(copper).append(" copper");
		return sb.toString().trim();
	}

	// === Party System ===
	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}

	public String getPendingPartyInviteFrom() {
		return pendingPartyInviteFrom;
	}

	public void setPendingPartyInviteFrom(String inviter) {
		this.pendingPartyInviteFrom = inviter;
	}
	private int experience = 0;

	public int getExperience() {
	    return experience;
	}

	public void gainExp(int amount) {
	    if (amount <= 0) return;
	    experience += amount;
	    sendMessage("You gain " + amount + " experience.");

	    // Optional: handle level-up (if your system supports it)
	    checkLevelUp();
	}

	private void checkLevelUp() {
	    int expToNext = getLevel() * 100;
	    while (experience >= expToNext) {
	        experience -= expToNext;
	        setLevel(getLevel() + 1);
	        sendLevelUpMessage();
	        expToNext = getLevel() * 100;
	    }
	}
	
	private void sendLevelUpMessage() {
	    String[] flair = {
	        "✨ You feel a surge of power as you reach a new level! ✨",
	        "🔥 A warm energy courses through you... Level up! 🔥",
	        "⚔️ You grow stronger. You are now level " + getLevel() + "! ⚔️",
	        "🌟 The world bends slightly to your will. Level " + getLevel() + " achieved! 🌟",
	        "💫 You ascend in skill and knowledge. Welcome to level " + getLevel() + "! 💫"
	    };
	    sendMessage("\n" + flair[getLevel() % flair.length] + "\n");
	}
	
	public void gainExpShared(int totalExp) {
	    List<Player> partyMembers = (party != null) ? party.getMembers() : List.of(this);

	    // Only count party members in the same room
	    List<Player> localMembers = new ArrayList<>();
	    for (Player p : partyMembers) {
	        if (p.getCurrentRoom() == this.getCurrentRoom()) {
	            localMembers.add(p);
	        }
	    }

	    int share = Math.max(1, totalExp / localMembers.size());
	    for (Player p : localMembers) {
	        p.gainExp(share);
	    }
	}

	public boolean isAdmin() {
	    // Assuming privilegeLevel 2 and above is admin
	    return this.getPrivilegeLevel() >= 2;
	}

	public String getRespawnWorldId() { return respawnWorldId; }
	public void setRespawnWorldId(String id) { this.respawnWorldId = id; }

	public int getRespawnZoneId() { return respawnZoneId; }
	public void setRespawnZoneId(int id) { this.respawnZoneId = id; }

	public int getRespawnRoomId() { return respawnRoomId; }
	public void setRespawnRoomId(int id) { this.respawnRoomId = id; }
	
	public void updateRespawnLocationFromCurrentRoom() {
	    Room room = this.getCurrentRoom();
	    if (room == null) return;

	    Zone zone = WorldManager.getZoneOfRoom(room);
	    if (zone == null) return;

	    World world = zone.getWorld();
	    if (world == null) return;

	    this.setRespawnWorldId(world.getWorldId());
	    this.setRespawnZoneId(zone.getZoneId());
	    this.setRespawnRoomId(room.getId());
	}
	
    private Editor currentEditor;

    public void setEditor(Editor editor) {
    	System.out.println("DEBUG: Editor set to " + (editor != null ? editor.getEditorName() : "null"));
        this.currentEditor = editor;
        if (editor != null) {
            editor.startEditing();
        }
    }


    public Editor getEditor() {
        return currentEditor;
    }

    public boolean isInEditor() {
        return currentEditor != null;
    }

    public void handleEditorInput(String input) {
        if (currentEditor != null) {
            currentEditor.handleInput(input);
        }
    }
    
    public boolean hasEffect(EffectType effectType) {
        return hasEffect(effectType.name());
    }


    public boolean isAwaitingMultiline() {
        return awaitingMultiline;
    }
    private boolean collectingMultilineInput = false;
    private Editor multilineTarget;

    // Getters/Setters
    public void setAwaitingMultiline(boolean b) { this.awaitingMultiline = b; }

    public StringBuilder getMultilineBuffer() { return multilineBuffer; }
    public Editor getMultilineEditor() { return multilineEditor; }

    public void startMultilineInput(Editor editor) {
        this.multilineBuffer = new StringBuilder();
        this.multilineEditor = editor;
        this.awaitingMultiline = true;
    }

    public void appendMultilineInput(String line) {
        if (multilineBuffer != null) {
            multilineBuffer.append(line).append("\n");
        }
    }

    public void cancelMultilineInput() {
        this.awaitingMultiline = false;
        this.multilineBuffer = null;
        this.multilineEditor = null;
    }
    public void handleInput(String input) {
        // Handle multiline input first
        if (collectingMultilineInput) {
            if ("END".equalsIgnoreCase(input.trim())) {
                collectingMultilineInput = false;
                if (multilineTarget instanceof HelpEditorFieldEditor fieldEditor) {
                    fieldEditor.applyMultilineInput(this, multilineBuffer.toString().trim());
                }
                multilineTarget = null;
                multilineBuffer = null;
            } else {
                multilineBuffer.append(input).append("\n");
            }
            return;
        }

        // Normal input handling
        if (currentEditor != null) {
            currentEditor.handleInput(input);
        } else {
            sendMessage("No active editor.");
        }
    }

	public String returnStatBlock() {
	    StringBuilder sb = new StringBuilder();

	    sb.append("Player Number: ").append(getId()).append("\n");
	    sb.append("Player Name: ").append(getMobName()).append("  Title: ").append(getPlayerTitle()).append("\n");
	    sb.append("Player Short Desc: ").append(getShortDescription()).append("\n");
	    sb.append("Player Long Desc: ").append(getLongDescription()).append("\n");
	    sb.append("Player Ext Desc: ").append(getExtendedDescription()).append("\n");

	    // Keywords
	    List<String> keywordList = getKeywords(); // safer than split
	    sb.append("Keywords: ").append(String.join(", ", keywordList)).append("\n");

	    sb.append("Keyword 1: ").append(Optional.ofNullable(getKeyword1()).orElse("")).append("  ")
	      .append("Keyword 2: ").append(Optional.ofNullable(getKeyword2()).orElse("")).append("  ")
	      .append("Keyword 3: ").append(Optional.ofNullable(getKeyword3()).orElse("")).append("\n");

	    sb.append("Professions: [").append(getProfession()).append("]\n");
	    sb.append("Race: [").append(getRace()).append("]  Subrace: [")
	      .append(getSubrace()).append("]  Level: [")
	      .append(getLevel()).append("]   Rank: [")
	      .append(getRank()).append("]\n");

	    sb.append("XP Value: ").append(getExpValue()).append("\n");
	    

	    sb.append("HPs: [").append(getBaseHP()).append("/").append(getMaxHP()).append("]   MPs: [")
	      .append(getBaseMP()).append("/").append(getMaxMP()).append("]\n");

	    sb.append("Stamina: ").append(getStamina())
	      .append("  Strength: ").append(getStrength())
	      .append("   Intelligence: ").append(getIntellect())
	      .append("   Agility: ").append(getAgility()).append("\n");

	    // Behavior Flags
	    sb.append("\nBehavior Flags: ");
	    for (MobBehaviorFlag flag : MobBehaviorFlag.values()) {
	        if (hasBehavior(flag)) {
	            sb.append(flag.name()).append(" ");
	        }
	    }

	    // Affect Flags
	    sb.append("\nAffect Flags: ");
	    for (MobAffectFlag flag : MobAffectFlag.values()) {
	        if (hasAffect(flag)) {
	            sb.append(flag.name()).append(" ");
	        }
	    }

	    // Spell/Ability Effect Flags
	    sb.append("\nEffect Flags: ");
	    if (activeEffects.isEmpty()) {
	        sb.append("None");
	    } else {
	        for (Effect effect : activeEffects) {
	            sb.append(effect.getName()).append(" ");
	        }
	    }
	    
	    /*
	    // Extra Booleans
	    sb.append("\nAttackable: ").append(getAttackable())
	      .append("  Talker: ").append(getV46())
	      .append("  Wanders: ").append(getWanders()).append("\n");
	     */
	    
	    
	    return sb.toString();
	}
	
	@Override
	public String getMobName() {
	    return this.name; // not null
	}
	public Player getLastTellSender() {
	    return lastTellSender;
	}

	public void setLastTellSender(Player lastTellSender) {
	    this.lastTellSender = lastTellSender;
	}

} // end Player
