package mud.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MobAI {

	public static void tickMobBehavior() {
		for (Mob mob : WorldManager.getAllMobs()) {
			Room room = mob.getCurrentRoom();
			if (room == null) continue; // skip if mob has no room


			// --- CITYGUARD ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.CITYGUARD) && !mob.getInCombat()) {
				// check mobs and players in room
				List<Mob> potentialVictims = new ArrayList<>();
				potentialVictims.addAll(room.getMobs());
				potentialVictims.addAll(room.getPlayers());

				for (Mob victim : potentialVictims) {
					if (victim == mob) continue; // skip self
					if (!victim.getInCombat() || victim.getTarget() == null) continue;

					Mob aggressor = victim.getTarget();
					if (aggressor == mob) continue; // don’t rescue from self
					if (aggressor.getTarget() != victim) continue; // only intervene if aggressor is still fighting victim

					room.broadcast(mob.getMobName() + " intervenes to protect " + victim.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " rescued " + victim.getMobName() + " from " + aggressor.getMobName());

					// Guard takes over combat
					mob.setTarget(aggressor);
					mob.setInCombat(true);

					aggressor.setTarget(mob);
					aggressor.setInCombat(true);

					victim.setTarget(null);
					victim.setInCombat(false);

					break; // only rescue once per tick
				}
			}

			// --- ASSISTER ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.ASSISTER) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					if (player.getInCombat() && player.getTarget() != null) {
						room.broadcast(mob.getMobName() + " rushes to aid its ally against " + player.getMobName() + "!", mob);
						mob.setTarget(player);
						mob.setInCombat(true);
						break;
					}
				}
			}


			// --- AGGRESSIVE ---
			// this part works
			if (mob.hasBehavior(MobBehaviorFlag.AGGRESSIVE) && !mob.getInCombat()) {
				for (Mob player : room.getPlayers()) {
					System.out.println("DEBUG: Found player " + player.getMobName() + " in room " + room.getId());
				}

				for (Mob player : room.getPlayers()) {

					if (player == null) continue; // safety
					// Optional: skip dead/disconnected players here

					room.broadcast(mob.getMobName() + " snarls and attacks " + player.getMobName() + "!", mob);
					System.out.println(mob.getMobName() + " attacked " + player.getMobName());

					// Mob engages combat
					mob.setTarget(player);
					mob.setInCombat(true);

					// Player is now in combat with mob
					player.setTarget(mob);
					player.setInCombat(true);

					break; // only attack one player per tick
				}
			}


			// --- JANITOR ---
			// will check when ObjectItems are finalized
			if (mob.hasBehavior(MobBehaviorFlag.JANITOR)) {
				for (ObjectItem obj : new ArrayList<>(room.getObjects())) { // avoid CME
					if (obj.getObjectType() == ObjectType.TRASH || obj.getObjectType() == ObjectType.CONTAINER) {
						mob.addItem(obj);
						room.removeObject(obj);
						room.broadcast(mob.getMobName() + " picks up " + obj.getName() + ".", mob);
					}
				}
			}


			// --- HUNTER ---
			if (mob.hasBehavior(MobBehaviorFlag.HUNTER)) {
				// TODO:
				// Track nearest player, move toward them across rooms (stay in Zone)
				// If in room with player, attack
			}


			// --- HEALER ----
			if (mob.hasBehavior(MobBehaviorFlag.HEALER)) {
				// TODO: 
				// If in room with mob/player && mob/player hp < 100, cast heal on mob/player

			}


			// --- PICKPOCKET ----
			if (mob.hasBehavior(MobBehaviorFlag.PICKPOCKET)) {
				// TODO: 
				// if in room with player, attempt to take coins from player
			}


			// --- WIMPY ----
			if (mob.hasBehavior(MobBehaviorFlag.PICKPOCKET)) {
				// TODO: 
				// if incombat, attempt to flee in random direction, exit combat
			}




			// --- other behaviors from MobBehaviorFlag go here ---

		}
	} // end tickMobBehavior()


	public static void tickMobMovement() {
		for (World world : WorldManager.getAllWorlds()) {
			tickMobMovement(world);
		}
	}

	// Enhanced tickMobMovement to confirm mobs are processed
	public static void tickMobMovement(World world) {
		// for Debugging
		//System.out.println("[MobMove] Ticking movement for world: " + world.getName()); 
		//System.out.println("World " + world.getName() + " has " + world.getRooms().size() + " rooms.");

		// Collect moves first (Mob -> Destination Room)
		Map<Mob, Room> moves = new HashMap<>();

		for (Room room : world.getRooms()) {
			List<Mob> mobs = room.getMobs();

			// Use a copy to safely iterate
			List<Mob> mobsCopy = new ArrayList<>(mobs);

			for (Mob mob : mobsCopy) {
				if (mob == null) continue;

				System.out.println("[MobMove] Checking mob: " + mob.getMobName());

				if (mob.hasBehavior(MobBehaviorFlag.STATIONARY)) continue;

				Room currentRoom = mob.getCurrentRoom();
				if (currentRoom == null) continue;

				Zone currentZone = currentRoom.getZone();
				if (currentZone == null) continue;

				Map<Direction, Room> exits = currentRoom.getExits();
				if (exits == null || exits.isEmpty()) continue;

				List<Direction> validDirs = new ArrayList<>();

				for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
					Direction dir = entry.getKey();
					Room dest = entry.getValue();

					if (dest == null) continue;
					if (dest.getZone() != currentZone) continue;
					if (dest.hasFlag(RoomFlag.NOMOB)) continue;

					Door door = currentRoom.getDoor(dir);
					if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

					// Skip lastRoom to avoid immediate backtracking
					if (dest == mob.getLastRoom()) continue;

					validDirs.add(dir);
				}

				// Allow backtracking only if no other options
				if (validDirs.isEmpty()) {
					for (Map.Entry<Direction, Room> entry : exits.entrySet()) {
						Direction dir = entry.getKey();
						Room dest = entry.getValue();

						if (dest == null) continue;
						if (dest.getZone() != currentZone) continue;
						if (dest.hasFlag(RoomFlag.NOMOB)) continue;

						Door door = currentRoom.getDoor(dir);
						if (door != null && door.isClosed() && !mob.hasBehavior(MobBehaviorFlag.HUNTER)) continue;

						validDirs.add(dir);
					}
				}

				if (!validDirs.isEmpty()) {
					Direction chosen = validDirs.get(new Random().nextInt(validDirs.size()));
					Room dest = currentRoom.getExit(chosen);

					if (dest != null && !dest.hasFlag(RoomFlag.NOMOB)) {
						moves.put(mob, dest);
						
					}
				}
			}
		}

		// Now apply moves after iteration to avoid concurrent modification
		for (Map.Entry<Mob, Room> entry : moves.entrySet()) {
			Mob mob = entry.getKey();
			Room dest = entry.getValue();
			Room currentRoom = mob.getCurrentRoom();

			if (currentRoom != null) {
				currentRoom.removeMob(mob);
				currentRoom.broadcast(mob.getMobName() + " wanders.", mob);
			}

			mob.setCurrentRoom(dest);
			dest.addMob(mob);
			mob.setLastRoom(currentRoom);

			dest.broadcast(mob.getMobName() + " arrives.", mob);
		}
	}

	public static String oppositeDirection(String dir) {
		return switch (dir.toLowerCase()) {
		case "north" -> "south";

		case "south" -> "north";
		case "east"  -> "west";
		case "west"  -> "east";
		case "up"    -> "down";
		case "down"  -> "up";
		case "northeast" -> "southwest";
		case "southeast" -> "northwest";
		case "southwest" -> "northeast";
		case "northwest" -> "southeast";
		default      -> "unknown";
		};
	}





}
