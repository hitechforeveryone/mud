package mud.config;

public class ChangeLog {
	
	
	// v7.0.3 basic mobAI implemented, more spells, work on zone scripts, work on Party system
	// v7.0.2 Zone exits work
	// v7.0.1 redesign of base structure on game, modularized game systems, work on Zone Exits
	// v7.0.0 created a Server and Client login system for game
	// v6.0.0 player objects gone, players are now Mobs
	// v0.5.3.6 various small updates		
	// v0.5.0.8 weapons deal damage now, armor provides damage redux now
	// v0.5.0 introduces zone objects and zoneScript objects (not working)
	

}
