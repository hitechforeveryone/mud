package mud.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import mud.core.*;
import mud.scripting.ZoneScript;
import mud.server.LoginManager;
import mud.spell.Spell;
import mud.spell.SpellManager;
import mud.spell.effects.Effect;
import mud.system.GameClock;
import mud.system.PlayerLoader;
import mud.combat.CombatManager;
import mud.config.Config;
import mud.editor.Editor;
import mud.editor.HelpEditor;
import mud.editor.HelpEditorFieldEditor;
import mud.editor.MobEditor;
import mud.editor.ObjectEditor;
import mud.editor.PlayerEditor;
import mud.editor.RoomEditor;
import mud.editor.WorldEditor;
import mud.editor.ZoneEditor;
import mud.editor.ZoneScriptEditor;

public class CommandProcessor {

	private static final PrintWriter PrintWriter = null;
	private static final BufferedReader BufferedReader = null;
	private static WorldManager worldManager;

	public CommandProcessor(WorldManager worldManager) {
		this.worldManager = worldManager;
	}

	public static String processCommand(String input, Player player) throws Exception {
		// Quick check for common shorthand commands before tokenization
		if (input.startsWith("'")) { // ' = say
		    String message = input.substring(1).trim();
		    if (message.isEmpty()) return "Say what?";
		    return handleSay(player, message);
		}
		if (input.startsWith("\"")) { // " = shout or yell
		    String message = input.substring(1).trim();
		    if (message.isEmpty()) return "Shout what?";
		    handleShout(player, message);
		    return null;
		}
		if (input.startsWith("%") || input.startsWith("%%")) { // % or %% = grape
		    String message = input.replaceFirst("^%+", "").trim();
		    if (message.isEmpty()) return "Usage: grapevine <message>";
		    GrapevineCommandHandler.handleGrapevine(player, message);
		    return null;
		}
		if (input.startsWith(":")) { // : = emote
		    String message = input.substring(1).trim();
		    if (message.isEmpty()) return "Emote what?";
		    handleEmote(player, message);
		    return null;
		}
		
		// if player is in multiline editor
		if (player.isAwaitingMultiline()) {
			if (input.trim().equalsIgnoreCase("END")) {
				player.setAwaitingMultiline(false);

				if (player.getMultilineEditor() instanceof HelpEditorFieldEditor subEditor) {
					subEditor.applyMultilineInput(player, player.getMultilineBuffer().toString().trim());
				}

				player.cancelMultilineInput();
			} else {
				player.appendMultilineInput(input);
			}
			return null; // important: do not process normal commands while in multiline
		}

		if (input == null || input.trim().isEmpty()) {
			return "You must enter a command.";
		}

		String[] tokens = input.trim().split("\\s+");
		String cmd = tokens[0].toLowerCase();

		Set<String> adminCommands = Set.of("pkick", "psummon", "goto", "setlevel");

		if (adminCommands.contains(cmd) && !player.isAdmin()) {
			return "You do not have permission to use that command.";
		}

		// Directional movement shortcut
		if (isDirection(cmd)) {
			return handleMovement(player, cmd);
		}

		switch (cmd) {
		// Admin Commands // TODO
		case "pkick":    return handleKick(player, tokens);
		case "psummon":  return handleSummon(player, tokens);
		case "goto":     return handleGoto(player, tokens);
		case "setlevel": return handleSetLevel(player, tokens);

		case "stat": StatCommandHandler.handleStat(player,tokens);
		return null;

		case "/restartgame":
			return null; // Reserved for future restart command

		// game exits	
		case "quit": {
			PlayerLoader.save(player);
			if (player.getEditor() != null) {
				player.getEditor().stopEditing();
				player.setEditor(null);
			}
			player.sendMessage("You have exited to the login screen.");
			WorldManager.removePlayer(player);
			return "quit";} // signal to ClientHandler
			case "rent": {handleRent(player);
			return null;}
			case "camp": {handleCamp(player);
			return null;}
			
			
			case "time": { handleTime(player); }
			return null;
			


		case "title": {
			if (tokens.length < 2) return "Set your title to what?";
			return handleTitle(player, tokens[1].trim());
		}

		case "list": {
			handleList(player, tokens);
			return null;
		}

		case "create": {
			String result = handleCreate(player, tokens);
			return (result == null) ? "Failed to create object. Check your input." : result;
		}

		case "csave": {
			return handleCSave(player, tokens);
		}

		case "go": {
			if (tokens.length < 2) return "Move where?";
			return handleMovement(player, tokens[1].toLowerCase());
		}

		// communication
		case "emote": {
		    if (tokens.length < 2) return "Emote what?";
		    handleEmote(player, input.substring(input.indexOf(' ') + 1));
		    return null;}
		case "frown": {return null;} // TODO // frown notarget and frown @ target
		case "grin": {return null;
			} // TODO // grin notarget and grin @ target
		case "sigh": {return null;} // TODO
		case "dance": {return null;} // TODO
		case "grape":
		case "grapevine": {
			if (tokens.length < 2) {
				return "Usage: grapevine <message>";
			}
			GrapevineCommandHandler.handleGrapevine(player, input.substring(input.indexOf(' ')));
			return null;}
		case "say": {
			if (tokens.length < 2) return "Say what?";
			return handleSay(player, input.substring(input.indexOf(' ')));}
		case "yell":
		case "shout": {
			if (tokens.length < 2) return "Shout what?";
			handleShout(player, input.substring(input.indexOf(' ')));
			return null;}
		case "tell": {
		    handleTell(player, tokens);
		    return null;}
		case "reply": {
		    handleReply(player, tokens);
		    return null;}
		case "whisper": {
		    handleWhisper(player, tokens);
		    return null;}

		// Help
		case "help":
			return handleHelp(player,tokens); // TODO: help system, add more helps
		case "hedit":
			if (tokens.length < 2) {
				player.sendMessage("Usage: hedit <keyword>");
				return null;
			}
			String keyword = tokens[1].toLowerCase();
			HelpEntry existing = HelpManager.getHelpEntry(keyword);
			if (existing != null) {
				player.setEditor(new HelpEditor(existing,player));
			} else {
				player.setEditor(new HelpEditor(keyword,player));
				player.sendMessage("Creating new help entry for: " + keyword);
			}
			return null;
		case "hindex":
			return handleHindex(player,tokens); 

		case "party": {
			return handleParty(player, tokens);
	
		}

		// combat
		case "target": { 
			if (tokens.length < 2) return "target whom?";
			return handleTarget(player, tokens[1].toLowerCase());
		}
		case "kill":
		case "attack": {
			if (tokens.length < 2) return "Attack whom?";
			return handleAttack(player, tokens[1].toLowerCase());
		}

		//spells 
		case "cast": { 
			if (tokens.length < 3) return "Cast what on whom?";
			return handleCast(player, tokens[1], tokens[2].toLowerCase());
		}
		//abilities
		case "rescue": {
			if (tokens.length < 2) return "Rescue who?";
			handleShortCast(player, tokens);
			return null;
		}
		case "kick": {
			if (tokens.length < 2) return "Kick who?";
			handleShortCast(player, tokens);
			return null;
		}
		case "flee": return null; // TODO	
		case "look": {
			handleLook(player, tokens);
			return null;
		}
		case "track": {
			if (tokens.length < 2) return "Track who?";
			handleShortCast(player, tokens);
			return null;
		}

		case "who": {
			handleWho(player);
			return null;
		}
		case "consider": {
			Mob target = player.getCurrentRoom().findMobByName(tokens[1]);
			if (target == null) return "There is no such creature here.";
			return handleConsider(player, target);
		}
		
		// obj management
		case "get": {
			if (tokens.length < 2) return "Get what?";
			handleGet(player, tokens);
		}
		case "drop": {
			if (tokens.length < 2) return "Drop what?";
			return handleDrop(player, tokens[1].toLowerCase());
		}
		case "equip": {
			if (tokens.length < 2) return "Equip what?";
			return handleEquip(player, tokens[1].toLowerCase());
		}
		case "grab": {
			// TODO // if tokens[1] has offhand for an equipslot, equip to offhand slot // for use with wands? shields? offhand weapons?
			return null;
		}
		case "light": {
			// TODO  // if tokens[1] is lightsource, equip to lightsource slot
		}
		case "unequip": {
			if (tokens.length < 2) return "Unequip what?";
			return handleUnequip(player, tokens[1].toLowerCase());
		}
		case "use": {
			if (tokens.length < 2) return "Use what?";
			return handleUseItem(player, tokens[1].toLowerCase());
		}
		case "eat": {
			// TODO // if tokens[1] is food, increase player hp by ....
		}
		case "drink":{
			
		}
		case "open": {
			handleOpen(player, tokens);
			return null;
		}
		case "close": {
			handleClose(player, tokens);
			return null;
		}
		case "lock": {
			handleLock(player, tokens);
			return null;
		}
		case "unlock": {
			handleUnlock(player, tokens);
			return null;
		}
		case "inventory":
		case "inv": return handleInventory(player);
		case "examine":
			return handleExamine(player,tokens); // TODO: update show extended object/mob info
	
		
		case "edit": {
			if (player.getEditor() != null) {
				System.out.println("[DEBUG] Passing input to editor: " + player.getEditor().getEditorName());
				player.getEditor().handleInput(input);
				return null;
			}
			handleEdit(player, tokens);
			return null;
		}

		case "load":
			return handleLoad(player,Arrays.copyOfRange(tokens, 1, tokens.length));

		case "unload":
			return null; // TODO: unload zone or world




		default:
			return "Unknown command: " + cmd;
		}
	}


	private static boolean isDirection(String word) {
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(word)) return true;
		}
		return false;
	}

	private static String handleMovement(Player player, String direction) {
	    Room current = player.getCurrentRoom();
	    Direction dirEnum = Direction.fromString(direction);
	    if (player.isAttacking() == false) {
	    if (dirEnum == null) {
	        return "Invalid direction.";
	    }

	    Door door = current.getDoor(dirEnum);
	    if (door != null) {
	        if (!door.isOpen()) return "🛋 The " + door.getDoorName() + " is closed.";
	        if (door.isLocked()) return "🔒 The " + door.getDoorName() + " is locked.";
	    }

	    // Prioritize cross-zone exits
	    ZoneExit crossZoneExit = current.getZoneExit(dirEnum);
	    if (crossZoneExit != null) {
	        Room nextRoom = WorldManager.getRoom(
	            crossZoneExit.getTargetWorldId(),
	            crossZoneExit.getTargetZoneId(),
	            crossZoneExit.getTargetRoomId()
	            
	        );
            // TODO LOAD WORLD/ZONE
            // check if TargetWorld is loaded if not, load it
            // load the targetZone
	        Zone nextZone = WorldManager.loadZone(crossZoneExit.getWorldId(), crossZoneExit.getTargetZoneId());
            nextRoom = nextZone.getRoom(crossZoneExit.getTargetRoomId());
            current.setExit(dirEnum, nextRoom);
            Direction reverse = dirEnum.getOpposite();
            nextRoom.setExit(reverse,current);

            
            // double check if nextRoom is null
	        if (nextRoom == null) {
	            return "⚠️ The path seems blocked (target room not loaded).";	            
	        }

	        // double check of nextZone is null
	        if (nextZone == null) {
	            return "⚠️ The path seems blocked (target zone missing).";
	        }

	        current.removeMob(player);
	        nextRoom.addMob(player);
	        player.setCurrentRoom(nextRoom);
	        player.setCurrentZone(nextZone);

	        player.sendMessage("You travel " + direction + " to zone " + nextZone.getZoneId() + ".");
	        CommandProcessor.handleLook(player, new String[]{"look"});
	        return null;
	    }

	    // Normal in-zone exit if no zone exit
	    Room next = current.getExit(dirEnum);
	    if (next == null) {
	        return "You can't go that way.";
	    }

	    Zone currentZone = player.getCurrentZone();
	    if (currentZone == null) {
	        return "⚠️ Movement failed: You are not currently in a valid zone.";
	    }

	    current.removeMob(player);
	    next.addMob(player);
	    player.setCurrentRoom(next);

	    player.sendMessage("You move " + direction + ".");
	    CommandProcessor.handleLook(player, new String[]{"look"});
	    }
	    else {
	    	 player.sendMessage("You are in combat.");
	    }
	    return null;
	} // end handleMovement




	public static void handleEmote(Player player, String message) {
		// emotes are physica, they ignore silences
	    if (message == null || message.trim().isEmpty()) {
	        player.sendMessage("Emote what?");
	        return;
	    }

	    String emoteMessage = player.getName() + " " + message.trim();
	    Room room = player.getCurrentRoom();

	    for (Player p : room.getPlayers()) {
	        p.sendMessage(emoteMessage);
	    }
	}

	public static void handleWhisper(Player sender, String[] tokens) {
	    if (tokens.length < 3) {
	        sender.sendMessage("Usage: whisper <player> <message>");
	        return;
	    }

	    if (sender.hasEffect(EffectType.SILENCE)) {
	        sender.sendMessage("You try to whisper, but no sound escapes your lips...");
	        return;
	    }

	    if (sender.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
	        sender.sendMessage("This room is eerily quiet. You cannot whisper here.");
	        return;
	    }

	    String targetName = tokens[1];
	    Player target = (Player) sender.getCurrentRoom().getMobByName(targetName);

	    if (target == null) {
	        sender.sendMessage("No player named '" + targetName + "' is here.");
	        return;
	    }

	    String message = String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length));

	    // Notify both
	    sender.sendMessage("You whisper to " + target.getName() + ": " + message);
	    target.sendMessage(sender.getName() + " whispers to you: " + message);
	}

	public static void handleTell(Player sender, String[] tokens) {
	    if (tokens.length < 3) {
	        sender.sendMessage("Usage: tell <player> <message>");
	        return;
	    }

	    if (sender.hasEffect(EffectType.SILENCE)) {
	        sender.sendMessage("You try to speak, but no sound escapes your lips...");
	        return;
	    }

	    if (sender.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
	        sender.sendMessage("This place is too quiet to send messages.");
	        return;
	    }

	    String targetName = tokens[1];
	    Player recipient = WorldManager.getPlayerByName(targetName);

	    if (recipient == null) {
	        sender.sendMessage("No player named '" + targetName + "' is currently online.");
	        return;
	    }

	    String message = String.join(" ", Arrays.copyOfRange(tokens, 2, tokens.length));
	    sender.sendMessage("You tell " + recipient.getName() + ": " + message);
	    recipient.sendMessage(sender.getName() + " tells you: " + message);
	    recipient.setLastTellSender(sender);

	}

	private static String handleSay(Player player, String message) {
		Room room = player.getCurrentRoom();
		if (player.hasEffect(EffectType.SILENCE)) {
			player.sendMessage("You try to speak, but no sound escapes your lips...");
		}
		room.broadcast(player.getName() + " says: " + message, player);
		return "You say: " + message;
	}
	
	public static void handleReply(Player player, String[] tokens) {
	    if (tokens.length < 2) {
	        player.sendMessage("Usage: reply <message>");
	        return;
	    }

	    if (player.hasEffect(EffectType.SILENCE)) {
	        player.sendMessage("You try to speak, but no sound escapes your lips...");
	        return;
	    }

	    if (player.getCurrentRoom().hasFlag(RoomFlag.QUIET)) {
	        player.sendMessage("This place is too quiet to send messages.");
	        return;
	    }

	    Player target = player.getLastTellSender();
	    if (target == null) {
	        player.sendMessage("You have no one to reply to.");
	        return;
	    }

	    String message = String.join(" ", Arrays.copyOfRange(tokens, 1, tokens.length));
	    player.sendMessage("You tell " + target.getName() + ": " + message);
	    target.sendMessage(player.getName() + " tells you: " + message);
	    target.setLastTellSender(player);  // Update back-and-forth reply support
	}


	public static void handleShout(Player sender, String message) {
		if (message == null || message.isBlank()) {
			sender.sendMessage("Usage: shout <message>");
			return;
		}

		Room currentRoom = sender.getCurrentRoom();

		if (currentRoom.hasFlag(RoomFlag.QUIET)) {
			sender.sendMessage("You cannot shout in this quiet room.");
			return;
		}
		if (sender.hasEffect(EffectType.SILENCE)) {
			sender.sendMessage("You try to shout, but no sound escapes your lips...");
			return;
		}

		Set<Room> targets = new HashSet<>();
		targets.add(currentRoom);

		// Add adjacent rooms
		for (Room adjacent : currentRoom.getExits().values()) {
			if (adjacent != null && !adjacent.hasFlag(RoomFlag.QUIET)) {
				targets.add(adjacent);
			}
		}

		String formatted = "\u001B[33;1m[Shout] " + sender.getName() + " shouts: " + message + "\u001B[0m";

		for (Room room : targets) {
			for (Player p : room.getPlayers()) {
				if (p != sender) {
					p.sendMessage(formatted);
				}
			}
		}

		sender.sendMessage("\u001B[33;1mYou shout: " + message + "\u001B[0m");
	}



	private static String handleAttack(Player player, String targetInput) {
		if (player == null || player.getCurrentRoom() == null) {
			return "You're nowhere and can't attack anything.";
		}

		Room room = player.getCurrentRoom();

		// Parse input like "2.goblin"
		int targetIndex = 1;
		String keyword = targetInput.toLowerCase();

		if (targetInput.contains(".")) {
			String[] parts = targetInput.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1].toLowerCase();
			} catch (NumberFormatException e) {
				// fallback: treat whole string as keyword
				targetIndex = 1;
				keyword = targetInput.toLowerCase();
			}
		}

		// Find matching mobs by keyword
		List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
		if (matchingMobs.size() < targetIndex) {
			return "No such target.";
		}

		Mob target = matchingMobs.get(targetIndex - 1);

		if (target == player) return "You can't attack yourself.";
		if (!player.canAttack()) {
			player.sendMessage("You're still recovering from your last attack!");
			return "";
		}

		player.setLastAttackTime();

		// Mark both as engaged in combat
		player.setTarget(target);
		if (target.getTarget() == null) {
			target.setTarget(player); // Mob knows who attacked it
		}

		return CombatManager.performAttack(player, target);
	}



	@SuppressWarnings("static-access")
	public static String handleShortCast(Player player, String[] tokens) {
	    if (player == null || player.getRoom() == null) {
	        return "You are nowhere. Try again later.";
	    }
	    if (tokens == null || tokens.length == 0) {
	        return "Cast what?";
	    }

	    // Spell is the first token; everything else (joined) is the target argument
	    String spellName = tokens[0].toLowerCase();
	    String targetArg = null;
	    if (tokens.length > 1) {
	        targetArg = String.join(" ", java.util.Arrays.copyOfRange(tokens, 1, tokens.length)).trim();
	        if (targetArg.isEmpty()) targetArg = null;
	    }

	    Spell spell = SpellManager.getInstance().getSpellByName(spellName);
	    if (spell == null) return "You don't know any such ability.";
	    if (!spell.isInstantCast()) return "That spell must be cast using the full 'cast' command.";

	    Mob target = null;

	    if (targetArg != null) {
	        // Normalize and strip surrounding non-alphanum (quotes, punctuation)
	        targetArg = targetArg.trim();
	        targetArg = targetArg.replaceAll("^[^\\p{Alnum}]+|[^\\p{Alnum}]+$", "");

	        // Parse optional numeric disambiguator (e.g. 2.sandor)
	        int requestedIndex = 1;
	        String namePart = targetArg;
	        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+)\\.(.+)$").matcher(targetArg);
	        if (m.matches()) {
	            try {
	                requestedIndex = Math.max(1, Integer.parseInt(m.group(1)));
	            } catch (NumberFormatException ignored) { requestedIndex = 1; }
	            namePart = m.group(2).trim();
	            namePart = namePart.replaceAll("^[^\\p{Alnum}]+|[^\\p{Alnum}]+$", "");
	        }

	        String namePartLower = namePart.toLowerCase();

	        // Collect matches in room order (stable), avoid duplicates
	        java.util.LinkedHashSet<Mob> set = new java.util.LinkedHashSet<>();
	        for (Mob mob : player.getRoom().getMobs()) {
	            if (mob == null) continue;
	            String mobName = mob.getMobName() == null ? "" : mob.getMobName();
	            String mobNameLower = mobName.toLowerCase();

	            // Exact name match has highest priority (and preserves order)
	            if (mobNameLower.equals(namePartLower)) {
	                set.add(mob);
	                continue;
	            }

	            // Keywords / fuzzy matches next
	            try {
	                if (mob.hasKeyword(namePart) || mob.matchesKeyword(namePart)) {
	                    set.add(mob);
	                    continue;
	                }
	            } catch (Exception ignored) {}

	            // Also allow prefix match (player typing 'sand' for 'sandor') - optional
	            if (!mobNameLower.isEmpty() && mobNameLower.startsWith(namePartLower)) {
	                set.add(mob);
	            }
	        }

	        java.util.List<Mob> matches = new java.util.ArrayList<>(set);

	        if (matches.isEmpty()) {
	            return "You don't see anyone named '" + namePart + "' here.";
	        }

	        if (requestedIndex > matches.size()) {
	            // Helpful message for debugging / user clarity: list available matches with indices
	            StringBuilder sb = new StringBuilder();
	            sb.append("There is no '").append(targetArg).append("' here. Matches:\n");
	            for (int i = 0; i < matches.size(); i++) {
	                Mob m2 = matches.get(i);
	                sb.append("  ").append(i+1).append(".").append(m2.getMobName()).append("\n");
	            }
	            return sb.toString();
	        }

	        // Pick the requested instance (1-based index)
	        target = matches.get(requestedIndex - 1);
	    }

	    return SpellManager.castSpell(spellName, player, target);
	}



	private static String handleCast(Player player, String spellName, String targetName) {
		
		
		Mob target = player.getCurrentRoom().findMobByName(targetName);
		if (target == null) {
			player.sendMessage("No such target in room, checking zone.");
			
			for (Mob Ztarget : player.getCurrentZone().getAllMobs()) {
				if (Ztarget.getMobName().equalsIgnoreCase(targetName)) {
					target = Ztarget;
					
					player.sendMessage("First zone target returned.");
					
				}
			}
	
		}
		
		if (player.hasEffect(EffectType.SILENCE)) {
			player.sendMessage("You try to cast, but no sound escapes your lips...");
			return null;
		}
		
		if (target.isDead()) return target.getMobName() + " is already dead.";
		return SpellManager.castSpell(spellName, player, target);
	}

	public static void handleGet(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are nowhere.");
			return;
		}
		Room room = player.getCurrentRoom();

		if (args.length < 2) {
			player.sendMessage("Usage: get <item|all> [from <container>]");
			return;
		}

		// Detect if command contains "from"
		int fromIndex = -1;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("from")) {
				fromIndex = i;
				break;
			}
		}

		String itemName;
		String containerName = null;

		if (fromIndex == -1) {
			// No "from" => getting item(s) from room directly
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		} else {
			if (fromIndex == 1 || fromIndex == args.length - 1) {
				player.sendMessage("Usage: get <item|all> [from <container>]");
				return;
			}
			itemName = String.join(" ", Arrays.copyOfRange(args, 1, fromIndex)).toLowerCase();
			containerName = String.join(" ", Arrays.copyOfRange(args, fromIndex + 1, args.length)).toLowerCase();
		}

		List<ObjectItem> sourceItems;

		if (containerName == null) {
			// Grab from room items
			sourceItems = new ArrayList<>(room.getObjects());  // your method to get all room objects
		} else {
			// Find container in room
			int containerIndex = 1;
			String containerKeyword = containerName;
			if (containerName.contains(".")) {
				String[] parts = containerName.split("\\.", 2);
				try {
					containerIndex = Integer.parseInt(parts[0]);
					containerKeyword = parts[1];
				} catch (NumberFormatException e) {
					containerIndex = 1;
				}
			}
			List<ObjectItem> containers = room.findObjectsByKeyword(containerKeyword);
			if (containers.isEmpty() || containers.size() < containerIndex) {
				player.sendMessage("There is no " + containerKeyword + " here.");
				return;
			}
			ObjectItem container = containers.get(containerIndex - 1);
			if (container.getContents() == null) {
				player.sendMessage("The " + containerKeyword + " is empty.");
				return;
			}
			sourceItems = container.getContents();
		}

		if (itemName.equals("all")) {
			if (sourceItems.isEmpty()) {
				player.sendMessage("There is nothing to get.");
				return;
			}
			// Transfer all items
			List<ObjectItem> toRemove = new ArrayList<>();
			for (ObjectItem item : sourceItems) {
				player.addItem(item);
				toRemove.add(item);
				player.sendMessage("You take " + item.getShortDescription() + ".");
			}
			sourceItems.removeAll(toRemove);
		} else {
			// Specific item requested (could be "corpse" or any other)
			List<ObjectItem> matchingItems = sourceItems.stream()
					.filter(i -> i.getName().toLowerCase().contains(itemName))
					.collect(Collectors.toList());

			if (matchingItems.isEmpty()) {
				player.sendMessage("You don't see that here.");
				return;
			}

			ObjectItem itemToGet = matchingItems.get(0);

			// Remove from source and add to player inventory
			sourceItems.remove(itemToGet);
			player.addItem(itemToGet);

			player.sendMessage("You take " + itemToGet.getShortDescription() + ".");
		}
	}



	private static String handleDrop(Player player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null || inventory.isEmpty()) return "You don't have anything.";

		ObjectItem toDrop = null;
		String lowerItemName = itemName.toLowerCase();

		for (ObjectItem item : inventory) {
			if (item != null && item.getName() != null &&
					item.getName().toLowerCase().contains(lowerItemName)) {
				toDrop = item;
				break;
			}
		}

		if (toDrop == null) return "You don't have that.";

		inventory.remove(toDrop);
		player.getCurrentRoom().addObject(toDrop);
		return "You drop: " + toDrop.getName();
	}



	private static String handleEquip(Player player, String itemName) {
		// TODO might need update
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null) return "You don't have any items.";

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) return "You don’t have that item.";

		Stream<EquipSlot> slot = item.getEquipSlot();
		if (slot == null) return "You cannot equip that item.";

		player.equip(slot.toList().getFirst(), item);
		inventory.remove(item);
		return "You equip the " + item.getName() + ".";
	} // end handleEquip


	public static String handleUseItem(Player player, String itemName) {
		List<ObjectItem> inventory = player.getInventory();
		if (inventory == null) return "You don't have any items.";

		ObjectItem item = null;
		for (ObjectItem i : inventory) {
			if (i.getName().equalsIgnoreCase(itemName)) {
				item = i;
				break;
			}
		}

		if (item == null) return "You don't have that item.";

		if (item.isStackable()) {
			item.setStackCount(item.getStackCount() - 1);
			String msg = "You use one " + item.getName() + ".";
			if (item.getStackCount() <= 0) {
				inventory.remove(item);
				msg += " You have used the last one.";
			}
			// TODO: Apply item effects here
			return msg;
		} else {
			inventory.remove(item); // or keep if reusable
			// TODO: Apply item effects here
			return "You use " + item.getName() + ".";
		}
	} // end handleUseItem


	public static String handleWho(Player viewer) {
		List<Player> players = WorldManager.getActivePlayers();

		List<String> gImms = new ArrayList<>();
		List<String> imms = new ArrayList<>();
		List<String> mortals = new ArrayList<>();

		for (Player p : players) {
			String display = p.getDisplayName();
			int privilege = p.getPrivilegeLevel();

			if (privilege == 2) {
				gImms.add("GImm " + display); // Devs
			}
			else if (privilege == 1) {
				imms.add(" Imm " + display); // Moderators
			} else {
				mortals.add("     " + display); // Regular players
			}
		}


		viewer.sendMessage("Players online (" + players.size() + "):");
		gImms.forEach(viewer::sendMessage);
		imms.forEach(viewer::sendMessage);
		mortals.forEach(viewer::sendMessage);

		return null;
	} // end handleWho



	public static void handleLook(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null) {
			player.sendMessage("You are nowhere.");
			return;
		}

		Room room = player.getCurrentRoom();

		if (args.length < 2 || args[0].equalsIgnoreCase("look") && args.length == 1) {
			lookRoom(player, room);
			return;
		}

		String combinedTarget = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		int targetIndex = 1;
		String keyword = combinedTarget;

		if (combinedTarget.contains(".")) {
			String[] parts = combinedTarget.split("\\.", 2);
			try {
				targetIndex = Integer.parseInt(parts[0]);
				keyword = parts[1];
			} catch (NumberFormatException e) {
				targetIndex = 1;
			}
		}



		List<ObjectItem> matches = room.findObjectsByKeyword(keyword);
		if (matches.size() >= targetIndex) {
			ObjectItem targetItem = matches.get(targetIndex - 1);
			if (targetItem != null && targetItem.getName().toLowerCase().contains("corpse")) {
				if (targetItem.getContents() != null && !targetItem.getContents().isEmpty()) {
					String contents = targetItem.getContents().stream()
							.map(ObjectItem::getShortDescription)
							.collect(Collectors.joining(", "));
					player.sendMessage("Inside the corpse you see: " + contents);
				} else {
					player.sendMessage("The corpse is empty.");
				}
				return;
			}
		}



		// 1. Direction Look
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(keyword)) {
				Room nextRoom = room.getExit(dir);
				if (nextRoom == null) {
					player.sendMessage("There is nothing in that direction.");
					return;
				}

				if (room.isDark() || room.isNightTime()) {
					player.sendMessage("It is too dark to see.");
					return;
				}

				Door door = room.getDoor(dir);
				if (door != null && door.isClosed()) {
					player.sendMessage("You see " + door.getShortDescription() + ".");
					if (door.isLocked()) player.sendMessage("It is locked.");
					return;
				}

				player.sendMessage("You see " + nextRoom.getShortDescription() + ".");
				return;
			}
		}

		// 2. Door Look
		List<Door> matchingDoors = room.getMatchingDoors(keyword);
		if (!matchingDoors.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingDoors.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			Door door = matchingDoors.get(targetIndex - 1);
			player.sendMessage(door.getFullDescription());
			return;
		}

		// 3. Mob Look
		List<Mob> matchingMobs = room.getMatchingMobs(keyword, player);
		if (!matchingMobs.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingMobs.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			Mob mob = matchingMobs.get(targetIndex - 1);
			lookMob(player, mob);
			return;
		}

		// 4. Object Look
		List<ObjectItem> matchingItems = room.getMatchingObjects(keyword);
		if (!matchingItems.isEmpty()) {
			if (targetIndex <= 0 || targetIndex > matchingItems.size()) {
				player.sendMessage("You don't see that here.");
				return;
			}
			ObjectItem item = matchingItems.get(targetIndex - 1);
			lookObject(player, item);
			return;
		}




		player.sendMessage("You don't see anything like that here.");
	} // end handleLook

	private static void lookRoom(Player player, Room room) {
		StringBuilder sb = new StringBuilder();
		sb.append("[").append(room.getId()).append("] ").append(Ansi.BOLD).append(room.getName()).append(Ansi.RESET).append("\n");
		sb.append(room.getFullDescription()).append("\n");

		// room flags
		Set<RoomFlag> flags = room.getFlags();
		String flagsString = flags.isEmpty() ? "None" :
			flags.stream()
			.map(Enum::name)
			.map(String::toLowerCase)
			.collect(Collectors.joining(", "));
		sb.append("Flags: ").append(flagsString).append("\n");

		// room exits
		List<String> exits = new ArrayList<>();
		for (Direction dir : Direction.values()) {
			if (room.getExit(dir) != null) {
				exits.add(dir.name().toLowerCase());
			}
		}
		sb.append(exits.isEmpty() ? "There are no obvious exits.\n" : "Exits: " + String.join(", ", exits) + "\n");
		// room doors
		for (Direction dir : Direction.values()) {
			Door door = room.getDoor(dir);
			if (door != null) {
				sb.append("To the ").append(dir.name().toLowerCase()).append(" is a ");
				sb.append(door.isClosed() ? "closed" : "open").append(" door: ").append(door.getShortDescription()).append("\n");
			}
		}
		// room mobs
		for (Mob mob : room.getMobs()) {
			if (!mob.equals(player)) {
				sb.append("You see ").append(mob.getShortDescription()).append(".\n");
			}
		}
		// room objects
		for (ObjectItem item : room.getObjects()) {
			sb.append("There is ").append(item.getShortDescription()).append(" here.\n");
		}

		sb.append("\n");
		sb.append("\n");

		// this should be player current HP / max HP  followed by current MP / max MP, then if fighting a mob, their HP/MP	    
		sb.append(player.getName()).append(":").append("HP: ").append(player.getCurrentHP()).append("/").append(player.getMaxHP()).append(" MP: ").append(player.getCurrentMP()).append("/").append(player.getMaxMP());
		if (player.getTarget() != null && player.getTarget().isDead()) {
			sb.append("  ").append(player.getTarget().getMobName()).append(":").append("HP: ").append(player.getTarget().getCurrentHP()).append("/").append(player.getTarget().getMaxHP()).append(" MP: ").append(player.getTarget().getCurrentMP()).append("/").append(player.getTarget().getMaxMP());
		}

		player.sendMessage(sb.toString());
	}


	private static void lookMob(Player player, Mob mob) {
		StringBuilder sb = new StringBuilder();
		sb.append(Ansi.BOLD).append(mob.getMobName()).append(Ansi.RESET).append("\n");
		sb.append(mob.getLongDescription()).append("\n");

		// Equipment
		Map<EquipSlot, ObjectItem> equipment = mob.getEquipment();
		boolean anyEquipped = equipment.values().stream().anyMatch(Objects::nonNull);
		if (anyEquipped) {
			sb.append("Equipped:\n");
			for (Map.Entry<EquipSlot, ObjectItem> entry : equipment.entrySet()) {
				if (entry.getValue() != null) {
					sb.append("  - ").append(entry.getKey().name().toLowerCase()).append(": ")
					.append(entry.getValue().getName()).append("\n");
				}
			}
		}

		// Inventory
		List<ObjectItem> inventoryItems = mob.getInventory();
		if (!inventoryItems.isEmpty()) {
			sb.append("Carrying:\n");
			for (ObjectItem item : inventoryItems) {
				sb.append("  - ").append(item.getName()).append("\n");
			}
		}

		player.sendMessage(sb.toString());
	} // end lookMob

	private static void lookObject(Player player, ObjectItem item) {
		StringBuilder sb = new StringBuilder();
		String reset = Ansi.RESET;

		// Icon based on ObjectType
		String icon = switch (item.getType()) {
		case WEAPON -> "⚔️";
		case ARMOR -> "🛡️";
		case CONTAINER -> "📦";
		case POTION -> "🧪";
		case FOOD -> "🍗";
		case DRINK -> "🥤";
		case SCROLL -> "📜";
		case WAND -> "✨";
		case STAFF -> "🔮";
		case TREASURE -> "💰";
		case COIN -> "🪙";
		case LIGHTSOURCE -> "🕯️";
		case KEY -> "🗝️";
		case SIGN -> "📋";
		case TRASH -> "🗑️";
		case CONTROLLER -> "🎛️";
		case PART -> "⚙️";
		case NONE -> "📎";
		default -> "📎";
		};

		sb.append(Ansi.BOLD).append(icon).append(" ").append(item.getName()).append(reset).append("\n");

		// Short/Long/Extended descriptions
		sb.append(item.getExtDescription()).append("\n");

		// Optional info
		if (item.isStackable()) {
			sb.append("Stack: ").append(item.getStackCount());
			if (item.getMaxStackSize() > 0)
				sb.append(" / ").append(item.getMaxStackSize());
			sb.append("\n");
		}

		if (item.getDurability() > 0) {
			sb.append("Durability: ").append(item.getDurability()).append("\n");
		}

		if (item.getMaxCharges() > 0) {
			sb.append("Charges: ").append(item.getCharges()).append(" / ").append(item.getMaxCharges()).append("\n");
		}

		// Bonus stats (if any)
		List<String> bonuses = new ArrayList<>();
		if (item.getStrengthBonus() != 0) bonuses.add("Str +" + item.getStrengthBonus());
		if (item.getStaminaBonus() != 0) bonuses.add("Sta +" + item.getStaminaBonus());
		if (item.getAgilityBonus() != 0) bonuses.add("Agi +" + item.getAgilityBonus());
		if (item.getIntellectBonus() != 0) bonuses.add("Int +" + item.getIntellectBonus());
		if (item.getHpBonus() > 0) bonuses.add("HP +" + item.getHpBonus());
		if (item.getMpBonus() > 0) bonuses.add("MP +" + item.getMpBonus());
		if (item.getHitrollBonus() != 0) bonuses.add("Hit +" + item.getHitrollBonus());
		if (item.getDamrollBonus() != 0) bonuses.add("Dam +" + item.getDamrollBonus());

		if (!bonuses.isEmpty()) {
			sb.append("Bonuses: ").append(String.join(", ", bonuses)).append("\n");
		}

		// Weapon info
		if (item.isWeapon()) {
			sb.append("Damage: ").append(item.getDiceCount()).append("d").append(item.getDiceSides());
			if (item.getDamageType() != null)
				sb.append(" ").append(item.getDamageType().name().toLowerCase());
			if (item.getWeaponType() != null)
				sb.append(" (").append(item.getWeaponType().name().toLowerCase()).append(")");
			sb.append("\n");
		}

		// Armor info
		if (item.isArmor()) {
			sb.append("Armor Type: ").append(item.getArmorType().name().toLowerCase()).append("\n");
		}

		player.sendMessage(sb.toString());
	} // end lookObject



	private static boolean matchesKeyword(HasKeywords entity, String keyword) {
		if (keyword == null) return false;
		for (String key : entity.getKeywords()) {
			if (key != null && key.equalsIgnoreCase(keyword)) {
				return true;
			}
		}
		return false;
	}

	public static void handleOpen(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Open what?");
			return;
		}

		// Parse direction or target from args, supporting inputs like:
		// "open east", "open door east", "open the east door"
		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Open what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try to interpret target as a direction for door
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is locked.");
					return;
				}
				if (!door.isClosed()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already open.");
					return;
				}
				door.setClosed(false);
				player.sendMessage("You open the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " opens the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}

		// Search for container in room or inventory by keywords
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to open.");
			return;
		}
		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is locked.");
			return;
		}
		if (!container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already open.");
			return;
		}

		container.setClosed(false);
		player.sendMessage("You open the " + container.getName() + ".");
	}

	public static void handleClose(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Close what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Close what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try door first
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (door.isClosed()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already closed.");
					return;
				}
				door.setClosed(true);
				player.sendMessage("You close the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " closes the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}

		// Search container in room or inventory
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to close.");
			return;
		}
		if (container.isClosed()) {
			player.sendMessage("The " + container.getName() + " is already closed.");
			return;
		}

		container.setClosed(true);
		player.sendMessage("You close the " + container.getName() + ".");
	}

	public static void handleUnlock(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Unlock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Unlock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try door first
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (!door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is not locked.");
					return;
				}
				door.setLocked(false);
				player.sendMessage("You unlock the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " unlocks the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}

		// Search container in room or inventory
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to unlock.");
			return;
		}
		if (!container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is not locked.");
			return;
		}

		container.setLocked(false);
		player.sendMessage("You unlock the " + container.getName() + ".");
	}

	public static void handleLock(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage("Lock what?");
			return;
		}

		String target = parseDirectionOrTarget(args);
		if (target == null) {
			player.sendMessage("Lock what?");
			return;
		}

		Room currentRoom = player.getCurrentRoom();

		// Try door first
		for (Direction dir : Direction.values()) {
			if (dir.name().equalsIgnoreCase(target)) {
				Door door = currentRoom.getDoor(dir);
				if (door == null) {
					player.sendMessage("There is no door to the " + dir.name().toLowerCase() + ".");
					return;
				}
				if (door.isLocked()) {
					player.sendMessage("The " + dir.name().toLowerCase() + " door is already locked.");
					return;
				}
				door.setLocked(true);
				player.sendMessage("You lock the " + dir.name().toLowerCase() + " door.");
				currentRoom.broadcast(player.getName() + " locks the " + dir.name().toLowerCase() + " door.", player);
				return;
			}
		}

		// Search container in room or inventory
		ObjectItem container = null;
		for (ObjectItem obj : currentRoom.getObjects()) {
			if (obj.isContainer() && matchesKeyword(obj, target)) {
				container = obj;
				break;
			}
		}
		if (container == null) {
			for (ObjectItem obj : player.getInventory()) {
				if (obj.isContainer() && matchesKeyword(obj, target)) {
					container = obj;
					break;
				}
			}
		}

		if (container == null) {
			player.sendMessage("You don't see any '" + target + "' to lock.");
			return;
		}
		if (container.isLocked()) {
			player.sendMessage("The " + container.getName() + " is already locked.");
			return;
		}

		container.setLocked(true);
		player.sendMessage("You lock the " + container.getName() + ".");
	} // end handleClose



	// Include this helper method as before
	private static String parseDirectionOrTarget(String[] args) {
		String joined = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		joined = joined.replaceAll("\\bdoor\\b", "")
				.replaceAll("\\bthe\\b", "")
				.trim();
		if (joined.isEmpty()) return null;
		String[] parts = joined.split("\\s+");
		return parts[0];
	}

	public static String handleUnequip(Player player, String itemNameOrSlot) {
		// TODO might need update
		if (itemNameOrSlot == null || itemNameOrSlot.trim().isEmpty()) {
			return "Unequip what?";
		}

		String input = itemNameOrSlot.trim().toLowerCase();

		// Try parsing as a slot first
		EquipSlot slot = EquipSlot.fromString(input);
		ObjectItem unequipped = null;

		if (slot != null) {
			unequipped = player.getEquipment().get(slot);
		} else {
			// Try matching by item name if no valid slot
			for (Map.Entry<EquipSlot, ObjectItem> entry : player.getEquipment().entrySet()) {
				ObjectItem item = entry.getValue();
				if (item != null && item.getName().equalsIgnoreCase(input)) {
					slot = entry.getKey();
					unequipped = item;
					break;
				}
			}
		}

		if (unequipped == null || slot == null) {
			return "You are not wearing or wielding that.";
		}

		// Remove from equipped slot
		player.getEquipment().put(slot, null);

		// Add to inventory
		player.getInventory().add(unequipped);

		return "You unequip the " + unequipped.getName() + " from your " + slot.name().toLowerCase() + ".";
	} // end handleUnequip

	public static String handleTitle(Player player, String newTitle) {
		if (newTitle == null || newTitle.isBlank()) {
			return "Usage: title <your title>";
		}

		// Optional: minimum privilege level to set custom titles
		if (player.getPrivilegeLevel() < 1) {
			return "You do not have permission to set a custom title.";
		}

		if (newTitle.length() > 40) {
			return "Title too long (max 40 characters).";
		}

		// Basic sanitization (strip control characters)
		newTitle = newTitle.replaceAll("[^a-zA-Z0-9 .,'\\-]", "").trim();

		player.setPlayerTitle(newTitle);
		return "Your title has been set to: \"" + newTitle + "\"";
	} // end handleTitle


	private static void handleList(Player player, String[] tokens) {
		if (tokens.length < 2) {
			player.sendMessage("List what? Options: player, world, zone, room, mob, object, spell");
			return;
		}

		String category = tokens[1].toLowerCase();

		switch (category) {
		case "player" :
		case "players" : {
			player.sendMessage("🧍 Players Online:");
			for (Player p : WorldManager.getActivePlayers()) {
				player.sendMessage(" - " + p.getName() + " (Level " + p.getLevel() + ")");
			}
			break;
		}

		case "world" :
		case "worlds" : {
			player.sendMessage("🌍 Worlds:");
			for (var world : WorldManager.getAllWorlds()) {
				player.sendMessage(" - " + world.getWorldId() + " (Name: " + world.getName() + ")");
			}
			break;
		}

		case "zone" :
		case "zones" : {
			if (player.getCurrentWorld() == null) {
				player.sendMessage("You are not in a world.");
				return;
			}

			player.sendMessage("🌐 Zones in world '" + player.getCurrentWorld().getWorldId() + "':");
			for (var zone : player.getCurrentWorld().getZones()) {
				player.sendMessage(" - Zone " + zone.getZoneId() + ": " + zone.getName());
			}
			break;
		}

		case "room" :
		case "rooms" : {
			if (player.getCurrentZone() == null) {
				player.sendMessage("You are not in a zone.");
				return;
			}

			player.sendMessage("🏠 Rooms in zone '" + player.getCurrentZone().getZoneId() + "':");
			for (Room room : player.getCurrentZone().getRooms().values()) {
				player.sendMessage(" - Room " + room.getId() + ": " + room.getName());
			}			
			break;
		}
		
		case "mob" :
		case "mobs" : {
			File dir = new File(Config.MOBS_DIR);
			if (!dir.exists() || !dir.isDirectory()) {
				player.sendMessage("No mobs directory found.");
				return;
			}

			File[] files = dir.listFiles((d, name) -> name.endsWith(".mob.txt"));
			if (files == null || files.length == 0) {
				player.sendMessage("No mobs have been created yet.");
				return;
			}

			player.sendMessage("📜 Saved Mobs:");
			for (File file : files) {
				String mobId = file.getName().replace(".mob.txt", "");
				try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
					String name = "Unknown";
					String level = "?";
					String line;

					while ((line = reader.readLine()) != null) {
						if (line.startsWith("MobName:")) {
							name = line.substring(8).trim();
						} else if (line.startsWith("Level:")) {
							level = line.substring(6).trim();
						}

						if (!name.equals("Unknown") && !level.equals("?")) break;
					}

					player.sendMessage(" - " + name + " (Level " + level + ") [ID: " + mobId + "]");

				} catch (IOException e) {
					player.sendMessage("⚠️ Error reading mob file: " + file.getName());
				}
			}
			break;
		}

		case "spell" :
		case "spells": {
			player.sendMessage(SpellManager.listSpells());
			break;
		}

		case "object" :
		case "objets" : {
			if (player.getCurrentZone() == null) {
				player.sendMessage("You are not in a zone.");
				return;
			}

			player.sendMessage("📦 Objects in zone '" + player.getCurrentZone().getZoneId() + "':");
			for (var obj : player.getCurrentZone().getAllObjects()) {
				player.sendMessage(" - " + obj.getShortDescription());
			}
			break;
		}

		default : {
			player.sendMessage("Unknown list category: " + category);
		}
		
		}
	} // end handleList


	public static String handleParty(Player player, String[] args) {
	    // The first arg should be the subcommand, not the literal "party"
	    if (args.length == 0) {
	        Party party = player.getParty();
	        if (party == null) return "You're not in a party.";
	        StringBuilder sb = new StringBuilder("Your party members:\n");
	        for (Player member : party.getMembers()) {
	            if (party.getLeader().equals(member)) {
	                sb.append(" * ").append(member.getDisplayName()).append(" (Leader)\n");
	            } else {
	                sb.append(" - ").append(member.getDisplayName()).append("\n");
	            }
	        }
	        return sb.toString();
	    }

	    // FIX: skip the literal "party" command name if present
	    int subIndex = 0;
	    if (args[0].equalsIgnoreCase("party")) {
	        if (args.length == 1) {
	            // just "party" => show members
	            return handleParty(player, new String[]{});
	        }
	        subIndex = 1; // shift index to get real subcommand
	    }

	    String sub = args[subIndex].toLowerCase();

	    switch (sub) {
	        case "invite" -> {
	            if (args.length <= subIndex + 1) return "Usage: party invite <player>";

	            if (player.getParty() != null && !player.getParty().isLeader(player)) {
	                return "Only the party leader can invite.";
	            }

	            String targetName = args[subIndex + 1];
	            Player target = WorldManager.getPlayer(targetName);
	            if (target == null) return "That player is not online.";

	            if (target.getParty() != null) return target.getName() + " is already in a party.";

	            if (player.getParty() == null) {
	                Party newParty = new Party(player);
	                player.setParty(newParty);
	            }

	            player.getParty().addMember(target);
	            player.sendMessage("You invite " + target.getName() + " to your party.");
	            target.sendMessage(player.getName() + " has invited you to join their party.");
	            return null;
	        }

	        case "kick" -> {
	            if (args.length <= subIndex + 1) return "Usage: party kick <player>";

	            if (player.getParty() == null || !player.getParty().isLeader(player)) {
	                return "Only the party leader can kick members.";
	            }

	            String targetName = args[subIndex + 1];
	            Player target = WorldManager.getPlayer(targetName);
	            if (target == null || !player.getParty().isMember(target)) {
	                return "That player is not in your party.";
	            }

	            player.getParty().removeMember(target);
	            player.sendMessage("You kicked " + target.getName() + " from the party.");
	            target.sendMessage("You have been kicked from the party.");
	            return null;
	        }

	        case "leave" -> {
	            if (player.getParty() == null) return "You're not in a party.";
	            player.getParty().removeMember(player);
	            player.sendMessage("You leave the party.");
	            return null;
	        }
	        
	        case "list" -> {
	            if (player.getParty() == null) return "You're not in a party.";
	            player.sendMessage("" + player.getParty().listMembers());
	            return null;
	        }

	        default -> {
	            return "Unknown party command. Try: party, party invite <name>, party kick <name>, party leave";
	        }
	    }
	} // end handleParty
	
	
	public static String handleConsider(Player player, Mob target) {
		if (target == null) return "Consider what?";

		StringBuilder sb = new StringBuilder();
		String reset = Ansi.RESET;

		if (player.hasEffect("blind")) {
			return Ansi.BOLD + "You consider " + target.getMobName() + "..." + reset + "\n"
					+ "But you can't see a thing!\n";
		}

		int playerLevel = player.getLevel();
		int mobLevel = target.getLevel();
		int levelDiff = Math.abs(playerLevel - mobLevel);

		boolean showStats = levelDiff <= 4;
		boolean maskStats = levelDiff <= 9;
		boolean maskIdentity = levelDiff >= 10;

		// ╔══════════════════════════════════════╗
		sb.append(Ansi.BOLD)
		.append("╔══════════════════════════════════════╗\n")
		.append("║         Consider: ").append(target.getMobName()).append("         ║\n")
		.append("╠══════════════════════════════════════╣\n")
		.append(reset);

		// Level and EXP
		sb.append("║ Level: ").append(maskIdentity ? "???" : mobLevel);
		if (!maskIdentity) {
			sb.append(mobLevel > playerLevel ? " (Stronger)" :
				mobLevel < playerLevel ? " (Weaker)" : " (Evenly matched)");
			sb.append("    EXP Reward: ").append(target.getExpValue());
		} else {
			sb.append("    EXP Reward: ???");
		}
		sb.append("\n");

		// Effects
		List<String> effectStrings = target.getActiveEffects().stream()
				.map(e -> switch (e.getName().toLowerCase()) {
				case "bleeding" -> Ansi.RED + "[BLEEDING]" + reset;
				case "shielded" -> Ansi.CYAN + "[SHIELDED]" + reset;
				case "burning" -> Ansi.MAGENTA + "[BURNING]" + reset;
				default -> "[" + e.getName().toUpperCase() + "]";
				}).toList();

		if (!effectStrings.isEmpty()) {
			sb.append("║ Effects: ").append(String.join(" ", effectStrings)).append("\n");
		}

		// Identity
		sb.append("╠═════════ Identity ═══════════════════╣\n");
		if (!maskIdentity) {
			sb.append("Race: ").append(target.getRace());
			String subrace = target.getSubrace();
			if (subrace != null && !subrace.isBlank() && !subrace.equalsIgnoreCase("none")) {
				sb.append(" — Subrace: ").append(subrace);
			}
			sb.append("\n");
		} else {
			sb.append("Race: ???\n");
		}

		String profession = (!maskStats && target.getProfession() != null)
				? target.getProfession().toString() : "???";
		String tier = (!maskStats && target.getRank() != null)
				? target.getRank().name().replace('_', ' ') : "???";

		sb.append("Profession: ").append(profession).append(" — Tier: ").append(tier).append("\n");

		// Stats
		sb.append("╠═════════ Stats ══════════════════════╣\n");
		if (showStats) {
			sb.append("Stats: Str ").append(target.getStrength())
			.append(", Sta ").append(target.getStamina())
			.append(", Int ").append(target.getIntellect())
			.append(", Agi ").append(target.getAgility()).append("\n");
		} else if (maskStats) {
			sb.append("Stats: Str ???, Sta ???, Int ???, Agi ???\n");
		} else {
			sb.append("Stats: Str ????, Sta ????, Int ????, Agi ????\n");
		}

		sb.append("╚══════════════════════════════════════╝\n\n");

		// Danger assessment
		sb.append(switch (levelDiff) {
		case 0 -> "You and " + target.getMobName() + " are evenly matched.\n";
		case 1, 2, 3 -> mobLevel < playerLevel
		? "You feel confident against " + target.getMobName() + ".\n"
				: target.getMobName() + " might be a fair fight.\n";
		case 4, 5, 6 -> target.getMobName() + " seems stronger than you.\n";
		case 7, 8, 9 -> "You sense danger from " + target.getMobName() + "...\n";
		default -> "⚠️ " + target.getMobName() + " is beyond your reckoning. Flee or perish.\n";
		});

		// Extended Description
		sb.append("\n").append(target.getExtendedDescription());

		return sb.toString();
	} // end handleConsider


	public static String formatMobRank(MobRank rank) {
		String name = rank.name().toLowerCase().replace('_', ' ');
		return Character.toUpperCase(name.charAt(0)) + name.substring(1);
	}

	private static String handleKick(Player admin, String[] args) {
		if (args.length < 2) return "Usage: kick <player>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		if (target == admin) return "You can't kick yourself.";
		target.sendMessage("You have been kicked by an admin.");
		target.getClientHandler().disconnect();
		return "Player " + target.getName() + " has been kicked.";
	}
	private static String handleSummon(Player admin, String[] args) {
		if (args.length < 2) return "Usage: summon <player>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		Room dest = admin.getCurrentRoom();
		target.getCurrentRoom().removeMob(target);
		dest.addMob(target);
		target.setCurrentRoom(dest);
		target.sendMessage("You have been summoned by an admin.");
		return "Player " + target.getName() + " summoned to your location.";
	}

	// Updated handleGoto to ensure correct player movement
	// Fix for handleGoto: Ensures admin is placed in correct room
	private static String handleGoto(Player admin, String[] args) {
	    if (args.length < 2) {
	        return "Usage: goto <worldId|worldName> <zoneId> <roomId> | <mob/player name>";
	    }

	    if (args.length >= 4) {
	        String worldIdOrName = args[1];
	        int zoneId, roomId;

	        try {
	            zoneId = Integer.parseInt(args[2]);
	            roomId = Integer.parseInt(args[3]);
	        } catch (NumberFormatException e) {
	            return "Zone ID and Room ID must be numbers.";
	        }

	        World targetWorld;
	        try {
	            int worldId = Integer.parseInt(worldIdOrName);
	            targetWorld = WorldManager.getWorld(worldId);
	        } catch (NumberFormatException e) {
	            targetWorld = WorldManager.getWorldByName(worldIdOrName);
	        }

	        if (targetWorld == null) return "World '" + worldIdOrName + "' not found.";

	        Zone targetZone = targetWorld.getZone(zoneId);
	        if (targetZone == null) return "Zone " + zoneId + " not found in world " + targetWorld.getName();

	        Room targetRoom = targetZone.getRoom(roomId);
	        if (targetRoom == null) return "Room " + roomId + " not found in Zone " + zoneId;

	        // Ensure clean move
	        Room currentRoom = admin.getCurrentRoom();
	        if (currentRoom != null) {
	            currentRoom.removeMob(admin);
	        }

	        // Double-check that the target room is the correct one
	        System.out.println("[DEBUG] Attempting teleport to: World " + targetWorld.getWorldId() + ", Zone " + zoneId + ", Room " + roomId);
	        System.out.println("[DEBUG] Resolved target room: " + targetRoom.getId() + " in Zone " + targetRoom.getZone().getZoneId() + ", World: " + targetRoom.getZone().getWorld().getWorldId());

	        // Update all location fields properly
	        admin.setCurrentWorld(targetWorld);
	        admin.setCurrentZone(targetZone);
	        admin.setCurrentRoom(targetRoom);
	        admin.setRoom(targetRoom);  // <- Ensure setRoom also affects logical location
	        targetRoom.addMob(admin);

	        targetRoom.broadcastExcept(admin.getName() + " suddenly appears in a flash of light!", admin);
	        CommandProcessor.handleLook(admin, new String[]{"look"});

	        return "You teleport to World " + targetWorld.getName() + ", Zone " + zoneId + ", Room " + roomId + ": " + targetRoom.getName();
	    }

	    // Fallback to mob/player name lookup
	    World world = admin.getCurrentWorld();
	    if (world == null) return "You are not in a world.";

	    String targetName = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();

	    for (Zone z : world.getZones()) {
	        for (Room r : z.getRooms().values()) {
	            for (Mob m : r.getMobs()) {
	                if (m.getMobName().equalsIgnoreCase(targetName) || m.matchesKeyword(targetName)) {
	                    Room cur = admin.getCurrentRoom();
	                    if (cur != null) cur.removeMob(admin);
	                    admin.setCurrentWorld(world);
	                    admin.setCurrentZone(z);
	                    admin.setCurrentRoom(r);
	                    admin.setRoom(r);
	                    r.addMob(admin);
	                    r.broadcastExcept(admin.getName() + " suddenly appears in a flash of light!", admin);
	                    CommandProcessor.handleLook(admin, new String[]{"look"});
	                    return "You teleport to " + m.getMobName() + "'s location in Zone " + z.getZoneId() + ", Room " + r.getId();
	                }
	            }
	        }
	    }

	    return "Target '" + targetName + "' not found.";
	} // end







	private static String handleSetLevel(Player admin, String[] args) {
		if (args.length < 3) return "Usage: setlevel <player> <level>";
		Player target = WorldManager.getPlayerByName(args[1]);
		if (target == null) return "No such player.";
		try {
			int level = Integer.parseInt(args[2]);
			if (level < 1 || level > 100) return "Level must be 1–100.";
			target.setLevel(level);
			return target.getName() + " is now level " + level + ".";
		} catch (NumberFormatException e) {
			return "Invalid level.";
		}
	}

	private static String handleCreate(Player player, String[] args) {
		if (args.length < 2) {
			return "Usage: create <world|zone|room|mob|player|object|spell|script> [name|id]";
		}

		String target = args[1].toLowerCase();
		String nameArg = (args.length >= 3) ? args[2] : null;

		switch (target) {
		case "world":
			if (nameArg == null) return "Usage: create world <name>";
			return handleCreateWorld(player, nameArg, worldManager);
			
		case "zone":
			if (nameArg == null) return "Usage: create zone <zoneId>";
			try {
				int zoneId = Integer.parseInt(nameArg);
				return handleCreateZone(player, zoneId);  // Create or edit zone + script
			} catch (NumberFormatException e) {
				return "Zone ID must be a number: " + nameArg;
			}

		case "room":
			if (nameArg == null) return "Usage: create room <roomId>";
			try {
				int roomId = Integer.parseInt(nameArg);
				return handleCreateRoom(player, roomId);
			} catch (NumberFormatException e) {
				return "Room ID must be a number: " + nameArg;
			}

		case "mob":
		case "player":
			if (nameArg == null) return "Usage: create " + target + " <name>";
			return handleCreateMob(player, nameArg); // You can later split mob/player handling if needed

		case "object":
			if (nameArg == null) return "Usage: create object <name>";
			return handleCreateObject(player, nameArg);

		case "spell":
			return "Spell creation is not implemented yet.";

		case "script":
		case "zonescript":
			return handleCreateZoneScript(player);

		default:
			return "Unknown create target: " + target;
		}
	} // end handleCreate


	@SuppressWarnings("static-access")
	private static String handleCreateWorld(Player player, String name, WorldManager worldManager) {
		if (name == null || name.isBlank()) {
			return "Please provide a world name. Usage: create world <name>";
		}

		name = name.toLowerCase(); // normalize world ID

		if (worldManager.worldExists(name)) {
			World existing = worldManager.getWorld(name);
			WorldEditor editor = new WorldEditor(existing, player, true);
			player.setEditor(editor);
			return "Editing existing world: " + existing.getName();
		} else {
			GameClock clock = new GameClock(WorldManager.GLOBAL_CALENDAR); // or however you create clocks
			World newWorld = new World(name, capitalize(name), clock);
			WorldEditor editor = new WorldEditor(newWorld, player, false);

			worldManager.addWorld(newWorld);
			player.setEditor(editor);
			return "Created and editing new world: " + newWorld.getName();
		}
	} // end handleCreateWorld


	private static String handleCreateZone(Player player, int newZoneNum) {
		World world = player.getCurrentWorld();
		if (world == null) return "You must be in a world to create a zone.";

		Zone zone = world.getZone(newZoneNum);
		if (zone != null) {
			ZoneEditor editor = new ZoneEditor(zone, player);
			player.setEditor(editor);
			editor.startEditing();
			return "Editing existing zone: " + newZoneNum;
		} else {
			Zone newZone = new Zone();
			newZone.setZoneId(newZoneNum);
			newZone.setWorld(world);
			newZone.setParentWorld(world);

			Room newRoom = new Room();
			newRoom.setId(0);
			newRoom.setZone(newZone);
			newZone.addRoom(0, newRoom); // Fixed from 1 -> 0 for default room

			// Add the new zone to the world
			world.addZone(newZoneNum, newZone);

			// Save the updated world
			if (WorldManager.saveWorld(world)) {
				player.sendMessage("✅ World updated and saved with new zone " + newZoneNum);
			} else {
				player.sendMessage("⚠️ Failed to save world after adding zone " + newZoneNum);
			}

			// Attempt to attach a ZoneScript if available
			String className = Config.SCRIPT_DIR + ".Zone" + newZoneNum + "ZoneScript";
			try {
				Class<?> clazz = Class.forName(className);
				Object scriptInstance = clazz.getDeclaredConstructor().newInstance();

				if (scriptInstance instanceof ZoneScript) {
					newZone.setZoneScript((ZoneScript) scriptInstance);
					System.out.println("✅ ZoneScript " + className + " applied to zone " + newZoneNum);
				} else {
					System.err.println("⚠️ " + className + " does not implement ZoneScript.");
				}
			} catch (ClassNotFoundException e) {
				System.err.println("⚠️ ZoneScript class not found: " + className);
			} catch (Exception e) {
				System.err.println("❌ Failed to instantiate ZoneScript: " + e.getMessage());
				e.printStackTrace();
			}

			ZoneEditor editor = new ZoneEditor(newZone, player);
			player.setEditor(editor);
			editor.startEditing();

			return "Created and editing new zone: " + newZoneNum;
		}
	} // end





	private static String handleCreateRoom(Player player, int newRoomNum) {
		Zone zone = player.getCurrentZone();
		if (zone == null) return "You must be in a zone to create a room.";
		Zone currentZone = player.getCurrentZone();
		Room newRoom = new Room();
		newRoom.setId(newRoomNum);
		newRoom.setZone(currentZone); 
		currentZone.addRoom(1, newRoom);
		return "";
	} // end handleCreateRoom

	private static String handleCreateMob(Player player, String name) {
		Mob mob = new Mob();
		if (name != null) mob.setMobName(name);

		player.setEditor(new MobEditor(mob,player));
		return "Created and editing new mob: " + mob.getMobName();
	} // end handleCreateMob

	private static String handleCreateObject(Player player, String name) {
		ObjectItem obj = new ObjectItem();
		if (name != null) obj.setName(name);

		player.setEditor(new ObjectEditor(obj));
		return "Created and editing new object: " + obj.getName();
	} // end handleCreateObject

	private static String handleCreateZoneScript(Player player) {
		Zone zone = player.getCurrentZone();
		if (zone == null) return "You must be in a zone to edit its script.";

		ZoneScript script = zone.getOrCreateScript(); // helper
		player.setEditor(new ZoneScriptEditor(player, script));

		handleEditScript(player);
		return "Editing zone script for zone: " + zone.getName();

	} // end handleCreateZoneScript

	private static String handleCSave(Player player, String[] args) throws Exception {
		Editor editor = player.getEditor();
		if (editor == null) {
			return "You are not currently editing anything.";
		}

		boolean success = editor.save();
		if (success) {
			return editor.getEditorName() + " saved successfully.";
		} else {
			return "Failed to save " + editor.getEditorName() + ".";
		}
	}

	private static String capitalize(String s) {
		if (s == null || s.isEmpty()) return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}

	private static String handleEdit(Player player, String[] tokens) {
		if (tokens.length < 2) {
			return "Usage: edit <world|zone|room|obj|mob|script> [args...]";
		}

		String subcommand = tokens[1].toLowerCase();

		switch (subcommand) {
		case "world": {
			World world = player.getCurrentWorld();
			if (world == null) return "You are not in a world.";
			WorldEditor worldEditor = new WorldEditor(world, player, false);
			player.setEditor(worldEditor);
			return handleEditWorld(player, tokens);
		}
		case "zone": {
			Zone zone = player.getCurrentZone();
			if (zone == null) return "You are not in a zone.";
			ZoneEditor zoneEditor = new ZoneEditor(zone, player);
			player.setEditor(zoneEditor);
			return handleEditZone(player, tokens);
		}
		case "room": {
			Room room = player.getCurrentRoom();
			if (room == null) return "You are not in a room.";
			RoomEditor roomEditor = new RoomEditor(room, player);
			player.setEditor(roomEditor);
			return handleEditRoom(player);
		}
		case "obj":
		case "object": {
			return handleEditObject(player, tokens);
		}
		case "mob": {
			return handleEditMob(player, tokens);
		}
		case "player": {	        	
			handleEditPlayer(player,tokens);
		}
		case "script": {
			   handleEditScript(player, tokens);
		}
		default:
			return "Unknown edit target: " + subcommand;
		}
	}


	private static String handleEditWorld(Player player, String[] tokens) {
		String worldId = tokens.length >= 3 ? tokens[2] : Config.DEFAULT_WORLD_ID;
		World world = WorldManager.getWorld(worldId);
		if (world == null) {
			return "World '" + worldId + "' not found.";
		}

		WorldEditor editor = new WorldEditor(world, player, true);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing existing world: " + world.getName();
	}

	private static String handleEditZone(Player player, String[] tokens) {
		World world = player.getCurrentWorld();
		if (world == null) {
			return "You must be in a world to edit a zone.";
		}

		int zoneId;


		// Case: edit zone <zoneId>
		try {
			zoneId = Integer.parseInt(tokens[2]);
		} catch (NumberFormatException e) {
			return "Invalid zone number: " + tokens[2];
		}

		Zone zone = world.getZone(zoneId);
		if (zone == null) {
			return "Zone #" + zoneId + " does not exist in world '" + world.getWorldId() + "'.";
		}


		return "Editing zone #" + zoneId + " in world '" + world.getWorldId() + "'.";
	}

	private static String handleEditRoom(Player player) {
		Room currentRoom = player.getCurrentRoom();
		if (currentRoom == null) {
			return "You must be in a room to edit it.";
		}
		RoomEditor editor = new RoomEditor(currentRoom, player);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing current room: " + currentRoom.getName();
	} // end handleEditRoom

	private static ObjectItem findContainerInRoomOrInventory(Room room, List<ObjectItem> inventory, String keyword) {
		for (ObjectItem obj : room.getObjects()) {
			if (obj.isContainer() && matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		for (ObjectItem obj : inventory) {
			if (obj.isContainer() && matchesKeyword(obj, keyword)) {
				return obj;
			}
		}
		return null;
	}

	private static String handleEditObject(Player player, String[] tokens) {
		ObjectItem targetObj = null;

		if (tokens.length < 3) {
			player.sendMessage("Please enter the object ID number to edit:");
			// Set player editor state to expect object ID input, if you have such a system
			// For example: player.setPendingInputState(InputState.OBJECT_ID_INPUT);
			return null; // Waiting for input
		}

		try {
			int objId = Integer.parseInt(tokens[2]);
			// Assume a global method to find object by ID, e.g.:
			targetObj = ObjectManager.getObjectById(objId);
			if (targetObj == null) {
				return "Object with ID " + objId + " not found.";
			}
		} catch (NumberFormatException e) {
			return "Invalid object ID.";
		}

		ObjectEditor editor = new ObjectEditor(targetObj);
		player.setEditor(editor);
		editor.startEditing();
		return "Editing object: " + targetObj.getName() + " (ID: " + targetObj.getObjID() + ")";
	} // end handleEditObject

	private static String handleEditPlayer(Player player, String[] tokens) {
		if (tokens.length < 3) {
			return "Usage: edit player <name>";
		}

		String targetName = tokens[2];
		Player target = PlayerLoader.load(targetName);
		if (target == null) {
			return "Player not found: " + targetName;
		}

		PlayerEditor editor = new PlayerEditor(target, player);
		player.setEditor(editor);
		editor.startEditing();
		return null;
	}


	private static String handleEditMob(Player player, String[] tokens) {

		Mob targetMob = null;

		if (tokens.length < 3) {
			player.sendMessage("Please enter the Mob ID number to edit:");
			return null; // Waiting for input
		}

		try {
			int mobId = Integer.parseInt(tokens[2]);

			// First, check if mob is already loaded (as a template)
			targetMob = MobManager.getMobById(mobId);

			// If not found, attempt to load from file
			if (targetMob == null) {
				targetMob = WorldManager.loadMob(String.valueOf(mobId));
				if (targetMob != null) {
					MobManager.registerMobTemplate(targetMob); // Add it to the template registry
				}
			}

			if (targetMob == null) {
				return "❌ Mob with ID " + mobId + " not found in memory or file.";
			}

		} catch (NumberFormatException e) {
			return "❌ Invalid Mob ID.";
		}

		MobEditor editor = new MobEditor(targetMob, player);
		player.setEditor(editor);
		editor.startEditing();
		return "🛠️ Editing mob: " + targetMob.getMobName() + " (ID: " + targetMob.getId() + ")";
	}


	public static void handleEditScript(Player player, String[] tokens) {
		if (tokens.length < 3) {
			player.sendMessage("Usage: edit script <zoneId>");
			return;
		}

		int zoneId;
		try {
			zoneId = Integer.parseInt(tokens[2]);
		} catch (NumberFormatException e) {
			player.sendMessage("Invalid zone ID.");
			return;
		}

		World world = player.getCurrentWorld();
		if (world == null) {
			player.sendMessage("You must be in a world to edit zone scripts.");
			return;
		}

		Zone zone = world.getZone(zoneId);
		if (zone == null) {
			player.sendMessage("Zone ID " + zoneId + " not found in world '" + world.getWorldId() + "'.");
			return;
		}

		ZoneScript script = zone.getScript();
		if (script == null) {
			player.sendMessage("⚠️ Zone " + zoneId + " has no script assigned.");
			return;
		}
		player.sendMessage("Editing script: " + zone.getScript().getZoneId());
		ZoneScriptEditor editor = new ZoneScriptEditor(player, script);
		player.setEditor(editor);
		editor.startEditing();  // will show menu
	}




	private static String handleEditScript(Player player) {
		World world = player.getCurrentWorld();
		Zone zone = player.getCurrentZone();
		if (world == null || zone == null) return "You're not in a valid zone to edit its script.";

		return handleEditScriptByZoneId(player, zone.getZoneId());
	}

	private static String handleEditScriptByZoneId(Player player, int zoneId) {
		World world = player.getCurrentWorld();
		if (world == null) return "You must be inside a world to edit a script.";

		Zone zone = world.getZone(zoneId);
		if (zone == null) return "Zone " + zoneId + " not found.";

		ZoneScript script = zone.getScript();
		if (script == null) return "Zone " + zoneId + " has no script assigned.";

		ZoneScriptEditor editor = new ZoneScriptEditor(player, script);
		player.setEditor(editor);
		editor.startEditing();

		return "Editing script for zone " + zoneId;
	}

	public static String handleLoad(Player player, String[] args) {
		if (args.length < 2) {
			return "Usage: load <object|mob|obj> <id>";
		}

		String type = args[0].toLowerCase();
		String idStr = args[1];

		int id;
		try {
			id = Integer.parseInt(idStr);
		} catch (NumberFormatException e) {
			return "Invalid ID. Please use a number.";
		}

		Room room = player.getCurrentRoom();

		switch (type) {
		case "object":
		case "obj": {
			ObjectItem obj = ObjectManager.getObjectById(id);
			if (obj == null) {
				return "❌ Object ID " + id + " not found.";
			}

			if (player.getInventory().size() >= player.getMaxInventorySize()) {
				return "❌ Inventory full. Could not load object.";
			}

			player.getInventory().add(obj);
			return "✅ Loaded object ID " + id + " into your inventory.";
		}

		case "mob": {
			Mob mob = MobManager.createMobById(id);

			// If not already registered, try loading from file
			if (mob == null) {
				mob = WorldManager.loadMob(String.valueOf(id));
				if (mob != null) {
					MobManager.registerMobTemplate(mob); // so it's available later
					mob = MobManager.createMobById(id);  // clone it fresh
				}
			}

			if (mob == null) {
				return "❌ Mob ID " + id + " not found (in memory or file).";
			}

			mob.setRoom(room);
			room.addMob(mob);
			mob.setCurrentRoom(room);
			return "✅ Loaded mob ID " + id + " into the room.";
		}

		default:
			return "❌ Unknown type: " + type + ". Use 'object', 'obj', or 'mob'.";
		}
	}

	public static String handleInventory(Player player) {
		if (player == null) {
			return "You are... nothing?";
		}

		List<ObjectItem> inventory = player.getInventory();

		if (inventory == null || inventory.isEmpty()) {
			return "You are carrying nothing.";
		}

		StringBuilder sb = new StringBuilder();
		sb.append("You are carrying:\n");

		int index = 1;
		for (ObjectItem item : inventory) {
			if (item != null) {
				sb.append(String.format("  %d. %s\n", index++, item.getShortDescription()));
			}
		}

		return sb.toString().trim();
	}

	public static String handleExamine(Player player, String[] args) {
		if (player == null || player.getCurrentRoom() == null || args.length < 2) {
			return "Examine what?";
		}

		String input = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		int index = 1;
		String keyword = input;

		// Parse "2.goblin" style input
		if (input.matches("^\\d+\\..+")) {
			String[] parts = input.split("\\.", 2);
			index = Integer.parseInt(parts[0]);
			keyword = parts[1].trim();
		}

		final int finalIndex = index;
		final String finalKeyword = keyword;
		Room room = player.getCurrentRoom();

		// Match mob by keyword or name
		List<Mob> mobMatches = room.getMobs().stream()
				.filter(m -> m.getMobName().equalsIgnoreCase(finalKeyword) || m.hasKeyword(finalKeyword))
				.collect(Collectors.toList());

		if (finalIndex <= mobMatches.size()) {
			return examineMob(player, mobMatches.get(finalIndex - 1));
		}

		// Match object by keyword or name
		List<ObjectItem> objMatches = room.getObjects().stream()
				.filter(o -> o.getName().equalsIgnoreCase(finalKeyword) || o.hasKeyword(finalKeyword))
				.collect(Collectors.toList());

		if (finalIndex <= objMatches.size()) {
			return examineObject(objMatches.get(finalIndex - 1));
		}

		return "You don't see that here.";
	}





	private static String examineMob(Player examiner, Mob target) {
		StringBuilder sb = new StringBuilder();

		int levelAdvantage = examiner.getLevel() - target.getLevel();

		sb.append("You examine ").append(target.getMobName()).append(" closely...\n");

		// Effects
		if (!target.getActiveEffects().isEmpty()) {
			sb.append("Effects: ");
			for (Effect e : target.getActiveEffects()) {
				sb.append(stylizeEffect(e)).append(" ");
			}
			sb.append("\n");
		}

		// Description
		sb.append(target.getLongDescription()).append("\n");
		sb.append(target.getExtendedDescription()).append("\n");

		// Stats
		sb.append("Stats:\n");
		if (levelAdvantage >= -5) {
			sb.append(String.format("  STR: %d  STA: %d  AGI: %d  INT: %d\n",
					target.getStrength(), target.getStamina(), target.getAgility(), target.getIntellect()));
		} else {
			sb.append("  STR: ??  STA: ??  AGI: ??  INT: ??\n");
		}

		if (levelAdvantage >= -10) {
			sb.append(String.format("  Race: %s  Subrace: %s  Profession %s  XP: %d\n",
					target.getRace(), target.getSubrace(), target.getProfession(), target.getExpValue()));
		} else {
			sb.append("  Race: ??  Profession: ??  XP: ???\n");
		}

		// Equipment
		sb.append("Wearing:\n");
		for (ObjectItem item : target.getEquipment().values()) {
			sb.append("  ").append(item.getShortDescription()).append("\n");
		}

		// Inventory
		sb.append("Inventory:\n");
		for (ObjectItem item : target.getInventory()) {
			sb.append("  ").append(item.getShortDescription()).append("\n");
		}

		return sb.toString();
	}


	private static String examineObject(ObjectItem obj) {
		StringBuilder sb = new StringBuilder();

		sb.append("You examine ").append(obj.getName()).append("...\n");

		// Stylized effects
		List<String> effects = new ArrayList<>();
		if (obj.hasEffect(ItemEffect.BLESSED)) effects.add("[\u001B[32mglows green\u001B[0m]");
		if (obj.hasEffect(ItemEffect.CURSED)) effects.add("[\u001B[31mglows red\u001B[0m]");
		if (obj.hasEffect(ItemEffect.MAGIC)) effects.add("[\u001B[34mglows blue\u001B[0m]");
		if (obj.hasEffect(ItemEffect.HUMMING)) effects.add("[\u001B[37mhums softly\u001B[0m]");
		if (obj.hasEffect(ItemEffect.VORPAL)) effects.add("[\u001B[37mshines with deadly light\u001B[0m]");
		if (obj.hasEffect(ItemEffect.POISONED) || obj.isPoisoned()) { effects.add("[\u001B[32mdrip of poison\u001B[0m]");
		if (obj.hasEffect(ItemEffect.BURNING)) effects.add("[\u001B[31mis engulfed in flames\u001B[0m]");

		if (!effects.isEmpty()) {
			sb.append("It ").append(String.join(", ", effects)).append(".\n");
		}

		// Description
		sb.append(obj.getExtDescription()).append("\n");

		// Stats
		sb.append("Stats:\n");
		sb.append("  Type: ").append(obj.getType()).append("\n");
		if (obj.getDamageBonus() != 0) sb.append("  Damage Bonus: ").append(obj.getDamageBonus()).append("\n");
		if (obj.getDefenseBonus() != 0) sb.append("  Defense Bonus: ").append(obj.getDefenseBonus()).append("\n");


		}
		return sb.toString();
	}

	private static String stylizeEffect(Effect e) {
		switch (e.getType()) {
		case "Blessed": return "\u001B[32mBlessed\u001B[0m";
		case "Cursed": return "\u001B[31mCursed\u001B[0m";
		case "Magic": return "\u001B[34mMagical\u001B[0m";
		default: return e.getType(); // fallback
		}
	}

	private static String handleHelp(Player player, String[] args) {
		if (args.length < 2) {
			return "Usage: help <topic>";
		}

		String query = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).toLowerCase();
		HelpEntry entry = HelpManager.getHelpEntry(query);

		if (entry == null) {
			return "No help found for: " + query;
		}

		return "**" + entry.getTitle() + "**\n" + entry.getBody();
	}
	private static String handleHindex(Player player, String[] args) {
		List<HelpEntry> entries = HelpManager.getAllEntries();

		if (entries.isEmpty()) {
			return "No help files available.";
		}

		StringBuilder sb = new StringBuilder();
		sb.append("Available Help Topics:\n");
		for (HelpEntry entry : entries) {
			sb.append("  - ").append(entry.getKeyword());
			if (entry.getTitle() != null && !entry.getTitle().equalsIgnoreCase(entry.getKeyword())) {
				sb.append(" (").append(entry.getTitle()).append(")");
			}
			sb.append("\n");
		}

		return sb.toString();
	}
	
	public static String handleCamp(Player player) {
	    if (player == null || player.getCurrentRoom() == null) {
	    	player.sendMessage("You are not in a valid location.");
	    }

	    Room room = player.getCurrentRoom();

	    // Check for CAMP flag
	    if (!room.getFlags().contains(RoomFlag.CAMP)) {
	    	player.sendMessage("You can't safely camp here.");
	    }

	    // Store camp location (optional)
	    player.setRentWorld(player.getCurrentWorld());
	    player.setRentZone(player.getCurrentZone());
	    player.setRentRoom(player.getCurrentRoom());

	    // Save player
	    PlayerLoader.save(player);

	    // Remove player from room/zone/world
	    room.removeMob(player);
	    player.setCurrentRoom(null);
	    player.setCurrentZone(null);
	    player.setCurrentWorld(null);

	    // Notify player and flag for logout
	    player.sendMessage("You set up camp and rest for the night. When you return, you'll wake here, safe and sound.");
	    player.setPendingLogout(true);

	    return null;
	} // end

	
	public static String handleRent(Player player) {
	    if (player == null || player.getCurrentRoom() == null) {
	        return "You are not in a valid location.";
	    }

	    Room room = player.getCurrentRoom();

	    // Check for RENT flag
	    if (!room.getFlags().contains(RoomFlag.RENT)) {
	        return "You can't rent a room here.";
	    }

	    // Check for INNKEEPER mob
	    boolean hasInnkeeper = room.getMobs().stream()
	        .anyMatch(mob -> mob.hasBehavior(MobBehaviorFlag.INNKEEPER));

	    if (!hasInnkeeper) {
	        return "There’s no one here to rent you a room.";
	    }

	    // ✅ Passed all checks; proceed to rent
	    player.setRentWorld(player.getCurrentWorld());
	    player.setRentZone(player.getCurrentZone());
	    player.setRentRoom(player.getCurrentRoom());

	    // Save player
	    PlayerLoader.save(player);

	    // Remove player from current room
	    room.removeMob(player);
	    player.setCurrentRoom(null);
	    player.setCurrentZone(null);
	    player.setCurrentWorld(null);

	    // Inform player
	    player.sendMessage("You rent a cozy room and fall asleep. When you return, you’ll wake here rested and safe.");

	    // Mark player for logout
	    player.setPendingLogout(true);

	    return null;
	} // end

	public static void handleTime(Player player) {
	    if (player == null) return;

	    World world = player.getCurrentWorld();
	    if (world == null) {
	        player.sendMessage("You are not currently in a world.");
	        return;
	    }

	    GameClock clock = world.getClock();
	    if (clock == null) {
	        player.sendMessage("World clock is unavailable.");
	        return;
	    }

	    long tick = clock.getCurrentTick();
	    int ticksPerDay = Config.ticksPerDay;
	    int ticksPerHour = ticksPerDay / 24;
	    int hour = (int)((tick % ticksPerDay) / ticksPerHour);


	    
	    player.sendMessage(""+ clock.getFormattedTime(world));
	} // end handleTime

    public static String handleTarget(Mob caster, String targetName) {
        if (caster == null || caster.getCurrentRoom() == null || targetName == null) {
            return null;
        }

        Room room = caster.getCurrentRoom();

        // Parse input like "2.goblin"
        int targetIndex = 1;
        String keyword = targetName.toLowerCase();

        if (targetName.contains(".")) {
            String[] parts = targetName.split("\\.", 2);
            try {
                targetIndex = Integer.parseInt(parts[0]);
                keyword = parts[1].toLowerCase();
            } catch (NumberFormatException e) {
                // fallback: treat whole string as keyword
                targetIndex = 1;
                keyword = targetName.toLowerCase();
            }
        }

        // Find matching mobs by keyword
        List<Mob> matchingMobs = room.findMobsByKeyword(keyword);
        if (matchingMobs == null || matchingMobs.size() < targetIndex) {
            if (caster instanceof Player player) {
                player.sendMessage("No such target.");
            }
            return null;
        }

        Mob target = matchingMobs.get(targetIndex - 1);
        if (target == caster) {
            if (caster instanceof Player player) {
                player.sendMessage("You cannot target yourself.");
             //   return "You cannot target yourself.";
            }
            return null;
        }

        caster.setTarget(target);
        if (caster instanceof Player player) {
            player.sendMessage("You target " + target.getMobName() + ".");
        }
        return null;
    } // end handTarget






	
} // end CommandProcessor
