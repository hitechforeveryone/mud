package mud.spell;

import mud.core.Mob;

public class DamageAbsorbSpell implements Spell {

    private static final int ABSORB_AMOUNT = 30; // total damage to absorb

    @Override
    public String getName() {
        return "damage_absorb";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to protect.");
            return false;
        }

        // Assume Mob has an absorbShield field or method to add absorb points
        if (target.addDamageAbsorb(ABSORB_AMOUNT)) {
            caster.sendMessage("You cast a protective shield on " + target.getMobName() + ", absorbing up to " + ABSORB_AMOUNT + " damage.");
            if (target != caster) {
                target.sendMessage(caster.getMobName() + " casts a shield on you, protecting you from damage.");
            }
            // Broadcast to others in the room except caster and target
            if (caster.getCurrentRoom() != null) {
                caster.getCurrentRoom().broadcastExcept(
                    caster.getMobName() + " casts a glowing shield around " + target.getMobName() + ".",
                    caster, target
                );
            }
            return true;
        } else {
            caster.sendMessage(target.getMobName() + " already has a damage absorb shield active.");
            return false;
        }
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}
}
