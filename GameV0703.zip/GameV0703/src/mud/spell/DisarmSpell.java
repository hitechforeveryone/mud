package mud.spell;

import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.ObjectItem;

public class DisarmSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "disarm";
    }

    @Override
    public String getDescription() {
        return "Attempt to knock the weapon from your opponent's hands.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
    	
    	
        if (caster == null || target == null) {
            return false;
        }
        EquipSlot MAINHAND = EquipSlot.MAINHAND;
        
        ObjectItem weapon = target.getEquippedItem(MAINHAND);
        if (weapon == null) {
            if (caster instanceof Player player) {
                player.sendMessage(target.getMobName() + " is not wielding a weapon.");
            }
            return false;
        }

        // Simple success roll: caster Agility vs target Agility
        int casterCheck = caster.getAgility() + (int)(Math.random() * 20);
        int targetCheck = target.getAgility() + (int)(Math.random() * 20);

        if (casterCheck > targetCheck) {
            target.unequip(MAINHAND);
            target.getCurrentRoom().addObject(weapon);

            if (caster instanceof Player player) {
                player.sendMessage("You " + getName() +  icon + " " + target.getMobName() + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You have been " + getName()+ "ed " +  icon + "by " + caster.getMobName() + "!");
            }
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your " + getName()+   icon + " attempt failed!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to " + getName() +  icon +  " you, but failed!");
            }
            return false;
        }
    }

    @Override
    public Object getProfession() {
        return null; // Open to all for now, could restrict to Warriors/Rogues later
    }

    @Override
    public int getLevelRequired() {
        return 3; // Require some experience
    }

	@Override
	public boolean isInstantCast() {
		return true;
	}
} // end DisarmSpell
