package mud.spell;

import mud.core.EffectType;
import mud.spell.effects.StunEffect;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;

import java.util.Random;

public class StunningBlowSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    private static final Random random = new Random();
  

    @Override
    public String getName() {
        return "stunningblow";
    }

    @Override
    public String getDescription() {
        return "Strike your foe with a blow that may stun them, preventing action for a short time.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (caster == null || target == null) {
            return false;
        }

        if (caster.getCurrentRoom() != target.getCurrentRoom()) {
            if (caster instanceof Player player) {
                player.sendMessage("Your target is not here.");
            }
            return false;
        }

        // Chance to stun: based on caster's Strength vs target's Stamina
        int chance = 50 + (caster.getStrength() - target.getStamina()) * 5;
        int roll = random.nextInt(100) + 1;

        int stunTime = random.nextInt(3)+1;
    	StunEffect STUN = new StunEffect(target, stunTime);
        if (roll <= chance) {
            target.addEffect(STUN); // stunned for 2–3 ticks
            
            if (caster instanceof Player player) {
                player.sendMessage("You smash " + target.getMobName() + " with a "+ getName() + icon + "!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("You are smashed by a "+ getName() + icon + " from " + caster.getMobName() + "!");
            }
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your "+ getName() + icon + " fails to connect properly.");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to smash you with a "+ getName() + icon + " but failed.");
            }
            return false;
        }
    }

    @Override
    public Object getProfession() {
        return null; // Could be restricted to Warrior/Fighter classes later
    }

    @Override
    public int getLevelRequired() {
        return 3;
    }

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return true;
	}
}
