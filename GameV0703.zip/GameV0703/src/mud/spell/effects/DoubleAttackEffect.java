package mud.spell.effects;

import mud.spell.effects.Effect;
import mud.core.Mob;
import mud.core.MobAffectFlag;

public class DoubleAttackEffect implements Effect {

    private final Mob target;
    private final boolean permanent = true;
    MobAffectFlag DA = MobAffectFlag.DOUBLEATTACK;
    
    public DoubleAttackEffect(Mob target) {
        this.target = target;
        this.target.setAffect(DA); // Enable double attack
    }

    @Override
    public void tick() {
        // Passive/permanent effects don’t need ticking logic
    }

    @Override
    public boolean isExpired() {
        return false; // Permanent effect
    }

    @Override
    public String getName() {
        return "double_attack";
    }

    @Override
    public Mob getTarget() {
        return target;
    }
    
    public void onRemove() {
    	target.removeAffect(DA);
    }

    @Override
    public int getHpBonus() {
        return 0;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public String getType() {
        return null;
    }

    @Override
    public int getDuration() {
        return 0;
    }
} // end
