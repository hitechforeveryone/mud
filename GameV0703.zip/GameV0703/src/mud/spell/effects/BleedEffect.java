package mud.spell.effects;

import java.util.*;

import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;

public class BleedEffect implements Effect {

    private static final List<BleedEffect> ACTIVE_EFFECTS = new ArrayList<>();

    private final Mob target;
    private final int damagePerTick;
    private final int totalTicks;
    private int ticksPassed = -1;
    
    MagicDamageType damageType = MagicDamageType.BLEED;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    public BleedEffect(Mob target, int damagePerTick, int totalTicks) {
        this.target = target;
        this.damagePerTick = damagePerTick;
        this.totalTicks = totalTicks;
        ACTIVE_EFFECTS.add(this);
    }

    public static void tickAll() {
        Iterator<BleedEffect> it = ACTIVE_EFFECTS.iterator();
        while (it.hasNext()) {
            BleedEffect effect = it.next();
            effect.tick();
            if (effect.isExpired()) {
                it.remove();
            }
        }
    }

    public void tick() {
        ticksPassed++;

        if (ticksPassed < totalTicks) {
            target.takeDamage(damagePerTick);
            target.sendMessage("You suffer " + damagePerTick + " bleed" + icon + " damage.");
            Room room = target.getCurrentRoom();
            if (room != null) {
                room.broadcastExcept(target.getMobName() + " bleeds" + icon + " from a wound!", target, null);
            }
        }
    }

    @Override
    public boolean isExpired() {
        return ticksPassed >= totalTicks;
    }

    @Override
    public Mob getTarget() {
        return target;
    }

    @Override
    public String getName() {
        return "Bleed";
    }

    @Override
    public int getHpBonus() {
        return 0;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public String getType() {
        return "DoT";
    }

    @Override
    public int getDuration() {
        return totalTicks;
    }
} // end