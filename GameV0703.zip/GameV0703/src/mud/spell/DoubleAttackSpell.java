package mud.spell;

import mud.core.Mob;
import mud.spell.effects.DoubleAttackEffect;

public class DoubleAttackSpell implements Spell {

    @Override
    public String getName() {
        return "double_attack";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually.
        applyPassive(caster);
        return true;
    }

    /**
     * Apply passive effect if missing.
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("double_attack")) {
            mob.addEffect(new DoubleAttackEffect(mob));
        }
    }

    @Override
    public String getDescription() {
        return "Grants the ability to occasionally strike twice in a single attack.";
    }

    @Override
    public Object getProfession() {
        return null; // Can tie to specific profession later if needed
    }

    @Override
    public int getLevelRequired() {
        return 0; // Adjust as needed for balance
    }

    @Override
    public boolean isInstantCast() {
        return true; // Passive, always active once applied
    }
} // end
