package mud.spell;

import mud.core.Direction;
import mud.core.Door;
import mud.core.Mob;
import mud.core.Player;
import mud.core.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class FleeSpell implements Spell {

    private final Random random = new Random();
 //   private final String direction = "";

    @Override
    public String getName() {
        return "Flee";
    }

    @Override
    public String getDescription() {
        return "Attempt to escape from combat, fleeing to a random adjacent room.";
    }

    public boolean cast(Mob caster, String direction) {

    	caster.sendMessage("You attempt to flee from combat.");
    	if (caster == caster.getTarget()) {
    		caster.sendMessage("You cannot flee from yourself");
    		return false;
    	}
        if (caster == null || caster.getCurrentRoom() == null) {
        	caster.sendMessage("You are nowhere.");
            return false;
        }

        Room currentRoom = caster.getCurrentRoom();
        Map<Direction, Room> exits = currentRoom.getExits();

        
        if (exits == null || exits.isEmpty()) {
            if (caster instanceof Player p) {
                p.sendMessage("You have nowhere to flee!");
            }
            return false;
        }

        // Collect valid exit rooms (avoid nulls)
       // String direction = "";
        List<Room> validRooms = new ArrayList<>();
        for (Room exitRoom : exits.values()) {
            if (exitRoom != null) {
                validRooms.add(exitRoom);
                direction = exits.keySet().toString();
                
            }
        }
	    Door door = caster.getCurrentRoom().getDoor(direction);
	    if (door != null) {
	        if (!door.isOpen()) caster.sendMessage("🛋 The " + door.getDoorName() + " is closed.");
	        if (door.isLocked()) caster.sendMessage("🔒 The " + door.getDoorName() + " is locked.");
	     //   return false;
	    }
	    
//	    Room current = caster.getCurrentRoom();
	    Direction dirEnum = Direction.fromString(direction);
	    if (dirEnum == null && caster instanceof Player p) {
	    	p.sendMessage("Invalid direction.");
	    }
        if (validRooms.isEmpty()) {
            if (caster instanceof Player player) {
                player.sendMessage("You try to flee, but all exits are blocked!");
            }
            return false;
        }

        Room escapeRoom = validRooms.get(random.nextInt(validRooms.size()));

        // Move the caster
        currentRoom.removeMob(caster);
        escapeRoom.addMob(caster);
        caster.setCurrentRoom(escapeRoom);
        
        // Drop combat target
        caster.setTarget(null);
        caster.getCurrentTarget().setTarget(null);


        if (caster instanceof Player p) {
            p.sendMessage("You flee from combat!\n");
        }

        // Announce to others in the room
        currentRoom.broadcast(caster.getMobName() + " flees from combat!", caster);
        escapeRoom.broadcast(caster.getMobName() + " rushes in, fleeing from battle.", caster);
        
        return true;
    }

    @Override
    public Object getProfession() {
        return null; // Any profession can use flee
    }

    @Override
    public int getLevelRequired() {
        return 1; // No restriction
    }

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cast(Mob caster, Mob target) {
		// TODO Auto-generated method stub
		return false;
	}
}
