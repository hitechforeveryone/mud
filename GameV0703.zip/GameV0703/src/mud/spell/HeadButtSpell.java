package mud.spell;

import mud.core.Mob;
import mud.core.Room;
import mud.core.ObjectItem;
import mud.core.ObjectType;
import mud.core.EquipSlot;  // Import the nested enum explicitly
import mud.core.MagicDamageType;

public class HeadButtSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.PHYSICAL;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "headbutt";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {

    	
        if (target == null) {
            caster.sendMessage("There is no target to " + getName() + ".");
            return false;
        }

        if (target == caster) {
            caster.sendMessage("You can't " + getName() + " yourself.");
            return false;
        }

        // Base damage for kick
        int baseDamage = 10 + caster.getStat("Strength") / 2;  // Use getStat() or getter for strength


        // Apply damage to target
        target.takeDamage(baseDamage);
        if (target.getTarget() == null) {
        	target.setTarget(caster);
        	caster.setTarget(target);
        }

        // Send messages
        caster.sendMessage("You " + getName() + " " + target.getMobName() + " for " + baseDamage + icon + " damage!");
        target.sendMessage(caster.getMobName() + getName() + "s you hard, dealing " + baseDamage + icon + " damage!");

        // Broadcast to others in the room except caster and target
        Room room = caster.getCurrentRoom();
        if (room != null) {
            room.broadcastExcept(caster.getMobName() + getName() + "s" + icon + " " + target.getMobName() + " very hard!", caster, target);
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// can be used without cast command
		return true;
	}
}