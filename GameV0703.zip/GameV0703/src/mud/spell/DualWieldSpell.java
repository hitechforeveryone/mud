package mud.spell;

import mud.core.Mob;
import mud.spell.effects.DualWieldEffect;

public class DualWieldSpell implements Spell {

    @Override
    public String getName() {
        return "dualwield";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        // Passive spell: not intended to be cast manually.
    	applyPassive(target);
        return true;
    }

    /**
     * Apply passive effect if missing.
     */
    public void applyPassive(Mob mob) {
        if (!mob.hasEffect("dual_wield")) {
            mob.addEffect(new DualWieldEffect(mob));
        }
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return true;
	}
}
