package mud.spell;

import mud.core.EquipSlot;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Player;
import mud.core.ObjectItem;

public class FumbleSpell implements Spell {
    MagicDamageType damageType = MagicDamageType.ARCANE;
    String icon = damageType.getIcon();
    String typeName = damageType.getPrettyName().toLowerCase();

    @Override
    public String getName() {
        return "fumble";
    }

    @Override
    public String getDescription() {
        return "Causes the target to fumble, dropping any weapon they are holding.";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            if (caster instanceof Player player) {
                player.sendMessage("There is no target to fumble.");
            }
            return false;
        }

        EquipSlot MAINHAND = EquipSlot.MAINHAND;
        ObjectItem weapon = target.getEquippedItem(MAINHAND);
        if (weapon == null) {
            if (caster instanceof Player player) {
                player.sendMessage(target.getMobName() + " is not wielding a weapon.");
            }
            return false;
        }

        // Simple opposed roll: caster Agility vs target Agility
        int casterCheck = (caster != null ? caster.getIntellect() : 10) + (int)(Math.random() * 20);
        int targetCheck = target.getAgility() + (int)(Math.random() * 20);

        if (casterCheck > targetCheck) {
            target.unequip(MAINHAND);
            target.getCurrentRoom().addObject(weapon);

            if (caster instanceof Player player) {
                player.sendMessage("You cause " + target.getMobName() + " to fumble " + icon + " and drop their weapon!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage("A strange force causes you to fumble " + icon + " and drop your weapon!");
            }
            return true;
        } else {
            if (caster instanceof Player player) {
                player.sendMessage("Your fumble spell " + icon + " fizzles!");
            }
            if (target instanceof Player playerTarget) {
                playerTarget.sendMessage(caster.getMobName() + " tried to make you fumble " + icon + " but failed!");
            }
            return false;
        }
    }

    @Override
    public Object getProfession() {
        return null; // Can be open to all casters for now
    }

    @Override
    public int getLevelRequired() {
        return 3;
    }

    @Override
    public boolean isInstantCast() {
        return true;
    }
} // end FumbleSpell
