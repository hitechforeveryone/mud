package mud.spell;

import mud.core.Mob;
import mud.spell.effects.Effect;
import mud.spell.effects.HealOverTimeEffect;

public class HealOverTimeSpell implements Spell {

    @Override
    public String getName() {
        return "heal_over_time";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to heal.");
            return false;
        }

        int healPerTick = 5;    // amount healed each tick
        int totalTicks = 6;     // duration in ticks

        // Create a new generic HoT effect instance
        HealOverTimeEffect hotEffect = new HealOverTimeEffect(target, healPerTick, totalTicks);

        // Add the effect to the target's effect list
        target.addEffect(hotEffect);

        caster.sendMessage("You cast Heal Over Time on " + target.getMobName() + ".");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " casts Heal Over Time on you.");
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}
}
