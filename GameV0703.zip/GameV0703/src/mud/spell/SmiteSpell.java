package mud.spell;

import mud.core.Mob;
import mud.core.Player;
import mud.core.MagicDamageType;

public class SmiteSpell implements Spell {
    private final MagicDamageType damageType = MagicDamageType.HOLY;
    private final String icon = damageType.getIcon();
    private final String typeName = damageType.getPrettyName().toLowerCase();
    
    @Override
    public String getName() {
        return "smite";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to " + getName() + icon + ".");
            return false;
        }

        boolean healCase = false;

        if (caster instanceof Player playerCaster) {
            if (target == caster) {
                healCase = true;
            } else if (playerCaster.getParty() != null && playerCaster.getParty().getMembers().contains(target)) {
                healCase = true;
            }
        }

        if (healCase) {
            // Heal case
            int healAmount = 20 + caster.getIntellect();
            target.heal(healAmount);

            caster.sendMessage("You cast " + getName() + icon + " and restore " + healAmount + " health to " + target.getMobName() + ".");
            if (target != caster) {
                target.sendMessage(caster.getMobName() + "'s " + getName() + icon + " heals you for " + healAmount + " health.");
            }
            caster.getCurrentRoom().broadcastExcept(
                caster.getMobName() + " casts " + getName() + icon + " on " + target.getMobName() + ", healing them.",
                caster, target
            );
        } else {
            // Damage case
            int damage = 20 + caster.getIntellect();
            target.takeDamage(damage, damageType);

            caster.sendMessage("You smite " + target.getMobName() + icon + ", dealing " + damage + " " + typeName + " damage.");
            target.sendMessage(caster.getMobName() + " smites you" + icon + ", dealing " + damage + " " + typeName + " damage!");
            caster.getCurrentRoom().broadcastExcept(
                caster.getMobName() + " smites " + target.getMobName() + icon + ", dealing " + damage + " " + typeName + " damage.",
                caster, target
            );
            if (target.getTarget() == null) {
            	target.setTarget(caster);
            	caster.setTarget(target);
            }
            
        }
        
        return true;
    }

    @Override
    public String getDescription() {
        return "Smite: If cast on self or ally, heals them. If cast on an enemy, deals holy damage.";
    }

    @Override
    public Object getProfession() {
        return null;
    }

    @Override
    public int getLevelRequired() {
        return 1;
    }

    @Override
    public boolean isInstantCast() {
        return false;
    }
} // end
