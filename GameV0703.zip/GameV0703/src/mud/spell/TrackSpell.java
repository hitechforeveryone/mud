package mud.spell;

import java.util.*;

import mud.core.Direction;
import mud.core.MagicDamageType;
import mud.core.Mob;
import mud.core.Room;
import mud.core.Zone;

public class TrackSpell implements Spell {


	
    private static final int MAX_TRACK_DEPTH = 50;
    private static final Map<Mob, Mob> ACTIVE = new HashMap<>();

    public TrackSpell() {}

    @Override
    public boolean cast(Mob caster, Mob target) {
        cancel(caster);
        MagicDamageType damageType = MagicDamageType.MAGNIFIER;
        String icon = damageType.getIcon();
        String typeName = damageType.getPrettyName().toLowerCase();
        
        if (target == null || caster == target) {
            caster.sendMessage(target == null ? "There is no target to track" + icon + "." : "You can't track" + icon + " yourself.");
            return false;
        }

        Room start = caster.getCurrentRoom();
        Zone zone = caster.getZone();
        Room troom = target.getCurrentRoom();
        if (start == null || zone == null || troom == null || target.getZone() != zone) {
            caster.sendMessage("Target is out of tracking" + icon + " range.");
            return false;
        }

        ACTIVE.put(caster, target);
        String idx = indexLabel(target, start);
        caster.sendMessage("You begin tracking" + icon + " " + target.getMobName() + (idx != null ? " (" + idx + ")" : "") + ".");
        return true;
    }

    public static void tick() {
        MagicDamageType damageType = MagicDamageType.MAGNIFIER;
        String icon = damageType.getIcon();
        String typeName = damageType.getPrettyName().toLowerCase();
        
        Iterator<Map.Entry<Mob, Mob>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Mob, Mob> e = it.next();
            Mob caster = e.getKey();
            Mob target = e.getValue();

            if (caster == null || target == null) { it.remove(); continue; }

            Room start = caster.getCurrentRoom();
            Room troom = target.getCurrentRoom();
            Zone zone = caster.getZone();
            if (start == null || troom == null || zone == null || target.getZone() != zone) {
            	caster.sendMessage("You lose the trail" + icon + ".");
                it.remove();
                continue;
            }

            if (start == troom) {
                String idx = indexLabel(target, start);
                caster.sendMessage(target.getMobName() + (idx != null ? " (" + idx + ")" : "") + " is right here with you.");
                it.remove();
                continue;
            }

            SearchHit hit = bfsFirstDirectionToRoom(start, troom, zone);
            if (hit != null) {
                String idx = indexLabel(target, hit.foundRoom);
                caster.sendMessage("You sense" + icon + target.getMobName() + (idx != null ? " (" + idx + ")" : "") + " to the " + hit.firstDir.name().toLowerCase() + ".");
            } else {
            	caster.sendMessage("You lose the trail" + icon + " of " + target.getMobName() + ".");
                it.remove();
            }
        }
    }

    private static class SearchHit { final Direction firstDir; final Room foundRoom; SearchHit(Direction d, Room r) { firstDir = d; foundRoom = r; }}

    private static SearchHit bfsFirstDirectionToRoom(Room start, Room target, Zone zone) {
        Map<Room, Direction> firstDirMap = new HashMap<>();
        Map<Room, Integer> depth = new HashMap<>();
        Set<Room> visited = new HashSet<>();
        Queue<Room> q = new LinkedList<>();
        q.add(start); visited.add(start); depth.put(start, 0);

        while (!q.isEmpty()) {
            Room cur = q.poll();
            int d = depth.getOrDefault(cur, 0);
            if (d >= MAX_TRACK_DEPTH) continue;

            for (Direction dir : Direction.values()) {
                Room nb = cur.getExit(dir);
                if (nb == null || visited.contains(nb) || nb.getZone() != zone) continue;

                visited.add(nb);
                depth.put(nb, d + 1);
                firstDirMap.put(nb, cur == start ? dir : firstDirMap.get(cur));

                if (nb == target) return new SearchHit(firstDirMap.get(nb), nb);
                q.add(nb);
            }
        }
        return null;
    }

    private static String indexLabel(Mob mob, Room room) {
        if (room == null) return null;
        int i = 1;
        for (Mob m : room.getMobs()) {
            if (m == mob) return i + "." + mob.getMobName().toLowerCase();
            i++;
        }
        return null;
    }

    private static void safeSend(Mob caster, String msg) { try { if (caster != null) caster.sendMessage(msg); } catch (Exception ignored) {} }

    public static void cancel(Mob caster) { if (caster != null) { ACTIVE.remove(caster); safeSend(caster, "Stopping tracking."); } }

    @Override public String getName() { return "track"; }
    @Override public String getDescription() { return "Continuously reveals direction to a target in your zone until found or lost."; }
    @Override public Object getProfession() { return null; }
    @Override public int getLevelRequired() { return 0; }
    @Override public boolean isInstantCast() { return true; }
}
