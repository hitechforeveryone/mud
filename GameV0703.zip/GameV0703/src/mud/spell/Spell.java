// Spell.java (Interface)
package mud.spell;

import mud.core.Mob;

public interface Spell {
    String getName();
    String getDescription();
    boolean cast(Mob caster, Mob target);
	Object getProfession();
	int getLevelRequired();
	boolean isInstantCast();  // can be used without cast command // kick, track, rescue, monk spells, etc
}