package mud.spell;

import mud.core.Mob;

public class HealSpell implements Spell {

    @Override
    public String getName() {
        return "heal";
    }

    @Override
    public boolean cast(Mob caster, Mob target) {
        if (target == null) {
            caster.sendMessage("There is no target to heal.");
            return false;
        }

        // Calculate heal amount (for example: base 20 + caster's Intellect)
        int healAmount = 20 + caster.getIntellect();

        // Heal the target
        target.heal(healAmount);

        // Notify both caster and target
        caster.sendMessage("You cast heal and restore " + healAmount + " health to " + target.getMobName() + ".");
        if (target != caster) {
            target.sendMessage(caster.getMobName() + " heals you for " + healAmount + " health.");
        }

        return true;
    }

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getProfession() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLevelRequired() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isInstantCast() {
		// TODO Auto-generated method stub
		return false;
	}
}
