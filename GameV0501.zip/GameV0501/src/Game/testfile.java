	private static void loadrm24mobs(zone loadZone, zoneScript zScript) {

	// rm24 tmob0 
	int mob0roller = roll(0,100);
	//		System.out.println(mob0roller);
	if (mob0roller<=zScript.getRm24mob0Perc()) {
		//load mob stuff
		// System.out.println("Will attempt to load mob: " + zScript.getRm24mob0ID());			
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob0ID()),0); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob0,Integer.valueOf(zScript.getRm24mob0ID())); // loads mob into specific zone, room, and mob, the 4 is the mob ID from db
		// load obj stuff
		int mob0headroller = roll(0,100);
		if (mob0headroller<=zScript.getRm24mob0HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: " + zScript.getRm24mob0HeadID());
			loadZone.rm24.tmob0.setHeadSlot(String.valueOf(zScript.getRm24mob0HeadID()));
			loadObject(loadZone.rm24.tmob0.mobHelm,zScript.getRm24mob0HeadID());				
		}
		else {
			//				System.out.println("head slot load roll failed");
		} // to be muted			
		int mob0neckroller = roll(0,100);
		if (mob0neckroller<=zScript.getRm24mob0NeckPerc()) {
			//				System.out.println("Will attempt to load the mob's neck slot: "+ zScript.getRm24mob0NeckID());
			loadZone.rm24.tmob0.setNeckSlot(String.valueOf(zScript.getRm24mob0NeckID()));
			loadObject(loadZone.rm24.tmob0.mobNeck, zScript.getRm24mob0NeckID());
		}
		else {
			//				System.out.println("neck slot load roll failed");
		} // to be muted
		int mob0shoulderroller = roll(0,100);
		if (mob0shoulderroller<=zScript.getRm24mob0ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: " + zScript.getRm24mob0ShoulderID());
			loadZone.rm24.tmob0.setShoulderSlot(String.valueOf(zScript.getRm24mob0ShoulderID()));
			loadObject(loadZone.rm24.tmob0.mobShoulder, zScript.getRm24mob0ShoulderID());
		}
		else {
			//				System.out.println("shoulder slot load roll failed");
		} // to be muted
		int mob0chestroller = roll(0,100);
		if (mob0chestroller<=zScript.getRm24mob0ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: " + zScript.getRm24mob0ChestID());
			loadZone.rm24.tmob0.setChestSlot(String.valueOf(zScript.getRm24mob0ChestID()));
			loadObject(loadZone.rm24.tmob0.mobChest, zScript.getRm24mob0ChestID());
		}
		else {
			//				System.out.println("chest slot load roll failed");
		} // to be muted
		int mob0wristroller = roll(0,100);
		if (mob0wristroller<=zScript.getRm24mob0WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: " + zScript.getRm24mob0WristID());
							loadZone.rm24.tmob0.setWristSlot(String.valueOf(zScript.getRm24mob0WristID()));
			loadObject(loadZone.rm24.tmob0.mobWrist, zScript.getRm24mob0WristID());
		}
		else {
			//				System.out.println("wrist slot load roll failed");
		} // to be muted
		int mob0handroller = roll(0,100);
		if (mob0handroller<=zScript.getRm24mob0HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: " + zScript.getRm24mob0HandsID());
							loadZone.rm24.tmob0.setHandSlot(String.valueOf(zScript.getRm24mob0HandsID()));
			loadObject(loadZone.rm24.tmob0.mobHand, zScript.getRm24mob0HandsID());
		}
		else {
			//				System.out.println("hand slot load roll failed");
		} // to be muted
		int mob0finger1roller = roll(0,100);
		if (mob0finger1roller<=zScript.getRm24mob0Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: " + zScript.getRm24mob0Finger1ID());
							loadZone.rm24.tmob0.setFinger1(String.valueOf(zScript.getRm24mob0Finger1ID()));
			loadObject(loadZone.rm24.tmob0.mobFinger1, zScript.getRm24mob0Finger1ID());
		}
		else {
			//				System.out.println("Finger1 slot load roll failed");
		} // to be muted
		int mob0finger2roller = roll(0,100);
		if (mob0finger2roller<=zScript.getRm24mob0Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: " + zScript.getRm24mob0Finger2ID());
					loadZone.rm24.tmob0.setFinger2(String.valueOf(zScript.getRm24mob0Finger2ID()));
			loadObject(loadZone.rm24.tmob0.mobFinger2, zScript.getRm24mob0Finger2ID());
		}
		else {
			//				System.out.println("Finger2 slot load roll failed");
		} // to be muted
		int mob0waistroller = roll(0,100);
		if (mob0waistroller<=zScript.getRm24mob0WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: " + zScript.getRm24mob0WaistID());
						loadZone.rm24.tmob0.setWaistSlot(String.valueOf(zScript.getRm24mob0WaistID()));
			loadObject(loadZone.rm24.tmob0.mobWaist, zScript.getRm24mob0WaistID());
		}
		else {
			//				System.out.println("waist slot load roll failed");
		} // to be muted
		int mob0legroller = roll(0,100);
		if (mob0legroller<=zScript.getRm24mob0LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: " + zScript.getRm24mob0LegID());
							loadZone.rm24.tmob0.setLegSlot(String.valueOf(zScript.getRm24mob0LegID()));
			loadObject(loadZone.rm24.tmob0.mobLeg, zScript.getRm24mob0LegID());
		}
		else { 
			//				System.out.println("leg slot load roll failed");
		} // to be muted
		int mob0footroller = roll(0,100);
		if (mob0footroller<=zScript.getRm24mob0FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: " + zScript.getRm24mob0FootID());
							loadZone.rm24.tmob0.setFootSlot(String.valueOf(zScript.getRm24mob0FootID()));
			loadObject(loadZone.rm24.tmob0.mobFoot, zScript.getRm24mob0FootID());
		}
		else {
			//				System.out.println("foot slot load roll failed");
		} // to be muted
		int mob0trinket1roller = roll(0,100);
		if (mob0trinket1roller<=zScript.getRm24mob0Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: " + zScript.getRm24mob0Trinket1ID());
			//					loadZone.rm24.tmob0.setTrinket1Slot(String.valueOf(zScript.getRm24mob0Trinket1ID()));
			loadObject(loadZone.rm24.tmob0.mobTrinket1, zScript.getRm24mob0Trinket1ID());
		}
		else { 
			//				System.out.println("trinket1 slot load roll failed");
		} // to be muted
		int mob0trinket2roller = roll(0,100);
		if (mob0trinket2roller<=zScript.getRm24mob0Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: " + zScript.getRm24mob0Trinket2ID());
								loadZone.rm24.tmob0.setTrinket2Slot(String.valueOf(zScript.getRm24mob0Trinket2ID()));
			loadObject(loadZone.rm24.tmob0.mobTrinket2, zScript.getRm24mob0Trinket2ID());
		}
		else {
			//				System.out.println("trinket2 slot load roll failed");
		} // to be muted
		int mob0weapon1roller = roll(0,100);
		if (mob0weapon1roller<=zScript.getRm24mob0Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: " + zScript.getRm24mob0Weapon1ID());
								loadZone.rm24.tmob0.setWeapon1Slot(String.valueOf(zScript.getRm24mob0Weapon1ID()));
			loadObject(loadZone.rm24.tmob0.mobWeapon1, zScript.getRm24mob0Weapon1ID());
		}
		else { 
			//				System.out.println("weapon1 slot load roll failed");
		} // to be muted
		int mob0weaponshieldroller = roll(0,100);
		if (mob0weaponshieldroller<=zScript.getRm24mob0WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: " + zScript.getRm24mob0WeaponShieldID());
			loadZone.rm24.tmob0.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob0WeaponShieldID()));
			loadObject(loadZone.rm24.tmob0.mobWeaponShield, zScript.getRm24mob0WeaponShieldID());
		}
		else {
			//				System.out.println("weaponShield slot load roll failed");
		} // to be muted		
	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob0.getMobNum() + " could not be loaded");
	}

	// rm24 tmob1
	int mob1roller = roll(0,100);
	//		System.out.println(mob1roller);
	if (mob1roller<=zScript.getRm24mob1Perc()) {
		//load mob stuff
		//			System.out.println("Will attempt to load mob: " + zScript.getRm24mob1());			
		// //mob stuffs
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob1ID()),1); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob1,Integer.valueOf(zScript.getRm24mob1ID()));
		// load obj stuff
		// do roll for each getRm24mob1HeadID() and getRm24mob1HeadPerc() ...
		int mob1headroller = roll(0,100);
		if (mob1headroller<=zScript.getRm24mob1HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: ");
			loadZone.rm24.tmob1.setHeadSlot(String.valueOf(zScript.getRm24mob1HeadID()));
			loadObject(loadZone.rm24.tmob1.mobHelm, zScript.getRm24mob1HeadID());
		}
		else {
			//				System.out.println("head slot load roll failed");
		} // to be muted			
		int mob1neckroller = roll(0,100);
		if (mob1neckroller<=zScript.getRm24mob1NeckPerc()) {
			//				System.out.println("Will attempt to load the mob's neck slot: ");
			loadZone.rm24.tmob1.setHeadSlot(String.valueOf(zScript.getRm24mob1NeckID()));
			loadObject(loadZone.rm24.tmob1.mobNeck, zScript.getRm24mob1NeckID());
		}
		else {
			//				System.out.println("neck slot load roll failed");
		} // to be muted
		int mob1shoulderroller = roll(0,100);
		if (mob1shoulderroller<=zScript.getRm24mob1ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: ");
			loadZone.rm24.tmob1.setShoulderSlot(String.valueOf(zScript.getRm24mob1ShoulderID()));
			loadObject(loadZone.rm24.tmob1.mobShoulder, zScript.getRm24mob1ShoulderID());
		}
		else {
			//				System.out.println("shoulder slot load roll failed");
		} // to be muted
		int mob1chestroller = roll(0,100);
		if (mob1chestroller<=zScript.getRm24mob1ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: ");
			loadZone.rm24.tmob1.setChestSlot(String.valueOf(zScript.getRm24mob1ChestID()));
			loadObject(loadZone.rm24.tmob1.mobChest, zScript.getRm24mob1ChestID());
		}
		else {
			//				System.out.println("chest slot load roll failed");
		} // to be muted
		int mob1wristroller = roll(0,100);
		if (mob1wristroller<=zScript.getRm24mob1WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: ");
			loadZone.rm24.tmob1.setWristSlot(String.valueOf(zScript.getRm24mob1WristID()));
			loadObject(loadZone.rm24.tmob1.mobWrist, zScript.getRm24mob1WristID());
		}
		else {
			//				System.out.println("wrist slot load roll failed");
		} // to be muted
		int mob1handroller = roll(0,100);
		if (mob1handroller<=zScript.getRm24mob1HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: ");
			loadZone.rm24.tmob1.setHandSlot(String.valueOf(zScript.getRm24mob1HandsID()));
			loadObject(loadZone.rm24.tmob1.mobHand, zScript.getRm24mob1HandsID());
		}
		else { 
			//				System.out.println("hand slot load roll failed");
		} // to be muted
		int mob1finger1roller = roll(0,100);
		if (mob1finger1roller<=zScript.getRm24mob1Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: ");
			loadZone.rm24.tmob1.setFinger1(String.valueOf(zScript.getRm24mob1Finger1ID()));
			loadObject(loadZone.rm24.tmob1.mobFinger1, zScript.getRm24mob1Finger1ID());
		}
		else {
			//				System.out.println("Finger1 slot load roll failed");
		} // to be muted
		int mob1finger2roller = roll(0,100);
		if (mob1finger2roller<=zScript.getRm24mob1Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: ");
			loadZone.rm24.tmob1.setFinger2(String.valueOf(zScript.getRm24mob1Finger1ID()));
			loadObject(loadZone.rm24.tmob1.mobFinger2, zScript.getRm24mob1Finger2ID());
		}
		else {
			//				System.out.println("Finger2 slot load roll failed");
		} // to be muted
		int mob1waistroller = roll(0,100);
		if (mob1waistroller<=zScript.getRm24mob1WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: ");
			loadZone.rm24.tmob1.setWaistSlot(String.valueOf(zScript.getRm24mob1WaistID()));
			loadObject(loadZone.rm24.tmob1.mobWaist, zScript.getRm24mob1WaistID());
		}
		else {
			//				System.out.println("waist slot load roll failed");
		} // to be muted
		int mob1legroller = roll(0,100);
		if (mob1legroller<=zScript.getRm24mob1LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: ");
			loadZone.rm24.tmob1.setLegSlot(String.valueOf(zScript.getRm24mob1LegID()));
			loadObject(loadZone.rm24.tmob1.mobLeg, zScript.getRm24mob1LegID());
		}
		else { 
			//				System.out.println("leg slot load roll failed");
		} // to be muted
		int mob1footroller = roll(0,100);
		if (mob1footroller<=zScript.getRm24mob1FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: ");
			loadZone.rm24.tmob1.setFootSlot(String.valueOf(zScript.getRm24mob1FootID()));
			loadObject(loadZone.rm24.tmob1.mobFoot, zScript.getRm24mob1FootID());
		}
		else {
			//				System.out.println("foot slot load roll failed");
		} // to be muted
		int mob1trinket1roller = roll(0,100);
		if (mob1trinket1roller<=zScript.getRm24mob1Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: ");
			loadZone.rm24.tmob1.setTrinket1Slot(String.valueOf(zScript.getRm24mob1Trinket1ID()));
			loadObject(loadZone.rm24.tmob1.mobTrinket1, zScript.getRm24mob1Trinket1ID());
		}
		else { 
			//				System.out.println("trinket1 slot load roll failed"); 
		} // to be muted
		int mob1trinket2roller = roll(0,100);
		if (mob1trinket2roller<=zScript.getRm24mob1Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: ");
			loadZone.rm24.tmob0.setTrinket2Slot(String.valueOf(zScript.getRm24mob1Trinket2ID()));
			loadObject(loadZone.rm24.tmob1.mobTrinket2, zScript.getRm24mob1Trinket2ID());
		}
		else {
			//			System.out.println("trinket2 slot load roll failed"); 
		} // to be muted
		int mob1weapon1roller = roll(0,100);
		if (mob1weapon1roller<=zScript.getRm24mob1Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: ");
			loadZone.rm24.tmob1.setWeapon1Slot(String.valueOf(zScript.getRm24mob1Weapon1ID()));
			loadObject(loadZone.rm24.tmob1.mobWeapon1, zScript.getRm24mob1Weapon1ID());
		}
		else { 
			//				System.out.println("weapon1 slot load roll failed");
		} // to be muted
		int mob1weaponshieldroller = roll(0,100);
		if (mob1weaponshieldroller<=zScript.getRm24mob1WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: ");
			loadZone.rm24.tmob0.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob1WeaponShieldID()));
			loadObject(loadZone.rm24.tmob1.mobWeaponShield, zScript.getRm24mob1WeaponShieldID());
		}
		else {
			//				System.out.println("weaponShield slot load roll failed"); 
		} // to be muted
	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob1.getMobNum() +" could not be loaded");
	}


	// rm24 tmob2
	int mob2roller = roll(0,100);
	//		System.out.println(mob2roller);
	if (mob2roller<=zScript.getRm24mob2Perc()) {
		//load mob stuff
		//			System.out.println("Will attempt to load mob: " + zScript.getRm24mob2());			
		// //mob stuffs
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob2ID()),2); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob2,Integer.valueOf(zScript.getRm24mob2ID()));			// load obj stuff
		// do roll for each getRm24mob2HeadID() and getRm24mob2HeadPerc() ...
		int mob2headroller = roll(0,100);
		if (mob2headroller<=zScript.getRm24mob2HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: ");
			loadZone.rm24.tmob2.setHeadSlot(String.valueOf(zScript.getRm24mob2HeadID()));
			loadObject(loadZone.rm24.tmob2.mobHelm, zScript.getRm24mob2HeadID());
		}
		else {
			//				System.out.println("head slot load roll failed");
		} // to be muted			
		int mob2neckroller = roll(0,100);
		if (mob2neckroller<=zScript.getRm24mob2NeckPerc()) {
			//				System.out.println("Will attempt to load the mob's neck slot: ");
			loadZone.rm24.tmob2.setNeckSlot(String.valueOf(zScript.getRm24mob2NeckID()));
			loadObject(loadZone.rm24.tmob2.mobNeck, zScript.getRm24mob2NeckID());
		}
		else { 
			//				System.out.println("neck slot load roll failed");
		} // to be muted
		int mob2shoulderroller = roll(0,100);
		if (mob2shoulderroller<=zScript.getRm24mob2ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: ");
			loadZone.rm24.tmob2.setHeadSlot(String.valueOf(zScript.getRm24mob2ShoulderID()));
			loadObject(loadZone.rm24.tmob2.mobShoulder, zScript.getRm24mob2ShoulderID());
		}
		else {
			//				System.out.println("shoulder slot load roll failed");
		} // to be muted
		int mob2chestroller = roll(0,100);
		if (mob2chestroller<=zScript.getRm24mob2ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: ");
			loadZone.rm24.tmob2.setChestSlot(String.valueOf(zScript.getRm24mob2ChestID()));
			loadObject(loadZone.rm24.tmob2.mobChest, zScript.getRm24mob2ChestID());
		}
		else { 
			//				System.out.println("chest slot load roll failed"); 
		} // to be muted
		int mob2wristroller = roll(0,100);
		if (mob2wristroller<=zScript.getRm24mob2WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: ");
			loadZone.rm24.tmob2.setWristSlot(String.valueOf(zScript.getRm24mob2WristID()));
			loadObject(loadZone.rm24.tmob2.mobWrist, zScript.getRm24mob2WristID());
		}
		else {
			//				System.out.println("wrist slot load roll failed"); 
		} // to be muted
		int mob2handroller = roll(0,100);
		if (mob2handroller<=zScript.getRm24mob2HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: ");
			loadZone.rm24.tmob2.setHandSlot(String.valueOf(zScript.getRm24mob2HandsID()));
			loadObject(loadZone.rm24.tmob2.mobHand, zScript.getRm24mob2HandsID());
		}
		else {
			//				System.out.println("hand slot load roll failed");
		} // to be muted
		int mob2finger1roller = roll(0,100);
		if (mob2finger1roller<=zScript.getRm24mob2Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: ");
			loadZone.rm24.tmob2.setFinger1(String.valueOf(zScript.getRm24mob2Finger1ID()));
			loadObject(loadZone.rm24.tmob2.mobFinger1, zScript.getRm24mob2Finger1ID());
		}
		else {
			//				System.out.println("Finger1 slot load roll failed");
		} // to be muted
		int mob2finger2roller = roll(0,100);
		if (mob2finger2roller<=zScript.getRm24mob2Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: ");
			loadZone.rm24.tmob2.setFinger2(String.valueOf(zScript.getRm24mob2Finger2ID()));
			loadObject(loadZone.rm24.tmob2.mobFinger2, zScript.getRm24mob2Finger2ID());
		}
		else {
			//				System.out.println("Finger2 slot load roll failed");
		} // to be muted
		int mob2waistroller = roll(0,100);
		if (mob2waistroller<=zScript.getRm24mob2WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: ");
			loadZone.rm24.tmob2.setWaistSlot(String.valueOf(zScript.getRm24mob2WaistID()));
			loadObject(loadZone.rm24.tmob2.mobWaist, zScript.getRm24mob2WaistID());
		}
		else {
			//				System.out.println("waist slot load roll failed");
		} // to be muted
		int mob2legroller = roll(0,100);
		if (mob2legroller<=zScript.getRm24mob2LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: ");
			loadZone.rm24.tmob2.setLegSlot(String.valueOf(zScript.getRm24mob2LegID()));
			loadObject(loadZone.rm24.tmob2.mobLeg, zScript.getRm24mob2LegID());
		}
		else {
			//				System.out.println("leg slot load roll failed"); 
		} // to be muted
		int mob2footroller = roll(0,100);
		if (mob2footroller<=zScript.getRm24mob2FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: ");
			loadZone.rm24.tmob3.setFootSlot(String.valueOf(zScript.getRm24mob2FootID()));
			loadObject(loadZone.rm24.tmob2.mobFoot, zScript.getRm24mob2FootID());
		}
		//			else { System.out.println("foot slot load roll failed"); } // to be muted
		int mob2trinket1roller = roll(0,100);
		if (mob2trinket1roller<=zScript.getRm24mob2Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: ");
			loadZone.rm24.tmob2.setHeadSlot(String.valueOf(zScript.getRm24mob2Trinket1ID()));
			loadObject(loadZone.rm24.tmob2.mobTrinket1, zScript.getRm24mob2Trinket1ID());
		}
		//			else { System.out.println("trinket1 slot load roll failed"); } // to be muted
		int mob2trinket2roller = roll(0,100);
		if (mob2trinket2roller<=zScript.getRm24mob2Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: ");
			loadZone.rm24.tmob2.setTrinket2Slot(String.valueOf(zScript.getRm24mob2Trinket2ID()));
			loadObject(loadZone.rm24.tmob2.mobTrinket2, zScript.getRm24mob2Trinket2ID());
		}
		//			else { System.out.println("trinket2 slot load roll failed"); } // to be muted
		int mob2weapon1roller = roll(0,100);
		if (mob2weapon1roller<=zScript.getRm24mob2Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: ");
			loadZone.rm24.tmob2.setWeapon1Slot(String.valueOf(zScript.getRm24mob2Weapon1ID()));
			loadObject(loadZone.rm24.tmob2.mobWeapon1, zScript.getRm24mob2Weapon1ID());
		}
		//			else { System.out.println("weapon1 slot load roll failed"); } // to be muted
		int mob2weaponshieldroller = roll(0,100);
		if (mob2weaponshieldroller<=zScript.getRm24mob2WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: ");
			loadZone.rm24.tmob2.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob2WeaponShieldID()));
			loadObject(loadZone.rm24.tmob2.mobWeaponShield, zScript.getRm24mob2WeaponShieldID());
		}
		//			else { System.out.println("weaponShield slot load roll failed"); } // to be muted
	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob2.getMobNum() +" could not be loaded");
	}

	// rm24 tmob3
	int mob3roller = roll(0,100);
	//		System.out.println(mob3roller);
	if (mob3roller<=zScript.getRm24mob3Perc()) {
		//load mob stuff
		//			System.out.println("Will attempt to load mob: " + zScript.getRm24mob3());			
		// //mob stuffs
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob3ID()),3); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob3,Integer.valueOf(zScript.getRm24mob3ID()));			// load obj stuff
		// do roll for each getRm24mob3HeadID() and getRm24mob3HeadPerc() ...
		int mob3headroller = roll(0,100);
		if (mob3headroller<=zScript.getRm24mob3HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: ");
			loadZone.rm24.tmob3.setHeadSlot(String.valueOf(zScript.getRm24mob3HeadID()));
			loadObject(loadZone.rm24.tmob3.mobHelm, zScript.getRm24mob3HeadID());
		}
		//			else { System.out.println("head slot load roll failed"); } // to be muted			
		int mob3neckroller = roll(0,100);
		if (mob3neckroller<=zScript.getRm24mob3NeckPerc()) {
			//				System.out.println("Will attempt to load the mob's neck slot: ");
			loadZone.rm24.tmob3.setNeckSlot(String.valueOf(zScript.getRm24mob3NeckID()));
			loadObject(loadZone.rm24.tmob3.mobNeck, zScript.getRm24mob3NeckID());
		}
		//			else { System.out.println("neck slot load roll failed"); } // to be muted
		int mob3shoulderroller = roll(0,100);
		if (mob3shoulderroller<=zScript.getRm24mob3ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: ");
			loadZone.rm24.tmob3.setShoulderSlot(String.valueOf(zScript.getRm24mob3ShoulderID()));
			loadObject(loadZone.rm24.tmob3.mobShoulder, zScript.getRm24mob3ShoulderID());
		}
		//			else { System.out.println("shoulder slot load roll failed"); } // to be muted
		int mob3chestroller = roll(0,100);
		if (mob3chestroller<=zScript.getRm24mob3ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: ");
			loadZone.rm24.tmob3.setChestSlot(String.valueOf(zScript.getRm24mob3ChestID()));
			loadObject(loadZone.rm24.tmob3.mobChest, zScript.getRm24mob3ChestID());
		}
		//			else { System.out.println("chest slot load roll failed"); } // to be muted
		int mob3wristroller = roll(0,100);
		if (mob3wristroller<=zScript.getRm24mob3WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: ");
			loadZone.rm24.tmob3.setWristSlot(String.valueOf(zScript.getRm24mob3WristID()));
			loadObject(loadZone.rm24.tmob3.mobWrist, zScript.getRm24mob3WristID());
		}
		//			else { System.out.println("wrist slot load roll failed"); } // to be muted
		int mob3handroller = roll(0,100);
		if (mob3handroller<=zScript.getRm24mob3HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: ");
			loadZone.rm24.tmob3.setHandSlot(String.valueOf(zScript.getRm24mob3HandsID()));
			loadObject(loadZone.rm24.tmob3.mobHand, zScript.getRm24mob3HandsID());
		}
		//			else { System.out.println("hand slot load roll failed"); } // to be muted
		int mob3finger1roller = roll(0,100);
		if (mob3finger1roller<=zScript.getRm24mob3Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: ");
			loadZone.rm24.tmob3.setFinger1(String.valueOf(zScript.getRm24mob3Finger1ID()));
			loadObject(loadZone.rm24.tmob3.mobFinger1, zScript.getRm24mob3Finger1ID());
		}
		//			else { System.out.println("Finger1 slot load roll failed"); } // to be muted
		int mob3finger2roller = roll(0,100);
		if (mob3finger2roller<=zScript.getRm24mob3Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: ");
			loadZone.rm24.tmob3.setFinger2(String.valueOf(zScript.getRm24mob3Finger2ID()));
			loadObject(loadZone.rm24.tmob3.mobFinger2, zScript.getRm24mob3Finger2ID());
		}
		//			else { System.out.println("Finger2 slot load roll failed"); } // to be muted
		int mob3waistroller = roll(0,100);
		if (mob3waistroller<=zScript.getRm24mob3WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: ");
			loadZone.rm24.tmob3.setWaistSlot(String.valueOf(zScript.getRm24mob3WaistID()));
			loadObject(loadZone.rm24.tmob3.mobWaist, zScript.getRm24mob3WaistID());
		}
		//			else { System.out.println("waist slot load roll failed"); } // to be muted
		int mob3legroller = roll(0,100);
		if (mob3legroller<=zScript.getRm24mob3LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: ");
			loadZone.rm24.tmob3.setLegSlot(String.valueOf(zScript.getRm24mob3LegID()));
			loadObject(loadZone.rm24.tmob3.mobLeg, zScript.getRm24mob3LegID());
		}
		//			else { System.out.println("leg slot load roll failed"); } // to be muted
		int mob3footroller = roll(0,100);
		if (mob3footroller<=zScript.getRm24mob3FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: ");
			loadZone.rm24.tmob3.setFootSlot(String.valueOf(zScript.getRm24mob3FootID()));
			loadObject(loadZone.rm24.tmob3.mobFoot, zScript.getRm24mob3FootID());
		}
		//			else { System.out.println("foot slot load roll failed"); } // to be muted
		int mob3trinket1roller = roll(0,100);
		if (mob3trinket1roller<=zScript.getRm24mob3Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: ");
			loadZone.rm24.tmob3.setTrinket1Slot(String.valueOf(zScript.getRm24mob3Trinket1ID()));
			loadObject(loadZone.rm24.tmob3.mobTrinket1, zScript.getRm24mob3Trinket1ID());
		}
		//			else { System.out.println("trinket1 slot load roll failed"); } // to be muted
		int mob3trinket2roller = roll(0,100);
		if (mob3trinket2roller<=zScript.getRm24mob3Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: ");
			loadZone.rm24.tmob3.setTrinket2Slot(String.valueOf(zScript.getRm24mob3Trinket2ID()));
			loadObject(loadZone.rm24.tmob3.mobTrinket2, zScript.getRm24mob3Trinket2ID());
		}
		//			else { System.out.println("trinket2 slot load roll failed"); } // to be muted
		int mob3weapon1roller = roll(0,100);
		if (mob3weapon1roller<=zScript.getRm24mob3Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: ");
			loadZone.rm24.tmob3.setWeapon1Slot(String.valueOf(zScript.getRm24mob3Weapon1ID()));
			loadObject(loadZone.rm24.tmob3.mobWeapon1, zScript.getRm24mob3Weapon1ID());
		}
		//			else { System.out.println("weapon1 slot load roll failed"); } // to be muted
		int mob3weaponshieldroller = roll(0,100);
		if (mob3weaponshieldroller<=zScript.getRm24mob3WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: ");
			loadZone.rm24.tmob3.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob3WeaponShieldID()));
			loadObject(loadZone.rm24.tmob3.mobWeaponShield, zScript.getRm24mob3WeaponShieldID());
		}
		//			else { System.out.println("weaponShield slot load roll failed"); } // to be muted
	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob3.getMobNum() +" could not be loaded");
	}

	// rm24 tmob4
	int mob4roller = roll(0,100);
//	System.out.println(mob4roller);
	if (mob4roller<=zScript.getRm24mob4Perc()) {
		//load mob stuff
		//			System.out.println("Will attempt to load mob: " + zScript.getRm24mob4());			
		// //mob stuffs
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob4ID()),4); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob4,Integer.valueOf(zScript.getRm24mob4ID()));			// load obj stuff
		// do roll for each getRm24mob4HeadID() and getRm24mob4HeadPerc() ...
		int mob4headroller = roll(0,100);
		if (mob4headroller<=zScript.getRm24mob4HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: ");
			loadZone.rm24.tmob4.setHeadSlot(String.valueOf(zScript.getRm24mob4HeadID()));
			loadObject(loadZone.rm24.tmob4.mobHelm, zScript.getRm24mob4HeadID());
		}
		else { System.out.println("head slot load roll failed"); } // to be muted			
		int mob4neckroller = roll(0,100);
		if (mob4neckroller<=zScript.getRm24mob4NeckPerc()) {
			//				System.out.println("Will attempt to load the mob's neck slot: ");
			loadZone.rm24.tmob4.setNeckSlot(String.valueOf(zScript.getRm24mob4NeckID()));
			loadObject(loadZone.rm24.tmob4.mobNeck, zScript.getRm24mob4NeckID());
		}
		else { System.out.println("neck slot load roll failed"); } // to be muted
		int mob4shoulderroller = roll(0,100);
		if (mob4shoulderroller<=zScript.getRm24mob4ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: ");
			loadZone.rm24.tmob4.setShoulderSlot(String.valueOf(zScript.getRm24mob4ShoulderID()));
			loadObject(loadZone.rm24.tmob4.mobShoulder, zScript.getRm24mob4ShoulderID());
		}
		else {
			//				System.out.println("shoulder slot load roll failed");
		} // to be muted
		int mob4chestroller = roll(0,100);
		if (mob4chestroller<=zScript.getRm24mob4ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: ");
			loadZone.rm24.tmob4.setChestSlot(String.valueOf(zScript.getRm24mob4ChestID()));
			loadObject(loadZone.rm24.tmob4.mobChest, zScript.getRm24mob4ChestID());
		}
		else {
			//				System.out.println("chest slot load roll failed");
		} // to be muted
		int mob4wristroller = roll(0,100);
		if (mob4wristroller<=zScript.getRm24mob4WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: ");
			loadZone.rm24.tmob4.setWristSlot(String.valueOf(zScript.getRm24mob4WristID()));
			loadObject(loadZone.rm24.tmob4.mobWrist, zScript.getRm24mob4WristID());
		}
		else { 
			//				System.out.println("wrist slot load roll failed");
		} // to be muted
		int mob4handroller = roll(0,100);
		if (mob4handroller<=zScript.getRm24mob4HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: ");
			loadZone.rm24.tmob4.setHandSlot(String.valueOf(zScript.getRm24mob4HandsID()));
			loadObject(loadZone.rm24.tmob4.mobHand, zScript.getRm24mob4HandsID());
		}
		else {
			//				System.out.println("hand slot load roll failed");
		} // to be muted
		int mob4finger1roller = roll(0,100);
		if (mob4finger1roller<=zScript.getRm24mob4Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: ");
			loadZone.rm24.tmob4.setFinger1(String.valueOf(zScript.getRm24mob4Finger1ID()));
			loadObject(loadZone.rm24.tmob4.mobFinger1, zScript.getRm24mob4Finger1ID());
		}
		//			else { System.out.println("Finger1 slot load roll failed"); } // to be muted
		int mob4finger2roller = roll(0,100);
		if (mob4finger2roller<=zScript.getRm24mob4Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: ");
			loadZone.rm24.tmob4.setFinger2(String.valueOf(zScript.getRm24mob4Finger2ID()));
			loadObject(loadZone.rm24.tmob4.mobFinger2, zScript.getRm24mob4Finger2ID());
		}
		//			else { System.out.println("Finger2 slot load roll failed"); } // to be muted
		int mob4waistroller = roll(0,100);
		if (mob4waistroller<=zScript.getRm24mob4WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: ");
			loadZone.rm24.tmob4.setWaistSlot(String.valueOf(zScript.getRm24mob4WaistID()));
			loadObject(loadZone.rm24.tmob4.mobWaist, zScript.getRm24mob4WaistID());
		}
		//			else { System.out.println("waist slot load roll failed"); } // to be muted
		int mob4legroller = roll(0,100);
		if (mob4legroller<=zScript.getRm24mob4LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: ");
			loadZone.rm24.tmob4.setLegSlot(String.valueOf(zScript.getRm24mob4LegID()));
			loadObject(loadZone.rm24.tmob4.mobLeg, zScript.getRm24mob4LegID());
		}
		//			else { System.out.println("leg slot load roll failed"); } // to be muted
		int mob4footroller = roll(0,100);
		if (mob4footroller<=zScript.getRm24mob4FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: ");
			loadZone.rm24.tmob4.setFootSlot(String.valueOf(zScript.getRm24mob4FootID()));
			loadObject(loadZone.rm24.tmob4.mobFoot, zScript.getRm24mob4FootID());
		}
		//			else { System.out.println("foot slot load roll failed"); } // to be muted
		int mob4trinket1roller = roll(0,100);
		if (mob4trinket1roller<=zScript.getRm24mob4Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: ");
			loadZone.rm24.tmob4.setTrinket1Slot(String.valueOf(zScript.getRm24mob4Trinket1ID()));
			loadObject(loadZone.rm24.tmob4.mobTrinket1, zScript.getRm24mob4Trinket1ID());
		}
		//			else { System.out.println("trinket1 slot load roll failed"); } // to be muted
		int mob4trinket2roller = roll(0,100);
		if (mob4trinket2roller<=zScript.getRm24mob4Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: ");
			loadZone.rm24.tmob4.setTrinket2Slot(String.valueOf(zScript.getRm24mob4Trinket2ID()));
			loadObject(loadZone.rm24.tmob4.mobTrinket2, zScript.getRm24mob4Trinket2ID());
		}
		//			else { System.out.println("trinket2 slot load roll failed"); } // to be muted
		int mob4weapon1roller = roll(0,100);
		if (mob4weapon1roller<=zScript.getRm24mob4Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: ");
			loadZone.rm24.tmob4.setWeapon1Slot(String.valueOf(zScript.getRm24mob4Weapon1ID()));
			loadObject(loadZone.rm24.tmob4.mobWeapon1, zScript.getRm24mob4Weapon1ID());
		}
		//			else { System.out.println("weapon1 slot load roll failed"); } // to be muted
		int mob4weaponshieldroller = roll(0,100);
		if (mob4weaponshieldroller<=zScript.getRm24mob4WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: ");
			loadZone.rm24.tmob4.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob4WeaponShieldID()));
			loadObject(loadZone.rm24.tmob4.mobWeaponShield, zScript.getRm24mob4WeaponShieldID());
		}
		//			else { System.out.println("weaponShield slot load roll failed"); } // to be muted

	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob4.getMobNum() +" could not be loaded");
	}

	// rm24 tmob5 
	int mob5roller = roll(0,100);
	//		System.out.println(mob5roller);
	if (mob5roller<=zScript.getRm24mob5Perc()) {
		//load mob stuff
		//			System.out.println("Will attempt to load mob: " + zScript.getRm24mob5());			
		// //mob stuffs
		loadZone.rm24.setMobNumAtPos(Integer.valueOf(zScript.getRm24mob5ID()),5); // sets the mob in the array // appears to do nothing
		loadMob(loadZone.rm24.tmob5,Integer.valueOf(zScript.getRm24mob0ID()));			// load obj stuff
		// do roll for each getRm24mob5HeadID() and getRm24mob5HeadPerc() ...
		int mob5headroller = roll(0,100);
		if (mob5headroller<=zScript.getRm24mob5HeadPerc()) {
			//				System.out.println("Will attempt to load the mob's head slot: ");
			loadZone.rm24.tmob5.setHeadSlot(String.valueOf(zScript.getRm24mob5HeadID()));
			loadObject(loadZone.rm24.tmob5.mobHelm, zScript.getRm24mob5HeadID());
		}
		//			else { System.out.println("head slot load roll failed"); } // to be muted			
		int mob5neckroller = roll(0,100);
		if (mob5neckroller<=zScript.getRm24mob5NeckPerc()) {
//			System.out.println("Will attempt to load the mob//'s neck slot: ");
			loadZone.rm24.tmob5.setNeckSlot(String.valueOf(zScript.getRm24mob5NeckID()));
			loadObject(loadZone.rm24.tmob5.mobNeck, zScript.getRm24mob5NeckID());
		}
		//			else { System.out.println("neck slot load roll failed"); } // to be muted
		int mob5shoulderroller = roll(0,100);
		if (mob5shoulderroller<=zScript.getRm24mob5ShoulderPerc()) {
			//				System.out.println("Will attempt to load the mob's shoulder slot: ");
			loadZone.rm24.tmob5.setShoulderSlot(String.valueOf(zScript.getRm24mob5ShoulderID()));
			loadObject(loadZone.rm24.tmob5.mobShoulder, zScript.getRm24mob5ShoulderID());
		}
		//			else { System.out.println("shoulder slot load roll failed"); } // to be muted
		int mob5chestroller = roll(0,100);
		if (mob5chestroller<=zScript.getRm24mob5ChestPerc()) {
			//				System.out.println("Will attempt to load the mob's chest slot: ");
			loadZone.rm24.tmob5.setChestSlot(String.valueOf(zScript.getRm24mob5ChestID()));
			loadObject(loadZone.rm24.tmob5.mobChest, zScript.getRm24mob5ChestID());
		}
		//			else { System.out.println("chest slot load roll failed"); } // to be muted
		int mob5wristroller = roll(0,100);
		if (mob5wristroller<=zScript.getRm24mob5WristPerc()) {
			//				System.out.println("Will attempt to load the mob's wrist slot: ");
			loadZone.rm24.tmob5.setWristSlot(String.valueOf(zScript.getRm24mob5WristID()));
			loadObject(loadZone.rm24.tmob5.mobWrist, zScript.getRm24mob5WristID());
		}
		//			else { System.out.println("wrist slot load roll failed"); } // to be muted
		int mob5handroller = roll(0,100);
		if (mob5handroller<=zScript.getRm24mob5HandsPerc()) {
			//				System.out.println("Will attempt to load the mob's hand slot: ");
			loadZone.rm24.tmob5.setHandSlot(String.valueOf(zScript.getRm24mob5HandsID()));
			loadObject(loadZone.rm24.tmob5.mobHand, zScript.getRm24mob5HandsID());
		}
		//			else { System.out.println("hand slot load roll failed"); } // to be muted
		int mob5finger1roller = roll(0,100);
		if (mob5finger1roller<=zScript.getRm24mob5Finger1Perc()) {
			//				System.out.println("Will attempt to load the mob's finger1 slot: ");
			loadZone.rm24.tmob5.setFinger1(String.valueOf(zScript.getRm24mob5Finger1ID()));
			loadObject(loadZone.rm24.tmob5.mobFinger1, zScript.getRm24mob5Finger1ID());
		}
		//			else { System.out.println("Finger1 slot load roll failed"); } // to be muted
		int mob5finger2roller = roll(0,100);
		if (mob5finger2roller<=zScript.getRm24mob5Finger2Perc()) {
			//				System.out.println("Will attempt to load the mob's finger2 slot: ");
			loadZone.rm24.tmob5.setFinger2(String.valueOf(zScript.getRm24mob5Finger2ID()));
			loadObject(loadZone.rm24.tmob5.mobFinger2, zScript.getRm24mob5Finger2ID());
		}
		//			else { System.out.println("Finger2 slot load roll failed"); } // to be muted
		int mob5waistroller = roll(0,100);
		if (mob5waistroller<=zScript.getRm24mob5WaistPerc()) {
			//				System.out.println("Will attempt to load the mob's waist slot: ");
			loadZone.rm24.tmob5.setWaistSlot(String.valueOf(zScript.getRm24mob5WaistID()));
			loadObject(loadZone.rm24.tmob5.mobWaist, zScript.getRm24mob5WaistID());
		}
		//			else { System.out.println("waist slot load roll failed"); } // to be muted
		int mob5legroller = roll(0,100);
		if (mob5legroller<=zScript.getRm24mob5LegPerc()) {
			//				System.out.println("Will attempt to load the mob's leg slot: ");
			loadZone.rm24.tmob5.setLegSlot(String.valueOf(zScript.getRm24mob5LegID()));
			loadObject(loadZone.rm24.tmob5.mobLeg, zScript.getRm24mob5LegID());
		}
		//			else { System.out.println("leg slot load roll failed"); } // to be muted
		int mob5footroller = roll(0,100);
		if (mob5footroller<=zScript.getRm24mob5FootPerc()) {
			//				System.out.println("Will attempt to load the mob's foot slot: ");
			loadZone.rm24.tmob5.setFootSlot(String.valueOf(zScript.getRm24mob5FootID()));
			loadObject(loadZone.rm24.tmob5.mobFoot, zScript.getRm24mob5FootID());
		}
		//			else { System.out.println("foot slot load roll failed"); } // to be muted
		int mob5trinket1roller = roll(0,100);
		if (mob5trinket1roller<=zScript.getRm24mob5Trinket1Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket1 slot: ");
			loadZone.rm24.tmob5.setTrinket1Slot(String.valueOf(zScript.getRm24mob5Trinket1ID()));
			loadObject(loadZone.rm24.tmob5.mobTrinket1, zScript.getRm24mob5Trinket1ID());
		}
		//			else { System.out.println("trinket1 slot load roll failed"); } // to be muted
		int mob5trinket2roller = roll(0,100);
		if (mob5trinket2roller<=zScript.getRm24mob5Trinket2Perc()) {
			//				System.out.println("Will attempt to load the mob's trinket2 slot: ");
			loadZone.rm24.tmob5.setTrinket2Slot(String.valueOf(zScript.getRm24mob5Trinket2ID()));
			loadObject(loadZone.rm24.tmob5.mobTrinket2, zScript.getRm24mob5Trinket2ID());
		}
		//			else { System.out.println("trinket2 slot load roll failed"); } // to be muted
		int mob5weapon1roller = roll(0,100);
		if (mob5weapon1roller<=zScript.getRm24mob5Weapon1Perc()) {
			//				System.out.println("Will attempt to load the mob's weapon1 slot: ");
			loadZone.rm24.tmob5.setWeapon1Slot(String.valueOf(zScript.getRm24mob5Weapon1ID()));
			loadObject(loadZone.rm24.tmob5.mobWeapon1, zScript.getRm24mob5Weapon1ID());
		}
		//			else { System.out.println("weapon1 slot load roll failed"); } // to be muted
		int mob5weaponshieldroller = roll(0,100);
		if (mob5weaponshieldroller<=zScript.getRm24mob5WeaponShieldPerc()) {
			//				System.out.println("Will attempt to load the mob's weaponShield slot: ");
			loadZone.rm24.tmob5.setWeaponShieldSlot(String.valueOf(zScript.getRm24mob5WeaponShieldID()));
			loadObject(loadZone.rm24.tmob5.mobWeaponShield, zScript.getRm24mob5WeaponShieldID());
		}
		//			else { System.out.println("weaponShield slot load roll failed"); } // to be muted
	}
	else {
		//			System.out.println("Mob " + loadZone.rm24.tmob5.getMobNum() +" could not be loaded");
	}
} // end loadrm24mobs()