package Game;

import java.util.Arrays;

public class player extends mob {

	int playerNum; //0
	String playerName; //1 a name
	String playerShortDesc; //2 a sentence fragment. ex "a fat, hairy dwarf"
	String playerLongDesc; //3 a short paragraph
	String[] playerKeyWords; //4
	int playerHP = 100; //5
	int playerMP = 100;// 6
	int playerLvl = 1; // 7
	int Stam = 10; //8 increases player HPs
	int Str = 10; //9 increases player base dmg
	int Intel = 10; //10 higher intel increases player mana
	int Agility = 10; //11 higher agility increases critical strike chance
	String headSlot = "nothing"; //12
	String neckSlot = "nothing"; //13
	String shoulderSlot = "nothing"; //14
	String chestSlot = "nothing";// 15
	String wristSlot = "nothing"; //16
	String handSlot = "nothing"; //17
	String finger1 = "nothing";//18 
	String finger2 = "nothing";  // 19
	String waistSlot = "nothing"; //20
	String legSlot = "nothing";//21
	String footSlot = "nothing";//22
	String trinket1Slot = "nothing";//23
	String trinket2Slot = "nothing";//24
	String weapon1Slot = "nothing"; //25
	String weaponShieldSlot = "nothing";//26
	String playerRace; //27  humanoid
	String playerSubRace = "none"; //28 none, human, elf, half-elf, dwarf, orc, troll, tauren, ...
	String playerTier = "0"; //29 "mob rank"
	/*
	 * 	Player Tier ranks:
	 * 		players can have ranks, higher ranks increase their health and damage and available spells/abilities
	 * 		Tier 0 - default tier
	 * 		Tier 1 - hp, dps increase by 125%
	 * 		Tier 2 - hp, dps increase 150%
	 * 		Tier 3 - hp, dps increase 175%
	 * 		Tier 4 - hp, dps increase 200%
	 * 		Tier Imm - hp, dps increase 1000%
	 * 		Tier GImm - access to dev tools
	 */

	int playerXP = 0; //30

	/*
	 *   XP for lvl 1-2 = 1000 XP, lvl 2-3 = 1500, lvl 3-4 = 2250, 3375, 5063, 7594, 11391, 17087, 25630,
	 *   38445, 57667, 86501, 129751, 194626. 291939, 437904, 656863
	 *   XP increases by 1.5x per subsequent level
	 */
	int playerIsAlive = 1; //31
	String playerGender = "none"; //32
	int playerMaxHP;
	int playerMaxMP;
	String playerClass = "none"; //33 ("1 - Cleric, 2 - Druid, 3 - Paladin, 4 - Fighter, 5 - Barbarian, 6 - Rogue, 7 - Mage, 0 - None");

	String blank1 = "unused"; //34	// attackable?
	String blank2 = "unused"; //35	// wanders = 1; // set to 0 on mobs by default so they are stationary
	String blank3 = "unused"; //36  // inCombat?
	String blank4 = "unused"; //37  // Target = "";?
	String blank5 = "unused"; //38  // isAggressive = 0; // maybe special effect to make this do something for players?
	String blank6 = "unused"; //39
	String blank7 = "unused"; //40
	String blank8 = "unused"; //41
	String blank9 = "unused"; //42
	String blank10 = "unused"; //43
	String blank11 = "unused"; //44
	String blank12 = "unused"; //45
	String blank13 = "unused"; //46 // mobTalker
	String blank14 = "unused"; //47 // mobSpeech1
	String blank15 = "unused"; //48 // mobSpeech2
	String blank16 = "unused"; //49 // mobSpeech3

	public objects pHelm;
	public objects pNeck;
	public objects pShoulder;//
	public objects pChest;//
	public objects pWrist;//
	public objects pHand;//
	public objects pFinger1;//
	public objects pFinger2;//
	public objects pWaist;//
	public objects pLeg;//
	public objects pFoot;//
	public objects pTrinket1;//
	public objects pTrinket2;//
	public objects pWeapon1;//
	public objects pWeaponShield;//
	
	public int getAgility() {
		return Agility;
	}

	public String getBlank1() {
		return blank1;
	}

	public String getBlank10() {
		return blank10;
	}

	public String getBlank11() {
		return blank11;
	}

	public String getBlank12() {
		return blank12;
	}

	public String getBlank13() {
		return blank13;
	}

	public String getBlank14() {
		return blank14;
	}

	public String getBlank15() {
		return blank15;
	}

	public String getBlank16() {
		return blank16;
	}

	public String getBlank2() {
		return blank2;
	}

	public String getBlank3() {
		return blank3;
	}

	public String getBlank4() {
		return blank4;
	}

	public String getBlank5() {
		return blank5;
	}

	public String getBlank6() {
		return blank6;
	}

	public String getBlank7() {
		return blank7;
	}

	public String getBlank8() {
		return blank8;
	}

	public String getBlank9() {
		return blank9;
	}

	public String getChestSlot() {
		return chestSlot;
	}

	public String getFinger1() {
		return finger1;
	}

	public String getFinger2() {
		return finger2;
	}

	public String getFootSlot() {
		return footSlot;
	}

	public String getHandSlot() {
		return handSlot;
	}

	public String getHeadSlot() {
		return headSlot;
	}

	public int getIntel() {
		return Intel;
	}

	public String getKeyWord(int i) {
		return playerKeyWords[i];
	}

	public String getLegSlot() {
		return legSlot;
	}

	public String getNeckSlot() {
		return neckSlot;
	}

	public String getPlayerClass() {
		return playerClass;
	}

	public String getPlayerGender() {
		return playerGender;
	}

	public int getPlayerHP() {
		return playerHP;
	}

	public int getPlayerIsAlive() {
		return playerIsAlive;
	}

	public String[] getPlayerKeyWords() {
		return playerKeyWords;
	}

	public String getPlayerLongDesc() {
		return playerLongDesc;
	}

	public int getPlayerLvl() {
		return playerLvl;
	}

	public int getPlayerMaxHP() {
		return playerMaxHP;
	}

	public int getPlayerMaxMP() {
		return playerMaxMP;
	}

	public int getPlayerMP() {
		return playerMP;
	}

	public String getPlayerName() {
		return playerName;
	}

	public int getPlayerNum() {
		return playerNum;
	}

	public String getPlayerRace() {
		return playerRace;
	}

	public String getPlayerShortDesc() {
		return playerShortDesc;
	}

	public String getPlayerSubRace() {
		return playerSubRace;
	}

	public String getPlayerTier() {
		return playerTier;
	}

	public int getPlayerXP() {
		return playerXP;
	}

	public String getShoulderSlot() {
		return shoulderSlot;
	}

	public int getStam() {
		return Stam;
	}

	public int getStr() {
		return Str;
	}

	public String getTrinket1Slot() {
		return trinket1Slot;
	}

	public String getTrinket2Slot() {
		return trinket2Slot;
	}

	public String getWaistSlot() {
		return waistSlot;
	}

	public String getWeapon1Slot() {
		return weapon1Slot;
	}

	public String getWeaponShieldSlot() {
		return weaponShieldSlot;
	}

	public String getWristSlot() {
		return wristSlot;
	}

	public void setAgility(int agility) {
		Agility = agility;
	}

	public void setBlank1(String blank1) {
		this.blank1 = blank1;
	}

	public void setBlank10(String blank10) {
		this.blank10 = blank10;
	}

	public void setBlank11(String blank11) {
		this.blank11 = blank11;
	}

	public void setBlank12(String blank12) {
		this.blank12 = blank12;
	}

	public void setBlank13(String blank13) {
		this.blank13 = blank13;
	}

	public void setBlank14(String blank14) {
		this.blank14 = blank14;
	}

	public void setBlank15(String blank15) {
		this.blank15 = blank15;
	}

	public void setBlank16(String blank16) {
		this.blank16 = blank16;
	}

	public void setBlank2(String blank2) {
		this.blank2 = blank2;
	}

	public void setBlank3(String blank3) {
		this.blank3 = blank3;
	}

	public void setBlank4(String blank4) {
		this.blank4 = blank4;
	}

	public void setBlank5(String blank5) {
		this.blank5 = blank5;
	}

	public void setBlank6(String blank6) {
		this.blank6 = blank6;
	}

	public void setBlank7(String blank7) {
		this.blank7 = blank7;
	}

	public void setBlank8(String blank8) {
		this.blank8 = blank8;
	}

	public void setBlank9(String blank9) {
		this.blank9 = blank9;
	}

	public void setChestSlot(String chestSlot) {
		this.chestSlot = chestSlot;
	}

	public void setFinger1(String finger1) {
		this.finger1 = finger1;
	}

	public void setFinger2(String finger2) {
		this.finger2 = finger2;
	}

	public void setFootSlot(String footSlot) {
		this.footSlot = footSlot;
	}

	public void setHandSlot(String handSlot) {
		this.handSlot = handSlot;
	}

	public void setHeadSlot(String headSlot) {
		this.headSlot = headSlot;
	}

	public void setIntel(int intel) {
		Intel = intel;
	}

	public void setLegSlot(String legSlot) {
		this.legSlot = legSlot;
	}

	public void setNeckSlot(String neckSlot) {
		this.neckSlot = neckSlot;
	}

	public void setPlayerClass(String playerClass) {
		this.playerClass = playerClass;
	}

	public void setPlayerGender(String playerGender) {
		this.playerGender = playerGender;
	}

	public void setPlayerHP(int playerHP) {
		this.playerHP = playerHP;
	}

	public void setPlayerIsAlive(int playerIsAlive) {
		this.playerIsAlive = playerIsAlive;
	}

	public void setPlayerKeyWords(String[] playerKeyWords) {
		this.playerKeyWords = playerKeyWords;
	}

	public void setPlayerLongDesc(String playerLongDesc) {
		this.playerLongDesc = playerLongDesc;
	}

	public void setPlayerLvl(int playerLvl) {
		this.playerLvl = playerLvl;
	}

	public void setPlayerMaxHP(int playerMaxHP) {
		this.playerMaxHP = playerMaxHP;
	}

	public void setPlayerMaxMP(int playerMaxMP) {
		this.playerMaxMP = playerMaxMP;
	}

	public void setPlayerMP(int playerMP) {
		this.playerMP = playerMP;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public void setPlayerNum(int playerNum) {
		this.playerNum = playerNum;
	}

	public void setPlayerRace(String playerRace) {
		this.playerRace = playerRace;
	}

	public void setPlayerShortDesc(String playerShortDesc) {
		this.playerShortDesc = playerShortDesc;
	}

	public void setPlayerSubRace(String playerSubRace) {
		this.playerSubRace = playerSubRace;
	}

	public void setPlayerTier(String playerTier) {
		this.playerTier = playerTier;
	}

	public void setPlayerXP(int playerXP) {
		this.playerXP = playerXP;
	}

	public void setShoulderSlot(String shoulderSlot) {
		this.shoulderSlot = shoulderSlot;
	}

	public void setStam(int stam) {
		Stam = stam;
	}

	public void setStr(int str) {
		Str = str;
	}

	public void setTrinket1Slot(String trinket1Slot) {
		this.trinket1Slot = trinket1Slot;
	}

	public void setTrinket2Slot(String trinket2Slot) {
		this.trinket2Slot = trinket2Slot;
	}

	public void setWaistSlot(String waistSlot) {
		this.waistSlot = waistSlot;
	}

	public void setWeapon1Slot(String weapon1Slot) {
		this.weapon1Slot = weapon1Slot;
	}

	public void setWeaponShieldSlot(String weaponShieldSlot) {
		this.weaponShieldSlot = weaponShieldSlot;
	}

	public void setWristSlot(String wristSlot) {
		this.wristSlot = wristSlot;
	}

	public void returnPlayerInfo() {
		// not current used, see engine.java playerScore()
		System.out.println("Player Name: " + getPlayerName());
		System.out.println("Description: " + getPlayerLongDesc());
		System.out.println("Race: [" + getPlayerRace() + "]  Level: [" + getPlayerLvl() + "]   Tier: [" + getPlayerTier() + "]");
		System.out.println("XP: [" + getPlayerXP() + "]");
		System.out.println("HPs: [" + getPlayerHP() + "/" + getPlayerMaxHP() + "]   MPs: [" + getPlayerMP() + "/" + getPlayerMaxMP() + "]");
		System.out.println("Stamina: " + getStam() + "  Strength: " + getStr() + "   Intelligence: " + getIntel() + "   Agility: " + getAgility());
		System.out.println("Equiped Items -----------------------------------------------------------");
		System.out.println("Head Slot: " + getHeadSlot());
		System.out.println("Neck Slot: " + getNeckSlot());
		System.out.println("Shoulder Slot: " + getShoulderSlot());
		System.out.println("Chest Slot: " + getChestSlot());
		System.out.println("Chest Slot2: "  );
		System.out.println("Wrist Slot: " + getWristSlot());
		System.out.println("Hand Slot: " + getHandSlot());		
		System.out.println("Finger Slot: " + getFinger1());
		System.out.println("Finger Slot: " + getFinger2());
		System.out.println("Waist Slot: " + getWaistSlot());
		System.out.println("Leg Slot: " + getLegSlot());
		System.out.println("Foot Slot: " + getFootSlot());
		System.out.println("Trinket Slot: " + getTrinket1Slot());
		System.out.println("Trinket Slot: " + getTrinket2Slot());
		System.out.println("Weapon Slot: " + getWeapon1Slot());
		System.out.println("Offhand Slot: " + getWeaponShieldSlot());
	}

	@Override
	public String toString() {
		return playerNum + "|" + playerName + "|" + playerShortDesc + "|" + playerLongDesc + "|"
				+ Arrays.toString(playerKeyWords) + "|" + playerHP + "|" + playerMP + "|" + playerLvl + "|" + Stam + "|"
				+ Str + "|" + Intel + "|" + Agility + "|" + headSlot + "|" + neckSlot + "|" + shoulderSlot + "|"
				+ chestSlot + "|" + wristSlot + "|" + handSlot + "|" + finger1 + "|" + finger2 + "|" + waistSlot + "|"
				+ legSlot + "|" + footSlot + "|" + trinket1Slot + "|" + trinket2Slot + "|" + weapon1Slot + "|"
				+ weaponShieldSlot + "|" + playerRace + "|" + playerSubRace + "|" + playerTier + "|" + playerXP + "|"
				+ playerIsAlive + "|" + playerGender + "|" + playerMaxHP + "|" + playerMaxMP + "|" + playerClass + "|"
				+ blank1 + "|" + blank2 + "|" + blank3 + "|" + blank4 + "|" + blank5 + "|" + blank6 + "|" + blank7 + "|"
				+ blank8 + "|" + blank9 + "|" + blank10 + "|" + blank11 + "|" + blank12 + "|" + blank13 + "|" + blank14
				+ "|" + blank15 + "|" + blank16;
	}

} // end player class
