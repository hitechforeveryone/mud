package Game;
//TODO
// THE GAME CURRENTLY DOES NOT USE THIS AT ALL THIS IS FOR DESIGN PURPOSES

/////////////////////////////////
// zone should have 100 rooms in it (0-99), the array will continue to build around you if you skip a room
// each room can have up to 6 mobs and 6 objects in it
/////////////////////////////////

public class zone {
	// TODO

	int zoneNum = 0; //0 // should be up to 6 digits?    
	String zoneOwner = "none"; //1 Char name?
	String zoneName = "none"; //2 optional
	int zoneResetState = 0; // states are 
	int resetTimer; //3 time till zone reloads, in weeks or months? not sure how this will work just yet

	mob tmob0 = new mob();
	mob tmob1 = new mob();
	mob tmob2 = new mob();
	mob tmob3 = new mob();
	mob tmob4 = new mob();
	mob tmob5 = new mob();
	
	objects tobj0 = new objects();
	objects tobj1 = new objects();
	objects tobj2 = new objects();
	objects tobj3 = new objects();
	objects tobj4 = new objects();
	objects tobj5 = new objects();
	
	String rmNums; // = "00,01,02,03,04,05,06,07,08,09,10,01,02,03,04,05,06,07,08,09,20,01,02,03,04,05,06,07,08,09,30,01,02,03,04,05,06,07,08,09,40,01,02,03,04,05,06,07,08,09,50,01,02,03,04,05,06,07,08,09,60,01,02,03,04,05,06,07,08,09,70,01,02,03,04,05,06,07,08,09,80,01,02,03,04,05,06,07,08,09,90,01,02,03,04,05,06,07,08,09, ";
	room rm00 = new room(); // should be 2 digits, this is separate from the room's ID number
	room rm01 = new room();
	room rm02 = new room();
	room rm03 = new room();
	room rm04 = new room();
	room rm05 = new room();
	room rm06 = new room();
	room rm07 = new room();
	room rm08 = new room();
	room rm09 = new room();

	room rm10 = new room();
	room rm11 = new room();
	room rm12 = new room();
	room rm13 = new room();
	room rm14 = new room();
	room rm15 = new room();
	room rm16 = new room();
	room rm17 = new room();
	room rm18 = new room();
	room rm19 = new room();

	room rm20 = new room();
	room rm21 = new room();
	room rm22 = new room();
	room rm23 = new room();
	room rm24 = new room();





	public void resetZone() {
		zoneNum = 0; //0 // should be up to 6 digits?    
		zoneOwner = "none"; //1 Char name?
		zoneName = "none"; //2 optional
		resetTimer = 300; //3 time till zone reloads, in weeks or months? not sure how this will work just yet
		
		String newString="";//
	
		rmNums = newString; // = "00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,08,09,40,01,02,03,04,05,06,07,08,09,50,01,02,03,04,05,06,07,08,09,60,01,02,03,04,05,06,07,08,09,70,01,02,03,04,05,06,07,08,09,80,01,02,03,04,05,06,07,08,09,90,01,02,03,04,05,06,07,08,09, ";
		
		tmob0.reset();
		tmob1.reset();
		tmob2.reset();
		tmob3.reset();
		tmob4.reset();
		tmob5.reset();
		
		tobj0.resetObject();
		tobj1.resetObject();
		tobj2.resetObject();
		tobj3.resetObject();
		tobj4.resetObject();
		tobj5.resetObject();
		
		rm00.resetRoom(); // should be 2 digits, this is separate from the room's ID number
		rm01.resetRoom();
		rm02.resetRoom();
		rm03.resetRoom();
		rm04.resetRoom();
		rm05.resetRoom();
		rm06.resetRoom();
		rm07.resetRoom();
		rm08.resetRoom();
		rm09.resetRoom();

		rm10.resetRoom();
		rm11.resetRoom();
		rm12.resetRoom();
		rm13.resetRoom();
		rm14.resetRoom();
		rm15.resetRoom();
		rm16.resetRoom();
		rm17.resetRoom();
		rm18.resetRoom();
		rm19.resetRoom();

		rm20.resetRoom();
		rm21.resetRoom();
		rm22.resetRoom();
		rm23.resetRoom();
		rm24.resetRoom();


	} // end resetZone()




	public int getZoneNum() {
		return zoneNum;
	}




	public void setZoneNum(int zoneNum) {
		this.zoneNum = zoneNum;
	}




	public String getZoneOwner() {
		return zoneOwner;
	}




	public void setZoneOwner(String zoneOwner) {
		this.zoneOwner = zoneOwner;
	}




	public String getZoneName() {
		return zoneName;
	}




	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}




	public int getResetTimer() {
		return resetTimer;
	}




	public void setResetTimer(int resetTimer) {
		this.resetTimer = resetTimer;
	}




	public room getRm00() {
		return rm00;
	}




	public void setRm00(room rm00) {
		this.rm00 = rm00;
	}




	public room getRm01() {
		return rm01;
	}




	public void setRm01(room rm01) {
		this.rm01 = rm01;
	}




	public room getRm02() {
		return rm02;
	}




	public void setRm02(room rm02) {
		this.rm02 = rm02;
	}




	public room getRm03() {
		return rm03;
	}




	public void setRm03(room rm03) {
		this.rm03 = rm03;
	}




	public room getRm04() {
		return rm04;
	}




	public void setRm04(room rm04) {
		this.rm04 = rm04;
	}




	public room getRm05() {
		return rm05;
	}




	public void setRm05(room rm05) {
		this.rm05 = rm05;
	}




	public room getRm06() {
		return rm06;
	}




	public void setRm06(room rm06) {
		this.rm06 = rm06;
	}




	public room getRm07() {
		return rm07;
	}




	public void setRm07(room rm07) {
		this.rm07 = rm07;
	}




	public room getRm08() {
		return rm08;
	}




	public void setRm08(room rm08) {
		this.rm08 = rm08;
	}




	public room getRm09() {
		return rm09;
	}




	public void setRm09(room rm09) {
		this.rm09 = rm09;
	}




	public room getRm10() {
		return rm10;
	}




	public void setRm10(room rm10) {
		this.rm10 = rm10;
	}




	public room getRm11() {
		return rm11;
	}




	public void setRm11(room rm11) {
		this.rm11 = rm11;
	}




	public room getRm12() {
		return rm12;
	}




	public void setRm12(room rm12) {
		this.rm12 = rm12;
	}




	public room getRm13() {
		return rm13;
	}




	public void setRm13(room rm13) {
		this.rm13 = rm13;
	}




	public room getRm14() {
		return rm14;
	}




	public void setRm14(room rm14) {
		this.rm14 = rm14;
	}




	public room getRm15() {
		return rm15;
	}




	public void setRm15(room rm15) {
		this.rm15 = rm15;
	}




	public room getRm16() {
		return rm16;
	}




	public void setRm16(room rm16) {
		this.rm16 = rm16;
	}




	public room getRm17() {
		return rm17;
	}




	public void setRm17(room rm17) {
		this.rm17 = rm17;
	}




	public room getRm18() {
		return rm18;
	}




	public void setRm18(room rm18) {
		this.rm18 = rm18;
	}




	public room getRm19() {
		return rm19;
	}




	public void setRm19(room rm19) {
		this.rm19 = rm19;
	}




	public room getRm20() {
		return rm20;
	}




	public void setRm20(room rm20) {
		this.rm20 = rm20;
	}




	public room getRm21() {
		return rm21;
	}




	public void setRm21(room rm21) {
		this.rm21 = rm21;
	}




	public room getRm22() {
		return rm22;
	}




	public void setRm22(room rm22) {
		this.rm22 = rm22;
	}




	public room getRm23() {
		return rm23;
	}




	public void setRm23(room rm23) {
		this.rm23 = rm23;
	}




	public room getRm24() {
		return rm24;
	}




	public void setRm24(room rm24) {
		this.rm24 = rm24;
	}






	public void returnZoneInfo() {
		// returns relevant info for the zone
				System.out.println("from returnZoneInfo()");
				System.out.println("Zone ID Num: " + getZoneNum()); //0
				System.out.println("Zone Owner: " + getZoneOwner()); //1
				System.out.println("Zone Name: " + getZoneName()); //2
				System.out.println("Zone ResetTimer: " + getResetTimer()); //2
				
				// add more zone info here // room # and room names?
	}

	@Override
	public String toString() {
		return getZoneNum() + "|" + getZoneOwner() + "|" + getZoneName() + "|" + getResetTimer() + "|" + getRm00() + "|" 
				+ getRm01() + "|" + getRm02() + "|" + getRm03() + "|" + getRm04() + "|" + getRm05() + "|" + getRm06() + "|" + getRm07() 
				+ "|" + getRm08() + "|" + getRm09() + "|" + getRm10() + "|" + getRm11() + "|" + getRm12() + "|" + getRm13() + "|" + getRm14()
				+ "|" + getRm15() + "|" + getRm16() + "|" + getRm17() + "|" + getRm18() + "|" + getRm19() + "|" + getRm20() + "|" + getRm21()
				+ "|" + getRm22() + "|" + getRm23() + "|" + getRm24()  ;
	}


	

	
	

} // end zone ....





// TODO
// scripts which load mobs and objs? doors? // load next zone

// roomScript srm00;  // create as needed? // set mob and obj defaults to all 0s?
// setObj0(0,100);setObj1(0,100);setOBj2(0,100);setObj3(0,100);setObj4(0,100);setObj5(0,100); //  set the obj to 0 at 100%?

// setMob0(0,100);setMob1(0,100);setMob2(0,100);setMob3(0,100);setMob4(0,100);setMob5(0,100); // set the mob to 0 at 100%?

// tmob0Head(0,1000;tmob0Neck(0,100);tmob0Shoulder(0,100);tmob0Chest(0,100);tmob0Wrist(0,100);tmob0Hand(0,100);tmob0Finger1(0,100);tmob0Finger2(0,100);
// tmob0Waist(0,100);tmob0Leg(0,100);tmob0Foot(0,100);tmob0Trinket1(0,100);tmob0Trinket2(0,100);tmob0Weapon1(0,100);tmob0Weaponshield(0,100); // set all equip to obj 0 at 100%?

// script load zone xxxxxx
//		to be used for loading next zones
//		to be used for loading the 6 objs in the rooms
//		to be used for loading the 6 mobs in the rooms
//		to be used for loading the equip on the mobs



