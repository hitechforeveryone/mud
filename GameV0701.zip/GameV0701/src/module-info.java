/**
 * 
 */
/**
 * 
 */
module GameV0701 {
	requires com.google.gson;
}