package mud.core;

public enum Direction {
    NORTH,
    NORTHEAST,
    EAST,
    SOUTHEAST,
    SOUTH,
    SOUTHWEST,
    WEST,
    NORTHWEST,
    UP,
    DOWN;

    public static Direction fromString(String input) {
        if (input == null) return null;

        String normalized = input.trim().toLowerCase();

        switch (normalized) {
            case "n": case "north": return NORTH;
            case "ne": case "northeast": case "north east": return NORTHEAST;
            case "e": case "east": return EAST;
            case "se": case "southeast": case "south east": return SOUTHEAST;
            case "s": case "south": return SOUTH;
            case "sw": case "southwest": case "sout hwest": return SOUTHWEST;
            case "w": case "west": return WEST;
            case "nw": case "northwest": case "north west": return NORTHWEST;
            case "u": case "up": case "upward": return UP;
            case "d": case "down": case "downward": return DOWN;
            default: return null;
        }
    }

    public Direction getOpposite() {
        return switch (this) {
            case NORTH -> SOUTH;
            case SOUTH -> NORTH;
            case EAST -> WEST;
            case WEST -> EAST;
            case UP -> DOWN;
            case DOWN -> UP;
            case NORTHEAST -> SOUTHWEST;
            case SOUTHWEST -> NORTHEAST;
            case NORTHWEST -> SOUTHEAST;
            case SOUTHEAST -> NORTHWEST;
        };
    }
    
    @Override
    public String toString() {
        // Title-cased name
        return name().charAt(0) + name().substring(1).toLowerCase();
    }

    public String toShortString() {
        switch (this) {
            case NORTH: return "n";
            case NORTHEAST: return "ne";
            case EAST: return "e";
            case SOUTHEAST: return "se";
            case SOUTH: return "s";
            case SOUTHWEST: return "sw";
            case WEST: return "w";
            case NORTHWEST: return "nw";
            case UP: return "u";
            case DOWN: return "d";
            default: return name().toLowerCase();
        }
    }
}
